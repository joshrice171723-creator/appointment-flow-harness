# Apex Appointment Flow — independent rebuild

Rails API, React/TypeScript and PostgreSQL; fictional Austin/Phoenix records and fake SMS/email only. The extracted harness is the project root. No prior application source was read or copied.

## Run on Windows

Prerequisites used here: Ruby 3.4.10, Bundler 4.0.15, Rails 8.1.4.1, Node 24.22.1, npm 11.19.1, Docker Desktop. PostgreSQL image resolved to 17.11. React/Vite/TypeScript versions are pinned in frontend/package-lock.json; Ruby versions in backend/Gemfile.lock.

From this directory in PowerShell:

```powershell
.\Start.ps1 -Setup
```

This starts the isolated demo database on 127.0.0.1:55442, installs locked dependencies, prepares/seeds the database and starts API/UI processes. Open http://127.0.0.1:5176. Subsequent starts use `.\Start.ps1`. It prints owned process IDs for stopping. Stop the database with `docker stop apex-clean-v22-db`; do not remove its data to stop it.

For terminal-visible startup, run `bundle exec rails server -b 127.0.0.1 -p 3022` in backend and `npm run dev` in frontend in separate terminals. Do not start duplicate servers. Local credentials in config and compose.yml are disposable demo values; never use them for hosted access.

## Exercise the workflow

1. Select clinic/staff in Workspaces → Front desk. Review Patient flow or Appointments. Pick a date near today to see upcoming seeds. Austin uses America/Chicago; Phoenix uses America/Phoenix.
2. Click Refresh PMS, then Run fake reminders. Batches send only 10:00–18:00 clinic time, before the visit. Outside that window they record zero attempts.
3. Open Patient workspace, choose clinic/patient appointment, then Text messages or Email. Choose the specific reminder and send YES, NO, STOP, or uncertain wording. These simulated provider events use the same server rules as inbound requests. No real delivery occurs.
4. Inspect successful and failed fake attempts in the inbox or patient Activity log. Exact YES confirms only a trusted, current, unambiguous future appointment revision; other replies require staff review. STOP persists independently of source data.
5. Assign work and record a note with attempted contact, confirmed, canceled or rescheduled outcome. The last two suppress local outreach; source booking changes still belong in the PMS. Local contact corrections preserve source facts and audit notes. Source changes after verification create a hold.
6. Leadership reports aggregate recorded PMS outcomes, not no-shows or causal improvement. Its API returns an explicit aggregate allowlist.

CLI reminder trigger (backend):

```powershell
bundle exec rails runner 'PmsRefresh.run; Practice.find_each { |p| puts ReminderBatch.run(practice: p) }'
```

For an evening demo, run `bundle exec rails runner script/demo_reminders.rb` from backend. This explicitly simulates today at clinic-local noon, records only fake attempts, then refreshes to restore current source trust. It does not change PMS appointment times. Tests inject clocks; HTTP endpoints use actual time.

## Verify

```powershell
py quality/run_checks.py
```

The configured gate includes Rails tests, RuboCop, Brakeman, Zeitwerk, React lint/types/tests/build. To run browser smoke with the two servers already running: `cd frontend; npx playwright test`. Smoke uses installed Microsoft Edge, with screenshots in notes/screenshots. It does not install a browser.

Original package preflight passed before any code was written. MANIFEST.sha256 describes the original ZIP, including mutable note/checklist files; it is retained as provenance, not regenerated to conceal later changes.

## Boundaries and limits

- The official PMS tables live in the pms schema. Only explicit setup/seeding writes them. Runtime refresh uses apex_reader with database SELECT permission only. Local workflow state lives in public tables.
- A source read is atomic; empty/failed/DST-ambiguous reads preserve tracked state and pause reminders. The replica can lag five minutes; a refresh does not make it the live booking system. Snapshots older than ten minutes cannot send or auto-confirm.
- Revision changes require fresh confirmation, including returning to an earlier appointment time. Historical deliveries retain original patient/clinic identity.
- Global database serialization is deliberate for this demo. Source refresh and clinic history are loaded in memory. Before operating at the brief's full volume, measure refresh and reply costs, bound source windows, and move history pagination to SQL. No throughput claim is made.
- Consent is a locally verified demo fact because the supplied PMS lacks permission fields. Available-channel permission defaults to the explicit combined verification, with separate SMS/email controls. Minors remain on hold: guardian authorization workflow is not implemented. Unsupported language remains on hold.
- Stub identities and clinic selection are not production authentication. Before production: server-verified staff sessions and clinic grants, authenticated provider webhooks, verified consent policy, protected secrets, retention/access controls, and real delivery reconciliation.
- No full booking/rescheduling UI, live vendors, deployment, or production authentication. UI has broad screenshot structure, not pixel equivalence. Detailed longitudinal analytics and multi-appointment reply clarification are not fully implemented; staff can explicitly record confirmed outcomes for individually clarified visits.
- Candidate must personally author DECISIONS.md. See notes/CANDIDATE_DECISION_NOTES.md; no agent-authored narrative is attributed to the candidate.
