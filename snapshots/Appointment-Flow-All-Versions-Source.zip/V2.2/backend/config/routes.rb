Rails.application.routes.draw do
  get "api/practices", to: "practices#index"
  get "api/practices/:practice_id/visits", to: "visits#index"
  post "api/practices/:practice_id/visits/:visit_id/actions", to: "staff_actions#create"
  post "api/practices/:practice_id/reminders", to: "reminders#create"
  post "api/practices/:practice_id/refresh", to: "refreshes#create"
  get "api/leadership", to: "leadership#index"
  post "api/practices/:practice_id/replies", to: "replies#create"
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
end
