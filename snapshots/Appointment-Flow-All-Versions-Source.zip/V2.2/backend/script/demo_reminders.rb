# Explicit daytime simulation for an evening demo; the source appointment times stay unchanged.
begin
  PmsRefresh.run
  Practice.find_each do |practice|
    clock = Time.current.in_time_zone(practice.timezone).change(hour: 12, min: 0, sec: 0)
    practice.update!(synced_at: clock)
    count = ReminderBatch.run(practice: practice, now: clock)
    puts "#{practice.name}: #{count} fake attempts at simulated clinic-local noon"
  end
ensure
  PmsRefresh.run
end
