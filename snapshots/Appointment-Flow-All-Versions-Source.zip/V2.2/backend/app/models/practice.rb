class Practice < ApplicationRecord
  has_many :visits
end
