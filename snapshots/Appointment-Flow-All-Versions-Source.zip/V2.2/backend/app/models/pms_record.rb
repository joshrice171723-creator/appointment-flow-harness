class PmsRecord < ActiveRecord::Base
  self.abstract_class = true
  establish_connection({ adapter: "postgresql", host: "127.0.0.1", port: ENV.fetch("APEX_DB_PORT", 55442),
    database: Rails.env.test? ? "apex_test" : "apex_development", username: "apex_reader", password: "local-reader-only" })
end
