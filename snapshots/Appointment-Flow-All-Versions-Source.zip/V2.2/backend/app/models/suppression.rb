class Suppression < ApplicationRecord
  belongs_to :practice
end
