class StaffAction < ApplicationRecord
  belongs_to :visit
  validates :staff, :note, :event_id, presence: true
  validates :kind, inclusion: { in: %w[attempted confirmed canceled rescheduled assign verified] }
end
