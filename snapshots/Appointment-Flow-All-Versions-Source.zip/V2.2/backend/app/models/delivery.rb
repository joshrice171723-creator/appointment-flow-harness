class Delivery < ApplicationRecord
  belongs_to :visit
end
