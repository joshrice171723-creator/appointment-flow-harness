class Reply < ApplicationRecord
  belongs_to :practice
  belongs_to :delivery
end
