class Visit < ApplicationRecord
  belongs_to :practice
  has_many :deliveries
  has_many :staff_actions

  def confirmed?
    confirmed_revision == revision
  end

  def active?
    outcome == "scheduled" && closed_revision != revision
  end

  def details
    source.merge(contact)
  end

  def recipient(channel)
    value = details[channel == "sms" ? "wireless_phone" : "email"].to_s.strip
    return value.downcase if channel == "email" && value.match?(/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/)
    digits = value.gsub(/\D/, "") if channel == "sms"
    digits = digits.delete_prefix("1") if digits&.length == 11
    "+1#{digits}" if digits&.match?(/\A\d{10}\z/)
  end

  def contact_hold(now: Time.current)
    facts = details
    birthdate = Date.iso8601(facts["birthdate"].to_s) rescue nil
    local_date = now.in_time_zone(practice.timezone).to_date
    return "Verify birthdate and authorized adult contact" unless birthdate && birthdate <= local_date.years_ago(18)
    return "Arrange contact in the preferred language" unless %w[en es].include?(facts["preferred_language"])
    return "Review changed source contact details" if contact["source_fingerprint"] && contact["source_fingerprint"] != source_fingerprint
    return "Verify contact permissions" unless facts["consent"] == true
    "No usable contact channel" unless recipient("sms") || recipient("email")
  end

  def source_fingerprint
    Digest::SHA256.hexdigest(source.slice("birthdate", "wireless_phone", "email", "preferred_language").to_json)
  end

  def channel_allowed?(channel)
    details.fetch("#{channel}_consent", details["consent"]) == true
  end
end
