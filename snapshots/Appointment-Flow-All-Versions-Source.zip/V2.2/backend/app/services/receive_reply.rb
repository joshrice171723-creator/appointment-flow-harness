class ReceiveReply
  def self.run(practice:, delivery_id:, body:, event_id:, now: Time.current)
    raise ArgumentError, "Reply and event ID are required" if body.blank? || body.length > 1000 || event_id.blank? || event_id.length > 100
    WorkflowLock.run do
      practice.reload
      previous = Reply.find_by(practice: practice, event_id: event_id)
      next previous if previous
      delivery = Delivery.joins(:visit).where(practice_id: practice.id, visits: { practice_id: practice.id }).find(delivery_id)
      visit = delivery.visit
      raise ActiveRecord::RecordNotFound unless delivery.patient_id == visit.patient_id
      command = body.strip.upcase
      result = "review"
      if command == "STOP" && delivery.channel == "sms"
        Suppression.find_or_create_by!(practice: practice, recipient: delivery.recipient, channel: "sms")
        result = "stopped"
      elsif command == "YES" && practice.trusted && practice.synced_at && practice.synced_at > now - 10.minutes &&
          delivery.status == "sent" && visit.active? && visit.starts_at > now &&
          delivery.revision == visit.revision && !visit.contact_hold(now: now) &&
          visit.channel_allowed?(delivery.channel) && !Suppression.exists?(practice: practice, channel: delivery.channel, recipient: delivery.recipient) &&
          visit.recipient(delivery.channel) == delivery.recipient && unambiguous?(practice, delivery, now)
        visit.update!(confirmed_revision: visit.revision, issue: nil)
        result = "confirmed"
      else
        visit.update!(issue: "Reply needs review")
      end
      Reply.create!(practice: practice, delivery: delivery, body: body, event_id: event_id, result: result)
    end
  end

  def self.unambiguous?(practice, delivery, now)
    candidates = practice.visits.where(outcome: "scheduled").where("starts_at > ?", now)
      .select { |v| v.active? && v.recipient(delivery.channel) == delivery.recipient }
    candidates.one? && candidates.first.id == delivery.visit_id
  end
end
