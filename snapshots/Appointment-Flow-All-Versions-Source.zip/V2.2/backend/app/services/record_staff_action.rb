class RecordStaffAction
  def self.run(practice:, visit_id:, staff:, kind:, note:, event_id:, revision:, contact: {})
    raise ArgumentError, "Choose a demo staff identity" unless [ "Taylor Morgan", "Jordan Lee" ].include?(staff)
    raise ArgumentError, "Note must be 1–1000 characters" if note.blank? || note.length > 1000
    raise ArgumentError, "Event ID is required" if event_id.blank? || event_id.length > 100
    WorkflowLock.run do
      visit = practice.visits.find(visit_id)
      previous = visit.staff_actions.find_by(event_id: event_id)
      next previous if previous
      raise ArgumentError, "Appointment changed. Reload and review before saving." unless visit.revision == revision
      action = visit.staff_actions.create!(practice_id: practice.id, patient_id: visit.patient_id, staff: staff, kind: kind, note: note, event_id: event_id)
      case kind
      when "assign"
        visit.owner = staff
      when "confirmed"
        raise ArgumentError, "Only a future scheduled visit can be confirmed" unless visit.active? && visit.starts_at > Time.current
        visit.confirmed_revision = visit.revision
        visit.issue = nil
      when "canceled", "rescheduled"
        visit.closed_revision = visit.revision
        visit.issue = nil
      when "verified"
        facts = contact.slice("birthdate", "wireless_phone", "email", "preferred_language", "consent", "sms_consent", "email_consent")
        raise ArgumentError, "Consent must be explicitly verified" unless [ true, false ].include?(facts["consent"])
        visit.contact = facts.merge("source_fingerprint" => visit.source_fingerprint)
        visit.issue = visit.contact_hold
      end
      visit.save!
      action
    end
  end
end
