class WorkflowLock
  # Serialize refresh, send, reply and staff writes to keep versions stable during decisions.
  def self.run
    ApplicationRecord.transaction do
      ApplicationRecord.connection.execute("SELECT pg_advisory_xact_lock(22022)")
      yield
    end
  end
end
