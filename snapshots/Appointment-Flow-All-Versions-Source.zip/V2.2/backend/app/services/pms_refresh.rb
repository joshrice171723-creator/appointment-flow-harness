class PmsRefresh
  TIMEZONES = { "Austin" => "America/Chicago", "Phoenix" => "America/Phoenix" }.freeze

  def self.run
    failure = nil
    WorkflowLock.run do
      begin
        ApplicationRecord.transaction(requires_new: true) { apply_snapshot }
      rescue StandardError => error
        Practice.update_all(trusted: false)
        failure = error
      end
    end
    raise failure if failure
  end

  def self.apply_snapshot
    rows = PmsRecord.connection.select_all(<<~SQL).to_a
      SELECT a.*, row_to_json(p.*) AS patient, c.name AS clinic_name
      FROM pms.appointments a JOIN pms.patients p ON p.id = a.patient_id
      JOIN pms.clinics c ON c.id = a.clinic_id
    SQL
    raise "PMS returned no appointments; reminders paused" if rows.empty?
    raise "A previously tracked clinic is empty; reminders paused" if (Practice.pluck(:id) - rows.map { |row| row["clinic_id"] }.uniq).any?
    rows.each do |row|
      zone = TIMEZONES.fetch(row["clinic_name"])
      practice = Practice.find_or_initialize_by(id: row["clinic_id"])
      practice.update!(name: row["clinic_name"], timezone: zone, synced_at: Time.current, trusted: true)
      wall_time = row["start_at"].strftime("%Y-%m-%d %H:%M:%S")
      periods = TZInfo::Timezone.get(zone).periods_for_local(DateTime.parse(wall_time))
      raise "Ambiguous or invalid PMS wall time" unless periods.one?
      instant = Time.find_zone!(zone).parse(wall_time)
      version_key = Digest::SHA256.hexdigest([ row["id"], row["patient_id"], row["clinic_id"], wall_time, row["status"] ].join("|"))
      patient = row["patient"].is_a?(String) ? JSON.parse(row["patient"]) : row["patient"]
      source = patient.merge("provider_name" => row["provider_name"], "wall_time" => wall_time, "appointment_version" => version_key)
      visit = Visit.find_or_initialize_by(id: row["id"])
      changed = visit.new_record? || visit.source["appointment_version"] != version_key || visit.outcome != row["status"]
      revision = changed ? SecureRandom.uuid : visit.revision
      if visit.persisted? && (visit.patient_id != row["patient_id"] || visit.practice_id != row["clinic_id"])
        visit.assign_attributes(contact: {}, owner: nil, confirmed_revision: nil, closed_revision: nil)
      end
      visit.assign_attributes(practice: practice, patient_id: row["patient_id"], source: source,
        starts_at: instant, revision: revision, outcome: row["status"])
      visit.issue = "Appointment changed; obtain a fresh confirmation" if visit.persisted? && visit.revision_changed?
      visit.save!
    end
    Visit.where.not(id: rows.map { |r| r["id"] }).update_all(outcome: "missing", issue: "Missing from PMS refresh")
  end
  private_class_method :apply_snapshot
end
