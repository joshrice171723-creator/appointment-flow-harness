class FakeTransport
  def self.deliver(recipient:, channel:)
    recipient.include?("fail@") || recipient.end_with?("0199") ? "failed" : "sent"
  end
end
