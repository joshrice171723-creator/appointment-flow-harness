class ReminderBatch
  def self.run(practice:, now: Time.current)
    WorkflowLock.run do
      practice.reload
      raise "Refresh PMS before sending reminders" unless practice.trusted && practice.synced_at && practice.synced_at > now - 10.minutes
      local_now = now.in_time_zone(practice.timezone)
      return 0 unless (10...18).cover?(local_now.hour)
      sent = 0
      practice.visits.where(outcome: "scheduled").where(starts_at: now...now + 8.days).find_each do |visit|
        next unless visit.active? && visit.starts_at > now
        hold = visit.contact_hold(now: now)
        if hold
          visit.update!(issue: hold)
          next
        end
        days = (visit.starts_at.in_time_zone(practice.timezone).to_date - local_now.to_date).to_i
        next if days > 7
        step = days <= 1 ? "final" : days <= 3 ? "follow_up" : "initial"
        visit.update!(issue: "No reply before appointment") if days <= 2 && !visit.confirmed? && visit.issue.blank?
        next if visit.confirmed? && step != "final"
        channel = "sms"
        sms = visit.recipient("sms")
        suppressed = Suppression.exists?(practice: practice, channel: "sms", recipient: sms)
        prior = visit.deliveries.where(revision: visit.revision, channel: "sms")
        backup = days <= 6 && step == "initial" && prior.where("created_at <= ?", now - 1.day).exists? && !visit.confirmed?
        channel = "email" if !sms || !visit.channel_allowed?("sms") || suppressed || backup || prior.where(status: "failed").exists?
        recipient = visit.recipient(channel)
        unless recipient && visit.channel_allowed?(channel)
          visit.update!(issue: "No permitted reminder channel")
          next
        end
        next if visit.deliveries.exists?(revision: visit.revision, step: step, channel: channel)
        text = visit.details["preferred_language"] == "es" ? "Responda YES para confirmar o NO para ayuda." : "Reply YES to confirm or NO for help."
        text = "Confirmed appointment reminder." if visit.confirmed?
        body = "#{practice.name}: #{visit.starts_at.in_time_zone(practice.timezone).strftime('%b %d, %Y %I:%M %p')} (#{practice.timezone}). #{text}"
        body += " Reply STOP to stop texts." if channel == "sms"
        status = FakeTransport.deliver(recipient: recipient, channel: channel)
        visit.deliveries.create!(practice_id: practice.id, patient_id: visit.patient_id, revision: visit.revision, step: step, channel: channel, recipient: recipient, body: body, status: status, created_at: now)
        visit.update!(issue: "Delivery failed; review contact") if status == "failed"
        sent += 1
      end
      sent
    end
  end
end
