class StaffActionsController < ApplicationController
  def create
    contact = params.fetch(:contact, ActionController::Parameters.new)
    raise ArgumentError, "Contact must be an object" unless contact.is_a?(ActionController::Parameters)
    action = RecordStaffAction.run(practice: practice, visit_id: params[:visit_id], staff: params.require(:staff),
      kind: params.require(:kind), note: params.require(:note), event_id: params.require(:event_id),
      revision: params.require(:revision), contact: contact.permit(:birthdate, :wireless_phone, :email, :preferred_language, :consent, :sms_consent, :email_consent).to_h)
    render json: { id: action.id }
  end
end
