class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "Record not found in this clinic" }, status: :not_found
  end
  rescue_from ArgumentError, ActiveRecord::RecordInvalid, ActionController::ParameterMissing do |error|
    render json: { error: error.message }, status: :unprocessable_entity
  end

  private

  def practice
    @practice ||= Practice.find(params[:practice_id])
  end
end
