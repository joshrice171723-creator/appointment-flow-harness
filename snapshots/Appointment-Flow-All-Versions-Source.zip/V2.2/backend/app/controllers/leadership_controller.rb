class LeadershipController < ApplicationController
  def index
    month = Date.iso8601("#{params.fetch(:month, Date.current.strftime('%Y-%m'))}-01")
    render json: Practice.order(:id).map { |clinic|
      from = Time.find_zone!(clinic.timezone).local(month.year, month.month, 1)
      visits = clinic.visits.where(starts_at: from...from.next_month)
      counts = visits.group(:outcome).count
      ids = visits.select(:id)
      {
        clinic: clinic.name, recorded: counts.values.sum, completed: counts.fetch("complete", 0),
        rescheduled: counts.fetch("unscheduled", 0), canceled: counts.fetch("broken", 0),
        unknown: counts.except("complete", "unscheduled", "broken").values.sum,
        messages: Delivery.where(practice_id: clinic.id, visit_id: ids, status: "sent").count,
        holds: visits.where.not(issue: nil).count,
        follow_ups: StaffAction.where(practice_id: clinic.id, visit_id: ids).count,
        confirmed: visits.where("confirmed_revision = revision").count
      }
    }
  end
end
