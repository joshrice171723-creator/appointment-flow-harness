class PracticesController < ApplicationController
  def index
    render json: Practice.order(:id).as_json(only: [ :id, :name, :timezone, :synced_at, :trusted ])
  end
end
