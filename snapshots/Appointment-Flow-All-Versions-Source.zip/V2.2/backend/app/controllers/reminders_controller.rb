class RemindersController < ApplicationController
  def create
    count = ReminderBatch.run(practice: practice)
    render json: { message: "#{count} fake delivery attempts recorded. Sending window: 10:00–18:00 clinic time." }
  rescue RuntimeError => error
    render json: { error: error.message }, status: :conflict
  end
end
