class RepliesController < ApplicationController
  def create
    reply = ReceiveReply.run(practice: practice, delivery_id: params.require(:delivery_id),
      body: params.require(:body).to_s, event_id: params.require(:event_id).to_s)
    render json: { id: reply.id, result: reply.result }
  end
end
