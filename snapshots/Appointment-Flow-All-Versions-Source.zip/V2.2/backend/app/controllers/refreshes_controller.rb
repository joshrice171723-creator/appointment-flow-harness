class RefreshesController < ApplicationController
  def create
    practice
    PmsRefresh.run
    render json: { message: "PMS refresh succeeded at #{Time.current.iso8601}. Source records remain read-only." }
  rescue StandardError => error
    Rails.logger.error("PMS refresh failed: #{error.class}")
    render json: { error: "PMS refresh failed. Reminders are paused; tracked appointments are preserved." }, status: :service_unavailable
  end
end
