class VisitsController < ApplicationController
  def index
    visits = practice.visits.includes(:deliveries, :staff_actions).order(:starts_at)
    replies = Reply.where(practice: practice).group_by(&:delivery_id)
    render json: visits.map { |visit|
      {
        id: visit.id, patient_id: visit.patient_id, name: [ visit.source["first_name"], visit.source["last_name"] ].join(" "),
        starts_at: visit.starts_at, revision: visit.revision, outcome: visit.outcome,
        confirmed: visit.confirmed?, active: visit.active?, owner: visit.owner, issue: visit.issue,
        source: visit.source.except("procedure_note"), contact: visit.contact,
        deliveries: visit.deliveries.select { |d| d.practice_id == practice.id && d.patient_id == visit.patient_id }.as_json(only: [ :id, :channel, :body, :status, :created_at ]),
        replies: visit.deliveries.select { |d| d.practice_id == practice.id && d.patient_id == visit.patient_id }.flat_map { |d| replies.fetch(d.id, []) }.as_json(only: [ :id, :delivery_id, :body, :result, :created_at ]),
        actions: visit.staff_actions.select { |a| a.practice_id == practice.id && a.patient_id == visit.patient_id }.as_json(only: [ :id, :staff, :kind, :note, :created_at ])
      }
    }
  end
end
