require "test_helper"

class ClinicTest < ActionDispatch::IntegrationTest
  setup do
    @clinic = Practice.create!(id: 101, name: "Austin", timezone: "America/Chicago")
    other = Practice.create!(id: 102, name: "Phoenix", timezone: "America/Phoenix")
    @visit = Visit.create!(id: 101, practice: @clinic, patient_id: 1, starts_at: 2.days.from_now,
      revision: "r1", outcome: "scheduled", source: { "first_name" => "Fictional", "last_name" => "Austin" })
    Visit.create!(id: 102, practice: other, patient_id: 2, starts_at: 2.days.from_now,
      revision: "r2", outcome: "scheduled", source: { "first_name" => "Secret", "last_name" => "Phoenix" })
  end

  test "S10 clinic-scoped listing and mutation reject another clinic visit" do
    get "/api/practices/101/visits"
    assert_response :success
    assert_equal [ 101 ], response.parsed_body.map { |row| row["id"] }
    post "/api/practices/101/visits/102/actions", params: { staff: "Taylor Morgan", kind: "assign", note: "test", revision: "r2", event_id: "scope" }, as: :json
    assert_response :not_found
    assert_equal 0, StaffAction.count
  end

  test "S16 S17 leadership response contains aggregate allowlist only" do
    get "/api/leadership", params: { month: Date.current.strftime("%Y-%m") }
    assert_response :success
    response.parsed_body.each do |row|
      assert_equal %w[canceled clinic completed confirmed follow_ups holds messages recorded rescheduled unknown], row.keys.sort
    end
    assert_not_includes response.body, "Fictional"
    assert_not_includes response.body, "Secret"
  end

  test "S19 invalid follow-up rolls back and successful event replay is idempotent" do
    args = { staff: "Taylor Morgan", kind: "attempted", note: "", revision: "r1", event_id: "save" }
    post "/api/practices/101/visits/101/actions", params: args, as: :json
    assert_response :unprocessable_entity
    assert_equal 0, StaffAction.count
    args[:note] = "Left a callback request"
    2.times { post "/api/practices/101/visits/101/actions", params: args, as: :json; assert_response :success }
    assert_equal 1, StaffAction.count
  end
end
