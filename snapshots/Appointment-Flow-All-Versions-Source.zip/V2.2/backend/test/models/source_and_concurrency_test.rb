require "test_helper"

class SourceAndConcurrencyTest < ActiveSupport::TestCase
  self.use_transactional_tests = false

  setup do
    @connection = ApplicationRecord.connection
    @connection.execute(Rails.root.join("db/pms.sql").read)
    clear_records
    @connection.execute("INSERT INTO pms.clinics(id,name) VALUES (1,'Austin')")
    @connection.execute("INSERT INTO pms.patients(id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (1,'Fake','Person','1990-01-01','5125550101','demo@example.test','en')")
    @connection.execute("INSERT INTO pms.appointments(id,clinic_id,patient_id,start_at,status) VALUES (1,1,1,'2026-11-23 12:00:00','scheduled')")
    PmsRefresh.run
    Visit.sole.update!(contact: { "consent" => true })
  end

  teardown { clear_records }

  test "PMS reader cannot write and source wall time converts using clinic zone" do
    assert_equal Time.utc(2026, 11, 23, 18), Visit.sole.starts_at
    assert_raises(ActiveRecord::StatementInvalid) { PmsRecord.connection.execute("UPDATE pms.patients SET first_name='forbidden'") }
  end

  test "S03 S09 refresh invalidates old confirmation and preserves STOP" do
    visit = Visit.sole
    visit.update!(confirmed_revision: visit.revision)
    Suppression.create!(practice_id: 1, recipient: "+15125550101", channel: "sms")
    @connection.execute("UPDATE pms.appointments SET start_at='2026-11-24 12:00:00'")
    PmsRefresh.run
    assert_not visit.reload.confirmed?
    assert_equal 1, Suppression.count
  end

  test "S14 empty source preserves tracked appointments and pauses sends" do
    @connection.execute("DELETE FROM pms.appointments")
    assert_raises(RuntimeError) { PmsRefresh.run }
    assert_equal 1, Visit.count
    assert_not Practice.sole.trusted
  end

  test "DST ambiguous and nonexistent wall times fail closed" do
    [ "2026-11-01 01:30:00", "2026-03-08 02:30:00" ].each do |wall|
      @connection.execute("UPDATE pms.appointments SET start_at=#{@connection.quote(wall)}")
      assert_raises(RuntimeError) { PmsRefresh.run }
      assert_not Practice.sole.trusted
    end
  end

  test "S15 concurrent batches and replies record one logical effect" do
    now = Time.utc(2026, 11, 16, 18)
    Practice.sole.update!(synced_at: now)
    threads = 2.times.map do
      Thread.new do
        ApplicationRecord.connection_pool.with_connection { ReminderBatch.run(practice: Practice.sole, now: now) }
      end
    end
    threads.each(&:value)
    assert_equal 1, Delivery.count
    delivery = Delivery.sole
    threads = 2.times.map do
      Thread.new do
        ApplicationRecord.connection_pool.with_connection do
          ReceiveReply.run(practice: Practice.sole, delivery_id: delivery.id, body: "YES", event_id: "parallel", now: now)
        end
      end
    end
    threads.each(&:value)
    assert_equal 1, Reply.count
    assert Visit.sole.confirmed?
  end

  test "moving away and back never resurrects confirmation or delivery keys" do
    original = Visit.sole.revision
    Visit.sole.update!(confirmed_revision: original)
    @connection.execute("UPDATE pms.appointments SET start_at='2026-11-24 12:00:00'")
    PmsRefresh.run
    @connection.execute("UPDATE pms.appointments SET start_at='2026-11-23 12:00:00'")
    PmsRefresh.run
    assert_not_equal original, Visit.sole.revision
    assert_not Visit.sole.confirmed?
  end

  test "patient replacement clears verification confirmation and ownership" do
    Visit.sole.update!(confirmed_revision: Visit.sole.revision, owner: "Taylor Morgan")
    @connection.execute("INSERT INTO pms.patients(id,first_name,last_name) VALUES (2,'Different','Person')")
    @connection.execute("UPDATE pms.appointments SET patient_id=2")
    PmsRefresh.run
    assert_empty Visit.sole.contact
    assert_nil Visit.sole.owner
    assert_not Visit.sole.confirmed?
  end
  test "untrusted source reply is retained for staff review" do
    now = Time.utc(2026, 11, 16, 18)
    Practice.sole.update!(synced_at: now)
    ReminderBatch.run(practice: Practice.sole, now: now)
    Practice.sole.update!(trusted: false)
    result = ReceiveReply.run(practice: Practice.sole, delivery_id: Delivery.sole.id, body: "YES", event_id: "untrusted", now: now)
    assert_equal "review", result.result
    assert_not Visit.sole.confirmed?
  end
  private


  def clear_records
    @connection.execute("TRUNCATE replies, deliveries, staff_actions, suppressions, visits, practices RESTART IDENTITY CASCADE")
    @connection.execute("TRUNCATE pms.appointments, pms.patients, pms.clinics CASCADE")
  end
end
