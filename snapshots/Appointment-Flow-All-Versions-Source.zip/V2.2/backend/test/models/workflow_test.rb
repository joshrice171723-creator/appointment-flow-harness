require "test_helper"

class WorkflowTest < ActiveSupport::TestCase
  setup do
    @now = Time.utc(2026, 11, 16, 18)
    @practice = Practice.create!(id: 1, name: "Austin", timezone: "America/Chicago", trusted: true, synced_at: @now)
    @visit = Visit.create!(id: 1, practice: @practice, patient_id: 1, revision: "r1", outcome: "scheduled", starts_at: @now + 7.days,
      source: { "first_name" => "Fictional", "last_name" => "Patient", "birthdate" => "1990-01-01", "wireless_phone" => "5125550101", "email" => "demo@example.test", "preferred_language" => "en" }, contact: { "consent" => true })
  end

  test "S01 and S06 YES confirms current version and duplicate reply has one effect" do
    ReminderBatch.run(practice: @practice, now: @now)
    delivery = @visit.deliveries.sole
    2.times { ReceiveReply.run(practice: @practice, delivery_id: delivery.id, body: "YES", event_id: "event-1", now: @now) }
    assert @visit.reload.confirmed?
    assert_equal 1, Reply.count
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal 1, Delivery.count
  end

  test "S03 stale reply never confirms a moved visit" do
    ReminderBatch.run(practice: @practice, now: @now)
    @visit.update!(revision: "r2", starts_at: @now + 8.days)
    reply = ReceiveReply.run(practice: @practice, delivery_id: Delivery.sole.id, body: "YES", event_id: "old", now: @now)
    assert_equal "review", reply.result
    assert_not @visit.reload.confirmed?
  end

  test "S09 STOP survives subsequent batches" do
    ReminderBatch.run(practice: @practice, now: @now)
    ReceiveReply.run(practice: @practice, delivery_id: Delivery.sole.id, body: "STOP", event_id: "stop", now: @now)
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal 1, Delivery.where(channel: "sms").count
    assert_equal 1, Suppression.count
    result = ReceiveReply.run(practice: @practice, delivery_id: Delivery.find_by!(channel: "sms").id, body: "YES", event_id: "after-stop", now: @now)
    assert_equal "review", result.result
    assert_not @visit.reload.confirmed?
  end

  test "S02 email fallback confirms and S05 failed SMS is retained" do
    @visit.update!(source: @visit.source.merge("wireless_phone" => "5125550199"))
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal "failed", Delivery.sole.status
    ReminderBatch.run(practice: @practice, now: @now)
    email = Delivery.find_by!(channel: "email")
    assert_equal "sent", email.status
    ReceiveReply.run(practice: @practice, delivery_id: email.id, body: "yes", event_id: "email", now: @now)
    assert @visit.reload.confirmed?
  end

  test "S07 NO after YES keeps confirmation and requires review" do
    ReminderBatch.run(practice: @practice, now: @now)
    %w[YES NO].each { |body| ReceiveReply.run(practice: @practice, delivery_id: Delivery.sole.id, body: body, event_id: body, now: @now) }
    assert @visit.reload.confirmed?
    assert_equal "Reply needs review", @visit.issue
  end

  test "S08 late reply and S12 shared number never auto-confirm" do
    ReminderBatch.run(practice: @practice, now: @now)
    duplicate = @visit.dup
    duplicate.id = 2
    duplicate.patient_id = 2
    duplicate.save!
    ReceiveReply.run(practice: @practice, delivery_id: Delivery.sole.id, body: "YES", event_id: "family", now: @now)
    assert_not @visit.reload.confirmed?
    duplicate.destroy!
    ReceiveReply.run(practice: @practice, delivery_id: Delivery.sole.id, body: "YES", event_id: "late", now: @visit.starts_at)
    assert_not @visit.reload.confirmed?
  end

  test "S13 unsafe contacts block until local verification and source stays raw" do
    original = @visit.source
    @visit.update!(source: original.merge("birthdate" => "2015-01-01"))
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal 0, Delivery.count
    assert_match(/adult/, @visit.reload.issue)
    @visit.update!(contact: { "consent" => true, "birthdate" => "1990-01-01" })
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal 1, Delivery.count
    assert_equal "2015-01-01", @visit.reload.source["birthdate"]
  end

  test "S04 source outcomes and closed visits never send; no post-start sends" do
    %w[complete broken unscheduled].each do |outcome|
      @visit.update!(outcome: outcome)
      ReminderBatch.run(practice: @practice, now: @now)
    end
    @visit.update!(outcome: "scheduled", starts_at: @now)
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal 0, Delivery.count
  end

  test "S15 clinic-local window and repeated batches coalesce missed steps" do
    ReminderBatch.run(practice: @practice, now: @now.change(hour: 15))
    assert_equal 0, Delivery.count
    @visit.update!(starts_at: @now + 1.day)
    3.times { ReminderBatch.run(practice: @practice, now: @now) }
    assert_equal [ "final" ], Delivery.pluck(:step)
  end

  test "S14 stale source blocks sends" do
    @practice.update!(trusted: false)
    assert_raises(RuntimeError) { ReminderBatch.run(practice: @practice, now: @now) }
    assert_equal 0, Delivery.count
  end

  test "channel-specific permission chooses permitted email and never sends denied channels" do
    @visit.update!(contact: { "consent" => true, "sms_consent" => false, "email_consent" => true })
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal [ "email" ], Delivery.pluck(:channel)
    @visit.update!(contact: { "consent" => true, "sms_consent" => false, "email_consent" => false }, revision: "r2")
    ReminderBatch.run(practice: @practice, now: @now)
    assert_equal 1, Delivery.count
    assert_equal "No permitted reminder channel", @visit.reload.issue
  end

  test "adult eligibility uses clinic birthday rather than UTC date" do
    @visit.update!(source: @visit.source.merge("birthdate" => "2008-11-16"))
    assert_match(/adult/, @visit.contact_hold(now: Time.utc(2026, 11, 16, 1)))
    assert_nil @visit.contact_hold(now: Time.utc(2026, 11, 16, 18))
  end

  test "S11 two-day follow-up appears even when the three-day message already exists" do
    @visit.update!(starts_at: @now + 3.days)
    ReminderBatch.run(practice: @practice, now: @now)
    @practice.update!(synced_at: @now + 1.day)
    ReminderBatch.run(practice: @practice, now: @now + 1.day)
    assert_equal 1, Delivery.count
    assert_equal "No reply before appointment", @visit.reload.issue
  end

  test "six-day email backup waits a day after successful initial SMS" do
    @visit.update!(starts_at: @now + 6.days)
    2.times { ReminderBatch.run(practice: @practice, now: @now) }
    assert_equal 1, Delivery.count
    @practice.update!(synced_at: @now + 1.day)
    ReminderBatch.run(practice: @practice, now: @now + 1.day)
    assert_equal [ "sms", "email" ], Delivery.order(:id).pluck(:channel)
  end
end
