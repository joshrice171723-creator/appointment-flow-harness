require "test_helper"

class LoggingTest < ActiveSupport::TestCase
  test "runtime logger suppresses SQL values and sensitive parameters are filtered" do
    assert_operator Rails.logger.level, :>=, Logger::INFO
    filter = ActiveSupport::ParameterFilter.new(Rails.application.config.filter_parameters)
    values = { "body" => "YES", "note" => "callback", "wireless_phone" => "5125550101", "birthdate" => "1990-01-01" }
    assert_equal [ "[FILTERED]" ], filter.filter(values).values.uniq
  end
end
