# Explicit demo setup is the only writer of the fictional source replica.
connection = ApplicationRecord.connection
connection.execute(Rails.root.join("db/pms.sql").read)
connection.execute("INSERT INTO pms.clinics(id,name,city,state) VALUES (1,'Austin','Austin','TX'),(2,'Phoenix','Phoenix','AZ') ON CONFLICT DO NOTHING")
24.times do |index|
  id = index + 1
  clinic = index < 12 ? 1 : 2
  zone = clinic == 1 ? "America/Chicago" : "America/Phoenix"
  local = Time.current.in_time_zone(zone)
  offset = [ -20, -10, -3, 0, 1, 2, 3, 5, 6, 7, 7, 8 ][index % 12]
  start = (local.to_date + offset).strftime("%Y-%m-%d") + " 15:00:00"
  phone = index % 12 == 8 ? nil : "512555#{format('%04d', 100 + id)}"
  phone = "5125550199" if index % 12 == 6
  phone = "5125550188" if [ 9, 10 ].include?(index % 12)
  birthday = index % 12 == 7 ? "2015-02-03" : "1990-02-03"
  language = index % 12 == 5 ? "es" : "en"
  outcome = offset < 0 ? %w[complete broken unscheduled][index % 3] : "scheduled"
  values = [ id, "Demo", "Patient #{id}", birthday, phone, "patient#{id}@example.test", language ].map { |v| connection.quote(v) }
  connection.execute("INSERT INTO pms.patients(id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (#{values.join(',')}) ON CONFLICT DO NOTHING")
  connection.execute("INSERT INTO pms.appointments(id,patient_id,clinic_id,provider_name,start_at,length_minutes,status,updated_at) VALUES (#{id},#{id},#{clinic},'Dr. Rowan',#{connection.quote(start)},30,#{connection.quote(outcome)},CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING")
end
PmsRefresh.run
Visit.find_each do |visit|
  next if visit.contact.present?
  visit.update!(contact: { "consent" => true, "source_fingerprint" => visit.source_fingerprint })
  visit.update!(issue: visit.contact_hold || (visit.starts_at < Time.current + 2.days && visit.active? ? "No reply before appointment" : nil))
end
puts "Seeded fictional Austin and Phoenix records. No live messages sent."
