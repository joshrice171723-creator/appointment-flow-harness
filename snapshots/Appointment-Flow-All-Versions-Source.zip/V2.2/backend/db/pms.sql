CREATE SCHEMA IF NOT EXISTS pms;
CREATE TABLE IF NOT EXISTS pms.clinics (id bigint PRIMARY KEY, name text NOT NULL, address_line text, city text, state char(2), phone text);
CREATE TABLE IF NOT EXISTS pms.patients (id bigint PRIMARY KEY, first_name text NOT NULL, last_name text NOT NULL, birthdate date, wireless_phone text, email text, preferred_language text, guarantor_id bigint REFERENCES pms.patients(id));
CREATE TABLE IF NOT EXISTS pms.appointments (id bigint PRIMARY KEY, patient_id bigint NOT NULL REFERENCES pms.patients(id), clinic_id bigint NOT NULL REFERENCES pms.clinics(id), provider_name text, start_at timestamp NOT NULL, length_minutes int, procedure_note text, status text NOT NULL, updated_at timestamp);
DO $$ BEGIN
 IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'apex_reader') THEN
   CREATE ROLE apex_reader LOGIN PASSWORD 'local-reader-only';
 END IF;
END $$;
GRANT USAGE ON SCHEMA pms TO apex_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA pms TO apex_reader;
