class ScopeDeliveryIdentity < ActiveRecord::Migration[8.1]
  def change
    add_column :deliveries, :practice_id, :bigint
    add_column :deliveries, :patient_id, :bigint
    reversible do |direction|
      direction.up do
        execute "UPDATE deliveries SET practice_id=visits.practice_id, patient_id=visits.patient_id FROM visits WHERE visits.id=deliveries.visit_id"
      end
    end
    change_column_null :deliveries, :practice_id, false
    change_column_null :deliveries, :patient_id, false
  end
end
