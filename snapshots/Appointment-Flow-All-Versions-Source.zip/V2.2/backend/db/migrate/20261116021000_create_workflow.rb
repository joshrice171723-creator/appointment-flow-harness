class CreateWorkflow < ActiveRecord::Migration[8.1]
  def change
    create_table :practices, id: false do |t|
      t.bigint :id, primary_key: true
      t.string :name, :timezone, null: false
      t.datetime :synced_at
      t.boolean :trusted, default: false, null: false
    end
    create_table :visits, id: false do |t|
      t.bigint :id, primary_key: true
      t.references :practice, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.jsonb :source, default: {}, null: false
      t.datetime :starts_at, null: false
      t.string :revision, :outcome, null: false
      t.string :confirmed_revision, :closed_revision, :owner, :issue
      t.jsonb :contact, default: {}, null: false
    end
    add_index :visits, [ :practice_id, :starts_at ]
    create_table :deliveries do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :revision, :step, :channel, :recipient, :body, :status, null: false
      t.datetime :created_at, null: false
    end
    add_index :deliveries, [ :visit_id, :revision, :step, :channel ], unique: true
    create_table :replies do |t|
      t.references :practice, null: false, foreign_key: true
      t.references :delivery, null: false, foreign_key: true
      t.string :event_id, :body, :result, null: false
      t.datetime :created_at, null: false
    end
    add_index :replies, [ :practice_id, :event_id ], unique: true
    create_table :suppressions do |t|
      t.references :practice, null: false, foreign_key: true
      t.string :recipient, :channel, null: false
    end
    add_index :suppressions, [ :practice_id, :recipient, :channel ], unique: true
    create_table :staff_actions do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :staff, :kind, :note, :event_id, null: false
      t.datetime :created_at, null: false
    end
    add_index :staff_actions, [ :visit_id, :event_id ], unique: true
  end
end
