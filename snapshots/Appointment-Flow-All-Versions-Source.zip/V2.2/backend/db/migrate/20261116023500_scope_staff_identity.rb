class ScopeStaffIdentity < ActiveRecord::Migration[8.1]
  def change
    add_column :staff_actions, :practice_id, :bigint
    add_column :staff_actions, :patient_id, :bigint
    reversible do |direction|
      direction.up do
        execute "UPDATE staff_actions SET practice_id=visits.practice_id, patient_id=visits.patient_id FROM visits WHERE visits.id=staff_actions.visit_id"
      end
    end
    change_column_null :staff_actions, :practice_id, false
    change_column_null :staff_actions, :patient_id, false
  end
end
