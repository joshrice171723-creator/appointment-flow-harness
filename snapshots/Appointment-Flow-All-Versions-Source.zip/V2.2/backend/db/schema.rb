# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_11_16_023500) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "deliveries", force: :cascade do |t|
    t.bigint "visit_id", null: false
    t.string "revision", null: false
    t.string "step", null: false
    t.string "channel", null: false
    t.string "recipient", null: false
    t.string "body", null: false
    t.string "status", null: false
    t.datetime "created_at", null: false
    t.bigint "practice_id", null: false
    t.bigint "patient_id", null: false
    t.index ["visit_id", "revision", "step", "channel"], name: "index_deliveries_on_visit_id_and_revision_and_step_and_channel", unique: true
    t.index ["visit_id"], name: "index_deliveries_on_visit_id"
  end

  create_table "practices", force: :cascade do |t|
    t.string "name", null: false
    t.string "timezone", null: false
    t.datetime "synced_at"
    t.boolean "trusted", default: false, null: false
  end

  create_table "replies", force: :cascade do |t|
    t.bigint "practice_id", null: false
    t.bigint "delivery_id", null: false
    t.string "event_id", null: false
    t.string "body", null: false
    t.string "result", null: false
    t.datetime "created_at", null: false
    t.index ["delivery_id"], name: "index_replies_on_delivery_id"
    t.index ["practice_id", "event_id"], name: "index_replies_on_practice_id_and_event_id", unique: true
    t.index ["practice_id"], name: "index_replies_on_practice_id"
  end

  create_table "staff_actions", force: :cascade do |t|
    t.bigint "visit_id", null: false
    t.string "staff", null: false
    t.string "kind", null: false
    t.string "note", null: false
    t.string "event_id", null: false
    t.datetime "created_at", null: false
    t.bigint "practice_id", null: false
    t.bigint "patient_id", null: false
    t.index ["visit_id", "event_id"], name: "index_staff_actions_on_visit_id_and_event_id", unique: true
    t.index ["visit_id"], name: "index_staff_actions_on_visit_id"
  end

  create_table "suppressions", force: :cascade do |t|
    t.bigint "practice_id", null: false
    t.string "recipient", null: false
    t.string "channel", null: false
    t.index ["practice_id", "recipient", "channel"], name: "index_suppressions_on_practice_id_and_recipient_and_channel", unique: true
    t.index ["practice_id"], name: "index_suppressions_on_practice_id"
  end

  create_table "visits", force: :cascade do |t|
    t.bigint "practice_id", null: false
    t.bigint "patient_id", null: false
    t.jsonb "source", default: {}, null: false
    t.datetime "starts_at", null: false
    t.string "revision", null: false
    t.string "outcome", null: false
    t.string "confirmed_revision"
    t.string "closed_revision"
    t.string "owner"
    t.string "issue"
    t.jsonb "contact", default: {}, null: false
    t.index ["practice_id", "starts_at"], name: "index_visits_on_practice_id_and_starts_at"
    t.index ["practice_id"], name: "index_visits_on_practice_id"
  end

  add_foreign_key "deliveries", "visits"
  add_foreign_key "replies", "deliveries"
  add_foreign_key "replies", "practices"
  add_foreign_key "staff_actions", "visits"
  add_foreign_key "suppressions", "practices"
  add_foreign_key "visits", "practices"
end
