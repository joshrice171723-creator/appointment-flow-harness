import { defineConfig } from '@playwright/test'
export default defineConfig({ testDir: '.', testMatch: 'smoke.spec.ts', use: { channel: 'msedge', headless: true }, timeout: 120000, expect: { timeout: 30000 }, workers: 1 })
