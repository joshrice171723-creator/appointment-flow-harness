﻿import { afterEach, expect, test, vi } from 'vitest'
import { cleanup, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { PatientDetail } from './PatientDetail'
import { displayTime, localDate } from './api'
import type { Visit } from './api'
afterEach(() => { cleanup(); vi.unstubAllGlobals() })
const practice = { id: 1, name: 'Austin', timezone: 'America/Chicago', synced_at: null, trusted: true }
const visit: Visit = { id: 1, patient_id: 1, name: 'Fictional Patient', starts_at: '2026-11-23T18:00:00Z', revision: 'r1', outcome: 'scheduled', active: true, confirmed: false, owner: null, issue: 'No reply', source: {}, contact: {}, deliveries: [], replies: [], actions: [] }
test('clinic dates and times use explicit timezones across UTC midnight', () => {
  expect(localDate('2026-11-16T01:00:00Z', 'America/Chicago')).toBe('2026-11-15')
  expect(displayTime('2026-11-23T18:00:00Z', 'America/Chicago')).toContain('12:00')
  expect(displayTime('2026-11-23T18:00:00Z', 'America/Phoenix')).toContain('11:00')
})
test('S19 failed follow-up retains note and event key for deliberate retry', async () => {
  const fetcher = vi.fn().mockResolvedValue({ ok: false, json: async () => ({ error: 'Appointment changed. Reload and review.' }) })
  vi.stubGlobal('fetch', fetcher)
  render(<PatientDetail visit={visit} practice={practice} staff="Taylor Morgan" onBack={() => {}} onSaved={() => {}}/>)
  const user = userEvent.setup()
  const note = screen.getByLabelText('Note') as HTMLTextAreaElement
  await user.type(note, 'Called patient; callback requested')
  await user.click(screen.getByRole('button', { name: 'Record follow-up' }))
  await waitFor(() => expect(screen.getByRole('alert').textContent).toContain('Appointment changed'))
  expect(note.value).toBe('Called patient; callback requested')
  const first = JSON.parse(fetcher.mock.calls[0][1].body)
  await user.click(screen.getByRole('button', { name: 'Record follow-up' }))
  await waitFor(() => expect(fetcher).toHaveBeenCalledTimes(2))
  expect(JSON.parse(fetcher.mock.calls[1][1].body).event_id).toBe(first.event_id)
})
