﻿import { useState } from 'react'
import type { Practice } from './api'
import { displayTime, request } from './api'
import { useVisits } from './useVisits'

export function Inbox({ practices }: { practices: Practice[] }) {
  const [clinic, setClinic] = useState('')
  const practice = practices.find(p => String(p.id) === clinic)
  return <section className="inbox"><h1>Patient inbox</h1><p>Fictional patients · local fake transport</p><label>Clinic<select value={clinic} onChange={e => setClinic(e.target.value)}><option value="">Choose a clinic</option>{practices.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>{practice && <Conversation key={practice.id} practice={practice}/>}</section>
}
function Conversation({ practice }: { practice: Practice }) {
  const [revision, setRevision] = useState(0)
  const { visits, error, loading } = useVisits(practice.id, revision)
  const [patient, setPatient] = useState('')
  const [channel, setChannel] = useState('sms')
  const visit = visits.find(v => String(v.id) === patient)
  return <>{error && <p role="alert">{error}</p>}{loading && <p>Loading patients…</p>}<label>Patient<select value={patient} onChange={e => setPatient(e.target.value)}><option value="">Choose a patient appointment</option>{visits.map(v => <option key={v.id} value={v.id}>{v.name} · {displayTime(v.starts_at, practice.timezone)}</option>)}</select></label><div className="toolbar"><button className={channel === 'sms' ? '' : 'secondary'} onClick={() => setChannel('sms')}>Text messages</button><button className={channel === 'email' ? '' : 'secondary'} onClick={() => setChannel('email')}>Email</button></div>{visit && <ReplyForm key={`${patient}-${channel}`} practice={practice} visit={visit} channel={channel} onSaved={() => setRevision(r => r + 1)}/>}</>
}
function ReplyForm({ practice, visit, channel, onSaved }: { practice: Practice; visit: import('./api').Visit; channel: string; onSaved: () => void }) {
  const [body, setBody] = useState('')
  const [deliveryId, setDeliveryId] = useState('')
  const [event, setEvent] = useState(crypto.randomUUID())
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  const deliveries = visit.deliveries.filter(d => d.channel === channel)
  async function send() {
    setBusy(true)
    try { const result = await request<{ result: string }>(`practices/${practice.id}/replies`, 'POST', { delivery_id: deliveryId, body, event_id: event }); setStatus(`Reply recorded: ${result.result}`); setBody(''); setEvent(crypto.randomUUID()); onSaved() }
    catch (e) { setStatus(e instanceof Error ? e.message : 'Outcome uncertain. Reload before retrying.') }
    finally { setBusy(false) }
  }
  return <><h2>Message history</h2>{deliveries.length === 0 && <p>No simulated {channel === 'email' ? 'emails' : 'text messages'} for this patient yet. Run a reminder batch during clinic sending hours.</p>}{deliveries.map(d => <article className="message" key={d.id}><small>Clinic reminder · {d.status} · {displayTime(d.created_at, practice.timezone)}</small><p>{d.body}</p>{visit.replies.filter(r => r.delivery_id === d.id).map(r => <blockquote key={r.id}>{r.body} · {r.result}</blockquote>)}</article>)}
    {deliveries.length > 0 && <form className="card" onSubmit={e => { e.preventDefault(); void send() }}><label>Reply to reminder<select required value={deliveryId} onChange={e => setDeliveryId(e.target.value)}><option value="">Choose a message</option>{deliveries.map(d => <option key={d.id} value={d.id}>#{d.id} · {d.status} · {displayTime(d.created_at, practice.timezone)}</option>)}</select></label><label>Your reply<textarea required value={body} maxLength={1000} onChange={e => setBody(e.target.value)}/></label><button disabled={busy}>Send simulated reply</button></form>}{status && <p role="status">{status}</p>}</>
}
