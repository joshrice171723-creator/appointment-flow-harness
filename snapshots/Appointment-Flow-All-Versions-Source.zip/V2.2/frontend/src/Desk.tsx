import { useState } from 'react'
import { displayTime, request, localDate } from './api'
import type { Practice, Visit } from './api'
import { useVisits } from './useVisits'
import { PatientDetail } from './PatientDetail'

export function Desk({ practice, staff }: { practice: Practice; staff: string }) {
  const [revision, setRevision] = useState(0)
  const [tab, setTab] = useState('flow')
  const [selected, setSelected] = useState<number | null>(null)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('active')
  const [issue, setIssue] = useState('')
  const [date, setDate] = useState(localDate(new Date().toISOString(), practice.timezone))
  const [page, setPage] = useState(0)
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  const { visits, error, loading } = useVisits(practice.id, revision)
  async function run(action: string) {
    setBusy(true); setStatus('')
    try { const result = await request<{ message: string }>(`practices/${practice.id}/${action}`, 'POST', {}); setStatus(result.message); setRevision(r => r + 1) }
    catch (e) { setStatus(e instanceof Error ? e.message : 'Request failed. Reload before retrying.') }
    finally { setBusy(false) }
  }
  const active = visits.filter(v => v.active && v.issue)
  const resolved = visits.filter(v => !v.active || v.confirmed)
  const matching = visits.filter(v => v.name.toLowerCase().includes(search.toLowerCase())).filter(v => {
    if (tab === 'appointments') return localDate(v.starts_at, practice.timezone) === date && (filter === 'active' || (filter === 'confirmed' ? v.confirmed : filter === 'review' ? !!v.issue : !v.confirmed))
    return (filter === 'resolved' ? resolved.includes(v) : active.includes(v)) && (!issue || v.issue === issue)
  })
  const patient = visits.find(v => v.id === selected)
  function open(visit: Visit) { setSelected(visit.id) }
  function moveDate(days: number) { const d = new Date(`${date}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + days); setDate(d.toISOString().slice(0, 10)); setPage(0) }
  return <><div className="page-heading"><div><p className="eyebrow">{practice.name} · {staff}</p><h1>{patient ? patient.name : tab === 'flow' ? 'Patient flow' : 'Appointments'}</h1><p>{practice.timezone} · Demo clinic scope</p></div><div className="toolbar"><button className="secondary" onClick={() => { setSelected(null); setTab('flow'); setFilter('active'); setPage(0) }}>Patient flow</button><button className="secondary" onClick={() => { setSelected(null); setTab('appointments'); setFilter('active'); setPage(0) }}>Appointments</button></div></div>
    <div className="toolbar"><span>Last PMS sync: {practice.synced_at ? displayTime(practice.synced_at, practice.timezone) : 'Never'}</span><button disabled={busy} className="secondary" onClick={() => run('refresh')}>Refresh PMS</button><button disabled={busy} onClick={() => run('reminders')}>Run fake reminders</button></div>
    {status && <p role="status">{status}</p>}{error && <p role="alert" className="error">{error}</p>}{loading && <p role="status">Loading appointments…</p>}
    {patient ? <PatientDetail key={patient.id} visit={patient} practice={practice} staff={staff} onBack={() => setSelected(null)} onSaved={() => setRevision(r => r + 1)}/> : <>
      {tab === 'flow' && <div className="stats">{[['Needs attention', active.filter(v => !v.owner).length], ['In progress', active.filter(v => v.owner).length], ['Resolved', resolved.length]].map(([label, count]) => <section className="card" key={label}><small>{label}</small><strong>{count}</strong></section>)}</div>}
      <div className="toolbar">{tab === 'flow' && <label>Follow-up type<select value={issue} onChange={e => { setIssue(e.target.value); setPage(0) }}><option value="">All follow-up types</option>{[...new Set(visits.map(v => v.issue).filter(Boolean))].map(value => <option key={value} value={value || ''}>{value}</option>)}</select></label>}<label>Find a patient<input type="search" value={search} onChange={e => { setSearch(e.target.value); setPage(0) }}/></label><label>Show<select value={filter} onChange={e => { setFilter(e.target.value); setPage(0) }}>{tab === 'flow' ? <><option value="active">Active work</option><option value="resolved">Resolved</option></> : <><option value="active">All appointments</option><option value="confirmed">Confirmed</option><option value="unconfirmed">Unconfirmed</option><option value="review">Replies to review</option></>}</select></label></div>
      {tab === 'appointments' && <section className="card"><div className="toolbar"><button className="secondary" onClick={() => moveDate(-7)}>← Previous week</button><button className="secondary" onClick={() => setDate(localDate(new Date().toISOString(), practice.timezone))}>Today</button><button className="secondary" onClick={() => moveDate(7)}>Next week →</button><label>Jump to date<input type="date" value={date} onChange={e => setDate(e.target.value)}/></label></div><div className="week">{Array.from({ length: 7 }, (_, i) => { const d = new Date(`${date}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + i - 3); const day = d.toISOString().slice(0, 10); return <button className="secondary" key={day} onClick={() => setDate(day)}>{day}<small>{visits.filter(v => localDate(v.starts_at, practice.timezone) === day).length} visits</small></button> })}</div></section>}
      {matching.length === 0 && !loading && <p>No appointments match this view.</p>}
      {tab === 'flow' ? <div className="board">{(filter === 'resolved' ? ['Resolved'] : ['Needs attention', 'In progress']).map(column => <section className="column" key={column}><h2>{column}</h2>{matching.slice(page * 10, page * 10 + 10).filter(v => column === 'Resolved' || (column === 'In progress' ? !!v.owner : !v.owner)).map(v => <article className="card" key={v.id}><span className="pill">{v.issue || 'Resolved'}</span><h3><button className="link" onClick={() => open(v)}>{v.name} ↗</button></h3><p>{displayTime(v.starts_at, practice.timezone)}</p><small>{v.owner || 'Unassigned'}</small></article>)}</section>)}</div> : <div className="card table-wrap"><table><thead><tr><th>Patient</th><th>Appointment</th><th>Confirmation</th><th>PMS outcome</th><th>Next step</th></tr></thead><tbody>{matching.slice(page * 10, page * 10 + 10).map(v => <tr key={v.id}><td>{v.name}</td><td>{displayTime(v.starts_at, practice.timezone)}<small>{v.source.provider_name}</small></td><td><span className="pill">{v.confirmed ? 'Confirmed' : 'Unconfirmed'}</span>{v.issue && <small>{v.issue}</small>}</td><td>{v.outcome}</td><td><button className="link" onClick={() => open(v)}>Patient details →</button></td></tr>)}</tbody></table></div>}
      <div className="toolbar"><span>{matching.length} matching records</span><button className="secondary" disabled={page === 0} onClick={() => setPage(p => p - 1)}>Previous</button><button className="secondary" disabled={(page + 1) * 10 >= matching.length} onClick={() => setPage(p => p + 1)}>Next</button></div>
    </>}
  </>
}
