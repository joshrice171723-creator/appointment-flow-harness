﻿import { useEffect, useState } from 'react'
import { request } from './api'
import type { Practice } from './api'
import { Desk } from './Desk'
import { Inbox } from './Inbox'
import { Leadership } from './Leadership'

export default function App() {
  const [practices, setPractices] = useState<Practice[]>([])
  const [error, setError] = useState('')
  const [workspace, setWorkspace] = useState('home')
  const [clinic, setClinic] = useState('1')
  const [staff, setStaff] = useState('Taylor Morgan')
  useEffect(() => {
    let active = true
    request<Practice[]>('practices').then(data => { if (active) setPractices(data) }).catch(e => { if (active) setError(e.message) })
    return () => { active = false }
  }, [])
  const practice = practices.find(p => String(p.id) === clinic)
  return <><header><a className="brand" href="#" onClick={() => setWorkspace('home')}><span className="brand-icon">A↗</span><span>APEX<small>APPOINTMENT FLOW</small></span></a><nav><button className="link" onClick={() => setWorkspace('home')}>Workspaces ↗</button></nav></header>
    <main className={workspace === 'home' ? 'home' : ''}>
      {error && <p role="alert" className="error">{error}</p>}
      {practices.length === 0 && !error && <p role="status">Loading clinics…</p>}
      {workspace === 'home' && <><h1>Workspaces</h1><div className="workspace-grid">
        <section className="card"><h2>Front desk</h2><p>Review appointments and record patient follow-up.</p><label>Clinic<select value={clinic} onChange={e => setClinic(e.target.value)}>{practices.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label><label>Staff member · demo sign-in<select value={staff} onChange={e => setStaff(e.target.value)}><option>Taylor Morgan</option><option>Jordan Lee</option></select></label><button disabled={!practice} onClick={() => setWorkspace('desk')}>Open front desk →</button></section>
        <section className="card tinted"><h2>Apex leadership</h2><p>Aggregate appointment outcomes. No patient details.</p><p className="large-number">{practices.length}<small>clinics</small></p><button onClick={() => setWorkspace('leadership')}>Open Apex leadership →</button></section>
        <section className="card"><h2>Patient</h2><p>Internal demo: inspect fake messages and simulate a reply.</p><button onClick={() => setWorkspace('patient')}>Open patient workspace →</button></section>
      </div></>}
      {workspace === 'desk' && practice && <Desk key={clinic} practice={practice} staff={staff}/>}
      {workspace === 'patient' && <Inbox practices={practices}/>}
      {workspace === 'leadership' && <Leadership/>}
    </main></>
}
