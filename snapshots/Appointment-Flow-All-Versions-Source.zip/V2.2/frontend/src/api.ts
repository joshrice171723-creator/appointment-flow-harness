export type Practice = { id: number; name: string; timezone: string; synced_at: string | null; trusted: boolean }
export type Delivery = { id: number; channel: string; body: string; status: string; created_at: string }
export type Reply = { id: number; delivery_id: number; body: string; result: string; created_at: string }
export type Action = { id: number; staff: string; kind: string; note: string; created_at: string }
export type Visit = {
  id: number; patient_id: number; name: string; starts_at: string; revision: string; outcome: string;
  confirmed: boolean; active: boolean; owner: string | null; issue: string | null;
  source: Record<string, string | null>; contact: Record<string, string | boolean>;
  deliveries: Delivery[]; replies: Reply[]; actions: Action[];
}
export async function request<T>(path: string, method = 'GET', body?: unknown): Promise<T> {
  const response = await fetch(`/api/${path}`, { method, headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status}). Reload before retrying an uncertain save.`)
  return data as T
}
export function localDate(value: string, timezone: string) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(value))
}
export function displayTime(value: string, timezone: string) {
  return new Intl.DateTimeFormat('en-US', { timeZone: timezone, month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(value))
}
