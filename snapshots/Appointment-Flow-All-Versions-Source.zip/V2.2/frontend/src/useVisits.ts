﻿import { useEffect, useState } from 'react'
import { request } from './api'
import type { Visit } from './api'

export function useVisits(clinic: number, revision: number) {
  const [state, setState] = useState<{ visits: Visit[]; error: string; loading: boolean }>({ visits: [], error: '', loading: true })
  useEffect(() => {
    let active = true
    request<Visit[]>(`practices/${clinic}/visits`).then(visits => {
      if (active) setState({ visits, error: '', loading: false })
    }).catch(e => { if (active) setState({ visits: [], error: e.message, loading: false }) })
    return () => { active = false }
  }, [clinic, revision])
  return state
}
