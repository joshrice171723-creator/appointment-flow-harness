import { useState } from 'react'
import { request, displayTime } from './api'
import type { Practice, Visit } from './api'

export function PatientDetail({ visit, practice, staff, onBack, onSaved }: { visit: Visit; practice: Practice; staff: string; onBack: () => void; onSaved: () => void }) {
  const [tab, setTab] = useState('follow')
  const [note, setNote] = useState('')
  const [kind, setKind] = useState('attempted')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [event, setEvent] = useState(crypto.randomUUID())
  const [facts, setFacts] = useState({ birthdate: String(visit.contact.birthdate ?? visit.source.birthdate ?? ''), wireless_phone: String(visit.contact.wireless_phone ?? visit.source.wireless_phone ?? ''), email: String(visit.contact.email ?? visit.source.email ?? ''), preferred_language: String(visit.contact.preferred_language ?? visit.source.preferred_language ?? ''), consent: visit.contact.consent === true, sms_consent: visit.contact.sms_consent !== false, email_consent: visit.contact.email_consent !== false })
  async function save(action: string, text: string) {
    setBusy(true); setError('')
    try {
      await request(`practices/${practice.id}/visits/${visit.id}/actions`, 'POST', { staff, kind: action, note: text, event_id: event, revision: visit.revision, contact: facts })
      setNote(''); setEvent(crypto.randomUUID()); onSaved()
    } catch (e) { setError(e instanceof Error ? e.message : 'Save outcome uncertain. Reload before retrying. Your draft is retained.') }
    finally { setBusy(false) }
  }
  return <><button className="link" onClick={onBack}>← Patient flow / {practice.name}</button><section className="appointment-summary"><h3>Appointment #{visit.id}</h3><p>{displayTime(visit.starts_at, practice.timezone)} · {visit.source.provider_name}</p><span className="pill">{visit.confirmed ? 'Confirmed' : 'Unconfirmed'}</span> · PMS outcome: {visit.outcome}<p>{visit.issue}</p></section>
    <div className="detail-grid"><aside className="card"><h2>Patient details</h2><p>{visit.name}</p><p>{Object.keys(visit.contact).length ? 'Locally verified details' : 'Not verified'}</p><details><summary>Verify or correct contact</summary><form onSubmit={e => { e.preventDefault(); void save('verified', note) }}>
      {(['birthdate', 'wireless_phone', 'email', 'preferred_language'] as const).map(field => <label key={field}>{({ birthdate: 'Birthdate', wireless_phone: 'Mobile phone', email: 'Email', preferred_language: 'Preferred language (en/es)' })[field]}<input type={field === 'birthdate' ? 'date' : field === 'email' ? 'email' : 'text'} value={facts[field]} onChange={e => setFacts({ ...facts, [field]: e.target.value })}/><small>PMS source: {visit.source[field] || 'No value'}</small></label>)}
      <label className="check"><input type="checkbox" checked={facts.sms_consent} onChange={e => setFacts({ ...facts, sms_consent: e.target.checked })}/>SMS permitted</label><label className="check"><input type="checkbox" checked={facts.email_consent} onChange={e => setFacts({ ...facts, email_consent: e.target.checked })}/>Email permitted</label><label className="check"><input type="checkbox" checked={facts.consent} onChange={e => setFacts({ ...facts, consent: e.target.checked })}/>Verified permission for available channels</label><label>Verification note<textarea required value={note} onChange={e => setNote(e.target.value)} maxLength={1000}/></label><button disabled={busy}>Save local verification</button></form></details>
      <dl>{Object.entries(facts).filter(([key]) => !['consent', 'sms_consent', 'email_consent'].includes(key)).map(([key, value]) => <div key={key}><dt>{key.replaceAll('_', ' ')}</dt><dd>{String(value) || 'No value'}</dd></div>)}</dl>
    </aside><section><div className="toolbar">{[['follow', 'Follow-up'], ['appointments', 'Appointments'], ['activity', 'Activity log']].map(([value, label]) => <button className={tab === value ? '' : 'secondary'} onClick={() => setTab(value)} key={value}>{label}</button>)}</div>
      {error && <p role="alert" className="error">{error}</p>}
      {tab === 'follow' && <section className="card"><h2>Follow-up</h2><p>Assigned to: {visit.owner || 'Unassigned'}</p><button disabled={busy} className="secondary" onClick={() => save('assign', 'Claimed by staff')}>Assign to me</button><form onSubmit={e => { e.preventDefault(); void save(kind, note) }}><label>Outcome<select value={kind} onChange={e => setKind(e.target.value)}><option value="attempted">Contact attempted</option><option value="confirmed">Confirmed by staff</option><option value="rescheduled">Rescheduled in PMS</option><option value="canceled">Canceled in PMS</option></select></label><label>Note<textarea required maxLength={1000} value={note} onChange={e => setNote(e.target.value)}/></label><button disabled={busy}>Record follow-up</button></form><details><summary>Follow-up history ({visit.actions.length})</summary>{visit.actions.map(a => <article key={a.id}><h3>{a.kind} · {a.staff}</h3><p>{a.note}</p><small>{displayTime(a.created_at, practice.timezone)}</small></article>)}</details></section>}
      {tab === 'appointments' && <section className="card"><h2>Appointment source</h2><p>{visit.source.wall_time} · {practice.timezone}</p><p>Source outcome: {visit.outcome}. Confirmation: {visit.confirmed ? 'Confirmed' : 'Unconfirmed'}.</p><p>Booking changes must be made in the PMS.</p></section>}
      {tab === 'activity' && <section className="card"><h2>Message activity</h2>{visit.deliveries.map(d => <article key={d.id}><h3>{d.channel} · {d.status}</h3><p>{d.body}</p>{visit.replies.filter(r => r.delivery_id === d.id).map(r => <p key={r.id}>Reply: {r.body} · {r.result}</p>)}</article>)}{visit.deliveries.length === 0 && <p>No delivery attempts recorded.</p>}</section>}
    </section></div></>
}
