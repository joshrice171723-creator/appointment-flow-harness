﻿import { useEffect, useState } from 'react'
import { request } from './api'
type Report = { clinic: string; recorded: number; completed: number; rescheduled: number; canceled: number; unknown: number; messages: number; holds: number; follow_ups: number; confirmed: number }
export function Leadership() {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7))
  const [data, setData] = useState<Report[]>([])
  const [error, setError] = useState('')
  useEffect(() => {
    let active = true
    request<Report[]>(`leadership?month=${encodeURIComponent(month)}`).then(rows => { if (active) { setData(rows); setError('') } }).catch(e => { if (active) setError(e.message) })
    return () => { active = false }
  }, [month])
  return <><div className="page-heading"><h1>Appointment outcomes</h1><label>Outcome month<input type="month" required value={month} onChange={e => setMonth(e.target.value)}/></label></div>{error && <p role="alert">{error}</p>}<p>Recorded PMS outcomes. Confirmation does not establish attendance or no-show reduction.</p><div className="board">{data.map(c => <section className="card" key={c.clinic}><h2>{c.clinic}</h2><p>{c.recorded} recorded visits</p><meter min={0} max={c.recorded || 1} value={c.completed}>{c.completed}</meter><div className="stats">{[['Completed', c.completed], ['Rescheduled', c.rescheduled], ['Canceled', c.canceled], ['Unknown', c.unknown]].map(([label, count]) => <div key={label}><small>{label}</small><strong>{count}</strong></div>)}</div></section>)}</div><section className="card table-wrap"><h2>Clinic comparison</h2><table><thead><tr><th>Clinic</th><th>Completion rate</th><th>Recorded visits</th><th>Confirmed</th></tr></thead><tbody>{data.map(c => <tr key={c.clinic}><td>{c.clinic}</td><td>{c.recorded ? `${(c.completed / c.recorded * 100).toFixed(1)}%` : 'No records'}</td><td>{c.recorded}</td><td>{c.confirmed}</td></tr>)}</tbody></table><p>Completion rate = completed / all recorded visits in the clinic-local month. Scheduled visits are unknown outcomes.</p></section>{[['messages', 'Reminder activity'], ['holds', 'Contact and reply holds'], ['follow_ups', 'Staff activity']].map(([key, title]) => <details className="card" key={key}><summary>{title}</summary>{data.map(c => <p key={c.clinic}>{c.clinic}: {c[key as 'messages' | 'holds' | 'follow_ups']} {key === 'holds' ? 'visits currently needing review' : key === 'messages' ? 'successful fake messages for visits in this month' : 'recorded staff actions for visits in this month'}</p>)}</details>)}</>
}
