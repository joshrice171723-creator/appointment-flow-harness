﻿# Architecture

```mermaid
flowchart LR
  PMS[(PostgreSQL pms schema)] -->|SELECT-only role| Refresh[PmsRefresh]
  Refresh --> Local[(App-owned PostgreSQL tables)]
  React[React workspaces] --> API[Rails controllers]
  API --> Workflows[ReminderBatch / ReceiveReply / RecordStaffAction]
  Workflows -->|transaction + advisory lock| Local
  Workflows --> Fake[FakeTransport: no network I/O]
  Local --> Reports[Aggregate leadership response]
```

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: source snapshot
  Unconfirmed --> Confirmed: safe YES or staff clarification
  Unconfirmed --> Review: ambiguous / late / stale reply or contact hold
  Confirmed --> Review: later conflicting reply
  Confirmed --> Unconfirmed: source appointment version changes
  Review --> Confirmed: staff records clarification
  Review --> Unconfirmed: local contact verification
  Unconfirmed --> Closed: source ends visit / staff records PMS change
  Confirmed --> Closed: source ends visit
```

Controllers translate HTTP and select the clinic. Workflows own cross-record rules and transactions. Visit owns contact eligibility and current confirmation meaning. Refresh, reply, reminder and staff writes share a PostgreSQL advisory lock so versions cannot change during a decision. Unique indexes back logical send/event deduplication. Fake transport records deterministic success/failure synchronously inside that transaction; this does not claim real-provider exactly-once delivery.

PMS timestamps are clinic-local wall times. Refresh requires an explicit timezone and rejects DST gaps/ambiguity rather than choosing a guessed instant. App-owned instants use UTC. Aggregate reports use clinic-local month boundaries and source outcomes separately from confirmations.
