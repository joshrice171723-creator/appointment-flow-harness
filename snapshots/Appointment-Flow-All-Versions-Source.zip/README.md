# Appointment Flow source snapshots

See SOURCE-MANIFEST.json for provenance and file hashes. V26 is the separate interview checkout stored in Appointment-Flow-v25. Source copies omit dependencies, runtime data, and credentials. The canceled V2.5.1.1.0 trial has no completed app to copy.
