namespace :demo do
  desc "Run fake reminders; optional NOW is an ISO8601 instant with offset"
  task reminders: :environment do
    now = ENV["NOW"] ? Time.iso8601(ENV.fetch("NOW")) : Time.current
    Clinic.find_each { |clinic| puts "#{clinic.name}: #{RunReminders.new(clinic, now: now).call} fake attempts" }
  end
end
