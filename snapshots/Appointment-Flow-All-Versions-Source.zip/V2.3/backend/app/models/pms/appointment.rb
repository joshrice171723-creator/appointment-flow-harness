module Pms
  class Appointment < Record
    self.table_name = "pms.appointments"
  end
end
