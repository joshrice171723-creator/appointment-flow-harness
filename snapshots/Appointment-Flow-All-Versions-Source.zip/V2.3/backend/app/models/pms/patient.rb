module Pms
  class Patient < Record
    self.table_name = "pms.patients"
  end
end
