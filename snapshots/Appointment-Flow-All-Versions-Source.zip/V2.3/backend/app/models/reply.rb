class Reply < ApplicationRecord
  belongs_to :clinic
  belongs_to :message
  validates :event_id, :body, presence: true, length: { maximum: 2000 }
end
