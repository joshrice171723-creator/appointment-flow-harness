class Contact < ApplicationRecord
  belongs_to :clinic
  has_many :visits

  def details = source.merge(corrections)
  def name = "#{source['first_name']} #{source['last_name']}"
  def recipient(channel)
    value = details[channel == "sms" ? "wireless_phone" : "email"].to_s
    return value.strip.downcase if channel == "email" && value.match?(/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/)
    digits = value.gsub(/\D/, "") if channel == "sms"
    digits = digits.delete_prefix("1") if digits&.length == 11
    "+1#{digits}" if digits&.length == 10
  end

  def hold(today)
    birthday = begin
      Date.iso8601(details["birthdate"].to_s)
    rescue Date::Error
      nil
    end
    return "Verify birthdate and an authorized adult contact" unless birthday && birthday <= today.advance(years: -18)
    return "Arrange contact in the preferred language" unless %w[en es].include?(details["preferred_language"])
    return "Review changed PMS details against local verification" if source["verification_conflict"]
    nil
  end

  def permitted?(channel)
    return false unless recipient(channel)
    return email_allowed if channel == "email"
    sms_allowed && !clinic.suppressions.exists?(recipient: recipient(channel))
  end
end
