class Message < ApplicationRecord
  belongs_to :visit
  has_many :replies
end
