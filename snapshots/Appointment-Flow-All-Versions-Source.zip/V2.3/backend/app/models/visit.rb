class Visit < ApplicationRecord
  belongs_to :clinic
  belongs_to :contact
  has_many :messages
  has_many :activities
  def confirmed? = confirmed_revision == revision
  def scheduled? = active && source["status"] == "scheduled" && local_outcome.nil?
  def local_time = starts_at&.in_time_zone(clinic.zone)
  def outcome = { "complete" => "Completed", "broken" => "Canceled", "unscheduled" => "Rescheduled" }.fetch(source["status"], "Unknown")
end
