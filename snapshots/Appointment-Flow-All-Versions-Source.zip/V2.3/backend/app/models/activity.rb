class Activity < ApplicationRecord
  belongs_to :visit
  validates :staff, :note, presence: true
  validates :note, length: { maximum: 2000 }
end
