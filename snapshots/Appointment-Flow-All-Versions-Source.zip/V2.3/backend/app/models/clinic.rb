class Clinic < ApplicationRecord
  has_many :contacts
  has_many :visits
  has_many :suppressions
  def timezone = ActiveSupport::TimeZone[zone]
end
