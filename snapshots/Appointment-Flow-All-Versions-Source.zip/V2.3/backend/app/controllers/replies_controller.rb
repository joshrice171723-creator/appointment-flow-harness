class RepliesController < ApplicationController
  def create
    reply = ProcessReply.new(clinic).call(message_id: params.require(:message_id), event_id: params.require(:event_id), body: params.require(:body))
    render json: { result: reply.result }
  end
end
