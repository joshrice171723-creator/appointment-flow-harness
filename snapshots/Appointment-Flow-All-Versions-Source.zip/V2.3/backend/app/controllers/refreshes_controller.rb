class RefreshesController < ApplicationController
  def create
    staff
    RefreshSource.new(clinic).call
    render json: { synced_at: clinic.reload.synced_at }
  end
end
