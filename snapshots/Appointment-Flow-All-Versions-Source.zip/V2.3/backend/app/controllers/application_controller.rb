class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "Record not found in this clinic" }, status: :not_found
  end
  rescue_from ActiveRecord::RecordInvalid, ArgumentError, ActionController::ParameterMissing do |error|
    render json: { error: error.message }, status: :unprocessable_entity
  end
  rescue_from RefreshSource::Unavailable do |error|
    render json: { error: error.message }, status: :service_unavailable
  end

  private

  def clinic = @clinic ||= Clinic.find(params[:clinic_id])
  def staff
    identity = request.headers["X-Demo-Staff"]
    raise ArgumentError, "Select a demo staff member" unless [ "Taylor Morgan", "Jordan Lee" ].include?(identity)
    identity
  end
end
