class LeadershipController < ApplicationController
  def index
    month = params[:month].present? ? Date.strptime(params[:month], "%Y-%m") : Date.current.beginning_of_month
    render json: Clinic.order(:id).map { |clinic| totals(clinic, month) }
  end

  private

  def totals(clinic, month)
    range = clinic.timezone.local(month.year, month.month, 1)...clinic.timezone.local(month.next_month.year, month.next_month.month, 1)
    visits = clinic.visits.where(active: true, starts_at: range)
    outcomes = visits.group("source ->> 'status'").count
    recorded = outcomes.values.sum
    completed = outcomes.fetch("complete", 0)
    { clinic: clinic.name, recorded: recorded, completed: completed, canceled: outcomes.fetch("broken", 0),
      rescheduled: outcomes.fetch("unscheduled", 0), unknown: recorded - completed - outcomes.fetch("broken", 0) - outcomes.fetch("unscheduled", 0),
      completion_rate: recorded.zero? ? nil : (100.0 * completed / recorded).round(1),
      messages: Message.where(visit_id: visits.select(:id)).count,
      open_issues: visits.where.not(issue: nil).count, confirmed: visits.where("confirmed_revision = revision").count }
  end
end
