class VisitsController < ApplicationController
  def index
    staff
    visits = clinic.visits.includes(:contact).where(active: true).order(:starts_at, :id)
    if params[:date].present?
      date = Date.iso8601(params[:date])
      visits = visits.where(starts_at: clinic.timezone.local(date.year, date.month, date.day).all_day)
    end
    render json: visits.map { |visit| summary(visit) }
  end

  def show
    staff
    visit = clinic.visits.find(params[:id])
    render json: summary(visit).merge(
      contact: { id: visit.contact.id, source: visit.contact.source, corrections: visit.contact.corrections, sms_allowed: visit.contact.sms_allowed, email_allowed: visit.contact.email_allowed },
      activities: visit.activities.order(:created_at).as_json(only: [ :id, :staff, :action, :note, :created_at ])
    )
  end

  private

  def summary(visit)
    { id: visit.id, contact_id: visit.contact_id, name: visit.contact.name, starts_at: visit.starts_at,
      wall_time: visit.source["start_at"], provider: visit.source["provider_name"], confirmed: visit.confirmed?,
      issue: visit.issue, owner: visit.owner, outcome: visit.outcome, local_outcome: visit.local_outcome,
      source_status: visit.source["status"], active: visit.active }
  end
end
