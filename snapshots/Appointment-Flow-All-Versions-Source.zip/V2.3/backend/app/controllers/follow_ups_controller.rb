class FollowUpsController < ApplicationController
  def create
    visit = RecordFollowUp.new.call(clinic: clinic, visit_id: params[:visit_id], staff: staff, action: params.require(:outcome), note: params.require(:note))
    render json: { id: visit.id, saved: true }
  end
end
