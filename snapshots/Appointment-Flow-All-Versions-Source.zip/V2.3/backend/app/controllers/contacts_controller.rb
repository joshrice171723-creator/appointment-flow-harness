class ContactsController < ApplicationController
  def update
    identity = staff
    fields = params.require(:corrections).permit(:birthdate, :wireless_phone, :email, :preferred_language).to_h
    clinic.with_lock do
      contact = clinic.contacts.find(params[:id])
      contact.update!(corrections: contact.corrections.merge(fields), source: contact.source.except("verification_conflict"))
      contact.visits.each { |visit| visit.activities.create!(staff: identity, action: "contact_verified", note: "Local contact details verified; source unchanged", created_at: Time.current) }
    end
    render json: { saved: true }
  end
end
