class ClinicsController < ApplicationController
  def index
    render json: Clinic.order(:id).as_json(only: [ :id, :name, :zone, :synced_at, :sync_error ])
  end
end
