class RemindersController < ApplicationController
  def create
    staff
    render json: { attempts: RunReminders.new(clinic).call }
  end
end
