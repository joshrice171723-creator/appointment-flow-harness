class MessagesController < ApplicationController
  def index
    contact = clinic.contacts.find(params.require(:contact_id))
    messages = Message.where(visit_id: contact.visits.select(:id)).includes(:replies).order(:created_at)
    render json: messages.map { |message| message.as_json(only: [ :id, :channel, :body, :status, :created_at ]).merge(replies: message.replies.as_json(only: [ :id, :body, :result, :created_at ])) }
  end
end
