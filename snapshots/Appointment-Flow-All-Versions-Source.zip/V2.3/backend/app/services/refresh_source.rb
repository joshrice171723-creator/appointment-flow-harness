class RefreshSource
  class Unavailable < StandardError; end

  def initialize(clinic)
    @clinic = clinic
  end

  def call
    @clinic.with_lock do
      rows = Pms::Appointment.where(clinic_id: @clinic.id).to_a
      raise Unavailable, "PMS returned no appointments; retained previous snapshot" if rows.empty?
      if @clinic.visits.where(active: true).where.not(source_id: rows.map(&:id)).exists?
        raise Unavailable, "PMS lost previously tracked rows; investigate the source before outreach"
      end
      patients = Pms::Patient.where(id: rows.map(&:patient_id)).index_by(&:id)
      raise Unavailable, "PMS patient data is incomplete" unless patients.size == rows.map(&:patient_id).uniq.size
      @contacts = @clinic.contacts.index_by(&:source_id)
      @visits = @clinic.visits.index_by(&:source_id)
      rows.each { |row| import(row, patients.fetch(row.patient_id)) }
      @clinic.visits.where.not(source_id: rows.map(&:id)).update_all(active: false)
      @clinic.update!(synced_at: Time.current, sync_error: nil)
    end
  rescue ActiveRecord::StatementInvalid, Unavailable => error
    @clinic.reload.update!(sync_error: "PMS refresh failed; outreach paused")
    raise Unavailable, "PMS refresh failed; outreach paused", cause: error
  end

  private

  def import(row, patient)
    contact = @contacts[patient.id] ||= @clinic.contacts.build(source_id: patient.id)
    facts = patient.as_json.except("id")
    changed = contact.corrections.any? { |key, _| contact.source[key] != facts[key] }
    facts["verification_conflict"] = true if changed || contact.source["verification_conflict"]
    contact.assign_attributes(source: facts)
    contact.save! if contact.changed?
    naive = Time.utc(row.start_at.year, row.start_at.month, row.start_at.day, row.start_at.hour, row.start_at.min, row.start_at.sec)
    periods = @clinic.timezone.tzinfo.periods_for_local(naive)
    instant = naive - periods.first.utc_total_offset if periods.one?
    visit = @visits[row.id] || @clinic.visits.build(source_id: row.id)
    changed = visit.new_record? || [ "patient_id", "start_at", "status" ].any? { |key| visit.source[key] != row.as_json[key] }
    revision = changed ? SecureRandom.uuid : visit.revision
    visit.assign_attributes(contact: contact, source: row.as_json, starts_at: instant, revision: revision, active: true)
    if visit.revision_changed? && visit.persisted?
      visit.assign_attributes(confirmed_revision: nil, local_outcome: nil, issue: "Appointment changed; review current time")
    end
    visit.issue = "Appointment wall time needs review" unless instant
    visit.save! if visit.changed?
  end
end
