class FakeDelivery
  def deliver(visit, step:, channel:, now:)
    contact = visit.contact
    recipient = contact.recipient(channel)
    spanish = contact.details["preferred_language"] == "es"
    time = visit.local_time.strftime("%Y-%m-%d %H:%M %Z")
    body = spanish ? "Cita: #{time}, #{visit.clinic.name}. Responda YES para confirmar o NO para ayuda." : "Appointment: #{time}, #{visit.clinic.name}. Reply YES to confirm or NO for help."
    body += " Reply STOP to stop texts." if channel == "sms"
    # This adapter never performs network I/O; failure is a deterministic fictional fixture.
    status = recipient.end_with?("0199") ? "failed" : "sent"
    visit.messages.create!(revision: visit.revision, step: step, channel: channel, recipient: recipient, status: status, body: body, created_at: now)
  end
end
