class RecordFollowUp
  ACTIONS = %w[assign attempted confirmed rescheduled canceled].freeze

  def call(clinic:, visit_id:, staff:, action:, note:)
    raise ArgumentError, "Choose a follow-up outcome" unless ACTIONS.include?(action)
    raise ArgumentError, "A short note is required" unless note.is_a?(String) && note.present? && note.length <= 2000
    visit = clinic.visits.find(visit_id)
    RefreshSource.new(clinic).call
    clinic.with_lock do
      visit.reload
      raise ArgumentError, "Visit is no longer scheduled; refresh and review" unless visit.scheduled?
      if action == "confirmed"
        raise ArgumentError, "Visit has started or its time needs review" unless visit.starts_at && visit.starts_at > Time.current
        visit.confirmed_revision = visit.revision
      end
      visit.owner = staff
      visit.local_outcome = action if %w[rescheduled canceled].include?(action)
      visit.issue = %w[confirmed rescheduled canceled].include?(action) ? nil : (visit.issue || "Staff follow-up")
      visit.save!
      visit.activities.create!(staff: staff, action: action, note: note, created_at: Time.current)
      visit
    end
  end
end
