class ProcessReply
  def initialize(clinic)
    @clinic = clinic
  end

  def call(message_id:, event_id:, body:, now: Time.current)
    unless body.is_a?(String) && event_id.is_a?(String) && body.present? && event_id.present? && body.length <= 2000 && event_id.length <= 2000
      raise ArgumentError, "Reply and event ID are required strings (maximum 2000 characters)"
    end
    message = Message.joins(:visit).where(visits: { clinic_id: @clinic.id }).find(message_id)
    RefreshSource.new(@clinic).call
    @clinic.with_lock do
      existing = Reply.find_by(clinic: @clinic, event_id: event_id)
      if existing
        raise ArgumentError, "Event ID already belongs to a different reply" unless existing.message_id == message_id.to_i && existing.body == body
        return existing
      end
      visit = message.visit
      result = interpret(message, visit, body.strip.upcase, now)
      Reply.create!(clinic: @clinic, message: message, event_id: event_id, body: body, result: result, created_at: now)
    end
  end

  private

  def interpret(message, visit, command, now)
    if command == "STOP" && message.channel == "sms"
      @clinic.suppressions.find_or_create_by!(recipient: message.recipient)
      return "SMS stopped"
    end
    recipients = @clinic.contacts.select { |contact| contact.recipient(message.channel) == message.recipient }
    pending = @clinic.visits.where(contact_id: recipients.map(&:id), active: true).select { |candidate| candidate.scheduled? && candidate.starts_at && candidate.starts_at > now }
    safe = message.status == "sent" && message.revision == visit.revision && visit.scheduled? && visit.starts_at && visit.starts_at > now && recipients.one? && pending.one? && visit.contact.recipient(message.channel) == message.recipient && !visit.contact.hold(now.in_time_zone(@clinic.zone).to_date)
    if command == "YES" && safe
      visit.update!(confirmed_revision: visit.revision, issue: nil)
      "Confirmed"
    else
      visit.update!(issue: "Reply needs review")
      "Reply needs review"
    end
  end
end
