class RunReminders
  def initialize(clinic, now: Time.current)
    @clinic, @now = clinic, now
  end

  def call
    RefreshSource.new(@clinic).call
    @clinic.with_lock do
      local_now = @now.in_time_zone(@clinic.zone)
      return 0 unless (10...18).cover?(local_now.hour)
      before = Message.joins(:visit).where(visits: { clinic_id: @clinic.id }).count
      @clinic.visits.includes(:contact).where(active: true).find_each do |visit|
        next unless visit.scheduled?
        if visit.starts_at.nil?
          visit.update!(issue: "Appointment wall time needs review")
          next
        end
        next unless visit.starts_at > @now
        days = (visit.local_time.to_date - local_now.to_date).to_i
        next unless (0..7).cover?(days)
        visit.update!(issue: "No reply; contact patient") if days <= 2 && !visit.confirmed? && visit.issue.nil?
        next if visit.confirmed?
        send_request(visit, days, local_now.to_date)
      end
      Message.joins(:visit).where(visits: { clinic_id: @clinic.id }).count - before
    end
  end

  private

  def send_request(visit, days, today)
    contact = visit.contact
    hold = contact.hold(today)
    channel = contact.permitted?("sms") ? "sms" : "email"
    hold ||= "No permitted usable reminder channel" unless contact.permitted?(channel)
    if hold
      visit.update!(issue: hold)
      return
    end
    step = days <= 1 ? "final" : days <= 3 ? "follow_up" : "initial"
    previous = visit.messages.where(revision: visit.revision)
    if days == 6 && previous.where(channel: "sms").exists? && contact.permitted?("email")
      channel, step = "email", "backup"
    end
    return if previous.exists?(step: step, channel: channel)
    message = FakeDelivery.new.deliver(visit, step: step, channel: channel, now: @now)
    if message.status == "failed"
      visit.update!(issue: "Delivery failed; review contact")
      FakeDelivery.new.deliver(visit, step: "backup", channel: "email", now: @now) if channel == "sms" && contact.permitted?("email") && !previous.exists?(step: "backup", channel: "email")
    elsif visit.issue == "No permitted usable reminder channel" || visit.issue&.start_with?("Verify", "Arrange", "Review changed")
      visit.update!(issue: nil)
    end
  end
end
