Rails.application.routes.draw do
  scope :api do
    resources :clinics, only: :index do
      resource :refresh, only: :create
      resources :visits, only: [ :index, :show ] do
        resource :follow_up, only: :create
      end
      resources :contacts, only: :update
      resources :messages, only: :index
      resources :replies, only: :create
      resource :reminders, only: :create
    end
    get "leadership", to: "leadership#index"
  end
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
end
