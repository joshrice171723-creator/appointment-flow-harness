# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end
# Fictional source writes are confined to this explicitly invoked setup path.
require_relative "demo_source"
DemoSource.seed
Clinic.find_each do |clinic|
  RefreshSource.new(clinic).call
  clinic.contacts.update_all(sms_allowed: true, email_allowed: true)
  now = clinic.timezone.local(Date.current.year, Date.current.month, Date.current.day, 11)
  RunReminders.new(clinic, now: now).call
  message = Message.joins(:visit).where(visits: { clinic_id: clinic.id }).where(status: "sent").first
  ProcessReply.new(clinic).call(message_id: message.id, event_id: "seed-confirm-#{clinic.id}", body: "YES", now: now) if message
end
