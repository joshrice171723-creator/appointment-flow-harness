# Explicit fictional PMS fixture writer; never called from application request paths.
module DemoSource
  def self.seed
    connection = ActiveRecord::Base.connection
    [ [ 1, "Austin", "TX" ], [ 2, "Phoenix", "AZ" ] ].each do |id, name, state|
      connection.execute("INSERT INTO pms.clinics (id,name,city,state) VALUES (#{id},#{connection.quote(name)},#{connection.quote(name)},#{connection.quote(state)}) ON CONFLICT (id) DO NOTHING")
      zone = id == 1 ? "America/Chicago" : "America/Phoenix"
      Clinic.find_or_create_by!(id: id) { |clinic| clinic.name = name; clinic.zone = zone }
      18.times do |index|
        patient_id = id * 100 + index
        phone = "202555#{format('%04d', patient_id)}"
        phone = "2025550199" if index == 3
        phone = "202555#{format('%04d', id * 100 + 5)}" if index == 6
        email = index == 1 ? "email.only.#{patient_id}@example.test" : "patient.#{patient_id}@example.test"
        birthday = index == 4 ? nil : index == 7 ? "2015-01-01" : "1990-01-01"
        language = index == 8 ? "fr" : index == 9 ? "es" : "en"
        phone = nil if index == 1 || index == 4
        values = [ patient_id, "Demo", "Patient #{patient_id}", birthday, phone, email, language ].map { |v| connection.quote(v) }.join(",")
        connection.execute("INSERT INTO pms.patients (id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (#{values}) ON CONFLICT (id) DO NOTHING")
        day = Date.current + (index < 12 ? (index % 7) + 1 : -(index - 10))
        status = index < 12 ? "scheduled" : %w[complete complete broken unscheduled scheduled complete][index - 12]
        starts = "#{day.iso8601} 15:00:00"
        connection.execute("INSERT INTO pms.appointments (id,patient_id,clinic_id,provider_name,start_at,length_minutes,procedure_note,status,updated_at) VALUES (#{patient_id},#{patient_id},#{id},'Dr. Avery Chen',#{connection.quote(starts)},30,'Synthetic source-only note',#{connection.quote(status)},CURRENT_TIMESTAMP) ON CONFLICT (id) DO NOTHING")
      end
    end
  end
end
