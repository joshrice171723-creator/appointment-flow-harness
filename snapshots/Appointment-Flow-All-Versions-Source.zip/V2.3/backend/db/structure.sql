SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pms; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pms;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.appointments (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    provider_name text,
    procedure_note text,
    start_at timestamp(6) without time zone NOT NULL,
    length_minutes integer,
    status text NOT NULL,
    updated_at timestamp(6) without time zone
);


--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.appointments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.appointments_id_seq OWNED BY pms.appointments.id;


--
-- Name: clinics; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.clinics (
    id bigint NOT NULL,
    name text NOT NULL,
    address_line text,
    city text,
    state text,
    phone text
);


--
-- Name: clinics_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.clinics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinics_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.clinics_id_seq OWNED BY pms.clinics.id;


--
-- Name: patients; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.patients (
    id bigint NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    birthdate date,
    wireless_phone text,
    email text,
    preferred_language text,
    guarantor_id bigint
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.patients_id_seq OWNED BY pms.patients.id;


--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id bigint NOT NULL,
    visit_id bigint NOT NULL,
    staff character varying NOT NULL,
    action character varying NOT NULL,
    note text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: clinics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinics (
    id bigint NOT NULL,
    name character varying NOT NULL,
    zone character varying NOT NULL,
    synced_at timestamp(6) without time zone,
    sync_error character varying
);


--
-- Name: clinics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clinics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clinics_id_seq OWNED BY public.clinics.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    source_id bigint NOT NULL,
    source jsonb DEFAULT '{}'::jsonb NOT NULL,
    corrections jsonb DEFAULT '{}'::jsonb NOT NULL,
    sms_allowed boolean DEFAULT false NOT NULL,
    email_allowed boolean DEFAULT false NOT NULL
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    visit_id bigint NOT NULL,
    revision character varying NOT NULL,
    step character varying NOT NULL,
    channel character varying NOT NULL,
    recipient character varying NOT NULL,
    status character varying NOT NULL,
    body text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.replies (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    message_id bigint NOT NULL,
    event_id character varying NOT NULL,
    result character varying NOT NULL,
    body text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: replies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.replies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: replies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.replies_id_seq OWNED BY public.replies.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: suppressions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppressions (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    recipient character varying NOT NULL
);


--
-- Name: suppressions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppressions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppressions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppressions_id_seq OWNED BY public.suppressions.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    contact_id bigint NOT NULL,
    source_id bigint NOT NULL,
    source jsonb DEFAULT '{}'::jsonb NOT NULL,
    starts_at timestamp(6) without time zone,
    revision character varying NOT NULL,
    confirmed_revision character varying,
    issue character varying,
    owner character varying,
    local_outcome character varying,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments ALTER COLUMN id SET DEFAULT nextval('pms.appointments_id_seq'::regclass);


--
-- Name: clinics id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics ALTER COLUMN id SET DEFAULT nextval('pms.clinics_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients ALTER COLUMN id SET DEFAULT nextval('pms.patients_id_seq'::regclass);


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: clinics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics ALTER COLUMN id SET DEFAULT nextval('public.clinics_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: replies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies ALTER COLUMN id SET DEFAULT nextval('public.replies_id_seq'::regclass);


--
-- Name: suppressions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppressions ALTER COLUMN id SET DEFAULT nextval('public.suppressions_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: replies replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: suppressions suppressions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppressions
    ADD CONSTRAINT suppressions_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: index_appointments_on_clinic_id_and_start_at; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX index_appointments_on_clinic_id_and_start_at ON pms.appointments USING btree (clinic_id, start_at);


--
-- Name: index_activities_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_activities_on_visit_id ON public.activities USING btree (visit_id);


--
-- Name: index_contacts_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contacts_on_clinic_id ON public.contacts USING btree (clinic_id);


--
-- Name: index_contacts_on_clinic_id_and_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_contacts_on_clinic_id_and_source_id ON public.contacts USING btree (clinic_id, source_id);


--
-- Name: index_messages_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_visit_id ON public.messages USING btree (visit_id);


--
-- Name: index_messages_on_visit_id_and_revision_and_step_and_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_messages_on_visit_id_and_revision_and_step_and_channel ON public.messages USING btree (visit_id, revision, step, channel);


--
-- Name: index_replies_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_clinic_id ON public.replies USING btree (clinic_id);


--
-- Name: index_replies_on_clinic_id_and_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_replies_on_clinic_id_and_event_id ON public.replies USING btree (clinic_id, event_id);


--
-- Name: index_replies_on_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_message_id ON public.replies USING btree (message_id);


--
-- Name: index_suppressions_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_suppressions_on_clinic_id ON public.suppressions USING btree (clinic_id);


--
-- Name: index_suppressions_on_clinic_id_and_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_suppressions_on_clinic_id_and_recipient ON public.suppressions USING btree (clinic_id, recipient);


--
-- Name: index_visits_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_clinic_id ON public.visits USING btree (clinic_id);


--
-- Name: index_visits_on_clinic_id_and_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_visits_on_clinic_id_and_source_id ON public.visits USING btree (clinic_id, source_id);


--
-- Name: index_visits_on_clinic_id_and_starts_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_clinic_id_and_starts_at ON public.visits USING btree (clinic_id, starts_at);


--
-- Name: index_visits_on_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_contact_id ON public.visits USING btree (contact_id);


--
-- Name: appointments fk_rails_12044a3e25; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT fk_rails_12044a3e25 FOREIGN KEY (patient_id) REFERENCES pms.patients(id);


--
-- Name: patients fk_rails_6a0da623bd; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT fk_rails_6a0da623bd FOREIGN KEY (guarantor_id) REFERENCES pms.patients(id);


--
-- Name: appointments fk_rails_adda5689a7; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT fk_rails_adda5689a7 FOREIGN KEY (clinic_id) REFERENCES pms.clinics(id);


--
-- Name: activities fk_rails_192085de26; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT fk_rails_192085de26 FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: contacts fk_rails_1ce78c131f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT fk_rails_1ce78c131f FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: replies fk_rails_34fb8b0c1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT fk_rails_34fb8b0c1a FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: suppressions fk_rails_583ec89c5b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppressions
    ADD CONSTRAINT fk_rails_583ec89c5b FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: visits fk_rails_67f7d0e40e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_67f7d0e40e FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: replies fk_rails_86583a924c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT fk_rails_86583a924c FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: visits fk_rails_902d69750b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_902d69750b FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: messages fk_rails_ad35b6f034; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_ad35b6f034 FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO public, pms;

INSERT INTO "schema_migrations" (version) VALUES
('20261116000100');
