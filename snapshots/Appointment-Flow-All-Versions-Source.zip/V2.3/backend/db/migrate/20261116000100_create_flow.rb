class CreateFlow < ActiveRecord::Migration[8.1]
  def change
    create_schema :pms
    create_table "pms.clinics" do |t|
      t.text :name, null: false
      t.text :address_line, :city, :state, :phone
    end
    create_table "pms.patients" do |t|
      t.text :first_name, :last_name, null: false
      t.date :birthdate
      t.text :wireless_phone, :email, :preferred_language
      t.bigint :guarantor_id
    end
    add_foreign_key "pms.patients", "pms.patients", column: :guarantor_id
    create_table "pms.appointments" do |t|
      t.bigint :patient_id, :clinic_id, null: false
      t.text :provider_name, :procedure_note
      t.datetime :start_at, null: false
      t.integer :length_minutes
      t.text :status, null: false
      t.datetime :updated_at
    end
    add_foreign_key "pms.appointments", "pms.patients", column: :patient_id
    add_foreign_key "pms.appointments", "pms.clinics", column: :clinic_id
    add_index "pms.appointments", [ :clinic_id, :start_at ]
    create_table :clinics do |t|
      t.string :name, :zone, null: false
      t.datetime :synced_at
      t.string :sync_error
    end
    create_table :contacts do |t|
      t.references :clinic, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.jsonb :source, default: {}, null: false
      t.jsonb :corrections, default: {}, null: false
      t.boolean :sms_allowed, :email_allowed, default: false, null: false
    end
    add_index :contacts, [ :clinic_id, :source_id ], unique: true
    create_table :visits do |t|
      t.references :clinic, :contact, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.jsonb :source, default: {}, null: false
      t.datetime :starts_at
      t.string :revision, null: false
      t.string :confirmed_revision
      t.string :issue, :owner, :local_outcome
      t.boolean :active, default: true, null: false
    end
    add_index :visits, [ :clinic_id, :source_id ], unique: true
    add_index :visits, [ :clinic_id, :starts_at ]
    create_table :messages do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :revision, :step, :channel, :recipient, :status, null: false
      t.text :body, null: false
      t.datetime :created_at, null: false
    end
    add_index :messages, [ :visit_id, :revision, :step, :channel ], unique: true
    create_table :replies do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :message, null: false, foreign_key: true
      t.string :event_id, :result, null: false
      t.text :body, null: false
      t.datetime :created_at, null: false
    end
    add_index :replies, [ :clinic_id, :event_id ], unique: true
    create_table :suppressions do |t|
      t.references :clinic, null: false, foreign_key: true
      t.string :recipient, null: false
    end
    add_index :suppressions, [ :clinic_id, :recipient ], unique: true
    create_table :activities do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :staff, :action, null: false
      t.text :note, null: false
      t.datetime :created_at, null: false
    end
  end
end
