require "test_helper"

class ConfirmationTest < ActiveSupport::TestCase
  self.use_transactional_tests = false
  teardown do
    ActiveRecord::Base.connection.execute("TRUNCATE activities, replies, messages, visits, contacts, suppressions, clinics, pms.appointments, pms.patients, pms.clinics RESTART IDENTITY CASCADE")
  end
  setup do
    @clinic = Clinic.create!(id: 1, name: "Austin", zone: "America/Chicago")
    connection = ActiveRecord::Base.connection
    connection.execute("INSERT INTO pms.clinics (id,name) VALUES (1,'Austin')")
    connection.execute("INSERT INTO pms.patients (id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (1,'Fictional','Adult','1990-01-01','2025550101','adult@example.test','en')")
    connection.execute("INSERT INTO pms.appointments (id,patient_id,clinic_id,start_at,status) VALUES (1,1,1,'2026-11-22 15:00','scheduled')")
    @now = Time.utc(2026, 11, 15, 17)
    RefreshSource.new(@clinic).call
    @clinic.contacts.first.update!(sms_allowed: true, email_allowed: true)
  end

  test "S01 S06 repeated batches and replies confirm once" do
    assert_equal 1, RunReminders.new(@clinic, now: @now).call
    assert_equal 0, RunReminders.new(@clinic, now: @now).call
    message = Message.first
    reply = ProcessReply.new(@clinic).call(message_id: message.id, event_id: "one", body: "YES", now: @now)
    assert_equal "Confirmed", reply.result
    assert_equal reply, ProcessReply.new(@clinic).call(message_id: message.id, event_id: "one", body: "YES", now: @now)
    assert @clinic.visits.first.confirmed?
    assert_equal 0, RunReminders.new(@clinic, now: @now + 4.days).call
  end

  test "S03 reschedule rejects stale YES and clears confirmation" do
    RunReminders.new(@clinic, now: @now).call
    message = Message.first
    ActiveRecord::Base.connection.execute("UPDATE pms.appointments SET start_at='2026-11-23 15:00' WHERE id=1")
    assert_equal "Reply needs review", ProcessReply.new(@clinic).call(message_id: message.id, event_id: "late", body: "YES", now: @now).result
    assert_not @clinic.visits.first.confirmed?
  end

  test "S03 moving a visit away and back never reuses an old message revision" do
    RunReminders.new(@clinic, now: @now).call
    message = Message.first
    ActiveRecord::Base.connection.execute("UPDATE pms.appointments SET start_at='2026-11-23 15:00' WHERE id=1")
    RefreshSource.new(@clinic).call
    ActiveRecord::Base.connection.execute("UPDATE pms.appointments SET start_at='2026-11-22 15:00' WHERE id=1")
    RunReminders.new(@clinic, now: @now).call
    assert_equal 2, Message.count
    assert_not_equal message.revision, @clinic.visits.first.revision
    assert_equal "Reply needs review", ProcessReply.new(@clinic).call(message_id: message.id, event_id: "reverted", body: "YES", now: @now).result
  end

  test "S08 S09 late reply does not confirm and STOP survives import" do
    RunReminders.new(@clinic, now: @now).call
    message = Message.first
    ProcessReply.new(@clinic).call(message_id: message.id, event_id: "stop", body: "stop", now: @now)
    RefreshSource.new(@clinic).call
    assert_not @clinic.contacts.first.permitted?("sms")
    ProcessReply.new(@clinic).call(message_id: message.id, event_id: "late", body: "YES", now: @now + 8.days)
    assert_not @clinic.visits.first.confirmed?
  end

  test "S14 empty source preserves snapshots and blocks sends" do
    ActiveRecord::Base.connection.execute("DELETE FROM pms.appointments")
    assert_raises(RefreshSource::Unavailable) { RunReminders.new(@clinic, now: @now).call }
    assert_equal 1, @clinic.visits.count
    assert_equal 0, Message.count
    assert @clinic.reload.sync_error
  end

  test "S13 minor and missing birthdate block contact" do
    ActiveRecord::Base.connection.execute("UPDATE pms.patients SET birthdate=NULL")
    assert_equal 0, RunReminders.new(@clinic, now: @now).call
    assert_match "Verify birthdate", @clinic.visits.first.issue
  end

  test "S02 email fallback can confirm" do
    @clinic.contacts.first.update!(sms_allowed: false)
    RunReminders.new(@clinic, now: @now).call
    assert_equal "email", Message.first.channel
    assert_equal "Confirmed", ProcessReply.new(@clinic).call(message_id: Message.first.id, event_id: "email", body: "yes", now: @now).result
  end

  test "S15 clinic window and start boundary are enforced" do
    assert_equal 0, RunReminders.new(@clinic, now: @now - 4.hours).call
    assert_equal 0, RunReminders.new(@clinic, now: @now + 7.days + 4.hours).call
  end

  test "DST ambiguous and nonexistent wall times are held" do
    [ "2026-11-01 01:30", "2026-03-08 02:30" ].each do |wall|
      ActiveRecord::Base.connection.execute("UPDATE pms.appointments SET start_at='#{wall}'")
      RefreshSource.new(@clinic).call
      assert_nil @clinic.visits.first.starts_at
    end
  end

  test "PMS records reject writes" do
    assert_raises(ActiveRecord::ReadOnlyRecord) { Pms::Patient.first.update!(first_name: "Changed") }
  end

  test "S15 concurrent batches have one logical fake send" do
    threads = 2.times.map do
      Thread.new do
        ActiveRecord::Base.connection_pool.with_connection do
          RunReminders.new(Clinic.find(@clinic.id), now: @now).call
        end
      end
    end
    threads.each(&:value)
    assert_equal 1, Message.count
  end

  test "S05 fake SMS failure is recorded with one backup email" do
    ActiveRecord::Base.connection.execute("UPDATE pms.patients SET wireless_phone='2025550199'")
    2.times { RunReminders.new(@clinic, now: @now).call }
    assert_equal [ [ "email", "sent" ], [ "sms", "failed" ] ], Message.order(:channel).pluck(:channel, :status)
  end

  test "S12 shared contact never confirms either patient" do
    ActiveRecord::Base.connection.execute("INSERT INTO pms.patients (id,first_name,last_name,birthdate,wireless_phone,preferred_language) VALUES (2,'Fictional','Family','1990-01-01','2025550101','en')")
    ActiveRecord::Base.connection.execute("INSERT INTO pms.appointments (id,patient_id,clinic_id,start_at,status) VALUES (2,2,1,'2026-11-23 15:00','scheduled')")
    RunReminders.new(@clinic, now: @now).call
    result = ProcessReply.new(@clinic).call(message_id: Message.first.id, event_id: "family", body: "YES", now: @now)
    assert_equal "Reply needs review", result.result
    assert_not @clinic.visits.any?(&:confirmed?)
  end

  test "S07 NO after YES preserves confirmation for staff review" do
    RunReminders.new(@clinic, now: @now).call
    processor = ProcessReply.new(@clinic)
    processor.call(message_id: Message.first.id, event_id: "yes", body: "YES", now: @now)
    processor.call(message_id: Message.first.id, event_id: "no", body: "NO", now: @now)
    assert @clinic.visits.first.confirmed?
    assert_equal "Reply needs review", @clinic.visits.first.issue
  end

  test "staff workflow rolls back confirmation if activity write fails" do
    travel_to @now do
      ActiveRecord::Base.connection.execute("ALTER TABLE activities ADD CONSTRAINT reject_test_action CHECK (action <> 'confirmed')")
      assert_raises(ActiveRecord::StatementInvalid) do
        RecordFollowUp.new.call(clinic: @clinic, visit_id: @clinic.visits.first.id, staff: "Taylor Morgan", action: "confirmed", note: "Phone confirmation")
      end
      assert_not @clinic.visits.first.reload.confirmed?
      assert_equal 0, Activity.count
    ensure
      ActiveRecord::Base.connection.execute("ALTER TABLE activities DROP CONSTRAINT IF EXISTS reject_test_action")
    end
  end

  test "S04 broken source ends outreach and replacement starts unconfirmed" do
    RunReminders.new(@clinic, now: @now).call
    ActiveRecord::Base.connection.execute("UPDATE pms.appointments SET status='broken'")
    ActiveRecord::Base.connection.execute("INSERT INTO pms.appointments (id,patient_id,clinic_id,start_at,status) VALUES (2,1,1,'2026-11-22 16:00','scheduled')")
    RunReminders.new(@clinic, now: @now).call
    assert_not @clinic.visits.find_by(source_id: 1).scheduled?
    assert_not @clinic.visits.find_by(source_id: 2).confirmed?
    assert_equal 2, Message.count
  end

  test "reply confirmation rolls back if audit persistence fails" do
    RunReminders.new(@clinic, now: @now).call
    ActiveRecord::Base.connection.execute("ALTER TABLE replies ADD CONSTRAINT reject_test_reply CHECK (body <> 'YES')")
    assert_raises(ActiveRecord::StatementInvalid) do
      ProcessReply.new(@clinic).call(message_id: Message.first.id, event_id: "rollback", body: "YES", now: @now)
    end
    assert_not @clinic.visits.first.reload.confirmed?
    assert_equal 0, Reply.count
  ensure
    ActiveRecord::Base.connection.execute("ALTER TABLE replies DROP CONSTRAINT IF EXISTS reject_test_reply")
  end

  test "invalid contact and denied permissions cannot send" do
    ActiveRecord::Base.connection.execute("UPDATE pms.patients SET wireless_phone='not a phone', email='invalid'")
    assert_equal 0, RunReminders.new(@clinic, now: @now).call
    contact = @clinic.contacts.first
    contact.update!(corrections: { wireless_phone: "2025550101", email: "safe@example.test" }, sms_allowed: false, email_allowed: false)
    assert_equal 0, RunReminders.new(@clinic, now: @now).call
    contact.update!(email_allowed: true)
    assert_equal 1, RunReminders.new(@clinic, now: @now).call
  end

  test "changed verified source contact creates a persistent conflict" do
    contact = @clinic.contacts.first
    contact.update!(corrections: { wireless_phone: "2025550123" })
    ActiveRecord::Base.connection.execute("UPDATE pms.patients SET wireless_phone='2025550145'")
    assert_equal 0, RunReminders.new(@clinic, now: @now).call
    assert_match "Review changed", @clinic.visits.first.issue
    assert_equal 0, RunReminders.new(@clinic, now: @now).call
  end

  test "partial source loss preserves earlier snapshots" do
    ActiveRecord::Base.connection.execute("INSERT INTO pms.appointments (id,patient_id,clinic_id,start_at,status) VALUES (2,1,1,'2026-11-23 15:00','scheduled')")
    RefreshSource.new(@clinic).call
    ActiveRecord::Base.connection.execute("DELETE FROM pms.appointments WHERE id=2")
    assert_raises(RefreshSource::Unavailable) { RunReminders.new(@clinic, now: @now).call }
    assert_equal 2, @clinic.visits.count
    assert_equal 0, Message.count
  end
end
