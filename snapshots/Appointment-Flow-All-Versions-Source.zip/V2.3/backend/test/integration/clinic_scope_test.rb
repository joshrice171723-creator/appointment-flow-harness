require "test_helper"

class ClinicScopeTest < ActionDispatch::IntegrationTest
  setup do
    @austin = Clinic.create!(name: "Austin", zone: "America/Chicago")
    @phoenix = Clinic.create!(name: "Phoenix", zone: "America/Phoenix")
    @contact = @phoenix.contacts.create!(source_id: 1, source: { first_name: "Private", last_name: "Person", wireless_phone: "2025550101", email: "private@example.test" })
    @visit = @phoenix.visits.create!(contact: @contact, source_id: 1, source: { status: "complete" }, revision: "one", starts_at: Time.current)
    @headers = { "X-Demo-Staff" => "Taylor Morgan" }
  end

  test "S10 clinic routes cannot fetch another clinic record" do
    get "/api/clinics/#{@austin.id}/visits/#{@visit.id}", headers: @headers
    assert_response :not_found
    get "/api/clinics/#{@austin.id}/messages", params: { contact_id: @contact.id }
    assert_response :not_found
    get "/api/clinics/#{@austin.id}/visits", headers: @headers
    assert_response :success
    assert_equal [], response.parsed_body
  end

  test "staff identity is required for staff reads" do
    get "/api/clinics/#{@phoenix.id}/visits"
    assert_response :unprocessable_entity
  end

  test "invalid dates and foreign scoped writes are rejected" do
    get "/api/clinics/#{@austin.id}/visits", params: { date: "nonsense" }, headers: @headers
    assert_response :unprocessable_entity
    post "/api/clinics/#{@austin.id}/visits/#{@visit.id}/follow_up", params: { outcome: "confirmed", note: "Foreign visit" }, headers: @headers
    assert_response :not_found
    patch "/api/clinics/#{@austin.id}/contacts/#{@contact.id}", params: { corrections: { email: "other@example.test" } }, headers: @headers
    assert_response :not_found
    assert_equal 0, Activity.count
  end

  test "S16 S17 leadership returns aggregate fields only" do
    get "/api/leadership", params: { month: Date.current.strftime("%Y-%m") }
    assert_response :success
    rows = response.parsed_body
    assert_equal 1, rows.last["completed"]
    assert_equal 100.0, rows.last["completion_rate"]
    assert_equal %w[canceled clinic completed completion_rate confirmed messages open_issues recorded rescheduled unknown], rows.last.keys.sort
    assert_no_match(/Private|Person|2025550101|private@example.test|birthdate|procedure/, response.body)
  end
end
