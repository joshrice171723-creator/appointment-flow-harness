import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  timeout: 90000,
  use: {
    baseURL: "http://127.0.0.1:5196",
    browserName: "chromium",
    channel: "msedge",
    screenshot: "only-on-failure",
  },
  webServer: {
    command: "npm run dev -- --strictPort",
    url: "http://127.0.0.1:5196",
    reuseExistingServer: true,
    timeout: 90000,
  },
});
