import { test, expect } from "@playwright/test";
test("three workspaces use the local API and retain clinic boundaries", async ({
  page,
}) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Workspaces" })).toBeVisible();
  await page
    .getByRole("combobox", { name: "Clinic", exact: true })
    .selectOption("1");
  await page.getByRole("button", { name: "Open front desk" }).click();
  await expect(
    page.getByRole("heading", { name: "Patient flow" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Appointments", exact: true }).click();
  await expect(
    page.getByRole("columnheader", { name: "Patient", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Demo Patient 100", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("combobox", { name: "Clinic", exact: true })
    .selectOption("2");
  await expect(
    page.getByRole("heading", { name: "Patient flow" }),
  ).toBeVisible();
  await expect(page.getByText("Demo Patient 100", { exact: true })).toHaveCount(
    0,
  );
  await page.getByRole("button", { name: "Workspaces" }).click();
  await page.getByRole("button", { name: "Open Apex leadership" }).click();
  await expect(
    page.getByRole("heading", { name: "Appointment outcomes" }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Clinic comparison" }),
  ).toBeVisible();
  await expect(page.getByText(/Demo Patient/)).toHaveCount(0);
  await page.getByRole("button", { name: "Workspaces" }).click();
  await page.getByRole("button", { name: "Open patient workspace" }).click();
  await page
    .getByRole("combobox", { name: "Clinic", exact: true })
    .selectOption("1");
  await page
    .getByRole("combobox", { name: "Patient", exact: true })
    .selectOption({ label: "Demo Patient 100" });
  await expect(
    page.getByRole("heading", { name: "Message history" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Email", exact: true }).click();
  await expect(page.getByText(/No simulated emails/)).toBeVisible();
  await page
    .getByRole("combobox", { name: "Patient", exact: true })
    .selectOption({ label: "Demo Patient 101" });
  await page.getByRole("textbox", { name: "Your reply" }).fill("YES");
  await page.getByRole("button", { name: "Send simulated reply" }).click();
  await expect(page.getByRole("status")).toHaveText("Confirmed");
  await page.screenshot({
    path: "../review/patient-inbox-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole("button", { name: "Workspaces" }).click();
  await expect(page.getByRole("heading", { name: "Workspaces" })).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBeTruthy();
  await page.screenshot({
    path: "../review/workspaces-mobile.png",
    fullPage: true,
  });
});
