export type Clinic = {
  id: number;
  name: string;
  zone: string;
  synced_at: string | null;
  sync_error: string | null;
};
export type Visit = {
  id: number;
  contact_id: number;
  name: string;
  starts_at: string | null;
  wall_time: string;
  provider: string;
  confirmed: boolean;
  issue: string | null;
  owner: string | null;
  outcome: string;
  local_outcome: string | null;
  source_status: string;
  active: boolean;
};
export type Contact = {
  id: number;
  source: Record<string, string | null>;
  corrections: Record<string, string>;
  sms_allowed: boolean;
  email_allowed: boolean;
};
export type Activity = {
  id: number;
  staff: string;
  action: string;
  note: string;
  created_at: string;
};
export type Detail = Visit & { contact: Contact; activities: Activity[] };
export type Message = {
  id: number;
  channel: string;
  body: string;
  status: string;
  created_at: string;
  replies: { id: number; body: string; result: string }[];
};
export type Totals = {
  clinic: string;
  recorded: number;
  completed: number;
  canceled: number;
  rescheduled: number;
  unknown: number;
  completion_rate: number | null;
  messages: number;
  open_issues: number;
  confirmed: number;
};

export async function api<T>(
  path: string,
  staff: string,
  options: RequestInit = {},
): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`/api/${path}`, {
      ...options,
      headers: { "Content-Type": "application/json", "X-Demo-Staff": staff },
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError")
      throw error;
    throw new Error(
      options.method
        ? "Save outcome is uncertain. Refresh and inspect history before trying again. Your draft is retained."
        : "Could not connect. Check that the local API is running.",
      { cause: error },
    );
  }
  const data = await response.json();
  if (!response.ok)
    throw new Error(
      typeof data.error === "string"
        ? data.error
        : "Request failed. Refresh and review before trying again.",
    );
  return data as T;
}

export function time(value: string | null, zone: string) {
  return value
    ? new Intl.DateTimeFormat("en-US", {
        timeZone: zone,
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value))
    : "Time needs review";
}
