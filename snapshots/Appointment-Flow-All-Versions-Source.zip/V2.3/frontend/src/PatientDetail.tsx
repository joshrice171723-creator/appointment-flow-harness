import { useEffect, useState } from "react";
import { api, time } from "./api";
import type { Clinic, Detail } from "./api";

export default function PatientDetail({
  clinic,
  staff,
  id,
  back,
}: {
  clinic: Clinic;
  staff: string;
  id: number;
  back: () => void;
}) {
  const [detail, setDetail] = useState<Detail | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [note, setNote] = useState("");
  const [outcome, setOutcome] = useState("attempted");
  const [tab, setTab] = useState("Follow-up");
  const [fields, setFields] = useState<Record<string, string>>({});
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    api<Detail>(`clinics/${clinic.id}/visits/${id}`, staff, {
      signal: controller.signal,
    })
      .then(setDetail)
      .catch((e) => {
        if (!controller.signal.aborted) setError(e.message);
      });
    return () => controller.abort();
  }, [clinic.id, staff, id]);
  async function save(contact: boolean) {
    if (!detail) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await api(
        `clinics/${clinic.id}/${contact ? `contacts/${detail.contact.id}` : `visits/${id}/follow_up`}`,
        staff,
        {
          method: contact ? "PATCH" : "POST",
          body: JSON.stringify(
            contact ? { corrections: fields } : { outcome, note },
          ),
        },
      );
      setNotice("Saved.");
      setEditing(false);
      setDetail(await api<Detail>(`clinics/${clinic.id}/visits/${id}`, staff));
      if (!contact) setNote("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }
  if (!detail)
    return (
      <p role={error ? "alert" : "status"}>{error || "Loading patient…"}</p>
    );
  const facts = { ...detail.contact.source, ...detail.contact.corrections };
  return (
    <>
      <button onClick={back}>← Patient flow / {clinic.name}</button>
      <h1>{detail.name}</h1>
      <p>
        {detail.issue || (detail.confirmed ? "Confirmed" : "No open follow-up")}{" "}
        · {detail.owner || "Unassigned"}
      </p>
      <p>Next appointment: {time(detail.starts_at, clinic.zone)}</p>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {notice && <p role="status">{notice}</p>}
      <div className="patient-layout">
        <aside className="card">
          <h2>Patient details</h2>
          <p>Local corrections preserve the original PMS values.</p>
          {[
            ["birthdate", "Birthdate"],
            ["wireless_phone", "Mobile phone"],
            ["email", "Email"],
            ["preferred_language", "Preferred language"],
          ].map(([key, label]) => (
            <div className="fact" key={key}>
              <label>
                {label}
                {editing ? (
                  <input
                    type={key === "birthdate" ? "date" : "text"}
                    value={fields[key] ?? facts[key] ?? ""}
                    onChange={(e) =>
                      setFields({ ...fields, [key]: e.target.value })
                    }
                  />
                ) : (
                  <strong>{facts[key] || "No value on file"}</strong>
                )}
              </label>
              <small>
                {key in detail.contact.corrections
                  ? "Locally verified"
                  : "Not verified"}{" "}
                · PMS: {detail.contact.source[key] || "No value"}
              </small>
            </div>
          ))}
          {editing ? (
            <button disabled={busy} onClick={() => save(true)}>
              Save verified details
            </button>
          ) : (
            <button
              onClick={() => {
                setFields(
                  Object.fromEntries(
                    [
                      "birthdate",
                      "wireless_phone",
                      "email",
                      "preferred_language",
                    ].map((key) => [key, facts[key] || ""]),
                  ),
                );
                setEditing(true);
              }}
            >
              Verify / correct details
            </button>
          )}
        </aside>
        <div>
          <nav className="tabs">
            {["Follow-up", "Appointments", "Activity log"].map((t) => (
              <button
                aria-pressed={t === tab}
                key={t}
                onClick={() => setTab(t)}
              >
                {t}
              </button>
            ))}
          </nav>
          <section className="card">
            {tab === "Follow-up" ? (
              <>
                <h2>Record follow-up</h2>
                <p>
                  Schedule changes are made in the PMS. This form records the
                  staff outcome locally.
                </p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    void save(false);
                  }}
                >
                  <label>
                    Outcome
                    <select
                      value={outcome}
                      onChange={(e) => setOutcome(e.target.value)}
                    >
                      {[
                        ["assign", "Assign to me"],
                        ["attempted", "Contact attempted"],
                        ["confirmed", "Confirmed by staff"],
                        ["rescheduled", "Rescheduled in PMS"],
                        ["canceled", "Canceled in PMS"],
                      ].map(([value, label]) => (
                        <option value={value} key={value}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Follow-up note
                    <textarea
                      required
                      maxLength={2000}
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                    />
                  </label>
                  <button disabled={busy}>Save follow-up</button>
                </form>
              </>
            ) : tab === "Appointments" ? (
              <>
                <h2>Appointment</h2>
                <p>
                  {time(detail.starts_at, clinic.zone)} · {detail.provider}
                </p>
                <p>
                  Confirmation: {detail.confirmed ? "Confirmed" : "Unconfirmed"}
                </p>
                <p>PMS outcome: {detail.outcome}</p>
                <p>Local outcome: {detail.local_outcome || "None recorded"}</p>
              </>
            ) : (
              <>
                <h2>Activity log</h2>
                {detail.activities.length === 0 && (
                  <p>No staff activity recorded.</p>
                )}
                {detail.activities.map((a) => (
                  <article className="fact" key={a.id}>
                    <strong>
                      {a.action} · {a.staff}
                    </strong>
                    <p>{a.note}</p>
                    <small>{time(a.created_at, clinic.zone)}</small>
                  </article>
                ))}
              </>
            )}
          </section>
        </div>
      </div>
    </>
  );
}
