import { useEffect, useState } from "react";
import { api, time } from "./api";
import type { Clinic, Visit } from "./api";
import PatientDetail from "./PatientDetail";
import Inbox from "./Inbox";

type Props = { clinic: Clinic; staff: string; patient: boolean };
export default function Workspace({ clinic, staff, patient }: Props) {
  const [visits, setVisits] = useState<Visit[] | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [revision, setRevision] = useState(0);
  const [view, setView] = useState("board");
  const [selected, setSelected] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("active");
  const [date, setDate] = useState("");
  const [page, setPage] = useState(0);
  const [busy, setBusy] = useState(false);
  const [sync, setSync] = useState({
    synced_at: clinic.synced_at,
    sync_error: clinic.sync_error,
  });
  useEffect(() => {
    const controller = new AbortController();
    api<Visit[]>(`clinics/${clinic.id}/visits`, staff, {
      signal: controller.signal,
    })
      .then(setVisits)
      .catch((e) => {
        if (!controller.signal.aborted) setError(e.message);
      });
    return () => controller.abort();
  }, [clinic.id, staff, revision]);

  async function run(operation: string) {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const result = await api<{ attempts?: number; synced_at?: string }>(
        `clinics/${clinic.id}/${operation}`,
        staff,
        { method: "POST" },
      );
      const clinics = await api<Clinic[]>("clinics", staff);
      const current = clinics.find((c) => c.id === clinic.id);
      if (current)
        setSync({
          synced_at: current.synced_at,
          sync_error: current.sync_error,
        });
      setNotice(
        operation === "reminders"
          ? `${result.attempts} fake delivery attempts recorded. Outreach runs only from 10:00 to 18:00 clinic time.`
          : "PMS snapshot refreshed.",
      );
      setRevision((r) => r + 1);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }

  if (!visits)
    return (
      <p role={error ? "alert" : "status"}>
        {error || "Loading clinic records…"}
      </p>
    );
  if (patient) return <Inbox clinic={clinic} staff={staff} visits={visits} />;
  if (selected !== null)
    return (
      <PatientDetail
        key={selected}
        clinic={clinic}
        staff={staff}
        id={selected}
        back={() => {
          setSelected(null);
          setRevision((r) => r + 1);
        }}
      />
    );
  const attention = visits.filter(
    (v) => v.issue && !v.owner && !v.local_outcome,
  );
  const progress = visits.filter((v) => v.issue && v.owner && !v.local_outcome);
  const resolved = visits.filter((v) => v.confirmed || v.local_outcome);
  const matches = visits.filter(
    (v) =>
      v.name.toLowerCase().includes(query.toLowerCase()) &&
      (!date ||
        (v.starts_at &&
          new Intl.DateTimeFormat("en-CA", { timeZone: clinic.zone }).format(
            new Date(v.starts_at),
          ) === date)) &&
      (filter === "all" ||
        (filter === "active" && v.issue && !v.local_outcome) ||
        (filter === "resolved" && (v.confirmed || v.local_outcome)) ||
        (filter === "confirmed" && v.confirmed) ||
        (filter === "unconfirmed" && !v.confirmed) ||
        (filter === "review" && v.issue?.includes("review")) ||
        (filter === "blocked" &&
          v.issue &&
          /Verify|channel|language|verification/.test(v.issue))),
  );
  function changeFilter(value: string) {
    setFilter(value);
    setPage(0);
  }
  return (
    <>
      <div className="heading">
        <div>
          <p className="eyebrow">
            {clinic.name} · {clinic.zone}
          </p>
          <h1>{view === "board" ? "Patient flow" : "Appointments"}</h1>
          <p>Last PMS sync: {time(sync.synced_at, clinic.zone)}</p>
        </div>
        <div className="actions">
          <button
            onClick={() => {
              setView(view === "board" ? "table" : "board");
              changeFilter("all");
            }}
          >
            {view === "board" ? "Appointments" : "Patient flow"}
          </button>
          <button disabled={busy} onClick={() => run("refresh")}>
            Refresh PMS
          </button>
          <button disabled={busy} onClick={() => run("reminders")}>
            Run fake reminders
          </button>
        </div>
      </div>
      {(error || sync.sync_error) && (
        <p role="alert" className="error">
          {error || sync.sync_error}
        </p>
      )}
      {notice && (
        <p role="status" className="notice">
          {notice}
        </p>
      )}
      <div className="stats">
        {[
          ["Needs attention", attention.length],
          ["In progress", progress.length],
          ["Resolved", resolved.length],
        ].map(([label, count]) => (
          <section className="card" key={label}>
            <span>{label}</span>
            <strong>{count}</strong>
          </section>
        ))}
      </div>
      <div className="toolbar">
        <label>
          Find a patient
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(0);
            }}
          />
        </label>
        <label>
          Show
          <select value={filter} onChange={(e) => changeFilter(e.target.value)}>
            {[
              ["active", "Active work"],
              ["all", "All appointments"],
              ["resolved", "Resolved"],
              ["confirmed", "Confirmed"],
              ["unconfirmed", "Unconfirmed"],
              ["review", "Replies / times to review"],
              ["blocked", "Contact holds"],
            ].map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          Appointment date
          <input
            type="date"
            value={date}
            onChange={(e) => {
              setDate(e.target.value);
              setPage(0);
            }}
          />
        </label>
        <button
          onClick={() => {
            setDate("");
            setPage(0);
          }}
        >
          All dates
        </button>
      </div>
      {date && (
        <div className="toolbar">
          {[-7, -1, 1, 7].map((days) => (
            <button
              key={days}
              onClick={() => {
                const d = new Date(`${date}T12:00:00`);
                d.setDate(d.getDate() + days);
                setDate(
                  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`,
                );
                setPage(0);
              }}
            >
              {days > 0 ? "+" : ""}
              {days} days
            </button>
          ))}
        </div>
      )}
      {matches.length === 0 && (
        <section className="card">No appointments match these filters.</section>
      )}
      {view === "board" ? (
        <div className="board">
          {["Unassigned", "Assigned"].map((column, index) => (
            <section className="queue" key={column}>
              <h2>{column}</h2>
              {matches
                .slice(page * 10, page * 10 + 10)
                .filter((v) => Boolean(v.owner) === Boolean(index))
                .map((v) => (
                  <button
                    className="work-card"
                    key={v.id}
                    onClick={() => setSelected(v.id)}
                  >
                    <span className="pill">
                      {v.issue ||
                        (v.confirmed
                          ? "Confirmed"
                          : v.local_outcome || "Unconfirmed")}
                    </span>
                    <h3>{v.name}</h3>
                    <p>{time(v.starts_at, clinic.zone)}</p>
                    <small>{v.owner || "Unassigned"}</small>
                  </button>
                ))}
            </section>
          ))}
        </div>
      ) : (
        <section className="card table-wrap">
          <table>
            <thead>
              <tr>
                <th>Patient</th>
                <th>Appointment · {clinic.zone}</th>
                <th>Confirmation / reply</th>
                <th>PMS outcome</th>
                <th>Next step</th>
              </tr>
            </thead>
            <tbody>
              {matches.slice(page * 10, page * 10 + 10).map((v) => (
                <tr key={v.id}>
                  <td>{v.name}</td>
                  <td>
                    {time(v.starts_at, clinic.zone)}
                    <small>{v.provider}</small>
                  </td>
                  <td>
                    <span className="pill">
                      {v.confirmed ? "Confirmed" : "Unconfirmed"}
                    </span>
                    <small>{v.issue}</small>
                  </td>
                  <td>{v.outcome}</td>
                  <td>
                    <button onClick={() => setSelected(v.id)}>
                      Patient details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
      <div className="toolbar">
        <span>
          {matches.length} matching visits · Page {page + 1}
        </span>
        <button disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
          Previous
        </button>
        <button
          disabled={(page + 1) * 10 >= matches.length}
          onClick={() => setPage((p) => p + 1)}
        >
          Next
        </button>
      </div>
    </>
  );
}
