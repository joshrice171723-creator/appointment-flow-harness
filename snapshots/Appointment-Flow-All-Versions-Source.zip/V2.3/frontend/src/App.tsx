import { useEffect, useState } from "react";
import { api } from "./api";
import type { Clinic } from "./api";
import Workspace from "./Workspace";
import Leadership from "./Leadership";
import "./App.css";

export default function App() {
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [clinicId, setClinicId] = useState("");
  const [staff, setStaff] = useState("Taylor Morgan");
  const [workspace, setWorkspace] = useState("home");
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    api<Clinic[]>("clinics", "", { signal: controller.signal })
      .then(setClinics)
      .catch((e) => {
        if (!controller.signal.aborted) setError(e.message);
      });
    return () => controller.abort();
  }, []);
  const clinic = clinics.find((c) => String(c.id) === clinicId);
  const picker = (
    <label>
      Clinic
      <select value={clinicId} onChange={(e) => setClinicId(e.target.value)}>
        <option value="">Choose a clinic</option>
        {clinics.map((c) => (
          <option value={c.id} key={c.id}>
            {c.name}
          </option>
        ))}
      </select>
    </label>
  );
  return (
    <>
      <header>
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setWorkspace("home");
          }}
          className="brand"
        >
          <span className="brand-icon">A↗</span>
          <span>
            APEX<small>APPOINTMENT FLOW</small>
          </span>
        </a>
        <nav>
          <button onClick={() => setWorkspace("home")}>Workspaces ↗</button>
        </nav>
      </header>
      <main>
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        {workspace === "home" ? (
          <>
            <h1>Workspaces</h1>
            <div className="workspace-grid">
              <section className="card">
                <h2>Front desk</h2>
                <p>Review appointments and follow up with patients.</p>
                {picker}
                <label>
                  Staff member · demo sign-in
                  <select
                    value={staff}
                    onChange={(e) => setStaff(e.target.value)}
                  >
                    <option>Taylor Morgan</option>
                    <option>Jordan Lee</option>
                  </select>
                </label>
                <button
                  className="primary"
                  disabled={!clinic}
                  onClick={() => setWorkspace("staff")}
                >
                  Open front desk →
                </button>
              </section>
              <section className="card leadership-card">
                <h2>Apex leadership</h2>
                <p>Aggregate outcomes across {clinics.length} clinics.</p>
                <button
                  className="primary"
                  onClick={() => setWorkspace("leadership")}
                >
                  Open Apex leadership →
                </button>
              </section>
              <section className="card">
                <h2>Patient</h2>
                <p>
                  Inspect simulated texts and email, then send a fictional
                  reply.
                </p>
                <button
                  className="primary"
                  onClick={() => setWorkspace("patient")}
                >
                  Open patient workspace →
                </button>
              </section>
            </div>
          </>
        ) : workspace === "leadership" ? (
          <Leadership />
        ) : (
          <>
            <div className="toolbar">
              {picker}
              {workspace === "staff" && (
                <span>{staff} · Demo staff identity</span>
              )}
            </div>
            {clinic ? (
              <Workspace
                key={`${workspace}-${clinic.id}-${staff}`}
                clinic={clinic}
                staff={staff}
                patient={workspace === "patient"}
              />
            ) : (
              <p>Choose a clinic to continue.</p>
            )}
          </>
        )}
      </main>
    </>
  );
}
