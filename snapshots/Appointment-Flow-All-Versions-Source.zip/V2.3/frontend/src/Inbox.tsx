import { useEffect, useState } from "react";
import { api } from "./api";
import type { Clinic, Message, Visit } from "./api";

export default function Inbox({
  clinic,
  staff,
  visits,
}: {
  clinic: Clinic;
  staff: string;
  visits: Visit[];
}) {
  const patients = [...new Map(visits.map((v) => [v.contact_id, v])).values()];
  const [contact, setContact] = useState("");
  const [channel, setChannel] = useState("sms");
  const [messages, setMessages] = useState<Message[] | null>(null);
  const [error, setError] = useState("");
  const [body, setBody] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    if (!contact) return;
    const controller = new AbortController();
    api<Message[]>(
      `clinics/${clinic.id}/messages?contact_id=${contact}`,
      staff,
      { signal: controller.signal },
    )
      .then(setMessages)
      .catch((e) => {
        if (!controller.signal.aborted) setError(e.message);
      });
    return () => controller.abort();
  }, [clinic.id, contact, staff, revision]);
  const history = messages?.filter((m) => m.channel === channel);
  async function reply(message: Message) {
    setBusy(true);
    setError("");
    try {
      const result = await api<{ result: string }>(
        `clinics/${clinic.id}/replies`,
        staff,
        {
          method: "POST",
          body: JSON.stringify({
            message_id: message.id,
            event_id: crypto.randomUUID(),
            body,
          }),
        },
      );
      setNotice(result.result);
      setBody("");
      setRevision((r) => r + 1);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Reply failed");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="inbox">
      <h1>Patient inbox</h1>
      <p>Fictional patients · simulated messages only</p>
      <label>
        Patient
        <select
          value={contact}
          onChange={(e) => {
            setContact(e.target.value);
            setMessages(null);
            setBody("");
            setError("");
            setNotice("");
          }}
        >
          <option value="">Choose a patient</option>
          {patients.map((v) => (
            <option key={v.contact_id} value={v.contact_id}>
              {v.name}
            </option>
          ))}
        </select>
      </label>
      <nav className="tabs">
        {[
          ["sms", "Text messages"],
          ["email", "Email"],
        ].map(([value, label]) => (
          <button
            key={value}
            aria-pressed={channel === value}
            onClick={() => {
              setChannel(value);
              setBody("");
            }}
          >
            {label}
          </button>
        ))}
      </nav>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
      {notice && <p role="status">{notice}</p>}
      {contact &&
        (!history ? (
          <p>Loading messages…</p>
        ) : (
          <>
            <h2>Message history</h2>
            {history.length === 0 && (
              <p>
                No simulated {channel === "sms" ? "text messages" : "emails"}{" "}
                for this patient yet. Run reminders from Front desk during the
                clinic sending window.
              </p>
            )}
            {history.map((m) => (
              <article className="bubble" key={m.id}>
                <small>Clinic reminder · {m.status}</small>
                <p>{m.body}</p>
                {m.replies.map((r) => (
                  <blockquote key={r.id}>
                    <p>{r.body}</p>
                    <small>{r.result}</small>
                  </blockquote>
                ))}
              </article>
            ))}
            {history.length > 0 && (
              <form
                className="card"
                onSubmit={(e) => {
                  e.preventDefault();
                  void reply(history[history.length - 1]);
                }}
              >
                <label>
                  Your reply
                  <textarea
                    required
                    maxLength={2000}
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                  />
                </label>
                <p>
                  Reply to the most recent{" "}
                  {channel === "sms" ? "text message" : "email"}.
                </p>
                <button disabled={busy}>Send simulated reply</button>
              </form>
            )}
          </>
        ))}
    </div>
  );
}
