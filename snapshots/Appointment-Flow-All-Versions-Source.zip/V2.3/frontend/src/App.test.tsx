import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import App from "./App";
import PatientDetail from "./PatientDetail";
import Workspace from "./Workspace";
const clinic = {
  id: 1,
  name: "Austin",
  zone: "America/Chicago",
  synced_at: null,
  sync_error: null,
};
afterEach(() => vi.unstubAllGlobals());
describe("workspaces", () => {
  it("refresh advances sync time and clears a prior source error", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async (url: string) =>
          new Response(
            JSON.stringify(
              url === "/api/clinics"
                ? [
                    {
                      ...clinic,
                      synced_at: "2026-11-15T17:00:00Z",
                      sync_error: null,
                    },
                  ]
                : url.endsWith("/refresh")
                  ? { synced_at: "2026-11-15T17:00:00Z" }
                  : [],
            ),
          ),
      ),
    );
    render(
      <Workspace
        clinic={{ ...clinic, sync_error: "Prior source failure" }}
        staff="Taylor Morgan"
        patient={false}
      />,
    );
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Prior source failure",
    );
    fireEvent.click(screen.getByRole("button", { name: "Refresh PMS" }));
    await screen.findByText("PMS snapshot refreshed.");
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    expect(screen.getByText(/Last PMS sync:/)).toHaveTextContent("11:00 AM");
  });
  it("requires a clinic and shows only selected clinic records", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async (url: string) =>
          new Response(JSON.stringify(url === "/api/clinics" ? [clinic] : [])),
      ),
    );
    render(<App />);
    expect(
      screen.getByRole("button", { name: /Open front desk/ }),
    ).toBeDisabled();
    await screen.findByRole("option", { name: "Austin" });
    fireEvent.change(screen.getByLabelText("Clinic"), {
      target: { value: "1" },
    });
    fireEvent.click(screen.getByRole("button", { name: /Open front desk/ }));
    expect(
      await screen.findByText("No appointments match these filters."),
    ).toBeInTheDocument();
    expect(fetch).toHaveBeenCalledWith(
      "/api/clinics/1/visits",
      expect.anything(),
    );
  });
  it("S19 preserves the draft when follow-up validation fails", async () => {
    const detail = {
      id: 1,
      name: "Fictional Adult",
      contact: { id: 1, source: {}, corrections: {} },
      activities: [],
    };
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: string, options: RequestInit) =>
        options.method
          ? new Response(
              JSON.stringify({ error: "A short note is required" }),
              { status: 422 },
            )
          : new Response(JSON.stringify(detail)),
      ),
    );
    render(
      <PatientDetail
        clinic={clinic}
        staff="Taylor Morgan"
        id={1}
        back={() => {}}
      />,
    );
    await screen.findByText("Fictional Adult");
    fireEvent.change(screen.getByLabelText("Follow-up note"), {
      target: { value: "Keep this draft" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save follow-up" }));
    await waitFor(() =>
      expect(screen.getByRole("alert")).toHaveTextContent(
        "A short note is required",
      ),
    );
    expect(screen.getByLabelText("Follow-up note")).toHaveValue(
      "Keep this draft",
    );
  });
});
