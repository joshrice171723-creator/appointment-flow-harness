import { useEffect, useState } from "react";
import { api } from "./api";
import type { Totals } from "./api";

export default function Leadership() {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [rows, setRows] = useState<Totals[] | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    api<Totals[]>(`leadership?month=${month}`, "", {
      signal: controller.signal,
    })
      .then(setRows)
      .catch((e) => {
        if (!controller.signal.aborted) setError(e.message);
      });
    return () => controller.abort();
  }, [month]);
  return (
    <>
      <div className="heading">
        <h1>Appointment outcomes</h1>
        <label>
          Outcome month
          <input
            type="month"
            required
            value={month}
            onChange={(e) => {
              if (e.target.value) {
                setMonth(e.target.value);
                setRows(null);
              }
            }}
          />
        </label>
      </div>
      <p>
        Aggregate PMS outcomes. Completion means completed / recorded visits;
        these records do not establish no-shows or reminder impact.
      </p>
      {error && <p role="alert">{error}</p>}
      {!rows ? (
        <p>Loading outcomes…</p>
      ) : (
        <>
          <div className="stats">
            {rows.map((r) => (
              <section className="card" key={r.clinic}>
                <h2>{r.clinic}</h2>
                <p>{r.recorded} recorded visits</p>
                <meter
                  min={0}
                  max={100}
                  value={r.completion_rate ?? 0}
                  aria-label={`${r.clinic} completion rate`}
                />
                <strong>
                  {r.completion_rate === null
                    ? "No recorded visits"
                    : `${r.completion_rate}% completed`}
                </strong>
                <p>
                  {r.completed} completed · {r.rescheduled} rescheduled ·{" "}
                  {r.canceled} canceled · {r.unknown} unknown
                </p>
              </section>
            ))}
          </div>
          <section className="card table-wrap">
            <h2>Clinic comparison</h2>
            <table>
              <thead>
                <tr>
                  <th>Clinic</th>
                  <th>Recorded</th>
                  <th>Completed</th>
                  <th>Rescheduled</th>
                  <th>Canceled</th>
                  <th>Unknown</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.clinic}>
                    <th>{r.clinic}</th>
                    {[
                      r.recorded,
                      r.completed,
                      r.rescheduled,
                      r.canceled,
                      r.unknown,
                    ].map((n, i) => (
                      <td key={i}>{n}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
          <details className="card">
            <summary>Reminder activity and follow-up</summary>
            <p>
              Counts refer to visits in the selected appointment month; delivery
              attempts include failed fake deliveries.
            </p>
            {rows.map((r) => (
              <p key={r.clinic}>
                {r.clinic}: {r.messages} attempts · {r.confirmed} currently
                confirmed · {r.open_issues} open issues
              </p>
            ))}
          </details>
        </>
      )}
    </>
  );
}
