# Components and state flow

```mermaid
flowchart LR
  Fixtures[Explicit fictional seed writer] --> PMS[(PostgreSQL pms schema)]
  PMS -->|read-only models| Refresh[RefreshSource]
  Refresh --> Local[(App snapshots / verified corrections)]
  React[React workspaces] --> API[Rails scoped controllers]
  API --> Refresh
  API --> Batch[RunReminders]
  Batch --> Fake[FakeDelivery: database only]
  Fake --> Messages[(Messages and attempts)]
  React --> Reply[ProcessReply]
  Messages --> Reply
  Reply --> Local
  API --> Staff[RecordFollowUp + activity]
  Staff --> Local
  Local --> Aggregate[Leadership counts only]
  Aggregate --> React
```

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: scheduled source visit
  Unconfirmed --> ContactHold: unsafe contact or wall time
  ContactHold --> Unconfirmed: locally verified / next batch
  Unconfirmed --> Requested: permitted fake attempt
  Requested --> Confirmed: unique current future YES / staff confirmation
  Requested --> Review: stale / late / NO / ambiguous
  Confirmed --> Review: later conflicting intent
  Confirmed --> Unconfirmed: changed source version
  Review --> Confirmed: staff clarification of this visit
  Unconfirmed --> Ended: PMS completed / broken / unscheduled
  Confirmed --> Ended: PMS outcome
```

Clinic row locks serialize app writes; message/reply/suppression unique indexes enforce idempotency. Appointment revisions change on every observed source identity/time/status transition, including reversions. Confirmation applies only to that revision. Fake attempts and state changes commit together, without network side effects. Source refresh commits a complete snapshot independently before each write operation; failure preserves old records and records a pause. Staff and reply transactions include their audit writes. Raw PMS fields and local verified values remain separately inspectable.
