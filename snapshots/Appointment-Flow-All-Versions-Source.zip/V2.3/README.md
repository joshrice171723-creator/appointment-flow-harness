# Apex Appointment Flow

Independent Rails + React assessment rebuild. Fictional Austin and Phoenix records, local fake SMS/email, clinic-scoped staff tools and aggregate leadership reporting. No live messaging or external PMS connection.

## Run on Windows

Prerequisites: Ruby 3.4, Bundler, Node 24/npm, Docker Desktop and PostgreSQL 17 command-line tools (`C:\PostgreSQL\17\bin` on this machine). Microsoft Edge is used for browser tests. This build used Ruby 3.4.10, Rails 8.1.4.1, PostgreSQL 17.11, React 19.3.1, TypeScript 6.0.x and Vite 8.3.8; lockfiles pin exact dependencies.

From this directory:

```powershell
.\Start-Demo.ps1 -Setup
```

For later starts, use `.\Start-Demo.ps1`. Open http://127.0.0.1:5196 after the API starts. The script refuses occupied ports. Logs are in `tmp/`. Alternatively, start the existing `apex-rebuild-v23-db` container, run `ruby bin/rails server -b 127.0.0.1 -p 3026` in `backend`, and `npm.cmd run dev -- --strictPort` in `frontend`, in separate terminals. Stop those terminal processes with Ctrl+C. Only stop PIDs belonging to this new checkout. Database binds to localhost:5543; demo-only credentials are in database.yml. For a fresh machine, provision PostgreSQL locally or pull the documented image; no external account is required.

`ruby bin/rails db:prepare` creates/migrates databases and seeds a fresh database. `ruby bin/rails db:seed` explicitly replays fictional fixture setup on an existing demo; do not use it to model a live source refresh. Source fixture writes are confined to `db/demo_source.rb`; app request paths use read-only PMS models. Do not use database reset commands against any other project.

## Exercise the workflow

1. Select Austin and a demo staff identity, then open Front desk. Inspect work cards or Appointments, search/filter, select dates and open patient details. Follow-up requires a note. Local contact corrections keep inspectable original PMS values and an activity record.
2. Run fake reminders. Sending is allowed only 10:00–18:00 clinic time; the button reports attempt count. To demonstrate an explicit clock, run in `backend`:

```powershell
$env:NOW = '2026-11-15T17:00:00Z' # choose 11:00 Austin on your seeded date
ruby bin/rails demo:reminders
Remove-Item Env:NOW
```

Use your actual seeded date for a later run. Scheduled requests coalesce to the nearest 7/3/1-day stage, with email fallback and a day-6 backup when text remains unanswered. Confirmed visits receive no further requests. Repeated/concurrent runs use a clinic lock and unique logical message keys. Fake phone suffix 0199 produces a recorded failure and permitted backup email. Messages contain date, time, clinic and reply instructions, never procedure notes.

3. Open Patient workspace, choose the clinic and fictional patient, switch Text messages/Email and submit YES, NO, STOP or uncertain text. The most recent message in the selected channel supplies the simulated provider thread. History includes failed attempts and inbound results. Email-only patients demonstrate email confirmation. Refresh staff views after a patient reply.
4. YES confirms only a current, future, uniquely matched visit. Shared contacts, multiple pending visits, stale versions and late replies become staff review. NO after YES retains confirmation for staff clarification. Exact STOP suppresses future SMS by clinic/recipient and survives source reads. The demo assumes the provider verified the sender for the selected thread; this is not a production authenticated patient portal.
5. Leadership shows aggregate PMS outcomes for a month. Confirmation and completion are separate; counts do not prove no-shows or causal reminder impact.

## Checks and evidence

With the seeded API running on 3026:

```powershell
$env:PATH = 'C:\PostgreSQL\17\bin;' + $env:PATH
py -X utf8 quality/run_checks.py
```

The configured gate runs Rails tests, RuboCop, Brakeman, ESLint including Hooks rules, TypeScript, React component tests, production build and Edge browser smoke. The smoke runner starts Vite if needed. Rails tests use the isolated `apex_test` database; concurrency/rollback tests intentionally truncate only that database's tables. `review/quality-gate.log`, `review/INDEPENDENT_REVIEW.md` and `review/FREEZE_CHECKLIST.md` record actual evidence and gaps. Harness preflight was run before app code; its immutable input manifest is preserved, while requested working notes are intentionally edited after preflight.

## Boundaries and remaining candidate work

Staff identity is a local stub, not authorization for deployment: any caller can choose either clinic. Real use requires authenticated clinic membership, CSRF/session or token controls, least-privilege PMS database credentials, consent verification, encrypted/audited patient data access, retention policy and verified provider webhooks. The application has no live delivery adapter. Minors and unknown birthdates are held for staff; automatic guarantor outreach is deliberately excluded until authorization can be established.

Source reads retain complete clinic history and reconcile snapshots under a clinic lock. Existing rows are preloaded, and unchanged records are not rewritten; this remains a demo-sized synchronous import, with no 4,000/day load benchmark. Upstream five-minute replication lag remains possible. Missing/empty source rows pause outreach rather than deleting work. Ambiguous/nonexistent DST wall times are held; zones are explicitly Austin/Chicago and Phoenix. PMS source deletion requires investigation before refresh can resume. Historical snapshot reporting only covers records imported by this demo.

The UI includes date navigation and a table rather than a full week calendar grid; leadership provides monthly outcomes/activity rather than the full multi-month expanded screenshot tables. Human assignment clarifies individual visits; there is no bulk ambiguous-reply matching form. These are extended-workflow limits; core send/reply/staff behavior takes priority. No production infrastructure, booking or self-service rescheduling was added.

Joshua must author final `DECISIONS.md` in his own words and rehearse the defense. See `notes/CANDIDATE_DECISION_NOTES.md` for implementation tradeoffs. This is a local experiment; no push, PR or employer submission is performed.
