class RepliesController < ScopedController
  def create
    message = Message.joins(:visit).where(visits: { clinic_id: @setting.clinic_id }).find(params[:message_id])
    RefreshClinic.call(@setting)
    reply = ReceivePatientReply.call(@setting, message: message, body: params[:body], external_id: params[:external_id])
    render json: reply
  end
end
