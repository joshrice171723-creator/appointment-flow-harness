class ClinicsController < ApplicationController
  def index
    render json: ClinicSetting.includes(:clinic).map { |setting| { id: setting.clinic_id, name: setting.clinic.name, timezone: setting.timezone, synced_at: setting.synced_at, sync_error: setting.sync_error } }
  end
end
