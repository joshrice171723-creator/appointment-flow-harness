class LeadershipController < ApplicationController
  def index
    render json: LeadershipReport.call(params[:month].to_s)
  rescue Date::Error
    render json: { error: "Choose a valid reporting month" }, status: :unprocessable_entity
  end
end
