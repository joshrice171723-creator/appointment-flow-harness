class ContactsController < ScopedController
  def update
    contact = Contact.where(clinic_id: @setting.clinic_id).find(params[:id])
    values = params.require(:values).permit(*VerifyContact::FIELDS).to_h
    VerifyContact.call(@setting, contact: contact, values: values, staff: @staff)
    render json: { saved: true }
  end
end
