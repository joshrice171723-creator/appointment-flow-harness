class FollowUpsController < ScopedController
  def create
    visit = Visit.where(clinic_id: @setting.clinic_id).find(params[:visit_id])
    record = RecordFollowUp.call(@setting, visit: visit, staff: @staff, outcome: params[:outcome], note: params[:note], request_id: params[:request_id])
    render json: record
  end
end
