class RefreshesController < ScopedController
  def create
    RefreshClinic.call(@setting)
    render json: { synced_at: @setting.reload.synced_at }
  end
end
