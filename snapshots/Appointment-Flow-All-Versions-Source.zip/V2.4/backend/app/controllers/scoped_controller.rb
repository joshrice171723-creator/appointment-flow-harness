class ScopedController < ApplicationController
  before_action :set_scope
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "Record not found in this clinic" }, status: :not_found
  end
  rescue_from ArgumentError, ActiveRecord::RecordInvalid, RefreshClinic::Unavailable, ReminderBatch::UntrustedSource do |error|
    render json: { error: error.message }, status: :unprocessable_entity
  end

  private
  def set_scope
    @setting = ClinicSetting.find_by!(clinic_id: params[:clinic_id])
    @staff = request.headers["X-Demo-Staff"]
    unless %w[Taylor Jordan].include?(@staff)
      render json: { error: "Select a demo staff identity" }, status: :unauthorized
    end
  end

  def scoped_visit
    Visit.where(clinic_id: @setting.clinic_id).find(params[:id])
  end
end
