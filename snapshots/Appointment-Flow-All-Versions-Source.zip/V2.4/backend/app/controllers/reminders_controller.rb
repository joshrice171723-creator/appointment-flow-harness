class RemindersController < ScopedController
  def create
    RefreshClinic.call(@setting)
    count = ReminderBatch.call(@setting)
    render json: { processed: count }
  end
end
