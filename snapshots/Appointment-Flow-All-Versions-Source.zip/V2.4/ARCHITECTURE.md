# Components and state

```mermaid
flowchart LR
  PMS[(Read-only PMS tables)] --> Refresh[RefreshClinic]
  Refresh --> DB[(App snapshots and audit)]
  React[React workspaces] --> API[Rails resource controllers]
  API --> Refresh
  API --> Batch[ReminderBatch]
  API --> Reply[ReceivePatientReply]
  API --> Staff[RecordFollowUp / VerifyContact]
  Batch --> Transport[FakeTransport SMS and email interface]
  Transport --> Fake[Local fake Message rows]
  Reply --> DB
  Staff --> DB
  Fake --> DB
  DB --> Report[Aggregate leadership query]
```

ClinicSetting row locks serialize writes within a clinic. Refresh owns reconciliation transaction; batch owns send records; reply owns inbound event and confirmation; follow-up owns note and outcome. Failed refresh status is saved outside the rolled-back reconciliation. Unique constraints protect send step/revision and event/request IDs.

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: Source scheduled
  Unconfirmed --> Confirmed: Unambiguous current YES or staff confirmation
  Unconfirmed --> Review: Hold / NO / stale or ambiguous reply
  Confirmed --> Review: Conflicting later reply
  Review --> Confirmed: Staff clarification + note
  Confirmed --> Unconfirmed: Source time/status revision
  Unconfirmed --> Closed: Source completed/broken/unscheduled or staff disposition
```

Confirmation is independent of PMS completion. Staff dispositions suppress reminders locally while source changes are handled in the PMS. Models own their record rules, controllers own HTTP/clinic scope, named services own cross-record writes.
