# Apex Appointment Flow rebuild

Rails API, PostgreSQL and React/TypeScript. Fictional records and local fake messages only. Source inputs are the supplied assessment, sanitized requirements and screenshots.

## Local setup (Windows PowerShell)

Verified local runtimes: Ruby 3.4.10, Rails 8.1.4.1, Node 24.22.1, npm 11.19.1, PostgreSQL 17.11. Dependency lockfiles capture library versions. TypeScript 5.9 is selected for compatibility with typescript-eslint; the fresh scaffold's TypeScript 7 was incompatible.

PostgreSQL must be running. Defaults in backend/config/database.yml use localhost:5443 and the local postgres role; set PGHOST, PGPORT, PGUSER and PGPASSWORD for your installation. The local demonstration uses a development database and separate test database named apex_rebuild_240_development and apex_rebuild_240_test.

```powershell
cd backend
bundle install
bundle exec rails db:create db:migrate db:seed
$env:RAILS_ENV = 'test'
bundle exec rails db:migrate
Remove-Item Env:RAILS_ENV
cd ../frontend
# Clear this inherited JetBrains/npm setting only in this shell if present.
Remove-Item Env:npm_config_allow_scripts -ErrorAction SilentlyContinue
npm.cmd ci
cd ..
./Start-Demo.ps1
```

Open http://127.0.0.1:5173. The script runs Rails on 3100 and Vite on 5173; Ctrl+C stops both. Alternatively run Rails and Vite in separate terminals. Do not expose this auth-stub demo publicly.

## Reminders and replies

Select Austin or Phoenix and a demo staff member. Refresh PMS, then Run fake reminders. The sending window is 10:00–18:00 clinic-local time. Outside that window a batch produces zero attempts. For an explicit simulated daytime run:

```powershell
cd backend
# Choose today's date, 11 AM Austin (UTC offset varies with DST).
$env:NOW = '2026-11-16T11:00:00-06:00'
bundle exec rails demo:reminders
Remove-Item Env:NOW
```

Use the actual seed date for a useful run: seed visits are relative to the first seed invocation. Existing source records are preserved on later seeds. FAIL_SMS=1 simulates deterministic SMS failure; failed attempts remain visible and a later backup-email step can send.

Open Patient workspace, choose clinic and fictional patient, switch Text messages / Email and type YES, NO, STOP or other text. The reply references the latest message in that channel. Only an unambiguous, current, successfully sent message can confirm. No message means no reply submission. Contact holds, stale revisions, shared numbers and multiple upcoming visits require staff review. Use Front desk to assign work, record a required follow-up note, or verify local contact corrections. For ambiguous replies, staff clarify the appointment by phone and record confirmation separately for the appropriate visit.

Fake sends are persisted Message rows, not network calls. Patient activity and inbox expose the message body and fake attempt status. No PHI from procedure_note enters messages or leadership responses.

## Checks

```powershell
py quality/run_checks.py
cd frontend
npx.cmd playwright test
```

The configured gate runs Rails tests, Ruby style, Brakeman, React lint/types/tests/build. Browser smoke needs the local demo running and installed Google Chrome. See notes/BUILD_LOG.md and review/FREEZE_CHECKLIST.md for actual results.

For an exit-code-preserving log and whole-command timing, run `py quality/record_checks.py`. The final recorded gate passed all seven checks in 106.06 seconds. Browser smoke uses installed Google Chrome (`channel: chrome`); install Chrome if it is unavailable. Run browser smoke separately from the gate on memory-constrained machines. Production dependencies audited clean; seven moderate advisories remain in development lint tooling.

## Rules and boundaries

PMS clinics, patients and appointments retain the brief's columns. Source model instances reject writes; seed tooling represents the external writer. Runtime workflows write only app-owned tables. A production database role must additionally have SELECT-only privileges on PMS tables; the local development role is deliberately not a security boundary.

Refresh joins appointments and patients in one PostgreSQL statement, then reconciles app state under a clinic lock. Empty/failed refresh retains prior records and blocks reminders. Appointment identity reassignment fails closed for manual reconciliation. Same-ID time/status changes create a new revision and clear the old confirmation. All batch/reply/follow-up operations share the clinic lock; unique indexes enforce logical-send and event IDs. The fake send and attempt record commit atomically. A real vendor would require a provider idempotency contract and an outbox, which is outside this demo.

Cadence: initial at 7 local days, backup email at 4–6, follow-up at 2–3, final request at 0–1 (strictly before start). Only the current step is sent; missed earlier steps do not burst. Confirmed visits receive no more confirmation requests. Manual invocation is intentional; production scheduling would invoke this operation periodically. Appointment source may lag five minutes; no implementation can detect a change not yet replicated.

Austin uses America/Chicago; Phoenix America/Phoenix. start_at is wall-clock time; application instants are UTC. DST gaps/folds are held for review. Unsupported languages and missing age/unsafe minor contact are held. This version does not infer guarantor consent: minors require staff outreach. Synthetic adult channel permission is assumed by seed/default contact settings; STOP is durable per clinic/normalized phone. Verification records preserve raw source values and staff/time provenance.

Leadership reports source outcomes, not no-shows or causal improvement. Completed / recorded is an outcome rate; scheduled visits remain Unknown. Auth is a selectable staff stub, not production authorization. Production would require authenticated clinic membership, request authorization, protected audit data, secrets management, consent policy and retention controls.

No final DECISIONS.md has been authored by the agent. Joshua must write it; notes/CANDIDATE_DECISION_NOTES.md supplies factual tradeoffs. No employer submission or external publishing was performed.

## Demonstration limits

The source refresh currently reconciles all clinic history, and reply matching reads clinic contacts. This favors a straightforward complete local snapshot over incremental synchronization, but work grows with unrelated history under a clinic lock. The 60-clinic / 4,000-daily-visit context has not been load-tested. Before real operation, measure those queries, persist indexed normalized recipient keys, and adopt incremental refresh with explicit deletion/reconciliation semantics. The two-clinic synthetic demo is the verified target.

The extended patient picker opens one visit context per patient. Staff can clarify individual visits through appointment details, but a dedicated multi-appointment ambiguity-resolution form and guardian-consent editor are not implemented. Leadership currently supplies monthly outcomes and aggregate activity rather than historical trend charts. No candidate live-defense or human acceptance has been performed.
