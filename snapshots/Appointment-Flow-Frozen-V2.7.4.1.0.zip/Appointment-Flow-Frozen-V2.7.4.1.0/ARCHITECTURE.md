# Architecture

```mermaid
flowchart LR
  React["React workspaces"] --> Rails["Rails HTTP resources"]
  Rake["Reminder command"] --> Reminders["ReminderRun"]
  Rails --> Reminders
  Rails --> Replies["PatientReply"]
  Rails --> Staff["StaffFollowUp / VerifyPatientContact"]
  Reminders --> Policy["ContactPolicy"]
  Replies --> Policy
  Policy --> PMS[("PostgreSQL PMS replica")]
  Reminders --> PMS
  Replies --> PMS
  Staff --> PMS
  Rails --> PMS
  Reminders --> Fake["Fake transport result"]
  Fake --> Local[("Messages, visit decisions, opt-outs and follow-ups")]
  Replies --> Local
  Staff --> Local
  Local --> Rails
```

- The assessment tables are kept in `pms`. Migrations provision the replica, read-only guard, and indexed normalization projections. Seed and test fixtures explicitly enable replica writes within their own transaction. Declared Active Record relationships and hash predicates handle runtime reads.
- A reminder run owns one clinic transaction. It checks that the replica has clinic visits, examines current scheduled visits in pages of 200, and checks the current revision, local time, and contact directory before writing. Messages are the fake dispatch ledger. The transaction commits the attempts, follow-up changes and successful-sync timestamp together. The attempt uniqueness key is clinic, appointment, revision and step.
- A patient event owns a clinic transaction for its audit message, confirmation, SMS opt-out or review case. A supplied outbound ID belongs to the selected patient and channel. Automatic confirmation also requires its revision and recipient to match the current scheduled visit and contact policy. A clinic and event reference identify a replay.
- Staff saves own clinic transactions for current task state, visit updates, responsibility, and audit records. The client preserves the draft and same save reference after a rejected or uncertain request. Patient contact writes keep raw PMS values and local verification history separately.
- Date ranges and filters execute in PostgreSQL. Interactive lists have stable order and explicit limits. Leadership queries filter and aggregate at the database, and serialize clinic totals only.

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: Scheduled source revision
  Unconfirmed --> Confirmed: Eligible YES or documented staff confirmation
  Unconfirmed --> Review: NO, ambiguous, shared, late or stale reply
  Confirmed --> Review: Later reply requires review while confirmation remains
  Review --> Confirmed: Staff confirms a current linked visit
  Review --> Unconfirmed: Staff resolves case without changing the visit
  Unconfirmed --> OutreachStopped: Staff records cancel or reschedule
  Confirmed --> OutreachStopped: Staff records cancel or reschedule
  OutreachStopped --> Unconfirmed: PMS supplies a new scheduled revision
  Confirmed --> Unconfirmed: PMS supplies a new scheduled revision
```

Review and confirmation can coexist. Completion is read separately from the PMS. An SMS opt-out survives source edits and applies to the clinic's patient and normalized destination. PMS revision fingerprints conservatively include the source update timestamp, so a routine edit can require a new confirmation cycle. Source replication lag still determines how current the observed data can be.
