import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { chromium } from 'playwright-core';

const executablePath = process.env.BROWSER_PATH ?? [
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/chromium',
  '/usr/bin/google-chrome',
].find(existsSync);
if (!executablePath) throw new Error('Set BROWSER_PATH to an installed Chromium-family browser.');

const browser = await chromium.launch({ executablePath, headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto(process.env.DEMO_URL ?? 'http://127.0.0.1:4317/');
  await page.getByRole('heading', { name: 'Workspaces', exact: true }).waitFor();

  await page.getByRole('button', { name: 'Open patient workspace' }).click();
  await page.getByLabel('Clinic').selectOption({ label: 'Austin' });
  const patient = page.getByRole('combobox', { name: 'Patient', exact: true });
  await patient.selectOption({ label: 'Elena Vega' });
  await page.getByText('No simulated texts yet.').waitFor();
  await page.getByRole('button', { name: 'Email', exact: true }).click();
  await page.getByText(/Su cita en Austin/).first().waitFor();
  await page.getByLabel('Reply', { exact: true }).fill('YES');
  await page.getByRole('button', { name: 'Send reply' }).click();
  await page.getByRole('status').filter({ hasText: 'Appointment confirmed.' }).waitFor();
  await patient.selectOption({ label: 'Avery Lane' });
  await page.locator('article.outbound').getByText(/Your appointment at Austin/).first().waitFor();
  await page.getByLabel('Reply', { exact: true }).fill('YES');
  await page.getByRole('button', { name: 'Send reply' }).click();
  await page.getByRole('status').filter({ hasText: 'Appointment confirmed.' }).waitFor();
  await page.getByRole('button', { name: 'Workspaces' }).click();

  await page.getByRole('button', { name: 'Open front desk' }).click();
  await page.getByRole('heading', { name: 'Patient flow' }).waitFor();
  await page.getByLabel('Search patients').fill('Kim');
  await page.getByRole('button', { name: 'Jamie Kim', exact: true }).first().click();
  await page.getByRole('heading', { name: 'Jamie Kim' }).waitFor();
  await page.getByRole('button', { name: 'Verify birthdate' }).click();
  await page.getByLabel('Birthdate', { exact: true }).fill('1990-04-15');
  await page.getByRole('button', { name: 'Save verification' }).click();
  await page.getByText('Birthdate verified.').waitFor();

  await page.getByRole('button', { name: 'Appointments', exact: true }).first().click();
  const dateInput = page.getByLabel('Jump to date');
  const today = await dateInput.inputValue();
  const nextWeek = new Date(today + 'T12:00:00Z');
  nextWeek.setUTCDate(nextWeek.getUTCDate() + 7);
  await dateInput.fill(nextWeek.toISOString().slice(0, 10));
  const visit = page.getByRole('row', { name: /Elena Vega/ });
  await visit.getByText('Confirmed', { exact: true }).waitFor();
  await page.getByRole('button', { name: 'Workspaces' }).click();

  await page.getByLabel('Clinic').selectOption({ label: 'Phoenix, AZ' });
  await page.getByRole('button', { name: 'Open front desk' }).click();
  await page.getByText('Signed in as Alex Rivera').waitFor();
  await page.getByRole('button', { name: 'Workspaces' }).click();

  await page.getByRole('button', { name: 'Open Apex leadership' }).click();
  await page.getByRole('heading', { name: 'Clinic comparison' }).waitFor();
  await page.locator('summary').filter({ hasText: 'Monthly history and reminder activity' }).click();
  await page.getByRole('columnheader', { name: 'Simulated deliveries' }).waitFor();
  assert.equal(await page.getByText('Elena Vega').count(), 0);

  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: 'Workspaces' }).click();
  assert.equal(await page.locator('html').evaluate((root) => root.scrollWidth), 390);
  assert.deepEqual(errors, []);
  console.log('Browser smoke passed: SMS and email replies, staff verification, appointment state, clinic switch, reporting, and mobile width.');
} finally {
  await browser.close();
}
