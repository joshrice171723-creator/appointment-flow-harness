import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { proxy: { '/api': 'http://127.0.0.1:4317' } },
  build: { outDir: '../backend/public/demo', emptyOutDir: true },
  base: '/demo/',
});
