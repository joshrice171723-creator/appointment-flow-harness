import { type FormEvent, useState } from 'react';
import { type Contact, type Desk, type PatientDetail, type Task, type Visit, messageFrom, request, siteApi, useApi } from './api';
import { Feedback, issueLabels, localTimestamp, Pill, queueLabels, SyncStamp, Tabs, VisitTable, wallDate } from './ui';

const contactNames: Record<Contact['field'], string> = {
  birthdate: 'Birthdate', wireless_phone: 'Mobile phone', email: 'Email', preferred_language: 'Preferred language',
};

const outcomes = [
  { id: 'attempted', label: 'Contact attempted' }, { id: 'confirmed', label: 'Confirmed' },
  { id: 'rescheduled', label: 'Rescheduled' }, { id: 'canceled', label: 'Canceled' },
  { id: 'resolved', label: 'Resolved after review' },
];
type DetailTask = Task & { candidates: Visit[]; reply: string | null };

export function PatientDetails({ desk, id, initialTask, openBoard }: {
  desk: Desk;
  id: number;
  initialTask?: number;
  openBoard: () => void;
}) {
  const [tab, setTab] = useState<'follow_up' | 'appointments' | 'activity'>('follow_up');
  const [refresh, setRefresh] = useState(0);
  const [status, setStatus] = useState('');
  const [selectedTask, setSelectedTask] = useState(initialTask);
  const base = siteApi(desk.site.id);
  const path = base + '/patients/' + id;
  const detail = useApi<PatientDetail>(path, desk.staff.id, refresh);

  function saved(message: string) {
    setStatus(message);
    setRefresh((value) => value + 1);
  }

  if (detail.status === 'loading') return <main><p role="status">Loading patient details…</p></main>;
  if (detail.status === 'error') return <main><button onClick={openBoard}>← Patient flow</button><Feedback error={detail.error} />
    <button onClick={() => setRefresh((value) => value + 1)}>Retry</button></main>;

  const data = detail.data;
  const active = data.tasks.filter((task) => task.queue !== 'resolved');
  const resolved = data.tasks.filter((task) => task.queue === 'resolved');
  const visit = data.next_visit;
  return <main>
    <p className="eyebrow">{desk.site.name}</p>
    <h1>{data.patient.name}</h1>
    <SyncStamp metadata={data} />
    <button className="text-button back" onClick={openBoard}>← Patient flow</button>
    <section className="visit-banner">
      <div><h2>Next scheduled appointment</h2>
        <p>{visit ? wallDate(visit.start_at, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : 'No upcoming appointment recorded.'}
          {visit?.provider && ' · ' + visit.provider}</p></div>
      {visit && <Pill tone={visit.confirmation}>{visit.confirmation === 'confirmed' ? 'Confirmed' : 'Unconfirmed'}</Pill>}
    </section>
    <Feedback status={status} />
    <div className="patient-grid">
      <aside className="panel contact-card">
        <h2>Patient details</h2>
        {data.contacts.map((contact) => <ContactField key={contact.field} contact={contact}
          timezone={data.timezone} path={path} staff={desk.staff.id} onSave={saved} />)}
      </aside>
      <section className="patient-main">
        <Tabs tabs={[{ id: 'follow_up', name: 'Follow-up', count: active.length },
          { id: 'appointments', name: 'Appointments' }, { id: 'activity', name: 'Activity log' }]}
          selected={tab} choose={setTab} label="Patient record" />
        {tab === 'follow_up' && <div className="panel case-list">
          <h2>Follow-up items</h2>
          {active.length === 0 && <p className="empty">No open follow-ups.</p>}
          {active.map((task) => <article key={task.id} className="case">
            <button className="case-toggle" aria-expanded={selectedTask === task.id}
              onClick={() => setSelectedTask(selectedTask === task.id ? undefined : task.id)}>
              <span><Pill tone={task.issue}>{issueLabels[task.issue]}</Pill><strong>{task.reason}</strong></span>
              <small>{task.assignee || queueLabels[task.queue]}</small>
            </button>
            {selectedTask === task.id && <FollowUpForm task={task} path={base + '/follow_ups/' + task.id}
              staff={desk.staff.id} onSave={saved} />}
          </article>)}
          <details className="resolved-list"><summary>Resolved follow-ups ({resolved.length})</summary>
            {resolved.map((task) => <p key={task.id}><strong>{issueLabels[task.issue]}</strong><small>{task.reason}</small></p>)}
            {resolved.length === 0 && <p>No resolved follow-ups.</p>}
          </details>
        </div>}
        {tab === 'appointments' && <div className="panel"><VisitTable visits={data.visits} /></div>}
        {tab === 'activity' && <div className="panel case-list"><h2>Activity log</h2>
          {data.activity.length === 0 && <p className="empty">No staff activity recorded.</p>}
          {data.activity.map((event) => <article key={event.id} className="case">
            <strong>{event.note}</strong><small>{event.staff} · {localTimestamp(event.created_at, data.timezone)}</small>
          </article>)}
        </div>}
      </section>
    </div>
  </main>;
}

function ContactField({ contact, timezone, path, staff, onSave }: {
  contact: Contact;
  timezone: string;
  path: string;
  staff: number;
  onSave: (message: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(contact.verified_value ?? contact.value ?? '');
  const [key, setKey] = useState(() => crypto.randomUUID());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const label = contactNames[contact.field];

  async function save(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError('');
    try {
      await request(path + '/contact_verification', { method: 'PATCH', staff, body: { verification: {
        field: contact.field, value, expected_source: contact.source, event_key: key,
      } } });
      onSave(label + ' verified.');
    } catch (failure) {
      setError(messageFrom(failure));
    } finally {
      setSaving(false);
    }
  }

  const shownValue = contact.field === 'preferred_language' && contact.value === 'en' ? 'English'
    : contact.field === 'preferred_language' && contact.value === 'es' ? 'Spanish' : contact.value;

  return <div className="contact-field">
    <div className="contact-heading"><strong>{label}</strong>
      <button className="text-button" type="button" aria-expanded={editing} onClick={() => setEditing(!editing)}>
        {editing ? 'Close' : 'Verify'}<span className="sr-only"> {label.toLowerCase()}</span>
      </button>
    </div>
    <div>{shownValue || 'Unavailable'}</div>
    <Pill tone={contact.status}>{contact.status === 'conflict' ? 'PMS conflict' : contact.status === 'verified' ? 'Verified' : 'Unverified'}</Pill>
    {contact.status === 'conflict' && <small>Verified value: {contact.verified_value || 'Unavailable'}</small>}
    {contact.verified_by && contact.verified_at && <small>{contact.verified_by} · {localTimestamp(contact.verified_at, timezone)}</small>}
    {editing && <form onSubmit={save} className="form-stack">
      <label>{label}
        {contact.field === 'preferred_language' ? <select value={value} onChange={(event) => { setValue(event.target.value); setKey(crypto.randomUUID()); }}>
          <option value="">Choose a language</option><option value="en">English</option><option value="es">Spanish</option>
        </select> : <input value={value} type={contact.field === 'birthdate' ? 'date' : 'text'}
          onChange={(event) => { setValue(event.target.value); setKey(crypto.randomUUID()); }} />}
      </label>
      <small>PMS value: {contact.source || 'Unavailable'}</small>
      <Feedback error={error} />
      <button className="primary" disabled={saving}>{saving ? 'Saving…' : 'Save verification'}</button>
    </form>}
  </div>;
}

function FollowUpForm({ task, path, staff, onSave }: {
  task: DetailTask;
  path: string;
  staff: number;
  onSave: (message: string) => void;
}) {
  const [outcome, setOutcome] = useState('attempted');
  const [note, setNote] = useState('');
  const [selected, setSelected] = useState<number[]>(task.issue !== 'reply_review' && task.appointment_id ? [task.appointment_id] : []);
  const [key, setKey] = useState(() => crypto.randomUUID());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const changesVisit = ['confirmed', 'rescheduled', 'canceled'].includes(outcome);
  const assignedElsewhere = task.staff_id !== null && task.staff_id !== staff;

  async function save(event?: FormEvent) {
    event?.preventDefault();
    setSaving(true);
    setError('');
    try {
      if (!event) {
        await request(path, { method: 'PATCH', staff });
        onSave('Follow-up assigned to you.');
      } else {
        const visits = changesVisit ? task.candidates.filter((visit) => selected.includes(visit.id))
          .map(({ id, revision }) => ({ id, revision })) : [];
        await request(path + '/staff_actions', { method: 'POST', staff, body: { action_record: { outcome, note, event_key: key, visits } } });
        onSave('Follow-up recorded.');
      }
    } catch (failure) {
      setError(messageFrom(failure));
    } finally {
      setSaving(false);
    }
  }

  return <div className="follow-up-form">
    {task.reply && <blockquote>{task.reply}</blockquote>}
    <Feedback error={error} />
    {assignedElsewhere ? <p className="muted">Assigned to {task.assignee}.</p> : <>
      {task.staff_id === null && <button type="button" onClick={() => void save()} disabled={saving}>Assign to me</button>}
      <form onSubmit={save} className="form-stack">
        <label>Follow-up outcome<select value={outcome} onChange={(event) => { setOutcome(event.target.value); setKey(crypto.randomUUID()); }}>
          {outcomes.map(({ id, label }) => <option key={id} value={id}>{label}</option>)}
        </select></label>
        {task.candidates.length > 0 && (changesVisit || task.issue === 'reply_review') && <fieldset>
          <legend>Linked appointments</legend>
          {task.candidates.map((visit) => <label key={visit.id} className="check">
            {changesVisit && task.issue === 'reply_review' && <input type="checkbox" checked={selected.includes(visit.id)}
              onChange={(event) => {
                setSelected(event.target.checked ? [...selected, visit.id] : selected.filter((id) => id !== visit.id));
                setKey(crypto.randomUUID());
              }} />}
            {visit.patient} · {wallDate(visit.start_at, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
          </label>)}
        </fieldset>}
        <label>Note<textarea value={note} required maxLength={500} rows={3} placeholder="What did you learn or do?"
          onChange={(event) => { setNote(event.target.value); setKey(crypto.randomUUID()); }} /></label>
        <button className="primary" disabled={saving}>{saving ? 'Saving…' : 'Record follow-up'}</button>
      </form>
    </>}
  </div>;
}
