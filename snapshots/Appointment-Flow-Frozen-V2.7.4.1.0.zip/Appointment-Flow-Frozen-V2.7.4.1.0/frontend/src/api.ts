import { useEffect, useState } from 'react';

export interface Staff { id: number; name: string }
export interface Site { id: number; name: string; location: string; staff: Staff[] }
export interface Desk { site: Site; staff: Staff }
export interface SiteMetadata { today: string; timezone: string; last_synced_at: string | null }
export interface Visit {
  id: number;
  revision: string;
  patient_id: number;
  patient: string;
  start_at: string;
  provider: string | null;
  minutes: number | null;
  confirmation: string;
  reply_review: boolean;
  outcome: string;
}
export type Queue = 'needs_attention' | 'in_progress' | 'resolved';
export type Issue = 'no_reply' | 'contact_hold' | 'delivery_failed' | 'reply_review';
export interface Task {
  id: number;
  patient_id: number;
  patient: string;
  issue: Issue;
  reason: string;
  queue: Queue;
  staff_id: number | null;
  assignee: string | null;
  appointment_id: number | null;
  revision: string | null;
  created_at: string;
}
export interface Patient { id: number; name: string }
export interface Contact {
  field: 'birthdate' | 'wireless_phone' | 'email' | 'preferred_language';
  source: string | null;
  value: string | null;
  verified_value: string | null;
  status: 'unverified' | 'verified' | 'conflict';
  verified_by: string | null;
  verified_at: string | null;
}
export interface PatientDetail extends SiteMetadata {
  patient: Patient;
  contacts: Contact[];
  next_visit: Visit | null;
  visits: Visit[];
  tasks: (Task & { candidates: Visit[]; reply: string | null })[];
  activity: { id: number; action: string; note: string; staff: string; created_at: string }[];
}
export type Channel = 'sms' | 'email';
export interface Message {
  id: number;
  body: string;
  direction: 'outbound' | 'inbound';
  result: string;
  occurred_at: string;
  in_reply_to: number | null;
}

export const siteApi = (id: number) => '/api/sites/' + id;

interface RequestOptions {
  staff?: number;
  method?: 'POST' | 'PATCH';
  body?: object;
  signal?: AbortSignal;
}

export async function request<T>(path: string, { staff, method, body, signal }: RequestOptions = {}): Promise<T> {
  const headers = new Headers({ Accept: 'application/json' });
  if (staff !== undefined) headers.set('X-Demo-Staff', String(staff));
  if (body) headers.set('Content-Type', 'application/json');
  const response = await fetch(path, { method, headers, body: body && JSON.stringify(body), signal });
  if (!response.ok) {
    const payload: unknown = await response.json().catch(() => null);
    const error = payload && typeof payload === 'object' && 'error' in payload ? payload.error : null;
    throw new Error(typeof error === 'string' ? error : 'The request failed. Try again.');
  }
  return response.json() as Promise<T>;
}

type RequestState<T> =
  | { status: 'loading' }
  | { status: 'ready'; data: T }
  | { status: 'error'; error: string };

export function useApi<T>(path: string, staff?: number, refresh = 0): RequestState<T> {
  const key = JSON.stringify([path, staff, refresh]);
  const [current, setCurrent] = useState<{ key: string; state: RequestState<T> }>();

  useEffect(() => {
    const controller = new AbortController();
    request<T>(path, { staff, signal: controller.signal }).then(
      (data) => { if (!controller.signal.aborted) setCurrent({ key, state: { status: 'ready', data } }); },
      (error: unknown) => {
        if (!controller.signal.aborted) setCurrent({ key, state: { status: 'error', error: messageFrom(error) } });
      },
    );
    return () => controller.abort();
  }, [path, staff, key]);

  return current?.key === key ? current.state : { status: 'loading' };
}

export function messageFrom(error: unknown) {
  return error instanceof Error && !(error instanceof TypeError)
    ? error.message
    : 'The connection was interrupted. Check the result or retry this same save.';
}
