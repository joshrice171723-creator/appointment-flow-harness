import { StrictMode, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { type Desk, type Site, useApi } from './api';
import { Board, Appointments } from './desk';
import { PatientDetails } from './patient-details';
import { Inbox } from './inbox';
import { Leadership } from './leadership';
import { Feedback } from './ui';
import '@fontsource-variable/inter';
import '@fontsource/dm-serif-text';
import './styles.css';

type Screen =
  | { name: 'workspaces' | 'leadership' | 'inbox' }
  | { name: 'board' | 'appointments'; desk: Desk }
  | { name: 'patient'; desk: Desk; id: number; task?: number };

function Workspaces({ sites, open }: { sites: Site[]; open: (screen: Screen) => void }) {
  const [selected, setSelected] = useState<number>();
  const [staffId, setStaffId] = useState<number>();
  const site = sites.find((entry) => entry.id === selected) ?? sites[0];
  const staff = site?.staff.find((entry) => entry.id === staffId) ?? site?.staff[0];

  return <main className="workspace-page">
    <h1>Workspaces</h1>
    <div className="workspace-grid">
      <section className="workspace-card">
        <h2>Front desk</h2>
        <p>Review appointments and follow up with patients.</p>
        <label>Clinic <select value={site?.id ?? ''} onChange={(event) => { setSelected(Number(event.target.value)); setStaffId(undefined); }}>
          {!site && <option value="">No clinics available</option>}
          {sites.map((entry) => <option value={entry.id} key={entry.id}>{entry.location || entry.name}</option>)}
        </select></label>
        <label>Staff member <select value={staff?.id ?? ''} onChange={(event) => setStaffId(Number(event.target.value))}>
          {!staff && <option value="">No staff available</option>}
          {site?.staff.map((entry) => <option value={entry.id} key={entry.id}>{entry.name}</option>)}
        </select></label>
        <button className="primary card-action" disabled={!site || !staff} onClick={() => site && staff && open({ name: 'board', desk: { site, staff } })}>
          Open front desk <span aria-hidden="true">→</span>
        </button>
      </section>
      <section className="workspace-card leadership-card">
        <h2>Apex leadership</h2>
        <p>Compare appointment outcomes across clinics.</p>
        <div className="clinic-count"><strong>{sites.length}</strong><span>{sites.length === 1 ? 'Clinic' : 'Clinics'}</span></div>
        <button className="primary card-action" onClick={() => open({ name: 'leadership' })}>
          Open Apex leadership <span aria-hidden="true">→</span>
        </button>
      </section>
      <section className="workspace-card">
        <h2>Patient</h2>
        <p>View fictional patient messages and simulate replies.</p>
        <button className="primary card-action" onClick={() => open({ name: 'inbox' })}>
          Open patient workspace <span aria-hidden="true">→</span>
        </button>
      </section>
    </div>
  </main>;
}

function App() {
  const [screen, setScreen] = useState<Screen>({ name: 'workspaces' });
  const [refresh, setRefresh] = useState(0);
  const directory = useApi<{ sites: Site[] }>('/api/workspaces', undefined, refresh);
  const desk = 'desk' in screen ? screen.desk : undefined;
  function open(next: Screen) {
    setScreen(next);
    window.scrollTo(0, 0);
  }

  return <>
    <header className="topbar">
      <button className="brand" type="button" onClick={() => open({ name: 'workspaces' })}>
        <span className="brand-mark" aria-hidden="true">A<span>✦</span></span>
        <span><strong>APEX</strong><small>APPOINTMENT FLOW</small></span>
      </button>
      <nav aria-label="Workspace">
        {desk && <>
          <button aria-current={screen.name === 'board' ? 'page' : undefined} onClick={() => open({ name: 'board', desk })}>Patient flow</button>
          <button aria-current={screen.name === 'appointments' ? 'page' : undefined} onClick={() => open({ name: 'appointments', desk })}>Appointments</button>
        </>}
        {screen.name === 'leadership' && <span className="nav-current">Apex leadership</span>}
        {screen.name === 'inbox' && <span className="nav-current">Patient demo</span>}
        <button onClick={() => open({ name: 'workspaces' })}>Workspaces <span aria-hidden="true">↗</span></button>
      </nav>
    </header>
    {directory.status === 'loading' && <main><p role="status">Loading workspaces…</p></main>}
    {directory.status === 'error' && <main><Feedback error={directory.error} /><button onClick={() => setRefresh(refresh + 1)}>Retry</button></main>}
    {directory.status === 'ready' && <>
      {screen.name === 'workspaces' && <Workspaces sites={directory.data.sites} open={open} />}
      {screen.name === 'leadership' && <Leadership />}
      {screen.name === 'inbox' && <Inbox sites={directory.data.sites} />}
      {screen.name === 'board' && <Board key={screen.desk.site.id} desk={screen.desk}
        openPatient={(id, task) => open({ name: 'patient', desk: screen.desk, id, task })}
        openAppointments={() => open({ name: 'appointments', desk: screen.desk })} />}
      {screen.name === 'appointments' && <Appointments key={screen.desk.site.id} desk={screen.desk}
        openPatient={(id) => open({ name: 'patient', desk: screen.desk, id })}
        openBoard={() => open({ name: 'board', desk: screen.desk })} />}
      {screen.name === 'patient' && <PatientDetails key={screen.id} desk={screen.desk} id={screen.id} initialTask={screen.task}
        openBoard={() => open({ name: 'board', desk: screen.desk })} />}
    </>}
  </>;
}

const element = document.getElementById('root');
if (element) createRoot(element).render(<StrictMode><App /></StrictMode>);
