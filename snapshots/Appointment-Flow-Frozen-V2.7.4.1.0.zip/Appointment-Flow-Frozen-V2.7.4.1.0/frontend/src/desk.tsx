import { useState } from 'react';
import { type Desk, type Issue, type Queue, type SiteMetadata, type Task, type Visit, messageFrom, request, siteApi, useApi } from './api';
import { addDays, Feedback, issueLabels, localTimestamp, Pager, Pill, queueLabels, SyncStamp, Tabs, VisitTable, wallDate, weekOf } from './ui';

type BoardFilter = 'active' | 'resolved' | 'all';
interface BoardData extends SiteMetadata {
  totals: Partial<Record<Queue, number>>;
  rows: Task[];
  page: number;
  more: boolean;
}

export function Board({ desk, openPatient, openAppointments }: {
  desk: Desk;
  openPatient: (patientId: number, taskId: number) => void;
  openAppointments: () => void;
}) {
  const [queue, setQueue] = useState<BoardFilter>('active');
  const [issue, setIssue] = useState<Issue | ''>('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [refresh, setRefresh] = useState(0);
  const [running, setRunning] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const base = siteApi(desk.site.id);
  const query = new URLSearchParams({ queue, issue, q: search.trim(), page: String(page) });
  const board = useApi<BoardData>(base + '/follow_ups?' + query, desk.staff.id, refresh);

  async function runReminders() {
    setRunning(true);
    setError('');
    setStatus('');
    try {
      const result = await request<{ delivered: number; failed: number; follow_ups_created: number }>(
        base + '/reminder_runs', { staff: desk.staff.id, method: 'POST' },
      );
      setStatus('Reminder run complete. Simulated deliveries: ' + result.delivered
        + ' · failed: ' + result.failed + ' · new follow-ups: ' + result.follow_ups_created + '.');
      setRefresh((value) => value + 1);
    } catch (failure) {
      setError(messageFrom(failure));
    } finally {
      setRunning(false);
    }
  }

  const totals = board.status === 'ready' ? board.data.totals : {};
  const queues: Queue[] = queue === 'active' ? ['needs_attention', 'in_progress']
    : queue === 'resolved' ? ['resolved'] : ['needs_attention', 'in_progress', 'resolved'];

  return <main>
    <div className="heading-row">
      <div><p className="eyebrow">{desk.site.name}</p><h1>Patient flow</h1>
        <p className="muted">Review patient replies and appointments that need follow-up.</p>
        {board.status === 'ready' && <SyncStamp metadata={board.data} />}
      </div>
      <div className="heading-actions">
        <small>Signed in as {desk.staff.name}</small>
        <div className="inline-actions">
          <button type="button" onClick={runReminders} disabled={running}>{running ? 'Running…' : 'Run reminders'}</button>
          <button type="button" className="primary" onClick={openAppointments}>Open appointments <span aria-hidden="true">→</span></button>
        </div>
      </div>
    </div>
    <Feedback error={error} status={status} />
    <div className="summary-grid">
      {Object.entries(queueLabels).map(([key, label]) => <div className="panel summary" key={key}>
        <span>{label}</span><strong>{board.status === 'ready' ? (totals[key as Queue] ?? 0) : '—'}</strong>
      </div>)}
    </div>
    <div className="filter-bar">
      <Tabs tabs={[{ id: 'active', name: 'Active' }, { id: 'resolved', name: 'Resolved' }, { id: 'all', name: 'All follow-ups' }]}
        selected={queue} label="Follow-up queue" choose={(id) => { setQueue(id); setPage(1); }} />
      <div className="filter-fields">
        <label>Search patients<input type="search" placeholder="First or last name" value={search}
          onChange={(event) => { setSearch(event.target.value); setPage(1); }} /></label>
        <label>Issue type<select value={issue} onChange={(event) => { setIssue(event.target.value as Issue | ''); setPage(1); }}>
          <option value="">All issues</option>
          {Object.entries(issueLabels).map(([id, label]) => <option key={id} value={id}>{label}</option>)}
        </select></label>
      </div>
    </div>
    {board.status === 'loading' && <p role="status" className="empty">Loading follow-ups…</p>}
    {board.status === 'error' && <><Feedback error={board.error} /><button onClick={() => setRefresh((value) => value + 1)}>Retry</button></>}
    {board.status === 'ready' && <>
      <div className="board-grid" data-columns={queues.length}>
        {queues.map((column) => {
          const rows = board.data.rows.filter((task) => task.queue === column);
          return <section key={column} className={'queue ' + column}>
            <div className="queue-heading"><h2>{queueLabels[column]}</h2><span>{totals[column] ?? 0}</span></div>
            {rows.length === 0 && <p className="empty">No matching follow-ups.</p>}
            {rows.map((task) => <article className="task-card" key={task.id}>
              <Pill tone={task.issue}>{issueLabels[task.issue]}</Pill>
              <h3><button className="text-button" onClick={() => openPatient(task.patient_id, task.id)}>{task.patient}</button></h3>
              <p>{task.reason}</p>
              <small>{task.assignee || 'Unassigned'} · {localTimestamp(task.created_at, board.data.timezone)}</small>
            </article>)}
          </section>;
        })}
      </div>
      <Pager page={board.data.page} more={board.data.more} choose={setPage} />
    </>}
  </main>;
}

type VisitFilter = 'all' | 'confirmed' | 'unconfirmed' | 'review';
interface AppointmentsData extends SiteMetadata {
  date: string;
  calendar: Record<string, number>;
  totals: Record<VisitFilter, number>;
  rows: Visit[];
  page: number;
  more: boolean;
}
const visitFilters: { id: VisitFilter; name: string }[] = [
  { id: 'all', name: 'All appointments' }, { id: 'confirmed', name: 'Confirmed' },
  { id: 'unconfirmed', name: 'Unconfirmed' }, { id: 'review', name: 'Replies to review' },
];

export function Appointments({ desk, openPatient, openBoard }: {
  desk: Desk;
  openPatient: (id: number) => void;
  openBoard: () => void;
}) {
  const [date, setDate] = useState('');
  const [filter, setFilter] = useState<VisitFilter>('all');
  const [page, setPage] = useState(1);
  const [refresh, setRefresh] = useState(0);
  const query = new URLSearchParams({ date, filter, page: String(page) });
  const visits = useApi<AppointmentsData>(siteApi(desk.site.id) + '/appointments?' + query, desk.staff.id, refresh);

  function chooseDate(value: string) {
    setDate(value);
    setPage(1);
  }

  return <main>
    <div className="heading-row"><div><p className="eyebrow">{desk.site.name}</p><h1>Appointments</h1>
      <p className="muted">See each visit’s confirmation state and PMS outcome.</p>
      {visits.status === 'ready' && <SyncStamp metadata={visits.data} />}
    </div><button onClick={openBoard}>Open patient flow <span aria-hidden="true">→</span></button></div>
    {visits.status === 'loading' && <p className="empty" role="status">Loading appointments…</p>}
    {visits.status === 'error' && <><Feedback error={visits.error} /><button onClick={() => setRefresh((value) => value + 1)}>Retry</button></>}
    {visits.status === 'ready' && <>
      <div className="panel calendar">
        <div className="inline-actions calendar-controls">
          <button onClick={() => chooseDate(addDays(visits.data.date, -7))}>← Previous week</button>
          <button onClick={() => chooseDate(visits.data.today)}>Today</button>
          <button onClick={() => chooseDate(addDays(visits.data.date, 7))}>Next week →</button>
          <label>Jump to date<input type="date" value={visits.data.date}
            onChange={(event) => { if (event.target.value) chooseDate(event.target.value); }} /></label>
        </div>
        <div className="week">
          {weekOf(visits.data.date).map((day) => <button key={day} aria-pressed={day === visits.data.date} onClick={() => chooseDate(day)}>
            <strong>{wallDate(day, { weekday: 'short', month: 'short', day: 'numeric' })}</strong>
            <small>{visits.data.calendar[day] ?? 0} visits</small>
          </button>)}
        </div>
      </div>
      <Tabs tabs={visitFilters.map((item) => ({ ...item, count: visits.data.totals[item.id] }))} selected={filter}
        choose={(value) => { setFilter(value); setPage(1); }} label="Confirmation status" />
      <div className="panel"><VisitTable visits={visits.data.rows} open={openPatient} /></div>
      <Pager page={visits.data.page} more={visits.data.more} choose={setPage} />
    </>}
  </main>;
}
