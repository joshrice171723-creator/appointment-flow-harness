import { type FormEvent, useState } from 'react';
import { type Channel, type Message, type Patient, type Site, messageFrom, request, siteApi, useApi } from './api';
import { Feedback, localTimestamp, Pager, Pill, Tabs, titleCase } from './ui';

const channels: { id: Channel; name: string }[] = [
  { id: 'sms', name: 'Text messages' }, { id: 'email', name: 'Email' },
];

export function Inbox({ sites }: { sites: Site[] }) {
  const [siteId, setSiteId] = useState<number>();
  return <main className="inbox-page">
    <h1>Patient inbox</h1>
    <p className="muted">Simulated messages for fictional patients.</p>
    <label>Clinic<select value={siteId ?? ''} onChange={(event) => setSiteId(Number(event.target.value) || undefined)}>
      <option value="">Choose a clinic</option>
      {sites.map((site) => <option value={site.id} key={site.id}>{site.name}</option>)}
    </select></label>
    {siteId && <PatientPicker key={siteId} siteId={siteId} />}
  </main>;
}

function PatientPicker({ siteId }: { siteId: number }) {
  const [patient, setPatient] = useState<Patient>();
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const base = siteApi(siteId) + '/inboxes';
  const patients = useApi<{ patients: Patient[]; page: number; more: boolean }>(
    base + '?' + new URLSearchParams({ q: query.trim(), page: String(page) }),
  );
  const rows = patients.status === 'ready' ? patients.data.patients : [];
  const options = patient && !rows.some((entry) => entry.id === patient.id) ? [patient, ...rows] : rows;
  return <>
    <label>Search by name<input type="search" value={query} onChange={(event) => { setQuery(event.target.value); setPage(1); }} /></label>
    <label>Patient<select value={patient?.id ?? ''} disabled={patients.status === 'loading'}
      onChange={(event) => setPatient(options.find((entry) => entry.id === Number(event.target.value)))}>
      <option value="">{patients.status === 'ready' && rows.length === 0 ? 'No matching patients' : 'Choose a patient'}</option>
      {options.map((entry) => <option value={entry.id} key={entry.id}>{entry.name}</option>)}
    </select></label>
    {patients.status === 'error' && <Feedback error={patients.error} />}
    {patients.status === 'ready' && <Pager page={patients.data.page} more={patients.data.more} choose={setPage} />}
    {patient && <PatientConversation key={patient.id} path={base + '/' + patient.id} />}
  </>;
}

function PatientConversation({ path }: { path: string }) {
  const [channel, setChannel] = useState<Channel>('sms');
  return <>
    <Tabs tabs={channels} selected={channel} choose={setChannel} label="Message channel" />
    <Conversation key={channel} path={path} channel={channel} />
  </>;
}

interface History { messages: Message[]; timezone: string; page: number; more: boolean }
function Conversation({ path, channel }: { path: string; channel: Channel }) {
  const [page, setPage] = useState(1);
  const [refresh, setRefresh] = useState(0);
  const [reply, setReply] = useState('');
  const [target, setTarget] = useState('');
  const [key, setKey] = useState(() => crypto.randomUUID());
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const history = useApi<History>(path + '?' + new URLSearchParams({ channel, page: String(page) }), undefined, refresh);
  const data = history.status === 'ready' ? history.data : undefined;
  const messages = data?.messages ?? [];
  const delivered = messages.filter((entry) => entry.direction === 'outbound' && entry.result === 'delivered').reverse();
  const selected = target || String(delivered[0]?.id ?? 'none');

  async function send(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setStatus('');
    setError('');
    try {
      const received = await request<{ result: string }>(path + '/replies', { method: 'POST', body: { reply: {
        channel, body: reply, event_key: key, message_id: selected === 'none' ? null : Number(selected),
      } } });
      const results: Record<string, string> = { confirmed: 'Appointment confirmed.', review: 'Reply sent to the front desk for review.',
        opted_out: 'Text messages stopped for this clinic.' };
      setStatus(results[received.result] || 'Reply recorded.');
      setReply('');
      setTarget('');
      setKey(crypto.randomUUID());
      setPage(1);
      setRefresh((value) => value + 1);
    } catch (failure) {
      setError(messageFrom(failure));
    } finally {
      setSaving(false);
    }
  }

  return <section className="conversation">
    <h2>Message history</h2>
    {history.status === 'loading' && <p role="status">Loading messages…</p>}
    {history.status === 'error' && <><Feedback error={history.error} /><button onClick={() => setRefresh((value) => value + 1)}>Retry</button></>}
    {data && <>
      {messages.length === 0 && <p className="muted">{channel === 'sms' ? 'No simulated texts yet.' : 'No simulated emails yet.'}</p>}
      <div className="messages">{messages.map((message) => <article key={message.id} className={'message ' + message.direction}>
        <small>{message.direction === 'outbound' ? 'Clinic' : 'Patient'} · {localTimestamp(message.occurred_at, data.timezone)}</small>
        <p>{message.body}</p>
        <Pill tone={message.result}>{titleCase(message.result)}</Pill>
      </article>)}</div>
      <Pager page={data.page} more={data.more} choose={(value) => { setPage(value); setTarget(''); setKey(crypto.randomUUID()); }} />
    </>}
    <form className="panel form-stack composer" onSubmit={send}>
      <h2>Simulate a reply</h2>
      {delivered.length > 0 && <label>Reply to<select value={selected} onChange={(event) => { setTarget(event.target.value); setKey(crypto.randomUUID()); }}>
        {delivered.map((message) => <option key={message.id} value={message.id}>{message.body.split(/ (?=Reply |Responda )/)[0]}</option>)}
        <option value="none">No specific message</option>
      </select></label>}
      <label>Reply<textarea value={reply} rows={3} required maxLength={1000} placeholder="Type a reply"
        onChange={(event) => { setReply(event.target.value); setKey(crypto.randomUUID()); }} /></label>
      <Feedback error={error} status={status} />
      <button className="primary" disabled={saving || !data}>{saving ? 'Sending…' : 'Send reply'}</button>
    </form>
  </section>;
}
