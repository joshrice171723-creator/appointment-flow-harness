// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, test, vi } from 'vitest';
import { Inbox } from './inbox';
import { weekOf, wallDate } from './ui';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

test('calendar preserves wall times and the selected clinic week across year boundaries', () => {
  expect(weekOf('2027-01-01')).toEqual([
    '2026-12-28', '2026-12-29', '2026-12-30', '2026-12-31', '2027-01-01', '2027-01-02', '2027-01-03',
  ]);
  expect(wallDate('2026-11-19T13:00:00', { hour: 'numeric', minute: '2-digit' })).toBe('1:00 PM');
});

test('switching clinics discards the previous patient and message state', async () => {
  const fetchStub = vi.fn(async (path: string) => {
    if (path.includes('/inboxes/')) {
      return Response.json({ messages: [{ id: 1, body: 'Austin message', direction: 'outbound',
        result: 'delivered', occurred_at: '2026-11-12T17:30:00Z', in_reply_to: null }], timezone: 'America/Chicago' });
    }
    return Response.json({ patients: path.includes('/101/') ? [{ id: 4, name: 'Austin patient' }] : [], page: 1, more: false });
  });
  vi.stubGlobal('fetch', fetchStub);
  render(<Inbox sites={[
    { id: 101, name: 'Austin', location: 'Austin, TX', staff: [] },
    { id: 102, name: 'Phoenix', location: 'Phoenix, AZ', staff: [] },
  ]} />);
  fireEvent.change(screen.getByLabelText('Clinic'), { target: { value: '101' } });
  await screen.findByRole('option', { name: 'Austin patient' });
  fireEvent.change(screen.getByLabelText('Patient'), { target: { value: '4' } });
  await screen.findByText('Austin message', { selector: 'p' });
  fireEvent.change(screen.getByLabelText('Clinic'), { target: { value: '102' } });
  expect(screen.queryByText('Austin message')).toBeNull();
  await screen.findByRole('option', { name: 'No matching patients' });
  expect(screen.queryByRole('option', { name: 'Austin patient' })).toBeNull();
}, 15_000);
