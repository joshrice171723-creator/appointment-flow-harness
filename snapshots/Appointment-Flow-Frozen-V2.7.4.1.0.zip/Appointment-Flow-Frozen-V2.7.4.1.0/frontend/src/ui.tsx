import type { ReactNode } from 'react';
import type { Issue, Queue, SiteMetadata, Visit } from './api';

export const queueLabels: Record<Queue, string> = {
  needs_attention: 'Needs attention', in_progress: 'In progress', resolved: 'Resolved',
};
export const issueLabels: Record<Issue, string> = {
  no_reply: 'No confirmation', contact_hold: 'Contact hold', delivery_failed: 'Delivery failed', reply_review: 'Reply to review',
};

export function titleCase(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1).replaceAll('_', ' ');
}

export function wallDate(value: string, options: Intl.DateTimeFormatOptions) {
  const timestamp = value.includes('T') ? value + 'Z' : value + 'T12:00:00Z';
  return new Intl.DateTimeFormat('en-US', { ...options, timeZone: 'UTC' }).format(new Date(timestamp));
}

export function localTimestamp(value: string, timezone: string) {
  return new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeStyle: 'short', timeZone: timezone }).format(new Date(value));
}

export function addDays(value: string, days: number) {
  const date = new Date(value + 'T12:00:00Z');
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

export function weekOf(value: string) {
  const day = new Date(value + 'T12:00:00Z').getUTCDay();
  return Array.from({ length: 7 }, (_, index) => addDays(value, index - ((day + 6) % 7)));
}

export function Tabs<T extends string>({ tabs, selected, choose, label }: {
  tabs: { id: T; name: string; count?: number }[];
  selected: T;
  choose: (id: T) => void;
  label: string;
}) {
  return <div className="tabs" role="group" aria-label={label}>
    {tabs.map(({ id, name, count }) => <button type="button" key={id} aria-pressed={selected === id} onClick={() => choose(id)}>
      {name}{count !== undefined && <span className="tab-count">{count}</span>}
    </button>)}
  </div>;
}

export function Pill({ children, tone = '' }: { children: ReactNode; tone?: string }) {
  return <span className={'pill ' + tone}>{children}</span>;
}

export function Feedback({ error, status }: { error?: string; status?: string }) {
  if (error) return <p className="feedback error" role="alert">{error}</p>;
  if (status) return <p className="feedback" role="status">{status}</p>;
}

export function SyncStamp({ metadata }: { metadata: SiteMetadata }) {
  return <p className="sync">Last PMS sync {metadata.last_synced_at ? localTimestamp(metadata.last_synced_at, metadata.timezone) : 'pending'} · {metadata.timezone}</p>;
}

export function Pager({ page, more, choose }: { page: number; more: boolean; choose: (page: number) => void }) {
  if (page === 1 && !more) return null;
  return <div className="pager">
    <button type="button" disabled={page <= 1} onClick={() => choose(page - 1)}>Previous</button>
    <span>Page {page}</span>
    <button type="button" disabled={!more} onClick={() => choose(page + 1)}>Next</button>
  </div>;
}

export function VisitTable({ visits, open }: { visits: Visit[]; open?: (patientId: number) => void }) {
  if (visits.length === 0) return <p className="empty">No appointments match this view.</p>;
  return <div className="table-scroll"><table>
    <thead><tr><th>Patient</th><th>Appointment</th><th>Confirmation</th><th>PMS outcome</th>{open && <th>Next step</th>}</tr></thead>
    <tbody>{visits.map((visit) => <tr key={visit.id}>
      <th scope="row">{visit.patient}</th>
      <td><strong>{wallDate(visit.start_at, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</strong>
        <small>{visit.provider || 'Provider unavailable'}{visit.minutes ? ' · ' + visit.minutes + ' min' : ''}</small></td>
      <td><Pill tone={visit.confirmation}>{titleCase(visit.confirmation)}</Pill>{visit.reply_review && <small>Reply to review</small>}</td>
      <td>{titleCase(visit.outcome)}</td>
      {open && <td><button type="button" className="text-button" onClick={() => open(visit.patient_id)}>Patient details <span aria-hidden="true">↗</span></button></td>}
    </tr>)}</tbody>
  </table></div>;
}
