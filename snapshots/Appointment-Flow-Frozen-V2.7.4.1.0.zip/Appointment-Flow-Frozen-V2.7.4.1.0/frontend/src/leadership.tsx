import { useState } from 'react';
import { useApi } from './api';
import { Feedback, wallDate } from './ui';

const categories = [
  { id: 'completed', label: 'Completed', color: 'green' },
  { id: 'rescheduled', label: 'Rescheduled', color: 'blue' },
  { id: 'canceled', label: 'Canceled', color: 'rust' },
  { id: 'unknown', label: 'Unknown', color: 'gray' },
] as const;
type Metrics = Record<(typeof categories)[number]['id'], number> & { recorded: number; completion_rate: number | null };
interface ClinicReport {
  id: number;
  name: string;
  outcomes: Metrics;
  previous: Metrics;
  delivered: number;
  failed: number;
  holds: number;
  follow_ups: Record<string, number>;
}

function percentage(rate: number | null) {
  return rate === null ? '—' : new Intl.NumberFormat('en-US', { style: 'percent', maximumFractionDigits: 1 }).format(rate);
}

export function Leadership() {
  const [month, setMonth] = useState('');
  const [refresh, setRefresh] = useState(0);
  const report = useApi<{ month: string; clinics: ClinicReport[] }>(
    '/api/leadership?' + new URLSearchParams({ month }), undefined, refresh,
  );
  const data = report.status === 'ready' ? report.data : undefined;

  return <main>
    <div className="heading-row"><div><h1>Appointment outcomes</h1>
      <p className="muted">PMS-recorded visits and follow-up activity by clinic.</p></div>
      <label>Outcome month<input type="month" value={month || data?.month || ''} onChange={(event) => setMonth(event.target.value)} /></label>
    </div>
    {report.status === 'loading' && <p role="status">Loading appointment outcomes…</p>}
    {report.status === 'error' && <><Feedback error={report.error} /><button onClick={() => setRefresh((value) => value + 1)}>Retry</button></>}
    {data && <>
      <section className="panel report-panel">
        <h2>{wallDate(data.month + '-01', { month: 'long', year: 'numeric' })}</h2>
        <div className="clinic-grid">{data.clinics.map((clinic) => <article key={clinic.id}>
          <div className="clinic-heading"><h3>{clinic.name}</h3><small>{clinic.outcomes.recorded} recorded visits</small></div>
          <div className="chart" aria-hidden="true">
            {categories.map((category) => <div key={category.id} className={category.color}
              style={{ flexGrow: clinic.outcomes[category.id] }} />)}
          </div>
          <div className="metrics">{categories.map((category) => <div key={category.id}>
            <span><i className={category.color} />{category.label}</span><strong>{clinic.outcomes[category.id]}</strong>
          </div>)}</div>
        </article>)}</div>
      </section>
      <section className="panel report-panel">
        <h2>Clinic comparison</h2>
        <p className="muted">Completion rate is completed visits divided by recorded visits. Unknown includes scheduled visits and unmapped PMS statuses.</p>
        <div className="table-scroll"><table>
          <thead><tr><th>Clinic</th><th>Completion rate</th><th>Recorded visits</th>
            {categories.map((category) => <th key={category.id}>{category.label}</th>)}</tr></thead>
          <tbody>{data.clinics.map((clinic) => <tr key={clinic.id}>
            <th scope="row">{clinic.name}</th><td>{percentage(clinic.outcomes.completion_rate)}</td><td>{clinic.outcomes.recorded}</td>
            {categories.map((category) => <td key={category.id}>{clinic.outcomes[category.id]}</td>)}
          </tr>)}</tbody>
        </table></div>
      </section>
      <ReportDisclosure title="Monthly history and reminder activity"
        description="Prior completion uses the previous month’s PMS visits. Simulated deliveries and failures count outbound attempts in the selected UTC month."
        headers={['Prior completion rate', 'Prior recorded visits', 'Simulated deliveries', 'Failed attempts']}
        rows={data.clinics.map((clinic) => [clinic.name, percentage(clinic.previous.completion_rate),
          clinic.previous.recorded, clinic.delivered, clinic.failed])} />
      <ReportDisclosure title="Contact holds" description="New contact holds opened in the selected UTC month."
        headers={['New contact holds']} rows={data.clinics.map((clinic) => [clinic.name, clinic.holds])} />
      <ReportDisclosure title="Contact and follow-up" description="Staff actions recorded in the selected UTC month. A case can have multiple contact attempts."
        headers={['Contact attempted', 'Confirmed', 'Rescheduled', 'Canceled', 'Resolved after review']}
        rows={data.clinics.map((clinic) => [clinic.name, clinic.follow_ups.attempted, clinic.follow_ups.confirmed,
          clinic.follow_ups.rescheduled, clinic.follow_ups.canceled, clinic.follow_ups.resolved])} />
    </>}
  </main>;
}

function ReportDisclosure({ title, description, headers, rows }: {
  title: string;
  description: string;
  headers: string[];
  rows: (string | number)[][];
}) {
  return <details className="panel report-disclosure">
    <summary>{title}</summary>
    <p className="muted">{description}</p>
    <div className="table-scroll"><table>
      <thead><tr><th>Clinic</th>{headers.map((header) => <th key={header}>{header}</th>)}</tr></thead>
      <tbody>{rows.map(([clinic, ...values]) => <tr key={clinic}>
        <th scope="row">{clinic}</th>{values.map((value, index) => <td key={headers[index]}>{value}</td>)}
      </tr>)}</tbody>
    </table></div>
  </details>;
}
