# Rubric results

## Round 1 · REVISE · 680214b

A separate Codex reviewer applied `agent-prompts/03_INDEPENDENT_REVIEW.md` to the checkpoint and reproduced risks through the normal HTTP endpoints on an isolated PostgreSQL database. The baseline reproduction ran four checks with 29 assertions and two expected failures.

| Criterion | Grade | Evidence and disposition |
| --- | --- | --- |
| Required behavior | REVISE | A late-adolescent patient received a message before turning 18. At the November 12 run, a November 15 birthday and a November 19 visit yielded HTTP 201 with one delivery. Use the clinic-local event date. |
| Safety and data boundaries | REVISE | After a valid email send, a tab-wrapped equivalent email appeared on another clinic’s patient. An inbound YES returned `confirmed`. The PostgreSQL directory trimmed spaces while Ruby trimmed additional whitespace. The review also identified raw search text and former contact values outside the request log filters. |
| Performance and Rails queries | REVISE | The batch issued 5 and 65 write statements for 5 and 65 existing holds needing the same reason change. The writes were equivalent and held the clinic lock across each statement. |
| Material workflow coverage | REVISE | Initial checks missed the birthday boundary and equivalent email variant after an earlier delivery. |
| Human readability | PASS | Normal reminder, inbound, staff, and verification requests reached the corresponding named transaction owner. The appointment filters and leadership response remained in their resource controllers. |
| Ease of change | UNVERIFIED | The disposable rule exercise was still running at the first grade. |
| Failure and transaction behavior | PASS | The reminder test forced failure after insertion of a fake attempt and showed no message, follow-up, or successful sync committed. |
| Verification and handoff | REVISE | The first application gate found dynamic query clauses flagged by Brakeman, a browser-script lint error, style fixes needed for a new migration, and a React test timeout. The local browser run was pending. |

## Round 2 · PASS · 893ffe4de1380af61794f18a660ba9b957ac3f4c

The independent reviewer reran the changed caller cases against the repaired code. Four tests passed with 34 assertions. For the pre-birthday visit, the response recorded zero deliveries. The tab-delimited cross-clinic duplicate changed the inbound outcome to review and left confirmation absent. The neighboring control rejected a reply referencing another patient’s message with HTTP 422 and left both inbound message and decision absent.

| Criterion | Grade | Evidence on the reviewed implementation |
| --- | --- | --- |
| Required behavior | PASS | The local reminder command recorded fake visits, and the built browser app submitted both an SMS YES and an email YES and displayed confirmation. `workspaces_test.rb` asserts the exact clinic-scoped appointment ID and its separate PMS outcome. Browser smoke exercised staff contact verification, clinic switching and report details. |
| Safety and data boundaries | PASS | `reminder_and_reply_test.rb` checks stale and replacement visits, late replies, opt-outs and ambiguous STOP, shared contacts across clinics, timezones and DST, failed/suspiciously empty reads, and rejected replica writes. `concurrent_reminders_test.rb` uses two PostgreSQL connections and observes one fake attempt. The repaired HTTP regressions prove age at outreach and current authoritative email matching. The leadership response test checks aggregate-only fields. Logs filter message bodies, prior contact values, and patient search text. |
| Performance and Rails queries | PASS | Both normal callers retained their exact outcome under growth. The measurements and source predicates are below. Runtime queries use Active Record relations. The DDL owns the live views and their expression indexes. |
| Material workflow coverage | PASS | The route and workflow map below identifies the material operations, their checks and persisted effects. |
| Human readability | PASS | `ReminderRun#call` shows replica presence, bounded selection, per-page processing and successful sync within one site lock. `PatientReply#call` validates the event, establishes the original message and recipient, then records its outcome. `StaffFollowUp#record` and `VerifyPatientContact#call` own their cross-record writes. The `SEND_HOURS` constant is the edit point for the local send-window rule. |
| Ease of change | PASS | In a detached copy and isolated PostgreSQL database, changing only `ReminderRun::SEND_HOURS` from 10:00 to 09:00 made a 09:30 Chicago run deliver exactly one expected visit. The same test still proved an 08:30 run wrote nothing. The new assertion failed before the edit and passed afterward with five assertions. |
| Failure and transaction behavior | PASS | The reminder test injects an exception on follow-up insert after the fake attempt write. The staff request test injects a failure after the audit INSERT and proves confirmation, case resolution, claim, and audit all rolled back. Stale and invalid writes return HTTP 422, while repeated event references keep one workflow effect. |
| Verification and handoff | PASS | A newly created PostgreSQL database ran all migrations, booted with zero sites and messages, then seeded and served the built app. `npm ci` succeeded in a clean checkout using the same frontend lockfile. The browser smoke passed on that database. `python quality/run_checks.py` passed all seven checks, including 30 Rails tests with 238 assertions, two React tests, RuboCop, Brakeman with zero warnings, ESLint, TypeScript, and the Vite build. |

### Material workflow map

| Normal entry point | Scope, result and evidence |
| --- | --- |
| `POST /api/sites/:site_id/reminder_runs`, `reminders:run` | Clinic-local upcoming scheduled source range, 200 visits per page, live recipient matching, per-revision deduplication, and site transaction for attempts, tasks and sync. Rails tests assert authorization, outcome counts, retry, failure rollback, and competing runs. The documented command was exercised against a freshly seeded database. |
| `POST /api/sites/:site_id/inboxes/:inbox_id/replies` | Patient membership, channel, message ID, live recipient and revision are checked before confirming. The service persists one audit event and its qualifying effect. Tests assert delivery context, current revision, clinic isolation, stale/late/ambiguous cases, and idempotent replay. Both channels passed through the built browser. |
| `GET /api/sites/:site_id/appointments`, `GET /api/sites/:site_id/follow_ups` | Ship at most 25 visits or 16 tasks per response, in deterministic order. Appointment count and calendar scope stay intact when filtering. The board search keeps full-clinic queue totals and excludes other-clinic data. Tests exercise pagination, filtering, an exact response under history growth, and staff visibility. |
| `PATCH /api/sites/:site_id/follow_ups/:id`, nested `staff_actions` POST | A scoped staff identity can claim open work and save a note. Changed revisions are rejected before mutation. Tests assert invalid, replayed, stale, valid and failed attempts, and check the local decision, raw PMS status, open/closed case and audit. |
| Patient detail GET, nested `contact_verification` PATCH | The current clinic and patient scope ends at bounded lists of visits, tasks and audit. A local verification preserves raw PMS data and prior value history. The next batch uses the verified value. A source drift reopens a hold. Tests and browser both exercise verification. |
| Inbox index/history GET, leadership GET | Inbox choices and histories are clinic-scoped and limited to 50 patients and 40 messages. Browser and React tests exercise selection and clinic changes. Leadership groups by clinic and month and serializes outcome and activity totals. The HTTP test verifies a confirmed scheduled visit does not count as completed. |

### PostgreSQL workload evidence

The probe wrapped the Rails request or clinic run. Fixture creation and assertions were outside the measurement. The reminder numbers cover the clinic operation including its transaction and readiness read. Rake was timed separately including Ruby boot. Individual timings vary under local concurrent verification.

| Caller and workload | Observed result |
| --- | --- |
| Appointment HTTP list with 1 row, then 500 prior same-clinic visits | The response body and returned visit ID were identical. Six SQL statements, six rows returned, four records instantiated, zero writes, and roughly 444 response bytes in each case. Earlier visits belong to the same clinic but fall outside the day and week predicates. |
| Reminder first population with 1 eligible visit | 20 SQL statements, 8 rows read, 5 records instantiated, 2 write statements affecting 2 rows, 0 rows returned by writes. The attempt and successful sync committed. |
| Identical reminder repeat, before and after 500 historical scheduled visits | Both repeated calls had 17 SQL statements, 8 rows read, 4 records instantiated and zero writes. The existing attempt ID remained the only dispatch. |
| Reminder first population with 205 eligible visits, then identical retry | First call had 27 SQL statements, 619 rows read, 413 records instantiated, and 3 writes affecting 206 rows. It inserted 205 precise visit attempts in two batches and updated the site sync. Repeat had 22 SQL statements, 823 rows read and 412 records instantiated, including prior attempt checks, with 0 writes or new deliveries. No write returned rows. |
| Existing holds whose reason changed, 5 to 65 through HTTP | Initial revision had 5 to 65 writes and 21 to 81 total statements. Repaired code had 1 write and 16 total statements in both cases, preserving the affected IDs and assignees. Replays wrote nothing. The independent reviewer measured 1,705 ms baseline and 174 ms repaired at 65 under shared-machine conditions. The main suite additionally asserts one write for 40 holds. |
| Leadership month aggregate with 10,000 historical visits and one in-month visit | Independent PostgreSQL plan used the appointment index with the month bound as an index condition, removed the unused decision join, touched ten buffers, and returned one aggregate row. The isolated execution time was approximately 0.28 ms. |

The participant’s authored `DECISIONS.md` and live defense are outside the technical grade. The factual notes reflect the implemented tradeoffs, including assumed demo consent, conservative source revisions, and clinic-local appointment clocks. The local Git repository has no upstream.
