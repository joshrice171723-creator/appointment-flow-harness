# Apex Appointment Flow

A local Rails, React, and PostgreSQL demo for appointment confirmations. Austin and Phoenix contain fictional patients. SMS and email are simulated in PostgreSQL.

## Start the demo

Use Ruby 3.4.10, Bundler 4.0.15, Node 24, npm, Python 3.10 or newer, and a PostgreSQL 17 server. Configure PostgreSQL's usual connection environment (`PGHOST`, `PGPORT`, `PGUSER` and a local password source if required). The setup role needs to create `apex_flow_development` and `apex_flow_test` or own those two empty databases.

From the repository root, install dependencies, migrate and seed, build the UI, and start Rails on loopback.

```sh
cd backend
bundle install
ruby bin/rails db:prepare
ruby bin/rails db:seed
cd ../frontend
npm ci
npm run build
cd ../backend
ruby bin/rails server -b 127.0.0.1 -p 4317
```

Open [http://127.0.0.1:4317](http://127.0.0.1:4317). The seed uses each clinic's current date and simulates an 11:30 a.m. batch, so both message channels have history regardless of when you start the app. Re-running the seed on the same clinic day preserves existing simulated replies and follow-ups.

## Exercise a reminder and reply

- Choose **Patient → Austin → Avery Lane** for a seeded SMS or **Austin → Elena Vega → Email** for a seeded email. Select a delivered message and send `YES` for an upcoming visit. `NO` or unclear wording opens a review. An exact SMS `STOP` suppresses future SMS.
- In **Front desk**, choose the same clinic, then **Appointments** and jump to the date in the reminder. The current revision displays **Confirmed**. Open **Patient flow** to assign work, record follow-up, or verify a contact locally.
- **Run reminders** in Patient flow evaluates the selected clinic at the current time. From `backend`, `ruby bin/rails reminders:run` evaluates all clinics. Optional environment variables are `SITE_ID` (`101` Austin, `102` Phoenix) and `NOW` (ISO 8601 instant with an explicit offset). For example, in PowerShell set `$env:SITE_ID = '101'` and `$env:NOW = '2026-11-16T11:45:00-06:00'`; choose a date that matches your seeded visits, then run the task. Remove the overrides when finished.
- Inspect fake deliveries in the patient inbox or run `ruby bin/rails console` and evaluate `Message.outbound.order(:id).pluck(:site_id, :appointment_id, :step, :channel, :result)`. In the fixture, an SMS destination ending in `0199` produces a failed attempt.

## Cadence and source assumptions

The default local sending window is 10:00 a.m. to 6:00 p.m. The initial window starts seven days ahead. When both channels are usable, the first attempt is by text and backup email can start six days ahead. Follow-up starts three days ahead, and the final window starts one day ahead. A batch chooses the current step per visit, coalescing missed steps. A confirmed visit can receive one informational final reminder. Staff follow-up opens within 48 hours for a scheduled visit that still needs confirmation.

The assessment's PMS tables live in the `pms` schema. Application records live in `public`. The runtime reads the clinic-local timestamp and source contact values directly. The seed and test fixture writer simulate replication. Source trigger guards reject application writes by default. The demo infers eligible channel permission from a usable contact for an adult whose details pass the safety checks. Verified local values keep a copy of the source value, so a subsequent source change can hold outreach for review. The directory checks contacts across the replica, including patients outside the current clinic and visible page.

The selected clinic and its staff ID are a demo identity stub. Real use would require authenticated staff identities, per-clinic authorization, a PostgreSQL account with SELECT-only replica privileges, an explicit consent registry, and verified inbound provider events. Leadership metrics use source outcomes, including Unknown for scheduled or unmapped statuses. They provide counts and completion rates for recorded visits.

## Verify

After installing dependencies and running migrations for both application databases, run from the repository root.

```sh
python quality/run_checks.py
```

For a browser smoke, leave the freshly seeded demo running and use `npm run smoke` from `frontend`. The script uses an installed Chromium-family browser. Set `BROWSER_PATH` if it is outside the default locations, or `DEMO_URL` for a different loopback port. The smoke records a fictional reply and a contact verification.

The original input preflight ran before application changes. The original files, including the blank build log and freeze checklist, are preserved at the first local Git checkpoint. Use that checkout to repeat `python quality/verify_harness.py` on the original inputs.

See [architecture](ARCHITECTURE.md), [build log](notes/BUILD_LOG.md), and [candidate decision notes](notes/CANDIDATE_DECISION_NOTES.md).
