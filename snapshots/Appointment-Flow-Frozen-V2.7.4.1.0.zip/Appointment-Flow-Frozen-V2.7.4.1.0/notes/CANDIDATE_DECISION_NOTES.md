# Tradeoff notes for candidate's own DECISIONS.md

The assessment requires that the candidate write `DECISIONS.md` **personally in their own words**. Capture factual choices and alternatives here so the candidate can make their own narrative later. Agent must not claim authorship on their behalf.

- Assumption / ambiguity:
- What was chosen and why:
- Alternative considered and drawback:
- Risk / what would change with another week:
- Evidence (test/demo/measurement):

- Implemented design: one Rails app with a prebuilt React frontend and one PostgreSQL server. The `pms` schema preserves source values. Views expose normalized contacts, current revisions and workspace projections. A fixture-only switch makes the demo replica writable within its own transaction.
- Transactions and index: the site row is the coordination boundary for local reminder, reply, correction and staff writes. The unique database key for a fake send is clinic, visit, revision and step. The fake transport returns a result and the persisted message is the whole simulated dispatch.
- Source uncertainty: the supplied schema has no version or consent columns. Revision checks conservatively include the source update timestamp, and new scheduled revisions can require fresh confirmation. Clinic-local time comes from timezone mapping, and ambiguous or nonexistent wall times require review. Replica lag remains a source limitation.
- Outreach: supported seed languages are English and Spanish. The demo assumes permission for eligible adult contacts, aggregates shared-contact evidence across the directory, and uses local SMS opt-outs. Guardians are referred to staff for authorization. Discuss a production consent source and verified provider events in your own words.
- Reporting: remember the distinction between source completion and confirmation. Reporting uses clinic-local visit dates, UTC activity months, and transparent outcome mappings. The data does not establish no-show reduction.
