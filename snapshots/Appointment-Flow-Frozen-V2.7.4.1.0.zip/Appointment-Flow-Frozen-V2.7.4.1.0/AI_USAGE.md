# AI usage

Codex implemented the clean-room application from the packaged assignment, sanitized product behavior, and ten reference screenshots. It used standard Rails, React, Vite, PostgreSQL and browser tools. It authored the implementation, synthetic fixtures, checks, architecture, and factual handoff. The workflow used local Git and a distinct AI review of the local application. No messages used a live vendor and no prior application repository was accessed.

Joshua required a passing preflight before application implementation and asked to proceed with the rebuild immediately afterward. The implementation choices and test evidence are recorded in the build log and rubric report. Candidate-authored decisions and interview explanations belong to Joshua.
