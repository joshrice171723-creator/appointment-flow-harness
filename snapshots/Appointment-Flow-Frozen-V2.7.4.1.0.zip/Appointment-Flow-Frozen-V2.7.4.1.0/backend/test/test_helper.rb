ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"
require Rails.root.join("db/support/replica_fixtures")

class ActiveSupport::TestCase
  DEMO_NOW = Time.iso8601("2026-11-12T17:30:00Z")

  def create_site(id: 1, name: "Austin", timezone: "America/Chicago")
    ReplicaFixtures.write { ReplicaFixtures::Clinic.create!(id:, name:) }
    Site.create!(id:, timezone:)
  end

  def create_patient(**attributes)
    defaults = { first_name: "Demo", last_name: "Example", birthdate: "1985-12-10",
      wireless_phone: "512-555-0100", email: "demo@example.test", preferred_language: "en" }
    ReplicaFixtures.write { ReplicaFixtures::Patient.create!(**defaults, **attributes) }
  end

  def create_visit(site, patient, **attributes)
    defaults = { start_at: "2026-11-19 13:00", status: "scheduled", updated_at: DEMO_NOW }
    ReplicaFixtures.write do
      ReplicaFixtures::Appointment.create!(clinic_id: site.id, patient_id: patient.id, **defaults, **attributes)
    end
  end
end
