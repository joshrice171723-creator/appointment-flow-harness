require "test_helper"

class ConcurrentRemindersTest < ActiveSupport::TestCase
  self.use_transactional_tests = false

  test "competing clinic runs record exactly one fake dispatch" do
    site = create_site(id: 8750)
    patient = create_patient
    visit = create_visit(site, patient)
    ready = Queue.new
    start = Queue.new
    runs = 2.times.map do
      Thread.new do
        ApplicationRecord.with_connection do
          ready << true
          start.pop
          ReminderRun.new(Site.find(site.id), now: DEMO_NOW).call
        end
      end
    end
    2.times { ready.pop }
    2.times { start << true }
    assert_equal [ 0, 1 ], runs.map { |thread| thread.value.fetch(:delivered) }.sort
    assert_equal visit.id, site.messages.outbound.sole.appointment_id
  ensure
    if site
      Message.where(site_id: site.id).delete_all
      site.destroy!
      ReplicaFixtures.write do
        visit&.destroy!
        patient&.destroy!
        ReplicaFixtures::Clinic.find(site.id).destroy!
      end
    end
  end
end
