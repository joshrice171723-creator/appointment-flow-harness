require "test_helper"

class ReminderAndReplyTest < ActiveSupport::TestCase
  setup do
    @site = create_site
    @patient = create_patient
    @visit = create_visit(@site, @patient)
  end

  test "a delivered SMS confirms its current visit once and the final reminder is informational" do
    assert_equal 1, run_reminders[:delivered]
    assert_equal 0, run_reminders[:delivered]
    sent = @site.messages.outbound.sole
    assert_equal [ "sms", "initial" ], [ sent.channel, sent.step ]
    assert_includes sent.body, "2026-11-19"
    assert_includes sent.body, "STOP"
    assert_equal "confirmed", reply("YES", sent).result
    assert_equal "confirmed", reply("YES", sent).result
    assert_equal 1, @site.messages.where(direction: "inbound").count
    assert_equal "confirmed", @site.visit_decisions.sole.outcome
    assert_equal 0, run_reminders(DEMO_NOW + 4.days)[:delivered]
    assert_equal 1, run_reminders(DEMO_NOW + 6.days)[:delivered]
    refute_includes @site.messages.find_by!(step: "final").body, "Reply YES"
  end

  test "email can confirm when the patient has no SMS contact" do
    ReplicaFixtures.write { @patient.update!(wireless_phone: nil) }
    assert_equal 1, run_reminders[:delivered]
    sent = @site.messages.outbound.sole
    assert_equal "email", sent.channel
    assert_equal "confirmed", reply(" yes ", sent).result
  end

  test "a moved visit rejects an old YES and receives its own reminder" do
    run_reminders
    old = @site.messages.outbound.sole
    assert_equal "confirmed", reply("YES", old).result
    ReplicaFixtures.write { @visit.update!(start_at: "2026-11-19 16:00", updated_at: DEMO_NOW + 15.minutes) }
    assert_equal "review", reply("YES", old, key: "fresh-event").result
    assert_equal old.revision, @site.visit_decisions.sole.revision
    assert_not_equal old.revision, PmsVisit.find(@visit.id).revision
    assert_equal 1, run_reminders(DEMO_NOW + 20.minutes)[:delivered]
    assert_equal 2, @site.messages.outbound.count
  end

  test "ending a source visit stops its reminders and leaves the replacement unconfirmed" do
    run_reminders
    sent = @site.messages.outbound.sole
    assert_equal "confirmed", reply("YES", sent).result
    ReplicaFixtures.write { @visit.update!(status: "broken", updated_at: DEMO_NOW + 15.minutes) }
    replacement = create_visit(@site, @patient, start_at: "2026-11-20 14:00")
    assert_equal 1, run_reminders(DEMO_NOW + 2.days)[:delivered]
    assert_equal [ @visit.id, replacement.id ], @site.messages.outbound.order(:id).pluck(:appointment_id)
    assert_empty @site.visit_decisions.where(appointment_id: replacement.id)
    assert_equal "review", reply("YES", sent, key: "old-thread").result
  end

  test "a shared contact introduced in another clinic prevents the current reply and future outreach" do
    run_reminders
    sent = @site.messages.outbound.sole
    other_site = create_site(id: 2, name: "Phoenix", timezone: "America/Phoenix")
    other_patient = create_patient(wireless_phone: "+1-512-555-0100", email: nil)
    create_visit(other_site, other_patient)
    assert_equal "review", reply("YES", sent).result
    assert_empty @site.visit_decisions
    assert_equal [ @visit.id ], @site.follow_ups.find_by!(issue: "reply_review").candidate_ids
    assert_equal 0, run_reminders(DEMO_NOW + 4.days)[:delivered]
    assert_match "shared", @site.follow_ups.find_by!(issue: "contact_hold").reason
  end

  test "STOP persists after the source phone changes" do
    run_reminders
    sent = @site.messages.outbound.sole
    assert_equal "opted_out", reply("sToP", sent).result
    ReplicaFixtures.write { @patient.update!(wireless_phone: "512-555-0101") }
    assert_equal 1, run_reminders(DEMO_NOW + 4.days)[:delivered]
    assert_equal [ "sms", "email" ], @site.messages.outbound.order(:id).pluck(:channel)
  end

  test "ambiguous opt-out wording prevents SMS while staff review it" do
    run_reminders
    sent = @site.messages.outbound.sole
    assert_equal "review", reply("STOP please", sent).result
    assert_equal FollowUp::SMS_OPT_OUT_REVIEW, @site.follow_ups.sole.reason
    assert_empty @site.sms_opt_outs
    assert_equal 1, run_reminders(DEMO_NOW + 4.days)[:delivered]
    assert_equal [ "sms", "email" ], @site.messages.outbound.order(:id).pluck(:channel)
  end

  test "a failed SMS is recorded and the next eligible step uses backup email" do
    ReplicaFixtures.write { @patient.update!(wireless_phone: "512-555-0199") }
    assert_equal 1, run_reminders[:failed]
    assert_equal "failed", @site.messages.outbound.sole.result
    assert_equal "delivery_failed", @site.follow_ups.sole.issue
    assert_equal 1, run_reminders(DEMO_NOW + 1.day)[:delivered]
    assert_equal 0, run_reminders(DEMO_NOW + 1.day)[:delivered]
    assert_equal "email", @site.messages.find_by!(step: "backup_email").channel
  end

  test "NO following YES creates a review without undoing confirmation" do
    run_reminders
    sent = @site.messages.outbound.sole
    assert_equal "confirmed", reply("YES", sent).result
    assert_equal "review", reply("NO", sent, key: "changed-intent").result
    assert_equal "confirmed", @site.visit_decisions.sole.outcome
    assert_equal [ @visit.id ], @site.follow_ups.sole.candidate_ids
  end

  test "a failed synchronization preserves previously committed messages and last successful sync" do
    run_reminders
    ReplicaFixtures.write { @visit.destroy! }
    assert_raises(ReplicaUnavailable) { run_reminders(DEMO_NOW + 1.day) }
    assert_equal DEMO_NOW, @site.reload.last_synced_at
    assert_equal 1, @site.messages.count
  end

  test "a later write failure rolls back a fake attempt and the entire refresh" do
    ReplicaFixtures.write { @patient.update!(wireless_phone: "512-555-0199") }
    ActiveSupport::Notifications.subscribed(->(*) { raise "injected failure" }, "insert_all.follow_up") do
      # Active Record reports statements after the database accepted them.
      listener = lambda do |event|
        raise "injected failure" if event.payload[:sql].start_with?('INSERT INTO "follow_ups"')
      end
      ActiveSupport::Notifications.subscribed(listener, "sql.active_record") do
        assert_raises(RuntimeError) { run_reminders }
      end
    end
    assert_empty @site.messages
    assert_empty @site.follow_ups
    assert_nil @site.reload.last_synced_at
  end

  test "a late YES becomes review and no message goes out after start" do
    run_reminders
    sent = @site.messages.outbound.sole
    late = Time.iso8601("2026-11-19T19:01:00Z")
    assert_equal "review", reply("YES", sent, at: late).result
    assert_empty @site.visit_decisions
    assert_equal 0, run_reminders(late)[:delivered]
  end

  test "the sending window uses Phoenix local time" do
    phoenix = create_site(id: 2, name: "Phoenix", timezone: "America/Phoenix")
    create_visit(phoenix, @patient)
    early = Time.iso8601("2026-11-12T16:30:00Z")
    assert_equal 1, ReminderRun.new(@site, now: early).call[:delivered]
    assert_equal 0, ReminderRun.new(phoenix, now: early).call[:delivered]
    assert_equal 1, ReminderRun.new(phoenix, now: DEMO_NOW).call[:delivered]
  end

  test "the clinic rejects ambiguous or nonexistent local timestamps" do
    [ "2026-03-08 02:30", "2026-11-01 01:30" ].each do |clock|
      record = create_visit(@site, @patient, start_at: clock)
      assert_nil @site.visit_instant(PmsVisit.find(record.id))
    end
  end

  test "the replica rejects writes from the application connection" do
    assert_raises(ActiveRecord::ReadOnlyRecord) { PmsVisit.find(@visit.id).destroy! }
    assert_raises(ActiveRecord::StatementInvalid) do
      ApplicationRecord.transaction(requires_new: true) { ReplicaFixtures::Appointment.delete(@visit.id) }
    end
    assert PmsVisit.exists?(@visit.id)
  end

  private

  def run_reminders(at = DEMO_NOW)
    ReminderRun.new(@site, now: at).call
  end

  def reply(body, original, key: "one-event", at: DEMO_NOW + 1.minute)
    PatientReply.new(@site, channel: original.channel, body:, event_key: key, now: at)
      .call(patient_id: @patient.id, message_id: original.id)
  end
end
