require "test_helper"
require Rails.root.join("../quality/rails_workload_probe")

class ReminderWorkloadTest < ActiveSupport::TestCase
  test "same-clinic history does not increase the work of a reminder run" do
    site = create_site
    patient = create_patient
    original = create_visit(site, patient)
    first, first_metrics = measure_run(site)
    unchanged, small = measure_run(site)
    assert_equal({ delivered: 1, failed: 0, follow_ups_created: 0 }, first)
    assert_equal({ delivered: 0, failed: 0, follow_ups_created: 0 }, unchanged)

    ReplicaFixtures.write do
      old_visits = 500.times.map do |index|
        { clinic_id: site.id, patient_id: patient.id, status: "scheduled", start_at: "2025-01-01 10:00:00",
          provider_name: "Demo provider #{index}" }
      end
      ReplicaFixtures::Appointment.insert_all!(old_visits)
    end
    assert_equal 501, site.visits.scheduled.count
    repeat, large = measure_run(site)
    assert_equal unchanged, repeat
    assert_equal [ original.id ], site.messages.outbound.pluck(:appointment_id)
    %i[database_statements read_rows instantiated_records direct_write_statements].each do |metric|
      assert_equal small[metric], large[metric], metric.to_s
    end
    puts "Reminder first: #{first_metrics}; repeat: #{small}; repeat with history: #{large}"
  end

  test "growing eligible visits uses one attempt insert per page and no writes on repeat" do
    site = create_site
    eligible = ReminderRun::PAGE_SIZE + 5
    visit_ids = ReplicaFixtures.write do
      patients = eligible.times.map do |index|
        { first_name: "Demo", last_name: "Patient #{index}", birthdate: "1980-01-01",
          preferred_language: "en", email: "patient#{index}@example.test" }
      end
      patient_ids = ReplicaFixtures::Patient.insert_all!(patients, returning: [ :id ]).rows.flatten
      rows = patient_ids.map do |id|
        { clinic_id: site.id, patient_id: id, start_at: "2026-11-19 14:00:00", status: "scheduled" }
      end
      ReplicaFixtures::Appointment.insert_all!(rows, returning: [ :id ]).rows.flatten
    end
    assert_equal eligible, site.visits.scheduled.count
    first, population = measure_run(site)
    assert_equal eligible, first.fetch(:delivered)
    assert_equal visit_ids.sort, site.messages.outbound.order(:appointment_id).pluck(:appointment_id)
    assert_equal 3, population.fetch(:direct_write_statements)
    assert_equal eligible + 1, population.fetch(:affected_rows)
    repeated, repeat = measure_run(site)
    assert_equal 0, repeated.fetch(:delivered)
    assert_equal 0, repeat.fetch(:direct_write_statements)
    assert_equal eligible, site.messages.outbound.count
    puts "Reminder #{eligible} eligible; first: #{population}; repeat: #{repeat}"
  end

  test "a shared change to existing contact hold reasons uses one update" do
    site = create_site
    patient = create_patient(birthdate: nil)
    count = 40
    ReplicaFixtures.write do
      ReplicaFixtures::Appointment.insert_all!(Array.new(count) do
        { clinic_id: site.id, patient_id: patient.id, status: "scheduled", start_at: "2026-11-19 14:00:00" }
      end)
    end
    assert_equal count, measure_run(site).first.fetch(:follow_ups_created)
    initial_ids = site.follow_ups.order(:id).pluck(:id)
    ReplicaFixtures.write { patient.update!(birthdate: "2016-01-20") }
    result, work = measure_run(site)
    assert_equal({ delivered: 0, failed: 0, follow_ups_created: 0 }, result)
    assert_equal initial_ids, site.follow_ups.order(:id).pluck(:id)
    assert_equal [ "Verify guardian authorization before outreach." ], site.follow_ups.distinct.pluck(:reason)
    assert_equal 1, work.fetch(:direct_write_statements)
    assert_equal count, work.fetch(:affected_rows)
    puts "Updated holds #{count}: #{work}"
  end

  private

  def measure_run(site)
    RailsWorkloadProbe.measure { ReminderRun.new(Site.find(site.id), now: DEMO_NOW).call }
  end
end
