namespace :reminders do
  desc "Evaluate upcoming visits and record fake deliveries. SITE_ID and NOW (ISO 8601 with offset) are optional."
  task run: :environment do
    now = ENV["NOW"] ? Time.iso8601(ENV.fetch("NOW")) : Time.current
    sites = ENV["SITE_ID"] ? Site.where(id: Site.find(ENV.fetch("SITE_ID")).id) : Site.all
    failed = false
    sites.find_each do |site|
      result = ReminderRun.new(site, now:).call
      puts "#{site.clinic.name}: #{result.to_json}"
    rescue ReplicaUnavailable, ActiveRecord::ConnectionNotEstablished, ActiveRecord::QueryCanceled => error
      warn "Clinic #{site.id}: #{error.class}. No reminder changes committed."
      failed = true
    end
    abort "One or more clinics could not refresh." if failed
  end
end
