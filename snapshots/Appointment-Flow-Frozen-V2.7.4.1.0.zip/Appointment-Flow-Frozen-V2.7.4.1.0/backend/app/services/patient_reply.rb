class PatientReply
  def initialize(site, channel:, body:, event_key:, now: Time.current)
    @site = site
    @channel = channel
    @body = body.to_s.strip
    @event_key = event_key
    @now = now
  end

  def call(patient_id:, message_id: nil)
    validate_input
    @site.with_lock do
      @patient = @site.patients.find(patient_id)
      existing = @site.messages.find_by(event_key: @event_key)
      if existing
        validate_replay(existing, message_id)
        next existing
      end

      @original = @site.messages.delivered.find_by(id: message_id, patient_id: @patient.id, channel: @channel) if message_id.present?
      raise WorkflowRejection, "Choose a delivered message from this conversation." if message_id.present? && @original.nil?

      @visit = @site.visits.find_by(id: @original.appointment_id) if @original
      @contacts = ContactPolicy.new(@site, [ @patient ])
      @recipient = @contacts.recipient(@patient, @channel)
      result = interpret_reply
      received = @site.messages.create!(patient_id: @patient.id, appointment_id: @original&.appointment_id,
        revision: @original&.revision, channel: @channel, recipient: @recipient, direction: "inbound",
        body: @body, event_key: @event_key, occurred_at: @now, in_reply_to_id: @original&.id, result:)
      record_review(received) if result == "review"
      received
    end
  end

  private

  def validate_input
    raise WorkflowRejection, "Choose Text messages or Email." unless Message::CHANNELS.include?(@channel)
    raise WorkflowRejection, "Enter a reply of 1 to 1000 characters." unless @body.length.in?(1..1000)
    raise WorkflowRejection, "A reply reference is required." unless @event_key.is_a?(String) && @event_key.length.in?(1..80)
  end

  def validate_replay(existing, message_id)
    return if existing.patient_id == @patient.id && existing.channel == @channel && existing.body == @body &&
      existing.in_reply_to_id.to_s == message_id.to_s

    raise WorkflowRejection, "That reply reference is already in use."
  end

  def interpret_reply
    if @channel == "sms" && @body.casecmp?("STOP") && @recipient
      @site.sms_opt_outs.find_or_create_by!(patient_id: @patient.id, recipient: @recipient) { |entry| entry.created_at = @now }
      return "opted_out"
    end

    if @body.casecmp?("YES")
      rejection = confirmation_rejection
      return confirm_visit unless rejection
      @reason = rejection
    elsif @channel == "sms" && @body.match?(/\bstop\b/i)
      @reason = FollowUp::SMS_OPT_OUT_REVIEW
    else
      @reason = @body.casecmp?("NO") ? "The patient asked for help with the appointment." : "Review the wording of the reply."
    end
    "review"
  end

  def confirmation_rejection
    return "The reply came from a shared contact." if @contacts.shared?(@patient, @channel)
    return "A current appointment could not be identified from this reply." unless current_visit?
    return "The reply arrived after the visit start or the local time needs review." unless (@site.visit_instant(@visit) || @now) > @now
    return "The original recipient is no longer eligible." unless @contacts.allowed_recipient(@patient, @channel) == @original.recipient
    return "The patient's contact details need review." if @contacts.hold_reason(@patient, @site.local_time(@now).to_date)
    return "Staff already recorded a schedule change." if @site.visit_decisions.where(@visit.identity).where(outcome: %w[canceled rescheduled]).exists?

    nil
  end

  def current_visit?
    @original && @visit && @visit.status == "scheduled" && @visit.patient_id == @patient.id &&
      @visit.revision == @original.revision
  end

  def confirm_visit
    @site.visit_decisions.find_or_create_by!(@visit.identity) { |decision| decision.outcome = "confirmed" }
    @site.follow_ups.where(@visit.identity).where(issue: "no_reply", resolved_at: nil).update_all(resolved_at: @now)
    "confirmed"
  end

  def record_review(message)
    candidates = @site.visits.scheduled
    if @recipient && @contacts.shared?(@patient, @channel)
      candidates = candidates.where(patient_id: ContactPolicy.matching_patient_ids(@channel, @recipient))
    else
      candidates = candidates.where(patient_id: @patient.id)
    end
    local_day = @site.local_time(@now).to_date
    candidate_ids = candidates.where(visit_date: local_day..(local_day + 30))
      .order(:start_at, :id).limit(30).pluck(:id)
    @site.follow_ups.create!(patient_id: @patient.id, appointment_id: current_visit? ? @visit.id : nil,
      revision: current_visit? ? @visit.revision : nil, issue: "reply_review", reason: @reason,
      message:, candidate_ids:, deduplication_key: "reply:#{message.id}")
  end
end
