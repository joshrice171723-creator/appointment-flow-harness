class WorkflowRejection < StandardError; end
