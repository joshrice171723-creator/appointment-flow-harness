class VerifyPatientContact
  def initialize(site, staff)
    @site = site
    @staff = staff
  end

  def call(patient_id:, field:, value:, expected_source:, event_key:)
    normalized = validate_value(field, value)
    raise WorkflowRejection, "A save reference is required." unless event_key.is_a?(String) && event_key.length.in?(1..80)

    @site.with_lock do
      patient = @site.patients.find(patient_id)
      previous = @site.staff_actions.find_by(event_key:)
      if previous
        verify_replay(previous, patient, field, normalized, expected_source)
        next previous
      end

      source = patient[field]&.to_s
      raise WorkflowRejection, "The PMS value changed. Reload the patient before verifying." unless source == expected_source

      verification = @site.contact_verifications.find_or_initialize_by(patient_id: patient.id, field:)
      channel = field == "wireless_phone" ? "sms" : "email"
      key = ContactPolicy.key(channel, normalized)
      action = @site.staff_actions.create!(patient_id: patient.id, staff_member: @staff, action: "verified",
        event_key:, note: "Verified #{field.humanize.downcase}.",
        details: { field:, source:, prior: verification.value, value: normalized })
      verification.update!(staff_member: @staff, source_value: source, value: normalized, contact_key: key)
      action
    end
  end

  private

  def verify_replay(previous, patient, field, value, source)
    return if previous.action == "verified" && previous.patient_id == patient.id && previous.staff_member_id == @staff.id &&
      previous.details.values_at("field", "value", "source") == [ field, value, source ]

    raise WorkflowRejection, "That save reference is already in use."
  end

  def validate_value(field, value)
    raise WorkflowRejection, "Choose a contact field." unless PmsPatient::CONTACT_FIELDS.include?(field)
    raise WorkflowRejection, "Enter a value of at most 200 characters." unless value.is_a?(String) && value.length <= 200

    value = value.strip
    case field
    when "birthdate"
      date = Date.iso8601(value)
      raise WorkflowRejection, "Enter a valid birthdate." unless date.between?(Date.new(1900), Date.current)
      date.iso8601
    when "preferred_language"
      raise WorkflowRejection, "Choose English or Spanish." unless %w[en es].include?(value.downcase)
      value.downcase
    else
      channel = field == "wireless_phone" ? "sms" : "email"
      raise WorkflowRejection, "Enter a valid demo contact or leave it blank." unless value.empty? || ContactPolicy.key(channel, value)
      value.presence
    end
  rescue Date::Error
    raise WorkflowRejection, "Enter a valid birthdate."
  end
end
