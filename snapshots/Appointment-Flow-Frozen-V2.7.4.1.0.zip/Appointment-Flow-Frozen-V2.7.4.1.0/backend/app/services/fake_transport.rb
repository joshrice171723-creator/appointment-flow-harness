class FakeTransport
  # The persisted message is the simulated dispatch. The adapter has no external side effects.
  def result_for(channel, recipient)
    return "failed" if channel == "sms" && recipient.end_with?("0199")

    "delivered"
  end
end
