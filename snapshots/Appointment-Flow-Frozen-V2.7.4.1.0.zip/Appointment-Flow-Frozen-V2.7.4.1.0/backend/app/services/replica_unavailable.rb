class ReplicaUnavailable < StandardError; end
