class ReminderRun
  FIRST_REQUEST_DAYS = 7
  BACKUP_EMAIL_DAYS = 6
  FOLLOW_UP_DAYS = 3
  FINAL_REMINDER_DAYS = 1
  NO_REPLY_HOURS = 48
  SEND_HOURS = 10...18
  PAGE_SIZE = 200

  def initialize(site, now: Time.current, transport: FakeTransport.new)
    @site = site
    @now = now
    @transport = transport
  end

  def call
    @site.with_lock do
      ensure_replica_present
      @stats = { delivered: 0, failed: 0, follow_ups_created: 0 }
      upcoming_visits.in_batches(of: PAGE_SIZE, load: true) do |batch|
        process_visits(batch.to_a)
      end
      @site.update!(last_synced_at: @now)
      @stats
    end
  end

  private

  def ensure_replica_present
    return if @site.visits.exists?

    raise ReplicaUnavailable, "No PMS appointments were returned for this clinic. The run was canceled."
  end

  def upcoming_visits
    @local_now = @site.local_time(@now)
    first_day = @local_now.to_date
    # Match the numeric wall-clock fields before interpreting any visit as an instant.
    midnight = Time.utc(first_day.year, first_day.month, first_day.day)
    first = midnight + @local_now.seconds_since_midnight
    @site.visits.scheduled.where(start_at: first...(midnight + (FIRST_REQUEST_DAYS + 1).days))
  end

  def process_visits(visits)
    identities = visits.map { |visit| [ visit.id, visit.revision ] }
    current_revision = { [ :appointment_id, :revision ] => identities }
    patients = PmsPatient.where(id: visits.map(&:patient_id).uniq).index_by(&:id)
    contacts = ContactPolicy.new(@site, patients.values)
    decisions = @site.visit_decisions.where(current_revision).pluck(:appointment_id, :revision, :outcome)
      .to_h { |id, revision, outcome| [ [ id, revision ], outcome ] }
    previous = @site.messages.outbound.where(current_revision).pluck(:appointment_id, :revision, :step, :channel, :result)
      .group_by { |id, revision, _step, _channel, _result| [ id, revision ] }
    attempts = []
    tasks = []
    clear_holds = []

    visits.each do |visit|
      identity = [ visit.id, visit.revision ]
      evolve_visit(visit, patients.fetch(visit.patient_id), contacts, decisions[identity],
        previous.fetch(identity, []), attempts, tasks, clear_holds)
    end

    @site.messages.insert_all!(attempts, returning: false) if attempts.any?
    reconcile_follow_ups(tasks, clear_holds)
  end

  def reconcile_follow_ups(tasks, clear_holds)
    keys = tasks.pluck(:deduplication_key) + clear_holds
    return if keys.empty?

    existing = @site.follow_ups.where(deduplication_key: keys).index_by(&:deduplication_key)
    fresh, tracked = tasks.partition { |task| !existing.key?(task.fetch(:deduplication_key)) }
    refresh_contact_holds(tracked, existing)
    if fresh.any?
      @site.follow_ups.insert_all!(fresh, returning: false)
      @stats[:follow_ups_created] += fresh.size
    end
    close_ids = existing.values_at(*clear_holds).compact.reject(&:resolved_at).map(&:id)
    @site.follow_ups.where(id: close_ids).update_all(resolved_at: @now) if close_ids.any?
  end

  def refresh_contact_holds(tasks, existing)
    changes = tasks.select do |task|
      follow_up = existing.fetch(task.fetch(:deduplication_key))
      task[:issue] == "contact_hold" && (follow_up.resolved_at || follow_up.reason != task[:reason])
    end
    changes.group_by { |task| task[:reason] }.each do |reason, holds|
      ids = holds.map { |hold| existing.fetch(hold.fetch(:deduplication_key)).id }
      @site.follow_ups.where(id: ids).update_all(reason:, resolved_at: nil, updated_at: @now)
    end
  end

  def evolve_visit(visit, patient, contacts, decision, previous, attempts, tasks, clear_holds)
    start = @site.visit_instant(visit)
    if start.nil?
      tasks << follow_up(visit, "contact_hold", "The local appointment time needs verification.")
      return
    end
    return if start <= @now || %w[canceled rescheduled].include?(decision)

    confirmed = decision == "confirmed"
    if !confirmed && start - @now <= NO_REPLY_HOURS.hours
      tasks << follow_up(visit, "no_reply", "This appointment starts within 48 hours and needs confirmation.")
    end

    hold = contacts.hold_reason(patient, @local_now.to_date)
    sms = contacts.allowed_recipient(patient, "sms")
    email = contacts.allowed_recipient(patient, "email")
    if hold || (sms.nil? && email.nil?)
      tasks << follow_up(visit, "contact_hold", hold || "No permitted text or email contact is available.")
      return
    end
    clear_holds << task_key(visit, "contact_hold")
    return unless SEND_HOURS.cover?(@local_now.hour)

    days = (visit.visit_date - @local_now.to_date).to_i
    step = reminder_step(days, confirmed, sms, email)
    return unless step
    return if previous.any? { |row| row[2] == step }

    sms_failed = previous.any? { |row| row[3] == "sms" && row[4] == "failed" }
    channel = step == "backup_email" || sms.nil? || (sms_failed && email) ? "email" : "sms"
    recipient = channel == "sms" ? sms : email
    result = @transport.result_for(channel, recipient)
    @stats[result.to_sym] += 1
    attempts << visit.identity.merge(patient_id: patient.id, channel:, recipient:, result:, step:,
      direction: "outbound", body: reminder_body(visit, contacts.language(patient), channel, confirmed), occurred_at: @now)
    if result == "failed"
      tasks << follow_up(visit, "delivery_failed", "The simulated delivery failed.")
    end
  end

  def reminder_step(days, confirmed, sms, email)
    return "final" if days <= FINAL_REMINDER_DAYS
    return if confirmed
    return "follow_up" if days <= FOLLOW_UP_DAYS
    return "initial" if sms.nil? || email.nil? || days > BACKUP_EMAIL_DAYS

    "backup_email"
  end

  def reminder_body(visit, language, channel, confirmed)
    day = visit.start_at.strftime("%Y-%m-%d")
    time = visit.start_at.strftime("%l:%M %p").strip
    name = @clinic_name ||= @site.clinic.name
    if language == "es"
      text = "Su cita en #{name} es el #{day} a las #{time}."
      text += " Responda YES para confirmar o NO para recibir ayuda." unless confirmed
      text += " Responda STOP para cancelar los mensajes de texto." if channel == "sms"
    else
      text = "Your appointment at #{name} is on #{day} at #{time}."
      text += " Reply YES to confirm or NO for help." unless confirmed
      text += " Reply STOP to opt out of texts." if channel == "sms"
    end
    text
  end

  def task_key(visit, issue)
    "#{visit.id}:#{visit.revision}:#{issue}"
  end

  def follow_up(visit, issue, reason)
    visit.identity.merge(patient_id: visit.patient_id, issue:, reason:, deduplication_key: task_key(visit, issue))
  end
end
