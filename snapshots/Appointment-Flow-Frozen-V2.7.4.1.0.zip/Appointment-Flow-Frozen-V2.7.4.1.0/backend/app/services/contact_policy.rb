class ContactPolicy
  Facts = Data.define(:patient, :values, :verifications)

  def self.key(channel, value)
    return if value.blank?

    case channel
    when "sms"
      return unless value.match?(/\A(?:\+1[ .-]?)?[\d ().-]+\z/)

      number = value.gsub(/\D/, "").sub(/\A1(?=\d{10}\z)/, "")
      number if number.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
    when "email"
      address = value.strip.downcase
      address if address.match?(URI::MailTo::EMAIL_REGEXP) && address.end_with?(".test")
    end
  end

  def self.field(channel)
    channel == "sms" ? "wireless_phone" : "email"
  end

  def self.facts(patient, verifications)
    values = PmsPatient::CONTACT_FIELDS.to_h { |field| [ field, patient[field]&.to_s ] }
    verifications.each_value do |verification|
      next unless values[verification.field] == verification.source_value

      values[verification.field] = verification.value
    end
    Facts.new(patient:, values:, verifications:)
  end

  def initialize(site, patients)
    verifications = site.contact_verifications.where(patient_id: patients.map(&:id)).group_by(&:patient_id)
    @facts = patients.index_with do |patient|
      self.class.facts(patient, verifications.fetch(patient.id, []).index_by(&:field))
    end
    @source_counts = {}
    @verified_counts = {}
    Message::CHANNELS.each { |channel| load_contact_counts(channel) }

    suppressions = sms_suppressions(site, patients.map(&:id))
    @suppressed_patients = suppressions.map(&:first).to_set
    @suppressed_recipients = suppressions.map(&:last).to_set
  end

  def recipient(patient, channel)
    self.class.key(channel, @facts.fetch(patient).values.fetch(self.class.field(channel)))
  end

  def language(patient)
    @facts.fetch(patient).values.fetch("preferred_language").to_s.downcase
  end

  def hold_reason(patient, local_date)
    facts = @facts.fetch(patient)
    if facts.verifications.any? { |field, verification| patient[field]&.to_s != verification.source_value }
      return "Verified contact details differ from the PMS. Review the source and local values."
    end

    birthdate = facts.values.fetch("birthdate")
    return "Verify the patient's birthdate." if birthdate.blank?
    adulthood_cutoff = local_date << (18 * 12)
    return "Verify guardian authorization before outreach." if Date.iso8601(birthdate) > adulthood_cutoff
    return "Verify the patient's preferred language." unless %w[en es].include?(language(patient))

    "A contact is shared with another patient." if Message::CHANNELS.any? { |channel| shared?(patient, channel) }
  end

  def allowed_recipient(patient, channel)
    value = recipient(patient, channel)
    return if value.nil? || shared?(patient, channel)
    return if channel == "sms" && (@suppressed_patients.include?(patient.id) || @suppressed_recipients.include?(value))

    value
  end

  def shared?(patient, channel)
    value = recipient(patient, channel)
    return false if value.nil?

    source_key = patient["#{channel}_key"]
    source_matches = @source_counts.fetch(channel).fetch(value, 0)
    verified_matches = @verified_counts.fetch(channel).fetch(value, Set.new)
    source_matches > (source_key == value ? 1 : 0) || verified_matches.any? { |id| id != patient.id }
  end

  def self.matching_patient_ids(channel, value)
    source = directory_matches(channel, value).select(:id)
    verified = ContactVerification.where(field: field(channel), contact_key: value).select(:patient_id)
    PmsPatient.where(id: source).or(PmsPatient.where(id: verified)).select(:id)
  end

  def self.directory_matches(channel, keys)
    channel == "sms" ? PmsPatient.where(sms_key: keys) : PmsPatient.where(email_key: keys)
  end
  private_class_method :directory_matches

  private

  def sms_suppressions(site, patient_ids)
    sms_keys = keys("sms")
    return [] if sms_keys.empty?

    opt_outs = site.sms_opt_outs.where(patient_id: patient_ids)
      .or(site.sms_opt_outs.where(recipient: sms_keys)).pluck(:patient_id, :recipient)
    messages = site.messages.where(channel: "sms", direction: "inbound")
    pending_reviews = messages.where(patient_id: patient_ids).or(messages.where(recipient: sms_keys))
      .joins(:follow_ups).where(follow_ups: { reason: FollowUp::SMS_OPT_OUT_REVIEW, resolved_at: nil })
      .distinct.pluck(:patient_id, :recipient)
    opt_outs + pending_reviews
  end

  def keys(channel)
    @facts.keys.filter_map { |patient| recipient(patient, channel) }.uniq
  end

  def load_contact_counts(channel)
    contacts = keys(channel)
    @source_counts[channel] = if channel == "sms"
      PmsPatient.where(sms_key: contacts).group(:sms_key).count
    else
      PmsPatient.where(email_key: contacts).group(:email_key).count
    end
    @verified_counts[channel] = ContactVerification.where(field: self.class.field(channel), contact_key: contacts)
      .pluck(:contact_key, :patient_id).each_with_object({}) do |(key, patient_id), matches|
        (matches[key] ||= Set.new).add(patient_id)
      end
  end
end
