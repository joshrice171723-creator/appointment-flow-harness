class PmsClinic < PmsRecord
  self.table_name = "pms.clinics"
end
