class PatientSearch < PmsRecord
  self.table_name = "pms.patient_search"

  def self.starting_with(query)
    prefix = query.downcase...("#{query.downcase}\u{10ffff}")
    where(first_last: prefix).or(where(last_name: prefix))
  end
end
