class Site < ApplicationRecord
  belongs_to :clinic, class_name: "PmsClinic", foreign_key: :id
  has_many :staff_members
  has_many :messages
  has_many :visit_decisions
  has_many :follow_ups
  has_many :contact_verifications
  has_many :sms_opt_outs
  has_many :staff_actions
  has_many :visits, class_name: "PmsVisit", foreign_key: :clinic_id

  def patients
    PmsPatient.where(id: visits.select(:patient_id))
  end

  def local_time(instant)
    instant.in_time_zone(timezone)
  end

  def visit_instant(visit)
    # The adapter reads this timestamp without zone as UTC-shaped wall-clock fields.
    TZInfo::Timezone.get(timezone).local_to_utc(visit.start_at, nil)
  rescue TZInfo::PeriodNotFound, TZInfo::AmbiguousTime
    nil
  end
end
