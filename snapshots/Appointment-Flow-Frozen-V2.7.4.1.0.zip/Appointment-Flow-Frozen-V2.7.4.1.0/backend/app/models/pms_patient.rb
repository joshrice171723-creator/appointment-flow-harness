class PmsPatient < PmsRecord
  self.table_name = "pms.directory"
  self.primary_key = :id

  CONTACT_FIELDS = %w[birthdate wireless_phone email preferred_language].freeze

  def full_name
    "#{first_name} #{last_name}"
  end
end
