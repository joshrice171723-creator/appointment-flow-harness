class PmsVisit < PmsRecord
  self.table_name = "pms.visits"
  self.primary_key = :id

  belongs_to :patient, class_name: "PmsPatient"
  scope :scheduled, -> { where(status: "scheduled") }

  def identity
    { appointment_id: id, revision: revision }
  end

  def wall_time
    start_at.strftime("%Y-%m-%dT%H:%M:%S")
  end
end
