class StaffMember < ApplicationRecord
  belongs_to :site
end
