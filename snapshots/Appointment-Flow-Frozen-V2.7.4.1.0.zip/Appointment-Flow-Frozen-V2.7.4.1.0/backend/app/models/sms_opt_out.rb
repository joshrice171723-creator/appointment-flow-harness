class SmsOptOut < ApplicationRecord
  belongs_to :site
end
