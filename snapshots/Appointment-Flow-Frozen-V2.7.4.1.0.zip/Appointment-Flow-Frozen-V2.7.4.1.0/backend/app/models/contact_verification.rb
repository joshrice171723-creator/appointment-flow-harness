class ContactVerification < ApplicationRecord
  belongs_to :site
  belongs_to :staff_member
end
