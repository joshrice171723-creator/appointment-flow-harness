class WorkspaceVisit < PmsVisit
  self.table_name = "workspace_visits"

  OUTCOMES = { "complete" => "completed", "broken" => "canceled", "unscheduled" => "rescheduled" }.freeze

  def self.on_days(first, last = first)
    from = Time.utc(first.year, first.month, first.day)
    through = Time.utc(last.year, last.month, last.day)
    where(start_at: from...(through + 1.day))
  end

  def as_payload
    {
      id: id, revision:, patient_id:, patient: patient.full_name, start_at: wall_time, provider: provider_name,
      minutes: length_minutes, confirmation: decision || "unconfirmed", reply_review:,
      outcome: OUTCOMES.fetch(status, "unknown")
    }
  end
end
