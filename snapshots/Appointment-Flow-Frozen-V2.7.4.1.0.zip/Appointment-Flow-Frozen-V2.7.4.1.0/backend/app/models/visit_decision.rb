class VisitDecision < ApplicationRecord
  belongs_to :site
end
