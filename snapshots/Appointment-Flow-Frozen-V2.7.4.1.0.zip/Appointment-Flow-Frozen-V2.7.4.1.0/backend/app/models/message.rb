class Message < ApplicationRecord
  CHANNELS = %w[sms email].freeze

  belongs_to :site
  has_many :follow_ups
  scope :outbound, -> { where(direction: "outbound") }
  scope :delivered, -> { outbound.where(result: "delivered") }
end
