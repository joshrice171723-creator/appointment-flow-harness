class StaffAction < ApplicationRecord
  belongs_to :site
  belongs_to :staff_member
  belongs_to :follow_up, optional: true
end
