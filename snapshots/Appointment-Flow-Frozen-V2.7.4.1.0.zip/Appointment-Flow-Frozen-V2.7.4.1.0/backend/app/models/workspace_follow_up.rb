class WorkspaceFollowUp < PmsRecord
  self.table_name = "workspace_follow_ups"
  self.primary_key = :id

  QUEUES = %w[needs_attention in_progress resolved].freeze

  belongs_to :patient, class_name: "PmsPatient"
  belongs_to :staff_member, optional: true
  belongs_to :message, optional: true

  def as_payload
    {
      id: id, patient_id:, patient: patient.full_name, issue:, reason:, queue:, staff_id: staff_member_id,
      assignee: staff_member&.name, appointment_id:, revision:, created_at:
    }
  end
end
