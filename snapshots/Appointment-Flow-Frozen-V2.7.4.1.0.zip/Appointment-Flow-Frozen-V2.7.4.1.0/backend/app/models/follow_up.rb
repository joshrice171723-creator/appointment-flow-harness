class FollowUp < ApplicationRecord
  ISSUES = %w[no_reply contact_hold delivery_failed reply_review].freeze
  SMS_OPT_OUT_REVIEW = "The text may be an opt-out request. Review it before sending more texts."

  belongs_to :site
  belongs_to :message, optional: true
  belongs_to :staff_member, optional: true
end
