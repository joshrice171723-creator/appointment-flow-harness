class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "This record is unavailable in the selected clinic." }, status: :not_found
  end

  rescue_from WorkflowRejection, ActionController::ParameterMissing do |error|
    render json: { error: error.message }, status: :unprocessable_entity
  end

  rescue_from ReplicaUnavailable, ActiveRecord::ConnectionNotEstablished, ActiveRecord::QueryCanceled do
    render json: { error: "The PMS refresh could not be completed. Try again after the source is available." },
      status: :service_unavailable
  end
end
