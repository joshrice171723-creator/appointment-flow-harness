module Api
  class RepliesController < SiteController
    def create
      attributes = params.expect(reply: %i[channel body event_key message_id])
      reply = PatientReply.new(@site, channel: attributes[:channel], body: attributes[:body], event_key: attributes[:event_key])
        .call(patient_id: params[:inbox_id], message_id: attributes[:message_id])
      render json: { id: reply.id, result: reply.result }, status: :created
    end
  end
end
