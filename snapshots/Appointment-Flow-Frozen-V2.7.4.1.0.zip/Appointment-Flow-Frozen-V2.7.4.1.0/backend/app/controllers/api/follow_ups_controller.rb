module Api
  class FollowUpsController < StaffController
    PAGE_SIZE = 16

    def index
      clinic_tasks = WorkspaceFollowUp.where(site_id: @site.id)
      visible_tasks = filter(clinic_tasks)
      rows = visible_tasks.order(created_at: :desc, id: :desc).offset((page - 1) * PAGE_SIZE).limit(PAGE_SIZE + 1)
        .preload(:patient, :staff_member).to_a
      render json: site_metadata.merge(totals: clinic_tasks.group(:queue).count,
        rows: rows.first(PAGE_SIZE).map(&:as_payload), page:, more: rows.size > PAGE_SIZE)
    end

    def update
      task = StaffFollowUp.new(@site, @staff).claim(params[:id])
      render json: { id: task.id, staff_id: task.staff_member_id }
    end

    private

    def filter(tasks)
      queue = params[:queue]
      tasks = tasks.where(queue: queue) if WorkspaceFollowUp::QUEUES.include?(queue)
      tasks = tasks.where.not(queue: "resolved") if queue.blank? || queue == "active"
      tasks = tasks.where(issue: params[:issue]) if FollowUp::ISSUES.include?(params[:issue])
      search = params[:q].to_s.strip.first(80)
      tasks = tasks.where(patient_id: PatientSearch.starting_with(search).select(:id)) if search.present?
      tasks
    end
  end
end
