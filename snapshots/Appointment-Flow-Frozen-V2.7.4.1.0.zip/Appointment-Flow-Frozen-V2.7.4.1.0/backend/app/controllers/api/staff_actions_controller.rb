module Api
  class StaffActionsController < StaffController
    def create
      request_data = params.expect(action_record: [ :outcome, :note, :event_key, visits: [ [ :id, :revision ] ] ])
      visits = (request_data[:visits] || []).to_h { |entry| [ entry[:id].to_s, entry[:revision] ] }
      raise WorkflowRejection, "Select at most 30 appointments." if visits.size > 30

      action = StaffFollowUp.new(@site, @staff).record(params[:follow_up_id], outcome: request_data[:outcome],
        note: request_data[:note], event_key: request_data[:event_key], targets: visits)
      render json: { id: action.id, action: action.action }, status: :created
    end
  end
end
