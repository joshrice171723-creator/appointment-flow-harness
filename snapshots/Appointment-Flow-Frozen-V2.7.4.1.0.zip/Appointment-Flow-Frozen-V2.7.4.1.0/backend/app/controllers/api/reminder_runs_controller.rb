module Api
  class ReminderRunsController < StaffController
    def create
      render json: ReminderRun.new(@site).call, status: :created
    end
  end
end
