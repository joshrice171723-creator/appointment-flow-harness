module Api
  class ContactVerificationsController < StaffController
    def update
      attributes = params.expect(verification: %i[field value expected_source event_key])
      action = VerifyPatientContact.new(@site, @staff).call(patient_id: params[:patient_id],
        field: attributes[:field], value: attributes[:value], expected_source: attributes[:expected_source],
        event_key: attributes[:event_key])
      render json: { id: action.id, action: action.action }
    end
  end
end
