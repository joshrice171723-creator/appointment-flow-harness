module Api
  class SiteController < ApplicationController
    before_action :load_site

    private

    def load_site
      @site = Site.find(params[:site_id])
      response.headers["Cache-Control"] = "no-store"
    end

    def page
      params[:page].to_s.to_i.clamp(1, 1000)
    end

    def iso_date(value, fallback)
      return fallback if value.blank?

      Date.iso8601(value)
    rescue Date::Error, TypeError
      raise WorkflowRejection, "Choose a valid date."
    end

    def site_metadata
      { today: @site.local_time(Time.current).to_date, timezone: @site.timezone, last_synced_at: @site.last_synced_at }
    end
  end
end
