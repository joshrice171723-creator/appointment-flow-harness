module Api
  class PatientsController < StaffController
    def show
      patient = @site.patients.find(params[:id])
      visits = WorkspaceVisit.where(clinic_id: @site.id, patient_id: patient.id).preload(:patient)
      now = @site.local_time(Time.current)
      upcoming = visits.scheduled.where(start_at: Time.utc(now.year, now.month, now.day, now.hour, now.min, now.sec)..)
        .where(decision: [ nil, "confirmed" ]).order(:start_at, :id).first
      tasks = WorkspaceFollowUp.where(site_id: @site.id, patient_id: patient.id).order(created_at: :desc, id: :desc)
        .limit(30).preload(:patient, :staff_member, :message)
      render json: site_metadata.merge(patient: { id: patient.id, name: patient.full_name },
        contacts: contacts(patient), next_visit: upcoming&.as_payload,
        visits: visits.order(start_at: :desc, id: :desc).limit(30).map(&:as_payload),
        tasks: task_payloads(tasks), activity: activity(patient.id))
    end

    private

    def contacts(patient)
      verifications = @site.contact_verifications.where(patient_id: patient.id).preload(:staff_member).index_by(&:field)
      facts = ContactPolicy.facts(patient, verifications)
      PmsPatient::CONTACT_FIELDS.map do |field|
        raw = patient[field]&.to_s
        verified = verifications[field]
        { field:, source: raw, value: facts.values[field], verified_value: verified&.value,
          status: !verified ? "unverified" : (raw == verified.source_value ? "verified" : "conflict"),
          verified_by: verified&.staff_member&.name, verified_at: verified&.updated_at }
      end
    end

    def task_payloads(tasks)
      entries = tasks.to_a
      ids = entries.flat_map { |task| task.candidate_ids.presence || [ task.appointment_id ].compact }.uniq
      visits = WorkspaceVisit.where(clinic_id: @site.id, id: ids).preload(:patient).index_by(&:id)
      entries.map do |task|
        candidates = task.candidate_ids.presence || [ task.appointment_id ].compact
        task.as_payload.merge(candidates: candidates.filter_map { |id| visits[id]&.as_payload }, reply: task.message&.body)
      end
    end

    def activity(patient_id)
      @site.staff_actions.where(patient_id:).order(created_at: :desc, id: :desc).limit(30).preload(:staff_member).map do |event|
        { id: event.id, action: event.action, note: event.note, staff: event.staff_member.name, created_at: event.created_at }
      end
    end
  end
end
