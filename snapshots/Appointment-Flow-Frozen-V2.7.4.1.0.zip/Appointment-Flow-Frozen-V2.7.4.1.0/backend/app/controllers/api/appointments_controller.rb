module Api
  class AppointmentsController < StaffController
    PAGE_SIZE = 25

    def index
      date = iso_date(params[:date], @site.local_time(Time.current).to_date)
      week_start = date.beginning_of_week
      clinic_visits = WorkspaceVisit.where(clinic_id: @site.id)
      day_visits = clinic_visits.on_days(date)
      visible_visits = filter(day_visits)
      rows = visible_visits.order(:start_at, :id).offset((page - 1) * PAGE_SIZE).limit(PAGE_SIZE + 1)
        .preload(:patient).to_a
      render json: site_metadata.merge(date:, calendar: clinic_visits.on_days(week_start, week_start + 6).group(:visit_date).count,
        totals: totals(day_visits), rows: rows.first(PAGE_SIZE).map(&:as_payload), page:, more: rows.size > PAGE_SIZE)
    end

    private

    def filter(visits)
      case params[:filter]
      when "confirmed" then visits.where(decision: "confirmed")
      when "unconfirmed" then visits.where(decision: nil)
      when "review" then visits.where(reply_review: true)
      else visits
      end
    end

    def totals(visits)
      counts = visits.group(:decision, :reply_review).count
      {
        all: counts.values.sum,
        confirmed: counts.sum { |(decision, _review), count| decision == "confirmed" ? count : 0 },
        unconfirmed: counts.sum { |(decision, _review), count| decision.nil? ? count : 0 },
        review: counts.sum { |(_decision, review), count| review ? count : 0 }
      }
    end
  end
end
