module Api
  class StaffController < SiteController
    before_action :load_staff

    private

    def load_staff
      @staff = @site.staff_members.find(request.headers["X-Demo-Staff"])
    end
  end
end
