module Api
  class WorkspacesController < ApplicationController
    def index
      sites = Site.includes(:clinic, :staff_members).order(:id)
      render json: { sites: sites.map { |site| site_payload(site) } }
    end

    private

    def site_payload(site)
      clinic = site.clinic
      { id: site.id, name: clinic.name, location: [ clinic.city, clinic.state ].compact.join(", "),
        staff: site.staff_members.sort_by(&:id).map { |staff| { id: staff.id, name: staff.name } } }
    end
  end
end
