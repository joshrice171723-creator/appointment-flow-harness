module ReplicaFixtures
  class Clinic < ApplicationRecord
    self.table_name = "pms.clinics"
  end

  class Patient < ApplicationRecord
    self.table_name = "pms.patients"
  end

  class Appointment < ApplicationRecord
    self.table_name = "pms.appointments"
    self.record_timestamps = false
  end

  def self.write
    ApplicationRecord.transaction(requires_new: true) do
      ApplicationRecord.with_connection do |connection|
        connection.execute("SET LOCAL apex.replica_fixture_write = 'on'")
        result = yield
        connection.execute("SET LOCAL apex.replica_fixture_write = 'off'")
        result
      end
    end
  end
end
