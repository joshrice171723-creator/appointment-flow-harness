class CreateWorkflow < ActiveRecord::Migration[8.1]
  def change
    create_table :sites do |t|
      t.string :timezone, null: false
      t.datetime :last_synced_at
    end

    create_table :staff_members do |t|
      t.references :site, null: false, foreign_key: true
      t.string :name, null: false
    end

    create_table :visit_decisions do |t|
      t.belongs_to :site, null: false, foreign_key: true
      t.bigint :appointment_id, null: false
      t.string :revision, null: false
      t.string :outcome, null: false
      t.timestamps
      t.index [ :site_id, :appointment_id, :revision ], unique: true
      t.check_constraint "outcome IN ('confirmed', 'rescheduled', 'canceled')", name: "valid_visit_decision"
    end

    create_table :messages do |t|
      t.belongs_to :site, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.bigint :appointment_id
      t.string :revision
      t.string :channel, null: false
      t.string :recipient
      t.string :direction, null: false
      t.string :step
      t.string :result, null: false
      t.string :event_key
      t.text :body, null: false
      t.datetime :occurred_at, null: false
      t.index [ :site_id, :patient_id, :channel, :occurred_at, :id ], name: "index_messages_for_inbox"
      t.index [ :site_id, :appointment_id, :revision, :step ], unique: true, name: "index_messages_once_per_step"
      t.index [ :site_id, :event_key ], unique: true
      t.check_constraint "channel IN ('sms', 'email')", name: "valid_message_channel"
      t.check_constraint "direction IN ('outbound', 'inbound')", name: "valid_message_direction"
    end

    create_table :sms_opt_outs do |t|
      t.belongs_to :site, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.string :recipient, null: false
      t.datetime :created_at, null: false
      t.index [ :site_id, :recipient, :patient_id ], unique: true
      t.index [ :site_id, :patient_id ]
    end

    create_table :contact_verifications do |t|
      t.belongs_to :site, null: false, foreign_key: true
      t.belongs_to :staff_member, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.string :field, null: false
      t.string :source_value
      t.string :value
      t.string :contact_key
      t.timestamps
      t.index [ :site_id, :patient_id, :field ], unique: true, name: "index_current_contact_verification"
      t.index [ :field, :contact_key ]
    end

    create_table :follow_ups do |t|
      t.belongs_to :site, null: false, foreign_key: true
      t.belongs_to :staff_member, foreign_key: true
      t.belongs_to :message, foreign_key: true
      t.bigint :patient_id, null: false
      t.bigint :appointment_id
      t.string :revision
      t.bigint :candidate_ids, array: true, null: false, default: []
      t.string :issue, null: false
      t.string :reason, null: false
      t.string :deduplication_key, null: false
      t.datetime :resolved_at
      t.timestamps
      t.index [ :site_id, :deduplication_key ], unique: true
      t.index [ :site_id, :resolved_at, :created_at, :id ], name: "index_follow_ups_for_board"
      t.index [ :site_id, :patient_id, :created_at ]
      t.index [ :site_id, :appointment_id, :revision, :issue ]
    end

    create_table :staff_actions do |t|
      t.belongs_to :site, null: false, foreign_key: true
      t.belongs_to :staff_member, null: false, foreign_key: true
      t.belongs_to :follow_up, foreign_key: true
      t.bigint :patient_id, null: false
      t.string :action, null: false
      t.string :event_key, null: false
      t.text :note, null: false
      t.datetime :created_at, null: false
      t.index [ :site_id, :event_key ], unique: true
      t.index [ :site_id, :patient_id, :created_at ]
    end
  end
end
