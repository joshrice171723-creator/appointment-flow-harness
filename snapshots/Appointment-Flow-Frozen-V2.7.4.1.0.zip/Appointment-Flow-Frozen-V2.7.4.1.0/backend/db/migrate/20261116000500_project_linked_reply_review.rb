class ProjectLinkedReplyReview < ActiveRecord::Migration[8.1]
  def up
    add_index :follow_ups, :candidate_ids, using: :gin, where: "issue = 'reply_review' AND resolved_at IS NULL"
    add_index :messages, [ :site_id, :recipient ], name: "index_inbound_sms_by_recipient",
      where: "direction = 'inbound' AND channel = 'sms'"
    define_visits_with_review("OR f.candidate_ids @> ARRAY[v.id]")
  end

  def down
    define_visits_with_review("")
    remove_index :follow_ups, :candidate_ids
    remove_index :messages, name: "index_inbound_sms_by_recipient"
  end

  private

  def define_visits_with_review(candidate_match)
    execute <<~SQL
      CREATE OR REPLACE VIEW workspace_visits AS
      SELECT v.*, decision.outcome AS decision,
             EXISTS (
               SELECT 1 FROM follow_ups f
               WHERE f.site_id = v.clinic_id AND f.issue = 'reply_review' AND f.resolved_at IS NULL
                 AND ((f.appointment_id = v.id AND f.revision = v.revision) #{candidate_match})
             ) AS reply_review
      FROM pms.visits v
      LEFT JOIN visit_decisions decision
        ON decision.site_id = v.clinic_id AND decision.appointment_id = v.id AND decision.revision = v.revision;
    SQL
  end
end
