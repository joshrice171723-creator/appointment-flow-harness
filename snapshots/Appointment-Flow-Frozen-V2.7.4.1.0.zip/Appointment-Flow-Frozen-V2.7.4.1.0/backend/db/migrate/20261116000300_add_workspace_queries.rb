class AddWorkspaceQueries < ActiveRecord::Migration[8.1]
  def up
    add_column :messages, :in_reply_to_id, :bigint
    add_foreign_key :messages, :messages, column: :in_reply_to_id
    add_column :staff_actions, :details, :jsonb, null: false, default: {}
    add_foreign_key :sites, "pms.clinics", column: :id
    add_index :messages, [ :occurred_at, :site_id, :direction, :result ], name: "index_message_activity"
    add_index :follow_ups, [ :created_at, :site_id, :issue ], name: "index_follow_up_activity"
    add_index :staff_actions, [ :created_at, :site_id, :action ], name: "index_staff_activity"

    execute <<~SQL
      CREATE VIEW workspace_visits AS
      SELECT v.*, decision.outcome AS decision,
             EXISTS (
               SELECT 1 FROM follow_ups f
               WHERE f.site_id = v.clinic_id AND f.appointment_id = v.id AND f.revision = v.revision
                 AND f.issue = 'reply_review' AND f.resolved_at IS NULL
             ) AS reply_review
      FROM pms.visits v
      LEFT JOIN visit_decisions decision
        ON decision.site_id = v.clinic_id AND decision.appointment_id = v.id AND decision.revision = v.revision;

      CREATE VIEW workspace_follow_ups AS
      SELECT f.*,
             CASE
               WHEN f.resolved_at IS NOT NULL THEN 'resolved'
               WHEN f.issue <> 'reply_review' AND v.id IS NOT NULL
                 AND (v.revision <> f.revision OR v.status <> 'scheduled') THEN 'resolved'
               WHEN f.staff_member_id IS NOT NULL THEN 'in_progress'
               ELSE 'needs_attention'
             END AS queue
      FROM follow_ups f
      LEFT JOIN pms.visits v ON v.id = f.appointment_id AND v.clinic_id = f.site_id;

      CREATE VIEW pms.patient_search AS
      SELECT id, lower(first_name || ' ' || last_name) COLLATE "C" AS first_last,
             lower(last_name) COLLATE "C" AS last_name
      FROM pms.patients;
      CREATE INDEX replica_patients_first_last ON pms.patients ((lower(first_name || ' ' || last_name) COLLATE "C"));
      CREATE INDEX replica_patients_last_name ON pms.patients ((lower(last_name) COLLATE "C"));
    SQL
  end

  def down
    execute "DROP VIEW workspace_visits, workspace_follow_ups, pms.patient_search"
    execute "DROP INDEX pms.replica_patients_first_last, pms.replica_patients_last_name"
    remove_index :messages, name: "index_message_activity"
    remove_index :follow_ups, name: "index_follow_up_activity"
    remove_index :staff_actions, name: "index_staff_activity"
    remove_foreign_key :sites, "pms.clinics", column: :id
    remove_foreign_key :messages, column: :in_reply_to_id
    remove_column :messages, :in_reply_to_id
    remove_column :staff_actions, :details
  end
end
