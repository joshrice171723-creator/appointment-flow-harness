class AlignReplicaEmailNormalization < ActiveRecord::Migration[8.1]
  def up
    execute <<~SQL
      CREATE FUNCTION pms.email_key(value text) RETURNS text
      LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE AS $$
        SELECT lower(regexp_replace(value, '^[[:space:]]+|[[:space:]]+$', '', 'g') COLLATE "C")
      $$;
      DROP INDEX pms.replica_patient_email;
      CREATE INDEX replica_patient_email ON pms.patients (pms.email_key(email));
    SQL
    define_directory_email("pms.email_key(email)")
  end

  def down
    define_directory_email("lower(btrim(email))")
    execute <<~SQL
      DROP INDEX pms.replica_patient_email;
      DROP FUNCTION pms.email_key(text);
      CREATE INDEX replica_patient_email ON pms.patients (lower(btrim(email)));
    SQL
  end

  private

  def define_directory_email(expression)
    execute <<~SQL
      CREATE OR REPLACE VIEW pms.directory AS
      SELECT p.*, pms.sms_key(wireless_phone) AS sms_key, #{expression} AS email_key,
             lower(last_name || ', ' || first_name) AS search_name
      FROM pms.patients p;
    SQL
  end
end
