class CreateReplica < ActiveRecord::Migration[8.1]
  def up
    create_schema :pms
    create_table "pms.clinics" do |t|
      t.text :name, null: false
      t.text :address_line
      t.text :city
      t.column :state, "char(2)"
      t.text :phone
    end
    create_table "pms.patients" do |t|
      t.text :first_name, null: false
      t.text :last_name, null: false
      t.date :birthdate
      t.text :wireless_phone
      t.text :email
      t.text :preferred_language
      t.bigint :guarantor_id
    end
    add_foreign_key "pms.patients", "pms.patients", column: :guarantor_id

    create_table "pms.appointments" do |t|
      t.bigint :patient_id, null: false
      t.bigint :clinic_id, null: false
      t.text :provider_name
      t.timestamp :start_at, null: false
      t.integer :length_minutes
      t.text :procedure_note
      t.text :status, null: false
      t.timestamp :updated_at
      t.index [ :clinic_id, :start_at, :id ]
      t.index [ :clinic_id, :status, :start_at, :id ]
      t.index [ :clinic_id, :patient_id, :start_at ]
    end
    add_foreign_key "pms.appointments", "pms.patients", column: :patient_id
    add_foreign_key "pms.appointments", "pms.clinics", column: :clinic_id

    install_replica_write_guard
    create_contact_directory
    create_visit_projection
  end

  def down
    execute "DROP SCHEMA pms CASCADE"
  end

  private

  def install_replica_write_guard
    execute <<~SQL
      CREATE FUNCTION pms.reject_application_writes() RETURNS trigger LANGUAGE plpgsql AS $$
      BEGIN
        IF current_setting('apex.replica_fixture_write', true) IS DISTINCT FROM 'on' THEN
          RAISE EXCEPTION 'The PMS replica is read-only';
        END IF;
        RETURN NULL;
      END;
      $$;
    SQL
    %w[clinics patients appointments].each do |table|
      execute <<~SQL
        CREATE TRIGGER read_only_replica BEFORE INSERT OR UPDATE OR DELETE OR TRUNCATE ON pms.#{table}
        FOR EACH STATEMENT EXECUTE FUNCTION pms.reject_application_writes()
      SQL
    end
  end

  def create_contact_directory
    execute <<~SQL
      CREATE FUNCTION pms.sms_key(value text) RETURNS text
      LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE AS $$
        SELECT CASE WHEN digits LIKE '1__________' THEN substr(digits, 2) ELSE digits END
        FROM (SELECT regexp_replace(value, '[^0-9]', '', 'g') AS digits) cleaned
      $$;
      CREATE INDEX replica_patient_sms ON pms.patients (pms.sms_key(wireless_phone));
      CREATE INDEX replica_patient_email ON pms.patients (lower(btrim(email)));
      CREATE INDEX replica_patient_name ON pms.patients (lower(last_name || ', ' || first_name));

      CREATE VIEW pms.directory AS
      SELECT p.*, pms.sms_key(wireless_phone) AS sms_key, lower(btrim(email)) AS email_key,
             lower(last_name || ', ' || first_name) AS search_name
      FROM pms.patients p;
    SQL
  end

  def create_visit_projection
    execute <<~SQL
      CREATE VIEW pms.visits AS
      SELECT a.id, a.clinic_id, a.patient_id, a.provider_name, a.start_at, a.length_minutes, a.status,
             md5(concat_ws('|', a.clinic_id, a.patient_id, a.start_at, a.updated_at)) AS revision,
             a.start_at::date AS visit_date
      FROM pms.appointments a;
    SQL
  end
end
