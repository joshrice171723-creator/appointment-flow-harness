require Rails.root.join("db/support/replica_fixtures")

sites = [
  { id: 101, name: "Austin", city: "Austin", state: "TX", timezone: "America/Chicago",
    staff: [ "Taylor Morgan", "Jordan Ellis" ] },
  { id: 102, name: "Phoenix", city: "Phoenix", state: "AZ", timezone: "America/Phoenix",
    staff: [ "Alex Rivera", "Casey Brooks" ] }
]
names = [ [ "Avery", "Lane" ], [ "Elena", "Vega" ], [ "Jamie", "Kim" ], [ "Riley", "Park" ],
          [ "Micah", "Shaw" ], [ "Quinn", "Stone" ], [ "Devon", "Reed" ], [ "Robin", "Cole" ],
          [ "Morgan", "Fox" ], [ "Sam", "Hart" ], [ "Blair", "Wu" ], [ "Parker", "Lake" ] ]

sites.each do |data|
  id = data.fetch(:id)
  clinic_day = Time.current.in_time_zone(data.fetch(:timezone)).to_date
  demo_clock = Time.use_zone(data.fetch(:timezone)) { Time.zone.local(clinic_day.year, clinic_day.month, clinic_day.day, 11, 30) }
  patients = names.each_with_index.map do |(first, last), index|
    phone = if index == 1
      nil
    elsif index == 4
      "#{data[:state] == 'TX' ? '512' : '602'}-555-0199"
    else
      "#{data[:state] == 'TX' ? '512' : '602'}-555-01#{format('%02d', index)}"
    end
    { id: id * 100 + index, first_name: first, last_name: last,
      birthdate: index == 2 ? nil : (index == 6 ? clinic_day - 12.years : Date.new(1988, 2, index + 1)),
      wireless_phone: phone, email: "#{first.downcase}.#{data[:name].downcase}@example.test",
      preferred_language: index == 1 ? "es" : (index == 5 ? nil : "en") }
  end
  ReplicaFixtures.write do
    ReplicaFixtures::Clinic.upsert({ id:, name: data[:name], city: data[:city], state: data[:state] })
    ReplicaFixtures::Patient.upsert_all(patients)
    visits = patients.each_with_index.map do |patient, index|
      days_ahead = [ 7, 7, 1, 1, 7, 2, 3, 0, 1, 1, 3, 3 ].fetch(index)
      date = clinic_day + days_ahead
      { id: id * 1000 + index, patient_id: patient[:id], clinic_id: id,
        provider_name: index.even? ? "Dr. Ellis" : "Dr. Ramirez", status: "scheduled",
        start_at: "#{date} #{index.even? ? '14:00' : '15:30'}", length_minutes: 45, updated_at: demo_clock }
    end
    [ clinic_day.beginning_of_month, clinic_day.prev_month.beginning_of_month ].each_with_index do |month, month_index|
      statuses = id == 101 ? %w[complete complete complete broken unscheduled] : %w[complete complete broken unscheduled]
      36.times do |index|
        date = month + index % [ [ (clinic_day - month).to_i, 1 ].max, month.end_of_month.day ].min
        visits << { id: id * 1000 + 100 + month_index * 50 + index, patient_id: patients[index % patients.size][:id],
          clinic_id: id, provider_name: "Dr. Ellis", status: statuses[index % statuses.size],
          start_at: "#{date} 10:00", length_minutes: 45, updated_at: demo_clock }
      end
    end
    ReplicaFixtures::Appointment.upsert_all(visits)
  end

  site = Site.find_or_create_by!(id:) { |record| record.timezone = data[:timezone] }
  data[:staff].each { |name| site.staff_members.find_or_create_by!(name:) }
  ReminderRun.new(site, now: demo_clock).call
  patient = patients.fetch(3)
  message = site.messages.delivered.find_by(patient_id: patient[:id], step: "final", occurred_at: demo_clock)
  if message
    PatientReply.new(site, channel: message.channel, body: "YES", event_key: "seed-confirmed-#{clinic_day}", now: demo_clock + 1.minute)
      .call(patient_id: patient[:id], message_id: message.id)
  end
  task = site.follow_ups.find_by(patient_id: patients.fetch(8)[:id], issue: "no_reply", resolved_at: nil)
  StaffFollowUp.new(site, site.staff_members.first, now: demo_clock).claim(task.id) if task && !task.staff_member_id
end

puts "Seeded Austin and Phoenix with fictional patients and fake message history."
