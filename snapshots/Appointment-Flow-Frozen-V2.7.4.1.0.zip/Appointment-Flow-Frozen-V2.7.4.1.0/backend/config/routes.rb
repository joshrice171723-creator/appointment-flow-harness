Rails.application.routes.draw do
  root to: redirect("/demo/index.html")
  get "up" => "rails/health#show", as: :rails_health_check

  namespace :api do
    resources :workspaces, only: :index
    resource :leadership, only: :show, controller: "leadership"
    resources :sites, only: [] do
      resources :appointments, only: :index
      resources :follow_ups, only: %i[index update] do
        resources :staff_actions, only: :create
      end
      resources :patients, only: :show do
        resource :contact_verification, only: :update
      end
      resources :reminder_runs, only: :create
      resources :inboxes, only: %i[index show] do
        resources :replies, only: :create
      end
    end
  end
end
