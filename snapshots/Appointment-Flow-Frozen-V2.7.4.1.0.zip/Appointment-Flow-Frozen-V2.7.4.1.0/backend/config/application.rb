require_relative "boot"

require "rails"
require "active_model/railtie"
require "active_record/railtie"
require "action_controller/railtie"
require "rails/test_unit/railtie"

Bundler.require(*Rails.groups)

module ApexFlow
  class Application < Rails::Application
    config.load_defaults 8.1
    config.autoload_lib(ignore: %w[assets tasks])
    config.api_only = true
    config.public_file_server.enabled = true
    # Migrations also provision the local PMS replica and its read projections.
    config.active_record.dump_schema_after_migration = false
    config.active_record.schema_format = :sql
  end
end
