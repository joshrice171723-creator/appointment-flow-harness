Rails.application.config.filter_parameters += %i[
  password token key secret authorization body note birthdate wireless_phone phone email value expected_source
]
Rails.application.config.filter_parameters << /\Aq\z/
