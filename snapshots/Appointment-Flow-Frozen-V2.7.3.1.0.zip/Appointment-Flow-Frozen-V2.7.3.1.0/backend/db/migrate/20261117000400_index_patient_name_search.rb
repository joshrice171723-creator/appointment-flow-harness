class IndexPatientNameSearch < ActiveRecord::Migration[8.1]
  def up
    add_column :clinic_patients, :search_name, :string, collation: "C"
    add_column :clinic_patients, :search_last_name, :string, collation: "C"

    # Initial local snapshots were created before search names were stored.
    execute <<~SQL
      UPDATE clinic_patients
      SET search_name = lower(name), search_last_name = lower(regexp_replace(name, '^.* ', ''))
    SQL
    change_column_null :clinic_patients, :search_name, false
    change_column_null :clinic_patients, :search_last_name, false
    add_index :clinic_patients, [ :clinic_workspace_id, :search_name ]
    add_index :clinic_patients, [ :clinic_workspace_id, :search_last_name ]
    add_index :work_items, [ :clinic_workspace_id, :clinic_patient_id, :state ], name: "index_work_items_on_clinic_patient_state"
  end

  def down
    remove_index :work_items, name: "index_work_items_on_clinic_patient_state"
    remove_column :clinic_patients, :search_name
    remove_column :clinic_patients, :search_last_name
  end
end
