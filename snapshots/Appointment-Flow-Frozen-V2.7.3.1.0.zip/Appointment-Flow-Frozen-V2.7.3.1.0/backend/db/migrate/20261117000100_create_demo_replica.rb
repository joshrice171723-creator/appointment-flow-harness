class CreateDemoReplica < ActiveRecord::Migration[8.1]
  def up
    create_table :clinics do |t|
      t.text :name, null: false
      t.text :address_line
      t.text :city
      t.string :state, limit: 2
      t.text :phone
    end

    create_table :patients do |t|
      t.text :first_name, null: false
      t.text :last_name, null: false
      t.date :birthdate
      t.text :wireless_phone
      t.text :email
      t.text :preferred_language
      t.references :guarantor, foreign_key: { to_table: :patients }
    end

    create_table :appointments do |t|
      t.references :patient, null: false, foreign_key: true
      t.references :clinic, null: false, foreign_key: true
      t.text :provider_name
      t.timestamp :start_at, null: false
      t.integer :length_minutes
      t.text :procedure_note
      t.text :status, null: false
      t.timestamp :updated_at
      t.index [ :clinic_id, :start_at ]
    end

    execute "GRANT SELECT ON clinics, patients, appointments TO apex_reader"
  end

  def down
    drop_table :appointments
    drop_table :patients
    drop_table :clinics
  end
end
