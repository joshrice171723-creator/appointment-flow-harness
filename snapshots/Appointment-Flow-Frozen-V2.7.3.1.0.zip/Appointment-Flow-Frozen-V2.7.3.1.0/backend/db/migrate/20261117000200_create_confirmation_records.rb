class CreateConfirmationRecords < ActiveRecord::Migration[8.1]
  TABLES = %w[clinic_workspaces clinic_patients visits deliveries replies sms_opt_outs work_items staff_actions].freeze

  def up
    create_table :clinic_workspaces do |t|
      t.string :name, null: false
      t.string :timezone, null: false
      t.datetime :synced_at
      t.string :sync_error
    end

    create_table :clinic_patients do |t|
      t.references :clinic_workspace, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.string :name, null: false
      t.jsonb :source_contact, null: false
      t.jsonb :verified_contact, null: false, default: {}
      t.string :sms_address
      t.string :email_address
      t.boolean :guardian_required, null: false, default: false
      t.index [ :clinic_workspace_id, :source_id ], unique: true
      t.index [ :clinic_workspace_id, :sms_address ]
      t.index [ :clinic_workspace_id, :email_address ]
    end

    create_table :visits do |t|
      t.references :clinic_workspace, null: false, foreign_key: true
      t.references :clinic_patient, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.integer :revision, null: false, default: 1
      t.timestamp :wall_start, null: false
      t.datetime :starts_at
      t.date :local_day, null: false
      t.string :source_status, null: false
      t.string :provider
      t.integer :minutes
      t.string :confirmation, null: false, default: "unconfirmed"
      t.string :staff_disposition
      t.index [ :clinic_workspace_id, :source_id ], unique: true
      t.index [ :clinic_workspace_id, :local_day, :wall_start, :id ]
      t.index [ :clinic_workspace_id, :source_status, :local_day ]
    end

    create_table :deliveries do |t|
      t.references :visit, null: false, foreign_key: true
      t.references :clinic_patient, null: false, foreign_key: true
      t.references :clinic_workspace, null: false, foreign_key: true
      t.integer :revision, null: false
      t.string :step, null: false
      t.string :channel, null: false
      t.string :recipient, null: false
      t.string :status, null: false
      t.text :body, null: false
      t.timestamps
      t.index [ :visit_id, :revision, :step, :channel ], unique: true
      t.index [ :clinic_workspace_id, :channel, :recipient, :status ], name: "index_deliveries_on_sender_match"
      t.index [ :clinic_workspace_id, :created_at ]
    end

    create_table :replies do |t|
      t.references :clinic_workspace, null: false, foreign_key: true
      t.references :clinic_patient, null: false, foreign_key: true
      t.references :delivery, foreign_key: true
      t.uuid :event_id, null: false
      t.string :channel, null: false
      t.text :body, null: false
      t.string :result, null: false
      t.timestamps
      t.index [ :clinic_workspace_id, :event_id ], unique: true
    end

    create_table :sms_opt_outs do |t|
      t.references :clinic_workspace, null: false, foreign_key: true
      t.string :recipient, null: false
      t.index [ :clinic_workspace_id, :recipient ], unique: true
    end

    create_table :work_items do |t|
      t.references :clinic_workspace, null: false, foreign_key: true
      t.references :clinic_patient, null: false, foreign_key: true
      t.references :visit, foreign_key: true
      t.references :reply, foreign_key: true
      t.integer :revision
      t.string :dedupe_key, null: false
      t.string :kind, null: false
      t.string :state, null: false, default: "needs_attention"
      t.string :assignee
      t.string :description, null: false
      t.jsonb :candidate_visits, null: false, default: []
      t.timestamps
      t.index [ :clinic_workspace_id, :dedupe_key ], unique: true
      t.index [ :clinic_workspace_id, :state, :updated_at, :id ]
    end

    create_table :staff_actions do |t|
      t.references :clinic_workspace, null: false, foreign_key: true
      t.references :clinic_patient, null: false, foreign_key: true
      t.references :work_item, foreign_key: true
      t.uuid :request_id, null: false
      t.string :staff, null: false
      t.string :outcome, null: false
      t.text :note, null: false
      t.jsonb :details, null: false, default: {}
      t.timestamps
      t.index [ :clinic_workspace_id, :request_id ], unique: true
    end

    execute "GRANT SELECT, INSERT, UPDATE, DELETE ON #{TABLES.join(', ')} TO apex_app"
    execute "GRANT USAGE, SELECT ON #{TABLES.map { |table| "#{table}_id_seq" }.join(', ')} TO apex_app"
    execute "GRANT SELECT ON schema_migrations, ar_internal_metadata TO apex_app"
  end

  def down
    TABLES.reverse_each { |table| drop_table table }
  end
end
