class RegisterDemoClinics < ActiveRecord::Migration[8.1]
  def up
    execute <<~SQL
      INSERT INTO clinic_workspaces (id, name, timezone) VALUES
        (1, 'Austin', 'America/Chicago'), (2, 'Phoenix', 'America/Phoenix')
    SQL
  end

  def down
    execute "DELETE FROM clinic_workspaces WHERE id IN (1, 2)"
  end
end
