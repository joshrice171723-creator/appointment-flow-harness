class DemoClinic < ApplicationRecord
  self.table_name = "clinics"
end

class DemoPatient < ApplicationRecord
  self.table_name = "patients"
end

class DemoAppointment < ApplicationRecord
  self.table_name = "appointments"
end

now = Time.current
ClinicWorkspace.order(:id).each do |clinic|
  DemoClinic.find_or_initialize_by(id: clinic.id).update!(
    name: clinic.name, city: clinic.name, state: clinic.id == 1 ? "TX" : "AZ",
    phone: clinic.id == 1 ? "512-555-0100" : "602-555-0100"
  )
  today = now.in_time_zone(clinic.zone).to_date
  area_code = clinic.id == 1 ? "512" : "602"
  patients = [
    [ "Alex", "Brooks", 7, "0101", true, "en", 1985 ],
    [ "Sam", "Reed", 7, nil, true, "en", 1990 ],
    [ "Lucia", "Vega", 3, "0103", true, "es", 1987 ],
    [ "Morgan", "Park", 1, "0104", false, "en", 1986 ],
    [ "Jamie", "Lane", 1, "0199", true, "en", 1979 ],
    [ "Charlie", "Bell", 2, "0106", false, "en", 2015 ],
    [ "Riley", "Quinn", 6, nil, false, "en", 1992 ],
    [ "Drew", "Wells", 4, "0108", false, "fr", 1989 ],
    [ "Avery", "Shaw", 0, "0109", true, "en", 1988 ],
    [ "Dana", "Fox", 5, "0110", false, "en", 1988 ],
    [ "Casey", "Hill", 5, "0110", false, "en", 1984 ]
  ]

  patients.each_with_index do |(first, last, days, phone, email, language, year), index|
    id = clinic.id * 100 + index + 1
    patient = DemoPatient.find_or_initialize_by(id: id)
    patient.update!(first_name: first, last_name: last, birthdate: Date.new(year, 4, 8),
      wireless_phone: phone && "#{area_code}-555-#{phone}", email: email ? "demo-#{id}@example.test" : nil,
      preferred_language: language)
    date = today + days
    DemoAppointment.find_or_initialize_by(id: id).update!(
      patient_id: patient.id, clinic_id: clinic.id, status: "scheduled", provider_name: "Dr. Jordan Patel",
      start_at: Time.utc(date.year, date.month, date.day, 13 + index % 4),
      length_minutes: 30 + 15 * (index % 3), procedure_note: "Fictional dental visit", updated_at: now
    )
  end

  [ today, today.prev_month, today.prev_month(2) ].each_with_index do |month, month_index|
    12.times do |index|
      date = month.beginning_of_month + index
      next if date >= today

      status = %w[complete complete complete complete complete broken complete complete unscheduled complete scheduled complete][index]
      status = "broken" if clinic.id == 2 && index.in?([ 4, 7 ])
      DemoAppointment.find_or_initialize_by(id: clinic.id * 1000 + month_index * 100 + index).update!(
        patient_id: clinic.id * 100 + index % patients.size + 1, clinic_id: clinic.id, status: status,
        provider_name: "Dr. Jordan Patel", start_at: Time.utc(date.year, date.month, date.day, 9),
        length_minutes: 45, procedure_note: "Fictional dental visit", updated_at: now
      )
    end
  end

  # Bootstrap a replayable timeline at a clinic-local 11 AM, independent of setup time.
  demo_run = clinic.zone.local(today.year, today.month, today.day, 11)
  ReminderRun.new(clinic, now: demo_run).call

  # Leave examples of review, assigned work and a resolved confirmation in each clinic.
  spanish_visit = clinic.visits.find_by!(source_id: clinic.id * 100 + 3)
  notice = spanish_visit.deliveries.where(revision: spanish_visit.revision, status: "sent").order(:id).first
  if notice
    reply = RecordReply.new(clinic, patient: notice.clinic_patient, delivery: notice,
      event_id: format("ec100000-0000-4000-8000-%012d", notice.id),
      channel: notice.channel, sender: notice.recipient, body: "NO", now: demo_run + 5.minutes).call
    item = clinic.work_items.find_by!(reply: reply)
    item.update!(state: "in_progress", assignee: clinic.staff_members.first) if item.state == "needs_attention"
  end

  same_day = clinic.visits.find_by!(source_id: clinic.id * 100 + 9)
  follow_up = same_day.work_items.open.find_by(kind: "no_confirmation", revision: same_day.revision)
  if follow_up && !follow_up.assignee
    staff = clinic.staff_members.first
    follow_up.update!(state: "in_progress", assignee: staff)
    StaffFollowUp.new(clinic, item_id: follow_up.id, staff: staff,
      request_id: format("ec200000-0000-4000-8000-%012d", follow_up.id),
      outcome: "confirmed", note: "Fictional call: patient confirmed today’s appointment.",
      visit_ids: [], now: demo_run + 10.minutes).call
  end
end
