SELECT 'CREATE ROLE apex_reader LOGIN'
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'apex_reader')\gexec
SELECT 'CREATE ROLE apex_app LOGIN'
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'apex_app')\gexec
