ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"

class ActiveSupport::TestCase
  self.use_transactional_tests = false

  setup do
    models = [ StaffAction, WorkItem, Reply, Delivery, SmsOptOut, Visit, ClinicPatient ]
    models.each(&:delete_all)
    TestAppointment.delete_all
    TestPatient.delete_all
    TestClinic.delete_all
    ClinicWorkspace.update_all(synced_at: nil, sync_error: nil)
    TestClinic.create!(id: 1, name: "Austin")
    TestClinic.create!(id: 2, name: "Phoenix")
  end

  class TestClinic < ApplicationRecord
    self.table_name = "clinics"
  end

  class TestPatient < ApplicationRecord
    self.table_name = "patients"
  end

  class TestAppointment < ApplicationRecord
    self.table_name = "appointments"
  end

  def source_visit(id: 1, clinic: 1, at: Time.utc(2026, 7, 14, 14), status: "scheduled", **contact)
    TestPatient.create!({
      id: id, first_name: "Fictional", last_name: "Patient #{id}", birthdate: Date.new(1988, 1, 1),
      wireless_phone: "512555#{format('%04d', 100 + id)}", email: "patient#{id}@example.test",
      preferred_language: "en"
    }.merge(contact))
    TestAppointment.create!(id: id, patient_id: id, clinic_id: clinic, start_at: at, status: status,
      provider_name: "Dr. Demo", length_minutes: 45)
  end

  def austin
    ClinicWorkspace.find(1)
  end

  def run_time
    Time.utc(2026, 7, 7, 16)
  end
end
