require "test_helper"
require_relative "../../../quality/rails_workload_probe"

class ReminderWorkloadTest < ActionDispatch::IntegrationTest
  test "clinic batch stays bounded by the source window and persists exactly one attempt per eligible visit" do
    source_visit
    travel_to(run_time) do
      initial = measure_run(sent: 1)
      small = measure_run(sent: 0)

      outside = 2_000.times.map do |index|
        { id: 1000 + index, clinic_id: 1, patient_id: 1, status: "complete",
          start_at: Time.utc(2026, 1, 1) + index.hours }
      end
      TestAppointment.insert_all!(outside)
      TestAppointment.connection.execute("ANALYZE appointments")
      grown = measure_run(sent: 0)
      assert_equal small.values_at(:read_rows, :read_statements, :instantiated_records),
        grown.values_at(:read_rows, :read_statements, :instantiated_records)
      assert_equal [ 1 ], Delivery.joins(:visit).pluck("visits.source_id")

      source = PmsAppointment.where(clinic_id: 1, start_at: Time.utc(2026, 6, 30)...Time.utc(2026, 7, 22))
      query = source.or(PmsAppointment.where(clinic_id: 1, id: [ 1 ])).to_sql
      plan = PmsAppointment.with_connection { |connection| connection.select_values("EXPLAIN #{query}").join("\n") }
      assert_match(/Index|Bitmap/, plan)

      30.times { |index| source_visit(id: index + 2) }
      larger_batch = measure_run(sent: 30)
      retry_batch = measure_run(sent: 0)
      assert_equal (1..31).to_a, Delivery.joins(:visit).order("visits.source_id").pluck("visits.source_id")
      assert_operator retry_batch.fetch(:affected_rows), :<, larger_batch.fetch(:affected_rows)
      if ENV["APEX_WORKLOAD"]
        puts "Reminder HTTP initial #{initial}"
        puts "Reminder HTTP small retry #{small}"
        puts "Reminder HTTP grown retry #{grown}"
        puts "Reminder HTTP expanded eligible batch #{larger_batch}"
        puts "Reminder HTTP expanded retry #{retry_batch}"
        puts plan
      end
    end
  end

  private

  def measure_run(sent:)
    _, metrics = RailsWorkloadProbe.measure do
      post "/api/clinics/1/reminder_run", headers: { "X-Apex-Staff" => "Taylor Morgan" }, as: :json
    end
    assert_response :created
    assert_equal [ sent, 0 ], response.parsed_body.values_at("sent", "failed")
    metrics.merge(response_bytes: response.body.bytesize)
  end
end
