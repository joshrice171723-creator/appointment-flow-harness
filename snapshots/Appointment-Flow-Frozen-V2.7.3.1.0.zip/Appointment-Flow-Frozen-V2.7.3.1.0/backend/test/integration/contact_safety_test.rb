require "test_helper"

class ContactSafetyTest < ActionDispatch::IntegrationTest
  test "an explicit non-NANP or misplaced country prefix never routes to another number" do
    source_visit(wireless_phone: "+512-555-0102", email: nil)
    source_visit(id: 2, wireless_phone: "512+555-0102", email: nil)
    source_visit(id: 3, wireless_phone: "+44 20 7946 0958", email: nil)
    source_visit(id: 4, wireless_phone: "+1 (512) 555-0104", email: nil)

    travel_to(run_time) do
      post "/api/clinics/1/reminder_run", headers: { "X-Apex-Staff" => "Taylor Morgan" }, as: :json
      assert_response :created
      assert_equal 1, response.parsed_body.fetch("sent")
      assert_equal [ "+15125550104", 4 ], [ Delivery.sole.recipient, Delivery.sole.visit.source_id ]
      assert_equal [ 1, 2, 3 ], WorkItem.where(kind: "contact_hold").joins(:visit).order("visits.source_id").pluck("visits.source_id")
    end
  end
end
