require "test_helper"

class ReminderRunsRequestTest < ActionDispatch::IntegrationTest
  test "staff can run a clinic batch through HTTP and another clinic's identity cannot" do
    source_visit
    travel_to(run_time) do
      post "/api/clinics/1/reminder_run", headers: { "X-Apex-Staff" => "Avery Chen" }, as: :json
      assert_response :forbidden
      assert_equal 0, Delivery.count
      post "/api/clinics/1/reminder_run", headers: { "X-Apex-Staff" => "Taylor Morgan" }, as: :json
      assert_response :created
      assert_equal 1, response.parsed_body.fetch("sent")
      assert_equal 1, Delivery.count
    end
  end
end
