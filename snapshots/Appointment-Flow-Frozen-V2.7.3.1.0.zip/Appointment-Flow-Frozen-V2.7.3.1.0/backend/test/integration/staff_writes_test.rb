require "test_helper"

class StaffWritesTest < ActionDispatch::IntegrationTest
  STAFF = { "X-Apex-Staff" => "Taylor Morgan" }.freeze

  test "verified contact changes the next run and leaves the source and audit history inspectable" do
    source_visit(wireless_phone: nil, email: nil)
    travel_to(run_time) do
      assert_equal 0, ReminderRun.new(austin).call.fetch(:sent)
      item = WorkItem.sole
      assert_equal "contact_hold", item.kind
      path = "/api/clinics/1/clinic_patients/#{item.clinic_patient_id}/contact_verification"
      payload = { field: "wireless_phone", value: "512-555-0102", contact_version: item.clinic_patient.contact_version("wireless_phone"), request_id: SecureRandom.uuid }
      2.times do
        post path, headers: STAFF, params: payload, as: :json
        assert_response :success
      end
      assert_equal 1, StaffAction.count
      assert_equal 1, ReminderRun.new(austin).call.fetch(:sent)
      assert_equal [ "+15125550102", "resolved" ], [ Delivery.sole.recipient, item.reload.state ]
      assert_nil PmsPatient.find(1).wireless_phone
    end
  end

  test "cross-clinic assignment cannot mutate and retrying a follow-up records one effect" do
    source_visit(at: Time.utc(2026, 7, 8, 14))
    travel_to(run_time) do
      ReminderRun.new(austin).call
      item = WorkItem.sole
      patch "/api/clinics/2/work_items/#{item.id}/work_assignment",
        headers: { "X-Apex-Staff" => "Casey Rivera" }, as: :json
      assert_response :not_found
      assert_nil item.reload.assignee
      patch "/api/clinics/1/work_items/#{item.id}/work_assignment", headers: STAFF, as: :json
      assert_response :success
      path = "/api/clinics/1/work_items/#{item.id}/follow_ups"
      post path, headers: STAFF, params: { outcome: "attempted", note: "", request_id: SecureRandom.uuid }, as: :json
      assert_response :unprocessable_content
      assert_empty StaffAction.all
      post path, headers: STAFF, params: { outcome: "attempted", note: "Left a message", request_id: SecureRandom.uuid }, as: :json
      assert_response :success
      assert_equal "in_progress", item.reload.state

      payload = { outcome: "confirmed", note: "Patient confirmed by phone", request_id: SecureRandom.uuid }
      2.times do
        post path, headers: STAFF, params: payload, as: :json
        assert_response :success
      end
      assert_equal 2, StaffAction.count
      assert_equal [ "resolved", "confirmed", "scheduled" ], [ item.reload.state, Visit.sole.confirmation, Visit.sole.source_status ]
      post path, headers: STAFF, params: payload.merge(outcome: "canceled"), as: :json
      assert_response :conflict
      assert_equal "confirmed", Visit.sole.confirmation
    end
  end

  test "an invalid cross-clinic candidate produces no staff action or visit change" do
    source_visit(at: Time.utc(2026, 7, 8, 14))
    source_visit(id: 2, clinic: 2, at: Time.utc(2026, 7, 8, 14))
    travel_to(run_time) do
      ReminderRun.new(austin).call
      ReminderRun.new(ClinicWorkspace.find(2)).call
      item = austin.work_items.find_by!(kind: "no_confirmation")
      item.update!(state: "in_progress", assignee: "Taylor Morgan")
      other_id = ClinicWorkspace.find(2).visits.sole.id
      post "/api/clinics/1/work_items/#{item.id}/follow_ups", headers: STAFF,
        params: { outcome: "confirmed", note: "Test", request_id: SecureRandom.uuid, visit_ids: [ other_id ] }, as: :json
      assert_response :conflict
      assert_empty StaffAction.all
      assert_equal [ "unconfirmed" ], Visit.distinct.pluck(:confirmation)
    end
  end
end
