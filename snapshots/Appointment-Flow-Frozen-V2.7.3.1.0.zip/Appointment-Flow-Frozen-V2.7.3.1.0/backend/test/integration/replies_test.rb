require "test_helper"

class RepliesTest < ActionDispatch::IntegrationTest
  test "SMS YES confirms the current visit once and stops later reminders" do
    source_visit
    travel_to(run_time) do
      ReminderRun.new(austin).call
      delivery = Delivery.sole
      event_id = SecureRandom.uuid
      2.times do
        reply(delivery, "YES", event_id: event_id)
        assert_response :success
        assert_equal "confirmed", response.parsed_body.fetch("result")
      end
      assert_equal 1, Reply.count
      assert_equal "confirmed", delivery.visit.reload.confirmation
    end
    assert_equal({ sent: 0, failed: 0 }, ReminderRun.new(austin, now: run_time + 4.days).call)
  end

  test "email-only reply confirms and later NO opens work without undoing confirmation" do
    source_visit(wireless_phone: "invalid")
    travel_to(run_time) do
      ReminderRun.new(austin).call
      delivery = Delivery.sole
      assert_equal "email", delivery.channel
      reply(delivery, "yes")
      assert_equal "confirmed", response.parsed_body.fetch("result")
      reply(delivery, "NO")
      assert_equal "review", response.parsed_body.fetch("result")
      assert_equal "confirmed", Visit.sole.confirmation
      assert_equal "reply_review", WorkItem.sole.kind
    end
  end

  test "a changed start invalidates old confirmation and same-time replacement has its own lifecycle" do
    source = source_visit
    travel_to(run_time) do
      ReminderRun.new(austin).call
      old_delivery = Delivery.sole
      reply(old_delivery, "YES")
      source.update!(start_at: source.start_at + 1.hour)
      reply(old_delivery, "YES")
      assert_equal "review", response.parsed_body.fetch("result")
      assert_equal [ 2, "unconfirmed" ], Visit.sole.attributes.values_at("revision", "confirmation")
      assert_equal 1, ReminderRun.new(austin).call.fetch(:sent)

      source.update!(status: "broken")
      source_visit(id: 2)
      ReminderRun.new(austin).call
      assert_equal [ [ 1, 1 ], [ 1, 2 ], [ 2, 1 ] ], Delivery.order(:id).joins(:visit).pluck("visits.source_id", :revision)
      assert_equal "broken", Visit.find_by!(source_id: 1).source_status
    end
  end

  test "reply received at start remains available for review" do
    source_visit
    ReminderRun.new(austin, now: run_time).call
    delivery = Delivery.sole
    travel_to(delivery.visit.starts_at) do
      reply(delivery, "YES")
      assert_equal "review", response.parsed_body.fetch("result")
      assert_equal "unconfirmed", delivery.visit.reload.confirmation
      assert_equal 1, Delivery.count
    end
  end

  test "STOP survives refresh, including an unavailable source, while STOP punctuation is reviewed" do
    source = source_visit(email: nil)
    travel_to(run_time) do
      ReminderRun.new(austin).call
      delivery = Delivery.sole
      reply(delivery, "STOP!")
      assert_equal "review", response.parsed_body.fetch("result")
      source.destroy!
      reply(delivery, " stop ")
      assert_equal "opted_out", response.parsed_body.fetch("result")
      assert_equal delivery.recipient, SmsOptOut.sole.recipient
      TestAppointment.create!(source.attributes)
    end
    assert_equal 0, ReminderRun.new(austin, now: run_time + 4.days).call.fetch(:sent)
    assert_equal 1, Delivery.count
  end

  test "a newly shared contact turns a previously sent YES into review with two candidates" do
    source_visit(email: nil)
    travel_to(run_time) do
      ReminderRun.new(austin).call
      delivery = Delivery.sole
      source_visit(id: 2, wireless_phone: "512-555-0101", email: nil)
      reply(delivery, "YES")
      assert_equal "review", response.parsed_body.fetch("result")
      assert_equal 2, WorkItem.find_by!(kind: "reply_review").candidate_visits.length
      assert_equal [ "unconfirmed" ], Visit.distinct.pluck(:confirmation)
      assert_equal 0, ReminderRun.new(austin).call.fetch(:sent)
    end
  end

  test "a different clinic or patient cannot use a sent envelope" do
    source_visit
    source_visit(id: 2)
    source_visit(id: 3, clinic: 2)
    travel_to(run_time) do
      ReminderRun.new(austin).call
      ReminderRun.new(ClinicWorkspace.find(2), now: run_time + 1.hour).call
      delivery = austin.deliveries.first
      reply(delivery, "YES", clinic_id: 2)
      assert_response :not_found
      reply(delivery, "YES", patient_id: austin.clinic_patients.where.not(id: delivery.clinic_patient_id).pick(:id))
      assert_response :not_found
      assert_empty Reply.all
    end
  end

  test "Spanish reminders use local text and recognize an accented confirmation" do
    source_visit(preferred_language: "es")
    travel_to(run_time) do
      ReminderRun.new(austin).call
      delivery = Delivery.sole
      assert_includes delivery.body, "14 de julio"
      reply(delivery, "Sí")
      assert_equal "confirmed", response.parsed_body.fetch("result")
    end
  end

  private

  def reply(delivery, message, event_id: SecureRandom.uuid, clinic_id: 1, patient_id: delivery.clinic_patient_id)
    post "/api/clinics/#{clinic_id}/clinic_patients/#{patient_id}/replies",
      params: { delivery_id: delivery.id, channel: delivery.channel, event_id: event_id, body: message }, as: :json
  end
end
