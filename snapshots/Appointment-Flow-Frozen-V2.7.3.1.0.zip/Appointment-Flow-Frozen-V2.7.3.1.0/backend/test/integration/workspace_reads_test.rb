require "test_helper"
require_relative "../../../quality/rails_workload_probe"

class WorkspaceReadsTest < ActionDispatch::IntegrationTest
  STAFF = { "X-Apex-Staff" => "Taylor Morgan" }.freeze

  test "appointment GET filters clinic, local date and reply state and preserves totals on every page" do
    27.times { |index| source_visit(id: index + 1) }
    source_visit(id: 40, clinic: 2)
    travel_to(run_time) do
      ClinicTransaction.with_fresh_source(austin, now: Time.current) { }
      phoenix = ClinicWorkspace.find(2)
      ClinicTransaction.with_fresh_source(phoenix, now: Time.current) { }
      expected = austin.visits.order(:wall_start, :id).pluck(:id)
      austin.visits.find(expected.last).update!(confirmation: "confirmed")
      WorkItem.for_visit!(austin.visits.find(expected.first), "reply_review", "Review this reply.")

      path = "/api/clinics/1/visits"
      get path, headers: STAFF, params: { date: "2026-07-14" }
      assert_response :success
      assert_equal expected.first(25), response.parsed_body["visits"].pluck("id")
      assert_equal({ "all" => 27, "confirmed" => 1, "unconfirmed" => 26, "review" => 1 }, response.parsed_body["totals"])
      assert_equal({ "2026-07-14" => 27 }, response.parsed_body["week"])

      get path, headers: STAFF, params: { date: "2026-07-14", page: 2 }
      assert_equal expected.last(2), response.parsed_body["visits"].pluck("id")
      get path, headers: STAFF, params: { date: "2026-07-14", filter: "review" }
      assert_equal [ expected.first ], response.parsed_body["visits"].pluck("id")
      assert_equal true, response.parsed_body["visits"].first["reply_review"]
      get path, headers: STAFF, params: { date: "2026-07-15" }
      assert_empty response.parsed_body["visits"]

      foreign_patient = phoenix.clinic_patients.sole.id
      get "/api/clinics/1/clinic_patients/#{foreign_patient}", headers: STAFF
      assert_response :not_found
      get "/api/clinics/1/clinic_patients/#{foreign_patient}/conversation"
      assert_response :not_found
    end
  end

  test "work board keeps clinic totals while a case insensitive filter and pages constrain displayed items" do
    7.times { |index| source_visit(id: index + 1, email: nil, wireless_phone: nil) }
    source_visit(id: 8, clinic: 2, email: nil, wireless_phone: nil)
    travel_to(run_time) do
      ReminderRun.new(austin).call
      ReminderRun.new(ClinicWorkspace.find(2)).call
      ids = austin.work_items.order(updated_at: :desc, id: :desc).pluck(:id)
      get "/api/clinics/1/work_items", headers: STAFF, params: { needs_attention: 2 }
      assert_response :success
      assert_equal ids.last(2), response.parsed_body.dig("queues", "needs_attention", "items").pluck("id")

      get "/api/clinics/1/work_items", headers: STAFF, params: { search: "pAtIeNt 5", kind: "contact_hold" }
      assert_equal 7, response.parsed_body.dig("totals", "needs_attention")
      queue = response.parsed_body.dig("queues", "needs_attention")
      assert_equal 1, queue.fetch("total")
      assert_equal [ "Fictional Patient 5" ], queue.fetch("items").pluck("patient_name")
      refute_includes response.body, "reply_body"

      get "/api/clinics/1/work_items", headers: STAFF, params: { search: "nonexistent" }
      assert_empty response.parsed_body.dig("queues", "needs_attention", "items")
    end
  end

  test "leadership distinguishes confirmation from outcomes and emits clinic aggregates only" do
    source_visit(at: Time.utc(2026, 7, 6, 10))
    source_visit(id: 2, at: Time.utc(2026, 7, 6, 11), status: "complete")
    source_visit(id: 3, clinic: 2, at: Time.utc(2026, 7, 6, 12), status: "broken")
    source_visit(id: 4)
    travel_to(run_time) do
      ReminderRun.new(austin).call
      Visit.find_by!(source_id: 1).update!(confirmation: "confirmed")
      get "/api/leadership", params: { month: "2026-07" }
      assert_response :success
      report = response.parsed_body
      assert_equal %w[clinics history month], report.keys.sort
      assert_equal [ "2026-07", "2026-06", "2026-05" ], report["history"].pluck("month")
      assert_equal [ [ "Austin", 2, 1, 0, 1 ], [ "Phoenix", 1, 0, 1, 0 ] ],
        report["clinics"].map { |row| row.values_at("name", "recorded", "completed", "canceled", "unknown") }
      allowed = %w[id name recorded completed canceled unknown sent failed confirmed_replies review_replies open_holds resolved_holds work_total follow_ups]
      assert report["history"].flat_map { |month| month["clinics"] }.all? { |clinic| clinic.keys.sort == allowed.sort }
      refute_match(/Fictional|Dr\. Demo|@example|512555|birthdate|procedure_note/, response.body)
    end
  end

  test "the complete HTTP day read stays bounded when unrelated clinic and historical rows grow" do
    source_visit
    travel_to(run_time) do
      ClinicTransaction.with_fresh_source(austin, now: Time.current) { }
      visit = austin.visits.sole
      small_body, small = measured_day
      foreign = ClinicWorkspace.find(2)
      source_visit(id: 2, clinic: 2)
      ClinicTransaction.with_fresh_source(foreign, now: Time.current) { }
      unrelated = 2_000.times.map do |index|
        attributes = visit.attributes.except("id")
        attributes.merge("source_id" => 10_000 + index, "local_day" => Date.new(2026, 1, 1) + (index % 60))
      end
      Visit.insert_all!(unrelated)
      Visit.connection.execute("ANALYZE visits")
      grown_body, grown = measured_day
      assert_equal small_body, grown_body
      assert_equal [ visit.id ], grown_body.fetch("visits").pluck("id")
      assert_equal small.values_at(:read_statements, :read_rows, :instantiated_records, :response_bytes),
        grown.values_at(:read_statements, :read_rows, :instantiated_records, :response_bytes)
      plan = austin.visits.where(local_day: visit.local_day).order(:wall_start, :id).limit(25).explain.inspect
      assert_match(/Index|Bitmap/, plan)
      if ENV["APEX_WORKLOAD"]
        puts "Appointments HTTP small #{small}"
        puts "Appointments HTTP grown #{grown}"
        puts plan
      end
    end
  end

  test "PMS reader cannot bypass model readonly behavior with a bulk write" do
    source_visit
    assert_raises(ActiveRecord::StatementInvalid) { PmsAppointment.where(id: 1).update_all(status: "complete") }
    assert_equal "scheduled", PmsAppointment.find(1).status
  end

  private

  def measured_day
    _, metrics = RailsWorkloadProbe.measure do
      get "/api/clinics/1/visits", params: { date: "2026-07-14" }, headers: STAFF
    end
    assert_response :success
    [ response.parsed_body, metrics.merge(response_bytes: response.body.bytesize) ]
  end
end
