require "test_helper"

class ReminderRunTest < ActiveSupport::TestCase
  test "refreshes the exact clinic's scheduled visits and records one initial SMS across concurrent runs" do
    source_visit
    source_visit(id: 2, clinic: 2)
    counts = 2.times.map do
      Thread.new do
        ActiveRecord::Base.connection_pool.with_connection do
          PmsRecord.connection_pool.with_connection { ReminderRun.new(austin, now: run_time).call }
        end
      end
    end.map(&:value)
    assert_equal [ 0, 1 ], counts.pluck(:sent).sort
    assert_equal [ [ "sms", "initial", "sent", 1 ] ], Delivery.pluck(:channel, :step, :status, :clinic_workspace_id)
    assert_equal Time.utc(2026, 7, 14, 19), Visit.sole.starts_at
  end

  test "records a failed SMS and one fallback email with an actionable item" do
    source_visit(wireless_phone: "512-555-0199")
    run = ReminderRun.new(austin, now: run_time)
    assert_equal({ sent: 1, failed: 1 }, run.call)
    assert_equal({ sent: 0, failed: 0 }, run.call)
    assert_equal [ [ "email", "sent" ], [ "sms", "failed" ] ], Delivery.order(:channel).pluck(:channel, :status)
    assert_equal "delivery_failed", WorkItem.sole.kind
  end

  test "rolls back a fake delivery and refreshed snapshot when an unexpected persistence failure follows the write" do
    source_visit
    transport = Class.new(FakeTransport) do
      def deliver(**)
        super
        raise ActiveRecord::RecordInvalid
      end
    end.new
    assert_raises(ActiveRecord::RecordInvalid) { ReminderRun.new(austin, now: run_time, transport: transport).call }
    assert_empty Delivery.all
    assert_empty Visit.all
    assert_nil austin.synced_at
    assert_equal 1, ReminderRun.new(austin, now: run_time).call.fetch(:sent)
  end

  test "keeps the previous snapshot and blocks sends when the PMS omits a tracked visit" do
    source = source_visit
    ReminderRun.new(austin, now: run_time).call
    source.destroy!
    assert_raises(ClinicRefresh::Unavailable) { ReminderRun.new(austin, now: run_time + 4.days).call }
    assert_equal 1, Visit.count
    assert_equal 1, Delivery.count
    assert_equal run_time, austin.synced_at
    assert_match(/previously tracked/, austin.sync_error)
  end

  test "rejects unsafe contacts and ambiguous daylight saving wall times" do
    source_visit(birthdate: nil)
    source_visit(id: 2, preferred_language: "fr")
    ReminderRun.new(austin, now: run_time).call
    assert_empty Delivery.all
    assert_equal [ "contact_hold", "contact_hold" ], WorkItem.pluck(:kind)
    assert_nil austin.wall_instant(Time.utc(2026, 11, 1, 1, 30))
    assert_nil austin.wall_instant(Time.utc(2026, 3, 8, 2, 30))
    assert_equal Time.utc(2026, 11, 1, 8), austin.wall_instant(Time.utc(2026, 11, 1, 2))
  end

  test "respects local send windows and clinic dates in Austin and Phoenix" do
    source_visit
    source_visit(id: 2, clinic: 2)
    phoenix = ClinicWorkspace.find(2)
    assert_equal 0, ReminderRun.new(phoenix, now: run_time).call.fetch(:sent)
    assert_equal 1, ReminderRun.new(phoenix, now: run_time + 1.hour).call.fetch(:sent)
    assert_equal 1, ReminderRun.new(austin, now: run_time).call.fetch(:sent)
    assert_equal [ Time.utc(2026, 7, 14, 19), Time.utc(2026, 7, 14, 21) ], Visit.order(:clinic_workspace_id).pluck(:starts_at)
  end
end
