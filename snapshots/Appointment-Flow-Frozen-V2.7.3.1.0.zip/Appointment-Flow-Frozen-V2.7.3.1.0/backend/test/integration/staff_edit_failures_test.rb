require "test_helper"

class StaffEditFailuresTest < ActionDispatch::IntegrationTest
  STAFF = { "X-Apex-Staff" => "Taylor Morgan" }.freeze

  test "a stale form cannot re-verify old contact details against a newly changed PMS value" do
    source_visit
    travel_to(run_time) do
      ReminderRun.new(austin).call
      patient = austin.clinic_patients.sole
      path = "/api/clinics/1/clinic_patients/#{patient.id}"
      get path, headers: STAFF
      token = response.parsed_body.dig("contact", "wireless_phone", "version")
      payload = { field: "wireless_phone", value: "512-555-0101", contact_version: token, request_id: SecureRandom.uuid }

      TestPatient.find(1).update!(wireless_phone: "512-555-0102")
      post "#{path}/contact_verification", headers: STAFF, params: payload, as: :json
      assert_response :conflict
      assert_empty StaffAction.all
      get path, headers: STAFF
      contact = response.parsed_body.dig("contact", "wireless_phone")
      assert_equal "512-555-0102", contact.fetch("value")
      refute_equal token, contact.fetch("version")
      assert_nil contact.fetch("verification")
    end
  end

  test "staff can verify the absence of an unusable contact channel" do
    source_visit(email: nil)
    travel_to(run_time) do
      ReminderRun.new(austin).call
      patient = austin.clinic_patients.sole
      path = "/api/clinics/1/clinic_patients/#{patient.id}"
      payload = { field: "wireless_phone", value: "", contact_version: patient.contact_version("wireless_phone"),
        request_id: SecureRandom.uuid }
      post "#{path}/contact_verification", headers: STAFF, params: payload, as: :json
      assert_response :success
      assert_nil patient.reload.sms_address
      assert_nil patient.verified_contact.dig("wireless_phone", "value")
      assert_equal "5125550101", PmsPatient.find(1).wireless_phone
    end
    assert_equal 0, ReminderRun.new(austin, now: run_time + 4.days).call.fetch(:sent)
    assert_equal "contact_hold", WorkItem.sole.kind
  end

  test "a write error after recording a staff action rolls it back and keeps the work open" do
    source_visit(at: Time.utc(2026, 7, 8, 14))
    travel_to(run_time) do
      ReminderRun.new(austin).call
      item = WorkItem.sole
      item.update!(state: "in_progress", assignee: "Taylor Morgan")
      payload = { outcome: "confirmed", note: "Patient confirmed by phone", request_id: SecureRandom.uuid }
      Visit.connection.add_check_constraint(:visits, "confirmation <> 'confirmed'", name: "test_reject_confirmation")
      assert_raises(ActiveRecord::StatementInvalid) do
        post "/api/clinics/1/work_items/#{item.id}/follow_ups", headers: STAFF, params: payload, as: :json
      end
      assert_equal "unconfirmed", Visit.sole.confirmation
      assert_equal "in_progress", item.reload.state
      assert_empty StaffAction.all
    ensure
      Visit.connection.remove_check_constraint(:visits, name: "test_reject_confirmation", if_exists: true)
    end
  end
end
