class PmsAppointment < PmsRecord
  self.table_name = "appointments"
  self.skip_time_zone_conversion_for_attributes = %i[start_at updated_at]
  self.filter_attributes += %i[procedure_note]
end
