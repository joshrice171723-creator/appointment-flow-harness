class PmsRecord < ApplicationRecord
  self.abstract_class = true

  connects_to database: { writing: :pms }

  def readonly?
    true
  end
end
