class ClinicPatient < ApplicationRecord
  CONTACT_FIELDS = %w[birthdate wireless_phone email preferred_language].freeze
  belongs_to :clinic_workspace
  has_many :visits
  has_many :deliveries
  has_many :replies
  has_many :work_items
  has_many :staff_actions

  self.filter_attributes += %i[name source_contact verified_contact sms_address email_address]

  def effective_contact
    source_contact.merge(verified_contact.transform_values { |entry| entry.fetch("value") })
  end

  def contact_version(field)
    Digest::SHA256.hexdigest([ source_contact[field], verified_contact[field] ].to_json)
  end

  def contact_conflict?
    verified_contact.any? do |field, entry|
      entry.fetch("source") != source_contact[field] && entry.fetch("value") != source_contact[field]
    end
  end

  def refresh_addresses
    contact = effective_contact
    self.sms_address = self.class.sms_address(contact["wireless_phone"])
    self.email_address = self.class.email_address(contact["email"])
  end

  def self.sms_address(value)
    phone = value.to_s.strip
    return unless phone.match?(/\A(?:\+1)?[0-9(). -]+\z/)

    digits = phone.gsub(/\D/, "")
    return if phone.start_with?("+") && !digits.match?(/\A1\d{10}\z/)

    digits = digits.delete_prefix("1") if digits.length == 11
    "+1#{digits}" if digits.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
  end

  def self.email_address(value)
    address = value.to_s.strip.downcase
    address if address.match?(/\A[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+\z/)
  end

  def adult_on?(date)
    birthdate = Date.iso8601(effective_contact["birthdate"].to_s)
    birthdate <= date.years_ago(18) && !guardian_required
  rescue Date::Error
    false
  end
end
