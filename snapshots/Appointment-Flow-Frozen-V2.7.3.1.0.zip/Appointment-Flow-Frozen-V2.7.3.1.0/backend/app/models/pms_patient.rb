class PmsPatient < PmsRecord
  self.table_name = "patients"
  self.filter_attributes += %i[first_name last_name birthdate wireless_phone email]
end
