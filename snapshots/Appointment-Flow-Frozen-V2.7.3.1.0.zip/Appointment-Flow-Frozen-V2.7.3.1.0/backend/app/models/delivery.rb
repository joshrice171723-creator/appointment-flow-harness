class Delivery < ApplicationRecord
  belongs_to :clinic_workspace
  belongs_to :clinic_patient
  belongs_to :visit

  self.filter_attributes += %i[recipient body]
end
