class Visit < ApplicationRecord
  belongs_to :clinic_workspace
  belongs_to :clinic_patient
  has_many :work_items
  has_many :deliveries

  scope :scheduled, -> { where(source_status: "scheduled", staff_disposition: nil) }

  def upcoming?(now)
    source_status == "scheduled" && staff_disposition.nil? && starts_at.present? && starts_at > now
  end

  def confirmed?
    confirmation == "confirmed"
  end
end
