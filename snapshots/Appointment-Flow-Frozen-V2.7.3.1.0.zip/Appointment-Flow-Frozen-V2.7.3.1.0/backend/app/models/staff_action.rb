class StaffAction < ApplicationRecord
  belongs_to :clinic_workspace
  belongs_to :clinic_patient
  belongs_to :work_item, optional: true

  self.filter_attributes += %i[note details]
end
