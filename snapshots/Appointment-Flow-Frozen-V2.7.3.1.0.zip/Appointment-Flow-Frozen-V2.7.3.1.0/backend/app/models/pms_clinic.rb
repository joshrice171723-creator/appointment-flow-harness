class PmsClinic < PmsRecord
  self.table_name = "clinics"
end
