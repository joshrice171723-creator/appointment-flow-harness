class Reply < ApplicationRecord
  belongs_to :clinic_workspace
  belongs_to :clinic_patient
  belongs_to :delivery, optional: true

  self.filter_attributes += %i[body]
end
