class WorkItem < ApplicationRecord
  KINDS = %w[no_confirmation contact_hold delivery_failed reply_review].freeze

  belongs_to :clinic_workspace
  belongs_to :clinic_patient
  belongs_to :visit, optional: true
  belongs_to :reply, optional: true
  has_many :staff_actions

  scope :open, -> { where(state: %w[needs_attention in_progress]) }

  def self.for_visit!(visit, kind, description)
    item = visit.clinic_workspace.work_items.find_or_initialize_by(
      dedupe_key: "visit:#{visit.id}:#{visit.revision}:#{kind}"
    )
    if item.state == "resolved"
      item.assign_attributes(state: "needs_attention", assignee: nil)
    end
    item.assign_attributes(visit: visit, revision: visit.revision, clinic_patient_id: visit.clinic_patient_id,
      kind: kind, description: description)
    item.save! if item.changed?
    item
  end
end
