class SmsOptOut < ApplicationRecord
  belongs_to :clinic_workspace

  self.filter_attributes += %i[recipient]
end
