class ClinicWorkspace < ApplicationRecord
  STAFF = { 1 => [ "Taylor Morgan", "Jordan Ellis" ], 2 => [ "Casey Rivera", "Avery Chen" ] }.freeze

  has_many :clinic_patients
  has_many :visits
  has_many :deliveries
  has_many :replies
  has_many :sms_opt_outs
  has_many :work_items
  has_many :staff_actions

  def zone
    Time.find_zone!(timezone)
  end

  def staff_members
    STAFF.fetch(id, [])
  end

  def wall_instant(wall)
    periods = zone.tzinfo.periods_for_local(wall)
    return unless periods.one?

    wall - periods.first.observed_utc_offset
  end
end
