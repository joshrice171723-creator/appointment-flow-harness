class SourceRefreshesController < StaffController
  def create
    ClinicTransaction.with_fresh_source(clinic, now: Time.current) { nil }
    render json: sync_status
  end
end
