class ClinicPatientsController < StaffController
  include StaffRecords

  def show
    patient = clinic.clinic_patients.find(params[:id])
    items = patient_work(patient)
    candidates = candidate_details(items)
    visits = patient.visits.order(wall_start: :desc, id: :desc).limit(25).preload(:clinic_patient).to_a
    reviews = open_review_items.where(visit_id: visits.map(&:id)).distinct.pluck(:visit_id).to_set

    render json: sync_status.merge(
      id: patient.id, name: patient.name, contact: contact_fields(patient),
      visits: visits.map { |visit| visit_summary(visit, reviews) },
      next_visit: next_visit(patient),
      work: items.map { |item| work_detail(item, candidates) },
      activity: patient.staff_actions.order(created_at: :desc, id: :desc).limit(25)
        .as_json(only: %i[id staff outcome note created_at details])
    )
  end

  private

  def patient_work(patient)
    patient_items = patient.work_items.preload(:clinic_patient, :visit, :reply).order(updated_at: :desc, id: :desc)
    selected = patient_items.find(params[:work]) if params[:work].present?
    [ selected, *patient_items.open.limit(20), *patient_items.where(state: "resolved").limit(20) ].compact.uniq
  end

  def candidate_details(items)
    ids = items.flat_map(&:candidate_visits).map(&:first).uniq
    clinic.visits.where(id: ids).preload(:clinic_patient).index_by(&:id)
  end

  def work_detail(item, candidates)
    visits = item.candidate_visits.filter_map do |id, revision|
      visit = candidates[id]
      next unless visit && visit.revision == revision && visit.upcoming?(Time.current)

      { id: id, revision: revision,
        label: "#{visit.clinic_patient.name} · #{visit.wall_start.strftime('%b %d at %I:%M %p')} · ##{visit.source_id}" }
    end
    work_summary(item).merge(reply_body: item.reply&.body, candidates: visits)
  end

  def contact_fields(patient)
    effective = patient.effective_contact
    ClinicPatient::CONTACT_FIELDS.index_with do |field|
      source = patient.source_contact[field]
      verified = patient.verified_contact[field]
      { value: effective[field], source: source, verification: verified, version: patient.contact_version(field),
        conflict: verified.present? && verified["source"] != source && verified["value"] != source }
    end
  end

  def next_visit(patient)
    visit = patient.visits.scheduled.where(starts_at: Time.current...).order(:starts_at, :id).preload(:clinic_patient).first
    visit_summary(visit, []) if visit
  end
end
