class ApplicationController < ActionController::API
  class InvalidInput < StandardError; end

  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "This record isn't available in the selected workspace." }, status: :not_found
  end

  rescue_from InvalidInput, ActionController::ParameterMissing do |error|
    render json: { error: error.message }, status: :unprocessable_content
  end

  rescue_from WorkflowConflict do |error|
    render json: { error: error.message }, status: :conflict
  end

  rescue_from ClinicRefresh::Unavailable do |error|
    render json: { error: error.message }, status: :service_unavailable
  end

  private

  def clinic
    @clinic ||= ClinicWorkspace.find(params[:clinic_id])
  end

  def iso_date(value, default:)
    return default if value.blank?
    raise InvalidInput, "Enter a date in YYYY-MM-DD format." unless value.is_a?(String) && value.match?(/\A\d{4}-\d{2}-\d{2}\z/)

    Date.iso8601(value)
  rescue Date::Error
    raise InvalidInput, "Enter a valid calendar date."
  end

  def positive_page
    page = Integer(params.fetch(:page, 1), exception: false)
    raise InvalidInput, "Choose a valid page." unless page&.between?(1, 10_000)

    page
  end

  def request_uuid(key)
    value = params.expect(key)
    unless value.is_a?(String) && value.match?(/\A[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\z/i)
      raise InvalidInput, "Supply a valid request ID."
    end
    value.downcase
  end
end
