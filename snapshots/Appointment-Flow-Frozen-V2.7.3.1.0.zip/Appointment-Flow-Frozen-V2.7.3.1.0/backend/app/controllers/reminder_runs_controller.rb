class ReminderRunsController < StaffController
  def create
    result = ReminderRun.new(clinic).call
    render json: result.merge(sync_status), status: :created
  end
end
