class ConversationsController < ApplicationController
  def show
    patient = clinic.clinic_patients.find(params[:clinic_patient_id])
    channel = params.fetch(:channel, "sms")
    raise InvalidInput, "Choose Text messages or Email." unless RecordReply::CHANNELS.include?(channel)

    delivered = patient.deliveries.where(clinic_workspace: clinic, channel: channel, status: "sent")
      .order(created_at: :desc, id: :desc).limit(50).to_a
    replies = patient.replies.where(clinic_workspace: clinic, channel: channel)
      .order(created_at: :desc, id: :desc).limit(50)
    messages = delivered.map { |delivery| message(delivery, "clinic") } +
      replies.map { |reply| message(reply, "patient") }

    render json: { latest_delivery_id: delivered.first&.id,
      messages: messages.sort_by { |entry| [ entry[:created_at], entry[:direction], entry[:id] ] }.last(50) }
  end

  private

  def message(record, direction)
    { id: record.id, body: record.body, created_at: record.created_at, direction: direction }
  end
end
