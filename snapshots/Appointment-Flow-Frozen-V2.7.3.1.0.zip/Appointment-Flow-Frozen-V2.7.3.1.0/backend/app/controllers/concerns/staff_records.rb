module StaffRecords
  private

  def visit_summary(visit, review_ids)
    { id: visit.id, source_id: visit.source_id, patient_id: visit.clinic_patient_id,
      patient_name: visit.clinic_patient.name, wall_start: visit.wall_start.strftime("%Y-%m-%dT%H:%M:%S"),
      local_day: visit.local_day, provider: visit.provider, minutes: visit.minutes, revision: visit.revision,
      confirmation: visit.confirmation, reply_review: review_ids.include?(visit.id),
      source_status: visit.source_status, staff_disposition: visit.staff_disposition }
  end

  def work_summary(item)
    visit = item.visit
    { id: item.id, patient_id: item.clinic_patient_id, patient_name: item.clinic_patient.name,
      kind: item.kind, state: item.state, description: item.description, assignee: item.assignee,
      visit: visit && { id: visit.id, source_id: visit.source_id, wall_start: visit.wall_start.strftime("%Y-%m-%dT%H:%M:%S") } }
  end

  def open_review_items
    clinic.work_items.open.where(kind: "reply_review").where.not(visit_id: nil)
  end
end
