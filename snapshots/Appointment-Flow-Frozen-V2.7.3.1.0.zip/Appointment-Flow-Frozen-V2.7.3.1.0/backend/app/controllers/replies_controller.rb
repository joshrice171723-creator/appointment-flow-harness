class RepliesController < ApplicationController
  def create
    patient = clinic.clinic_patients.find(params[:clinic_patient_id])
    channel = params.expect(:channel)
    body = params.expect(:body)
    unless RecordReply::CHANNELS.include?(channel) && body.is_a?(String) && body.strip.present? && body.length <= 1_000
      raise InvalidInput, "Choose Text messages or Email and enter a reply of 1 to 1,000 characters."
    end

    delivery = patient.deliveries.where(clinic_workspace: clinic, channel: channel, status: "sent")
      .find(params.expect(:delivery_id))
    reply = RecordReply.new(clinic, patient: patient, delivery: delivery, event_id: request_uuid(:event_id),
      channel: channel, sender: delivery.recipient, body: body).call
    render json: { id: reply.id, result: reply.result }
  end
end
