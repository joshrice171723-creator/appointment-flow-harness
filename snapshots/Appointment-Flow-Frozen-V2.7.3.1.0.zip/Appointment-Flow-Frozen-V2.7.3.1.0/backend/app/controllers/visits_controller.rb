class VisitsController < StaffController
  include StaffRecords

  PAGE_SIZE = 25

  def index
    date = iso_date(params[:date], default: Time.current.in_time_zone(clinic.zone).to_date)
    full_day = clinic.visits.where(local_day: date)
    review_visits = full_day.where(id: open_review_items.select(:visit_id))
    totals = full_day.group(:confirmation).count
    counts = { all: totals.values.sum, confirmed: totals.fetch("confirmed", 0),
      unconfirmed: totals.fetch("unconfirmed", 0), review: review_visits.count }
    displayed = filtered_visits(full_day, review_visits)
    page = positive_page
    visits = displayed.order(:wall_start, :id).offset((page - 1) * PAGE_SIZE).limit(PAGE_SIZE).preload(:clinic_patient).to_a
    reviews = open_review_items.where(visit_id: visits.map(&:id)).distinct.pluck(:visit_id).to_set

    render json: sync_status.merge(
      visits: visits.map { |visit| visit_summary(visit, reviews) },
      week: clinic.visits.where(local_day: date.all_week(:monday)).group(:local_day).count,
      totals: counts, total: counts.fetch(params.fetch(:filter, "all").to_sym)
    )
  end

  private

  def filtered_visits(full_day, review_visits)
    case params.fetch(:filter, "all")
    when "all" then full_day
    when "confirmed", "unconfirmed" then full_day.where(confirmation: params[:filter])
    when "review" then review_visits
    else raise InvalidInput, "Choose an appointment status filter."
    end
  end
end
