class LeadershipController < ApplicationController
  def show
    @clinics = ClinicWorkspace.order(:id).to_a
    requested = params[:month]
    if requested.present? && !(requested.is_a?(String) && requested.match?(/\A\d{4}-\d{2}\z/))
      raise InvalidInput, "Choose an outcome month."
    end
    now = Time.current
    month = iso_date(requested.presence && "#{requested}-01", default: now.to_date.beginning_of_month)
    history = PmsRecord.transaction(isolation: :repeatable_read) do
      (0..2).map { |months_ago| month_report(month.prev_month(months_ago), now) }
    end
    render json: { month: month.strftime("%Y-%m"), clinics: history.first.fetch(:clinics), history: history }
  rescue ActiveRecord::ConnectionNotEstablished, ActiveRecord::ConnectionFailed, ActiveRecord::StatementInvalid => error
    # Connection and statement failures should be visible to local diagnostics.
    raise ClinicRefresh::Unavailable, "Appointment reporting is currently unavailable.", cause: error
  end

  private

  def month_report(month, now)
    outcomes = outcome_counts(month, now)
    activity = activity_counts(month)

    { month: month.strftime("%Y-%m"), clinics: @clinics.map { |clinic| clinic_totals(clinic, outcomes, activity) } }
  end

  def outcome_counts(month, now)
    cohort = PmsAppointment.none
    @clinics.group_by(&:timezone).each_value do |clinics|
      local_now = now.in_time_zone(clinics.first.zone)
      local_wall = Time.utc(local_now.year, local_now.month, local_now.day, local_now.hour, local_now.min, local_now.sec)
      stop = [ month.next_month.beginning_of_day.utc, local_wall ].min
      cohort = cohort.or(PmsAppointment.where(clinic_id: clinics.map(&:id), start_at: month.beginning_of_day.utc...stop))
    end
    cohort.group(:clinic_id, :status).count
  end

  def activity_counts(month)
    range = month.beginning_of_day.utc...month.next_month.beginning_of_day.utc
    ids = @clinics.map(&:id)
    { deliveries: Delivery.where(clinic_workspace_id: ids, created_at: range).group(:clinic_workspace_id, :status).count,
      replies: Reply.where(clinic_workspace_id: ids, created_at: range).group(:clinic_workspace_id, :result).count,
      work: WorkItem.where(clinic_workspace_id: ids, created_at: range).group(:clinic_workspace_id, :state, :kind).count,
      follow_ups: StaffAction.where(clinic_workspace_id: ids, created_at: range).where.not(outcome: "verified_contact")
        .group(:clinic_workspace_id).count }
  end

  def clinic_totals(clinic, outcomes, activity)
    id = clinic.id
    statuses = outcomes.filter_map { |(clinic_id, status), count| [ status, count ] if clinic_id == id }.to_h
    completed = statuses.fetch("complete", 0)
    canceled = statuses.fetch("broken", 0)
    recorded = statuses.values.sum
    work = activity.fetch(:work).select { |(clinic_id, _, _), _| clinic_id == id }
    {
      id: id, name: clinic.name, recorded: recorded, completed: completed, canceled: canceled,
      unknown: recorded - completed - canceled,
      sent: activity.fetch(:deliveries).fetch([ id, "sent" ], 0),
      failed: activity.fetch(:deliveries).fetch([ id, "failed" ], 0),
      confirmed_replies: activity.fetch(:replies).fetch([ id, "confirmed" ], 0),
      review_replies: activity.fetch(:replies).fetch([ id, "review" ], 0),
      open_holds: work.sum { |(_, state, kind), count| kind == "contact_hold" && state != "resolved" ? count : 0 },
      resolved_holds: work.fetch([ id, "resolved", "contact_hold" ], 0),
      work_total: work.values.sum, follow_ups: activity.fetch(:follow_ups).fetch(id, 0)
    }
  end
end
