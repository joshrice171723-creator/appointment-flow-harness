class WorkItemsController < StaffController
  include StaffRecords

  def index
    full_board = clinic.work_items
    matching = apply_filters(full_board)
    states = board_states
    totals = full_board.group(:state).count
    matching_totals = matching.where(state: states).group(:state).count

    size = Integer(params.fetch(:per_page, 5), exception: false)
    raise InvalidInput, "Choose 5, 10 or 20 items per column." unless [ 5, 10, 20 ].include?(size)

    queues = states.index_with { |state| queue(matching.where(state: state), state, size, matching_totals.fetch(state, 0)) }
    render json: sync_status.merge(totals: %w[needs_attention in_progress resolved].index_with { |state| totals.fetch(state, 0) },
      queues: queues)
  end

  private

  def board_states
    case params.fetch(:mode, "active")
    when "active" then %w[needs_attention in_progress]
    when "resolved" then [ "resolved" ]
    else raise InvalidInput, "Choose active or resolved work."
    end
  end

  def apply_filters(scope)
    kind = params[:kind]
    search = params.fetch(:search, "")
    raise InvalidInput, "Enter a patient name up to 80 characters." unless search.is_a?(String) && search.length <= 80

    if kind.present?
      raise InvalidInput, "Choose a follow-up type." unless WorkItem::KINDS.include?(kind)
      scope = scope.where(kind: kind)
    end
    prefix = search.squish.downcase
    return scope if prefix.empty?

    range = prefix..."#{prefix}\u{10ffff}"
    people = clinic.clinic_patients.where(search_name: range).or(clinic.clinic_patients.where(search_last_name: range))
    scope.where(clinic_patient_id: people.select(:id))
  end

  def queue(scope, state, size, total)
    page = Integer(params.fetch(state, 1), exception: false)
    raise InvalidInput, "Choose a valid page." unless page&.between?(1, 10_000)

    items = scope.order(updated_at: :desc, id: :desc).offset((page - 1) * size).limit(size).preload(:clinic_patient, :visit)
    { items: items.map { |item| work_summary(item) }, total: total }
  end
end
