class ClinicsController < ApplicationController
  def index
    render json: ClinicWorkspace.order(:id).map { |entry| clinic_summary(entry) }
  end

  private

  def clinic_summary(entry)
    { id: entry.id, name: entry.name, timezone: entry.timezone,
      staff: entry.staff_members, today: Time.current.in_time_zone(entry.zone).to_date }
  end
end
