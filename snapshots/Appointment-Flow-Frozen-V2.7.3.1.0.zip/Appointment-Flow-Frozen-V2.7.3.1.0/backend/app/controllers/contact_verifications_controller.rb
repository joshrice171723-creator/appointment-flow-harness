class ContactVerificationsController < StaffController
  def create
    @patient_id = clinic.clinic_patients.find(params[:clinic_patient_id]).id
    @field = params.expect(:field)
    @value = verified_value
    @request_id = request_uuid(:request_id)
    @version = params.expect(:contact_version)

    action = clinic.with_lock { previous_action } ||
      ClinicTransaction.with_fresh_edit(clinic, now: Time.current) { previous_action || verify_contact }
    render json: { id: action.id, field: @field, value: @value }
  end

  private

  def verified_value
    value = params.fetch(:value, nil)
    unless ClinicPatient::CONTACT_FIELDS.include?(@field) && value.is_a?(String) && value.length <= 250
      raise InvalidInput, "Choose a contact field and enter a value."
    end
    value = value.strip
    valid = case @field
    when "birthdate"
      date = iso_date(value, default: nil)
      date && date <= Time.current.in_time_zone(clinic.zone).to_date
    when "wireless_phone" then value.empty? || ClinicPatient.sms_address(value)
    when "email" then value.empty? || ClinicPatient.email_address(value)
    when "preferred_language" then ReminderRun::LANGUAGES.include?(value)
    end
    raise InvalidInput, "Enter a valid #{ @field.tr('_', ' ') }." unless valid

    value.presence
  end

  def previous_action
    action = clinic.staff_actions.find_by(request_id: @request_id)
    return unless action
    if action.clinic_patient_id != @patient_id || action.staff != @staff || action.outcome != "verified_contact" ||
        action.details.values_at("field", "value") != [ @field, @value ]
      raise WorkflowConflict, "This request ID was already used for another action."
    end

    action
  end

  def verify_contact
    patient = clinic.clinic_patients.find(@patient_id)
    if @version != patient.contact_version(@field)
      raise WorkflowConflict, "Contact details changed. Reopen this patient before verifying."
    end

    source = patient.source_contact[@field]
    audit = clinic.staff_actions.create!(clinic_patient: patient, request_id: @request_id, staff: @staff,
      outcome: "verified_contact", note: "Verified #{@field.tr('_', ' ')}.",
      details: { field: @field, value: @value, source: source, previous: patient.effective_contact[@field] })
    patient.verified_contact = patient.verified_contact.merge(
      @field => { "value" => @value, "source" => source, "staff" => @staff, "at" => audit.created_at.iso8601 }
    )
    patient.refresh_addresses
    patient.save!
    audit
  end
end
