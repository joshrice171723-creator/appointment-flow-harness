class InboxPatientsController < ApplicationController
  def index
    render json: clinic.clinic_patients.order(:name, :id).limit(100).as_json(only: %i[id name])
  end
end
