class FollowUpsController < StaffController
  def create
    outcome = params.expect(:outcome)
    note = params.expect(:note)
    unless StaffFollowUp::OUTCOMES.include?(outcome) && note.is_a?(String) && note.strip.present? && note.length <= 1_000
      raise InvalidInput, "Select an outcome and enter a note of 1 to 1,000 characters."
    end

    ids = params.fetch(:visit_ids, [])
    unless ids.is_a?(Array) && ids.size <= 20 && ids.all? { |id| id.is_a?(Integer) && id.positive? }
      raise InvalidInput, "Choose up to 20 valid appointments."
    end

    item = clinic.work_items.find(params[:work_item_id])
    action = StaffFollowUp.new(clinic, item_id: item.id, staff: @staff, request_id: request_uuid(:request_id),
      outcome: outcome, note: note.strip, visit_ids: ids.uniq.sort).call
    render json: { id: action.id, outcome: action.outcome }
  end
end
