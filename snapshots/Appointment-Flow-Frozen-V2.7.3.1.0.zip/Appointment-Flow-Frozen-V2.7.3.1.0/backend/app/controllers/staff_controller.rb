class StaffController < ApplicationController
  before_action :select_staff

  private

  def select_staff
    @staff = request.headers["X-Apex-Staff"]
    unless clinic.staff_members.include?(@staff)
      render json: { error: "Select a staff member for this clinic." }, status: :forbidden
    end
  end

  def sync_status
    { synced_at: clinic.synced_at, sync_error: clinic.sync_error }
  end
end
