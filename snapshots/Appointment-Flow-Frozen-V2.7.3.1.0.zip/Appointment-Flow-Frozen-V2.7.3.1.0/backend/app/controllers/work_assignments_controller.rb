class WorkAssignmentsController < StaffController
  def update
    clinic.with_lock do
      item = clinic.work_items.find(params[:work_item_id])
      if item.state == "resolved" || (item.assignee && item.assignee != @staff)
        raise WorkflowConflict, "This work item is closed or assigned to another staff member."
      end

      item.update!(state: "in_progress", assignee: @staff)
      render json: { id: item.id, state: item.state, assignee: item.assignee }
    end
  end
end
