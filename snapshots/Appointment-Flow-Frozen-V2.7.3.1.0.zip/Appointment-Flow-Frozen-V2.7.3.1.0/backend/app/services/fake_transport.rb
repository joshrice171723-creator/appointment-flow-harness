class FakeTransport
  def deliver(visit:, step:, channel:, recipient:, body:)
    failed = recipient.end_with?("5550199") || recipient == "undeliverable@example.test"
    visit.deliveries.create!(
      clinic_workspace_id: visit.clinic_workspace_id, clinic_patient_id: visit.clinic_patient_id,
      revision: visit.revision, step: step, channel: channel, recipient: recipient,
      status: failed ? "failed" : "sent", body: body
    )
  end
end
