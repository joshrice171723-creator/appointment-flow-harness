class RecordReply
  CHANNELS = %w[sms email].freeze
  CONFIRMATIONS = %w[YES SI SÍ].freeze

  def initialize(clinic, patient:, delivery:, event_id:, channel:, sender:, body:, now: Time.current)
    @clinic = clinic
    @patient = patient
    @delivery = delivery
    @event_id = event_id
    @channel = channel
    @sender = channel == "sms" ? ClinicPatient.sms_address(sender) : ClinicPatient.email_address(sender)
    @body = body
    @command = body.strip.upcase
    @now = now
  end

  def call
    if @command == "STOP" && @channel == "sms" && expected_sender?
      @clinic.with_lock { existing_reply || record_opt_out }
    else
      # Replay should remain available even when a later source refresh is unavailable.
      @clinic.with_lock { existing_reply } ||
        ClinicTransaction.with_fresh_source(@clinic, now: @now) { existing_reply || record_intent }
    end
  end

  private

  def existing_reply
    reply = @clinic.replies.find_by(event_id: @event_id)
    return unless reply
    if reply.clinic_patient_id != @patient.id || reply.delivery_id != @delivery&.id ||
        reply.channel != @channel || reply.body != @body
      raise WorkflowConflict, "This request ID was already used for another reply."
    end

    reply
  end

  def expected_sender?
    @sender.present? && @delivery&.status == "sent" && @delivery.channel == @channel &&
      @delivery.recipient == @sender && @delivery.clinic_workspace_id == @clinic.id &&
      @delivery.clinic_patient_id == @patient.id
  end

  def record_opt_out
    @clinic.sms_opt_outs.find_or_create_by!(recipient: @sender)
    create_reply("opted_out")
  end

  def record_intent
    visit = @clinic.visits.find_by(id: @delivery&.visit_id)
    candidates = candidate_visits
    if CONFIRMATIONS.include?(@command) && unambiguous_current_reply?(visit, candidates)
      confirm_visit(visit)
    else
      record_review(visit, candidates)
    end
  end

  def candidate_visits
    return [] unless @sender

    field = @channel == "sms" ? :sms_address : :email_address
    @clinic.visits.scheduled.joins(:clinic_patient)
      .where(clinic_patients: { field => @sender })
      .where(starts_at: @now...)
      .order(:starts_at, :id).limit(21).pluck(:id, :revision)
  end

  def unambiguous_current_reply?(visit, candidates)
    return false unless expected_sender? && visit&.upcoming?(@now)
    return false unless visit.revision == @delivery.revision && visit.clinic_patient_id == @patient.id
    return false unless candidates == [ [ visit.id, visit.revision ] ]

    patient = @patient.reload
    field = @channel == "sms" ? :sms_address : :email_address
    today = @now.in_time_zone(@clinic.zone).to_date
    patient.adult_on?(today) && !patient.contact_conflict? &&
      patient.public_send(field) == @sender &&
      !@clinic.clinic_patients.where(field => @sender).where.not(id: patient.id).exists? &&
      (@channel != "sms" || !@clinic.sms_opt_outs.exists?(recipient: @sender)) &&
      !visit.work_items.open.where(kind: "reply_review", revision: visit.revision).exists?
  end

  def confirm_visit(visit)
    visit.update!(confirmation: "confirmed")
    visit.work_items.open.where(kind: "no_confirmation", revision: visit.revision)
      .update_all(state: "resolved", updated_at: @now)
    create_reply("confirmed")
  end

  def record_review(visit, candidates)
    reply = create_reply("review")
    current_visit = visit if visit && visit.revision == @delivery.revision && visit.clinic_patient_id == @patient.id
    @clinic.work_items.create!(
      clinic_patient: @patient, visit: current_visit, revision: current_visit&.revision, reply: reply,
      dedupe_key: "reply:#{reply.id}", kind: "reply_review", description: review_reason(visit, candidates),
      candidate_visits: candidates.first(20)
    )
    reply
  end

  def review_reason(visit, candidates)
    return "The reply arrived for an earlier appointment version." if visit && visit.revision != @delivery.revision
    return "The appointment is past or no longer scheduled." if visit && !visit.upcoming?(@now)
    return "Clarify which appointment this reply concerns." if candidates.size > 1
    return "The patient asked for help with this appointment." if @command == "NO"

    "Review the reply and verify the appointment with the patient."
  end

  def create_reply(result)
    @clinic.replies.create!(clinic_patient: @patient, delivery: @delivery, channel: @channel,
      event_id: @event_id, body: @body, result: result)
  end
end
