class WorkflowConflict < StandardError
end
