class ClinicRefresh
  class Unavailable < StandardError; end

  def initialize(clinic, now:)
    @clinic = clinic
    @now = now
    @today = now.in_time_zone(clinic.zone).to_date
  end

  # The caller holds the clinic row lock. The source snapshot has its own read-only connection.
  def call
    tracked_ids = @clinic.visits.where(source_status: "scheduled", local_day: @today..).pluck(:source_id)
    appointments, patients = read_source(tracked_ids)
    known_visits = @clinic.visits.where(source_id: appointments.map(&:id)).index_by(&:source_id)

    local_patients = save_patients(patients)
    appointments.each { |source| save_visit(source, known_visits[source.id], local_patients.fetch(source.patient_id)) }
    @clinic.update!(synced_at: @now, sync_error: nil)
  end

  private

  def read_source(tracked_ids)
    PmsRecord.transaction(isolation: :repeatable_read) do
      unless PmsClinic.exists?(@clinic.id)
        raise Unavailable, "Clinic is unavailable in the PMS."
      end

      clinic_appointments = PmsAppointment.where(clinic_id: @clinic.id)
      range = (@today - 7).beginning_of_day.utc...(@today + 15).beginning_of_day.utc
      appointments = clinic_appointments.where(start_at: range)
        .or(clinic_appointments.where(id: tracked_ids)).to_a
      if (tracked_ids - appointments.map(&:id)).any?
        raise Unavailable, "The PMS did not return previously tracked appointments."
      end

      patient_ids = appointments.map(&:patient_id).uniq
      patients = PmsPatient.where(id: patient_ids).to_a
      if patients.size != patient_ids.size
        raise Unavailable, "The PMS did not return all appointment patients."
      end

      [ appointments, patients ]
    end
  rescue ActiveRecord::ConnectionNotEstablished, ActiveRecord::ConnectionFailed, ActiveRecord::StatementInvalid => error
    raise Unavailable, "The PMS could not be read. Try refreshing again.", cause: error
  end

  def save_patients(source_patients)
    local_patients = @clinic.clinic_patients.where(source_id: source_patients.map(&:id)).index_by(&:source_id)
    source_patients.to_h do |source|
      patient = local_patients[source.id] || @clinic.clinic_patients.build(source_id: source.id)
      patient.assign_attributes(
        name: "#{source.first_name} #{source.last_name}",
        search_name: "#{source.first_name} #{source.last_name}".squish.downcase, search_last_name: source.last_name.squish.downcase,
        guardian_required: source.guarantor_id.present?,
        source_contact: {
          birthdate: source.birthdate&.iso8601, wireless_phone: source.wireless_phone,
          email: source.email, preferred_language: source.preferred_language
        }.stringify_keys
      )
      patient.refresh_addresses
      patient.save! if patient.changed?
      [ source.id, patient ]
    end
  end

  def save_visit(source, tracked_visit, patient)
    visit = tracked_visit || @clinic.visits.build(source_id: source.id)
    if version_changed?(visit, source, patient)
      visit.work_items.open.update_all(state: "resolved", updated_at: @now)
      visit.assign_attributes(revision: visit.revision + 1, confirmation: "unconfirmed", staff_disposition: nil)
    elsif visit.source_status == "scheduled" && source.status != "scheduled"
      visit.work_items.open.where.not(kind: "reply_review").update_all(state: "resolved", updated_at: @now)
    end

    visit.assign_attributes(
      clinic_patient: patient, wall_start: source.start_at, starts_at: @clinic.wall_instant(source.start_at),
      local_day: source.start_at.to_date, source_status: source.status,
      provider: source.provider_name, minutes: source.length_minutes
    )
    visit.save! if visit.changed?
  end

  def version_changed?(visit, source, patient)
    visit.persisted? && (visit.wall_start != source.start_at || visit.clinic_patient_id != patient.id ||
      (visit.source_status != "scheduled" && source.status == "scheduled"))
  end
end
