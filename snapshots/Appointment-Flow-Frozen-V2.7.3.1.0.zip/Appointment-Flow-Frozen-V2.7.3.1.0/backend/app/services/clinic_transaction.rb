class ClinicTransaction
  def self.with_fresh_source(clinic, now:)
    source_failure = nil
    result = clinic.with_lock do
      begin
        ClinicRefresh.new(clinic, now: now).call
      rescue ClinicRefresh::Unavailable => error
        clinic.update!(sync_error: error.message)
        source_failure = error
      end
      yield unless source_failure
    end
    raise source_failure if source_failure

    result
  end

  # A rejected edit can leave the successful refresh visible for the next attempt.
  def self.with_fresh_edit(clinic, now:, &edit)
    edit_failure = nil
    result = with_fresh_source(clinic, now: now) do
      begin
        ClinicWorkspace.transaction(requires_new: true, &edit)
      rescue WorkflowConflict => error
        edit_failure = error
      end
    end
    raise edit_failure if edit_failure

    result
  end
end
