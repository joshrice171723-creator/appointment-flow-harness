class ReminderRun
  LEAD_DAYS = 7
  BACKUP_DAY = 6
  FOLLOW_UP_DAY = 3
  FINAL_DAY = 1
  SEND_HOURS = 10...18
  LANGUAGES = %w[en es].freeze
  Batch = Data.define(:shared_phones, :shared_emails, :opt_outs, :history, :open_work)

  def initialize(clinic, now: Time.current, transport: FakeTransport.new)
    @clinic = clinic
    @now = now
    @local_now = now.in_time_zone(clinic.zone)
    @transport = transport
  end

  def call
    ClinicTransaction.with_fresh_source(@clinic, now: @now) do
      counts = { sent: 0, failed: 0 }
      eligible_visits.find_in_batches(batch_size: 200) do |visits|
        batch = load_batch(visits)
        visits.each do |visit|
          process_visit(visit, batch).each { |delivery| counts[delivery.status.to_sym] += 1 }
        end
      end
      counts
    end
  end

  private

  def eligible_visits
    today = @local_now.to_date
    unconfirmed = @clinic.visits.scheduled.where(local_day: today..(today + LEAD_DAYS), confirmation: "unconfirmed")
    unconfirmed.where(starts_at: nil).or(unconfirmed.where(starts_at: @now..)).preload(:clinic_patient)
  end

  def load_batch(visits)
    phones = visits.filter_map { |visit| visit.clinic_patient.sms_address }.uniq
    emails = visits.filter_map { |visit| visit.clinic_patient.email_address }.uniq
    versions = visits.map { |visit| [ visit.id, visit.revision ] }
    attempts = @clinic.deliveries.where([ :visit_id, :revision ] => versions)
      .pluck(:visit_id, :step, :channel, :status).group_by(&:first)
    work = @clinic.work_items.open.where([ :visit_id, :revision ] => versions)
      .distinct.pluck(:visit_id, :kind).group_by(&:first)
    Batch.new(shared_addresses(:sms_address, phones), shared_addresses(:email_address, emails),
      @clinic.sms_opt_outs.where(recipient: phones).pluck(:recipient).to_set, attempts, work)
  end

  def shared_addresses(field, addresses)
    counts = @clinic.clinic_patients.where(field => addresses).group(field).count
    counts.select { |_, count| count > 1 }.keys.to_set
  end

  def process_visit(visit, batch)
    unless visit.starts_at
      WorkItem.for_visit!(visit, "contact_hold", "The clinic-local appointment time is ambiguous or invalid.")
      return []
    end
    return [] unless visit.upcoming?(@now)

    hold, channels = outreach_options(visit.clinic_patient, batch)
    if hold
      WorkItem.for_visit!(visit, "contact_hold", hold)
      return []
    end

    open_kinds = batch.open_work.fetch(visit.id, []).map(&:last)
    update_follow_up(visit, open_kinds)
    return [] unless SEND_HOURS.cover?(@local_now.hour)
    return [] if open_kinds.include?("reply_review")

    send_current_step(visit, channels, batch.history.fetch(visit.id, []))
  end

  def update_follow_up(visit, open_kinds)
    if open_kinds.include?("contact_hold")
      visit.work_items.open.where(kind: "contact_hold", revision: visit.revision)
        .update_all(state: "resolved", updated_at: @now)
    end
    if visit.starts_at <= @now + 48.hours && !open_kinds.include?("no_confirmation")
      WorkItem.for_visit!(visit, "no_confirmation", "The appointment starts within 48 hours and needs confirmation.")
    end
  end

  def outreach_options(patient, batch)
    return [ "Verify patient age and responsible-party permission." ] unless patient.adult_on?(@local_now.to_date)
    return [ "Review the change to verified contact details in the PMS." ] if patient.contact_conflict?
    unless LANGUAGES.include?(patient.effective_contact["preferred_language"])
      return [ "Verify a supported preferred language." ]
    end

    channels = {}
    phone = patient.sms_address
    email = patient.email_address
    channels["sms"] = phone if phone && !batch.shared_phones.include?(phone) && !batch.opt_outs.include?(phone)
    channels["email"] = email if email && !batch.shared_emails.include?(email)
    return [ "Verify a unique, usable contact channel and permission." ] if channels.empty?

    [ nil, channels ]
  end

  def send_current_step(visit, channels, history)
    days = (visit.local_day - @local_now.to_date).to_i
    step, channel = scheduled_step(days, channels, history)
    return [] unless channel
    return [] if history.any? { |_, prior_step, _, _| prior_step == step }

    first = deliver(visit, step, channel, channels.fetch(channel))
    if first.status == "failed" && channel == "sms" && channels.key?("email")
      [ first, deliver(visit, step, "email", channels.fetch("email")) ]
    else
      [ first ]
    end
  end

  def scheduled_step(days, channels, history)
    case days
    when (FOLLOW_UP_DAY + 1)..LEAD_DAYS
      if days <= BACKUP_DAY && history.any? { |_, step, channel, status| [ step, channel, status ] == %w[initial sms sent] }
        return [ "backup", "email" ] if channels.key?("email")
        return []
      end
      [ "initial", channels.keys.first ]
    when (FINAL_DAY + 1)..FOLLOW_UP_DAY
      [ "follow_up", channels.keys.first ]
    when FINAL_DAY
      [ "final", channels.keys.first ]
    end
  end

  def deliver(visit, step, channel, address)
    delivery = @transport.deliver(visit: visit, step: step, channel: channel, recipient: address,
      body: message(visit, channel))
    if delivery.status == "failed"
      WorkItem.for_visit!(visit, "delivery_failed", "A fake #{channel.upcase} delivery failed. Review available channels.")
    end
    delivery
  end

  def message(visit, channel)
    time = visit.wall_start.strftime("%b %d, %Y at %I:%M %p")
    if visit.clinic_patient.effective_contact["preferred_language"] == "es"
      time = I18n.l(visit.wall_start.to_date, locale: :es, format: :long) + visit.wall_start.strftime(" a las %H:%M")
      text = "Apex #{@clinic.name}: Cita el #{time}. Responda SI para confirmar o NO para pedir ayuda."
      text += " Responda STOP para dejar de recibir mensajes." if channel == "sms"
    else
      text = "Apex #{@clinic.name}: Appointment on #{time}. Reply YES to confirm or NO for help."
      text += " Reply STOP to opt out." if channel == "sms"
    end
    text
  end
end
