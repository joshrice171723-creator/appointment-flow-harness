class StaffFollowUp
  OUTCOMES = %w[attempted confirmed rescheduled canceled clarified].freeze

  def initialize(clinic, item_id:, staff:, request_id:, outcome:, note:, visit_ids:, now: Time.current)
    @clinic = clinic
    @item_id = item_id
    @staff = staff
    @request_id = request_id
    @outcome = outcome
    @note = note
    @visit_ids = visit_ids
    @now = now
  end

  def call
    @clinic.with_lock { previous_action } ||
      ClinicTransaction.with_fresh_edit(@clinic, now: @now) do
        previous_action || apply_follow_up
      end
  end

  private

  def previous_action
    action = @clinic.staff_actions.find_by(request_id: @request_id)
    return unless action
    if [ action.work_item_id, action.staff, action.outcome, action.note, action.details["visit_ids"] ] !=
        [ @item_id, @staff, @outcome, @note, @visit_ids ]
      raise WorkflowConflict, "This request ID was already used for another action."
    end

    action
  end

  def apply_follow_up
    item = @clinic.work_items.find(@item_id)
    if item.state != "in_progress" || item.assignee != @staff
      raise WorkflowConflict, "Assign this open follow-up to yourself before saving."
    end

    visits = selected_visits(item)
    action = @clinic.staff_actions.create!(work_item: item, clinic_patient_id: item.clinic_patient_id,
      staff: @staff, request_id: @request_id, outcome: @outcome, note: @note, details: { visit_ids: @visit_ids })
    return action if @outcome == "attempted"

    visits.each { |visit| update_visit(visit) } unless @outcome == "clarified"
    item.update!(state: "resolved")
    action
  end

  def selected_visits(item)
    return [] if @outcome == "attempted" || (@outcome == "clarified" && @visit_ids.empty?)

    candidates = item.candidate_visits.dup
    candidates << [ item.visit_id, item.revision ] if item.visit_id
    expected_versions = candidates.to_h
    ids = @visit_ids
    ids = [ item.visit_id ].compact if ids.empty? && expected_versions.size <= 1
    visits = @clinic.visits.where(id: ids).to_a
    if visits.empty? || visits.size != ids.size ||
        visits.any? { |visit| expected_versions[visit.id] != visit.revision || !visit.upcoming?(@now) }
      raise WorkflowConflict, "Choose a current appointment from this follow-up. Refresh after a schedule change."
    end

    visits
  end

  def update_visit(visit)
    if @outcome == "confirmed"
      visit.update!(confirmation: "confirmed")
      kinds = %w[no_confirmation contact_hold delivery_failed]
    else
      visit.update!(staff_disposition: @outcome, confirmation: "unconfirmed")
      kinds = WorkItem::KINDS
    end
    visit.work_items.open.where(revision: visit.revision, kind: kinds)
      .update_all(state: "resolved", updated_at: @now)
  end
end
