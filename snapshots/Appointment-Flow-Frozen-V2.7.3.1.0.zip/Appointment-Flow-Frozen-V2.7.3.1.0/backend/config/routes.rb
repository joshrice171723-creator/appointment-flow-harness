Rails.application.routes.draw do
  get "up" => "rails/health#show", as: :rails_health_check
  root to: redirect("/workspace/index.html")

  scope :api do
    resource :leadership, only: :show, controller: "leadership"
    resources :clinics, only: :index do
      resource :reminder_run, only: :create
      resource :source_refresh, only: :create
      resources :visits, only: :index
      resources :inbox_patients, only: :index
      resources :clinic_patients, only: :show do
        resource :conversation, only: :show
        resources :replies, only: :create
        resource :contact_verification, only: :create
      end
      resources :work_items, only: :index do
        resource :work_assignment, only: :update
        resources :follow_ups, only: :create
      end
    end
  end
end
