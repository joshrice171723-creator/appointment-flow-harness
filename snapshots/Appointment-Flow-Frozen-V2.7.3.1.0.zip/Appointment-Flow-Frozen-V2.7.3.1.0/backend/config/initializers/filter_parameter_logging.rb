Rails.application.config.filter_parameters += %i[body note birthdate wireless_phone email preferred_language recipient details source_contact verified_contact]
