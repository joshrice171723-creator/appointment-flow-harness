import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { setTimeout as wait } from "node:timers/promises";

const browser = process.env.APEX_BROWSER ??
  "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const base = process.env.APEX_DEMO_URL ?? "http://127.0.0.1:3000";
const artifacts = resolve("tmp/apex-ui-smoke");
const profile = resolve("tmp", `browser-${process.pid}`);
await mkdir(artifacts, { recursive: true });
const child = spawn(browser, [
  "--headless=new", "--disable-gpu", "--no-first-run", "--disable-background-networking",
  "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0",
  `--user-data-dir=${profile}`,
  "--window-size=1440,1000", "about:blank"
], { windowsHide: true, stdio: "ignore" });
let spawnFailure;
child.on("error", error => { spawnFailure = error; });

async function until(label, probe) {
  for (let attempt = 0; attempt < 60; attempt++) {
    if (spawnFailure) throw spawnFailure;
    const result = await probe();
    if (result) return result;
    await wait(250);
  }
  throw new Error(`Timed out waiting for ${label}`);
}

let socket;
let messageId = 0;
const pending = new Map();
const uncaught = [];
try {
  const target = await until("an isolated browser tab", async () => {
    try {
      const debugPort = (await readFile(resolve(profile, "DevToolsActivePort"), "utf8")).split("\n")[0];
      const list = await fetch(`http://127.0.0.1:${debugPort}/json/list`).then(response => response.json());
      return list.find(entry => entry.url === "about:blank");
    } catch {
      return null;
    }
  });
  socket = new WebSocket(target.webSocketDebuggerUrl);
  socket.addEventListener("message", ({ data }) => {
    const message = JSON.parse(data);
    if (message.method === "Runtime.exceptionThrown") uncaught.push(message.params.exceptionDetails.text);
    if (!message.id) return;
    const handler = pending.get(message.id);
    pending.delete(message.id);
    if (handler) message.error ? handler.reject(new Error(message.error.message)) : handler.resolve(message.result);
  });
  await new Promise((resolveOpen, reject) => {
    socket.addEventListener("open", resolveOpen, { once: true });
    socket.addEventListener("error", reject, { once: true });
  });

  function send(method, params = {}) {
    return new Promise((resolveCommand, reject) => {
      pending.set(++messageId, { resolve: resolveCommand, reject });
      socket.send(JSON.stringify({ id: messageId, method, params }));
    });
  }
  async function evaluate(fn, ...args) {
    const response = await send("Runtime.evaluate", {
      expression: `(${fn})(...${JSON.stringify(args)})`, returnByValue: true
    });
    if (response.exceptionDetails) throw new Error(response.exceptionDetails.exception?.description ?? "Browser evaluation failed");
    return response.result.value;
  }

  const includes = text => until(text, () => evaluate(value => document.body?.innerText.includes(value), text));
  async function click(text) {
    const selector = "button, a, summary";
    await until(`an enabled control labeled ${text}`, () => evaluate((selector, label) => {
      const control = [...document.querySelectorAll(selector)]
        .find(node => !node.disabled && (node.innerText.trim().replace(/\s+/g, " ") === label.replace(/\s+/g, " ") || node.getAttribute("aria-label") === label));
      if (!control) return false;
      control.click();
      return true;
    }, selector, text));
  }
  async function choose(label, optionText) {
    await until(`${label} option ${optionText}`, () => evaluate((label, optionText) => {
      const input = [...document.querySelectorAll("select")].find(node => node.labels[0].innerText.startsWith(label));
      const option = input && [...input.options].find(entry => entry.text === optionText);
      if (!option) return false;
      input.value = option.value;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }, label, optionText));
  }
  async function type(text) {
    await until("a visible reply or note input", () => evaluate(() => {
      const input = document.querySelector("textarea");
      if (!input) return false;
      input.focus();
      return true;
    }));
    await send("Input.insertText", { text });
  }
  async function screenshot(name) {
    const result = await send("Page.captureScreenshot", { format: "png" });
    await writeFile(resolve(artifacts, name), Buffer.from(result.data, "base64"));
  }

  await send("Page.enable");
  await send("Runtime.enable");
  await send("Page.navigate", { url: base });
  await includes("Workspaces");
  await includes("Austin");
  await screenshot("01-workspaces.png");

  await click("Open front desk\n→");
  await includes("Patient flow");
  await includes("Needs attention");
  await click("Run reminders");
  await includes("Reminder run complete.");
  await choose("Follow-up type", "Confirmation needed");
  await includes("Morgan Park");
  await screenshot("02-front-desk.png");
  await click("Open follow-up for Morgan Park");
  await includes("Next scheduled appointment");
  const assignAvailable = await evaluate(() => [...document.querySelectorAll("button")].some(node => node.innerText === "Assign to me"));
  if (assignAvailable) await click("Assign to me");
  await type("Browser check: left a callback number.");
  await click("Record follow-up");
  await includes("Follow-up recorded.");
  await click("Activity log");
  await includes("left a callback number");

  await click("Workspaces ↗");
  await click("Open patient workspace\n→");
  await includes("Patient inbox");
  await choose("Clinic", "Austin");
  await choose("Patient", "Sam Reed");
  await includes("No simulated text messages");
  await click("Email");
  await includes("Reply YES");
  await type("YES");
  await click("Send reply");
  await includes("Appointment confirmed.");
  await screenshot("03-email-reply.png");
  await choose("Patient", "Alex Brooks");
  await click("Email");
  await includes("No simulated emails for this patient yet.");
  await click("Text messages");
  await includes("Reply YES");
  await type("YES");
  await click("Send reply");
  await includes("Appointment confirmed.");

  await click("← Workspaces");
  await click("Open front desk\n→");
  await click("Appointments");
  await includes("Jump to date");
  await click("Next week →");
  await includes("Sam Reed");
  const row = await evaluate(() => [...document.querySelectorAll("tbody tr")]
    .find(row => row.innerText.includes("Sam Reed"))?.innerText);
  assert.match(row, /Confirmed/);
  assert.match(row, /Unknown/);
  assert.match(await evaluate(() => [...document.querySelectorAll("tbody tr")]
    .find(row => row.innerText.includes("Alex Brooks"))?.innerText), /Confirmed/);
  await screenshot("04-appointments.png");

  await click("Workspaces ↗");
  await click("Open Apex leadership\n→");
  await includes("Clinic comparison");
  await click("Contact and follow-up");
  await includes("Staff follow-ups");
  assert.equal(await evaluate(() => document.body.innerText.includes("Sam Reed")), false);
  await screenshot("05-leadership.png");

  await click("Workspaces ↗");
  await send("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 1, mobile: true });
  await includes("Open front desk");
  assert.equal(await evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  assert.deepEqual(uncaught, []);
  await screenshot("06-mobile.png");
  console.log("PASS: desktop workspaces, staff follow-up, SMS and email replies, appointment state, leadership, and mobile layout.");
  socket.send(JSON.stringify({ id: ++messageId, method: "Browser.close" }));
  await Promise.race([new Promise(resolveClose => socket.addEventListener("close", resolveClose, { once: true })), wait(1_000)]);
} finally {
  socket?.close();
  child.kill();
}
