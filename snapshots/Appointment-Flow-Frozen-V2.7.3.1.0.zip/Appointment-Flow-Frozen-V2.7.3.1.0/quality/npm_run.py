"""Run the project's npm scripts on Windows or a POSIX runner."""
import os
import subprocess
import sys

raise SystemExit(subprocess.call(["npm.cmd" if os.name == "nt" else "npm", *sys.argv[1:]]))
