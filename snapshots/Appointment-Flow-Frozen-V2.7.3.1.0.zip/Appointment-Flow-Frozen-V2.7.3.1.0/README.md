# Apex Appointment Flow

Rails, React and PostgreSQL assessment demo for appointment reminders, patient responses and clinic follow-up. The seed contains fictional patients in Austin and Phoenix. Messages are stored in PostgreSQL by the fake SMS/email adapter.

## Start locally

On Windows, use Ruby 3.4, Bundler, Node 24, npm, Python 3.11 and PostgreSQL 17 client/server tools. The tested versions were Ruby 3.4.10, Rails 8.1.4.1, Bundler 4.0.15, Node 24.19.0, npm 11.17.0, Python 3.11.15 and PostgreSQL 17.11. The setup script creates a dedicated loopback-only PostgreSQL cluster under `tmp` on port 55473. It uses local demo roles and trust authentication inside that cluster.

From the root directory in PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File script/setup.ps1
Set-Location backend
ruby bin/rails server -b 127.0.0.1 -p 3000
```

Open [the local workspace](http://127.0.0.1:3000/). Supply `-PostgresBin 'path/to/bin'` to the setup script if PostgreSQL is installed elsewhere. Use the script for initial setup on an empty cluster. Re-running seeds moves the synthetic source dates relative to the current day and can start new visit versions. The environment variable `APEX_DB_USER=apex_admin` is reserved for setup and tests. The running development server uses `apex_app` and a separate `apex_reader` connection. Keep this demo on loopback.

## Walk through the demo

1. Open **Front desk**, choose Austin and a staff member, and select **Run reminders**. The button refreshes the clinic from the PMS and runs the current reminder window. Outside 10:00–18:00 clinic time it refreshes and opens appropriate staff work. The seed has already run one batch at a simulated 11:00 local time for each clinic and includes assigned and resolved follow-up examples.
2. Return to **Workspaces** and open **Patient**. Choose Austin and Alex Brooks for a text, or Sam Reed for an email. View the history, type `YES`, and choose **Send reply**. A confirming reply updates the matching visit. Try `NO` in a separate conversation for staff review or exact `STOP` on a text to opt out.
3. In **Appointments**, jump to seven days from the clinic's current date and use **Confirmed**. The appointment confirmation and PMS outcome appear in separate columns. In **Patient flow**, open another patient's follow-up, assign it to yourself, and save a note with an outcome.
4. Visit **Apex leadership** and expand the report sections. Counts derive from PMS outcomes and local activity. The reporting page explains how the completion rate is calculated.

The calendar reads cached visits from the most recent successful refresh, which imports the prior seven days and next fifteen days including today, plus previously tracked future scheduled visits. Use **Sync appointments** to refresh the read model without running reminders.

## Reminder rules

The batch selects upcoming scheduled visits by clinic-local calendar date. Initial outreach begins seven days out, prefers a unique authorized SMS number and uses email when SMS is unavailable. If the initial SMS succeeds and the visit remains unconfirmed, email can back it up starting at six days. An SMS failure can fall back immediately to email. At three days and one day, the batch sends the current request if eligible. Missed stages coalesce, and confirmed visits skip further outreach. A manual batch or a scheduler invoking the same entry point supplies the repeat cadence. The demo has no persistent scheduler.

On-file contact permission is a fixture assumption. Unsafe age or guardian records, uncertain verified contacts, unsupported language and unavailable channels create staff work. The policy suppresses addresses shared by patients in the clinic's known roster, including retained snapshots. It uses the same clinic boundary for opt-outs. Source updates are visible after replication and refresh. The PMS source has no revision token, so the app increments a local version when it observes a changed start time, patient, or return to scheduled status. Ambiguous or nonexistent local times are held for staff review.

## Checks

```powershell
python quality/run_checks.py
$env:APEX_WORKLOAD = '1'
Set-Location backend
ruby bin/rails test test/integration/reminder_workload_test.rb test/integration/workspace_reads_test.rb
```

With the seeded server running, `node quality/browser_smoke.mjs` exercises SMS, email and staff flows in headless Edge. It writes screenshots under `tmp/apex-ui-smoke`.

The packaged preflight verifies the original harness inputs before application work. See the dated [build log](notes/BUILD_LOG.md) for that run and [rubric results](review/RUBRIC_RESULTS.md) for application evidence.

See [architecture](ARCHITECTURE.md), [AI usage](AI_USAGE.md) and [candidate decision notes](notes/CANDIDATE_DECISION_NOTES.md). The submission's `DECISIONS.md` is a candidate-authored deliverable.
