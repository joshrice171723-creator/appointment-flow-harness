# Rebuild grading record

## Round 1 — independent review

Application checkpoint `b912a6e7a6b1a1fad5d2060ae0e7eb4cf71abee3`. Overall **REVISE**. The independent Codex reviewer used the local checkpoint, source, and assertions in the focused suites. Browser, clean setup and disposable rule-change verification were still running during the review.

| Criterion | Grade | Evidence |
| --- | --- | --- |
| Required behavior | REVISE | Core reminder and reply paths were exercised by `reminder_runs_request_test.rb` and `replies_test.rb`. Contact clearing and stale-contact recovery failed on source review. |
| Safety and data boundaries | REVISE | Request tests verified clinic scope, deduplication, source permissions, new-visit revision and opt-out persistence. An unsupported or malformed explicit phone prefix could redirect outreach. |
| Performance and Rails queries | PASS | The day GET and batch POST produced identical results and stable reads as older data grew. PostgreSQL used the date and clinic indexes. The source refresh reads the time window and relevant tracked IDs. |
| Material workflow coverage | PASS | Review covered refresh, reminders, inbound reply, assignment, staff follow-up, verification, appointment and board reads, inbox and reporting. |
| Human readability | PASS | HTTP actions expose scope and return fields. Each cross-record write has a named workflow or transaction and the local business lock is visible at the entry point. |
| Ease of change | UNVERIFIED | Disposable rule-change exercise pending. |
| Failure and transaction behavior | REVISE | Reminder rollback was exercised. An expected stale edit also rolled back the successful source refresh, making the reopen instruction ineffective. |
| Verification and handoff | UNVERIFIED | Fresh setup, gate and browser evidence pending. |

### Verified findings and repairs

1. `ClinicPatient.sms_address` stripped arbitrary plus signs, so strings such as `+512-555-0102` could be sent to a different address. The repair accepts an explicit plus only as part of an actual `+1` country prefix and rejects malformed placement. The HTTP test verifies zero sends for the invalid fixtures and a send to the single corrected positive control.
2. `ContactVerificationsController#verify_contact` raised a conflict under the same transaction as source refresh. Reopening the patient showed the old token. The staff edit savepoint preserves successful refresh on an expected conflict. An unexpected local persistence error still rolls back edits and the outer snapshot. HTTP tests verify the reported status, new source value, and persisted state after a database constraint failure following an audit insert.
3. Rails strong-parameter `expect` rejected the empty string before the documented clearing branch ran. The controller now validates a direct fetch, which accepts an explicit blank phone or email and rejects omitted or non-string input. The HTTP regression verifies the local blank, unchanged source phone, and a held next reminder run.

The post-repair targeted suite passed 7 tests with 47 assertions. The final regrade and gate follow below.


## Round 2 — independent regrade and completed checks

Application revision `b67b1a85be9b4b7b7c5fc61349e4bcb28a2648e9`. Overall **PASS**. The independent reviewer examined the repair diff and the assertions for all three findings. The following local executions closed the remaining evidence items. The technical-freeze commit changes handoff documents only.

| Criterion | Grade | Evidence |
| --- | --- | --- |
| Required behavior | PASS | The real UI started an Austin reminder run, recorded a staff follow-up note, and submitted `YES` in both SMS and email. The appointment table showed confirmations with source outcome still Unknown. The Rails request suite asserts the separate PMS-outcome counts and checks the in-window, out-of-window, and due-date cases. |
| Safety and data boundaries | PASS | The final Rails suite asserts one attempt after concurrent runs, exact reply-key replay, a fresh version after a move, no retroactive confirmation, durable STOP, shared and malformed-recipient holds, no cross-clinic reads/writes, aggregate-only leadership, and PostgreSQL-level read-only PMS access. `contact_safety_test.rb` passed against the repaired normalizer. |
| Performance and Rails queries | PASS | The final gate exercised both full HTTP growth probes. The identical appointment response after unrelated growth used seven statements and six returned rows. The initial and expanded reminder batches persisted correct attempt identities. Replays wrote zero rows at the same clock and used 19 statements for both one and 31 eligible visits. The plans used the clinic/day ordering and PMS clinic/time indexes. |
| Material workflow coverage | PASS | The independent review traced the source refresh and reminder run, reply and opt-out write, work assignment and follow-up, contact verification, appointment and board queries, inbox lookup and reporting. The route tests and running UI exercised the applicable fields, scope, and persisted effects. |
| Human readability | PASS | In `ReminderRun#call`, the refresh, bounded reads, evaluation and writes form the visible execution order. The cadence and send window are in `ReminderRun`. The clinic lock and source read live in `ClinicTransaction` and `ClinicRefresh`. The staff edit savepoint gives a rejected form explicit rollback behavior and keeps successful source changes visible. |
| Ease of change | PASS | On a disposable copy of the initial checkpoint, changed one production line from `SEND_HOURS = 10...18` to `11...18`. The new HTTP assertion failed before the change because a 10 AM request sent two messages. Afterward it sent zero at 10 AM and one fake SMS plus one fake email at 11 AM. The test passed with seven assertions. That production rule is identical on the repaired revision. |
| Failure and transaction behavior | PASS | The stale edit returns 409 and the following staff GET returns the new source value and version without a verification. A PostgreSQL constraint error following the staff audit insert left no audit event, kept the item open and left the visit unconfirmed. The reminder rollback check induced failure after a delivery row and found neither the attempt nor the snapshot persisted. A missing tracked source visit preserved the prior snapshot and blocked sends. |
| Verification and handoff | PASS | The Windows setup script completed from a clean checkout and empty PostgreSQL cluster. The migration-only request returned both clinic names with an empty PMS using the restricted runtime role. The final seeded runtime exposed active, assigned and resolved work. The headless Edge run passed through all three workspaces and checked layout at 390 px. The final local quality gate passed all seven checks. |

Final run of `APEX_WORKLOAD=1 python quality/run_checks.py` passed 28 Rails tests with 171 assertions and three React tests. RuboCop reported zero offenses, Brakeman reported zero warnings, and frontend lint, typecheck and production build passed.

### Final measured HTTP work

| Request and fixture | Overall SQL | Reads | Returned rows | Objects instantiated | Direct writes | Affected rows | Response bytes | Local time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Appointments, baseline | 7 | 7 | 6 | 3 | 0 | 0 | 454 | 46.1 ms |
| Appointments, 2,000 older local visits and one foreign-clinic visit | 7 | 7 | 6 | 3 | 0 | 0 | 454 | 46.5 ms |
| Reminder, first eligible visit | 25 | 17 | 11 | 8 | 4 | 4 | 78 | 132.6 ms |
| Reminder, one-visit repeat | 19 | 15 | 13 | 8 | 0 | 0 | 78 | 104.1 ms |
| Reminder, repeat with 2,000 older source rows | 19 | 15 | 13 | 8 | 0 | 0 | 78 | 93.3 ms |
| Reminder, 30 additional eligible visits | 169 | 75 | 253 | 188 | 90 | 90 | 79 | 1,083.1 ms |
| Reminder, 31-visit repeat | 19 | 15 | 313 | 188 | 0 | 0 | 78 | 281.5 ms |

The batch revalidates the active source cohort and prior delivery steps on each run. Reads grow with newly eligible work and its required records. The 30 new visits each required a patient snapshot, visit snapshot and delivery. Query counts for identically timed retries stayed flat after batching. Timings are individual local observations on PostgreSQL 17.11. See [workload method](WORKLOAD_RESULTS.md).
