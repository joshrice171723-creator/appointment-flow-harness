import { useEffect, useState } from "react";

export class ApiError extends Error {
  constructor(message: string, public readonly status: number) {
    super(message);
  }
}

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: {
      Accept: "application/json",
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...options.headers
    }
  });
  if (!response.ok) {
    const result = await response.json().catch(() => null);
    throw new ApiError(result?.error ?? "The workspace could not complete this request.", response.status);
  }
  return response.json() as Promise<T>;
}

export function useApi<T>(path: string | null, staff = "") {
  const [version, setVersion] = useState(0);
  const [resource, setResource] = useState<{ key: string; data?: T; error?: string }>();
  const key = JSON.stringify([path, staff, version]);

  useEffect(() => {
    if (!path) return;
    const controller = new AbortController();
    api<T>(path, { signal: controller.signal, headers: staffHeaders(staff) })
      .then(data => setResource({ key, data }))
      .catch((error: unknown) => {
        if (!controller.signal.aborted) setResource({ key, error: errorMessage(error) });
      });
    return () => controller.abort();
  }, [path, staff, key]);

  const current = resource?.key === key ? resource : undefined;
  return { data: current?.data, error: current?.error, loading: !!path && !current, reload: () => setVersion(value => value + 1) };
}

export function staffHeaders(staff: string): Record<string, string> {
  return staff ? { "X-Apex-Staff": staff } : {};
}

export function errorMessage(error: unknown): string {
  return error instanceof ApiError ? error.message : "The connection was interrupted. Try again to check the result.";
}

export function savedRequestId(current: { key: string; id: string } | null, payload: object) {
  const key = JSON.stringify(payload);
  return current?.key === key ? current : { key, id: crypto.randomUUID() };
}
