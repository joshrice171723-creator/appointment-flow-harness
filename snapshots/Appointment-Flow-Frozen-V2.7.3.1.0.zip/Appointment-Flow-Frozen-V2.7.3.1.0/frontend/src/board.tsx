import { useState } from "react";
import { api, errorMessage, staffHeaders, useApi } from "./api";
import { stateLabels, wallDate, workLabels } from "./domain";
import type { StaffContext, SyncStatus, WorkItem, WorkKind, WorkState } from "./domain";
import { ChoiceTabs, Feedback, PageHeading, SyncLine } from "./ui";

interface Queue {
  items: WorkItem[];
  total: number;
}

interface BoardData extends SyncStatus {
  totals: Record<WorkState, number>;
  queues: Partial<Record<WorkState, Queue>>;
}

const states = Object.keys(stateLabels) as WorkState[];
const kinds = Object.keys(workLabels) as WorkKind[];
const emptyPages = { needs_attention: 1, in_progress: 1, resolved: 1 };

export function Board({ staff }: { staff: StaffContext }) {
  const { clinic } = staff;
  const [mode, setMode] = useState<"active" | "resolved">("active");
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState("");
  const [pages, setPages] = useState(emptyPages);
  const [pageSize, setPageSize] = useState(5);
  const [running, setRunning] = useState(false);
  const [notice, setNotice] = useState<{ text: string; error?: boolean }>();
  const query = new URLSearchParams({
    mode, search, kind, per_page: String(pageSize),
    ...Object.fromEntries(states.map(state => [state, String(pages[state])]))
  });
  const board = useApi<BoardData>(`/clinics/${clinic.id}/work_items?${query}`, staff.name);

  async function runReminders() {
    setRunning(true);
    setNotice(undefined);
    try {
      const result = await api<{ sent: number; failed: number }>(`/clinics/${clinic.id}/reminder_run`, {
        method: "POST", headers: staffHeaders(staff.name)
      });
      setNotice({ text: `Reminder run complete. ${result.sent} sent, ${result.failed} failed.` });
    } catch (error) {
      setNotice({ text: errorMessage(error), error: true });
    } finally {
      setRunning(false);
      board.reload();
    }
  }

  const visibleStates: WorkState[] = mode === "active" ? ["needs_attention", "in_progress"] : ["resolved"];
  return <main>
    <PageHeading title="Patient flow" clinic={clinic} aside={<div className="cluster">
      <span className="quiet">{staff.name}</span>
      <button className="primary" onClick={runReminders} disabled={running}>{running ? "Running…" : "Run reminders"}</button>
    </div>} />
    <SyncLine clinic={clinic} status={board.data} />
    {notice && <p className={`notice ${notice.error ? "error" : ""}`} role={notice.error ? "alert" : "status"}>{notice.text}</p>}
    <div className="metric-grid">
      {states.map(state => <section className="metric" key={state}>
        <p className="quiet">{stateLabels[state]}</p>
        <strong>{board.data?.totals[state] ?? "—"}</strong>
      </section>)}
    </div>
    <div className="cluster spread section-gap">
      <ChoiceTabs label="Board view" value={mode} choices={[
        { value: "active", label: "Active work" }, { value: "resolved", label: "Resolved" }
      ]} onChange={value => { setMode(value); setPages(emptyPages); }} />
      <a className="button" href="#/appointments">All appointments →</a>
    </div>
    <div className="cluster section-gap">
      <label>Find a patient
        <input type="search" placeholder="Search by name" maxLength={80} value={search}
          onChange={event => { setSearch(event.target.value); setPages(emptyPages); }} />
      </label>
      <label>Follow-up type
        <select value={kind} onChange={event => { setKind(event.target.value); setPages(emptyPages); }}>
          <option value="">All follow-up types</option>
          {kinds.map(option => <option key={option} value={option}>{workLabels[option]}</option>)}
        </select>
      </label>
      <label>Per column
        <select value={pageSize} onChange={event => { setPageSize(Number(event.target.value)); setPages(emptyPages); }}>
          {[5, 10, 20].map(size => <option key={size}>{size}</option>)}
        </select>
      </label>
    </div>
    <div className="section-gap">
      <Feedback error={board.error} loading={board.loading} />
      {board.data && <div className="board">{visibleStates.map(state =>
        <QueueColumn key={state} state={state} queue={board.data?.queues[state]} page={pages[state]} size={pageSize}
          setPage={page => setPages(current => ({ ...current, [state]: page }))} />
      )}</div>}
    </div>
  </main>;
}

function QueueColumn({ state, queue, page, size, setPage }: {
  state: WorkState;
  queue?: Queue;
  page: number;
  size: number;
  setPage: (page: number) => void;
}) {
  const total = queue?.total ?? 0;
  const offset = (page - 1) * size;
  return <section className={`board-column stack ${state === "in_progress" ? "progress" : ""}`}>
    <div className="cluster spread"><h3>{stateLabels[state]}</h3><span className="badge">{total}</span></div>
    <div className="cluster spread small">
      <span className="quiet">{total && offset < total ? `${offset + 1}–${Math.min(offset + size, total)} of ${total}` : `${total} matching`}</span>
      <div className="cluster">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>Previous</button>
        <button disabled={offset + size >= total} onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </div>
    {queue?.items.length ? queue.items.map(item => <article className="board-card" key={item.id}>
      <div className="cluster spread">
        <span className={`badge ${item.kind}`}>{workLabels[item.kind]}</span>
        <a href={`#/patient/${item.patient_id}/${item.id}`} aria-label={`Open follow-up for ${item.patient_name}`}>Open ↗</a>
      </div>
      <h3><a href={`#/patient/${item.patient_id}/${item.id}`}>{item.patient_name}</a></h3>
      <p>{item.description}</p>
      {item.visit && <p className="small quiet">{wallDate(item.visit.wall_start, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</p>}
      <p className="work-meta quiet small">{item.assignee ?? "Unassigned"}</p>
    </article>) : <p className="quiet">No matching work items.</p>}
  </section>;
}
