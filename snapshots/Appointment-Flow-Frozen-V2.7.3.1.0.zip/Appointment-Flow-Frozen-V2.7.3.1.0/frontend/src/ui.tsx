import type { ReactNode } from "react";
import type { Clinic, StaffContext, SyncStatus } from "./domain";
import { clinicTime } from "./domain";

export function Brand({ staff, current }: { staff?: StaffContext; current?: string }) {
  return <header className="site-header">
    <a href="#/" className="brand" aria-label="Apex Appointment Flow home">
      <span className="brand-mark" aria-hidden="true">A<sup>↗</sup></span>
      <span><strong>APEX</strong><small>APPOINTMENT FLOW</small></span>
    </a>
    <nav aria-label="Workspace navigation">
      {staff && <>
        <a href="#/front-desk" aria-current={current === "front-desk" ? "page" : undefined}>Patient flow</a>
        <a href="#/appointments" aria-current={current === "appointments" ? "page" : undefined}>Appointments</a>
      </>}
      {current === "leadership" && <span className="nav-current">Apex leadership</span>}
      <a href="#/">Workspaces <span aria-hidden="true">↗</span></a>
    </nav>
  </header>;
}

export function PageHeading({ title, clinic, aside }: { title: string; clinic?: Clinic; aside?: ReactNode }) {
  return <div className="page-heading">
    <div>{clinic && <p className="eyebrow">{clinic.name}</p>}<h1>{title}</h1></div>
    {aside}
  </div>;
}

export function SyncLine({ clinic, status }: { clinic: Clinic; status?: SyncStatus }) {
  return <>
    <p className="quiet sync-line">{status?.synced_at ? `Last PMS sync: ${clinicTime(status.synced_at, clinic.timezone)}` : "PMS sync pending"} · {clinic.timezone}</p>
    {status?.sync_error && <p role="alert" className="notice error">{status.sync_error} The workspace shows the last successful sync.</p>}
  </>;
}

export function Feedback({ error, loading }: { error?: string; loading?: boolean }) {
  if (error) return <p className="notice error" role="alert">{error}</p>;
  if (loading) return <p className="quiet" role="status">Loading…</p>;
  return null;
}

export function ChoiceTabs<T extends string>({ choices, value, onChange, label }: {
  choices: { value: T; label: string; count?: number }[];
  value: T;
  onChange: (value: T) => void;
  label: string;
}) {
  return <div className="tabs" role="group" aria-label={label}>{choices.map(choice =>
    <button key={choice.value} onClick={() => onChange(choice.value)} aria-pressed={value === choice.value}>
      {choice.label}{choice.count !== undefined && <span className="tab-count">{choice.count}</span>}
    </button>
  )}</div>;
}
