import { useState } from "react";
import { api, errorMessage, staffHeaders, useApi } from "./api";
import { calendarDate, visitOutcome, wallDate, weekStart } from "./domain";
import type { StaffContext, SyncStatus, Visit } from "./domain";
import { ChoiceTabs, Feedback, PageHeading, SyncLine } from "./ui";

type VisitFilter = "all" | "confirmed" | "unconfirmed" | "review";
interface DayData extends SyncStatus {
  visits: Visit[];
  totals: Record<VisitFilter, number>;
  week: Record<string, number>;
  total: number;
}

const filters: { value: VisitFilter; label: string }[] = [
  { value: "all", label: "All appointments" },
  { value: "confirmed", label: "Confirmed" },
  { value: "unconfirmed", label: "Unconfirmed" },
  { value: "review", label: "Replies to review" }
];

export function Appointments({ staff }: { staff: StaffContext }) {
  const { clinic } = staff;
  const [day, setDay] = useState(clinic.today);
  const [filter, setFilter] = useState<VisitFilter>("all");
  const [page, setPage] = useState(1);
  const [refreshing, setRefreshing] = useState(false);
  const [syncError, setSyncError] = useState<string>();
  const date = new URLSearchParams({ date: day, filter, page: String(page) });
  const appointments = useApi<DayData>(`/clinics/${clinic.id}/visits?${date}`, staff.name);
  const first = weekStart(day);

  function changeDay(value: string) {
    if (value) { setDay(value); setPage(1); }
  }

  async function refresh() {
    setRefreshing(true);
    setSyncError(undefined);
    try {
      await api(`/clinics/${clinic.id}/source_refresh`, { method: "POST", headers: staffHeaders(staff.name) });
    } catch (error) {
      setSyncError(errorMessage(error));
    } finally {
      setRefreshing(false);
      appointments.reload();
    }
  }

  return <main>
    <PageHeading title="Appointments" clinic={clinic} aside={<div className="cluster">
      <button onClick={refresh} disabled={refreshing}>{refreshing ? "Syncing…" : "Sync appointments"}</button>
      <a className="button" href="#/front-desk">Open patient flow →</a>
    </div>} />
    <SyncLine clinic={clinic} status={appointments.data} />
    <Feedback error={syncError} />
    <section className="card stack" aria-label="Appointment calendar">
      <div className="cluster">
        <button onClick={() => changeDay(calendarDate(day, -7))}>← Previous week</button>
        <button onClick={() => changeDay(clinic.today)}>Today</button>
        <button onClick={() => changeDay(calendarDate(day, 7))}>Next week →</button>
      </div>
      <label>Jump to date<input type="date" value={day} onChange={event => changeDay(event.target.value)} /></label>
      <div className="week">{Array.from({ length: 7 }, (_, index) => {
        const date = calendarDate(first, index);
        const count = appointments.data?.week[date] ?? 0;
        return <button key={date} aria-pressed={date === day} onClick={() => changeDay(date)}>
          {wallDate(date, { weekday: "short", month: "short", day: "numeric" })}
          <small className="quiet">{count} {count === 1 ? "visit" : "visits"}</small>
        </button>;
      })}</div>
    </section>
    <div className="section-gap">
      <ChoiceTabs label="Appointment state" value={filter}
        choices={filters.map(option => ({ ...option, count: appointments.data?.totals[option.value] }))}
        onChange={value => { setFilter(value); setPage(1); }} />
    </div>
    <section className="card section-gap">
      <Feedback error={appointments.error} loading={appointments.loading} />
      {appointments.data && <VisitTable visits={appointments.data.visits} timezone={clinic.timezone} />}
      {(appointments.data?.total ?? 0) > 25 && <div className="cluster section-gap">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>Previous page</button>
        <span>Page {page}</span>
        <button disabled={page * 25 >= (appointments.data?.total ?? 0)} onClick={() => setPage(page + 1)}>Next page</button>
      </div>}
    </section>
  </main>;
}

export function VisitTable({ visits, timezone }: { visits: Visit[]; timezone: string }) {
  if (!visits.length) return <p className="quiet">No appointments match this view.</p>;

  return <div className="table-scroll"><table>
    <thead><tr><th>Patient</th><th>Appointment · {timezone}</th><th>Confirmation</th><th>PMS outcome</th><th>Next step</th></tr></thead>
    <tbody>{visits.map(visit => <tr key={visit.id}>
      <td><strong>{visit.patient_name}</strong><small className="quiet">Appointment #{visit.source_id}</small></td>
      <td>{wallDate(visit.wall_start, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
        <small className="quiet">{[visit.provider, visit.minutes ? `${visit.minutes} min` : null].filter(Boolean).join(" · ")}</small>
      </td>
      <td><span className={`badge ${visit.confirmation}`}>{visit.confirmation === "confirmed" ? "Confirmed" : "Unconfirmed"}</span>
        {visit.reply_review && <small>Reply needs review</small>}
        {visit.staff_disposition && <small>Staff recorded {visit.staff_disposition}</small>}
      </td>
      <td>{visitOutcome(visit.source_status)}</td>
      <td><a href={`#/patient/${visit.patient_id}`}>Patient details</a></td>
    </tr>)}</tbody>
  </table></div>;
}
