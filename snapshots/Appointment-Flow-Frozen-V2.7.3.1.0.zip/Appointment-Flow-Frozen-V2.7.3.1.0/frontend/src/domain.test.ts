import assert from "node:assert/strict";
import { test } from "node:test";
import { calendarDate, visitOutcome, wallDate, weekStart } from "./domain";

test("calendar navigation preserves a clinic-provided date through month and DST boundaries", () => {
  assert.equal(weekStart("2026-11-01"), "2026-10-26");
  assert.equal(calendarDate("2026-11-01", 1), "2026-11-02");
  assert.equal(calendarDate("2026-12-31", 1), "2027-01-01");
});

test("source wall time is displayed as entered independently of the browser timezone", () => {
  assert.equal(wallDate("2026-11-16T15:00:00", { hour: "numeric", minute: "2-digit" }), "3:00 PM");
});

test("only the source complete status displays a completed appointment", () => {
  assert.equal(visitOutcome("complete"), "Completed");
  assert.equal(visitOutcome("scheduled"), "Unknown");
  assert.equal(visitOutcome("unscheduled"), "Unknown");
  assert.equal(visitOutcome("broken"), "Canceled");
});
