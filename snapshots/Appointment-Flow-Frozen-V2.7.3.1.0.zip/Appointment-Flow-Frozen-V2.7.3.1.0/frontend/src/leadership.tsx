import { useState } from "react";
import { useApi } from "./api";
import { wallDate } from "./domain";
import { Feedback, PageHeading } from "./ui";

interface ClinicTotals {
  id: number;
  name: string;
  recorded: number;
  completed: number;
  canceled: number;
  unknown: number;
  sent: number;
  failed: number;
  confirmed_replies: number;
  review_replies: number;
  open_holds: number;
  resolved_holds: number;
  work_total: number;
  follow_ups: number;
}
interface MonthReport { month: string; clinics: ClinicTotals[] }
interface Report extends MonthReport { history: MonthReport[] }

const categories = [
  { value: "completed", label: "Completed", color: "#2c6758" },
  { value: "canceled", label: "Canceled", color: "#995343" },
  { value: "unknown", label: "Unknown outcome", color: "#78857d" }
] as const;

function rate(part: number, total: number) { return total ? `${(part * 100 / total).toFixed(1)}%` : "—"; }
function monthName(month: string) { return wallDate(`${month}-01`, { month: "long", year: "numeric" }); }

export function Leadership() {
  const [month, setMonth] = useState("");
  const report = useApi<Report>(`/leadership${month ? `?month=${encodeURIComponent(month)}` : ""}`);
  const data = report.data;
  return <main>
    <PageHeading title="Appointment outcomes" aside={<label>Outcome month
      <input type="month" value={month || data?.month || ""} onChange={event => setMonth(event.target.value)} />
    </label>} />
    <Feedback error={report.error} loading={report.loading} />
    {data && <div className="stack">
      <section className="card stack">
        <h2>{monthName(data.month)}</h2>
        <div className="summary">{data.clinics.map(clinic => <section className="stack" key={clinic.id}>
          <div className="cluster spread"><h3>{clinic.name}</h3><span className="quiet">{clinic.recorded} recorded visits</span></div>
          <div className="outcome-bar" aria-hidden="true">{categories.map(category => <span key={category.value}
            style={{ flexGrow: clinic[category.value], backgroundColor: category.color }} />)}</div>
          <div className="outcome-grid">{categories.map(category => <div key={category.value}>
            <span className="outcome-key" style={{ backgroundColor: category.color }} />{category.label}
            <p><strong>{clinic[category.value]}</strong> <small className="quiet">{rate(clinic[category.value], clinic.recorded)}</small></p>
          </div>)}</div>
        </section>)}</div>
      </section>
      <section className="card stack">
        <h2>Clinic comparison</h2>
        <details><summary>How rates are calculated</summary>
          <p>Completion rate is completed visits divided by all PMS visits whose scheduled time has passed. A broken visit counts as canceled. The PMS provides no separate reschedule or no-show outcome and cannot establish the effect of reminders.</p>
        </details>
        <div className="table-scroll"><table>
          <thead><tr><th>Clinic</th><th>Completion rate</th><th>Recorded visits</th><th>Rescheduled</th><th>Canceled</th><th>Unknown</th></tr></thead>
          <tbody>{data.clinics.map(clinic => <tr key={clinic.id}>
            <td><strong>{clinic.name}</strong></td><td>{rate(clinic.completed, clinic.recorded)}<small>{clinic.completed} completed</small></td>
            <td>{clinic.recorded}</td><td title="Unavailable from the PMS">—</td><td>{clinic.canceled}</td><td>{clinic.unknown}</td>
          </tr>)}</tbody>
        </table></div>
      </section>
      <details className="report"><summary>Monthly history and reminder activity</summary>
        <p className="quiet">Activity counts use the UTC month of the message or reply.</p>
        <div className="table-scroll"><table>
          <thead><tr><th>Month</th><th>Clinic</th><th>Completed / recorded</th><th>Fake sends</th><th>Failed sends</th><th>Confirming replies</th></tr></thead>
          <tbody>{data.history.flatMap(report => report.clinics.map(clinic => <tr key={`${report.month}:${clinic.id}`}>
            <td>{monthName(report.month)}</td><td>{clinic.name}</td><td>{clinic.completed} / {clinic.recorded}</td>
            <td>{clinic.sent}</td><td>{clinic.failed}</td><td>{clinic.confirmed_replies}</td>
          </tr>))}</tbody>
        </table></div>
      </details>
      <details className="report"><summary>Contact holds</summary>
        <p className="quiet">Current status of holds created in the selected UTC month.</p>
        <div className="table-scroll"><table>
          <thead><tr><th>Clinic</th><th>Open holds</th><th>Resolved holds</th></tr></thead>
          <tbody>{data.clinics.map(clinic => <tr key={clinic.id}><td>{clinic.name}</td><td>{clinic.open_holds}</td><td>{clinic.resolved_holds}</td></tr>)}</tbody>
        </table></div>
      </details>
      <details className="report"><summary>Contact and follow-up</summary>
        <p className="quiet">Counts are grouped by when the event or work item was recorded, in UTC.</p>
        <div className="table-scroll"><table>
          <thead><tr><th>Clinic</th><th>Replies sent to review</th><th>Work items created</th><th>Staff follow-ups</th></tr></thead>
          <tbody>{data.clinics.map(clinic => <tr key={clinic.id}><td>{clinic.name}</td><td>{clinic.review_replies}</td>
            <td>{clinic.work_total}</td><td>{clinic.follow_ups}</td></tr>)}</tbody>
        </table></div>
      </details>
    </div>}
  </main>;
}
