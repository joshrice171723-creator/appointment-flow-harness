import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { useApi } from "./api";
import type { Clinic, StaffContext } from "./domain";
import { Appointments } from "./appointments";
import { Board } from "./board";
import { PatientDetail } from "./patient-detail";
import { Inbox } from "./inbox";
import { Leadership } from "./leadership";
import { Brand, Feedback, PageHeading } from "./ui";
import "./styles.css";

function App() {
  const [path, setPath] = useState(() => window.location.hash.slice(1) || "/");
  const [staff, setStaff] = useState<StaffContext>();
  const clinics = useApi<Clinic[]>("/clinics");

  useEffect(() => {
    function onHashChange() {
      setPath(window.location.hash.slice(1) || "/");
      window.scrollTo(0, 0);
    }
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  if (path === "/patient-inbox") return <Inbox clinics={clinics.data ?? []} error={clinics.error} loading={clinics.loading} />;
  if (path === "/leadership") return <><Brand current="leadership" /><Leadership /></>;

  const patientRoute = path.match(/^\/patient\/(\d+)(?:\/(\d+))?$/);
  if (staff && (["/front-desk", "/appointments"].includes(path) || patientRoute)) {
    return <>
      <Brand staff={staff} current={path.slice(1)} />
      {path === "/front-desk" && <Board key={staff.clinic.id} staff={staff} />}
      {path === "/appointments" && <Appointments key={staff.clinic.id} staff={staff} />}
      {patientRoute && <PatientDetail key={`${staff.clinic.id}:${patientRoute[1]}:${patientRoute[2]}`}
        staff={staff} patientId={Number(patientRoute[1])} workId={patientRoute[2] ? Number(patientRoute[2]) : undefined} />}
    </>;
  }

  return <>
    <Brand />
    <main className="launch">
      <PageHeading title="Workspaces" />
      <Feedback error={clinics.error} loading={clinics.loading} />
      {path !== "/" && <p className="notice">Select a clinic and staff member to open the front desk.</p>}
      <Workspaces clinics={clinics.data ?? []} previous={staff} onStaff={setStaff} />
    </main>
  </>;
}

function Workspaces({ clinics, previous, onStaff }: {
  clinics: Clinic[];
  previous?: StaffContext;
  onStaff: (staff: StaffContext) => void;
}) {
  const [clinicId, setClinicId] = useState(previous?.clinic.id);
  const [staffName, setStaffName] = useState(previous?.name);
  const clinic = clinics.find(entry => entry.id === clinicId) ?? clinics[0];
  const name = clinic?.staff.find(member => member === staffName) ?? clinic?.staff[0] ?? "";
  return <div className="workspace-grid">
    <section className="card">
      <h2>Front desk</h2>
      <p className="quiet">Review appointments and follow up with patients.</p>
      <form className="stack" onSubmit={event => {
        event.preventDefault();
        if (clinic && name) {
          onStaff({ clinic, name });
          window.location.hash = "/front-desk";
        }
      }}>
        <label>Clinic
          <select value={clinic?.id ?? ""} disabled={!clinic} onChange={event => {
            setClinicId(Number(event.target.value));
            setStaffName(undefined);
          }}>
            {clinics.map(entry => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
          </select>
        </label>
        <label><span>Staff member <small className="quiet">· Demo sign-in</small></span>
          <select value={name} disabled={!clinic} onChange={event => setStaffName(event.target.value)}>
            {clinic?.staff.map(member => <option key={member}>{member}</option>)}
          </select>
        </label>
        <button className="button primary" disabled={!clinic || !name}>Open front desk <span aria-hidden="true">→</span></button>
      </form>
    </section>
    <section className="card">
      <h2>Apex leadership</h2>
      <p className="quiet">Review appointment outcomes by clinic.</p>
      <div className="clinic-count"><strong>{clinics.length}</strong><span className="quiet small">{clinics.length === 1 ? "clinic" : "clinics"}</span></div>
      <a className="button primary" href="#/leadership">Open Apex leadership <span aria-hidden="true">→</span></a>
    </section>
    <section className="card">
      <h2>Patient</h2>
      <p className="quiet">Read and reply to simulated texts and emails.</p>
      <a className="button primary" href="#/patient-inbox">Open patient workspace <span aria-hidden="true">→</span></a>
    </section>
  </div>;
}

createRoot(document.getElementById("root")!).render(<App />);
