import { useRef, useState } from "react";
import type { FormEvent } from "react";
import { api, errorMessage, savedRequestId, staffHeaders, useApi } from "./api";
import { VisitTable } from "./appointments";
import { clinicTime, contactLabels, stateLabels, wallDate, workLabels } from "./domain";
import type { ContactField, StaffContext, SyncStatus, Visit, WorkItem } from "./domain";
import { ChoiceTabs, Feedback, PageHeading, SyncLine } from "./ui";

interface Contact {
  value: string | null;
  source: string | null;
  verification: { staff: string; at: string } | null;
  conflict: boolean;
  version: string;
}

interface Activity {
  id: number;
  staff: string;
  outcome: string;
  note: string;
  created_at: string;
  details: { field?: ContactField; previous?: string | null; value?: string | null };
}

interface PatientData extends SyncStatus {
  id: number;
  name: string;
  contact: Record<ContactField, Contact>;
  next_visit: Visit | null;
  visits: Visit[];
  work: WorkItem[];
  activity: Activity[];
}

const contactFields = Object.keys(contactLabels) as ContactField[];
const visitTime = { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" } as const;

export function PatientDetail({ staff, patientId, workId }: { staff: StaffContext; patientId: number; workId?: number }) {
  const endpoint = `/clinics/${staff.clinic.id}/clinic_patients/${patientId}`;
  const patient = useApi<PatientData>(endpoint + (workId ? `?work=${workId}` : ""), staff.name);
  const [tab, setTab] = useState<"work" | "visits" | "activity">("work");
  const [notice, setNotice] = useState<string>();
  const data = patient.data;
  if (!data) return <main><a href="#/front-desk">← Patient flow</a><Feedback error={patient.error} loading={patient.loading} /></main>;

  const open = data.work.filter(item => item.state !== "resolved");
  const closed = data.work.filter(item => item.state === "resolved");
  function saved(message: string) { setNotice(message); patient.reload(); }

  return <main>
    <a href="#/front-desk" className="small">← Patient flow</a>
    <div className="section-gap"><PageHeading title={data.name} clinic={staff.clinic} /></div>
    <SyncLine clinic={staff.clinic} status={data} />
    {notice && <p className="notice" role="status">{notice}</p>}
    <section className="card">
      <h3>Next scheduled appointment</h3>
      {data.next_visit ? <p>{wallDate(data.next_visit.wall_start, visitTime)} · Appointment #{data.next_visit.source_id}</p>
        : <p className="quiet">No upcoming appointment recorded.</p>}
    </section>
    <div className="detail-grid section-gap">
      <aside className="card stack">
        <h2>Patient details</h2>
        {contactFields.map(field => <ContactRow key={field} field={field} contact={data.contact[field]} staff={staff}
          endpoint={`${endpoint}/contact_verification`} saved={saved} />)}
      </aside>
      <div className="stack">
        <ChoiceTabs label="Patient details sections" value={tab} onChange={setTab} choices={[
          { value: "work", label: "Follow-up", count: open.length },
          { value: "visits", label: "Appointments" },
          { value: "activity", label: "Activity log" }
        ]} />
        <section className="card stack">
          {tab === "work" && <>
            <h2>Follow-up items</h2>
            {!open.length && <p className="quiet">No open follow-up items.</p>}
            {open.map(item => <WorkDetail key={item.id} item={item} staff={staff} saved={saved} />)}
            <details open={closed.some(item => item.id === workId) || undefined}>
              <summary>Resolved follow-up records ({closed.length})</summary>
              {closed.length ? closed.map(item => <WorkDetail key={item.id} item={item} staff={staff} saved={saved} />)
                : <p className="quiet">No resolved records.</p>}
            </details>
          </>}
          {tab === "visits" && <VisitTable visits={data.visits} timezone={staff.clinic.timezone} />}
          {tab === "activity" && <>
            <h2>Activity log</h2>
            {!data.activity.length && <p className="quiet">No staff actions recorded.</p>}
            {data.activity.map(entry => <article key={entry.id} className="work-detail">
              <strong>{entry.staff} · {entry.outcome.replaceAll("_", " ")}</strong>
              <p className="quiet small">{clinicTime(entry.created_at, staff.clinic.timezone)}</p>
              <p>{entry.note}</p>
              {entry.details.field && <p>{entry.details.previous ?? "No previous value"} → {entry.details.value ?? "No value"}</p>}
            </article>)}
          </>}
        </section>
      </div>
    </div>
  </main>;
}

function ContactRow({ field, contact, staff, endpoint, saved }: {
  field: ContactField; contact: Contact; staff: StaffContext; endpoint: string; saved: (message: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(contact.value ?? "");
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const request = useRef<{ key: string; id: string } | null>(null);
  const label = contactLabels[field];

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(undefined);
    const payload = { field, value, contact_version: contact.version };
    request.current = savedRequestId(request.current, payload);
    try {
      await api(endpoint, { method: "POST", headers: staffHeaders(staff.name),
        body: JSON.stringify({ ...payload, request_id: request.current.id }) });
      setEditing(false);
      saved(`${label} verified.`);
    } catch (error) {
      setError(errorMessage(error));
    } finally {
      setBusy(false);
    }
  }

  return <div className="contact-row">
    <span className="quiet small">{label}</span>
    <strong>{contact.value || "No value on file"}</strong>
    <div className="cluster spread">
      <span className="badge">{contact.verification ? "Verified locally" : "Not verified"}</span>
      <button type="button" onClick={() => { setEditing(!editing); setError(undefined); }} aria-label={editing ? `Close ${label} editor` : `Verify ${label}`}>
        {editing ? "Close" : "Verify"}
      </button>
    </div>
    {contact.verification && <p className="small quiet">Verified by {contact.verification.staff}</p>}
    {contact.conflict && <p className="notice">PMS value changed to {contact.source ?? "no value"}. Verify before sending reminders.</p>}
    {editing && <form className="stack" onSubmit={submit}>
      <label>{label}
        {field === "preferred_language"
          ? <select required value={value} onChange={event => setValue(event.target.value)}>
            <option value="">Choose a language</option><option value="en">English</option><option value="es">Spanish</option>
          </select>
          : <input type={{ birthdate: "date", wireless_phone: "tel", email: "email" }[field]}
            value={value} onChange={event => setValue(event.target.value)} maxLength={250} />}
      </label>
      <Feedback error={error} />
      <button className="primary" disabled={busy}>{busy ? "Saving…" : "Save verification"}</button>
    </form>}
  </div>;
}

function WorkDetail({ item, staff, saved }: { item: WorkItem; staff: StaffContext; saved: (message: string) => void }) {
  const [outcome, setOutcome] = useState("attempted");
  const [note, setNote] = useState("");
  const [visits, setVisits] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const request = useRef<{ key: string; id: string } | null>(null);
  const endpoint = `/clinics/${staff.clinic.id}/work_items/${item.id}`;
  const mine = item.assignee === staff.name && item.state === "in_progress";

  async function assign() {
    setBusy(true);
    setError(undefined);
    try {
      await api(`${endpoint}/work_assignment`, { method: "PATCH", headers: staffHeaders(staff.name) });
      saved("Follow-up assigned to you.");
    } catch (error) {
      setError(errorMessage(error));
    } finally {
      setBusy(false);
    }
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(undefined);
    const payload = { outcome, note, visit_ids: outcome === "attempted" ? [] : visits };
    request.current = savedRequestId(request.current, payload);
    try {
      await api(`${endpoint}/follow_ups`, { method: "POST", headers: staffHeaders(staff.name),
        body: JSON.stringify({ ...payload, request_id: request.current.id }) });
      setNote("");
      saved("Follow-up recorded.");
    } catch (error) {
      setError(errorMessage(error));
    } finally {
      setBusy(false);
    }
  }

  const canChooseVisit = !!item.visit || item.candidates.length > 0;
  const needsSelection = !["attempted", "clarified"].includes(outcome) && (item.candidates.length > 1 || !item.visit);
  return <article className="work-detail">
    <div className="cluster spread">
      <span className={`badge ${item.kind}`}>{workLabels[item.kind]}</span>
      <small className="quiet">{stateLabels[item.state]} · {item.assignee ?? "Unassigned"}</small>
    </div>
    <p>{item.description}</p>
    {item.visit && <p className="quiet small">Appointment #{item.visit.source_id} · {wallDate(item.visit.wall_start, visitTime)}</p>}
    {item.reply_body && <blockquote>{item.reply_body}</blockquote>}
    {item.state === "needs_attention" && <button className="section-gap" type="button" onClick={assign} disabled={busy}>Assign to me</button>}
    {mine && <form className="stack" onSubmit={submit}>
      <label>Follow-up outcome
        <select value={outcome} onChange={event => setOutcome(event.target.value)}>
          <option value="attempted">Contact attempted</option>
          {canChooseVisit && <>
            <option value="confirmed">Confirmed</option>
            <option value="rescheduled">Rescheduled</option>
            <option value="canceled">Canceled</option>
          </>}
          {item.kind === "reply_review" && <option value="clarified">Reply clarified</option>}
        </select>
      </label>
      {outcome !== "attempted" && item.candidates.length > 0 && <fieldset>
        <legend>Appointments discussed</legend>
        {item.candidates.map(candidate => <label className="form-check" key={candidate.id}>
          <input type="checkbox" checked={visits.includes(candidate.id)} onChange={event =>
            setVisits(current => event.target.checked ? [...current, candidate.id] : current.filter(id => id !== candidate.id))} />
          {candidate.label}
        </label>)}
      </fieldset>}
      <label>Follow-up note<textarea rows={3} required maxLength={1000} value={note} onChange={event => setNote(event.target.value)} /></label>
      <button className="primary" disabled={busy || (needsSelection && visits.length === 0)}>{busy ? "Saving…" : "Record follow-up"}</button>
    </form>}
    <Feedback error={error} />
  </article>;
}
