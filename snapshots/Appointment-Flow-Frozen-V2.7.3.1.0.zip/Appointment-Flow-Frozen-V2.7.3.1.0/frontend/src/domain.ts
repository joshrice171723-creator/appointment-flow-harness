export type Channel = "sms" | "email";
export type WorkState = "needs_attention" | "in_progress" | "resolved";
export type WorkKind = "no_confirmation" | "contact_hold" | "delivery_failed" | "reply_review";
export type ContactField = "birthdate" | "wireless_phone" | "email" | "preferred_language";

export interface Clinic {
  id: number;
  name: string;
  timezone: string;
  staff: string[];
  today: string;
}

export interface StaffContext {
  clinic: Clinic;
  name: string;
}

export interface SyncStatus {
  synced_at: string | null;
  sync_error: string | null;
}

export interface Visit {
  id: number;
  source_id: number;
  patient_id: number;
  patient_name: string;
  wall_start: string;
  local_day: string;
  provider: string | null;
  minutes: number | null;
  confirmation: "confirmed" | "unconfirmed";
  reply_review: boolean;
  source_status: string;
  staff_disposition: string | null;
  revision: number;
}

export interface WorkItem {
  id: number;
  patient_id: number;
  patient_name: string;
  kind: WorkKind;
  state: WorkState;
  description: string;
  assignee: string | null;
  visit: { id: number; wall_start: string; source_id: number } | null;
  reply_body: string | null;
  candidates: { id: number; revision: number; label: string }[];
}

export const workLabels: Record<WorkKind, string> = {
  no_confirmation: "Confirmation needed",
  contact_hold: "Reminders blocked",
  delivery_failed: "Delivery failed",
  reply_review: "Reply needs review"
};

export const stateLabels: Record<WorkState, string> = {
  needs_attention: "Needs attention",
  in_progress: "In progress",
  resolved: "Resolved"
};

export const contactLabels: Record<ContactField, string> = {
  birthdate: "Birthdate",
  wireless_phone: "Mobile phone",
  email: "Email",
  preferred_language: "Preferred language"
};

export function calendarDate(date: string, days: number): string {
  const value = new Date(`${date}T12:00:00Z`);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

export function weekStart(date: string): string {
  const day = new Date(`${date}T12:00:00Z`).getUTCDay();
  return calendarDate(date, -((day + 6) % 7));
}

export function wallDate(value: string, options: Intl.DateTimeFormatOptions): string {
  return new Intl.DateTimeFormat("en-US", { ...options, timeZone: "UTC" }).format(
    new Date(value.length === 10 ? `${value}T12:00:00Z` : `${value}Z`)
  );
}

export function clinicTime(value: string, timeZone: string): string {
  return new Intl.DateTimeFormat("en-US", { dateStyle: "medium", timeStyle: "short", timeZone }).format(new Date(value));
}

export function visitOutcome(status: string): string {
  return ({ complete: "Completed", broken: "Canceled" } as Record<string, string>)[status] ?? "Unknown";
}
