import { useRef, useState } from "react";
import type { FormEvent } from "react";
import { api, errorMessage, savedRequestId, useApi } from "./api";
import { clinicTime } from "./domain";
import type { Channel, Clinic } from "./domain";
import { ChoiceTabs, Feedback, PageHeading } from "./ui";

interface ConversationData {
  latest_delivery_id: number | null;
  messages: { id: number; direction: "clinic" | "patient"; body: string; created_at: string }[];
}

export function Inbox({ clinics, loading, error }: { clinics: Clinic[]; loading: boolean; error?: string }) {
  const [clinicId, setClinicId] = useState("");
  const [patientId, setPatientId] = useState("");
  const [channel, setChannel] = useState<Channel>("sms");
  const clinic = clinics.find(entry => entry.id === Number(clinicId));
  const patients = useApi<{ id: number; name: string }[]>(clinic ? `/clinics/${clinic.id}/inbox_patients` : null);
  const patient = patients.data?.find(entry => entry.id === Number(patientId));

  return <main className="inbox">
    <a href="#/" className="back small">← Workspaces</a>
    <PageHeading title="Patient inbox" />
    <Feedback error={error} loading={loading} />
    <div className="stack">
      <label>Clinic
        <select value={clinicId} onChange={event => {
          setClinicId(event.target.value); setPatientId(""); setChannel("sms");
        }}>
          <option value="">Choose a clinic</option>
          {clinics.map(entry => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
        </select>
      </label>
      <Feedback error={patients.error} loading={patients.loading} />
      {patients.data && <label>Patient
        <select value={patientId} onChange={event => { setPatientId(event.target.value); setChannel("sms"); }}>
          <option value="">Choose a patient</option>
          {patients.data.map(entry => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
        </select>
      </label>}
      {patients.data?.length === 0 && <p className="quiet">No demo patients have been synced for this clinic.</p>}
      {clinic && patient && <>
        <ChoiceTabs label="Message channel" value={channel} onChange={setChannel}
          choices={[{ value: "sms", label: "Text messages" }, { value: "email", label: "Email" }]} />
        <Conversation key={`${clinic.id}:${patient.id}:${channel}`} clinic={clinic} patientId={patient.id} channel={channel} />
      </>}
    </div>
  </main>;
}

function Conversation({ clinic, patientId, channel }: { clinic: Clinic; patientId: number; channel: Channel }) {
  const path = `/clinics/${clinic.id}/clinic_patients/${patientId}`;
  const history = useApi<ConversationData>(`${path}/conversation?channel=${channel}`);
  const [body, setBody] = useState("");
  const [notice, setNotice] = useState<string>();
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const request = useRef<{ key: string; id: string } | null>(null);
  const deliveryId = history.data?.latest_delivery_id;
  async function reply(event: FormEvent) {
    event.preventDefault();
    if (!deliveryId) return;
    setBusy(true);
    setError(undefined);
    setNotice(undefined);
    const payload = { body, channel, delivery_id: deliveryId };
    request.current = savedRequestId(request.current, payload);
    try {
      const result = await api<{ result: string }>(`${path}/replies`, {
        method: "POST", body: JSON.stringify({ ...payload, event_id: request.current.id })
      });
      setNotice(result.result === "confirmed" ? "Reply recorded. Appointment confirmed." :
        result.result === "opted_out" ? "Reply recorded. Text reminders stopped." : "Reply recorded for front-desk review.");
      setBody("");
      request.current = null;
      history.reload();
    } catch (error) {
      setError(errorMessage(error));
    } finally {
      setBusy(false);
    }
  }

  return <>
    <Feedback error={history.error} loading={history.loading} />
    {notice && <p className="notice" role="status">{notice}</p>}
    {history.data && (history.data.messages.length ? <>
      <h2>Message history</h2>
      {history.data.messages.map(message => <article key={`${message.direction}:${message.id}`}
        className={`bubble ${message.direction === "patient" ? "outgoing" : ""}`}>
        <strong className="small quiet">{message.direction === "clinic" ? "Clinic reminder" : "Your reply"} · {clinicTime(message.created_at, clinic.timezone)}</strong>
        <p>{message.body}</p>
      </article>)}
    </> : <p className="quiet">No simulated {channel === "email" ? "emails" : "text messages"} for this patient yet.</p>)}
    {deliveryId && <form className="card stack" onSubmit={reply}>
      <label>Your reply<textarea value={body} rows={4} maxLength={1000} required onChange={event => setBody(event.target.value)} /></label>
      <Feedback error={error} />
      <div><button className="primary" disabled={busy || !body.trim()}>{busy ? "Sending…" : "Send reply"}</button></div>
    </form>}
  </>;
}
