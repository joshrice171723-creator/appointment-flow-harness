# Tradeoff notes for candidate's own DECISIONS.md

The assessment requires that the candidate write `DECISIONS.md` **personally in their own words**. Capture factual choices and alternatives here so the candidate can make their own narrative later. Agent must not claim authorship on their behalf.

- Assumption / ambiguity:
- What was chosen and why:
- Alternative considered and drawback:
- Risk / what would change with another week:
- Evidence (test/demo/measurement):

## Observed implementation choices

- The local demo runs one Rails server with the built React app and a PostgreSQL cluster on loopback. The same server hosts the API and static assets. Database roles isolate the fake PMS read connection and runtime writes.
- Staff explicitly trigger the batch. A scheduler can call the same entry point. Decide how you would operationalize cadence and retries if the fake transport became a real provider.
- Same-ID reschedules advance a locally observed version. Source reader failures prevent sends, keep the last good view, and surface sync health. State changes between two replica observations are subject to the source replication contract.
- The initial SMS, backup email and later steps use conservative fallback, unique recipients and one configured local window. Missing age/guardian permission and ambiguous clock times hold outreach for staff. Channel permission for these fictional adults comes from the demo fixture assumptions.
- A message and its local work can commit atomically because fake delivery is a database record. A real provider has a separate commit boundary and requires a durable dispatch and reconciliation strategy.
- Leadership uses source completion outcomes and current local work counts. Separate reschedule and no-show counts cannot be derived from the provided statuses. Come prepared to explain what upstream outcome or longitudinal data would be needed.
