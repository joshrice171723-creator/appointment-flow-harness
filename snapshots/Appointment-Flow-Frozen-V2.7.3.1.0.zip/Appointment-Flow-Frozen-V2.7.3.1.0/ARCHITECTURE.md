# Architecture

```mermaid
flowchart LR
    Staff[React front desk] --> Rails[Rails HTTP API]
    Patient[React patient demo] --> Rails
    Lead[React leadership] --> Reports[Aggregate endpoints]
    Rails --> Clinic[Clinic row lock and workflow transaction]
    Clinic --> Source[PMS snapshot reader]
    Source --> PMS[(PostgreSQL PMS tables)]
    Clinic --> App[(Local visits, replies and follow-up)]
    Clinic --> Fake[Fake SMS and email adapter]
    Fake --> App
    Reports --> PMS
    Reports --> App
```

The PMS uses the assessment's clinic, patient and appointment tables. The runtime connects as `apex_reader` for those tables and `apex_app` for local writes. Migration and seed commands use `apex_admin` for the supplied fake replica. A clinic has one local row that serializes writes from sync, reminder runs, replies and staff follow-up. The source read runs at repeatable-read isolation using its own connection. PostgreSQL write permissions enforce the source boundary even for bulk model operations.

Refresh preserves raw source contact facts and projects clinic-local comparisons. Appointment wall timestamps preserve the date and time entered at the clinic. The named timezone resolves them to UTC only when there is one possible instant. For a known source outage or incomplete snapshot, the transaction saves the failure indicator and keeps the previous snapshot. When a successful source read is followed by a fake transport or local persistence exception, the application transaction rolls back the snapshot and any local business writes.

```mermaid
stateDiagram-v2
    [*] --> Unconfirmed
    Unconfirmed --> Unconfirmed: reminder or follow-up attempt
    Unconfirmed --> Confirmed: safe YES or verified staff follow-up
    Unconfirmed --> Unconfirmed: ambiguous reply adds staff work
    Confirmed --> Confirmed: later NO adds staff work
    Confirmed --> Unconfirmed: changed PMS version
    Unconfirmed --> Unconfirmed: changed PMS version
    Unconfirmed --> Suppressed: staff recorded cancellation or reschedule
    Confirmed --> Suppressed: staff recorded cancellation or reschedule
    Suppressed --> Unconfirmed: changed PMS version
```

A reminder is eligible only while the current source visit remains scheduled and unstarted. Deliveries keep the visit version, channel, step and normalized recipient. A unique index protects each logical channel attempt. A fake delivery is a database write in the same transaction as related work. A real transport would need its own idempotency and delivery boundary.

The patient demo supplies an already-sent envelope from the selected clinic and patient. Matching checks the current visit, version, sender and candidate set before confirmation. A review item stores candidate identities for a staff member to clarify. Text opt-outs correlate to a previously sent address and persist independently of the snapshot. Staff outcomes and contact verification write an audit row with a scoped request identifier.

Leadership reads grouped clinic/status quantities from the PMS and grouped local work and messaging counts. Staff confirmation and source attendance are independent. The demo staff identity uses an allowlist for the chosen clinic. A deployed application would require authenticated identities, server-owned clinic permissions, and a restricted patient-simulation surface.
