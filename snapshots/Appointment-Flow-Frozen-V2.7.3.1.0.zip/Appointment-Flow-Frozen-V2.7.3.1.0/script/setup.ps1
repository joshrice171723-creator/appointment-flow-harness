param(
    [string]$PostgresBin = 'C:/Program Files/PostgreSQL/17/bin',
    [int]$Port = 55473
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$cluster = Join-Path $root 'tmp/apex-postgres'
$postgresLog = Join-Path $root 'tmp/apex-postgres.log'

function Invoke-SetupCommand {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Executable exited with code $LASTEXITCODE." }
}

New-Item -ItemType Directory -Force (Join-Path $root 'tmp') | Out-Null
if (-not (Test-Path -LiteralPath (Join-Path $cluster 'PG_VERSION'))) {
    Invoke-SetupCommand (Join-Path $PostgresBin 'initdb.exe') @(
        '-D', $cluster, '-U', 'apex_admin', '-A', 'trust', '-E', 'UTF8', '--locale=C'
    )
}

& (Join-Path $PostgresBin 'pg_ctl.exe') -D $cluster status
if ($LASTEXITCODE -ne 0) {
    Invoke-SetupCommand (Join-Path $PostgresBin 'pg_ctl.exe') @(
        '-D', $cluster, '-o', "-h 127.0.0.1 -p $port", '-l', $postgresLog, 'start'
    )
}

Invoke-SetupCommand (Join-Path $PostgresBin 'psql.exe') @(
    '-h', '127.0.0.1', '-p', "$port", '-U', 'apex_admin', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1',
    '-f', (Join-Path $root 'backend/script/demo_roles.sql')
)

$previousPort = $env:APEX_PG_PORT
$previousUser = $env:APEX_DB_USER
$previousEnvironment = $env:RAILS_ENV
Push-Location (Join-Path $root 'backend')
try {
    Invoke-SetupCommand 'bundle.bat' @('install')
    $env:APEX_PG_PORT = "$Port"
    $env:APEX_DB_USER = 'apex_admin'
    $env:RAILS_ENV = 'development'
    Invoke-SetupCommand 'ruby.exe' @('bin/rails', 'db:create', 'db:migrate')
    Invoke-SetupCommand 'ruby.exe' @('bin/rails', 'db:seed')
    $env:RAILS_ENV = 'test'
    Invoke-SetupCommand 'ruby.exe' @('bin/rails', 'db:create', 'db:migrate')
} finally {
    $env:APEX_PG_PORT = $previousPort
    $env:APEX_DB_USER = $previousUser
    $env:RAILS_ENV = $previousEnvironment
    Pop-Location
}

Push-Location (Join-Path $root 'frontend')
try {
    Invoke-SetupCommand 'npm.cmd' @('ci', '--no-audit', '--no-fund')
    Invoke-SetupCommand 'npm.cmd' @('run', 'build')
} finally {
    Pop-Location
}
