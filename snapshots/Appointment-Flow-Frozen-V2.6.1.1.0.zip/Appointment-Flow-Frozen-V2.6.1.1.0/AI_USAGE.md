# AI usage

- Codex in the provided agent environment read the authorized package, verified the manifest, built the local Rails and React application, wrote the synthetic fixtures and tests, and ran the verification commands. No prior implementation repository or notes were accessed.
- Joshua required a successful harness preflight before the rebuild. The agent ran it before the first application file was created. The supplied screenshots guided layout. The official assessment and sanitized behavior documents supplied the workflow contract.
- The agent chose the cadence, clinic-scoped transaction model, conservative reply handling, local contact policy and aggregate reporting definitions. The factual rationale is in [candidate decision notes](notes/CANDIDATE_DECISION_NOTES.md). The candidate authors `DECISIONS.md` and owns the live defense.
- Codex consulted official Rails, React and Vite documentation for framework conventions. Optional skills, external orchestration plugins and prior-project memory were unused. Review mode and results are recorded in [rubric results](review/RUBRIC_RESULTS.md).
