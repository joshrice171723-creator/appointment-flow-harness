# Architecture

```mermaid
flowchart LR
    UI["React workspaces"] --> API["Rails resource endpoints"]
    API --> Staff["Demo clinic and staff scope"]
    API --> Replies["Reply processing"]
    API --> Read["Clinic calendar and work queue"]
    API --> Report["Aggregate leadership queries"]
    Staff --> Batch["Reminder run"]
    Staff --> Work["Follow-up and contact verification"]
    Batch --> Refresh["Compare and reconcile PMS snapshot"]
    Refresh --> PMS[("PMS clinics, patients, appointments")]
    Replies --> PMS
    Work --> PMS
    Report --> PMS
    Batch --> Fake["Fake SMS and email adapter"]
    Fake --> Batch
    Batch --> Local[("Local visits, messages, contacts and work")]
    Refresh --> Local
    Replies --> Local
    Work --> Local
    Local --> Read
    Local --> Report
```

One PostgreSQL database contains the supplied replica tables and separate application tables. Runtime reads of the replica use the read-only `Pms` models. Demo seeding and test fixtures populate the writable replica side. Staff actions, verification, replies, acknowledgments and reminder attempts update only the application tables. The staff session signs the selected clinic and identity and expires after 12 hours. Patient selection in the simulator is scoped to visits at that clinic.

## Appointment response lifecycle

```mermaid
stateDiagram-v2
    [*] --> Unconfirmed: new scheduled source revision
    Unconfirmed --> Confirmed: matched YES or staff records confirmation
    Unconfirmed --> StaffDisposition: staff records cancel or reschedule
    Confirmed --> StaffDisposition: staff records cancel or reschedule
    Confirmed --> Unconfirmed: source time or patient changes
    StaffDisposition --> Unconfirmed: source time or patient changes
    Unconfirmed --> Ineligible: source ends visit or visit starts
    Confirmed --> Ineligible: source ends visit or visit starts
    StaffDisposition --> Ineligible: source ends visit or visit starts
    Ineligible --> Unconfirmed: source schedules a new future revision
```

Review is a work item that can coexist with any response. Unclear or stale replies leave the response unchanged. Staff review candidates carry the revision recorded when the reply arrived. The PMS status stays independently visible when staff record a response or disposition.

## Scheduling and consistency

The reminder endpoint and CLI both call `ReminderRun`. It locks the clinic, compares the source and tracked visits in one SQL snapshot, rejects missing tracked visits and applies changes. The calendar projects visits from yesterday through 35 days ahead. Open staff work keeps eligible older source rows in the comparison so delayed PMS outcomes can close obsolete work. The batch evaluates scheduled, unconfirmed visits in the next seven clinic-local days. The first available run from days seven through four selects the initial step. Days three through the visit start use the follow-up step. SMS is preferred initially. An allowed email is used when SMS is unavailable, after an initial SMS for the follow-up, or as a one-time backup when a simulated SMS fails. One step per run is eligible for a visit, with a single backup on failure. Sending hours are 10:00 through 17:59 in the clinic. In the 48 hours before a visit, unresolved confirmations can create staff work.

PMS `start_at` contains wall-clock components. The app interprets them in the configured IANA zone for each clinic, and blocks outreach for a nonexistent or ambiguous DST time. The batch records its timestamp and fake deliveries in the clinic transaction. An unexpected failure rolls back those local writes. Clinic locks serialize app writes for that clinic, and database keys enforce unique reminder attempts and inbound/staff request identifiers.

The inbox attaches the latest displayed delivered message to its simulated reply. That record supplies the sender address and is retained on the reply. A confirmation must match exactly one recent delivered visit revision for the clinic, channel, current contact address and patient. Staff and reply processing check the current replica appointment before applying an outcome. Shared, changed, conflicting, late and unsupported replies go to review. An exact STOP is stored for the actual sender per clinic and channel. The standard Rails request log filters message bodies, patient searches, verification values and notes.

The external PMS may lag the staff system by five minutes. The app acts on the latest readable replica and can detect changes once they reach it. A production version would use a separately managed read-only replica role, staff authentication and clinic authorization, provider-signed inbound requests, an outbox for provider sends, and retention controls. The fake adapter is synchronous and has no external delivery effects.

Implementation references include the [Rails API guide](https://guides.rubyonrails.org/api_app.html), [Rails query guide](https://guides.rubyonrails.org/active_record_querying.html), [React guide](https://react.dev/learn), and [Vite guide](https://vite.dev/guide/).
