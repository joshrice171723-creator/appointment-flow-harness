# Tradeoff notes for candidate's own DECISIONS.md

The assessment requires that the candidate write `DECISIONS.md` **personally in their own words**. Capture factual choices and alternatives here so the candidate can make their own narrative later. Agent must not claim authorship on their behalf.

- Assumption / ambiguity:
- What was chosen and why:
- Alternative considered and drawback:
- Risk / what would change with another week:
- Evidence (test/demo/measurement):

## Factual implementation choices for the candidate to examine

- The app uses one Rails JSON API, one React UI and two sets of tables in a local PostgreSQL database. The local visit rows retain response and revision state and let staff inspect the last successful snapshot when a refresh is rejected. Source IDs and wall times remain inspectable.
- The 7-to-4-day initial band and follow-up starting three days out coalesce missed days. Confirmation ends confirmation requests. The same clinic lock guards fake send claims, incoming replies and staff changes. An external provider would require delivery status handling across a database and network boundary.
- Shared addresses are checked against raw source addresses and verified contacts. Unverified minors, unsupported or missing language, mismatched verification and invalid contacts can require staff review. The SMS and email seed fields are synthetic permissions for the demo. Local verification records original values and staff provenance.
- One unambiguous delivery in a recent address/channel history can justify applying YES or SÍ. Two candidate revisions, an expired visit or an uncertain sender go to staff review. Candidate revisions remain attached to the reply. The seed assumes the simulated inbox identity, while a real inbound endpoint would need provider verification.
- Staff can record a disposition for the current version. The authoritative PMS state still comes from its source column. Leadership uses completed divided by recorded visit rows and counts staff-reported reschedules or cancellations under follow-up. The replica has no explicit no-show category.
- Discuss whether a per-appointment reply token, better PMS freshness signals, a clinic-managed consent record, or independent provider dispatch would be the next change. The answer and tradeoffs belong in the candidate's own `DECISIONS.md`.
