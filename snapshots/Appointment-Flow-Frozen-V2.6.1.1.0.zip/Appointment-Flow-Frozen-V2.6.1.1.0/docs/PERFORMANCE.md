# Database work and performance

Measure the useful result, time for the complete operation, and work done as the data grows. Start at the existing entry point and follow shared services, association reads, writes and retries. Keep clinic, revision, authorization and transaction boundaries intact.

## Choose the query by its result

Before implementing a material database decision, identify the eligible rows and the smallest result the caller needs. Note it in the existing slice plan. Read the actual Rails version's [Active Record Query Interface](https://guides.rubyonrails.org/active_record_querying.html) for the patterns you use.

| Caller needs | Start with |
|---|---|
| Whether a matching record exists | Scoped `exists?` on an unloaded relation. Reuse a suitable collection when it is already loaded and the answer needs the same snapshot. |
| A few scalar values | `pluck` or `pick`. Use `select` when a caller still needs specific model attributes or behavior. |
| Totals by category | `group(...).count` or the equivalent database aggregate. Keep the intended grouping and date boundary. |
| A list and related rows | Filter and bound the parent list first, then load the required associations together. Check the rendered or serialized result for lazy per-row queries. |
| Related rows or keys already read | Reuse them within the consistency boundary. If an existing write can return the needed keys, check the adapter's return options instead of automatically reading them again. |
| A set of similar writes | Check whether a bulk API preserves validation, callbacks, timestamps, uniqueness, and rollback. Verify the affected rows and return only values the caller uses. |

Keep a clear leading scope. Make null, range endpoints, ordering, and revision or tenant predicates explicit. Keep small SQL fragments for operations that need them. Bind dynamic values, and check the SQL that reaches PostgreSQL when changing a relation, join, or index. Make an expensive shared read or source refresh visible at the owning workflow, with the time-critical section and expected failure easy to find.

## Verify growth during implementation

Choose a consequential read and write or batch from the normal callers. A shared operation is in scope even when it lives several calls below the entry point. Add a focused check to the current slice when the first material path works. Reuse this evidence in review if the final source and workload still match.

1. Establish the expected response and persisted effects in a small synthetic fixture. Run the complete operation with setup and assertions outside the measured block.
2. Keep the useful work fixed. Add data the current query could scan or load even though the result should be unchanged. Choose this extra data from the actual query scope. Include rows inside broad ranges, if relevant, and measure the important query as well as the caller.
3. Grow the eligible work for a batch. Compare reads, written rows, and object loading. For a workflow that can retry, repeat with existing results and check both the persisted effects and what work repeats. Include the scope of any lock or transaction.
4. Record statement counts, returned rows when available, model instantiations, relevant writes, elapsed time, and the query or application source location behind meaningful growth. For a JSON aggregate or wide result, inspect record cardinality or payload size as appropriate. Use a plan to assess a scan or an index. Record which metrics are available and conditions that affect timing.

Use the existing test instrumentation or `quality/rails_workload_probe.rb` for synchronous Rails operations. It measures Active Record events on the calling thread. Check external connections or work on other threads separately when they are material. Framework schema work and cache hits have separate counters. A large payload, misleading aggregate row count, or unnecessary work under a lock matters even when the query count stays flat.

During grading, use equivalent results and trace evidence to distinguish necessary work from avoidable work. For any verified material finding, change the smallest responsible code, rerun the same scenario, and check correctness and performance together. Explain unavoidable growth and distinguish measured facts from a source prediction.

## Measured results on application checkpoint d039c23

The Windows run used Ruby 3.4.10, Rails 8.1.4.1 and PostgreSQL 17.11 on loopback. Run `APEX_WORKLOAD=1 ruby bin/rails test test/integration/workload_test.rb` from `backend`, setting the environment variable with `$env:APEX_WORKLOAD = '1'` in PowerShell. The test measures full synchronous HTTP requests from the actual staff routes. It creates fixtures and verifies persisted effects outside each measured section. Statement counts below exclude cache and schema events. Timing is one local sample per row.

The fixtures start with one eligible appointment, then add 1,200 visits inside the PMS refresh window and outside the reminder cadence and selected calendar week. Finally, the test adds 40 eligible visits. It asserts unchanged calendar rows, unchanged read/model counts on unrelated retry growth, and one fake delivery per eligible appointment. Both the original and revised source comparison produced the same delivery and calendar results.

| Request | DB statements | Rows returned | Records instantiated | Direct write statements | Affected rows | Elapsed ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| First small reminder run | 20 | 8 | 6 | 3 | 3 | 813.9 |
| Small reminder retry | 17 | 8 | 4 | 0 | 0 | 79.1 |
| Import 1,200 newly tracked upcoming visits | 18 | 1,208 | 1,204 | 1 | 1,200 | 1,838.0 |
| Reminder retry with the added visits | 17 | 8 | 4 | 0 | 0 | 82.2 |
| Initial run with 40 additional eligible visits | 59 | 209 | 125 | 41 | 80 | 493.4 |
| Retry with 40 additional eligible visits | 17 | 208 | 84 | 0 | 0 | 117.2 |
| Calendar, one visit | 7 | 6 | 4 | 0 | 0 | 79.4 |
| Same calendar after 1,200 unrelated visits | 7 | 6 | 4 | 0 | 0 | 51.7 |
| Calendar with 41 selected visits | 8 | 87 | 84 | 0 | 0 | 123.3 |

- The earlier working snapshot returned 2,410 rows and loaded 2,406 models on the 1,200-row unrelated retry. The request took 1,448.6 ms in that run. `PmsRefresh#source_changes` now asks PostgreSQL for changed or missing rows from one statement snapshot. `reconcile` reloads only the local rows being changed. The workload assertions preserve the same response and persisted attempt counts. Real-clock retries can also update the successful sync timestamp.
- The expanded fixture's replica query used a hash full join with bitmap scans on the clinic indexes. It matched 1,241 rows on each side, returned zero differences and used 39 shared buffer hits. PostgreSQL reported 7.687 ms execution. Database comparison work still grows with the clinic's tracked candidates even when no rows are transferred to Rails. First-time calendar projection performed a single bulk upsert for the 1,200 new rows.
- The calendar row lookup used `index_visits_on_clinic_setting_id_and_wall_time` for a bounded day followed by an incremental sort and a 200-row limit. It returned 41 rows using 19 shared buffer hits and 0.258 ms of PostgreSQL execution. The HTTP measurements include grouping, patient preload and response generation.
- Eligible growth adds one local fake attempt insert per delivery. The 40-visit run did one visit upsert and 40 attempt inserts. A frozen-clock replay wrote zero rows. The clinic lock includes refresh, eligibility, and the short local fake adapter calls. Active Record reported row and affected-row counts for all measured read and write statements. The first run included 11 separate schema events.

## Repair recheck

The final gate repeated all calendar and reminder measurements above with the late-work source comparison enabled. Returned rows, model counts, writes and result assertions matched. The 1,200-row retry took 57.2 ms and did zero writes. PostgreSQL spent 7.177 ms on the snapshot comparison, returned zero changed rows, and used 39 shared buffer hits. The bounded calendar lookup used the same index and returned 41 rows in 0.273 ms of PostgreSQL execution.

The independent reviewer measured `GET /api/leadership_report?month=2026-11` against two clinics and then sixty. Before repair this took 9 and 183 SELECTs, with whole-request timings of 180 and 2,979.8 ms. After repair the same fixture used 6 SELECTs in both cases, with timings of 92.8 and 143.2 ms. The original two summaries were equal. The final gate's separately warmed fixture used 6 SELECTs at both sizes, returning 6 and 122 database rows and taking 43.5 and 64.1 ms. The added rows represent the 58 configured clinics and their source labels. The regression also checks that a staff action near a month boundary is counted in Austin's November but Phoenix's October. `LeadershipReport` groups all three activity relations by clinic over their timezone-specific month windows.

## Grouped outbound reminder writes

The before runs used application checkpoint `238a473` from checkout `f8c7637` with the same 24-visit fixture and audit assertions as the after runs on `6167b2f`. The earlier isolated experiment used `d039c23`. The baseline reproduced on the current source is 43 statements and 26 writes for 24 attempts. The measurement uses the authenticated reminder POST and its source comparison, clinic lock and visit projection. PostgreSQL 17.11, Rails 8.1.4.1 and the original workload probe ran with the same database and test seed `53441`. The timed requests exclude fixture creation, sign-in and post-response assertions. Whole-command timings below include Rails startup, setup, all workloads and query-plan checks.

| Request | Statements before → after | Direct writes before → after | Affected rows both versions | Before ms, run 1 / run 2 | After ms, run 1 / run 2 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 24 successful reminders from an empty clinic projection | 43 → 20 | 26 → 3 | 49 | 656.1 / 666.2 | 355.9 / 312.0 |
| Retry of those 24 reminders | 17 → 17 | 0 → 0 | 0 | 165.6 / 160.8 | 112.7 / 80.8 |
| 40 eligible appointments added to the existing growth fixture | 59 → 20 | 41 → 2 | 80 | 418.8 / 614.2 | 264.3 / 144.7 |

Whole focused command times were 30.092 and 27.470 seconds before and 22.328 and 25.182 seconds after. These are two local samples per version. The retry used the same database work, so its timing variation does not establish a retry improvement.

- The 24-visit request made 15 reads returning 123 rows and instantiated 75 records in both versions. It wrote 24 visit projections, advanced the clinic sync timestamp and recorded 24 attempts. Database read counts, affected rows and the source comparison code stayed the same. The clinic transaction now uses one strict message insert for the 24 outcomes. The 40-visit growth case kept 16 reads, 209 returned rows and 125 instantiated records, with one projection upsert and one message insert. Its clinic timestamp had already been set at the fixed test time.
- Both versions produced the same response counts and all expected message fields, including the linked visit, revision, step, channel, address, body, timestamps, and the defaults used by inbound-only fields. The retry kept the complete stored rows, including their IDs. The focused tests cover the separate dispatch and audit times, SMS rejection and email fallback, and the same transaction's rollback after PostgreSQL reports two message rows written.
- The unrelated growth retry still returned 8 rows with zero writes. Calendar payload equality and the clinic/day index check passed. Leadership continued to use six reads with two and sixty clinics.
- The change buffers the current clinic's new attempt rows until the final insert. Work items and fake delivery decisions are still evaluated per visit under the clinic lock. The measurements cover up to 40 newly eligible visits with the local fake transport. The same model of rollback covers the local audit rows, refresh and work items.
