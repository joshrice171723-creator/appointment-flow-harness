class WorkItem < ApplicationRecord
  KINDS = {
    "no_reply" => "No confirmation",
    "contact_hold" => "Contact hold",
    "delivery_failed" => "Delivery failed",
    "reply_review" => "Reply to review"
  }.freeze

  belongs_to :clinic_setting
  belongs_to :visit, optional: true
  belongs_to :message, optional: true
  belongs_to :patient, class_name: "Pms::Patient", optional: true
  has_many :staff_actions

  scope :open, -> { where(resolved_at: nil) }

  def self.record_visit_issue(visit, kind, reason)
    item = find_or_initialize_by(
      clinic_setting_id: visit.clinic_setting_id, key: "#{visit.id}:#{visit.revision}:#{kind}"
    )
    return if item.persisted? && item.resolved_at.nil? && item.reason == reason

    item.update!(visit: visit, patient_id: visit.patient_id, revision: visit.revision, kind: kind,
      reason: reason, resolved_at: nil)
  end
end
