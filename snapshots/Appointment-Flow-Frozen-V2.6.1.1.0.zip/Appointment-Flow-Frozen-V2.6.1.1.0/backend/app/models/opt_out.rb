class OptOut < ApplicationRecord
  belongs_to :clinic_setting
end
