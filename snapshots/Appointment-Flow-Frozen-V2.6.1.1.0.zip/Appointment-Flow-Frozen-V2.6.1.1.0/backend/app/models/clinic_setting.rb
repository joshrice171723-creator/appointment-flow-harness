class ClinicSetting < ApplicationRecord
  STAFF = {
    1 => [ "Taylor Morgan", "Jordan Ellis" ],
    2 => [ "Casey Reed", "Alex Monroe" ]
  }.freeze

  belongs_to :clinic, class_name: "Pms::Clinic", foreign_key: :id, optional: true
  has_many :visits
  has_many :contact_verifications
  has_many :messages
  has_many :opt_outs
  has_many :work_items
  has_many :staff_actions

  def zone
    Time.find_zone!(timezone)
  end

  def local_date(now = Time.current)
    now.in_time_zone(zone).to_date
  end

  def wall_midnight(date)
    date.to_time(:utc)
  end

  def appointment_instant(wall_time)
    periods = zone.tzinfo.periods_for_local(wall_time)
    return unless periods.one?

    wall_time - periods.first.observed_utc_offset
  end

  def staff_names
    STAFF.fetch(id, [])
  end
end
