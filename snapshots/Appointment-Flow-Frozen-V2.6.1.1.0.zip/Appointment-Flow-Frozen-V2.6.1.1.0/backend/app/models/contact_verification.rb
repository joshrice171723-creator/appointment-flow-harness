class ContactVerification < ApplicationRecord
  FIELDS = %w[birthdate wireless_phone email preferred_language].freeze

  belongs_to :clinic_setting

  def value_for(patient, field)
    fields.fetch(field, {}).fetch("value") { patient.public_send(field)&.to_s }
  end

  def conflicts_with?(patient)
    fields.any? { |field, entry| entry.fetch("source") != patient.public_send(field)&.to_s }
  end
end
