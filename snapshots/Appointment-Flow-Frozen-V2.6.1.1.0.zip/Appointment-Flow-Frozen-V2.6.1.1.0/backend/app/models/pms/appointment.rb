module Pms
  class Appointment < Record
    self.table_name = "appointments"
  end
end
