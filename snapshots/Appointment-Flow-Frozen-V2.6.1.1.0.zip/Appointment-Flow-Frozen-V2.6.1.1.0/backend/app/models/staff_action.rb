class StaffAction < ApplicationRecord
  REQUEST_KEY = /\A[\w-]{8,100}\z/

  belongs_to :clinic_setting
  belongs_to :work_item, optional: true
end
