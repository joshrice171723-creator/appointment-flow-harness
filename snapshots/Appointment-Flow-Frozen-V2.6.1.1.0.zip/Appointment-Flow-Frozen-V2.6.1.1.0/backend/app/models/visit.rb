class Visit < ApplicationRecord
  belongs_to :clinic_setting
  belongs_to :patient, class_name: "Pms::Patient"
  has_many :messages
  has_many :work_items

  scope :scheduled, -> { where(source_status: "scheduled") }

  def accepts_response?(now)
    source_status == "scheduled" && starts_at.present? && starts_at > now &&
      response.in?(%w[unconfirmed confirmed])
  end

  def matches_replica?(source)
    source.present? && source.clinic_id == clinic_setting_id && source.patient_id == patient_id &&
      source.start_at == wall_time && source.status == source_status
  end

  def local_time_label
    wall_time.strftime("%a, %b %-d at %-I:%M %p")
  end
end
