class Message < ApplicationRecord
  belongs_to :clinic_setting
  belongs_to :visit, optional: true

  scope :outbound, -> { where(direction: "outbound") }
  scope :inbound, -> { where(direction: "inbound") }
  scope :delivered, -> { where(outcome: "delivered") }

  def current_candidate?(visit)
    candidate_revisions[visit.id.to_s] == visit.revision
  end
end
