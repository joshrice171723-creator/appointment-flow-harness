class StaffFollowUpsController < StaffController
  def create
    item = @clinic.work_items.find(params[:work_item_id])
    target_ids = params[:target_ids] || []
    unless target_ids.is_a?(Array) && target_ids.size <= 40 && target_ids.all? { |id| id.is_a?(Integer) && id.positive? }
      raise InvalidInput, "Choose valid appointments."
    end

    action = StaffFollowUp.new(@clinic, item: item, staff: @staff, outcome: params[:outcome],
      note: params[:note], request_key: params[:request_key], target_ids: target_ids.uniq.sort).call
    render json: { id: action.id, outcome: action.outcome }, status: :created
  end
end
