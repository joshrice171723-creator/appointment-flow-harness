class ReminderRunsController < StaffController
  def create
    render json: ReminderRun.new(@clinic).call, status: :created
  end
end
