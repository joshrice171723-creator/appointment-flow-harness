class StaffController < ApplicationController
  before_action :require_staff_clinic

  private

  def require_staff_clinic
    token = request.headers["Authorization"].to_s.delete_prefix("Bearer ")
    identity = Rails.application.message_verifier(:staff_demo).verified(token, purpose: :staff_demo)
    unless identity && identity.fetch("clinic_id").to_s == params[:clinic_id].to_s
      return render json: { error: "Open the selected front-desk workspace first." }, status: :unauthorized
    end

    @clinic = ClinicSetting.find(identity.fetch("clinic_id"))
    @staff = identity.fetch("staff")
  end
end
