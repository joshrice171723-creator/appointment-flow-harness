module StaffPayload
  private

  def clinic_json
    {
      id: @clinic.id, name: @clinic.clinic.name, timezone: @clinic.timezone,
      today: @clinic.local_date.iso8601, last_synced_at: @clinic.last_synced_at
    }
  end

  def visit_json(visit)
    visit.as_json(only: %i[id appointment_id patient_id wall_time source_status response provider_name length_minutes])
      .merge(patient_name: visit.patient.name)
  end

  def item_json(item)
    item.as_json(only: %i[id patient_id kind reason assignee resolved_at created_at])
      .merge(patient_name: item.patient&.name, visit_time: item.visit&.wall_time)
  end

  def patient_record(patient, selected_item: nil)
    verification = @clinic.contact_verifications.find_by(patient_id: patient.id) if patient
    profile = if patient
      fields = ContactVerification::FIELDS.index_with do |field|
        source = patient.public_send(field)&.to_s
        entry = verification&.fields&.[](field)
        { source: source, verified: entry, conflict: entry.present? && entry.fetch("source") != source }
      end
      { id: patient.id, name: patient.name, fields: fields }
    end

    items = if patient
      @clinic.work_items.where(patient_id: patient.id)
        .includes(:patient, :visit, :message).order(resolved_at: :desc, updated_at: :desc).limit(60)
    else
      [ selected_item ]
    end
    items = items.to_a
    items.unshift(selected_item) if selected_item && items.none? { |item| item.id == selected_item.id }

    candidate_ids = items.filter_map(&:message).flat_map(&:candidate_ids).uniq
    candidates = @clinic.visits.where(id: candidate_ids).includes(:patient).index_by(&:id)
    follow_ups = items.map do |item|
      message = item.message
      current_candidates = message&.candidate_ids.to_a.filter_map do |id|
        visit = candidates[id]
        visit_json(visit) if visit && message.current_candidate?(visit)
      end
      item_json(item).merge(message: message&.body, candidates: current_candidates)
    end

    activity = @clinic.staff_actions.where(patient_id: patient.id)
      .order(created_at: :desc).limit(60).as_json(only: %i[id staff outcome note created_at details]) if patient
    visits = @clinic.visits.where(patient_id: patient.id).includes(:patient).order(wall_time: :desc).limit(60) if patient

    { clinic: clinic_json, patient: profile, items: follow_ups,
      visits: visits.to_a.map { |visit| visit_json(visit) }, activity: activity || [] }
  end
end
