class LeadershipReportsController < ApplicationController
  def show
    value = params[:month].presence || Date.current.strftime("%Y-%m")
    unless value.is_a?(String) && value.match?(/\A\d{4}-\d{2}\z/)
      raise InvalidInput, "Choose a valid reporting month."
    end

    report = LeadershipReport.new(Date.iso8601("#{value}-01")).call
    render json: report
  rescue Date::Error
    raise InvalidInput, "Choose a valid reporting month."
  end
end
