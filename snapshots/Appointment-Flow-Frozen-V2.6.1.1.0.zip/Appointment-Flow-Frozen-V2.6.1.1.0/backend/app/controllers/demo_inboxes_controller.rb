class DemoInboxesController < ApplicationController
  before_action :load_clinic

  def index
    patients = Pms::Patient.where(id: patient_ids).order(:last_name, :first_name)
    render json: { patients: patients.map { |patient| { id: patient.id, name: patient.name } }, timezone: @clinic.timezone }
  end

  def show
    patient = Pms::Patient.where(id: patient_ids).find(params[:id])
    channel = params[:channel].to_s
    raise InvalidInput, "Choose Text messages or Email." unless InboundReply::CHANNELS.include?(channel)

    conversation = @clinic.messages.where(patient_id: patient.id, channel: channel).order(created_at: :desc, id: :desc)
    messages = conversation.where.not(outcome: "failed").limit(100).reverse
    latest = messages.reverse_each.find { |message| message.direction == "outbound" && message.outcome == "delivered" }
    unless latest
      latest = conversation.outbound.delivered.first
      messages.unshift(latest) if latest
    end
    render json: { messages: messages.map { |message| message_json(message) }, reply_to_id: latest&.id }
  end

  private

  def load_clinic
    @clinic = ClinicSetting.find(params[:clinic_id])
  end

  def patient_ids
    @clinic.visits.select(:patient_id)
  end

  def message_json(message)
    message.as_json(only: %i[id body direction outcome created_at])
  end
end
