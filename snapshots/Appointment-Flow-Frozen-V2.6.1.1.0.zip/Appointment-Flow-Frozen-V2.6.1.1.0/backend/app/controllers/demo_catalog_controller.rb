class DemoCatalogController < ApplicationController
  def index
    clinics = ClinicSetting.includes(:clinic).order(:id).filter_map do |setting|
      next unless setting.clinic

      { id: setting.id, name: setting.clinic.name, state: setting.clinic.state, staff: setting.staff_names }
    end
    render json: { clinics: clinics }
  end
end
