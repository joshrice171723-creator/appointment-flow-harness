class StaffPatientsController < StaffController
  include StaffPayload

  def show
    patient = Pms::Patient.where(id: @clinic.visits.select(:patient_id)).find(params[:id])
    render json: patient_record(patient)
  end
end
