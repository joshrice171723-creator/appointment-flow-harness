class ApplicationController < ActionController::API
  class InvalidInput < StandardError; end

  rescue_from InvalidInput, WorkflowRejected, ActionController::ParameterMissing, with: :invalid_request
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "This record is unavailable in the selected clinic." }, status: :not_found
  end
  rescue_from PmsRefresh::Unavailable do |error|
    render json: { error: error.message }, status: :service_unavailable
  end

  private

  def invalid_request(error)
    render json: { error: error.message }, status: :unprocessable_content
  end
end
