class StaffWorkItemsController < StaffController
  include StaffPayload

  PAGE_SIZE = 12

  def index
    items = @clinic.work_items
    counts = items.group(Arel.sql("resolved_at IS NOT NULL"), Arel.sql("assignee IS NOT NULL")).count
    status = params.fetch(:status, "active")
    items = case status
    when "active" then items.open
    when "resolved" then items.where.not(resolved_at: nil)
    when "all" then items
    else raise InvalidInput, "Choose a board status."
    end

    if params[:kind].present?
      raise InvalidInput, "Choose a follow-up type." unless WorkItem::KINDS.key?(params[:kind])

      items = items.where(kind: params[:kind])
    end
    if params[:q].present?
      pattern = "%#{ActiveRecord::Base.sanitize_sql_like(params[:q].to_s.strip.first(100))}%"
      patients = Pms::Patient.where("concat_ws(' ', first_name, last_name) ILIKE ?", pattern).select(:id)
      items = items.where(patient_id: patients)
    end

    total = items.count
    pages = [ (total.to_f / PAGE_SIZE).ceil, 1 ].max
    page = params[:page].to_i.clamp(1, pages)
    rows = items.includes(:patient, :visit).order(updated_at: :desc, id: :desc)
      .limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE)
    render json: {
      clinic: clinic_json, kinds: WorkItem::KINDS, items: rows.map { |item| item_json(item) },
      page: page, pages: pages, total: total,
      counts: { attention: counts.fetch([ false, false ], 0), progress: counts.fetch([ false, true ], 0),
        resolved: counts.fetch([ true, false ], 0) + counts.fetch([ true, true ], 0) }
    }
  end

  def show
    item = @clinic.work_items.includes(:patient, :visit, :message).find(params[:id])
    render json: patient_record(item.patient, selected_item: item)
  end

  def update
    item = @clinic.work_items.find(params[:id])
    @clinic.with_lock do
      item.reload
      if item.resolved_at || (item.assignee && item.assignee != @staff)
        raise WorkflowRejected, "This item is no longer available to assign."
      end

      item.update!(assignee: @staff)
    end
    render json: { id: item.id, assignee: item.assignee }
  end
end
