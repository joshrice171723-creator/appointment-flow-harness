class StaffSessionsController < ApplicationController
  def create
    clinic = ClinicSetting.find(params[:clinic_id])
    staff = params[:staff].to_s
    unless clinic.clinic && clinic.staff_names.include?(staff)
      raise InvalidInput, "Choose a staff member for this clinic."
    end

    identity = { "clinic_id" => clinic.id, "staff" => staff }
    token = Rails.application.message_verifier(:staff_demo).generate(identity, purpose: :staff_demo, expires_in: 12.hours)
    render json: { token: token }, status: :created
  end
end
