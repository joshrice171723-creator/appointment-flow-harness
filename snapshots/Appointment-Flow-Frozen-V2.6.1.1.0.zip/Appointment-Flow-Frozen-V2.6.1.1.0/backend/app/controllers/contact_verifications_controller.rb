class ContactVerificationsController < StaffController
  def update
    patient = Pms::Patient.where(id: @clinic.visits.select(:patient_id)).find(params[:patient_id])
    action = VerifyContact.new(@clinic, patient: patient, staff: @staff, field: params[:id],
      value: params[:value], request_key: params[:request_key]).call
    render json: { id: action.id, outcome: action.outcome }
  end
end
