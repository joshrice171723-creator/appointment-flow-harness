class DemoRepliesController < ApplicationController
  def create
    clinic = ClinicSetting.find(params[:clinic_id])
    patient = Pms::Patient.where(id: clinic.visits.select(:patient_id)).find(params[:inbox_id])
    channel, body, event_id = params.expect(:channel, :body, :event_id)
    message = InboundReply.new(clinic, patient: patient, channel: channel, body: body, event_id: event_id,
      reply_to_id: params[:reply_to_id]).call

    render json: { id: message.id, outcome: message.outcome }, status: :created
  end
end
