class StaffAppointmentsController < StaffController
  include StaffPayload

  FILTERS = %w[all confirmed unconfirmed review].freeze

  def index
    date = appointment_date
    filter = params.fetch(:filter, "all")
    raise InvalidInput, "Choose an appointment filter." unless FILTERS.include?(filter)

    day = @clinic.wall_midnight(date)
    tomorrow = @clinic.wall_midnight(date + 1)
    visits = @clinic.visits.where(wall_time: day...tomorrow)
    review_messages = @clinic.work_items.open.where(kind: "reply_review").select(:message_id)
    review_ids = @clinic.messages.where(id: review_messages).select("unnest(candidate_ids)")
    review_visits = visits.where(id: review_ids)

    totals = visits.group(:response).count
    selected = case filter
    when "confirmed", "unconfirmed" then visits.where(response: filter)
    when "review" then review_visits
    else visits
    end

    monday = date.beginning_of_week
    week = @clinic.wall_midnight(monday)...@clinic.wall_midnight(monday + 7)
    week_counts = @clinic.visits.where(wall_time: week).group(Arel.sql("wall_time::date")).count
    rows = selected.includes(:patient).order(:wall_time, :id).limit(200).to_a
    review_row_ids = review_visits.where(id: rows.map(&:id)).pluck(:id).to_set
    render json: {
      clinic: clinic_json, date: date.iso8601, week_counts: week_counts,
      counts: { all: totals.values.sum, confirmed: totals.fetch("confirmed", 0),
        unconfirmed: totals.fetch("unconfirmed", 0), review: review_visits.count },
      visits: rows.map { |visit| visit_json(visit).merge(needs_review: review_row_ids.include?(visit.id)) }
    }
  end

  private

  def appointment_date
    return @clinic.local_date if params[:date].blank?

    value = params[:date].to_s
    raise InvalidInput, "Enter a valid date." unless value.match?(/\A\d{4}-\d{2}-\d{2}\z/)

    Date.iso8601(value)
  rescue Date::Error
    raise InvalidInput, "Enter a valid date."
  end
end
