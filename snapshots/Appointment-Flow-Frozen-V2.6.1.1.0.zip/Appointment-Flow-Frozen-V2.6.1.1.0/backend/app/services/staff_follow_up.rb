class StaffFollowUp
  OUTCOMES = %w[attempted confirmed rescheduled canceled reviewed].freeze

  def initialize(clinic, item:, staff:, outcome:, note:, request_key:, target_ids: [], now: Time.current)
    @clinic = clinic
    @item = item
    @staff = staff
    @outcome = outcome
    @note = note.to_s.strip
    @request_key = request_key.to_s
    @target_ids = target_ids
    @now = now
  end

  def call
    validate_input
    @clinic.with_lock do
      existing = @clinic.staff_actions.find_by(request_key: @request_key)
      next replay(existing) if existing

      @item.reload
      validate_item
      visits = current_targets
      apply_outcome(visits)
      @clinic.staff_actions.create!(work_item: @item, patient_id: @item.patient_id, staff: @staff,
        outcome: @outcome, note: @note, request_key: @request_key, target_ids: @target_ids, created_at: @now)
    end
  end

  private

  def validate_input
    raise WorkflowRejected, "Choose a follow-up outcome." unless OUTCOMES.include?(@outcome)
    raise WorkflowRejected, "Enter a short note (1–500 characters)." unless @note.length.between?(1, 500)
    raise WorkflowRejected, "The save identifier is invalid." unless @request_key.match?(StaffAction::REQUEST_KEY)
  end

  def replay(action)
    unless [ action.work_item_id, action.staff, action.outcome, action.note, action.target_ids ] ==
        [ @item.id, @staff, @outcome, @note, @target_ids ]
      raise WorkflowRejected, "This save identifier already belongs to a different update."
    end

    action
  end

  def validate_item
    raise WorkflowRejected, "This item is already resolved. Reload to see its history." if @item.resolved_at
    if @item.assignee && @item.assignee != @staff
      raise WorkflowRejected, "This item is assigned to another staff member."
    end

    reply_review = @item.kind == "reply_review"
    if (@outcome == "reviewed" && !reply_review) ||
        (@target_ids.any? && (!reply_review || %w[attempted reviewed].include?(@outcome)))
      raise WorkflowRejected, "Choose an outcome and appointments for this follow-up type."
    end
  end

  def current_targets
    return [] if %w[attempted reviewed].include?(@outcome)

    ids = @item.kind == "reply_review" ? @target_ids : [ @item.visit_id ]
    allowed = @item.kind == "reply_review" ? @item.message.candidate_ids : [ @item.visit_id ]
    if ids.empty? || (ids - allowed).any?
      raise WorkflowRejected, "Choose the appointment or appointments you verified."
    end

    visits = @clinic.visits.where(id: ids).to_a
    source = Pms::Appointment.where(id: visits.map(&:appointment_id)).index_by(&:id)
    if visits.size != ids.size || visits.any? { |visit| ineligible?(visit, source[visit.appointment_id]) }
      raise WorkflowRejected, "An appointment changed or has already started. Refresh before saving."
    end

    visits
  end

  def ineligible?(visit, source)
    return true unless visit.accepts_response?(@now) && visit.matches_replica?(source)

    if @item.kind == "reply_review"
      !@item.message.current_candidate?(visit)
    else
      @item.revision != visit.revision
    end
  end

  def apply_outcome(visits)
    @item.update!(assignee: @staff, resolved_at: @outcome == "attempted" ? nil : @now)
    visits.each do |visit|
      visit.update!(response: @outcome, responded_at: @now)
      related = visit.work_items.open.where(revision: visit.revision)
      related = related.where(kind: "no_reply") if @outcome == "confirmed"
      related.where.not(kind: "reply_review").update_all(resolved_at: @now, updated_at: @now)
    end
  end
end
