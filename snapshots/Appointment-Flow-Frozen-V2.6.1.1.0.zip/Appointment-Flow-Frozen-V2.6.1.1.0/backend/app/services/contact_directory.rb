class ContactDirectory
  PHONE_EXPRESSION = "right(regexp_replace(wireless_phone, '[^0-9]', '', 'g'), 10)"
  EMAIL_EXPRESSION = "lower(regexp_replace(email, '^[[:space:]]+|[[:space:]]+$', '', 'g'))"
  LANGUAGES = %w[en es].freeze

  def self.phone(value)
    raw = value.to_s.strip
    return unless raw.match?(/\A\+?[0-9(). -]+\z/)

    digits = raw.gsub(/\D/, "")
    return if raw.start_with?("+") && !digits.match?(/\A1\d{10}\z/)

    digits = digits.sub(/\A1(?=\d{10}\z)/, "")
    digits if digits.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
  end

  def self.email(value)
    address = value.to_s.strip.downcase
    address if address.length <= 254 && address.match?(URI::MailTo::EMAIL_REGEXP)
  end

  def initialize(clinic, patients, date)
    @date = date
    @verifications = clinic.contact_verifications.where(patient_id: patients.map(&:id)).index_by(&:patient_id)
    @addresses = patients.to_h { |patient| [ patient.id, addresses_for(patient) ] }
    @owners = {
      "sms" => address_owners("sms", PHONE_EXPRESSION, :verified_phone),
      "email" => address_owners("email", EMAIL_EXPRESSION, :verified_email)
    }
    @opt_outs = clinic.opt_outs.where(address: @addresses.values.flat_map(&:values).compact.uniq)
      .pluck(:channel, :address).to_set
  end

  def hold_reason(patient)
    verification = @verifications[patient.id]
    return "Verified details differ from the PMS. Review the current source values." if verification&.conflicts_with?(patient)

    birthdate = value_for(patient, "birthdate")
    return "A valid birthdate is required." if birthdate.blank? || Date.iso8601(birthdate) > @date
    return "Guardian authorization requires staff review." if Date.iso8601(birthdate) > @date.years_ago(18)
    return "Preferred language requires staff review." unless LANGUAGES.include?(language(patient))

    nil
  end

  def language(patient)
    value_for(patient, "preferred_language").to_s.strip.downcase
  end

  def address(patient, channel)
    @addresses.fetch(patient.id).fetch(channel)
  end

  def address_available?(patient, channel)
    recipient = address(patient, channel)
    recipient.present? && !shared?(patient, channel) && !@opt_outs.include?([ channel, recipient ])
  end

  def shared?(patient, channel)
    owner_ids(patient, channel).any? { |owner_id| owner_id != patient.id }
  end

  def owner_ids(patient, channel)
    @owners.fetch(channel).fetch(address(patient, channel), [])
  end

  private

  def value_for(patient, field)
    verification = @verifications[patient.id]
    verification ? verification.value_for(patient, field) : patient.public_send(field)&.to_s
  end

  def addresses_for(patient)
    {
      "sms" => self.class.phone(value_for(patient, "wireless_phone")),
      "email" => self.class.email(value_for(patient, "email"))
    }
  end

  def address_owners(channel, expression, verified_column)
    addresses = @addresses.values.filter_map { |address| address[channel] }.uniq
    return {} if addresses.empty?

    normalized_address = Arel.sql(expression)
    source = Pms::Patient.where(normalized_address.in(addresses)).pluck(:id, normalized_address)
    verified = ContactVerification.where(verified_column => addresses).pluck(:patient_id, verified_column)
    (source + verified).group_by(&:last).transform_values { |entries| entries.map(&:first).uniq }
  end
end
