class LeadershipReport
  MONTHS = 6

  def initialize(month)
    @month = month
  end

  def call
    clinics = ClinicSetting.includes(:clinic).order(:id).select(&:clinic)
    months = ((MONTHS - 1).downto(0)).map { |offset| @month << offset }
    # PMS timestamps carry clinic wall-clock components, so grouping uses the stored month.
    wall_range = months.first.to_time(:utc)...@month.next_month.to_time(:utc)
    outcomes = Pms::Appointment.where(clinic_id: clinics.map(&:id), start_at: wall_range)
      .group(:clinic_id, Arel.sql("date_trunc('month', start_at)::date"), :status).count
    outcomes_by_month = outcomes.each_with_object({}) do |((clinic_id, month, status), count), grouped|
      (grouped[[ clinic_id, month ]] ||= {})[status] = count
    end
    ranges = clinic_month_ranges(clinics)
    reminders = monthly_activity(Message.outbound, ranges).group(:clinic_setting_id, :outcome).count
    staff = monthly_activity(StaffAction.all, ranges).group(:clinic_setting_id, :outcome).count
    holds = monthly_activity(WorkItem.where(kind: "contact_hold"), ranges).group(:clinic_setting_id).count

    {
      month: @month.strftime("%Y-%m"),
      clinics: clinics.map { |clinic| clinic_summary(clinic, months, outcomes_by_month, reminders, staff, holds) }
    }
  end

  private

  def clinic_month_ranges(clinics)
    next_month = @month.next_month
    clinics.group_by(&:timezone).values.map do |settings|
      zone = settings.first.zone
      first = zone.local(@month.year, @month.month)
      last = zone.local(next_month.year, next_month.month)
      [ settings.map(&:id), first...last ]
    end
  end

  def monthly_activity(records, ranges)
    ranges.reduce(records.none) do |scope, (clinic_ids, range)|
      scope.or(records.where(clinic_setting_id: clinic_ids, created_at: range))
    end
  end

  def clinic_summary(clinic, months, outcomes, reminders, staff, holds)
    id = clinic.id
    month_history = months.map do |month|
      outcome_totals(month, outcomes.fetch([ id, month ], {}))
    end

    {
      clinic_id: id, name: clinic.clinic.name, outcomes: month_history.last, history: month_history,
      reminders: { delivered: reminders.fetch([ id, "delivered" ], 0), failed: reminders.fetch([ id, "failed" ], 0) },
      work: {
        contact_holds: holds.fetch(id, 0),
        attempted: staff.fetch([ id, "attempted" ], 0), confirmed: staff.fetch([ id, "confirmed" ], 0),
        rescheduled: staff.fetch([ id, "rescheduled" ], 0), canceled: staff.fetch([ id, "canceled" ], 0),
        reviewed: staff.fetch([ id, "reviewed" ], 0), contact_verified: staff.fetch([ id, "contact_verified" ], 0)
      }
    }
  end

  def outcome_totals(month, counts)
    recorded = counts.values.sum
    completed = counts.fetch("complete", 0)
    scheduled = counts.fetch("scheduled", 0)
    { month: month.strftime("%Y-%m"), recorded: recorded, completed: completed,
      scheduled: scheduled, unknown: recorded - completed - scheduled,
      completion_rate: recorded.positive? ? (completed.fdiv(recorded) * 100).round(1) : nil }
  end
end
