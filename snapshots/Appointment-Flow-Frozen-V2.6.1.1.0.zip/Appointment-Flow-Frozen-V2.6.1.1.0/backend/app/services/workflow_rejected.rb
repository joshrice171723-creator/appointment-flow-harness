class WorkflowRejected < StandardError; end
