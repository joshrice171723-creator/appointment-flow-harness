class FakeMessenger
  Result = Data.define(:outcome)

  def deliver(channel:, address:, body:)
    # The reserved fictional suffix exercises a provider rejection.
    rejected = channel == "sms" && address.end_with?("0199")
    Result.new(outcome: rejected ? "failed" : "delivered")
  end
end
