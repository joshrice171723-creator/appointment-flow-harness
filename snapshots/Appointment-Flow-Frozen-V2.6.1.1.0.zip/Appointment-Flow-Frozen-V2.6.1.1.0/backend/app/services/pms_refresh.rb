class PmsRefresh
  class Unavailable < StandardError; end

  LOOKAHEAD_DAYS = 35
  VISIT_FIELDS = %i[id appointment_id patient_id provider_name length_minutes wall_time source_status].freeze

  def initialize(clinic, now)
    @clinic = clinic
    @now = now
    @first_day = clinic.wall_midnight(clinic.local_date(now) - 1)
    @last_day = clinic.wall_midnight(clinic.local_date(now) + LOOKAHEAD_DAYS + 1)
  end

  # The calling workflow holds the clinic lock through reconciliation and any sends.
  def call
    changes = source_changes
    if changes.any? { |appointment| appointment.id.nil? }
      raise Unavailable, "The PMS snapshot is missing tracked appointments. Existing work was preserved."
    end

    reconcile(changes) if changes.any?
    @clinic.update!(last_synced_at: @now)
  end

  private

  def source_changes
    unless Pms::Clinic.exists?(@clinic.id)
      raise Unavailable, "The PMS clinic is unavailable."
    end

    replica = Pms::Appointment.where(clinic_id: @clinic.id)
    open_visit_work = @clinic.work_items.open.where.not(kind: "reply_review").select(:visit_id)
    visits_with_work = @clinic.visits.where(id: open_visit_work, appointment_id: replica.select(:id))
    tracked = @clinic.visits.where(wall_time: @first_day...@last_day)
      .or(@clinic.visits.scheduled.where(wall_time: @first_day..)).or(visits_with_work)
    nearby = replica.where(start_at: @first_day...@last_day)
    source = nearby.or(replica.where(id: tracked.select(:appointment_id)))
    local = tracked.or(@clinic.visits.where(appointment_id: nearby.select(:id)))

    # One statement compares the same source snapshot for both missing and changed rows.
    Pms::Appointment.find_by_sql(<<~SQL)
      SELECT replica.id, replica.patient_id, replica.provider_name, replica.length_minutes,
             replica.start_at, replica.status, local.id AS visit_id
      FROM (#{source.select(:id, :patient_id, :provider_name, :length_minutes, :start_at, :status).to_sql}) replica
      FULL OUTER JOIN (#{local.select(*VISIT_FIELDS).to_sql}) local
        ON local.appointment_id = replica.id
      WHERE replica.id IS NULL OR local.id IS NULL
        OR (replica.patient_id, replica.start_at, replica.status, replica.provider_name, replica.length_minutes)
          IS DISTINCT FROM (local.patient_id, local.wall_time, local.source_status, local.provider_name, local.length_minutes)
    SQL
  rescue ActiveRecord::ConnectionNotEstablished, ActiveRecord::ConnectionFailed
    raise Unavailable, "The PMS could not be reached."
  rescue ActiveRecord::StatementInvalid => error
    raise unless error.cause.is_a?(PG::QueryCanceled) || error.cause.is_a?(PG::UndefinedTable)

    raise Unavailable, "The PMS snapshot could not be read."
  end

  def reconcile(source)
    tracked = @clinic.visits.where(id: source.filter_map(&:visit_id)).index_by(&:id)
    superseded_ids = []
    changes = source.map do |appointment|
      visit = tracked[appointment.visit_id]
      attributes = visit_attributes(appointment)
      if visit
        visit.assign_attributes(attributes)
        if (visit.changed & %w[patient_id wall_time starts_at source_status]).any?
          superseded_ids << visit.id
          attributes.merge(revision: visit.revision + 1, response: "unconfirmed", responded_at: nil)
        else
          attributes.merge(revision: visit.revision, response: visit.response, responded_at: visit.responded_at)
        end
      else
        attributes.merge(revision: 1, response: "unconfirmed", responded_at: nil)
      end
    end
    @clinic.visits.upsert_all(changes, unique_by: %i[clinic_setting_id appointment_id], returning: false)
    if superseded_ids.any?
      @clinic.work_items.open.where(visit_id: superseded_ids).where.not(kind: "reply_review")
        .update_all(resolved_at: @now, updated_at: @now)
    end
  end

  def visit_attributes(appointment)
    {
      appointment_id: appointment.id,
      clinic_setting_id: @clinic.id,
      patient_id: appointment.patient_id,
      provider_name: appointment.provider_name,
      length_minutes: appointment.length_minutes,
      wall_time: appointment.start_at,
      starts_at: @clinic.appointment_instant(appointment.start_at),
      source_status: appointment.status
    }
  end
end
