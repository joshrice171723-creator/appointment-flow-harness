class VerifyContact
  def initialize(clinic, patient:, staff:, field:, value:, request_key:, now: Time.current)
    @clinic = clinic
    @patient = patient
    @staff = staff
    @field = field
    @value = value.to_s.strip
    @request_key = request_key.to_s
    @now = now
  end

  def call
    verify_input
    @clinic.with_lock do
      existing = @clinic.staff_actions.find_by(request_key: @request_key)
      next replay(existing) if existing

      @patient.reload
      verification = @clinic.contact_verifications.find_or_initialize_by(patient_id: @patient.id)
      previous = verification.value_for(@patient, @field)
      source = @patient.public_send(@field)&.to_s
      entry = { "value" => @value, "source" => source, "verified_by" => @staff, "verified_at" => @now.iso8601 }
      verification.fields = verification.fields.merge(@field => entry)
      verification.verified_phone = ContactDirectory.phone(verification.fields.dig("wireless_phone", "value"))
      verification.verified_email = ContactDirectory.email(verification.fields.dig("email", "value"))
      verification.save!

      @clinic.staff_actions.create!(patient_id: @patient.id, staff: @staff, outcome: "contact_verified",
        note: "Verified #{@field.humanize.downcase}.", request_key: @request_key, created_at: @now,
        details: { field: @field, previous: previous, value: @value, source: source })
    end
  end

  private

  def verify_input
    raise WorkflowRejected, "Choose a contact field." unless ContactVerification::FIELDS.include?(@field)
    raise WorkflowRejected, "The save identifier is invalid." unless @request_key.match?(StaffAction::REQUEST_KEY)

    valid = case @field
    when "birthdate"
      valid_birthdate?
    when "wireless_phone"
      @value.empty? || ContactDirectory.phone(@value)
    when "email"
      @value.empty? || ContactDirectory.email(@value)
    when "preferred_language"
      ContactDirectory::LANGUAGES.include?(@value)
    end
    raise WorkflowRejected, "Enter a valid value for #{@field.humanize.downcase}." unless valid
  end

  def valid_birthdate?
    @value.match?(/\A\d{4}-\d{2}-\d{2}\z/) && Date.iso8601(@value) <= @clinic.local_date(@now)
  rescue Date::Error
    false
  end

  def replay(action)
    unless action.outcome == "contact_verified" && action.staff == @staff && action.patient_id == @patient.id &&
        action.details.values_at("field", "value") == [ @field, @value ]
      raise WorkflowRejected, "This save identifier already belongs to a different update."
    end

    action
  end
end
