class ReminderRun
  INITIAL_DAYS = 7
  FOLLOW_UP_DAYS = 3
  SEND_HOURS = 10...18
  STAFF_FOLLOW_UP = 48.hours

  def initialize(clinic, now: nil, messenger: FakeMessenger.new)
    @clinic = clinic
    @fixed_time = now
    @messenger = messenger
  end

  def call
    @result = { delivered: 0, failed: 0, held: 0 }
    @pending_attempts = []
    @clinic.with_lock do
      @now = @fixed_time || Time.current
      @local_now = @now.in_time_zone(@clinic.zone)
      PmsRefresh.new(@clinic, @now).call
      visits = eligible_visits
      load_reminder_context(visits)
      visits.each { |visit| process(visit) }
      persist_attempts
    end
    @result
  end

  private

  def eligible_visits
    first_day = @local_now.to_date
    window = @clinic.wall_midnight(first_day)...@clinic.wall_midnight(first_day + INITIAL_DAYS + 1)
    candidates = @clinic.visits.scheduled.where(response: "unconfirmed", wall_time: window)
    candidates.where("starts_at > ?", @now)
      .or(candidates.where(starts_at: nil)).includes(:patient).order(:id).to_a
  end

  def load_reminder_context(visits)
    @contacts = ContactDirectory.new(@clinic, visits.map(&:patient).uniq, @local_now.to_date)
    visit_ids = visits.map(&:id)
    @attempts = @clinic.messages.outbound.where(visit_id: visit_ids)
      .pluck(:visit_id, :revision, :step, :channel, :outcome)
      .to_h { |visit_id, revision, step, channel, outcome| [ [ visit_id, revision, step ], [ channel, outcome ] ] }
    @holds = @clinic.work_items.open.where(visit_id: visit_ids, kind: "contact_hold").index_by(&:visit_id)
    @no_replies = @clinic.work_items.where(visit_id: visit_ids, kind: "no_reply").pluck(:visit_id, :revision).to_set
  end

  def process(visit)
    patient = visit.patient
    channels = %w[sms email].select { |channel| @contacts.address_available?(patient, channel) }
    reason = contact_hold(visit, channels)
    if reason
      @result[:held] += 1
      hold = @holds[visit.id]
      if hold&.revision == visit.revision
        hold.update!(reason: reason) if hold.reason != reason
      else
        WorkItem.record_visit_issue(visit, "contact_hold", reason)
      end
      return
    end

    @holds[visit.id]&.update!(resolved_at: @now)
    if visit.starts_at <= @now + STAFF_FOLLOW_UP && !@no_replies.include?([ visit.id, visit.revision ])
      WorkItem.record_visit_issue(visit, "no_reply", "No confirmation within 48 hours of the visit.")
    end
    return unless SEND_HOURS.cover?(@local_now.hour)

    send_due_reminder(visit, channels)
  end

  def contact_hold(visit, channels)
    return "Appointment time is ambiguous in the clinic timezone." if visit.starts_at.nil?

    @contacts.hold_reason(visit.patient) ||
      ("No usable, unshared, permitted contact channel." if channels.empty?)
  end

  def send_due_reminder(visit, channels)
    days_ahead = (visit.wall_time.to_date - @local_now.to_date).to_i
    step = days_ahead > FOLLOW_UP_DAYS ? "initial" : "follow_up"
    earlier = @attempts[[ visit.id, visit.revision, "initial" ]]
    key = [ visit.id, visit.revision, step ]
    if !@attempts.key?(key)
      channel = step == "follow_up" && earlier&.first == "sms" && channels.include?("email") ? "email" : channels.first
      @attempts[key] = [ channel, deliver(visit, channel, step) ]
    end

    backup_key = [ visit.id, visit.revision, "#{step}_backup" ]
    if @attempts[key] == [ "sms", "failed" ] && channels.include?("email") && !@attempts.key?(backup_key)
      deliver(visit, "email", "#{step}_backup")
    end
  end

  def deliver(visit, channel, step)
    sent_at = @fixed_time || Time.current
    return unless sent_at < visit.starts_at && SEND_HOURS.cover?(sent_at.in_time_zone(@clinic.zone).hour)

    address = @contacts.address(visit.patient, channel)
    body = reminder_text(visit, channel)
    result = @messenger.deliver(channel: channel, address: address, body: body)
    @pending_attempts << {
      visit_id: visit.id, patient_id: visit.patient_id, revision: visit.revision,
      channel: channel, address: address, body: body, outcome: result.outcome, step: step,
      created_at: sent_at, updated_at: Time.current
    }
    if result.outcome == "failed"
      WorkItem.record_visit_issue(visit, "delivery_failed", "A simulated #{channel.upcase} reminder failed.")
    end
    @result[result.outcome.to_sym] += 1
    result.outcome
  end

  def persist_attempts
    return if @pending_attempts.empty?

    @clinic.messages.outbound.insert_all!(@pending_attempts, returning: false, record_timestamps: false)
  end

  def reminder_text(visit, channel)
    local_time = visit.wall_time.strftime("%Y-%m-%d %H:%M")
    if @contacts.language(visit.patient) == "es"
      body = "Cita en #{@clinic.clinic.name}: #{local_time} (hora local). Responda SÍ para confirmar o NO si necesita ayuda."
      body += " Responda STOP para dejar de recibir mensajes." if channel == "sms"
    else
      body = "Appointment at #{@clinic.clinic.name}: #{local_time} (local time). Reply YES to confirm or NO for help."
      body += " Reply STOP to opt out." if channel == "sms"
    end
    body
  end
end
