class InboundReply
  CHANNELS = %w[sms email].freeze
  COMMANDS = { "YES" => "confirm", "SI" => "confirm", "SÍ" => "confirm", "NO" => "help" }.freeze
  REPLY_HISTORY = 30.days

  def initialize(clinic, patient:, channel:, body:, event_id:, reply_to_id: nil, now: Time.current)
    @clinic = clinic
    @patient = patient
    @channel = channel
    @body = body.to_s.strip
    @event_id = event_id.to_s
    @reply_to_id = reply_to_id
    @now = now
  end

  def call
    validate_input
    @clinic.with_lock do
      existing = @clinic.messages.inbound.find_by(external_id: @event_id)
      next replay(existing) if existing

      contacts = ContactDirectory.new(@clinic, [ @patient.reload ], @clinic.local_date(@now))
      delivery = reply_to_delivery
      sender = delivery ? delivery.address : contacts.address(@patient, @channel)
      raise WorkflowRejected, "There is no usable address for this channel." unless sender

      if @body.upcase == "STOP"
        @clinic.opt_outs.find_or_create_by!(channel: @channel, address: sender)
        next record(sender, "opted_out")
      end

      history = @clinic.messages.outbound.delivered.where(channel: @channel, address: sender, created_at: (@now - REPLY_HISTORY)..@now)
        .distinct.pluck(:visit_id, :revision, :patient_id)
      visit = current_match(history, contacts, delivery)
      if visit && COMMANDS[@body.upcase] == "confirm"
        confirm(sender, visit)
      else
        candidates = delivery ? history + [ [ delivery.visit_id, delivery.revision, delivery.patient_id ] ] : history
        queue_for_review(sender, candidates, contacts, visit)
      end
    end
  end

  private

  def validate_input
    raise WorkflowRejected, "Choose Text messages or Email." unless CHANNELS.include?(@channel)
    raise WorkflowRejected, "Enter a reply between 1 and 500 characters." unless @body.length.between?(1, 500)
    raise WorkflowRejected, "The reply identifier is invalid." unless @event_id.match?(/\A[\w-]{8,100}\z/)
    if @reply_to_id && (!@reply_to_id.is_a?(Integer) || @reply_to_id <= 0)
      raise WorkflowRejected, "Reload the conversation before replying."
    end
  end

  def replay(message)
    unless [ message.patient_id, message.channel, message.body, message.reply_to_id ] ==
        [ @patient.id, @channel, @body, @reply_to_id ]
      raise WorkflowRejected, "This reply identifier already belongs to a different message."
    end

    message
  end

  def reply_to_delivery
    deliveries = @clinic.messages.outbound.delivered.where(patient_id: @patient.id, channel: @channel)
    if @reply_to_id
      delivery = deliveries.find_by(id: @reply_to_id)
      return delivery if delivery
    elsif !deliveries.exists?
      return
    end

    raise WorkflowRejected, "Reload the conversation before replying."
  end

  def current_match(history, contacts, delivery)
    return unless delivery && history == [ [ delivery.visit_id, delivery.revision, @patient.id ] ]
    return unless contacts.address(@patient, @channel) == delivery.address &&
      contacts.hold_reason(@patient).nil? && contacts.address_available?(@patient, @channel)

    visit_id, revision, patient_id = history.first
    return unless patient_id == @patient.id

    visit = @clinic.visits.find_by(id: visit_id, patient_id: patient_id, revision: revision)
    return unless visit&.accepts_response?(@now)

    appointment = Pms::Appointment.find_by(id: visit.appointment_id)
    visit if visit.matches_replica?(appointment)
  end

  def confirm(sender, visit)
    message = record(sender, "confirmed", visit: visit)
    if visit.response != "confirmed"
      visit.update!(response: "confirmed", responded_at: @now)
      visit.work_items.open.where(revision: visit.revision, kind: "no_reply")
        .update_all(resolved_at: @now, updated_at: @now)
    end
    message
  end

  def queue_for_review(sender, history, contacts, visit)
    candidates = history.group_by(&:first).transform_values { |entries| entries.map(&:second).max }
    if contacts.shared?(@patient, @channel)
      owners = contacts.owner_ids(@patient, @channel)
      shared_visits = @clinic.visits.scheduled.where(patient_id: owners, starts_at: @now..)
        .order(:starts_at, :id).limit(40).pluck(:id, :revision)
      candidates.merge!(shared_visits.to_h)
    end

    reason =
      if contacts.shared?(@patient, @channel)
        "The sender address is shared. Verify the intended visit."
      elsif visit && COMMANDS[@body.upcase] == "help"
        "The patient asked for help. Check before changing the visit."
      elsif visit
        "The reply could not be interpreted as a confirmation."
      else
        "The reply could not be matched to one current eligible visit."
      end

    message = record(sender, "needs_review", visit: visit, candidates: candidates)
    @clinic.work_items.create!(key: "reply:#{message.id}", kind: "reply_review", reason: reason,
      message: message, visit: visit, revision: visit&.revision, patient_id: @patient.id)
    message
  end

  def record(sender, outcome, visit: nil, candidates: {})
    @clinic.messages.create!(visit: visit, patient_id: @patient.id, revision: visit&.revision,
      channel: @channel, address: sender, body: @body, direction: "inbound", external_id: @event_id,
      outcome: outcome, candidate_ids: candidates.keys, candidate_revisions: candidates,
      reply_to_id: @reply_to_id, created_at: @now)
  end
end
