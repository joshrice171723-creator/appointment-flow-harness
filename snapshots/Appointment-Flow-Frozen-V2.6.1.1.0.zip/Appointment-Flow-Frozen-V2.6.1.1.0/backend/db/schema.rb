# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_11_16_000005) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "appointments", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "clinic_id", null: false
    t.text "provider_name"
    t.datetime "start_at", null: false
    t.integer "length_minutes"
    t.text "procedure_note"
    t.text "status", null: false
    t.datetime "updated_at"
    t.index ["clinic_id", "start_at"], name: "index_appointments_on_clinic_id_and_start_at"
    t.index ["clinic_id"], name: "index_appointments_on_clinic_id"
    t.index ["patient_id"], name: "index_appointments_on_patient_id"
  end

  create_table "clinic_settings", force: :cascade do |t|
    t.string "timezone", null: false
    t.datetime "last_synced_at"
  end

  create_table "clinics", force: :cascade do |t|
    t.text "name", null: false
    t.text "address_line"
    t.text "city"
    t.string "state", limit: 2
    t.text "phone"
  end

  create_table "contact_verifications", force: :cascade do |t|
    t.bigint "clinic_setting_id", null: false
    t.bigint "patient_id", null: false
    t.jsonb "fields", default: {}, null: false
    t.string "verified_phone"
    t.string "verified_email"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["clinic_setting_id", "patient_id"], name: "idx_on_clinic_setting_id_patient_id_38f9a96d55", unique: true
    t.index ["clinic_setting_id"], name: "index_contact_verifications_on_clinic_setting_id"
    t.index ["verified_email"], name: "index_contact_verifications_on_verified_email"
    t.index ["verified_phone"], name: "index_contact_verifications_on_verified_phone"
  end

  create_table "messages", force: :cascade do |t|
    t.bigint "clinic_setting_id", null: false
    t.bigint "visit_id"
    t.bigint "patient_id"
    t.integer "revision"
    t.string "channel", null: false
    t.string "direction", null: false
    t.string "address", null: false
    t.text "body", null: false
    t.string "outcome", null: false
    t.string "step"
    t.string "external_id"
    t.bigint "candidate_ids", default: [], null: false, array: true
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.jsonb "candidate_revisions", default: {}, null: false
    t.bigint "reply_to_id"
    t.index ["clinic_setting_id", "channel", "address", "created_at"], name: "index_messages_on_reply_address"
    t.index ["clinic_setting_id", "external_id"], name: "index_messages_on_clinic_setting_id_and_external_id", unique: true, where: "((direction)::text = 'inbound'::text)"
    t.index ["clinic_setting_id", "patient_id", "channel", "created_at"], name: "index_messages_for_inbox"
    t.index ["clinic_setting_id"], name: "index_messages_on_clinic_setting_id"
    t.index ["visit_id", "revision", "step"], name: "index_messages_on_visit_id_and_revision_and_step", unique: true, where: "((direction)::text = 'outbound'::text)"
    t.index ["visit_id"], name: "index_messages_on_visit_id"
  end

  create_table "opt_outs", force: :cascade do |t|
    t.bigint "clinic_setting_id", null: false
    t.string "channel", null: false
    t.string "address", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["clinic_setting_id", "channel", "address"], name: "index_opt_outs_on_clinic_setting_id_and_channel_and_address", unique: true
    t.index ["clinic_setting_id"], name: "index_opt_outs_on_clinic_setting_id"
  end

  create_table "patients", force: :cascade do |t|
    t.text "first_name", null: false
    t.text "last_name", null: false
    t.date "birthdate"
    t.text "wireless_phone"
    t.text "email"
    t.text "preferred_language"
    t.bigint "guarantor_id"
    t.index "\"right\"(regexp_replace(wireless_phone, '[^0-9]'::text, ''::text, 'g'::text), 10)", name: "patients_normalized_phone"
    t.index "lower(regexp_replace(email, '^[[:space:]]+|[[:space:]]+$'::text, ''::text, 'g'::text))", name: "patients_normalized_email"
    t.index ["guarantor_id"], name: "index_patients_on_guarantor_id"
  end

  create_table "staff_actions", force: :cascade do |t|
    t.bigint "clinic_setting_id", null: false
    t.bigint "work_item_id"
    t.bigint "patient_id"
    t.string "staff", null: false
    t.string "outcome", null: false
    t.text "note", null: false
    t.string "request_key", null: false
    t.bigint "target_ids", default: [], null: false, array: true
    t.jsonb "details", default: {}, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["clinic_setting_id", "patient_id", "created_at"], name: "idx_on_clinic_setting_id_patient_id_created_at_969f1b3198"
    t.index ["clinic_setting_id", "request_key"], name: "index_staff_actions_on_clinic_setting_id_and_request_key", unique: true
    t.index ["clinic_setting_id"], name: "index_staff_actions_on_clinic_setting_id"
    t.index ["work_item_id"], name: "index_staff_actions_on_work_item_id"
  end

  create_table "visits", force: :cascade do |t|
    t.bigint "appointment_id", null: false
    t.bigint "clinic_setting_id", null: false
    t.bigint "patient_id", null: false
    t.string "provider_name"
    t.integer "length_minutes"
    t.datetime "wall_time", null: false
    t.datetime "starts_at"
    t.string "source_status", null: false
    t.integer "revision", default: 1, null: false
    t.string "response", default: "unconfirmed", null: false
    t.datetime "responded_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["clinic_setting_id", "appointment_id"], name: "index_visits_on_clinic_setting_id_and_appointment_id", unique: true
    t.index ["clinic_setting_id", "patient_id", "wall_time"], name: "index_visits_on_clinic_setting_id_and_patient_id_and_wall_time"
    t.index ["clinic_setting_id", "source_status", "starts_at"], name: "idx_on_clinic_setting_id_source_status_starts_at_4c370775e0"
    t.index ["clinic_setting_id", "wall_time"], name: "index_visits_on_clinic_setting_id_and_wall_time"
    t.index ["clinic_setting_id"], name: "index_visits_on_clinic_setting_id"
  end

  create_table "work_items", force: :cascade do |t|
    t.bigint "clinic_setting_id", null: false
    t.bigint "visit_id"
    t.bigint "message_id"
    t.bigint "patient_id"
    t.integer "revision"
    t.string "key", null: false
    t.string "kind", null: false
    t.string "reason", null: false
    t.string "assignee"
    t.datetime "resolved_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["clinic_setting_id", "key"], name: "index_work_items_on_clinic_setting_id_and_key", unique: true
    t.index ["clinic_setting_id", "patient_id"], name: "index_work_items_on_clinic_setting_id_and_patient_id"
    t.index ["clinic_setting_id", "resolved_at", "kind"], name: "index_work_items_on_clinic_setting_id_and_resolved_at_and_kind"
    t.index ["clinic_setting_id"], name: "index_work_items_on_clinic_setting_id"
    t.index ["message_id"], name: "index_work_items_on_message_id"
    t.index ["visit_id"], name: "index_work_items_on_visit_id"
  end

  add_foreign_key "appointments", "clinics"
  add_foreign_key "appointments", "patients"
  add_foreign_key "contact_verifications", "clinic_settings"
  add_foreign_key "messages", "clinic_settings"
  add_foreign_key "messages", "messages", column: "reply_to_id"
  add_foreign_key "messages", "visits"
  add_foreign_key "opt_outs", "clinic_settings"
  add_foreign_key "patients", "patients", column: "guarantor_id"
  add_foreign_key "staff_actions", "clinic_settings"
  add_foreign_key "staff_actions", "work_items"
  add_foreign_key "visits", "clinic_settings"
  add_foreign_key "work_items", "clinic_settings"
  add_foreign_key "work_items", "messages"
  add_foreign_key "work_items", "visits"
end
