if Rails.env.development?
  # A writable side of the synthetic replica for local provisioning only.
  module DemoReplica
    class Clinics < ApplicationRecord
      self.table_name = "clinics"
    end

    class Patients < ApplicationRecord
      self.table_name = "patients"
    end

    class Appointments < ApplicationRecord
      self.table_name = "appointments"
    end
  end

  ClinicSetting.find_or_create_by!(id: 1) { |setting| setting.timezone = "America/Chicago" }
  ClinicSetting.find_or_create_by!(id: 2) { |setting| setting.timezone = "America/Phoenix" }
  DemoReplica::Clinics.upsert_all([
    { id: 1, name: "Austin", city: "Austin", state: "TX", phone: "5125550100" },
    { id: 2, name: "Phoenix", city: "Phoenix", state: "AZ", phone: "6025550100" }
  ], record_timestamps: false)

  names = [
    [ "Amelia", "Rivera" ], [ "Noah", "Bennett" ], [ "Olivia", "Hayes" ],
    [ "Mateo", "Cruz" ], [ "Sofia", "Reed" ], [ "Ethan", "Blake" ],
    [ "Isla", "Foster" ], [ "Lucas", "Grant" ], [ "Mia", "Ellis" ],
    [ "Leo", "Brooks" ], [ "Ava", "Lane" ], [ "Sam", "Parker" ],
    [ "Nina", "Mills" ], [ "Theo", "Stone" ], [ "Ruby", "Hart" ],
    [ "Owen", "West" ], [ "Luna", "James" ], [ "Ivy", "Scott" ],
    [ "Eli", "Cole" ], [ "Zoe", "Ford" ]
  ]

  ClinicSetting.find_each do |clinic|
    local_now = Time.current.in_time_zone(clinic.zone)
    seed_day = local_now.hour < ReminderRun::SEND_HOURS.begin ? local_now.to_date - 1 : local_now.to_date
    seed_clock = if ReminderRun::SEND_HOURS.cover?(local_now.hour)
      local_now
    else
      clinic.zone.local(seed_day.year, seed_day.month, seed_day.day, ReminderRun::SEND_HOURS.end - 1)
    end
    today = seed_clock.to_date
    area_code = clinic.id == 1 ? "512" : "602"
    patients = names.each_with_index.map do |(first_name, last_name), index|
      id = clinic.id * 100 + index + 1
      phone = "#{area_code}555#{format('%04d', 101 + index)}"
      email = "#{first_name.downcase}.#{last_name.downcase}.#{clinic.id}@example.test"
      birthdate = Date.new(1983 + index, (index % 12) + 1, 9)
      phone = nil if index == 1 || index == 2
      email = nil if index == 2 || index.in?([ 7, 8 ])
      phone = "#{area_code}5550199" if index == 4
      birthdate = today.years_ago(12) if index == 6
      phone = "#{area_code}5550130" if index.in?([ 7, 8 ])
      language = index == 3 ? "es" : "en"
      language = "fr" if index == 9
      { id: id, first_name: first_name, last_name: last_name, email: email, birthdate: birthdate,
        wireless_phone: phone, preferred_language: language }
    end
    DemoReplica::Patients.upsert_all(patients)

    upcoming = [ 7, 7, 0, 1, 3, 0, 1, 2, 2, 1, 0, 1, 2, 3, 4, 4, 5, 6, 8, 9 ]
    appointments = patients.each_with_index.map do |patient, index|
      date = today + upcoming.fetch(index)
      { id: patient.fetch(:id) * 100, patient_id: patient.fetch(:id), clinic_id: clinic.id,
        provider_name: index.even? ? "Dr. Morgan" : "Dr. Chen",
        start_at: Time.utc(date.year, date.month, date.day, 13 + index % 4, index.even? ? 0 : 30),
        length_minutes: index.even? ? 45 : 30, status: "scheduled", updated_at: Time.current }
    end
    history = 65.times.map do |index|
      patient = patients[index % patients.size]
      date = today - index - 1
      status = if (index + clinic.id) % 13 == 0
        "broken"
      elsif (index + clinic.id) % 17 == 0
        "unscheduled"
      else
        "complete"
      end
      { id: clinic.id * 100_000 + index, patient_id: patient.fetch(:id), clinic_id: clinic.id,
        provider_name: "Dr. Morgan", start_at: Time.utc(date.year, date.month, date.day, 13),
        length_minutes: 45, status: status, updated_at: Time.current }
    end
    DemoReplica::Appointments.upsert_all(appointments + history)

    ReminderRun.new(clinic, now: seed_clock).call
    [
      [ 4, "confirmed", "Patient confirmed by phone." ],
      [ 12, "attempted", "Left a callback request." ]
    ].each do |patient_number, outcome, note|
      patient_id = clinic.id * 100 + patient_number
      item = clinic.work_items.open.find_by(patient_id: patient_id, kind: "no_reply")
      next unless item

      StaffFollowUp.new(clinic, item: item, staff: clinic.staff_names.first, outcome: outcome, note: note,
        request_key: "seed-#{outcome}-#{seed_day}", now: seed_clock).call
    end
  end
  puts "Seeded Austin and Phoenix with fictional patients and simulated reminder history."
end
