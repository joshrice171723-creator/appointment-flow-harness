class CreateConfirmationRecords < ActiveRecord::Migration[8.1]
  def change
    create_table :clinic_settings, id: false do |t|
      t.bigint :id, primary_key: true
      t.string :timezone, null: false
      t.datetime :last_synced_at
    end

    create_table :visits do |t|
      t.bigint :appointment_id, null: false
      t.references :clinic_setting, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.string :provider_name
      t.integer :length_minutes
      t.datetime :wall_time, null: false
      t.datetime :starts_at
      t.string :source_status, null: false
      t.integer :revision, null: false, default: 1
      t.string :response, default: "unconfirmed", null: false
      t.datetime :responded_at
      t.timestamps
      t.index [ :clinic_setting_id, :appointment_id ], unique: true
      t.index [ :clinic_setting_id, :wall_time ]
      t.index [ :clinic_setting_id, :patient_id, :wall_time ]
      t.index [ :clinic_setting_id, :source_status, :starts_at ]
    end

    create_table :contact_verifications do |t|
      t.references :clinic_setting, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.jsonb :fields, null: false, default: {}
      t.string :verified_phone
      t.string :verified_email
      t.timestamps
      t.index [ :clinic_setting_id, :patient_id ], unique: true
      t.index :verified_phone
      t.index :verified_email
    end

    create_table :messages do |t|
      t.references :clinic_setting, null: false, foreign_key: true
      t.references :visit, foreign_key: true
      t.bigint :patient_id
      t.integer :revision
      t.string :channel, null: false
      t.string :direction, null: false
      t.string :address, null: false
      t.text :body, null: false
      t.string :outcome, null: false
      t.string :step
      t.string :external_id
      t.bigint :candidate_ids, array: true, null: false, default: []
      t.timestamps
      t.index [ :visit_id, :revision, :step ], unique: true, where: "direction = 'outbound'"
      t.index [ :clinic_setting_id, :external_id ], unique: true, where: "direction = 'inbound'"
      t.index [ :clinic_setting_id, :channel, :address, :created_at ], name: "index_messages_on_reply_address"
      t.index [ :clinic_setting_id, :patient_id, :channel, :created_at ], name: "index_messages_for_inbox"
    end

    create_table :opt_outs do |t|
      t.references :clinic_setting, null: false, foreign_key: true
      t.string :channel, null: false
      t.string :address, null: false
      t.timestamps
      t.index [ :clinic_setting_id, :channel, :address ], unique: true
    end

    create_table :work_items do |t|
      t.references :clinic_setting, null: false, foreign_key: true
      t.references :visit, foreign_key: true
      t.references :message, foreign_key: true
      t.bigint :patient_id
      t.integer :revision
      t.string :key, null: false
      t.string :kind, null: false
      t.string :reason, null: false
      t.string :assignee
      t.datetime :resolved_at
      t.timestamps
      t.index [ :clinic_setting_id, :key ], unique: true
      t.index [ :clinic_setting_id, :resolved_at, :kind ]
      t.index [ :clinic_setting_id, :patient_id ]
    end

    create_table :staff_actions do |t|
      t.references :clinic_setting, null: false, foreign_key: true
      t.references :work_item, foreign_key: true
      t.bigint :patient_id
      t.string :staff, null: false
      t.string :outcome, null: false
      t.text :note, null: false
      t.string :request_key, null: false
      t.bigint :target_ids, array: true, null: false, default: []
      t.jsonb :details, null: false, default: {}
      t.timestamps
      t.index [ :clinic_setting_id, :request_key ], unique: true
      t.index [ :clinic_setting_id, :patient_id, :created_at ]
    end
  end
end
