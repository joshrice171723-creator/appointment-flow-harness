class RecordReplyCandidateRevisions < ActiveRecord::Migration[8.1]
  def change
    add_column :messages, :candidate_revisions, :jsonb, default: {}, null: false
  end
end
