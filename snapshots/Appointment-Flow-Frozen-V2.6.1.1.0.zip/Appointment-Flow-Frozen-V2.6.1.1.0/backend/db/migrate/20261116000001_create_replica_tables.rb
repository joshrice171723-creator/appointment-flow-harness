class CreateReplicaTables < ActiveRecord::Migration[8.1]
  def change
    create_table :clinics do |t|
      t.text :name, null: false
      t.text :address_line
      t.text :city
      t.column :state, "char(2)"
      t.text :phone
    end

    create_table :patients do |t|
      t.text :first_name, null: false
      t.text :last_name, null: false
      t.date :birthdate
      t.text :wireless_phone
      t.text :email
      t.text :preferred_language
      t.references :guarantor, foreign_key: { to_table: :patients }
    end

    create_table :appointments do |t|
      t.references :patient, null: false, foreign_key: true
      t.references :clinic, null: false, foreign_key: true
      t.text :provider_name
      t.datetime :start_at, null: false
      t.integer :length_minutes
      t.text :procedure_note
      t.text :status, null: false
      t.datetime :updated_at
      t.index [ :clinic_id, :start_at ]
    end

    reversible do |migration|
      migration.up do
        execute <<~SQL
          CREATE INDEX patients_normalized_email ON patients (lower(btrim(email)));
          CREATE INDEX patients_normalized_phone ON patients (
            right(regexp_replace(wireless_phone, '[^0-9]', '', 'g'), 10)
          );
        SQL
      end
    end
  end
end
