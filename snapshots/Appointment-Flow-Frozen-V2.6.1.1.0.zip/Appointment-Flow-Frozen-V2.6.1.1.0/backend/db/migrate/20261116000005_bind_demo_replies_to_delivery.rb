class BindDemoRepliesToDelivery < ActiveRecord::Migration[8.1]
  def change
    add_reference :messages, :reply_to, foreign_key: { to_table: :messages }, index: false
  end
end
