class MatchEmailContactWhitespace < ActiveRecord::Migration[8.1]
  def change
    remove_index :patients, "lower(btrim(email))", name: "patients_normalized_email"
    add_index :patients, "lower(regexp_replace(email, '^[[:space:]]+|[[:space:]]+$', '', 'g'))",
      name: "patients_normalized_email"
  end
end
