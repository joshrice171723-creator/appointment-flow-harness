Rails.application.config.filter_parameters += [
  :authorization, :token, :body, :note, :email, :mobile, :wireless_phone, :birthdate, :sender, :recipient, :value, :q
]
