Rails.application.routes.draw do
  get "up" => "rails/health#show", as: :rails_health_check

  scope :api do
    resources :clinics, only: :index, controller: "demo_catalog"
    resource :staff_session, only: :create

    scope "staff/:clinic_id" do
      resources :reminder_runs, only: :create
      resources :appointments, only: :index, controller: "staff_appointments"
      resources :work_items, only: [ :index, :show, :update ], controller: "staff_work_items" do
        resources :follow_ups, only: :create, controller: "staff_follow_ups"
      end
      resources :patients, only: :show, controller: "staff_patients" do
        resources :contact_verifications, only: :update
      end
    end

    scope "demo/:clinic_id" do
      resources :inboxes, only: [ :index, :show ], controller: "demo_inboxes" do
        resources :replies, only: :create, controller: "demo_replies"
      end
    end

    resource :leadership_report, only: :show
  end
end
