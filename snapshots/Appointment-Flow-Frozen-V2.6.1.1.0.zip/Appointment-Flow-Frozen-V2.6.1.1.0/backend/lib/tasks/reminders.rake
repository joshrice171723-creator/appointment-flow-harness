namespace :reminders do
  desc "Refresh the local replica views and run fake reminders for each configured clinic"
  task run: :environment do
    failed = false
    ClinicSetting.includes(:clinic).find_each do |clinic|
      next unless clinic.clinic

      result = ReminderRun.new(clinic).call
      puts "#{clinic.clinic.name}: #{result.inspect}"
    rescue PmsRefresh::Unavailable => error
      warn "Clinic #{clinic.id}: #{error.message}"
      failed = true
    end
    abort "One or more clinic refreshes failed." if failed
  end
end
