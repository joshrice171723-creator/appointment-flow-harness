require "test_helper"

class ReminderConcurrencyTest < ActiveSupport::TestCase
  include ReplicaFixture
  self.use_transactional_tests = false

  test "two database connections cannot claim the same clinic reminder" do
    test_clinic_id = 3
    test_patient_id = 303
    clinic = create_clinic(test_clinic_id)
    patient = create_patient(id: test_patient_id, wireless_phone: "5125550188")
    create_visit(clinic, id: test_patient_id, patient: patient)
    gate = Queue.new
    now = Time.utc(2026, 11, 16, 17)
    runs = 2.times.map do
      Thread.new do
        gate.pop
        ApplicationRecord.with_connection do
          ReminderRun.new(ClinicSetting.find(test_clinic_id), now: now).call
        end
      end
    end
    2.times { gate << true }

    assert_equal [ 0, 1 ], runs.map { |thread| thread.value.fetch(:delivered) }.sort
    assert_equal "delivered", clinic.messages.sole.outcome
  ensure
    if clinic
      WorkItem.where(clinic_setting_id: test_clinic_id).delete_all
      Message.where(clinic_setting_id: test_clinic_id).delete_all
      Visit.where(clinic_setting_id: test_clinic_id).delete_all
      ReplicaFixture::Appointment.where(clinic_id: test_clinic_id).delete_all
      ReplicaFixture::Patient.where(id: test_patient_id).delete_all
      clinic.destroy!
      ReplicaFixture::Clinic.find(test_clinic_id).destroy!
    end
  end
end
