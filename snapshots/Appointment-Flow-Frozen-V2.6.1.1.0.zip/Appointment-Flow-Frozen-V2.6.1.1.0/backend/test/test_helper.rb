ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"

module ReplicaFixture
  class Clinic < ApplicationRecord
    self.table_name = "clinics"
  end

  class Patient < ApplicationRecord
    self.table_name = "patients"
  end

  class Appointment < ApplicationRecord
    self.table_name = "appointments"
  end

  def create_clinic(id = 1)
    ReplicaFixture::Clinic.create!(id: id, name: id == 1 ? "Austin" : "Phoenix")
    ClinicSetting.find_or_create_by!(id: id) do |clinic|
      clinic.timezone = id == 1 ? "America/Chicago" : "America/Phoenix"
    end
  end

  def create_visit(clinic, id: 101, on: Date.new(2026, 11, 23), hour: 13, patient: nil, **attributes)
    patient ||= create_patient(id: id)
    ReplicaFixture::Appointment.create!(id: id, clinic_id: clinic.id, patient_id: patient.id,
      start_at: Time.utc(on.year, on.month, on.day, hour), provider_name: "Dr. Morgan", length_minutes: 45,
      status: "scheduled", **attributes)
  end

  def create_patient(id: 101, **attributes)
    ReplicaFixture::Patient.create!({
      id: id, first_name: "Demo", last_name: "Patient #{id}", birthdate: "1992-09-20",
      wireless_phone: "5125550#{id.to_s.last(3)}", email: "patient#{id}@example.test", preferred_language: "en"
    }.merge(attributes))
  end

  def staff_headers(clinic)
    post "/api/staff_session", params: { clinic_id: clinic.id, staff: clinic.staff_names.first }, as: :json
    { "Authorization" => "Bearer #{response.parsed_body.fetch('token')}" }
  end
end
