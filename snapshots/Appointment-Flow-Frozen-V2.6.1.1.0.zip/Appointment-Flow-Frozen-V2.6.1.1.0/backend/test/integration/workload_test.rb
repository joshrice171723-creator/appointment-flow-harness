require "test_helper"
require_relative "../../../quality/rails_workload_probe"

class WorkloadTest < ActionDispatch::IntegrationTest
  include ReplicaFixture

  NOW = Time.utc(2026, 11, 16, 17)
  VISIT_DAY = NOW.to_date + 7

  setup do
    @clinic = create_clinic
    create_visit(@clinic)
    travel_to NOW
  end

  test "normal appointment reads and reminder runs with unrelated and eligible growth" do
    headers = staff_headers(@clinic)
    measured_batch(headers, "small first run", delivered: 1)
    before_growth = measured_batch(headers, "small retry", delivered: 0)
    original = measured_calendar(headers, "small calendar")

    insert_unrelated_visits
    measured_batch(headers, "import unrelated upcoming visits", delivered: 0)
    after_growth = measured_batch(headers, "retry with 1,200 unrelated upcoming visits", delivered: 0)
    assert_equal before_growth.values_at(:read_rows, :instantiated_records),
      after_growth.values_at(:read_rows, :instantiated_records)
    assert_equal original, measured_calendar(headers, "calendar with 1,200 unrelated upcoming visits")

    insert_eligible_visits
    measured_batch(headers, "40 additional eligible visits", delivered: 40)
    measured_batch(headers, "retry after 40 additional eligible visits", delivered: 0)
    assert_equal 41, @clinic.messages.outbound.count
    assert_equal 41, measured_calendar(headers, "calendar with 40 additional eligible visits").size
    print_query_plans(headers) if ENV["APEX_WORKLOAD"]
  end

  test "24 successful reminders preserve the outbound audit and replay without writes" do
    insert_eligible_visits(23)
    headers = staff_headers(@clinic)

    metrics = measured_batch(headers, "24 successful reminders", delivered: 24)
    assert_equal({ "delivered" => 24, "failed" => 0, "held" => 0 }, response.parsed_body)
    assert_equal 3, metrics.fetch(:direct_write_statements)
    assert_equal 49, metrics.fetch(:affected_rows)

    visits = @clinic.visits.order(:id).to_a
    attempts = @clinic.messages.outbound.order(:id).map(&:attributes)
    assert_equal 24, visits.size
    assert_equal visits.map { |visit| expected_initial_attempt(visit) }, attempts.map { |row| row.except("id") }

    retry_metrics = measured_batch(headers, "retry after 24 successful reminders", delivered: 0)
    assert_equal({ "delivered" => 0, "failed" => 0, "held" => 0 }, response.parsed_body)
    assert_equal 0, retry_metrics.fetch(:direct_write_statements)
    assert_equal attempts, @clinic.messages.outbound.order(:id).map(&:attributes)
  end

  test "leadership groups clinic-local month activity with a fixed number of queries" do
    phoenix = create_clinic(2)
    month_boundary = Time.utc(2026, 11, 1, 6, 30)
    [ @clinic, phoenix ].each do |clinic|
      clinic.staff_actions.create!(staff: clinic.staff_names.first, outcome: "attempted",
        note: "Called to confirm.", request_key: "report-fixture", created_at: month_boundary)
    end

    measured_report("leadership warm-up")
    first_metrics, original = measured_report("leadership with 2 clinics")
    assert_equal [ 1, 0 ], original.map { |clinic| clinic.fetch("work").fetch("attempted") }

    ids = (3..60).to_a
    ReplicaFixture::Clinic.insert_all!(ids.map { |id| { id: id, name: "Fixture Clinic #{id}" } })
    ClinicSetting.insert_all!(ids.map { |id| { id: id, timezone: id.odd? ? @clinic.timezone : phoenix.timezone } })

    expanded_metrics, expanded = measured_report("leadership with 60 clinics")
    assert_equal first_metrics.fetch(:read_statements), expanded_metrics.fetch(:read_statements)
    assert_equal 60, expanded.size
    assert_equal original, expanded.first(2)
  end

  private

  def measured_batch(headers, label, delivered:)
    _, metrics = RailsWorkloadProbe.measure do
      post "/api/staff/1/reminder_runs", headers: headers
    end
    assert_response :created
    assert_equal delivered, response.parsed_body.fetch("delivered")
    puts "#{label}: #{metrics.to_json}" if ENV["APEX_WORKLOAD"]
    metrics
  end

  def measured_calendar(headers, label)
    _, metrics = RailsWorkloadProbe.measure do
      get "/api/staff/1/appointments", params: { date: VISIT_DAY.iso8601 }, headers: headers
    end
    assert_response :success
    puts "#{label}: #{metrics.to_json}" if ENV["APEX_WORKLOAD"]
    response.parsed_body.fetch("visits")
  end

  def measured_report(label)
    _, metrics = RailsWorkloadProbe.measure do
      ApplicationRecord.uncached { get "/api/leadership_report", params: { month: "2026-11" } }
    end
    assert_response :success
    puts "#{label}: #{metrics.to_json}" if ENV["APEX_WORKLOAD"]
    [ metrics, response.parsed_body.fetch("clinics") ]
  end

  def insert_unrelated_visits
    patients = 120.times.map do |index|
      { id: 2_000 + index, first_name: "Fixture", last_name: "Patient #{index}", birthdate: "1991-05-15" }
    end
    ReplicaFixture::Patient.insert_all!(patients)
    appointments = 1_200.times.map do |index|
      date = VISIT_DAY + 7 + index % 18
      { id: 3_000 + index, clinic_id: @clinic.id, patient_id: patients[index % patients.size].fetch(:id),
        start_at: Time.utc(date.year, date.month, date.day, 9 + index / 18 % 8, index % 4 * 15),
        status: "scheduled", length_minutes: 30 }
    end
    ReplicaFixture::Appointment.insert_all!(appointments)
  end

  def insert_eligible_visits(count = 40)
    count.times do |index|
      create_visit(@clinic, id: 130 + index, on: VISIT_DAY, hour: 9 + index % 8)
    end
  end

  def expected_initial_attempt(visit)
    local_time = visit.wall_time.strftime("%Y-%m-%d %H:%M")
    {
      "clinic_setting_id" => @clinic.id, "visit_id" => visit.id, "patient_id" => visit.patient_id,
      "revision" => 1, "channel" => "sms", "direction" => "outbound", "address" => "5125550#{visit.patient_id}",
      "body" => "Appointment at Austin: #{local_time} (local time). Reply YES to confirm or NO for help. Reply STOP to opt out.",
      "outcome" => "delivered", "step" => "initial", "external_id" => nil,
      "candidate_ids" => [], "candidate_revisions" => {}, "reply_to_id" => nil,
      "created_at" => NOW, "updated_at" => NOW
    }
  end

  def print_query_plans(headers)
    snapshot_sql = nil
    capture = ->(event) do
      sql = event.payload.fetch(:sql)
      snapshot_sql = sql if sql.include?("FULL OUTER JOIN") && sql.include?("IS DISTINCT FROM")
    end
    ActiveSupport::Notifications.subscribed(capture, "sql.active_record") do
      post "/api/staff/1/reminder_runs", headers: headers
    end
    assert_response :created

    start = @clinic.wall_midnight(VISIT_DAY)
    finish = @clinic.wall_midnight(VISIT_DAY + 1)
    calendar_sql = @clinic.visits.where(wall_time: start...finish).order(:wall_time, :id).limit(200).to_sql
    ApplicationRecord.with_connection do |connection|
      puts "Replica comparison plan"
      puts connection.exec_query("EXPLAIN (ANALYZE, BUFFERS) #{snapshot_sql}").rows.flatten
      puts "Calendar row lookup plan"
      puts connection.exec_query("EXPLAIN (ANALYZE, BUFFERS) #{calendar_sql}").rows.flatten
    end
  end
end
