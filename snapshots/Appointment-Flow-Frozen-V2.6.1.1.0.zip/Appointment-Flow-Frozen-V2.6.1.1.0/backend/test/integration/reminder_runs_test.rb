require "test_helper"

class ReminderRunsTest < ActionDispatch::IntegrationTest
  include ReplicaFixture

  NOW = Time.utc(2026, 11, 16, 17)

  setup do
    @clinic = create_clinic
  end

  test "staff can start a clinic-scoped batch and retries keep one attempt per step" do
    other = create_clinic(2)
    create_visit(@clinic)
    create_visit(other, id: 202)
    travel_to NOW do
      headers = staff_headers(@clinic)
      post "/api/staff/1/reminder_runs", headers: headers
      assert_response :created
      assert_equal({ "delivered" => 1, "failed" => 0, "held" => 0 }, response.parsed_body)
      assert_equal "sms", @clinic.messages.sole.channel
      assert_equal "initial", @clinic.messages.sole.step
      assert_includes @clinic.messages.sole.body, "Austin"
      assert_empty other.messages
      assert_no_difference "Message.count" do
        post "/api/staff/1/reminder_runs", headers: headers
      end
      assert_response :created
      post "/api/staff/2/reminder_runs", headers: headers
      assert_response :unauthorized
    end

    assert_difference "Message.count", 1 do
      ReminderRun.new(@clinic, now: NOW + 4.days).call
    end
    assert_equal "email", @clinic.messages.find_by!(step: "follow_up").channel
  end

  test "a failed SMS is recorded once with a single email backup" do
    patient = create_patient(wireless_phone: "5125550199")
    create_visit(@clinic, patient: patient)
    assert_equal({ delivered: 1, failed: 1, held: 0 }, ReminderRun.new(@clinic, now: NOW).call)
    assert_equal({ delivered: 0, failed: 0, held: 0 }, ReminderRun.new(@clinic, now: NOW).call)

    assert_equal [
      [ "initial", "sms", "5125550199", "failed" ],
      [ "initial_backup", "email", patient.email, "delivered" ]
    ], @clinic.messages.order(:id).pluck(:step, :channel, :address, :outcome)
    assert_equal "delivery_failed", @clinic.work_items.sole.kind
  end

  test "does not send before the clinic window or at the appointment" do
    create_visit(@clinic, on: NOW.to_date, hour: 11)
    assert_no_difference "Message.count" do
      ReminderRun.new(@clinic, now: NOW - 2.hours).call
      ReminderRun.new(@clinic, now: NOW).call
    end
  end

  test "a live batch checks the clock again before each send" do
    create_visit(@clinic, on: NOW.to_date, hour: 12)
    create_visit(@clinic, on: NOW.to_date, hour: 12, id: 102)
    advance_clock = -> { travel 2.hours }
    adapter = FakeMessenger.new
    adapter.define_singleton_method(:deliver) do |**message|
      advance_clock.call
      super(**message)
    end

    travel_to NOW do
      assert_equal 1, ReminderRun.new(@clinic, messenger: adapter).call.fetch(:delivered)
    end
    attempt = @clinic.messages.outbound.sole
    assert_equal 101, attempt.patient_id
    assert_equal NOW, attempt.created_at
    assert_equal NOW + 2.hours, attempt.updated_at
  end

  test "failed replica snapshot preserves work and last successful sync" do
    appointment = create_visit(@clinic)
    travel_to NOW do
      headers = staff_headers(@clinic)
      post "/api/staff/1/reminder_runs", headers: headers
      assert_response :created
      appointment.destroy!
      travel 1.day
      headers = staff_headers(@clinic)
      assert_no_difference "Message.count" do
        post "/api/staff/1/reminder_runs", headers: headers
      end
      assert_response :service_unavailable
      assert_equal NOW, @clinic.reload.last_synced_at
      assert_equal appointment.id, @clinic.visits.sole.appointment_id
    end
  end

  test "an unexpected failure after a fake send rolls back the batch and can be retried" do
    create_visit(@clinic)
    create_visit(@clinic, id: 102)
    failing_adapter = Class.new(FakeMessenger) do
      def deliver(**message)
        raise "injected failure" if message.fetch(:address).end_with?("0102")

        super
      end
    end.new

    assert_raises(RuntimeError, "injected failure") do
      ReminderRun.new(@clinic, now: NOW, messenger: failing_adapter).call
    end
    assert_empty @clinic.messages.reload
    assert_empty @clinic.visits.reload
    assert_nil @clinic.reload.last_synced_at
    assert_equal 2, ReminderRun.new(@clinic, now: NOW).call.fetch(:delivered)
  end

  test "a failure after the attempts are written rolls back the attempts and staff work" do
    patient = create_patient(wireless_phone: "5125550199")
    create_visit(@clinic, patient: patient)
    inserted = 0
    fail_after_attempts = lambda do |event|
      next unless event.payload.fetch(:sql).start_with?('INSERT INTO "messages"')

      inserted += event.payload.fetch(:affected_rows)
      raise "injected failure after writing attempts" if inserted == 2
    end

    error = assert_raises(RuntimeError) do
      ActiveSupport::Notifications.subscribed(fail_after_attempts, "sql.active_record") do
        ReminderRun.new(@clinic, now: NOW).call
      end
    end
    assert_equal "injected failure after writing attempts", error.message
    assert_equal 2, inserted
    assert_empty @clinic.messages.reload
    assert_empty @clinic.work_items.reload
    assert_empty @clinic.visits.reload
    assert_nil @clinic.reload.last_synced_at
    assert_equal({ delivered: 1, failed: 1, held: 0 }, ReminderRun.new(@clinic, now: NOW).call)
    assert_equal 2, @clinic.messages.count
    assert_equal "delivery_failed", @clinic.work_items.sole.kind
  end

  test "clinic time explicitly handles DST and year-round Phoenix time" do
    phoenix = create_clinic(2)
    assert_nil @clinic.appointment_instant(Time.utc(2026, 3, 8, 2, 15))
    assert_nil @clinic.appointment_instant(Time.utc(2026, 11, 1, 1, 15))
    assert_equal Time.utc(2026, 7, 1, 17), @clinic.appointment_instant(Time.utc(2026, 7, 1, 12))
    assert_equal Time.utc(2026, 7, 1, 19), phoenix.appointment_instant(Time.utc(2026, 7, 1, 12))
  end
end
