require "test_helper"

class AppointmentWorkflowsTest < ActionDispatch::IntegrationTest
  include ReplicaFixture

  NOW = Time.utc(2026, 11, 16, 17)

  setup do
    @clinic = create_clinic
    travel_to NOW
  end

  test "SMS and email replies confirm the chosen visit and retry records one event" do
    sms_visit = create_visit(@clinic)
    email_patient = create_patient(id: 102, wireless_phone: nil)
    email_visit = create_visit(@clinic, id: 102, patient: email_patient)
    ReminderRun.new(@clinic).call

    reply(sms_visit.patient_id, "sms", "YES", id: "event-sms-1")
    assert_response :created
    assert_equal "confirmed", response.parsed_body.fetch("outcome")
    assert_no_difference "Message.count" do
      reply(sms_visit.patient_id, "sms", "YES", id: "event-sms-1")
    end
    assert_response :created
    reply(email_visit.patient_id, "email", "yes", id: "event-email-1")
    assert_response :created
    assert_equal "confirmed", response.parsed_body.fetch("outcome")
    assert_equal [ "confirmed", "confirmed" ], @clinic.visits.order(:appointment_id).pluck(:response)
    assert_equal [ "scheduled", "scheduled" ], Pms::Appointment.order(:id).pluck(:status)

    travel 4.days
    assert_no_difference "Message.count" do
      ReminderRun.new(@clinic).call
    end
  end

  test "a moved visit rejects an old reply and gets a fresh revision" do
    appointment = create_visit(@clinic)
    ReminderRun.new(@clinic).call
    reply(appointment.patient_id, "sms", "YES", id: "old-time-confirm")
    assert_equal "confirmed", response.parsed_body.fetch("outcome")

    appointment.update!(start_at: appointment.start_at + 1.hour)
    reply(appointment.patient_id, "sms", "YES", id: "old-time-reply")
    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    ReminderRun.new(@clinic).call
    visit = @clinic.visits.sole
    assert_equal 2, visit.revision
    assert_equal "unconfirmed", visit.response
    assert_equal [ 1, 2 ], visit.messages.outbound.order(:id).pluck(:revision)
    reply(appointment.patient_id, "sms", "YES", id: "ambiguous-reply")
    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    assert_equal "unconfirmed", visit.reload.response
  end

  test "a broken and recreated visit does not inherit confirmation" do
    appointment = create_visit(@clinic)
    ReminderRun.new(@clinic).call
    reply(appointment.patient_id, "sms", "YES", id: "visit-confirmed")

    appointment.update!(status: "broken")
    replacement = create_visit(@clinic, id: 202, patient: ReplicaFixture::Patient.find(appointment.patient_id))
    ReminderRun.new(@clinic).call
    reply(appointment.patient_id, "sms", "YES", id: "replacement-reply")

    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    assert_equal "broken", @clinic.visits.find_by!(appointment_id: appointment.id).source_status
    assert_equal "unconfirmed", @clinic.visits.find_by!(appointment_id: replacement.id).response
  end

  test "late replies and conflicting NO are recorded without changing confirmation" do
    appointment = create_visit(@clinic, on: NOW.to_date, hour: 13)
    ReminderRun.new(@clinic).call
    reply(appointment.patient_id, "sms", "YES", id: "early-confirm")
    assert_equal "confirmed", response.parsed_body.fetch("outcome")
    reply(appointment.patient_id, "sms", "NO", id: "conflicting-no")
    assert_equal "needs_review", response.parsed_body.fetch("outcome")

    travel 3.hours
    reply(appointment.patient_id, "sms", "YES", id: "post-start-reply")
    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    assert_equal "confirmed", @clinic.visits.sole.response
    assert_equal 2, @clinic.work_items.open.where(kind: "reply_review").count
  end

  test "exact STOP persists through sync and other STOP variants go to review" do
    appointment = create_visit(@clinic)
    ReminderRun.new(@clinic).call
    reply(appointment.patient_id, "sms", "STOP!", id: "variant-stop")
    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    assert_empty @clinic.opt_outs
    reply(appointment.patient_id, "sms", "  sToP  ", id: "exact-stop")
    assert_equal "opted_out", response.parsed_body.fetch("outcome")
    travel 4.days
    ReminderRun.new(@clinic).call

    assert_equal 1, @clinic.messages.outbound.where(channel: "sms").count
    assert_equal 1, @clinic.messages.outbound.where(channel: "email").count
    assert_equal "5125550101", @clinic.opt_outs.sole.address
  end

  test "a reply to an older inbox message uses its recorded sender after a contact correction" do
    patient = create_patient(email: nil)
    create_visit(@clinic, patient: patient)
    ReminderRun.new(@clinic).call
    delivery = @clinic.messages.outbound.sole
    headers = staff_headers(@clinic)
    contact_path = "/api/staff/1/patients/#{patient.id}/contact_verifications/wireless_phone"
    patch contact_path, params: { value: "5125550177", request_key: "new-address" }, headers: headers, as: :json
    assert_response :success

    get "/api/demo/1/inboxes/#{patient.id}", params: { channel: "sms" }
    assert_equal delivery.id, response.parsed_body.fetch("reply_to_id")
    reply(patient.id, "sms", "YES", id: "old-address-yes", reply_to_id: delivery.id)
    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    reply(patient.id, "sms", "STOP", id: "old-address-stop", reply_to_id: delivery.id)
    assert_equal "opted_out", response.parsed_body.fetch("outcome")
    assert_equal "5125550101", @clinic.opt_outs.sole.address
    assert_equal delivery.id, @clinic.messages.inbound.find_by!(external_id: "old-address-stop").reply_to_id

    patch contact_path, params: { value: patient.wireless_phone, request_key: "restore-address" }, headers: headers, as: :json
    assert_response :success
    travel 4.days
    assert_no_difference "Message.outbound.count" do
      ReminderRun.new(@clinic).call
    end
  end

  test "an old delivery reference cannot confirm a newer appointment after the matching window" do
    old = create_visit(@clinic)
    ReminderRun.new(@clinic).call
    old_delivery = @clinic.messages.outbound.sole
    travel 31.days
    replacement = create_visit(@clinic, id: 102, patient: ReplicaFixture::Patient.find(old.patient_id),
      on: Time.current.to_date + 7)
    ReminderRun.new(@clinic).call

    reply(old.patient_id, "sms", "YES", id: "past-match-window", reply_to_id: old_delivery.id)

    assert_response :created
    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    assert_equal "unconfirmed", @clinic.visits.find_by!(appointment_id: replacement.id).response
  end

  test "shared contact creates review candidates and only staff can clarify a target" do
    first = create_patient(email: nil)
    second = create_patient(id: 102, email: nil, wireless_phone: first.wireless_phone)
    create_visit(@clinic, patient: first)
    create_visit(@clinic, id: 102, patient: second)
    ReminderRun.new(@clinic).call
    assert_empty @clinic.messages.outbound

    reply(first.id, "sms", "YES", id: "shared-yes")
    assert_equal "needs_review", response.parsed_body.fetch("outcome")
    review = @clinic.work_items.find_by!(kind: "reply_review")
    assert_equal @clinic.visits.order(:id).pluck(:id), review.message.candidate_ids.sort
    assert_equal [ "unconfirmed", "unconfirmed" ], @clinic.visits.order(:id).pluck(:response)

    target = @clinic.visits.find_by!(patient_id: second.id)
    follow_up(review, staff_headers(@clinic), outcome: "confirmed", note: "Reached the patient on a verified line.",
      target_ids: [ target.id ])
    assert_response :created
    assert_equal "confirmed", target.reload.response
    assert_equal "unconfirmed", @clinic.visits.find_by!(patient_id: first.id).response
    assert review.reload.resolved_at
  end

  test "contact correction unblocks and a later discrepancy creates a new hold" do
    patient = create_patient(birthdate: nil)
    create_visit(@clinic, patient: patient)
    ReminderRun.new(@clinic).call
    assert_empty @clinic.messages
    assert_includes @clinic.work_items.open.sole.reason, "birthdate"

    headers = staff_headers(@clinic)
    path = "/api/staff/1/patients/#{patient.id}/contact_verifications/birthdate"
    edit = { value: "1992-09-20", request_key: "birthdate-confirm" }
    patch path, params: edit, headers: headers, as: :json
    assert_response :success
    assert_no_difference "StaffAction.count" do
      patch path, params: edit, headers: headers, as: :json
    end
    assert_response :success
    assert_nil patient.reload.birthdate
    ReminderRun.new(@clinic).call
    assert_equal "delivered", @clinic.messages.outbound.sole.outcome
    assert_empty @clinic.work_items.open

    patient.update!(birthdate: "1994-09-20")
    travel 4.days
    ReminderRun.new(@clinic).call
    assert_equal 1, @clinic.messages.outbound.count
    assert_includes @clinic.work_items.open.sole.reason, "differ from the PMS"
  end

  test "minors and unsupported languages have actionable holds" do
    child = create_patient(birthdate: "2016-10-13")
    unknown_language = create_patient(id: 102, preferred_language: "fr")
    create_visit(@clinic, patient: child)
    create_visit(@clinic, id: 102, patient: unknown_language)
    ReminderRun.new(@clinic).call

    assert_empty @clinic.messages.outbound
    assert_equal [ "Guardian authorization requires staff review.", "Preferred language requires staff review." ],
      @clinic.work_items.order(:id).pluck(:reason)
  end

  test "invalid international numbers fall back to email and a missing language requires review" do
    patient = create_patient(wireless_phone: "+5125550101")
    missing_language = create_patient(id: 102, preferred_language: nil)
    create_visit(@clinic, patient: patient)
    create_visit(@clinic, id: 102, patient: missing_language)

    ReminderRun.new(@clinic).call

    assert_equal "email", @clinic.messages.outbound.sole.channel
    assert_equal missing_language.id, @clinic.work_items.sole.patient_id
  end

  test "contact ownership detects shared emails with different case and whitespace across clinics" do
    other = create_clinic(2)
    first = create_patient(wireless_phone: nil, email: "shared@example.test")
    second = create_patient(id: 202, wireless_phone: nil, email: "\tSHARED@example.test\r\n")
    create_visit(@clinic, patient: first)
    create_visit(other, id: 202, patient: second)

    ReminderRun.new(@clinic).call
    ReminderRun.new(other).call

    assert_empty Message.outbound
    assert_equal [ "contact_hold", "contact_hold" ], WorkItem.order(:id).pluck(:kind)
  end

  test "staff cannot apply a reviewed reply to a changed appointment revision" do
    appointment = create_visit(@clinic)
    ReminderRun.new(@clinic).call
    reply(appointment.patient_id, "sms", "NO", id: "stale-review-source")
    item = @clinic.work_items.find_by!(kind: "reply_review")

    appointment.update!(start_at: appointment.start_at + 2.hours)
    ReminderRun.new(@clinic).call
    follow_up(item, staff_headers(@clinic), outcome: "confirmed", note: "Attempted to apply an old reply.",
      target_ids: [ @clinic.visits.sole.id ])

    assert_response :unprocessable_content
    assert_equal "unconfirmed", @clinic.visits.sole.response
    assert_nil item.reload.resolved_at
    assert_empty @clinic.staff_actions
  end

  test "board search, assignment, validation, and uncertain retry preserve one staff outcome" do
    appointment = create_visit(@clinic, on: NOW.to_date + 1)
    ReminderRun.new(@clinic).call
    item = @clinic.work_items.open.sole
    headers = staff_headers(@clinic)

    get "/api/staff/1/work_items", params: { q: "nobody" }, headers: headers
    assert_empty response.parsed_body.fetch("items")
    get "/api/staff/1/work_items", params: { q: "Demo Patient", kind: "no_reply" }, headers: headers
    assert_equal item.id, response.parsed_body.fetch("items").sole.fetch("id")
    assert_equal 1, response.parsed_body.fetch("counts").fetch("attention")

    patch "/api/staff/1/work_items/#{item.id}", headers: headers
    assert_response :success
    assert_equal @clinic.staff_names.first, item.reload.assignee

    follow_up(item, headers, outcome: "attempted", note: "")
    assert_response :unprocessable_content
    assert_equal 0, @clinic.staff_actions.count
    follow_up(item, headers, outcome: "attempted", note: "Left a callback request.")
    assert_response :created
    assert_nil item.reload.resolved_at
    assert_no_difference "StaffAction.count" do
      follow_up(item, headers, outcome: "attempted", note: "Left a callback request.")
    end
    assert_response :created

    follow_up(item, headers, outcome: "confirmed", note: "Confirmed by phone.", request_key: "phone-confirmed")
    assert_response :created
    assert item.reload.resolved_at
    assert_equal "confirmed", @clinic.visits.find_by!(appointment_id: appointment.id).response
  end

  test "a failed staff audit write rolls back the disposition and keeps the task open" do
    create_visit(@clinic, on: NOW.to_date + 1)
    ReminderRun.new(@clinic).call
    item = @clinic.work_items.open.sole
    headers = staff_headers(@clinic)
    ApplicationRecord.with_connection do |connection|
      connection.execute "ALTER TABLE staff_actions ADD CONSTRAINT reject_test_note CHECK (note <> 'reject this note')"
    end

    error = assert_raises(ActiveRecord::StatementInvalid) do
      follow_up(item, headers, outcome: "confirmed", note: "reject this note")
    end
    assert_instance_of PG::CheckViolation, error.cause
    assert_nil item.reload.resolved_at
    assert_nil item.assignee
    assert_equal "unconfirmed", @clinic.visits.sole.response
    assert_empty @clinic.staff_actions
  end

  test "a delayed PMS completion closes stale no-confirmation work" do
    appointment = create_visit(@clinic, on: NOW.to_date + 1)
    ReminderRun.new(@clinic).call
    item = @clinic.work_items.open.sole
    travel 5.days
    appointment.update!(status: "complete")
    headers = staff_headers(@clinic)

    post "/api/staff/1/reminder_runs", headers: headers
    assert_response :created
    get "/api/staff/1/work_items", headers: headers
    assert_response :success
    assert_empty response.parsed_body.fetch("items")
    assert item.reload.resolved_at
    assert_equal "complete", item.visit.source_status
  end

  test "cross-clinic reads and writes fail and leadership returns only aggregates" do
    other = create_clinic(2)
    first = create_visit(@clinic, on: NOW.to_date + 1)
    foreign = create_visit(other, id: 202, on: NOW.to_date + 1)
    create_visit(@clinic, id: 102, on: NOW.to_date - 2, status: "complete")
    ReminderRun.new(@clinic).call
    ReminderRun.new(other).call
    headers = staff_headers(@clinic)

    get "/api/staff/1/appointments", params: { date: (NOW.to_date + 1).iso8601 }, headers: headers
    assert_response :success
    assert_equal [ first.patient_id ], response.parsed_body.fetch("visits").pluck("patient_id")
    get "/api/staff/1/patients/#{foreign.patient_id}", headers: headers
    assert_response :not_found
    patch "/api/staff/1/work_items/#{other.work_items.open.sole.id}", headers: headers
    assert_response :not_found
    reply(foreign.patient_id, "sms", "YES", id: "wrong-clinic")
    assert_response :not_found

    get "/api/leadership_report", params: { month: "2026-11" }
    assert_response :success
    report = response.parsed_body
    assert_equal %w[Austin Phoenix], report.fetch("clinics").pluck("name")
    assert_equal 1, report.fetch("clinics").first.fetch("outcomes").fetch("completed")
    assert_equal 50.0, report.fetch("clinics").first.fetch("outcomes").fetch("completion_rate")
    %w[patient_id patient_name birthdate email phone address body note].each do |private_field|
      refute_match(/"#{private_field}"\s*:/, response.body)
    end
    refute_includes response.body, "Demo Patient"
  end

  private

  def reply(patient_id, channel, body, id:, reply_to_id: :latest)
    if reply_to_id == :latest
      reply_to_id = @clinic.messages.outbound.delivered.where(patient_id: patient_id, channel: channel)
        .order(:created_at, :id).last&.id
    end
    post "/api/demo/1/inboxes/#{patient_id}/replies",
      params: { channel: channel, body: body, event_id: id, reply_to_id: reply_to_id }, as: :json
  end

  def follow_up(item, headers, outcome:, note:, target_ids: [], request_key: "follow-up-001")
    post "/api/staff/1/work_items/#{item.id}/follow_ups",
      params: { outcome: outcome, note: note, target_ids: target_ids, request_key: request_key },
      headers: headers, as: :json
  end
end
