# Apex Appointment Flow

A local appointment confirmation demo for fictional Austin and Phoenix clinics. Front desk shows the work queue and appointment calendar. Apex leadership shows aggregate outcomes and staff activity. Patient inbox simulates SMS and email.

## Run locally

Tested with Ruby 3.4.10, Bundler 4.0.15, Rails 8.1.4.1, PostgreSQL 17.11, Node 24.19.0, npm 11.17.0, React 19.3.1 and Vite 8.3.8. Python 3.9 or later runs the quality harness.

### PostgreSQL

Use a local PostgreSQL role that can create the two demo databases. The defaults are host `127.0.0.1`, port `55432` and role `apex`. Override them with `APEX_DB_HOST`, `APEX_DB_PORT`, `APEX_DB_USER` and `APEX_DB_PASSWORD`. `APEX_DB_NAME` changes the development database name when testing a fresh setup. The Rails test database is `apex_flow_test`.

On Windows with installed PostgreSQL 17, these PowerShell commands start a dedicated loopback cluster in this checkout. Run them from the repository root.

```powershell
$apexPg = 'C:/Program Files/PostgreSQL/17/bin'
$apexData = Join-Path $PWD 'tmp/apex-pg'
New-Item -ItemType Directory -Path tmp -Force | Out-Null
if (-not (Test-Path (Join-Path $apexData 'PG_VERSION'))) {
  & "$apexPg/initdb.exe" -D $apexData -U apex --auth=trust --encoding=UTF8 --locale=C
}
& "$apexPg/pg_isready.exe" -h 127.0.0.1 -p 55432
if ($LASTEXITCODE -ne 0) {
  Start-Process -FilePath "$apexPg/postgres.exe" -ArgumentList @('-D', ('"' + $apexData + '"'), '-h', '127.0.0.1', '-p', '55432') -WindowStyle Hidden
}
& "$apexPg/pg_isready.exe" -h 127.0.0.1 -p 55432
```

Use this trusted loopback cluster only for the fictional demo. The command to stop this cluster is `& "$apexPg/pg_ctl.exe" -D $apexData stop -m fast`.

### Rails and React

Start Rails in one terminal. The first `db:prepare` creates and seeds the development database. For an existing empty database, run `ruby bin/rails db:seed` once.

```text
cd backend
bundle install
ruby bin/rails db:prepare
ruby bin/rails server -b 127.0.0.1 -p 3000
```

Start React in another terminal from the repository root.

```text
cd frontend
npm ci
npm run dev
```

On Windows PowerShell, use `npm.cmd` if PowerShell blocks `npm.ps1`. Open [the local app](http://127.0.0.1:4178). Vite forwards the API requests to Rails.

## Walk through the demo

1. Open **Front desk**, select Austin and Taylor Morgan, then click **Run reminders**. The result shows fake deliveries, failures and appointments on hold. **Appointments** shows the local visit time, confirmation status and PMS status. The CLI entry point is `ruby bin/rails reminders:run` in `backend`.
2. Return to **Workspaces**, open **Patient**, choose Austin and **Amelia Rivera**. Read the initial text message, enter `YES`, and send the reply. Choose **Noah Bennett** and open **Email** to confirm a visit through email as well. The seeded appointment dates are relative to the most recent sending window, and the seeds contain an initial message for both patients.
3. Send `NO` after confirming Amelia. In Austin **Patient flow**, filter by **Reply to review**, open the new item, and assign it or record a follow-up note. A staff member can correct local contact details from **Patient details**. Refresh eligibility using **Run reminders**.
4. Switch to Phoenix through **Workspaces** to see its own queue. Open **Apex leadership** to compare the monthly aggregate outcome and follow-up counts.

In development, fake deliveries are stored in `Message.outbound`. The patient inbox shows delivered messages and inbound replies. Use `ruby bin/rails console` in `backend` to inspect all attempts, including failures. Synthetic SMS numbers ending in `0199` exercise a provider rejection.

## Checks

Run `python quality/run_checks.py` from the root after the bundle, database and npm dependencies are prepared. It runs Rails tests, RuboCop, Brakeman, React lint, TypeScript, Vitest and the Vite build. With both servers running against freshly seeded demo data and Google Chrome available, run `npm run smoke` in `frontend` for the local browser tests. The browser run writes fictional replies and follow-up records.

The input preflight ran before application changes. To verify the original inputs again using the local Git history, archive the `602747a` checkpoint and run `python quality/verify_harness.py` inside that extracted tree. It contains the original versions of the build log and review checklist.

See [architecture](ARCHITECTURE.md), [decision notes](notes/CANDIDATE_DECISION_NOTES.md), [AI usage](AI_USAGE.md) and [review results](review/RUBRIC_RESULTS.md). The assessment requires the candidate to write `DECISIONS.md` personally.
