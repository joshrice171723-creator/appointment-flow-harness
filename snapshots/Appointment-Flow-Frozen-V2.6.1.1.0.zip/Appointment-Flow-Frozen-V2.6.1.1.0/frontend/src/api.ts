import { useEffect, useReducer, useState } from 'react'

export async function request<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  const headers = new Headers(options.headers)
  headers.set('Accept', 'application/json')
  if (options.body) headers.set('Content-Type', 'application/json')
  if (token) headers.set('Authorization', 'Bearer ' + token)

  let response: Response
  try {
    response = await fetch('/api' + path, { ...options, headers })
  } catch (error) {
    if (options.signal?.aborted) throw error
    throw new Error('The local server could not be reached. Reload before changing a pending save.')
  }
  if (!response.ok) {
    const failure: { error?: string } = await response.json().catch(() => ({}))
    throw new Error(failure.error ?? 'The server could not complete this request. Check the latest status and retry.')
  }
  return response.json() as Promise<T>
}

type QueryResult<T> = { key: string; data: T } | { key: string; error: string }

export function useQuery<T>(path: string | null, token?: string) {
  const [result, setResult] = useState<QueryResult<T>>()
  const [version, refresh] = useReducer((count: number) => count + 1, 0)
  const key = path === null ? null : version + ':' + path

  useEffect(() => {
    if (path === null || key === null) return
    const controller = new AbortController()
    request<T>(path, { signal: controller.signal }, token).then(
      data => setResult({ key, data }),
      error => {
        if (!controller.signal.aborted) setResult({ key, error: errorMessage(error) })
      },
    )
    return () => controller.abort()
  }, [key, path, token])

  const current = result?.key === key ? result : undefined
  return {
    data: current && 'data' in current ? current.data : undefined,
    error: current && 'error' in current ? current.error : undefined,
    loading: key !== null && !current,
    refresh,
  }
}

export function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'The operation could not be completed.'
}

export function jsonBody(method: 'POST' | 'PATCH', data: object): RequestInit {
  return { method, body: JSON.stringify(data) }
}
