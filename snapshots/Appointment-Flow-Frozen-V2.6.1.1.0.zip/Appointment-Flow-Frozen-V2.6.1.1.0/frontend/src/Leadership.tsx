import { useState } from 'react'
import { useQuery } from './api'
import { Alert, Header, Loading } from './layout'

type Totals = {
  month: string; recorded: number; completed: number; scheduled: number; unknown: number; completion_rate: number | null
}
type ClinicSummary = {
  clinic_id: number; name: string; outcomes: Totals; history: Totals[]
  reminders: { delivered: number; failed: number }
  work: { contact_holds: number; attempted: number; confirmed: number; rescheduled: number; canceled: number; reviewed: number; contact_verified: number }
}
type Report = { month: string; clinics: ClinicSummary[] }

const monthFormatter = new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })
const metricLabels = { completed: 'Completed', scheduled: 'Scheduled', unknown: 'Unknown outcome' }

function monthLabel(month: string) {
  return monthFormatter.format(new Date(month + '-01T00:00:00Z'))
}

function rateLabel(rate: number | null) {
  return rate === null ? '—' : rate.toFixed(1) + '%'
}

export function Leadership({ onHome }: { onHome: () => void }) {
  const [month, setMonth] = useState('')
  const report = useQuery<Report>('/leadership_report?' + new URLSearchParams({ month }))
  const result = report.data

  return (
    <>
      <Header onHome={onHome}><span className="nav-context">Apex leadership</span></Header>
      <main className="page leadership">
        <div className="heading-row">
          <div><h1>Appointment outcomes</h1><p className="muted">Recorded PMS outcomes by clinic.</p></div>
          <label>Outcome month<input type="month" value={month || result?.month || ''} onChange={event => setMonth(event.target.value)} /></label>
        </div>
        {report.loading && <Loading />}
        {report.error && <><Alert message={report.error} /><button onClick={report.refresh}>Retry</button></>}
        {result && !result.clinics.length && <p className="muted">No reporting clinics are available.</p>}
        {result && result.clinics.length > 0 && (
          <>
            <section className="panel inset">
              <h2>{monthLabel(result.month)}</h2>
              <div className="outcome-grid">
                {result.clinics.map(clinic => <OutcomeCard key={clinic.clinic_id} clinic={clinic} />)}
              </div>
            </section>
            <section className="panel inset">
              <div className="section-heading"><h2>Clinic comparison</h2></div>
              <div className="table-scroll">
                <table>
                  <thead><tr><th>Clinic</th><th>Completion rate</th><th>Recorded visits</th><th>Completed</th><th>Scheduled</th><th>Unknown outcome</th></tr></thead>
                  <tbody>{result.clinics.map(clinic => <OutcomeRow key={clinic.clinic_id} label={clinic.name} totals={clinic.outcomes} />)}</tbody>
                </table>
              </div>
              <p className="muted small">Completion rate is completed visits divided by all recorded visits in the selected month. Broken and unscheduled PMS rows have an unknown outcome.</p>
              <p className="muted small">No-show counts are unavailable because the PMS has no dedicated no-show status.</p>
            </section>
            <details className="panel inset report-section">
              <summary>Monthly history and reminder activity</summary>
              <div className="outcome-grid">
                {result.clinics.map(clinic => (
                  <section key={clinic.clinic_id}>
                    <h3>{clinic.name}</h3>
                    <p className="muted small">This month: {clinic.reminders.delivered} simulated messages delivered · {clinic.reminders.failed} failed.</p>
                    <div className="table-scroll">
                      <table>
                        <thead><tr><th>Month</th><th>Completion rate</th><th>Recorded</th><th>Completed</th><th>Scheduled</th><th>Unknown</th></tr></thead>
                        <tbody>{clinic.history.map(totals => <OutcomeRow key={totals.month} label={monthLabel(totals.month)} totals={totals} />)}</tbody>
                      </table>
                    </div>
                  </section>
                ))}
              </div>
            </details>
            <details className="panel inset report-section">
              <summary>Contact holds</summary>
              <p className="muted small">Counts include contact hold items created in the selected month.</p>
              <dl className="report-totals">
                {result.clinics.map(clinic => <div key={clinic.clinic_id}><dt>{clinic.name}</dt><dd>{clinic.work.contact_holds}</dd></div>)}
              </dl>
            </details>
            <details className="panel inset report-section">
              <summary>Contact and follow-up</summary>
              <p className="muted small">Counts reflect recorded staff actions in the selected month. Reschedule and cancellation actions reflect staff reports.</p>
              <div className="table-scroll">
                <table>
                  <thead><tr><th>Clinic</th><th>Contact attempted</th><th>Confirmed</th><th>Rescheduled</th><th>Canceled</th><th>Reviewed</th><th>Details verified</th></tr></thead>
                  <tbody>{result.clinics.map(clinic => (
                    <tr key={clinic.clinic_id}><th>{clinic.name}</th><td>{clinic.work.attempted}</td><td>{clinic.work.confirmed}</td>
                      <td>{clinic.work.rescheduled}</td><td>{clinic.work.canceled}</td><td>{clinic.work.reviewed}</td><td>{clinic.work.contact_verified}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            </details>
          </>
        )}
      </main>
    </>
  )
}

function OutcomeCard({ clinic }: { clinic: ClinicSummary }) {
  const metrics = Object.keys(metricLabels) as (keyof typeof metricLabels)[]
  return (
    <section className="clinic-outcome">
      <div className="section-heading"><h3>{clinic.name}</h3><span className="muted small">{clinic.outcomes.recorded} recorded visits</span></div>
      <div className="outcome-bar" aria-hidden="true">
        {metrics.map(key => <span key={key} className={key} style={{
          width: (clinic.outcomes.recorded ? clinic.outcomes[key] / clinic.outcomes.recorded * 100 : 0) + '%',
        }} />)}
      </div>
      <dl className="outcome-legend">
        {metrics.map(key => (
          <div key={key}>
            <dt><span aria-hidden="true" className={key} />{metricLabels[key]}</dt>
            <dd>{clinic.outcomes[key]}</dd>
          </div>
        ))}
      </dl>
    </section>
  )
}

function OutcomeRow({ label, totals }: { label: string; totals: Totals }) {
  return (
    <tr><th>{label}</th><td>{rateLabel(totals.completion_rate)}</td><td>{totals.recorded}</td>
      <td>{totals.completed}</td><td>{totals.scheduled}</td><td>{totals.unknown}</td></tr>
  )
}
