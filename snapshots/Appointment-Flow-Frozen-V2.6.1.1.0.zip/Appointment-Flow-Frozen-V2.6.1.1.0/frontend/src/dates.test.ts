import { describe, expect, it } from 'vitest'
import { localClock, shiftDate, weekDates } from './dates'

describe('clinic calendar', () => {
  it('keeps Monday through Sunday together across DST and month boundaries', () => {
    expect(weekDates('2026-11-01')).toEqual([
      '2026-10-26', '2026-10-27', '2026-10-28', '2026-10-29',
      '2026-10-30', '2026-10-31', '2026-11-01',
    ])
    expect(shiftDate('2026-03-08', 1)).toBe('2026-03-09')
  })

  it('prints the clinic wall-clock components without converting to the browser zone', () => {
    expect(localClock('2026-11-16T13:30:00Z')).toBe('1:30 PM')
  })
})
