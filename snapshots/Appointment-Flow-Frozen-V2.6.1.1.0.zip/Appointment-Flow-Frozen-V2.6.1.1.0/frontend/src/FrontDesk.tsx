import { useState } from 'react'
import type { FormEvent } from 'react'
import { errorMessage, request, useQuery } from './api'
import { localClock, longDate, shortDate, shiftDate, weekDates } from './dates'
import { Alert, Header, Loading, Pill, SyncStatus } from './layout'
import { PatientDetail } from './PatientDetail'
import { workLabels } from './types'
import { VisitTable } from './VisitTable'
import type { ClinicView, Session, Visit, WorkItem } from './types'

type Detail = { kind: 'patient' | 'item'; id: number }
type DeskView = 'board' | 'appointments'
type BoardResult = {
  clinic: ClinicView
  kinds: Record<string, string>
  counts: { attention: number; progress: number; resolved: number }
  items: WorkItem[]
  page: number
  pages: number
  total: number
}

export function FrontDesk({ session, onHome }: { session: Session; onHome: () => void }) {
  const [view, setView] = useState<DeskView>('board')
  const [detail, setDetail] = useState<Detail>()
  const [runStatus, setRunStatus] = useState<{ kind: 'pending' | 'error' | 'saved'; message: string }>()
  const [version, setVersion] = useState(0)
  const base = '/staff/' + session.clinic.id

  function open(next: DeskView) {
    setDetail(undefined)
    setView(next)
  }

  async function runReminders() {
    setRunStatus({ kind: 'pending', message: 'Refreshing appointments and checking reminder eligibility…' })
    try {
      const result = await request<{ delivered: number; failed: number; held: number }>(
        base + '/reminder_runs', { method: 'POST' }, session.token,
      )
      setVersion(current => current + 1)
      setRunStatus({
        kind: 'saved',
        message: 'Reminders delivered ' + result.delivered + ' · Failed ' + result.failed + ' · Appointments on hold ' + result.held,
      })
    } catch (failure) {
      setRunStatus({ kind: 'error', message: errorMessage(failure) })
    }
  }

  return (
    <>
      <Header onHome={onHome}>
        <button className="nav-button" aria-current={view === 'board' ? 'page' : undefined} onClick={() => open('board')}>Patient flow</button>
        <button className="nav-button" aria-current={view === 'appointments' ? 'page' : undefined} onClick={() => open('appointments')}>Appointments</button>
      </Header>
      <main className="page desk">
        {detail ? (
          <PatientDetail key={detail.kind + detail.id} base={base} detail={detail} session={session} onBack={() => setDetail(undefined)} />
        ) : view === 'board' ? (
          <>
            <div className="heading-row">
              <div><p className="clinic-label">{session.clinic.name}</p><h1>Patient flow</h1><p className="muted">Signed in as {session.staff}</p></div>
              <button className="primary" disabled={runStatus?.kind === 'pending'} onClick={runReminders}>
                {runStatus?.kind === 'pending' ? 'Running reminders…' : 'Run reminders'}
              </button>
            </div>
            {runStatus?.kind === 'error' && <Alert message={runStatus.message} />}
            {runStatus && runStatus.kind !== 'error' && <p className="feedback" role="status">{runStatus.message}</p>}
            <Board base={base} token={session.token} version={version} onOpen={id => setDetail({ kind: 'item', id })} />
          </>
        ) : (
          <Appointments base={base} token={session.token} clinicName={session.clinic.name} version={version}
            onPatient={id => setDetail({ kind: 'patient', id })} />
        )}
      </main>
    </>
  )
}

function Board({ base, token, version, onOpen }: {
  base: string; token: string; version: number; onOpen: (id: number) => void
}) {
  const [scope, setScope] = useState('active')
  const [kind, setKind] = useState('')
  const [draft, setDraft] = useState('')
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const params = new URLSearchParams({ status: scope, kind, q: search, page: String(page), revision: String(version) })
  const query = useQuery<BoardResult>(base + '/work_items?' + params, token)
  const board = query.data

  function submitSearch(event: FormEvent) {
    event.preventDefault()
    setSearch(draft.trim())
    setPage(1)
  }

  return (
    <>
      {board && <SyncStatus clinic={board.clinic} />}
      {board && (
        <div className="stats-grid">
          {[
            ['Needs attention', board.counts.attention, 'warm'],
            ['In progress', board.counts.progress, 'soft'],
            ['Resolved', board.counts.resolved, ''],
          ].map(([label, total, tone]) => (
            <div className={'panel stat ' + tone} key={label}><span>{label}</span><strong>{total}</strong></div>
          ))}
        </div>
      )}
      <div className="board-tools">
        <div className="tabs" aria-label="Work item status">
          {[['active', 'Active work'], ['resolved', 'Resolved'], ['all', 'All work']].map(([id, label]) => (
            <button key={id} aria-pressed={scope === id} onClick={() => { setScope(id); setPage(1) }}>{label}</button>
          ))}
        </div>
        <form className="filter-form" onSubmit={submitSearch}>
          <label>Issue type
            <select value={kind} onChange={event => { setKind(event.target.value); setPage(1) }}>
              <option value="">All issue types</option>
              {Object.entries(workLabels).map(([key, label]) => <option value={key} key={key}>{label}</option>)}
            </select>
          </label>
          <label>Search patients<input type="search" value={draft} onChange={event => setDraft(event.target.value)} placeholder="Patient name" /></label>
          <button type="submit">Search</button>
        </form>
      </div>
      {query.loading && <Loading />}
      {query.error && <><Alert message={query.error} /><button onClick={query.refresh}>Retry</button></>}
      {board && (
        <>
          {scope === 'active' ? (
            <div className="board-columns">
              <WorkColumn heading="Needs attention" items={board.items.filter(item => !item.assignee)} onOpen={onOpen} />
              <WorkColumn heading="In progress" items={board.items.filter(item => item.assignee)} onOpen={onOpen} />
            </div>
          ) : <WorkColumn heading={scope === 'resolved' ? 'Resolved' : 'All work'} items={board.items} onOpen={onOpen} />}
          <div className="pagination">
            <span className="muted">{board.total} {board.total === 1 ? 'item' : 'items'} · Page {board.page} of {board.pages}</span>
            <button disabled={board.page <= 1} onClick={() => setPage(board.page - 1)}>Previous</button>
            <button disabled={board.page >= board.pages} onClick={() => setPage(board.page + 1)}>Next</button>
          </div>
        </>
      )}
    </>
  )
}

function WorkColumn({ heading, items, onOpen }: { heading: string; items: WorkItem[]; onOpen: (id: number) => void }) {
  return (
    <section className="work-column">
      <h2>{heading}</h2>
      {items.length === 0 && <p className="muted">No items match this view.</p>}
      {items.map(item => (
        <article className="panel work-card" key={item.id}>
          <Pill tone={item.kind === 'reply_review' ? 'blue' : item.kind === 'contact_hold' ? 'amber' : 'neutral'}>
            {workLabels[item.kind] ?? item.kind}
          </Pill>
          <h3><button className="text-action" onClick={() => onOpen(item.id)}>{item.patient_name ?? 'Unmatched reply'} <span aria-hidden="true">→</span></button></h3>
          <p>{item.reason}</p>
          {item.visit_time && <p className="muted small">{shortDate(item.visit_time.slice(0, 10))} · {localClock(item.visit_time)}</p>}
          {item.resolved_at ? <Pill tone="green">Resolved</Pill> : item.assignee && <p className="muted small">Assigned to {item.assignee}</p>}
        </article>
      ))}
    </section>
  )
}

const appointmentTabs = { all: 'All appointments', confirmed: 'Confirmed', unconfirmed: 'Unconfirmed', review: 'Replies to review' }
type AppointmentFilter = keyof typeof appointmentTabs
type AppointmentResult = {
  clinic: ClinicView; date: string; visits: Visit[]; week_counts: Record<string, number>; counts: Record<AppointmentFilter, number>
}

function Appointments({ base, token, clinicName, version, onPatient }: {
  base: string; token: string; clinicName: string; version: number; onPatient: (id: number) => void
}) {
  const [date, setDate] = useState('')
  const [filter, setFilter] = useState<AppointmentFilter>('all')
  const params = new URLSearchParams({ date, filter, revision: String(version) })
  const query = useQuery<AppointmentResult>(base + '/appointments?' + params, token)
  const result = query.data
  const selected = date || result?.date || ''

  return (
    <>
      <p className="clinic-label">{clinicName}</p>
      <h1>Appointments</h1>
      {result && <SyncStatus clinic={result.clinic} />}
      <section className="panel calendar" aria-label="Appointment calendar">
        <div className="calendar-controls">
          <button disabled={!selected} onClick={() => setDate(shiftDate(selected, -7))}>← Previous week</button>
          <button disabled={!date} onClick={() => setDate('')}>Today</button>
          <button disabled={!selected} onClick={() => setDate(shiftDate(selected, 7))}>Next week →</button>
          <label>Jump to date<input type="date" value={selected} onChange={event => setDate(event.target.value)} /></label>
        </div>
        {selected && (
          <div className="week">
            {weekDates(selected).map(day => (
              <button key={day} aria-pressed={day === selected} onClick={() => setDate(day)}>
                <strong>{shortDate(day)}</strong><span>{result ? (result.week_counts[day] ?? 0) + ' visits' : ' '}</span>
              </button>
            ))}
          </div>
        )}
      </section>
      <div className="tabs appointment-tabs">
        {(Object.keys(appointmentTabs) as AppointmentFilter[]).map(key => (
          <button key={key} aria-pressed={filter === key} onClick={() => setFilter(key)}>
            {appointmentTabs[key]} {result && <span className="tab-count">{result.counts[key]}</span>}
          </button>
        ))}
      </div>
      {query.loading && <Loading />}
      {query.error && <><Alert message={query.error} /><button onClick={query.refresh}>Retry</button></>}
      {result && (
        <section className="panel appointments-panel">
          <h2>{longDate(result.date)}</h2>
          <VisitTable visits={result.visits} onPatient={onPatient} />
          {result.counts[filter] > result.visits.length && <p className="muted">Showing the first {result.visits.length} matching appointments.</p>}
        </section>
      )}
    </>
  )
}
