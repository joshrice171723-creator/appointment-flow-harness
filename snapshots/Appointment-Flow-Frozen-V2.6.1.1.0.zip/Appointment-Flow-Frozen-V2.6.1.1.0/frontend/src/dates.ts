const dateLabel = new Intl.DateTimeFormat('en-US', {
  weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC',
})
const dateHeading = new Intl.DateTimeFormat('en-US', {
  month: 'long', day: 'numeric', year: 'numeric', timeZone: 'UTC',
})
const clockLabel = new Intl.DateTimeFormat('en-US', {
  hour: 'numeric', minute: '2-digit', timeZone: 'UTC',
})

export function shiftDate(date: string, days: number) {
  const value = new Date(date + 'T00:00:00Z')
  value.setUTCDate(value.getUTCDate() + days)
  return value.toISOString().slice(0, 10)
}

export function weekDates(date: string) {
  const day = new Date(date + 'T00:00:00Z').getUTCDay()
  const monday = shiftDate(date, -((day + 6) % 7))
  return Array.from({ length: 7 }, (_, index) => shiftDate(monday, index))
}

export function shortDate(date: string) {
  return dateLabel.format(new Date(date + 'T00:00:00Z'))
}

export function longDate(date: string) {
  return dateHeading.format(new Date(date + 'T00:00:00Z'))
}

export function localClock(wallTime: string) {
  return clockLabel.format(new Date(wallTime))
}

export function instantLabel(instant: string, timezone: string) {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
    timeZone: timezone, timeZoneName: 'short',
  }).format(new Date(instant))
}
