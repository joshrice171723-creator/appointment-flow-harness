import { useState } from 'react'
import type { FormEvent } from 'react'
import { errorMessage, jsonBody, request, useQuery } from './api'
import { FrontDesk } from './FrontDesk'
import { PatientInbox } from './PatientInbox'
import { Leadership } from './Leadership'
import { Alert, Header, Loading } from './layout'
import type { Clinic, Session } from './types'

type Workspace = 'workspaces' | 'front_desk' | 'leadership' | 'inbox'

export function App() {
  const [workspace, setWorkspace] = useState<Workspace>('workspaces')
  const [session, setSession] = useState<Session>()
  const catalog = useQuery<{ clinics: Clinic[] }>('/clinics')
  const goHome = () => setWorkspace('workspaces')

  if (workspace === 'front_desk' && session) return <FrontDesk key={session.token} session={session} onHome={goHome} />
  if (workspace === 'leadership') return <Leadership onHome={goHome} />
  if (workspace === 'inbox') return <PatientInbox clinics={catalog.data?.clinics ?? []} onHome={goHome} />

  return (
    <>
      <Header onHome={goHome} />
      <main className="workspaces page">
        <h1>Workspaces</h1>
        {catalog.loading && <Loading />}
        {catalog.error && <><Alert message={catalog.error} /><button onClick={catalog.refresh}>Retry</button></>}
        {catalog.data && (
          <WorkspaceCards
            clinics={catalog.data.clinics}
            onStaff={value => {
              setSession(value)
              setWorkspace('front_desk')
            }}
            onLeadership={() => setWorkspace('leadership')}
            onPatient={() => setWorkspace('inbox')}
          />
        )}
      </main>
    </>
  )
}

function WorkspaceCards({
  clinics, onStaff, onLeadership, onPatient,
}: {
  clinics: Clinic[]
  onStaff: (session: Session) => void
  onLeadership: () => void
  onPatient: () => void
}) {
  const [clinicId, setClinicId] = useState(clinics[0]?.id ?? 0)
  const [staffName, setStaffName] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string>()
  const clinic = clinics.find(candidate => candidate.id === clinicId)
  const staff = staffName || clinic?.staff[0] || ''

  async function openDesk(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!clinic || !staff) return
    setBusy(true)
    setError(undefined)
    try {
      const result = await request<{ token: string }>('/staff_session', jsonBody('POST', {
        clinic_id: clinic.id, staff,
      }))
      onStaff({ clinic, staff, token: result.token })
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="workspace-grid">
      <form className="panel workspace-card" onSubmit={openDesk}>
        <h2>Front desk</h2>
        <p className="muted">Review appointments and follow up with patients.</p>
        {clinics.length === 0 && <p className="muted">No demo clinics are available.</p>}
        {clinic && (
          <>
            <label>Clinic
              <select aria-label="Clinic" value={clinic.id} onChange={event => {
                setClinicId(Number(event.target.value))
                setStaffName('')
              }}>
                {clinics.map(entry => <option key={entry.id} value={entry.id}>{entry.name}{entry.state ? ', ' + entry.state : ''}</option>)}
              </select>
            </label>
            <label>Staff member <span className="muted">(demo sign-in)</span>
              <select value={staff} onChange={event => setStaffName(event.target.value)}>
                {clinic.staff.map(name => <option key={name}>{name}</option>)}
              </select>
            </label>
          </>
        )}
        {error && <Alert message={error} />}
        <button className="primary wide" disabled={busy || !staff}>{busy ? 'Opening…' : 'Open front desk'}<span aria-hidden="true">→</span></button>
      </form>
      <section className="panel workspace-card leadership-card">
        <h2>Apex leadership</h2>
        <p className="muted">Compare appointment outcomes and reminder activity by clinic.</p>
        <p className="clinic-count"><strong>{clinics.length}</strong><span>{clinics.length === 1 ? 'Clinic' : 'Clinics'}</span></p>
        <button className="primary wide" onClick={onLeadership}>Open Apex leadership<span aria-hidden="true">→</span></button>
      </section>
      <section className="panel workspace-card">
        <h2>Patient</h2>
        <p className="muted">View simulated text and email messages and send a demo reply.</p>
        <button className="primary wide" onClick={onPatient}>Open patient workspace<span aria-hidden="true">→</span></button>
      </section>
    </div>
  )
}
