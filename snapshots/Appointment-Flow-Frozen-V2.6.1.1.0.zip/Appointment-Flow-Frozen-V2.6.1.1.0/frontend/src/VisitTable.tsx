import { localClock, shortDate } from './dates'
import { Pill } from './layout'
import { outcomeLabels, responseLabels } from './types'
import type { Visit } from './types'

export function VisitTable({ visits, onPatient }: { visits: Visit[]; onPatient?: (id: number) => void }) {
  if (visits.length === 0) return <p className="muted">No appointments match this view.</p>

  return (
    <div className="table-scroll">
      <table>
        <thead><tr><th>Patient</th><th>Appointment</th><th>Confirmation</th><th>PMS status</th>{onPatient && <th>Next step</th>}</tr></thead>
        <tbody>{visits.map(visit => (
          <tr key={visit.id}>
            <td><strong>{visit.patient_name}</strong><small>Appointment #{visit.appointment_id}</small></td>
            <td>{shortDate(visit.wall_time.slice(0, 10))} · {localClock(visit.wall_time)}<small>{visit.provider_name}{visit.length_minutes ? ' · ' + visit.length_minutes + ' min' : ''}</small></td>
            <td>
              <Pill tone={visit.response === 'confirmed' ? 'green' : 'neutral'}>{responseLabels[visit.response] ?? visit.response}</Pill>
              {visit.needs_review && <small>Reply to review</small>}
            </td>
            <td>{outcomeLabels[visit.source_status] ?? 'Unknown'}</td>
            {onPatient && <td><button className="text-action" onClick={() => onPatient(visit.patient_id)}>Patient details →</button></td>}
          </tr>
        ))}</tbody>
      </table>
    </div>
  )
}
