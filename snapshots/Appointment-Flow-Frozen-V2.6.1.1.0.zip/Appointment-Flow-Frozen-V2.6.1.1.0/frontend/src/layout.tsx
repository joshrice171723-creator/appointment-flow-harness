import type { ReactNode } from 'react'
import type { ClinicView } from './types'
import { instantLabel } from './dates'

export function Header({ onHome, children }: { onHome: () => void; children?: ReactNode }) {
  return (
    <header className="masthead">
      <button type="button" className="brand link-button" onClick={onHome} aria-label="Apex workspaces">
        <span className="brand-mark" aria-hidden="true">A<span>+</span></span>
        <span><strong>APEX</strong><small>APPOINTMENT FLOW</small></span>
      </button>
      <nav aria-label="Workspace navigation">
        {children}
        <button type="button" className="nav-button" onClick={onHome}>Workspaces <span aria-hidden="true">↗</span></button>
      </nav>
    </header>
  )
}

export function SyncStatus({ clinic }: { clinic: ClinicView }) {
  return (
    <p className="muted sync-status">
      {clinic.last_synced_at ? 'Last PMS sync ' + instantLabel(clinic.last_synced_at, clinic.timezone) : 'PMS sync pending'}
      {' · '}{clinic.timezone}
    </p>
  )
}

export function Alert({ message }: { message: string }) {
  return <p className="feedback error" role="alert">{message}</p>
}

export function Loading() {
  return <p className="loading" role="status">Loading…</p>
}

export function Pill({ children, tone = 'neutral' }: { children: ReactNode; tone?: string }) {
  return <span className={'pill ' + tone}>{children}</span>
}
