import { useState } from 'react'
import type { FormEvent } from 'react'
import { errorMessage, jsonBody, request, useQuery } from './api'
import { instantLabel } from './dates'
import { Alert, Loading } from './layout'
import type { Clinic } from './types'

type Channel = 'sms' | 'email'
type InboxList = { patients: { id: number; name: string }[]; timezone: string }
type Message = { id: number; body: string; direction: 'inbound' | 'outbound'; outcome: string; created_at: string }

export function PatientInbox({ clinics, onHome }: { clinics: Clinic[]; onHome: () => void }) {
  const [clinicId, setClinicId] = useState('')
  const [patientId, setPatientId] = useState('')
  const [channel, setChannel] = useState<Channel>('sms')
  const base = '/demo/' + clinicId + '/inboxes'
  const list = useQuery<InboxList>(clinicId ? base : null)

  return (
    <main className="page inbox">
      <button className="back-link" onClick={onHome}>← Workspaces</button>
      <h1>Patient inbox</h1>
      <label>Clinic
        <select aria-label="Clinic" value={clinicId} onChange={event => {
          setClinicId(event.target.value)
          setPatientId('')
          setChannel('sms')
        }}>
          <option value="">Choose a clinic</option>
          {clinics.map(clinic => <option value={clinic.id} key={clinic.id}>{clinic.name}</option>)}
        </select>
      </label>
      {list.loading && <Loading />}
      {list.error && <><Alert message={list.error} /><button onClick={list.refresh}>Retry</button></>}
      {list.data && (
        <label>Patient
          <select aria-label="Patient" value={patientId} onChange={event => { setPatientId(event.target.value); setChannel('sms') }}>
            <option value="">{list.data.patients.length ? 'Choose a patient' : 'No demo patients available'}</option>
            {list.data.patients.map(patient => <option key={patient.id} value={patient.id}>{patient.name}</option>)}
          </select>
        </label>
      )}
      {list.data && patientId && (
        <>
          <div className="tabs inbox-tabs" aria-label="Message channel">
            <button aria-pressed={channel === 'sms'} onClick={() => setChannel('sms')}>Text messages</button>
            <button aria-pressed={channel === 'email'} onClick={() => setChannel('email')}>Email</button>
          </div>
          <Conversation key={base + '/' + patientId + channel} path={base + '/' + patientId} channel={channel} timezone={list.data.timezone} />
        </>
      )}
    </main>
  )
}

const replyLabels: Record<string, string> = {
  confirmed: 'Confirmation recorded.', opted_out: 'Opt-out recorded.', needs_review: 'Reply sent to the front desk for review.',
}

function Conversation({ path, channel, timezone }: { path: string; channel: Channel; timezone: string }) {
  const history = useQuery<{ messages: Message[]; reply_to_id: number | null }>(path + '?channel=' + channel)
  const [draft, setDraft] = useState('')
  const [eventId, setEventId] = useState(() => crypto.randomUUID())
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  async function send(event: FormEvent) {
    event.preventDefault()
    setError('')
    setNotice('')
    setBusy(true)
    try {
      const result = await request<{ outcome: string }>(path + '/replies', jsonBody('POST', {
        channel, body: draft, event_id: eventId, reply_to_id: history.data?.reply_to_id,
      }))
      setDraft('')
      setEventId(crypto.randomUUID())
      setNotice(replyLabels[result.outcome] ?? 'Reply recorded.')
      history.refresh()
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      {history.loading && <Loading />}
      {history.error && <><Alert message={history.error} /><button onClick={history.refresh}>Retry</button></>}
      {history.data && (
        <>
          {history.data.messages.length ? (
            <section>
              <h2>Message history</h2>
              <ol className="timeline">
                {history.data.messages.map(message => (
                  <li key={message.id} className={message.direction}>
                    <p className="small muted">{message.direction === 'inbound' ? 'Your reply' : 'Clinic reminder'} · {instantLabel(message.created_at, timezone)}</p>
                    <p>{message.body}</p>
                  </li>
                ))}
              </ol>
            </section>
          ) : <p>No simulated {channel === 'email' ? 'emails' : 'text messages'} for this patient yet.</p>}
        </>
      )}
      <form className="panel inset reply-form" onSubmit={send}>
        <label>Your reply<textarea value={draft} maxLength={500} rows={3} placeholder="Type your reply" required onChange={event => {
          setDraft(event.target.value)
          setEventId(crypto.randomUUID())
        }} /></label>
        {error && <Alert message={error} />}
        {notice && <p className="feedback" role="status">{notice}</p>}
        <button className="primary" disabled={busy || !history.data || !draft.trim()}>{busy ? 'Sending…' : 'Send reply'}</button>
      </form>
    </>
  )
}
