import { useState } from 'react'
import type { FormEvent } from 'react'
import { errorMessage, jsonBody, request, useQuery } from './api'
import { instantLabel, localClock, shortDate } from './dates'
import { Alert, Loading, Pill, SyncStatus } from './layout'
import { VisitTable } from './VisitTable'
import { contactLabels, workLabels } from './types'
import type { ContactField, ContactValue, DetailedItem, Patient, PatientRecord, Session } from './types'

type Detail = { kind: 'patient' | 'item'; id: number }
const outcomes = {
  attempted: 'Contact attempted', confirmed: 'Confirmed', rescheduled: 'Rescheduled', canceled: 'Canceled', reviewed: 'Reviewed',
}
type FollowUpOutcome = keyof typeof outcomes

export function PatientDetail({ base, detail, session, onBack }: {
  base: string; detail: Detail; session: Session; onBack: () => void
}) {
  const [tab, setTab] = useState('Follow-up')
  const [notice, setNotice] = useState('')
  const path = base + (detail.kind === 'patient' ? '/patients/' : '/work_items/') + detail.id
  const query = useQuery<PatientRecord>(path, session.token)
  const record = query.data

  function saved(message: string) {
    setNotice(message)
    query.refresh()
  }

  return (
    <>
      <button className="back-link" onClick={onBack}>← Back to {detail.kind === 'item' ? 'patient flow' : 'appointments'}</button>
      {query.loading && <Loading />}
      {query.error && <><Alert message={query.error} /><button onClick={query.refresh}>Retry</button></>}
      {notice && <p role="status" className="feedback">{notice}</p>}
      {record && (
        <>
          <p className="clinic-label">{session.clinic.name}</p>
          <h1>{record.patient?.name ?? 'Unmatched reply'}</h1>
          <SyncStatus clinic={record.clinic} />
          <div className={'detail-grid' + (record.patient ? '' : ' single')}>
            {record.patient && <Contacts key={record.patient.id} patient={record.patient} base={base} token={session.token} onSaved={saved} />}
            <section className="detail-main">
              <div className="tabs" aria-label="Patient information">
                {['Follow-up', 'Appointments', 'Activity log'].map(label => (
                  <button key={label} aria-pressed={tab === label} onClick={() => setTab(label)}>{label}</button>
                ))}
              </div>
              {tab === 'Follow-up' && (
                <FollowUpList items={record.items} selected={detail.kind === 'item' ? detail.id : undefined}
                  base={base} session={session} timezone={record.clinic.timezone} onSaved={saved} />
              )}
              {tab === 'Appointments' && <section className="panel inset"><VisitTable visits={record.visits} /></section>}
              {tab === 'Activity log' && (
                <section className="panel inset">
                  <h2>Activity log</h2>
                  {record.activity.length === 0 && <p className="muted">No staff activity recorded.</p>}
                  <ul className="activity-list">
                    {record.activity.map(entry => (
                      <li key={entry.id}>
                        <strong>{entry.staff}</strong><span className="muted small"> {instantLabel(entry.created_at, record.clinic.timezone)}</span>
                        <p>{entry.note}</p>
                        {entry.details.field && <p className="small muted">{contactLabels[entry.details.field]}: {entry.details.previous || 'No value'} → {entry.details.value || 'No value'}</p>}
                      </li>
                    ))}
                  </ul>
                </section>
              )}
            </section>
          </div>
        </>
      )}
    </>
  )
}

function Contacts({ patient, base, token, onSaved }: {
  patient: Patient; base: string; token: string; onSaved: (message: string) => void
}) {
  const [editing, setEditing] = useState<ContactField>()
  const fields = Object.keys(contactLabels) as ContactField[]

  return (
    <aside className="panel inset contact-panel">
      <h2>Patient details</h2>
      {fields.map(field => {
        const entry = patient.fields[field]
        return (
          <div className="contact-row" key={field}>
            <div className="contact-head">
              <span className="muted small">{contactLabels[field]}</span>
              {editing !== field && <button className="text-action small" onClick={() => setEditing(field)}>Verify <span className="sr-only">{contactLabels[field]}</span></button>}
            </div>
            <strong>{(entry.verified?.value ?? entry.source) || 'No value on file'}</strong>
            <Pill tone={entry.conflict ? 'amber' : entry.verified ? 'green' : 'neutral'}>
              {entry.conflict ? 'PMS conflict' : entry.verified ? 'Verified' : 'Unverified'}
            </Pill>
            {entry.verified && <p className="muted small">PMS value {entry.source || 'unavailable'}</p>}
            {editing === field && (
              <ContactForm field={field} entry={entry} path={base + '/patients/' + patient.id + '/contact_verifications/' + field}
                token={token} onCancel={() => setEditing(undefined)} onSaved={onSaved} />
            )}
          </div>
        )
      })}
    </aside>
  )
}

function ContactForm({ field, entry, path, token, onCancel, onSaved }: {
  field: ContactField; entry: ContactValue; path: string; token: string; onCancel: () => void; onSaved: (message: string) => void
}) {
  const [value, setValue] = useState(entry.verified?.value ?? entry.source ?? '')
  const [key, setKey] = useState(() => crypto.randomUUID())
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  function edit(next: string) {
    setValue(next)
    setKey(crypto.randomUUID())
  }

  async function save(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    setError('')
    try {
      await request(path, jsonBody('PATCH', { value, request_key: key }), token)
      onSaved(contactLabels[field] + ' verified.')
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setBusy(false)
    }
  }

  return (
    <form className="contact-editor" onSubmit={save}>
      <label>Verified {contactLabels[field].toLowerCase()}
        {field === 'preferred_language' ? (
          <select value={value} onChange={event => edit(event.target.value)} required>
            <option value="">Choose language</option>
            {value && value !== 'en' && value !== 'es' && <option value={value}>Current: {value}</option>}
            <option value="en">English</option><option value="es">Spanish</option>
          </select>
        ) : (
          <input type={field === 'birthdate' ? 'date' : field === 'email' ? 'email' : 'tel'}
            value={value} onChange={event => edit(event.target.value)} required={field === 'birthdate'} />
        )}
      </label>
      {error && <Alert message={error} />}
      <div className="actions">
        <button className="primary" disabled={busy}>{busy ? 'Saving…' : 'Save verification'}</button>
        <button type="button" onClick={onCancel} disabled={busy}>Cancel</button>
      </div>
    </form>
  )
}

function FollowUpList({ items, selected, base, session, timezone, onSaved }: {
  items: DetailedItem[]; selected?: number; base: string; session: Session; timezone: string; onSaved: (message: string) => void
}) {
  const open = items.filter(item => !item.resolved_at)
  const resolved = items.filter(item => item.resolved_at)

  return (
    <section className="panel inset">
      <h2>Follow-up items</h2>
      {!open.length && <p className="muted">No open follow-up items.</p>}
      {open.map((item, index) => (
        <details key={item.id} className="case" open={selected ? selected === item.id : index === 0}>
          <summary>{workLabels[item.kind] ?? item.kind}{item.assignee && <span className="muted"> · {item.assignee}</span>}</summary>
          <p>{item.reason}</p>
          {item.message && <blockquote>{item.message}</blockquote>}
          <FollowUpForm item={item} path={base + '/work_items/' + item.id} session={session} onSaved={onSaved} />
        </details>
      ))}
      {resolved.length > 0 && (
        <details className="case" open={resolved.some(item => item.id === selected)}>
          <summary>Resolved follow-up records ({resolved.length})</summary>
          <ul className="activity-list">
            {resolved.map(item => (
              <li key={item.id}>
                <strong>{workLabels[item.kind] ?? item.kind}</strong>
                <p>{item.reason}</p>
                {item.resolved_at && <p className="muted small">Resolved {instantLabel(item.resolved_at, timezone)}</p>}
              </li>
            ))}
          </ul>
        </details>
      )}
    </section>
  )
}

function FollowUpForm({ item, path, session, onSaved }: {
  item: DetailedItem; path: string; session: Session; onSaved: (message: string) => void
}) {
  const [outcome, setOutcome] = useState<FollowUpOutcome>('attempted')
  const [note, setNote] = useState('')
  const [targets, setTargets] = useState<number[]>([])
  const [key, setKey] = useState(() => crypto.randomUUID())
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const review = item.kind === 'reply_review'
  const needsTargets = review && outcome !== 'attempted' && outcome !== 'reviewed'
  const someoneElse = item.assignee && item.assignee !== session.staff

  async function submit(event: FormEvent) {
    event.preventDefault()
    await save(path + '/follow_ups', jsonBody('POST', {
      outcome, note, target_ids: needsTargets ? targets : [], request_key: key,
    }), 'Follow-up saved.')
  }

  async function save(endpoint: string, options: RequestInit, message: string) {
    setBusy(true)
    setError('')
    try {
      await request(endpoint, options, session.token)
      onSaved(message)
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setBusy(false)
    }
  }

  if (someoneElse) return <p className="muted">Assigned to {item.assignee}.</p>

  return (
    <>
      {item.assignee ? <p className="muted small">Assigned to {item.assignee}</p> : (
        <button className="primary" disabled={busy} onClick={() => save(path, { method: 'PATCH' }, 'Assigned to ' + session.staff + '.')}>
          Assign to me
        </button>
      )}
      <form className="follow-up-form" onSubmit={submit}>
        <label>Follow-up outcome
          <select value={outcome} onChange={event => {
            setOutcome(event.target.value as FollowUpOutcome)
            setKey(crypto.randomUUID())
          }}>
            {(Object.keys(outcomes) as FollowUpOutcome[])
              .filter(choice => choice === 'attempted' || (choice === 'reviewed' ? review : !review || item.candidates.length > 0))
              .map(choice => <option value={choice} key={choice}>{outcomes[choice]}</option>)}
          </select>
        </label>
        {needsTargets && (
          <fieldset>
            <legend>Verified appointments</legend>
            {item.candidates.map(visit => (
              <label className="checkbox" key={visit.id}>
                <input type="checkbox" checked={targets.includes(visit.id)} onChange={event => {
                  setTargets(event.target.checked ? [...targets, visit.id] : targets.filter(id => id !== visit.id))
                  setKey(crypto.randomUUID())
                }} />
                {visit.patient_name} · {shortDate(visit.wall_time.slice(0, 10))} · {localClock(visit.wall_time)}
              </label>
            ))}
          </fieldset>
        )}
        <label>Note<textarea value={note} required maxLength={500} rows={3} onChange={event => {
          setNote(event.target.value)
          setKey(crypto.randomUUID())
        }} /></label>
        {error && <Alert message={error} />}
        <button className="primary" disabled={busy || (needsTargets && !targets.length)}>
          {busy ? 'Saving…' : 'Save follow-up'}
        </button>
      </form>
    </>
  )
}
