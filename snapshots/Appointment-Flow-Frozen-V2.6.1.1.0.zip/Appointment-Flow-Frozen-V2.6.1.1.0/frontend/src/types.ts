export type Clinic = { id: number; name: string; state: string | null; staff: string[] }
export type Session = { clinic: Clinic; staff: string; token: string }
export type ClinicView = {
  id: number
  name: string
  timezone: string
  today: string
  last_synced_at: string | null
}
export type Visit = {
  id: number
  appointment_id: number
  patient_id: number
  patient_name: string
  wall_time: string
  source_status: string
  response: string
  provider_name: string | null
  length_minutes: number | null
  needs_review?: boolean
}
export type WorkItem = {
  id: number
  patient_id: number | null
  patient_name: string | null
  kind: string
  reason: string
  assignee: string | null
  resolved_at: string | null
  created_at: string
  visit_time: string | null
}
export type DetailedItem = WorkItem & { message: string | null; candidates: Visit[] }
export type ContactField = 'birthdate' | 'wireless_phone' | 'email' | 'preferred_language'
export type ContactValue = {
  source: string | null
  verified: { value: string; source: string | null; verified_by: string; verified_at: string } | null
  conflict: boolean
}
export type Patient = { id: number; name: string; fields: Record<ContactField, ContactValue> }
export type StaffActivity = {
  id: number
  staff: string
  outcome: string
  note: string
  created_at: string
  details: { field?: ContactField; previous?: string | null; value?: string }
}
export type PatientRecord = {
  clinic: ClinicView
  patient: Patient | null
  items: DetailedItem[]
  visits: Visit[]
  activity: StaffActivity[]
}

export const workLabels: Record<string, string> = {
  no_reply: 'No confirmation', contact_hold: 'Contact hold',
  delivery_failed: 'Delivery failed', reply_review: 'Reply to review',
}
export const responseLabels: Record<string, string> = {
  confirmed: 'Confirmed', unconfirmed: 'Unconfirmed', rescheduled: 'Rescheduled by staff',
  canceled: 'Canceled by staff',
}
export const outcomeLabels: Record<string, string> = {
  scheduled: 'Scheduled', complete: 'Completed', broken: 'Broken', unscheduled: 'Unscheduled',
}
export const contactLabels: Record<ContactField, string> = {
  birthdate: 'Birthdate', wireless_phone: 'Mobile phone', email: 'Email', preferred_language: 'Preferred language',
}
