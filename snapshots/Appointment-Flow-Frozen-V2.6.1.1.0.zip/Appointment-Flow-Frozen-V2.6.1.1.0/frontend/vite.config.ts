import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    port: 4178,
    strictPort: true,
    proxy: { '/api': 'http://127.0.0.1:3000' },
  },
  preview: {
    host: '127.0.0.1',
    port: 4178,
    strictPort: true,
    proxy: { '/api': 'http://127.0.0.1:3000' },
  },
})
