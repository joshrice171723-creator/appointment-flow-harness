# Architecture

One Rails process serves the React workspace and its JSON API. PostgreSQL keeps the supplied PMS tables and app-owned state in the same demo database. Runtime code reads the PMS models. Seeds and tests use separate source fixture writers.

```mermaid
flowchart LR
  UI["React workspaces"] --> API["Rails JSON controllers"]
  CLI["Reminder rake task"] --> Batch["Reminder run"]
  API --> Refresh["Clinic snapshot refresh"]
  API --> Batch
  API --> Reply["Reply and follow-up workflows"]
  Refresh --> PMS["PMS clinics, patients, appointments"]
  Refresh --> Local["Office, visit revision and audit"]
  Batch --> Refresh
  Batch --> Fake["Fake text and email receipts"]
  Fake --> Local
  Reply --> PMS
  Reply --> Local
  API --> Report["Clinic aggregate outcomes"]
  Report --> PMS
  Report --> Local
```

## Appointment and reply lifecycle

```mermaid
flowchart TD
  A["Scheduled visit revision"] --> B["Eligible fake reminder"]
  A --> H["Contact or time hold"]
  B --> C["Clear YES tied to current recipient and revision"]
  C --> D["Confirmed"]
  B --> R["Late, conflicting, or ambiguous reply"]
  R --> F["Staff review"]
  B --> S["Exact STOP stores an SMS opt-out"]
  A --> V["PMS moves visit or changes patient"]
  D --> V
  V --> A
  A --> X["PMS ends visit or staff records canceled or rescheduled"]
  D --> X
```

### Persistence and ownership

- **Clinic refresh** reads eligible source rows in one statement, compares them with the projection, and bulk-upserts changes in a transaction. It increments the revision on a changed source appointment time or patient, or when a visit reopens. The successful watermark commits with the projection. Appointment status and confirmation remain separate.
- **Reminder runs** require a successful refresh. A clinic lock serializes send decisions with replies and staff edits. Before creating fake receipts, the batch checks the planned appointments against the current PMS rows. A unique index covers visit, revision, step and channel. The fake receipt and associated task updates commit together. The recipient directory compares normalized destination ownership across the PMS and the clinic’s verified values. The external replica can lag source changes by about five minutes.
- **Replies** name an accepted delivery from the selected patient's simulated inbox. Each event key belongs to one clinic. The workflow compares the delivery with the current visit, the live source and the current contact details before a YES can confirm. A historical message remains with its original patient. An SMS STOP can apply to an old message's destination.
- **Staff follow-up** validates clinic ownership, assignment, the form’s visit revisions and current source identity. Multi-selection requires explicit human identification of each candidate. Local updates commit with the audit event. Contact verification compares the form’s contact revision with current raw and verified values and records which source value the staff member reviewed.
- **Leadership** counts PMS and app activity using clinic and month scopes. Responses contain clinic names, counts, and rates. Patient details and message history use separate, role-scoped endpoints.
