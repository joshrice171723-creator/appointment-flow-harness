# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_11_16_000004) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "appointments", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "clinic_id", null: false
    t.text "provider_name"
    t.datetime "start_at", precision: nil, null: false
    t.integer "length_minutes"
    t.text "procedure_note"
    t.text "status", null: false
    t.datetime "updated_at", precision: nil
    t.index ["clinic_id", "start_at"], name: "index_appointments_on_clinic_id_and_start_at"
    t.index ["patient_id"], name: "index_appointments_on_patient_id"
  end

  create_table "clinics", force: :cascade do |t|
    t.text "name", null: false
    t.text "address_line"
    t.text "city"
    t.string "state", limit: 2
    t.text "phone"
  end

  create_table "contact_verifications", force: :cascade do |t|
    t.bigint "office_id", null: false
    t.bigint "patient_id", null: false
    t.jsonb "verified_values", default: {}, null: false
    t.jsonb "source_values", default: {}, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["office_id", "patient_id"], name: "index_contact_verifications_on_office_id_and_patient_id", unique: true
  end

  create_table "deliveries", force: :cascade do |t|
    t.bigint "visit_id", null: false
    t.bigint "patient_id", null: false
    t.integer "revision", null: false
    t.string "stage", null: false
    t.string "channel", null: false
    t.string "destination", null: false
    t.boolean "successful", null: false
    t.boolean "asks_confirmation", null: false
    t.text "body", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["created_at"], name: "index_deliveries_on_created_at"
    t.index ["patient_id", "channel", "created_at"], name: "index_deliveries_on_patient_id_and_channel_and_created_at"
    t.index ["visit_id", "revision", "stage", "channel"], name: "idx_on_visit_id_revision_stage_channel_0b1b006b7c", unique: true
  end

  create_table "offices", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.string "time_zone", null: false
    t.string "staff_names", default: [], null: false, array: true
    t.datetime "refreshed_at"
    t.index ["clinic_id"], name: "index_offices_on_clinic_id", unique: true
  end

  create_table "patients", force: :cascade do |t|
    t.text "first_name", null: false
    t.text "last_name", null: false
    t.date "birthdate"
    t.text "wireless_phone"
    t.text "email"
    t.text "preferred_language"
    t.bigint "guarantor_id"
    t.index ["guarantor_id"], name: "index_patients_on_guarantor_id"
  end

  create_table "replies", force: :cascade do |t|
    t.bigint "office_id", null: false
    t.bigint "delivery_id", null: false
    t.string "event_key", null: false
    t.text "body", null: false
    t.string "result", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["delivery_id"], name: "index_replies_on_delivery_id"
    t.index ["office_id", "event_key"], name: "index_replies_on_office_id_and_event_key", unique: true
  end

  create_table "sms_opt_outs", force: :cascade do |t|
    t.bigint "office_id", null: false
    t.string "destination", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["office_id", "destination"], name: "index_sms_opt_outs_on_office_id_and_destination", unique: true
  end

  create_table "staff_events", force: :cascade do |t|
    t.bigint "office_id", null: false
    t.bigint "visit_id"
    t.bigint "work_item_id"
    t.bigint "patient_id", null: false
    t.string "staff_name", null: false
    t.string "event_key", null: false
    t.string "outcome", null: false
    t.text "note", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.jsonb "details", default: {}, null: false
    t.index ["office_id", "event_key"], name: "index_staff_events_on_office_id_and_event_key", unique: true
    t.index ["office_id", "patient_id", "created_at"], name: "index_staff_events_on_office_id_and_patient_id_and_created_at"
    t.index ["visit_id"], name: "index_staff_events_on_visit_id"
    t.index ["work_item_id"], name: "index_staff_events_on_work_item_id"
  end

  create_table "visits", force: :cascade do |t|
    t.bigint "office_id", null: false
    t.bigint "source_id", null: false
    t.bigint "patient_id", null: false
    t.datetime "source_start_at", precision: nil, null: false
    t.datetime "starts_at"
    t.string "status", null: false
    t.string "provider_name"
    t.integer "length_minutes"
    t.integer "revision", default: 1, null: false
    t.datetime "confirmed_at"
    t.string "disposition"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.date "source_date", null: false
    t.index ["office_id", "patient_id", "source_start_at"], name: "index_visits_on_office_id_and_patient_id_and_source_start_at"
    t.index ["office_id", "source_date"], name: "index_visits_on_office_id_and_source_date"
    t.index ["office_id", "source_id"], name: "index_visits_on_office_id_and_source_id", unique: true
    t.index ["office_id", "source_start_at"], name: "index_visits_on_office_id_and_source_start_at"
    t.index ["office_id", "status", "starts_at"], name: "index_visits_on_office_id_and_status_and_starts_at"
  end

  create_table "work_items", force: :cascade do |t|
    t.bigint "visit_id", null: false
    t.integer "revision", null: false
    t.string "key", null: false
    t.string "kind", null: false
    t.string "state", default: "needs_attention", null: false
    t.string "assignee"
    t.text "reason", null: false
    t.bigint "reply_id"
    t.bigint "candidate_visit_ids", default: [], null: false, array: true
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["reply_id"], name: "index_work_items_on_reply_id"
    t.index ["state", "kind"], name: "index_work_items_on_state_and_kind"
    t.index ["visit_id", "revision", "key"], name: "index_work_items_on_visit_id_and_revision_and_key", unique: true
  end

  add_foreign_key "appointments", "clinics"
  add_foreign_key "appointments", "patients"
  add_foreign_key "contact_verifications", "offices"
  add_foreign_key "deliveries", "visits"
  add_foreign_key "patients", "patients", column: "guarantor_id"
  add_foreign_key "replies", "deliveries"
  add_foreign_key "replies", "offices"
  add_foreign_key "sms_opt_outs", "offices"
  add_foreign_key "staff_events", "offices"
  add_foreign_key "staff_events", "visits"
  add_foreign_key "staff_events", "work_items"
  add_foreign_key "visits", "offices"
  add_foreign_key "work_items", "replies"
  add_foreign_key "work_items", "visits"
end
