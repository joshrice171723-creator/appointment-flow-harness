# Fixture writers are used only by db:seed. The runtime PMS models are read-only.
module DemoPms
  class Clinic < ApplicationRecord
    self.table_name = "clinics"
  end

  class Patient < ApplicationRecord
    self.table_name = "patients"
  end

  class Appointment < ApplicationRecord
    self.table_name = "appointments"
  end
end

[
  [ 101, "Austin", "TX", "America/Chicago", "512", [ "Robin Shaw", "Casey Fields" ] ],
  [ 102, "Phoenix", "AZ", "America/Phoenix", "480", [ "Jordan Rivers", "Avery Wells" ] ]
].each do |id, city, state, zone, area, staff|
  DemoPms::Clinic.find_or_create_by!(id: id) do |clinic|
    clinic.assign_attributes(name: "#{city}, #{state}", city: city, state: state, phone: "#{area}-555-0100")
  end
  office = Office.find_or_create_by!(clinic_id: id) { |record| record.assign_attributes(time_zone: zone, staff_names: staff) }
  offset = id * 100
  today = Time.current.in_time_zone(office.zone).to_date
  scenarios = [
    [ "Mara", "Lin", 7, "0101", "en", true ],
    [ "Elias", "Reed", 7, nil, "en", true ],
    [ "Nora", "Ibarra", 3, "0103", "es", true ],
    [ "Ari", "Quinn", 1, "0104", "en", false ],
    [ "Jules", "Hart", 7, "0199", "en", true ],
    [ "Wren", "Bell", 1, "0106", "en", true ],
    [ "Sage", "Bell", 2, "0106", "en", true ],
    [ "River", "Cole", 0, "0108", "en", true ]
  ]
  scenarios.each_with_index do |(first, last, days, suffix, language, adult), index|
    seed_id = offset + index + 1
    DemoPms::Patient.find_or_create_by!(id: seed_id) do |patient|
      patient.assign_attributes(first_name: first, last_name: last,
        birthdate: adult ? Date.new(1988, 3, 12) : (today << 120),
        wireless_phone: suffix && "#{area}-555-#{suffix}",
        email: [ 5, 6 ].include?(index) ? nil : "#{first.downcase}.#{id}@example.invalid",
        preferred_language: language)
    end
    date = today + days
    DemoPms::Appointment.find_or_create_by!(id: seed_id) do |appointment|
      appointment.assign_attributes(clinic_id: id, patient_id: seed_id, provider_name: "Dr. Devon Finch",
        start_at: Time.utc(date.year, date.month, date.day, 16, index * 5),
        length_minutes: 45, status: "scheduled", updated_at: Time.current)
    end
  end

  (1..44).each do |index|
    date = today - index
    DemoPms::Appointment.find_or_create_by!(id: offset + 30 + index) do |appointment|
      status = index % (id == 101 ? 6 : 4) == 0 ? "broken" : "complete"
      appointment.assign_attributes(clinic_id: id, patient_id: offset + (index % scenarios.length) + 1,
        provider_name: "Dr. Devon Finch", start_at: Time.utc(date.year, date.month, date.day, 13),
        length_minutes: 40, status: status, updated_at: Time.current)
    end
  end

  next if office.refreshed_at

  demo_noon = office.zone.local(today.year, today.month, today.day, 12)
  ReminderRun.new(office, now: demo_noon).call
  delivery = office.deliveries.accepted.find_by(patient_id: offset + 3)
  if delivery
    RecordReply.new(office, patient_id: delivery.patient_id, delivery_id: delivery.id,
      body: "YES", event_key: "seed-confirmation", now: demo_noon).call
  end
end
