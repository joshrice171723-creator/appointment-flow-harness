class CreatePmsReplica < ActiveRecord::Migration[8.1]
  def change
    create_table :clinics do |t|
      t.text :name, null: false
      t.text :address_line
      t.text :city
      t.column :state, "character(2)"
      t.text :phone
    end

    create_table :patients do |t|
      t.text :first_name, null: false
      t.text :last_name, null: false
      t.date :birthdate
      t.text :wireless_phone
      t.text :email
      t.text :preferred_language
      t.references :guarantor, foreign_key: { to_table: :patients }
    end

    create_table :appointments do |t|
      t.references :patient, null: false, foreign_key: true
      t.references :clinic, null: false, foreign_key: true, index: false
      t.text :provider_name
      t.column :start_at, :timestamp, null: false
      t.integer :length_minutes
      t.text :procedure_note
      t.text :status, null: false
      t.column :updated_at, :timestamp
      t.index %i[clinic_id start_at]
    end
  end
end
