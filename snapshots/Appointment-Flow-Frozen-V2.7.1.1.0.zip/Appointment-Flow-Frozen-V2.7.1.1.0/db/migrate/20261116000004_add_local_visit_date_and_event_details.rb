class AddLocalVisitDateAndEventDetails < ActiveRecord::Migration[8.1]
  class Projection < ActiveRecord::Base
    self.table_name = "visits"
  end

  def up
    add_column :visits, :source_date, :date
    Projection.reset_column_information
    Projection.find_each do |visit|
      visit.update_columns(source_date: visit.source_start_at.to_date)
    end
    change_column_null :visits, :source_date, false
    add_index :visits, %i[office_id source_date]
    add_column :staff_events, :details, :jsonb, null: false, default: {}
  end

  def down
    remove_column :staff_events, :details
    remove_column :visits, :source_date
  end
end
