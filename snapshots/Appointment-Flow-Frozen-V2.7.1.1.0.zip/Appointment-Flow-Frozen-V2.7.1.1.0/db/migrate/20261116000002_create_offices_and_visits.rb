class CreateOfficesAndVisits < ActiveRecord::Migration[8.1]
  def change
    create_table :offices do |t|
      t.bigint :clinic_id, null: false, index: { unique: true }
      t.string :time_zone, null: false
      t.string :staff_names, array: true, null: false, default: []
      t.datetime :refreshed_at
    end

    create_table :visits do |t|
      t.references :office, null: false, foreign_key: true, index: false
      t.bigint :source_id, null: false
      t.bigint :patient_id, null: false
      t.column :source_start_at, :timestamp, null: false
      t.datetime :starts_at
      t.string :status, null: false
      t.string :provider_name
      t.integer :length_minutes
      t.integer :revision, null: false, default: 1
      t.datetime :confirmed_at
      t.string :disposition
      t.timestamps
      t.index %i[office_id source_id], unique: true
      t.index %i[office_id source_start_at]
      t.index %i[office_id status starts_at]
      t.index %i[office_id patient_id source_start_at]
    end
  end
end
