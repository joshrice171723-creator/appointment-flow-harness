class CreateOutreachRecords < ActiveRecord::Migration[8.1]
  def change
    create_table :deliveries do |t|
      t.references :visit, null: false, foreign_key: true, index: false
      t.bigint :patient_id, null: false
      t.integer :revision, null: false
      t.string :stage, null: false
      t.string :channel, null: false
      t.string :destination, null: false
      t.boolean :successful, null: false
      t.boolean :asks_confirmation, null: false
      t.text :body, null: false
      t.timestamps
      t.index %i[visit_id revision stage channel], unique: true
      t.index %i[patient_id channel created_at]
      t.index :created_at
    end

    create_table :replies do |t|
      t.references :office, null: false, foreign_key: true, index: false
      t.references :delivery, null: false, foreign_key: true
      t.string :event_key, null: false
      t.text :body, null: false
      t.string :result, null: false
      t.timestamps
      t.index %i[office_id event_key], unique: true
    end

    create_table :sms_opt_outs do |t|
      t.references :office, null: false, foreign_key: true, index: false
      t.string :destination, null: false
      t.timestamps
      t.index %i[office_id destination], unique: true
    end

    create_table :contact_verifications do |t|
      t.references :office, null: false, foreign_key: true, index: false
      t.bigint :patient_id, null: false
      t.jsonb :verified_values, null: false, default: {}
      t.jsonb :source_values, null: false, default: {}
      t.timestamps
      t.index %i[office_id patient_id], unique: true
    end

    create_table :work_items do |t|
      t.references :visit, null: false, foreign_key: true, index: false
      t.integer :revision, null: false
      t.string :key, null: false
      t.string :kind, null: false
      t.string :state, null: false, default: "needs_attention"
      t.string :assignee
      t.text :reason, null: false
      t.references :reply, foreign_key: true
      t.bigint :candidate_visit_ids, array: true, null: false, default: []
      t.timestamps
      t.index %i[visit_id revision key], unique: true
      t.index %i[state kind]
    end

    create_table :staff_events do |t|
      t.references :office, null: false, foreign_key: true, index: false
      t.references :visit, foreign_key: true
      t.references :work_item, foreign_key: true
      t.bigint :patient_id, null: false
      t.string :staff_name, null: false
      t.string :event_key, null: false
      t.string :outcome, null: false
      t.text :note, null: false
      t.timestamps
      t.index %i[office_id event_key], unique: true
      t.index %i[office_id patient_id created_at]
    end
  end
end
