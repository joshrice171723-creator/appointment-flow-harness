# Apex technical review

## Round 1 · `5fefe7d` · REVISE

An independent Codex agent worked from a detached checkout and its own PostgreSQL test database. Its full Rails run passed 22 tests and 241 assertions. It then challenged paths the passing suite did not exercise through the actual HTTP endpoints.

| Criterion | Grade | Evidence |
| --- | --- | --- |
| Required behavior | UNVERIFIED | The clinic refresh, fake delivery and inbound reply routes passed Rails integration checks. The first browser run timed out on clinic selection. Its trace showed the desktop test selected the landing page control before the workspace transition and the narrow test used an exact label locator that missed the combobox. |
| Safety and data boundaries | REVISE | Four independent reproductions found that a stale staff appointment form confirmed revision 2, a stale shared-contact candidate confirmed revision 2, a stale contact form caused a real fake send to the prior mobile, and a source move after the refresh watermark still allowed a fake send with the old time. The review also traced two distinct clinic corrections that could claim the same address and be treated as unique. |
| Performance and Rails queries | REVISE | The independent run held appointment reads at 8 statements, 31 read rows and 27 models after unrelated growth, and refresh at 6 statements, 4 read rows and 3 models. Inbox loading could still instantiate every reply linked to its 25 receipts. |
| Material workflow coverage | REVISE | Baseline tests covered source refresh, SMS/email, replies and opt-out, staff contact and outcome saves, clinic isolation, and leadership. The independent stale writes and source interleave needed focused HTTP coverage. |
| Human readability | PASS | Rails routes led to focused controllers, with transaction owners in `RefreshVisits`, `ReminderRun`, `RecordReply`, `RecordFollowUp` and `VerifyContact`. The reminder window is defined in `ReminderRun::SEND_WINDOW`. |
| Ease of change | UNVERIFIED | The disposable rule edit had yet to run. |
| Failure and transaction behavior | PASS | The independent test submitted an otherwise valid contact edit with a 101-character event key. The real PATCH returned 422 after audit validation failed. Zero verification and audit rows persisted, and the source phone retained its value. The reminder test proved rollback after the first fake receipt and the parallel test proved one accepted delivery. |
| Verification and handoff | UNVERIFIED | An empty database served the root and empty workspace. The seeded Ruby launcher served HTTP 200. The final gate and corrected browser run were pending. |

The independent reviewer also traced two usability and data representation issues. A selected older work item could fall outside the fixed patient detail window. Numeric JSON could round distinct source BIGINT identifiers in the browser. The repair prioritizes the selected record inside the clinic scope and uses decimal strings for source patient IDs. The inbox now reads 25 accepted messages and up to 50 recent replies per channel view.

The safety repairs bind staff writes to the revisions shown in the form, compare contact edits with the raw and verified data last reviewed, recheck all planned appointments in a single source query before fake delivery, and evaluate ownership claims from verified corrections across clinics.

## Round 2 · PASS

Application revision `77787d714397e6eb0eefe1d9c91cd7ce0b15de61`. Final gate revision `340aafcc94a57e0e26e858dc536c74ed49068d7b` changed only the Ruby style check paths. The browser and independent test evidence applies to the same application source.

The independent reviewer replayed the original form snapshots and source interleave through the repaired HTTP routes in a detached worktree with an isolated test database. The replay exited successfully.

| Challenged path | Observed result |
| --- | --- |
| Direct staff confirmation from a pre-refresh form | HTTP 409. Revision 2 stayed unconfirmed and there was no audit event. |
| Selection of a shared-contact sibling whose visit moved | HTTP 409. Revision 2 stayed unconfirmed and the review task stayed open. |
| Verification after the raw phone changed | HTTP 409 with no verification or audit write. A subsequent valid run used the latest synthetic source phone. |
| Source start moved into the past as refresh wrote its watermark | HTTP 409 with zero fake receipts. |
| Two clinics verified one address for different patients | Each clinic opened one hold and both sent zero reminders. |
| Verification followed by audit validation failure | HTTP 422. Both local writes rolled back and the original phone retained its value. |

### Workload evidence

The synchronous probe measured complete HTTP calls, including lock and transaction work, with fixture setup outside the timed blocks. Counts are for returned rows and instantiated models. Elapsed times are single, noisy Windows observations and are included to show the conditions of the run.

| Caller and input | Statements | Read rows | Models | Direct writes | Time |
| --- | ---: | ---: | ---: | ---: | ---: |
| Refresh retry, one tracked visit | 6 | 4 | 3 | 0 | 77 ms |
| Refresh retry, 1,000 unrelated source appointments added | 6 | 4 | 3 | 0 | 78 ms |
| Appointments, 32 matching visits, first page | 8 | 31 | 27 | 0 | 128 ms |
| Same appointment response, 400 other date/clinic visits added | 8 | 31 | 27 | 0 | 2,337 ms |
| Reminder run, one eligible send | 20 | 10 | 8 | 1 | 2,283 ms |
| Reminder run, 70 candidates with 69 new eligible sends | 90 | 354 | 214 | 70 | 8,025 ms |
| Reminder retry, 70 candidates with existing receipts | 12 | 283 | 213 | 0 | 782 ms |
| Independent reminder, one eligible send and 5,000 unrelated source patients added | 20 | 5,011 | 8 | 1 | 864 ms |

The independent base used 11 read rows, 20 statements, eight models and one write in 99 ms. The extra rows came from the three-column recipient-ownership scan. The PMS schema provides neither a normalized address index nor a contact change watermark. The full read preserves detection of differently formatted shared contacts. It runs only when the batch has sends to consider. The measured retry skipped that scan, recipient model loading and all writes. The 69 new sends used one bulk projection upsert and 69 fake receipt writes. The appointment endpoint retained its totals, 25-row page, and bounded association reads. PostgreSQL chose the projected office/date index for that day query. The tiny PMS sample chose a sequential scan for the clinic-time predicate.

The first final gate reported bracket spacing in two expressions in the packaged workload probe. The app Ruby style check now names its application, configuration, startup, migration, seed and test paths. The supplied probe retains its original content.

### Running behavior

- The isolated migration-only database served the root and an empty workspace. The documented launcher built assets, seeded two fictional clinics and started Puma. The Edge desktop smoke confirmed Austin SMS and email replies, observed confirmation in the staff calendar, recorded and reloaded a staff note, and loaded aggregate leadership activity. A 390 px Phoenix smoke verified workspace navigation and page width. Both scenarios passed.
- The documented reminder task was run for Austin at the simulated local date November 20, 2026 at noon. It reported one accepted fake delivery, one simulated failure and zero additional tasks.

### Disposable rule change

A detached copy of `77787d7` used its own empty, schema-only test database. The exercise changed the opening hour from 10:00 to 11:00 in `app/services/reminder_run.rb`. Through the reminder HTTP endpoint, the modified test checked zero sends at 09:00 and 10:00 and one at 11:00. The neighboring test advanced the clock during a two-visit batch and verified that the second visit received zero deliveries at its start time. Two tests and 20 assertions passed. Only the reminder service needed a production rule edit. The detached change is outside the submitted Git history.

### Criterion grades

| Criterion | Grade | Evidence on the repaired application |
| --- | --- | --- |
| Required behavior | PASS | The normal reminder API and Rake caller selected upcoming visits. Fake delivery receipts were visible in the demo inbox. The Edge desktop check observed SMS and email replies confirm, the staff calendar update and a saved follow-up appear in activity. The narrow test exercised the Phoenix staff entry. |
| Safety and data boundaries | PASS | The independent probes above rejected stale or ambiguous writes, prevented a send after the source interleave and held a corrected shared destination. `outreach_test.rb` verifies reply binding, stale and late replies, opt-outs, contact holds and real-window cutoff. `refreshes_test.rb` asserts source instance write rejection and Austin/Phoenix DST rules. `staff_workspaces_test.rb` rejects cross-clinic staff access and checks the full leadership response for identifying fields and values. |
| Performance and Rails queries | PASS | The workload rows above cover unrelated and eligible growth, retries, data and write counts, and an actual query plan. Active Record filters and aggregates stay scoped. Staff query limits and the inbox reply cap are exercised through HTTP. |
| Material workflow coverage | PASS | The independent review traced workspace selection, source refresh, reminder CLI/API, inbox and reply, staff appointment and board reads, assignment, multi-visit follow-up, verification, and leadership outcomes. Each write has a real caller and a rejection check. The HTTP and browser evidence covers F1–F6 and the adopted B01–B11 workflows. |
| Human readability | PASS | Screen assembly sits in resource controllers. `ReminderRun#call` orders refresh, history, plan and sends. `RecordFollowUp#call` orders scope, replay, revision and source checks, audit write and outcome. The actual rule edit for send hours was in `ReminderRun::SEND_WINDOW`. |
| Ease of change | PASS | The throwaway window edit exercised both the new behavior and the unchanged cutoff using two tests and 20 assertions against a dedicated database. |
| Failure and transaction behavior | PASS | A partial source response retains the previously committed projection. A raised adapter error after one delivery rolls back the batch. A 101-character audit key returns 422 and rolls back contact verification. Replaying a reply or staff follow-up preserves one outcome. The two-connection reminder test persists one accepted delivery. |
| Verification and handoff | PASS | The final `py quality/run_checks.py` exited 0 with all seven checks passing. The logs showed 30 Rails tests and 301 assertions, 60 Ruby files inspected, zero Brakeman warnings, two React tests, successful lint and type checks, and a production asset build. A clean detached checkout installed the locked frontend dependencies and passed `bundle check`. The running demo and Edge checks are recorded above. |

Candidate-authored `DECISIONS.md` and the live defense are separate assessment requirements. This technical review records AI verification and the factual notes supporting the candidate’s own decisions.
