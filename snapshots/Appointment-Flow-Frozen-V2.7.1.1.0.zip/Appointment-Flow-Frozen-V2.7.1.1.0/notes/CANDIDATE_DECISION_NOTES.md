# Tradeoff notes for candidate's own DECISIONS.md

The assessment requires that the candidate write `DECISIONS.md` **personally in their own words**. Capture factual choices and alternatives here so the candidate can make their own narrative later. Agent must not claim authorship on their behalf.

- Assumption / ambiguity:
- What was chosen and why:
- Alternative considered and drawback:
- Risk / what would change with another week:
- Evidence (test/demo/measurement):

## Factual implementation notes

- A clinic-specific snapshot projects source visits into an app-owned revision. PMS wall times are read as date and time fields, then interpreted with the configured IANA zone. Missing or repeated DST times are held for review.
- Reminder cadence is keyed by clinic-local day and a 10:00–18:00 window. The final step requests confirmation for open visits and is informational for confirmed visits. The source schema contains no consent fields, so the demo assumes authorization only for eligible fictional adult contact owners.
- A fake message receipt doubles as the simulated inbox and commits atomically with local reminder changes. Replaying a reply with the same event key returns its prior result. A live provider would need a durable idempotency contract across systems.
- The simulator sends an explicit originating delivery ID, which the server scopes to the selected clinic and historical recipient. SMS shared-address matching remains unsafe even when that ID is available. A staff member can select verified candidates after clarification.
- Staff-recorded cancel and reschedule outcomes stop outreach locally. PMS source rows remain owned by the simulator fixtures. Leaders see completion and follow-up activity, and the dataset does not support a no-show rate.
- Direct source polling and a full three-column recipient ownership read were chosen because the supplied PMS patient table has no contact-change timestamp or normalized contact index. The work and tradeoff are visible in the rubric.
