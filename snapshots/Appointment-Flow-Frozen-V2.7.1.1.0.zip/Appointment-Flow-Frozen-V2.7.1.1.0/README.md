# Apex Appointment Flow

Rails and React demo for appointment reminders, confirmations, and clinic follow-up. The demo uses fictional records and persists all SMS and email activity in PostgreSQL.

## Run locally

Use Ruby 3.4.10, Rails 8.1.4.1, Node 24.19.0 with npm 11.17.0, and a running PostgreSQL instance. This build used PostgreSQL 17.11. Set the usual PostgreSQL connection variables (`PGHOST`, `PGPORT`, `PGUSER` and a password if your local role requires it). The role needs permission to create the application databases, or you can create them first. Use `APEX_DEMO_DATABASE` to select a dedicated development database.

```powershell
bundle install
npm.cmd --prefix frontend ci
bundle exec ruby bin/demo
```

Use `npm` in place of `npm.cmd` on Unix. Open `http://127.0.0.1:3000`. The launcher builds React, prepares PostgreSQL, seeds the two clinics, and starts Rails. Run `bundle exec ruby bin/rails db:seed` for seed-only setup. Initial fictional appointment dates are set relative to the day of seeding. Repeating the seed preserves existing visits and activity.

## Try the workflows

1. Open **Front desk**, choose **Austin, TX**, and keep **Robin Shaw** selected. The board shows contact holds, failed attempts, and visits that still need confirmation. Select **Refresh PMS** to reconcile source changes and **Run demo reminders** to exercise the selected clinic. The summary reports fake attempts and follow-up tasks.
2. From **Workspaces**, open **Patient**, select Austin and **Mara Lin**, then enter `YES` on the **Text messages** tab. Switch back to Front desk → **Appointments** → **Next week** to see the confirmed visit. For email, select **Elias Reed** and open **Email**. `NO` sends the reply to staff review. `STOP` on a text thread suppresses texts to that destination for the clinic.
3. Open a **Patient flow** task to take its assignment and record contact attempted, confirmation, a canceled or rescheduled visit, or review. The patient details show local contact verification and staff activity.
4. Open **Apex leadership** to compare appointment outcomes and activity for Austin and Phoenix. Completion uses PMS outcomes, so it answers a different question from confirmation. The underlying source statuses leave no-shows unknown.

To run a fake reminder batch from the terminal, use `bundle exec ruby bin/rails reminders:run`. List office IDs with `bundle exec ruby bin/rails runner 'pp Office.pluck(:id, :clinic_id)'`. To choose one office and a clock time inside its local sending window, run `bundle exec ruby bin/rails 'reminders:run[1,2026-11-16T12:00:00-06:00]'` with an instant appropriate to your seed dates. Use the browser inbox to inspect accepted fake messages. To inspect all attempt results without printing message content or addresses:

```shell
bundle exec ruby bin/rails runner 'pp Delivery.order(:id).pluck(:visit_id, :revision, :stage, :channel, :successful)'
```

## Checks

```powershell
bundle exec ruby bin/rails db:test:prepare
py quality/run_checks.py
npm.cmd --prefix frontend run smoke
```

Use `python3 quality/run_checks.py` on Unix. The browser smoke uses Microsoft Edge on Windows or an installed Playwright Chromium on Unix. It starts Rails on port 3107 by default and expects a built UI and demo data freshly seeded for the clinic’s current date. The smoke records a simulated reply and a staff note. Set `APEX_DEMO_DATABASE` to an isolated name to preserve another demo session. Set `APEX_SMOKE_URL` to use an existing demo server. Set `WORKLOAD=1` for the Rails test command to print workload metrics.

## Demo rules

- The appointment calendar starts with a snapshot covering seven past days and 35 future days. Refresh captures an appointment that moves out of that window if it was tracked inside it. A missing tracked row rejects refresh and prevents that run from sending.
- The clinic's configured IANA zone interprets PMS wall-clock times. Austin observes DST and Phoenix uses its own rules. A repeated or missing DST wall time needs review. Sends use local hours 10:00 to 18:00, ending at the start of the visit.
- Start seven days out, offer optional backup email at six days, follow up at three days, and send a final message within one day. A confirmed visit can get an informational final message. The demo can fall back to an authorized email after a failed text. A reply under review pauses outreach for that visit version.
- The demo assumes adults with usable, unique fictional contacts and a supported language have permission to receive outreach. Missing authorization, another guarantor, uncertain birthdate, conflicting source values, and unsupported languages trigger review. SMS opt-outs are stored locally by clinic and normalized destination.
- Demo staff credentials are a clinic/staff selector in a signed Rails session. A production deployment would use authenticated staff identities with clinic grants, separate replica credentials with database-enforced read-only access, contact consent and guardian verification, provider-signed inbound messages, and PHI access auditing and retention rules. The fake transport writes its receipt in the same database transaction as app state. A live transport would require its own durable retry and idempotency boundary.

See [ARCHITECTURE.md](ARCHITECTURE.md), [AI_USAGE.md](AI_USAGE.md), and [candidate decision notes](notes/CANDIDATE_DECISION_NOTES.md). The assessment requires the candidate to write `DECISIONS.md` personally.
