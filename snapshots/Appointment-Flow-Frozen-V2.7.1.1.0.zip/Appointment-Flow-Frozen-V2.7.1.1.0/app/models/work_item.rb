class WorkItem < ApplicationRecord
  STATES = %w[needs_attention in_progress resolved].freeze
  KINDS = {
    "no_reply" => "No confirmation",
    "contact_hold" => "Contact hold",
    "delivery_failed" => "Delivery failed",
    "reply_review" => "Reply to review"
  }.freeze

  belongs_to :visit
  belongs_to :reply, optional: true

  scope :open, -> { where(state: %w[needs_attention in_progress]) }
end
