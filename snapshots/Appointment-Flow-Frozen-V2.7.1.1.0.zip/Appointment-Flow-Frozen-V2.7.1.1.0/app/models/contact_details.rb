class ContactDetails
  FIELDS = %w[birthdate wireless_phone email preferred_language].freeze
  LANGUAGES = %w[en es].freeze

  def self.phone(value)
    compact = value.to_s.delete("(). -")
    return unless compact.match?(/\A(?:\+?1)?[2-9]\d{2}[2-9]\d{6}\z/)

    "+1#{compact.last(10)}"
  end

  def self.email(value)
    normalized = value.to_s.strip.downcase
    normalized if URI::MailTo::EMAIL_REGEXP.match?(normalized)
  end

  def initialize(patient, verification, date:)
    @patient = patient
    @verification = verification
    @date = date
  end

  def source_values
    FIELDS.index_with { |field| @patient.public_send(field)&.to_s }
  end

  def verified_values
    @verification&.verified_values || {}
  end

  def values
    source_values.merge(verified_values)
  end

  def revision
    baseline = @verification&.source_values.to_h.sort
    ActiveSupport::Digest.hexdigest([ source_values, verified_values.sort, baseline ].to_json)
  end

  def conflicts
    return [] unless @verification

    verified_values.keys.select { |field| source_values[field] != @verification.source_values[field] }
  end

  def language
    values["preferred_language"].to_s.strip.downcase
  end

  def destination(channel)
    channel == "sms" ? self.class.phone(values["wireless_phone"]) : self.class.email(values["email"])
  end

  def hold_reason
    return "PMS contact details changed after local verification." if conflicts.any?

    birthdate = date_of_birth
    return "Verify the patient’s birthdate and contact authorization." unless birthdate && birthdate <= @date
    adult_since = birthdate >> (18 * 12)
    if adult_since > @date || (@patient.guarantor_id && @patient.guarantor_id != @patient.id)
      return "Verify the responsible party before contacting this patient."
    end
    return "Verify a supported preferred language." unless LANGUAGES.include?(language)

    nil
  end

  private

  def date_of_birth
    Date.iso8601(values.fetch("birthdate").to_s, limit: 10)
  rescue Date::Error
    nil
  end
end
