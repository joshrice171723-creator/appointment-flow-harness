class Reply < ApplicationRecord
  belongs_to :office
  belongs_to :delivery

  validates :event_key, length: { in: 1..100 }
  validates :body, presence: true, length: { maximum: 500 }
end
