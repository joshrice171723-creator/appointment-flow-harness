class SmsOptOut < ApplicationRecord
  belongs_to :office
end
