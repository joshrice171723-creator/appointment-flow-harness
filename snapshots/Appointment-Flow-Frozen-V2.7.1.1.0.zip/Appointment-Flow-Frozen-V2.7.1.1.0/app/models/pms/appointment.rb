module Pms
  class Appointment < Record
    self.table_name = "appointments"
    self.skip_time_zone_conversion_for_attributes = %i[start_at updated_at]

    scope :identity_rows, -> { select(:id, :clinic_id, :patient_id, :start_at, :status) }
  end
end
