module Pms
  class Clinic < Record
    self.table_name = "clinics"
  end
end
