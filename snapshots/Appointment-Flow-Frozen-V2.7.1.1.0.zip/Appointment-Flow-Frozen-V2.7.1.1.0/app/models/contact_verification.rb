class ContactVerification < ApplicationRecord
  belongs_to :office
end
