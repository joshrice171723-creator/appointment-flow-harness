class StaffEvent < ApplicationRecord
  belongs_to :office
  belongs_to :visit, optional: true
  belongs_to :work_item, optional: true

  validates :event_key, length: { in: 1..100 }
  validates :note, presence: true, length: { maximum: 500 }
end
