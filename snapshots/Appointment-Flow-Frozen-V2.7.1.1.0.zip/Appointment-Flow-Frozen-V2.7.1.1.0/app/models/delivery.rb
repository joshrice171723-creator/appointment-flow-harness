class Delivery < ApplicationRecord
  belongs_to :visit
  has_many :replies

  scope :accepted, -> { where(successful: true) }
end
