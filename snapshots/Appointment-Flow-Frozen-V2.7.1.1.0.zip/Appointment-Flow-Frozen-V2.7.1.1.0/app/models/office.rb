class Office < ApplicationRecord
  belongs_to :clinic, class_name: "Pms::Clinic"
  has_many :visits
  has_many :deliveries, through: :visits
  has_many :replies
  has_many :work_items, through: :visits
  has_many :contact_verifications
  has_many :sms_opt_outs
  has_many :staff_events

  def zone
    Time.find_zone!(time_zone)
  end

  def wall_time_range(first_date, end_date)
    Time.utc(first_date.year, first_date.month, first_date.day)...Time.utc(end_date.year, end_date.month, end_date.day)
  end

  def interpret_wall_time(value)
    periods = zone.tzinfo.periods_for_local(value)
    return unless periods.one?

    value.utc - periods.first.observed_utc_offset
  end
end
