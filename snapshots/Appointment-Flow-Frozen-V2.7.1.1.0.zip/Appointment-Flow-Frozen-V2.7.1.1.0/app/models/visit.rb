class Visit < ApplicationRecord
  belongs_to :office
  belongs_to :patient, class_name: "Pms::Patient"
  has_many :deliveries
  has_many :work_items

  scope :scheduled, -> { where(status: "scheduled") }
  scope :open_for_outreach, -> { scheduled.where(disposition: nil) }

  def open_for_outreach?
    status == "scheduled" && disposition.nil?
  end

  def source_current?(source, clinic_id:)
    source && source.clinic_id == clinic_id && source.status == "scheduled" &&
      source.start_at == source_start_at && source.patient_id == patient_id && open_for_outreach?
  end

  def outcome
    return "Completed" if status == "complete"
    return disposition.capitalize if disposition.in?(%w[canceled rescheduled])

    "Unknown"
  end
end
