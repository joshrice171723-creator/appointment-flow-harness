# The delivery row committed by ReminderRun is the fake provider's receipt and inbox.
class FakeMessenger
  FAILURE_DESTINATIONS = %w[+15125550199 unavailable@example.invalid].freeze

  def self.deliver(visit:, channel:, destination:, stage:, body:, asks_confirmation:, at:)
    visit.deliveries.create!(
      patient_id: visit.patient_id, revision: visit.revision, stage: stage, channel: channel,
      destination: destination, successful: accepts?(destination), asks_confirmation: asks_confirmation,
      body: body, created_at: at, updated_at: at
    )
  end

  def self.accepts?(destination)
    !FAILURE_DESTINATIONS.include?(destination)
  end

  private_class_method :accepts?
end
