class RecordReply
  class EventConflict < StandardError; end
  class SourceUnavailable < StandardError; end

  def initialize(office, patient_id:, delivery_id:, body:, event_key:, now: Time.current)
    @office = office
    @patient_id = patient_id
    @delivery_id = delivery_id
    @body = body
    @event_key = event_key
    @now = now
  end

  def call
    @office.with_lock do
      delivery = @office.deliveries.accepted.where(patient_id: @patient_id).find(@delivery_id)
      previous = @office.replies.find_by(event_key: @event_key)
      next replay(previous, delivery) if previous

      reply = @office.replies.create!(delivery: delivery, event_key: @event_key, body: @body, result: "received")
      visit = delivery.visit
      if command == "STOP" && delivery.channel == "sms"
        record_opt_out(delivery, reply)
      elsif command == "YES" && confirmation_allowed?(delivery, visit)
        confirm(visit, reply)
      else
        refer_to_staff(delivery, visit, reply)
      end
      reply
    end
  end

  private

  def command
    @body.strip.upcase
  end

  def replay(previous, delivery)
    unless previous.delivery_id == delivery.id && previous.body == @body
      raise EventConflict, "This reply identifier belongs to a different reply. Reload the inbox."
    end

    previous
  end

  def record_opt_out(delivery, reply)
    @office.sms_opt_outs.find_or_create_by!(destination: delivery.destination)
    reply.update!(result: "opted_out")
  end

  def confirmation_allowed?(delivery, visit)
    return false unless delivery.asks_confirmation && delivery.revision == visit.revision
    return false unless visit.starts_at && @now < visit.starts_at && delivery.patient_id == visit.patient_id
    return false unless visit.source_current?(read_source(visit), clinic_id: @office.clinic_id)

    patient = Pms::Patient.find(delivery.patient_id)
    details = directory.details(patient, date: @now.in_time_zone(@office.zone).to_date)
    details.hold_reason.nil? && details.destination(delivery.channel) == delivery.destination &&
      directory.permitted?(delivery.channel, delivery.destination, delivery.patient_id)
  end

  def read_source(visit)
    Pms::Appointment.identity_rows.find_by(id: visit.source_id, clinic_id: @office.clinic_id)
  rescue ActiveRecord::StatementInvalid, ActiveRecord::ConnectionNotEstablished => error
    raise SourceUnavailable, "The PMS could not be checked. Refresh the inbox before trying again.", cause: error
  end

  def directory
    @directory ||= RecipientDirectory.new(@office)
  end

  def confirm(visit, reply)
    visit.update!(confirmed_at: @now) unless visit.confirmed_at
    visit.work_items.open.where(revision: visit.revision, kind: "no_reply").update_all(state: "resolved", updated_at: @now)
    reply.update!(result: "confirmed")
  end

  def refer_to_staff(delivery, visit, reply)
    candidate_ids = candidate_visits(delivery, visit)
    visit.work_items.create!(
      revision: delivery.revision, key: "reply-#{reply.id}", kind: "reply_review",
      reason: review_reason(delivery, visit, candidate_ids),
      candidate_visit_ids: candidate_ids, reply: reply
    )
    reply.update!(result: "needs_review")
  end

  def candidate_visits(delivery, visit)
    return [] unless visit.starts_at && visit.starts_at > @now
    return [] unless delivery.revision == visit.revision && delivery.patient_id == visit.patient_id

    ids = directory.owners(delivery.channel, delivery.destination)
    return [] unless ids.include?(visit.patient_id)

    if ids.one?
      return [ visit.id ] if visit.open_for_outreach?

      return []
    end

    @office.visits.open_for_outreach.where(patient_id: ids.to_a, starts_at: @now...(@now + 8.days))
      .order(:starts_at, :id).limit(25).pluck(:id)
  end

  def review_reason(delivery, visit, candidate_ids)
    return "The reply refers to a previous appointment version." if delivery.revision != visit.revision
    return "The reply arrived after the appointment started." if visit.starts_at && @now >= visit.starts_at
    return "Clarify which visit belongs to this shared contact." if candidate_ids.many?
    return "The patient requested help with their appointment." if command == "NO"

    "Verify the reply and current appointment before recording a confirmation."
  end
end
