class RecipientDirectory
  def initialize(office)
    @verifications = office.contact_verifications.index_by(&:patient_id)
    @opt_outs = office.sms_opt_outs.pluck(:destination).to_set
    @owners = Hash.new { |owners, key| owners[key] = Set.new }

    Pms::Patient.pluck(:id, :wireless_phone, :email).each do |patient_id, phone, email|
      register(patient_id, phone, email)
    end
    @verifications.each do |patient_id, record|
      register(patient_id, record.verified_values["wireless_phone"], record.verified_values["email"])
    end
    ContactVerification.where.not(office_id: office.id).pluck(:patient_id, :verified_values).each do |patient_id, values|
      register(patient_id, values["wireless_phone"], values["email"])
    end
  end

  def details(patient, date:)
    ContactDetails.new(patient, @verifications[patient.id], date: date)
  end

  def permitted?(channel, destination, patient_id)
    return false if destination.nil? || (channel == "sms" && @opt_outs.include?(destination))

    owners(channel, destination) == Set[patient_id]
  end

  def owners(channel, destination)
    @owners[[ channel, destination ]]
  end

  private

  def register(patient_id, phone, email)
    phone = ContactDetails.phone(phone)
    email = ContactDetails.email(email)
    owners("sms", phone).add(patient_id) if phone
    owners("email", email).add(patient_id) if email
  end
end
