class RecordFollowUp
  class Rejected < StandardError; end
  class Conflict < StandardError; end
  class SourceUnavailable < StandardError; end

  OUTCOMES = %w[attempted confirmed rescheduled canceled reviewed].freeze

  def initialize(office, patient_id:, staff_name:, attributes:)
    @office = office
    @patient_id = patient_id
    @staff_name = staff_name
    @attributes = attributes
    @outcome = attributes[:outcome]
    @now = Time.current
  end

  def call
    raise Rejected, "Choose a valid follow-up outcome." unless OUTCOMES.include?(@outcome)

    @office.with_lock do
      visit = @office.visits.where(patient_id: @patient_id).find(@attributes[:visit_id])
      item = visit.work_items.find(@attributes[:work_item_id]) if @attributes[:work_item_id].present?
      if (previous = @office.staff_events.find_by(event_key: @attributes[:event_key]))
        next replay(previous, visit, item)
      end

      verify_revision(visit, request_details.fetch("visit_revision"))
      validate_task(item, visit)
      affected = visits_to_update(visit, item)
      verify_source(affected)
      event = record_event(visit, item, affected)
      apply_outcome(affected, item)
      event
    end
  end

  private

  def request_details
    @request_details ||= {
      "visit_revision" => Integer(@attributes[:visit_revision].to_s, exception: false),
      "candidates" => Array(@attributes[:candidates]).map do |candidate|
        {
          "id" => Integer(candidate[:id].to_s, exception: false),
          "revision" => Integer(candidate[:revision].to_s, exception: false)
        }
      end.sort_by { |candidate| candidate["id"].to_i }
    }
  end

  def replay(previous, visit, item)
    valid = previous.visit_id == visit.id && previous.work_item_id == item&.id &&
      previous.staff_name == @staff_name && previous.outcome == @outcome &&
      previous.note == @attributes[:note] && previous.details.slice(*request_details.keys) == request_details
    raise Conflict, "This request identifier belongs to another follow-up." unless valid

    previous
  end

  def validate_task(item, visit)
    return unless item

    raise Conflict, "This follow-up is already resolved." if item.state == "resolved"
    if item.assignee && item.assignee != @staff_name
      raise Conflict, "This item is assigned to #{item.assignee}."
    end
    if item.revision != visit.revision && @outcome.in?(%w[confirmed rescheduled canceled])
      raise Conflict, "This task refers to a previous appointment version."
    end
  end

  def visits_to_update(visit, item)
    return [] unless @outcome.in?(%w[confirmed rescheduled canceled])
    return [ visit ] unless item&.kind == "reply_review"

    selected = request_details.fetch("candidates")
    ids = selected.pluck("id")
    if ids.empty? || ids.uniq.size != ids.size || (ids - item.candidate_visit_ids).any?
      raise Rejected, "Select the appointment or appointments you clarified with the patient."
    end

    revisions = selected.index_by { |candidate| candidate.fetch("id") }
    @office.visits.find(ids).each do |candidate|
      verify_revision(candidate, revisions.fetch(candidate.id).fetch("revision"))
    end
  end

  def verify_revision(visit, expected)
    return if visit.revision == expected

    raise Conflict, "An appointment changed. Reopen the patient details and verify the current visit before saving."
  end

  def verify_source(visits)
    return if visits.empty?

    source_rows = read_source(visits)
    visits.each do |visit|
      unless visit.starts_at && visit.starts_at > @now && visit.source_current?(source_rows[visit.source_id], clinic_id: @office.clinic_id)
        raise Conflict, "The PMS visit changed or already started. Refresh appointments before recording an outcome."
      end
    end
  end

  def read_source(visits)
    Pms::Appointment.identity_rows.where(clinic_id: @office.clinic_id, id: visits.map(&:source_id)).index_by(&:id)
  rescue ActiveRecord::StatementInvalid, ActiveRecord::ConnectionNotEstablished => error
    raise SourceUnavailable, "The PMS could not be checked. Try again after it is available.", cause: error
  end

  def record_event(visit, item, affected)
    @office.staff_events.create!(
      visit: visit, work_item: item, patient_id: visit.patient_id, staff_name: @staff_name,
      event_key: @attributes[:event_key], outcome: @outcome, note: @attributes[:note],
      details: request_details.merge("affected_visit_ids" => affected.map(&:id))
    )
  end

  def apply_outcome(visits, item)
    visits.each do |visit|
      if @outcome == "confirmed"
        visit.update!(confirmed_at: visit.confirmed_at || @now)
      else
        visit.update!(disposition: @outcome)
      end
      visit.work_items.open.where(revision: visit.revision).where.not(kind: "reply_review")
        .update_all(state: "resolved", updated_at: @now)
    end

    item&.update!(
      state: @outcome == "attempted" ? "in_progress" : "resolved",
      assignee: @staff_name
    )
  end
end
