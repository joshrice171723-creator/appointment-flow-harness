class RefreshVisits
  class Unavailable < StandardError; end

  def initialize(office, now: Time.current)
    @office = office
    @now = now
  end

  # Reminder runs already hold this same office lock and transaction.
  def call
    @office.with_lock do
      tracked = tracked_visits
      source_rows = read_source(tracked)
      verify_snapshot(source_rows, tracked)
      reconcile(source_rows, tracked)
      @office.update!(refreshed_at: @now)
    end
    @office.refreshed_at
  end

  private

  def wall_range
    today = @now.in_time_zone(@office.zone).to_date
    @office.wall_time_range(today - 7, today + 36)
  end

  def tracked_visits
    @office.visits.where(source_start_at: wall_range).index_by(&:source_id)
  end

  def read_source(tracked)
    appointments = Pms::Appointment.where(clinic_id: @office.clinic_id)
    appointments.where(start_at: wall_range).or(appointments.where(id: tracked.keys))
      .pluck(:id, :patient_id, :start_at, :status, :provider_name, :length_minutes)
  rescue ActiveRecord::StatementInvalid, ActiveRecord::ConnectionNotEstablished => error
    raise Unavailable, "The PMS source could not be read.", cause: error
  end

  def verify_snapshot(source_rows, tracked)
    missing = tracked.keys - source_rows.map(&:first)
    if missing.any? || (source_rows.empty? && @office.refreshed_at.nil?)
      raise Unavailable, "The PMS returned an incomplete clinic snapshot."
    end
  end

  def reconcile(source_rows, tracked)
    new_ids = source_rows.map(&:first) - tracked.keys
    previous = @office.visits.where(source_id: new_ids).index_by(&:source_id)
    tracked.merge!(previous)
    obsolete_visit_ids = []
    changes = source_rows.filter_map do |source_id, patient_id, wall_time, status, provider, length|
      visit = tracked[source_id]
      attributes = {
        patient_id: patient_id, source_start_at: wall_time, source_date: wall_time.to_date, status: status,
        provider_name: provider, length_minutes: length
      }
      next if visit && attributes.all? { |key, value| visit.public_send(key) == value }

      local_state = revision_attributes(visit, attributes)
      if visit && (local_state[:revision] != visit.revision || status != "scheduled")
        obsolete_visit_ids << visit.id
      end
      attributes.merge(local_state,
        office_id: @office.id, source_id: source_id,
        starts_at: @office.interpret_wall_time(wall_time))
    end
    @office.visits.upsert_all(changes, unique_by: %i[office_id source_id], returning: false) if changes.any?
    if obsolete_visit_ids.any?
      WorkItem.open.where(visit_id: obsolete_visit_ids).where.not(kind: "reply_review")
        .update_all(state: "resolved", updated_at: @now)
    end
  end

  def revision_attributes(visit, attributes)
    return { revision: 1, confirmed_at: nil, disposition: nil } unless visit

    revised = visit.source_start_at != attributes[:source_start_at] ||
      visit.patient_id != attributes[:patient_id] ||
      (visit.status != "scheduled" && attributes[:status] == "scheduled")
    return { revision: visit.revision + 1, confirmed_at: nil, disposition: nil } if revised

    { revision: visit.revision, confirmed_at: visit.confirmed_at, disposition: visit.disposition }
  end
end
