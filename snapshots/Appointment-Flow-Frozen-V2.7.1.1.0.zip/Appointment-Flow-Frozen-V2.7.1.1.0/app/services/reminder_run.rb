class ReminderRun
  class SourceChanged < StandardError; end

  SEND_WINDOW = (10...18)
  FINAL_DAY = 1
  FOLLOW_UP_DAY = 3
  BACKUP_DAY = 6
  FIRST_DAY = 7
  PlannedSend = Data.define(:visit, :stage, :channels, :asks_confirmation)

  def initialize(office, now: nil, messenger: FakeMessenger)
    @office = office
    @clock = now ? -> { now } : -> { Time.current }
    @now = @clock.call
    @local_now = @now.in_time_zone(office.zone)
    @messenger = messenger
  end

  def call
    RefreshVisits.new(@office, now: @now).call
    @office.with_lock do
      visits = upcoming_visits
      load_outreach_history(visits)
      totals = { sent: 0, failed: 0, tasks: 0 }
      planned = visits.filter_map { |visit| plan_send(visit, totals) }
      send_reminders(planned, totals)
      totals
    end
  end

  private

  def upcoming_visits
    last_date = @local_now.to_date + FIRST_DAY + 1
    valid_times = @office.visits.open_for_outreach.where(starts_at: @now...last_date.in_time_zone(@office.zone))
    uncertain_times = @office.visits.open_for_outreach.where(
      starts_at: nil, source_start_at: @office.wall_time_range(@local_now.to_date, last_date)
    )
    valid_times.or(uncertain_times).order(:source_start_at, :id).to_a
  end

  def load_outreach_history(visits)
    visit_ids_by_revision = visits.group_by(&:revision).transform_values { |rows| rows.map(&:id) }
    @attempts = current_history(Delivery.all, visit_ids_by_revision)
      .select(:visit_id, :revision, :stage, :channel, :successful).group_by(&:visit_id)
    @work_items = current_history(WorkItem.all, visit_ids_by_revision).group_by(&:visit_id)
  end

  def current_history(records, ids_by_revision)
    ids_by_revision.reduce(records.none) do |current, (revision, ids)|
      current.or(records.where(visit_id: ids, revision: revision))
    end
  end

  def plan_send(visit, totals)
    unless visit.starts_at
      task(visit, "contact_hold", "The PMS appointment time needs review.", totals)
      return
    end
    if visit.starts_at <= @now
      return
    end

    if !visit.confirmed_at && visit.starts_at <= @now + 48.hours
      task(visit, "no_reply", "The visit starts within 48 hours and still needs confirmation.", totals)
    end

    attempts = @attempts.fetch(visit.id, [])
    stage, channels, asks = reminder_for(visit, attempts)
    return unless stage && SEND_WINDOW.cover?(@local_now.hour) && !reply_under_review?(visit)
    return if attempts.any? { |item| item.stage == stage && item.successful }

    remaining = channels.reject { |channel| attempts.any? { |item| item.stage == stage && item.channel == channel } }
    return if remaining.empty?

    PlannedSend.new(visit, stage, remaining, asks)
  end

  def reminder_for(visit, attempts)
    days = (visit.source_start_at.to_date - @local_now.to_date).to_i
    return [ "final", %w[sms email], !visit.confirmed_at ] if days <= FINAL_DAY
    return if visit.confirmed_at
    return [ "follow_up", %w[sms email], true ] if days <= FOLLOW_UP_DAY

    first_delivery = attempts.find { |item| item.stage == "initial" && item.successful }
    return [ "initial", %w[sms email], true ] unless first_delivery
    [ "backup", [ "email" ], true ] if days == BACKUP_DAY && first_delivery.channel == "sms"
  end

  def reply_under_review?(visit)
    @work_items.fetch(visit.id, []).any? do |item|
      item.kind == "reply_review" && item.state != "resolved"
    end
  end

  def send_reminders(planned, totals)
    return if planned.empty?

    @directory = RecipientDirectory.new(@office)
    patients = Pms::Patient.where(id: planned.map { |send| send.visit.patient_id }).index_by(&:id)
    verify_current_appointments(planned.map(&:visit))
    planned.each do |send|
      details = @directory.details(patients.fetch(send.visit.patient_id), date: @local_now.to_date)
      send_reminder(send, details, totals)
    end
  end

  def verify_current_appointments(visits)
    source = read_current_appointments(visits.map(&:source_id))
    return if visits.all? { |visit| visit.source_current?(source[visit.source_id], clinic_id: @office.clinic_id) }

    raise SourceChanged, "The PMS changed during this reminder run. Run reminders again to refresh the appointments."
  end

  def read_current_appointments(source_ids)
    Pms::Appointment.identity_rows.where(clinic_id: @office.clinic_id, id: source_ids).index_by(&:id)
  rescue ActiveRecord::StatementInvalid, ActiveRecord::ConnectionNotEstablished => error
    raise RefreshVisits::Unavailable, "The PMS could not be checked before sending reminders.", cause: error
  end

  def send_reminder(send, details, totals)
    visit = send.visit
    if (reason = details.hold_reason)
      task(visit, "contact_hold", reason, totals)
      return
    end

    available = send.channels.filter_map do |channel|
      destination = details.destination(channel)
      [ channel, destination ] if @directory.permitted?(channel, destination, visit.patient_id)
    end
    if available.empty?
      # Backup is optional when the first SMS arrived and email is unavailable.
      task(visit, "contact_hold", "Verify a usable, unique contact with permission to receive reminders.", totals) unless send.stage == "backup"
      return
    end

    resolve_tasks(visit, [ "contact_hold" ])
    available.each do |channel, destination|
      now = @clock.call
      break unless now < visit.starts_at && SEND_WINDOW.cover?(now.in_time_zone(@office.zone).hour)

      delivery = @messenger.deliver(
        visit: visit, channel: channel, destination: destination, stage: send.stage, asks_confirmation: send.asks_confirmation,
        body: message_body(visit, details.language, channel, send.asks_confirmation), at: now
      )
      if delivery.successful
        totals[:sent] += 1
        break
      end
      totals[:failed] += 1
      task(visit, "delivery_failed", "A simulated #{channel.upcase} delivery failed. Verify the contact details.", totals)
    end
  end

  def task(visit, kind, reason, totals)
    existing = @work_items.fetch(visit.id, []).find { |item| item.key == kind }
    if existing
      if existing.state == "resolved"
        existing.update!(state: "needs_attention", assignee: nil, reason: reason)
        totals[:tasks] += 1
      elsif existing.reason != reason
        existing.update!(reason: reason)
      end
      return
    end

    visit.work_items.create!(revision: visit.revision, key: kind, kind: kind, reason: reason)
    totals[:tasks] += 1
  end

  def resolve_tasks(visit, kinds)
    @work_items.fetch(visit.id, []).each do |item|
      item.update!(state: "resolved") if kinds.include?(item.kind) && item.state != "resolved"
    end
  end

  def message_body(visit, language, channel, asks)
    clinic = @office.clinic.name
    time = visit.source_start_at.strftime("%b %-d, %Y at %-I:%M %p")
    if language == "es"
      local_time = visit.source_start_at.strftime("%d/%m/%Y a las %H:%M")
      body = "Tiene una cita en #{clinic} el #{local_time} (hora local)."
      body += " Responda YES para confirmar o NO si necesita ayuda." if asks
      body += " Responda STOP para dejar de recibir textos." if channel == "sms"
      return body
    end

    body = "You have an appointment at #{clinic} on #{time} (local time)."
    body += " Reply YES to confirm or NO for help." if asks
    body += " Reply STOP to stop text reminders." if channel == "sms"
    body
  end
end
