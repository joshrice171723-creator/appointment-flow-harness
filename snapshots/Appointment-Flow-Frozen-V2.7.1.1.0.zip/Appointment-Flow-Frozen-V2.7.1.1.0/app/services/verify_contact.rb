class VerifyContact
  class InvalidFields < StandardError; end
  class Conflict < StandardError; end

  def initialize(office, patient_id:, staff_name:, fields:, event_key:, revision:)
    @office = office
    @patient_id = patient_id
    @staff_name = staff_name
    @fields = fields.transform_values { |value| value.to_s.strip.presence }
    @event_key = event_key
    @revision = revision
  end

  def call
    validate_fields
    @office.with_lock do
      raise ActiveRecord::RecordNotFound unless @office.visits.exists?(patient_id: @patient_id)

      if (previous = @office.staff_events.find_by(event_key: @event_key))
        next replay(previous)
      end

      patient = Pms::Patient.find(@patient_id)
      verification = @office.contact_verifications.find_or_initialize_by(patient_id: patient.id)
      details = ContactDetails.new(patient, verification, date: Time.current.in_time_zone(@office.zone).to_date)
      unless details.revision == @revision
        raise Conflict, "Contact details changed. Reopen the patient details and review the current values before saving."
      end
      record_verification(verification, details)
      record_event(patient.id, details)
    end
  end

  private

  def validate_fields
    raise InvalidFields, "Choose at least one contact field to verify." if @fields.empty?

    if (phone = @fields["wireless_phone"]) && !ContactDetails.phone(phone)
      raise InvalidFields, "Enter a valid US mobile number."
    end
    if (email = @fields["email"]) && !ContactDetails.email(email)
      raise InvalidFields, "Enter a valid email address."
    end
    if (language = @fields["preferred_language"]) && !ContactDetails::LANGUAGES.include?(language)
      raise InvalidFields, "Choose English or Spanish."
    end
    if (date = @fields["birthdate"]) && Date.iso8601(date, limit: 10) > Time.current.in_time_zone(@office.zone).to_date
      raise InvalidFields, "Birthdate cannot be in the future."
    end
  rescue Date::Error
    raise InvalidFields, "Enter a valid birthdate."
  end

  def replay(previous)
    unless previous.patient_id.to_s == @patient_id.to_s && previous.staff_name == @staff_name &&
        previous.outcome == "contact_verified" && previous.details["verified"] == @fields &&
        previous.details["contact_revision"] == @revision
      raise Conflict, "This request identifier belongs to another change."
    end

    previous
  end

  def record_verification(verification, details)
    verification.update!(
      verified_values: verification.verified_values.merge(@fields),
      source_values: verification.source_values.merge(details.source_values.slice(*@fields.keys))
    )
  end

  def record_event(patient_id, details)
    @office.staff_events.create!(
      patient_id: patient_id, staff_name: @staff_name, event_key: @event_key,
      outcome: "contact_verified", note: "Verified local contact details.",
      details: { "verified" => @fields, "source" => details.source_values.slice(*@fields.keys), "contact_revision" => @revision }
    )
  end
end
