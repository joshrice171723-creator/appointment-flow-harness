class InboxesController < ApplicationController
  before_action :require_patient_demo

  def show
    office = Office.find(params[:office_id])
    patient_id = params[:patient_id]
    return head :not_found unless office.visits.exists?(patient_id: patient_id) || office.deliveries.accepted.exists?(patient_id: patient_id)

    channel = params[:channel] == "email" ? "email" : "sms"
    deliveries = office.deliveries.accepted.where(patient_id: patient_id, channel: channel)
      .order(created_at: :desc, id: :desc).limit(25).to_a
    replies = office.replies.where(delivery_id: deliveries.map(&:id)).order(created_at: :desc, id: :desc)
      .limit(50).group_by(&:delivery_id)
    render json: deliveries.map { |delivery| thread(delivery, replies.fetch(delivery.id, [])) }
  end

  private

  def thread(delivery, replies)
    {
      id: delivery.id, body: delivery.body, created_at: delivery.created_at,
      replies: replies.reverse.map { |reply| { id: reply.id, body: reply.body, result: reply.result, created_at: reply.created_at } }
    }
  end
end
