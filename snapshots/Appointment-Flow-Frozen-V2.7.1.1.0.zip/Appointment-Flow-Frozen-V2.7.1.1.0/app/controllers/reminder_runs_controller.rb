class ReminderRunsController < ApplicationController
  before_action :require_staff

  def create
    render json: ReminderRun.new(staff_office).call, status: :created
  rescue RefreshVisits::Unavailable => error
    render json: { error: error.message }, status: :service_unavailable
  rescue ReminderRun::SourceChanged => error
    render json: { error: error.message }, status: :conflict
  end
end
