class RepliesController < ApplicationController
  before_action :require_patient_demo

  def create
    delivery_id, body, event_key = params.expect(:delivery_id, :body, :event_key)
    unless body.is_a?(String) && event_key.is_a?(String)
      return render json: { error: "A reply and its request identifier are required." }, status: :bad_request
    end
    office = Office.find(params[:office_id])
    reply = RecordReply.new(office, patient_id: params[:patient_id], delivery_id: delivery_id,
      body: body, event_key: event_key).call
    render json: { id: reply.id, result: reply.result }, status: :created
  rescue RecordReply::EventConflict => error
    render json: { error: error.message }, status: :conflict
  rescue RecordReply::SourceUnavailable => error
    render json: { error: error.message }, status: :service_unavailable
  rescue ActiveRecord::RecordInvalid => error
    render json: { error: error.record.errors.full_messages.to_sentence }, status: :unprocessable_content
  end
end
