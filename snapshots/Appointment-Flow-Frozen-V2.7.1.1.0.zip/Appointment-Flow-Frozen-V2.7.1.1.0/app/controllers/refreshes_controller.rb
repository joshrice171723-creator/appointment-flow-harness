class RefreshesController < ApplicationController
  before_action :require_staff

  def create
    refreshed_at = RefreshVisits.new(staff_office).call
    render json: { refreshed_at: refreshed_at }, status: :created
  rescue RefreshVisits::Unavailable => error
    render json: { error: error.message }, status: :service_unavailable
  end
end
