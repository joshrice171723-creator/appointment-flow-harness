class StaffPatientsController < ApplicationController
  before_action :require_staff

  def show
    visits = staff_office.visits.where(patient_id: params[:id])
    patient = Pms::Patient.find(params[:id]) if visits.exists?
    return head :not_found unless patient

    verification = staff_office.contact_verifications.find_by(patient_id: patient.id)
    contact = ContactDetails.new(patient, verification, date: Time.current.in_time_zone(staff_office.zone).to_date)
    items = WorkItem.where(visit_id: visits.select(:id))
    render json: {
      id: patient.id.to_s, name: patient.name,
      contact: {
        source: contact.source_values, values: contact.values, verified: contact.verified_values.keys,
        conflicts: contact.conflicts, hold: contact.hold_reason, revision: contact.revision
      },
      visits: prioritize(visits, params[:visit_id]).order(source_start_at: :desc, id: :desc).limit(30)
        .map { |visit| appointment(visit) },
      work_items: task_details(items, patient.id),
      activity: staff_office.staff_events.where(patient_id: patient.id).order(created_at: :desc, id: :desc).limit(30)
        .map { |event| event.as_json(only: %i[id created_at outcome note staff_name]) }
    }
  end

  private

  def prioritize(records, selected_id)
    selected_id.present? ? records.in_order_of(:id, [ selected_id ], filter: false) : records
  end

  def appointment(visit)
    {
      id: visit.id, time: visit.source_start_at.strftime("%a, %b %-d · %-I:%M %p"),
      provider: visit.provider_name, confirmed: visit.confirmed_at.present?, revision: visit.revision,
      outcome: visit.outcome, open: visit.open_for_outreach? && visit.starts_at && visit.starts_at > Time.current
    }
  end

  def task_details(items, patient_id)
    visible = prioritize(items, params[:item_id]).order(state: :asc, created_at: :desc, id: :desc).limit(30)
      .includes(:visit, reply: :delivery).to_a
    candidate_ids = visible.flat_map(&:candidate_visit_ids).uniq
    candidates = staff_office.visits.where(id: candidate_ids).strict_loading.includes(:patient).index_by(&:id)
    visible.map do |item|
      visit = item.visit
      {
        id: item.id, kind: item.kind, state: item.state, reason: item.reason, assignee: item.assignee,
        visit_id: visit.id, visit_time: appointment(visit)[:time], visit_revision: visit.revision,
        current: visit.revision == item.revision,
        reply: item.reply&.delivery&.patient_id == patient_id ? item.reply.body : nil,
        candidates: item.candidate_visit_ids.filter_map do |id|
          candidate = candidates[id]
          { id: id, name: candidate.patient.name, time: appointment(candidate)[:time], revision: candidate.revision } if candidate
        end
      }
    end
  end
end
