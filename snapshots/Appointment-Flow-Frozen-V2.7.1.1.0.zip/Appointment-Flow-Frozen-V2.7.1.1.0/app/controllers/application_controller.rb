class ApplicationController < ActionController::Base
  # Only allow modern browsers supporting webp images, web push, badges, import maps, CSS nesting, and CSS :has.
  allow_browser versions: :modern

  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "This record is unavailable in the selected workspace." }, status: :not_found
  end

  rescue_from ActionController::ParameterMissing do |error|
    render json: { error: error.message }, status: :bad_request
  end

  private

  def require_staff
    return if session[:role] == "staff" && staff_office.staff_names.include?(session[:staff_name])

    render json: { error: "Select a clinic and staff member in Workspaces." }, status: :forbidden
  end

  def require_patient_demo
    return if session[:role] == "patient"

    render json: { error: "Open the patient demo workspace first." }, status: :forbidden
  end

  def require_leadership
    return if session[:role] == "leadership"

    render json: { error: "Open the leadership workspace first." }, status: :forbidden
  end

  def staff_office
    @staff_office ||= Office.find(session[:office_id])
  end
end
