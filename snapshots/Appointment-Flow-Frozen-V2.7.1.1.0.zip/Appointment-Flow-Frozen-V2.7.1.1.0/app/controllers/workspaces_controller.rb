class WorkspacesController < ApplicationController
  def show
    return render :show, layout: false unless request.format.json?

    render json: {
      selection: { role: session[:role], office_id: session[:office_id], staff_name: session[:staff_name] },
      offices: Office.includes(:clinic).order(:id).map do |office|
        { id: office.id, name: office.clinic.name, time_zone: office.time_zone, staff_names: office.staff_names }
      end
    }
  end

  def create
    role = params.require(:role)
    return invalid_selection unless role.in?(%w[staff leadership patient])

    if role == "staff"
      office = Office.find(params.require(:office_id))
      return invalid_selection unless office.staff_names.include?(params[:staff_name])
    end

    reset_session
    session[:role] = role
    session[:office_id] = office.id if office
    session[:staff_name] = params[:staff_name] if office
    render json: { csrf_token: form_authenticity_token }
  end

  def destroy
    reset_session
    render json: { csrf_token: form_authenticity_token }
  end

  private

  def invalid_selection
    render json: { error: "Choose a workspace and a staff member from that clinic." }, status: :unprocessable_content
  end
end
