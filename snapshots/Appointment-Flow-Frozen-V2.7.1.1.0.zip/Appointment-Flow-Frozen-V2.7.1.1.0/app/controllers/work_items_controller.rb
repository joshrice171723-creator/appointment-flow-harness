class WorkItemsController < ApplicationController
  before_action :require_staff
  PAGE_SIZE = 12

  def index
    items = staff_office.work_items
    totals = items.group(:state).count
    displayed = filtered_items(items)
    total = displayed.count
    pages = [ (total.to_f / PAGE_SIZE).ceil, 1 ].max
    page = params[:page].to_s.to_i.clamp(1, pages)
    rows = displayed.order(created_at: :desc, id: :desc).offset((page - 1) * PAGE_SIZE)
      .limit(PAGE_SIZE).strict_loading.includes(visit: :patient)

    render json: {
      items: rows.map { |item| board_card(item) }, totals: totals, page: page, pages: pages, total: total,
      kinds: WorkItem::KINDS, refreshed_at: staff_office.refreshed_at
    }
  end

  def update
    item = staff_office.with_lock do
      current = staff_office.work_items.open.find(params[:id])
      release = params[:assigned] == false
      if current.assignee && current.assignee != session[:staff_name]
        return render json: { error: "This item is assigned to #{current.assignee}." }, status: :conflict
      end

      current.update!(assignee: release ? nil : session[:staff_name],
        state: release ? "needs_attention" : "in_progress")
      current
    end
    render json: { state: item.state, assignee: item.assignee }
  end

  private

  def filtered_items(items)
    items = case params[:view]
    when "resolved" then items.where(state: "resolved")
    when "all" then items
    else items.open
    end
    items = items.where(kind: params[:kind]) if WorkItem::KINDS.key?(params[:kind])
    params[:search].to_s.strip.first(100).split.first(5).each do |word|
      names = [ word, word.downcase, word.upcase, word.capitalize ].uniq
      patients = Pms::Patient.where(first_name: names).or(Pms::Patient.where(last_name: names))
      items = items.where(visits: { patient_id: patients.select(:id) })
    end
    items
  end

  def board_card(item)
    visit = item.visit
    {
      id: item.id, kind: item.kind, reason: item.reason, state: item.state, assignee: item.assignee,
      patient: { id: visit.patient_id.to_s, name: visit.patient.name },
      visit: visit.source_start_at.strftime("%a, %b %-d · %-I:%M %p")
    }
  end
end
