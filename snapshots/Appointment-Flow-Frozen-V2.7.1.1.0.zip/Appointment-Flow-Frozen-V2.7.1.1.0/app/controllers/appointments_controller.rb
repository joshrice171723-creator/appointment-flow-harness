class AppointmentsController < ApplicationController
  before_action :require_staff
  PAGE_SIZE = 25

  def index
    date = params[:date].present? ? Date.iso8601(params[:date].to_s, limit: 10) : Time.current.in_time_zone(staff_office.zone).to_date
    visits = staff_office.visits
    day = visits.where(source_date: date)
    review_ids = staff_office.work_items.open.where(kind: "reply_review").select(:visit_id)
    review = day.where(id: review_ids)
    full_count = day.count
    confirmed_count = day.where.not(confirmed_at: nil).count
    totals = { all: full_count, confirmed: confirmed_count, unconfirmed: full_count - confirmed_count, review: review.count }

    displayed = case params[:view]
    when "confirmed" then day.where.not(confirmed_at: nil)
    when "unconfirmed" then day.where(confirmed_at: nil)
    when "review" then review
    else day
    end
    total = totals.stringify_keys.fetch(params[:view], full_count)
    pages = [ (total.to_f / PAGE_SIZE).ceil, 1 ].max
    page = params[:page].to_s.to_i.clamp(1, pages)
    rows = displayed.order(:source_start_at, :id).offset((page - 1) * PAGE_SIZE).limit(PAGE_SIZE).strict_loading.includes(:patient).to_a
    visible_reviews = staff_office.work_items.open.where(kind: "reply_review", visit_id: rows.map(&:id)).distinct.pluck(:visit_id).to_set

    render json: {
      visits: rows.map { |visit| visit_row(visit, visible_reviews.include?(visit.id)) },
      totals: totals, week: week_summary(visits, date), refreshed_at: staff_office.refreshed_at,
      page: page, pages: pages, total: total, date: date
    }
  rescue Date::Error
    render json: { error: "Choose a valid appointment date." }, status: :unprocessable_content
  end

  private

  def week_summary(visits, date)
    start = date.beginning_of_week
    days = (start...(start + 7)).to_a
    counts = visits.where(source_date: start...(start + 7)).group(:source_date).count
    days.map { |day| { date: day, count: counts.fetch(day, 0) } }
  end

  def visit_row(visit, needs_review)
    {
      id: visit.id, patient: { id: visit.patient_id.to_s, name: visit.patient.name },
      date: visit.source_start_at.to_date, time: visit.source_start_at.strftime("%-I:%M %p"),
      time_uncertain: visit.starts_at.nil?, provider: visit.provider_name, minutes: visit.length_minutes,
      confirmed: visit.confirmed_at.present?, needs_review: needs_review, outcome: visit.outcome
    }
  end
end
