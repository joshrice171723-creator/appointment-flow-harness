class ContactVerificationsController < ApplicationController
  before_action :require_staff

  def update
    fields = params.expect(contact: ContactDetails::FIELDS.map(&:to_sym)).to_h
    event = VerifyContact.new(staff_office, patient_id: params[:staff_patient_id], staff_name: session[:staff_name],
      fields: fields, event_key: params.expect(:event_key), revision: params.expect(:revision)).call
    render json: { id: event.id }
  rescue VerifyContact::InvalidFields => error
    render json: { error: error.message }, status: :unprocessable_content
  rescue VerifyContact::Conflict => error
    render json: { error: error.message }, status: :conflict
  rescue ActiveRecord::RecordInvalid => error
    render json: { error: error.record.errors.full_messages.to_sentence }, status: :unprocessable_content
  end
end
