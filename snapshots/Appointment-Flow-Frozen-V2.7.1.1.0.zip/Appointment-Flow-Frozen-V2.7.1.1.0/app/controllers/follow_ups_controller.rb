class FollowUpsController < ApplicationController
  before_action :require_staff

  def create
    attributes = params.permit(:event_key, :note, :outcome, :visit_id, :visit_revision, :work_item_id, candidates: %i[id revision])
    event = RecordFollowUp.new(staff_office, patient_id: params[:staff_patient_id],
      staff_name: session[:staff_name], attributes: attributes).call
    render json: { id: event.id, outcome: event.outcome }, status: :created
  rescue RecordFollowUp::Rejected => error
    render json: { error: error.message }, status: :unprocessable_content
  rescue RecordFollowUp::Conflict => error
    render json: { error: error.message }, status: :conflict
  rescue RecordFollowUp::SourceUnavailable => error
    render json: { error: error.message }, status: :service_unavailable
  rescue ActiveRecord::RecordInvalid => error
    render json: { error: error.record.errors.full_messages.to_sentence }, status: :unprocessable_content
  end
end
