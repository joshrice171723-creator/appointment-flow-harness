class OutcomesController < ApplicationController
  before_action :require_leadership

  def show
    month = params[:month].present? ? Date.iso8601("#{params[:month]}-01", limit: 10) : Date.current.beginning_of_month
    offices = Office.includes(:clinic).order(:id)
    render json: { month: month.strftime("%Y-%m"), clinics: offices.map { |office| clinic_totals(office, month) } }
  rescue Date::Error
    render json: { error: "Choose a valid outcome month." }, status: :unprocessable_content
  end

  private

  def clinic_totals(office, month)
    today = Time.current.in_time_zone(office.zone).to_date
    wall_range = office.wall_time_range(month, [ month.next_month, today + 1 ].min)
    activity_range = month.in_time_zone(office.zone)...month.next_month.in_time_zone(office.zone)
    source = Pms::Appointment.where(clinic_id: office.clinic_id, start_at: wall_range)
    statuses = source.group(:status).count
    dispositions = verified_dispositions(office, wall_range, source)
    completed = statuses.fetch("complete", 0)
    total = statuses.values.sum
    confirmed = office.visits.where(source_start_at: wall_range).where.not(confirmed_at: nil).count
    deliveries = office.deliveries.where(created_at: activity_range).group(:channel, :successful).count
    tasks = office.work_items.where(created_at: activity_range).group(:kind, :state).count
    events = office.staff_events.where(created_at: activity_range).group(:outcome).count

    {
      name: office.clinic.name, recorded: total, completed: completed, confirmed: confirmed,
      rescheduled: dispositions.fetch("rescheduled", 0), canceled: dispositions.fetch("canceled", 0),
      unknown: total - completed - dispositions.values.sum,
      completion_rate: total.positive? ? (100.0 * completed / total).round(1) : nil,
      deliveries: %w[sms email].index_with do |channel|
        { sent: deliveries.fetch([ channel, true ], 0), failed: deliveries.fetch([ channel, false ], 0) }
      end,
      holds: {
        open: tasks.fetch([ "contact_hold", "needs_attention" ], 0) + tasks.fetch([ "contact_hold", "in_progress" ], 0),
        resolved: tasks.fetch([ "contact_hold", "resolved" ], 0)
      },
      follow_ups: %w[attempted confirmed canceled rescheduled reviewed contact_verified].index_with { |key| events.fetch(key, 0) }
    }
  end

  def verified_dispositions(office, range, source)
    local = office.visits.where(source_start_at: range, disposition: %w[canceled rescheduled])
      .pluck(:source_id, :patient_id, :source_start_at, :disposition)
    current = source.where(id: local.map(&:first)).where.not(status: "complete")
      .pluck(:id, :patient_id, :start_at).to_set
    local.each_with_object(Hash.new(0)) do |(id, patient_id, time, disposition), totals|
      totals[disposition] += 1 if current.include?([ id, patient_id, time ])
    end
  end
end
