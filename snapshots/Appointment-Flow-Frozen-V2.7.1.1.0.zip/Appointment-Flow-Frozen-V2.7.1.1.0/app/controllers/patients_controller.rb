class PatientsController < ApplicationController
  before_action :require_patient_demo

  def index
    office = Office.find(params[:office_id])
    members = Pms::Patient.where(id: office.visits.select(:patient_id))
    former_recipients = Pms::Patient.where(id: office.deliveries.accepted.select(:patient_id))
    patients = members.or(former_recipients).order(:first_name, :last_name, :id)
    render json: patients.pluck(:id, :first_name, :last_name).map { |id, first, last| { id: id.to_s, name: "#{first} #{last}" } }
  end
end
