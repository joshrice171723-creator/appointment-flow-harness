namespace :reminders do
  desc "Run fake reminders for all clinics or one office ID, optionally at an ISO-8601 time"
  task :run, [ :office_id, :at ] => :environment do |_task, args|
    now = Time.iso8601(args[:at]) if args[:at]
    offices = args[:office_id] ? Office.where(id: args[:office_id]) : Office.all
    abort "No matching demo offices. Run db:seed first." unless offices.exists?

    failed = false
    offices.find_each do |office|
      totals = ReminderRun.new(office, now: now).call
      puts "#{office.clinic.name} · #{totals[:sent]} accepted, #{totals[:failed]} failed, #{totals[:tasks]} tasks opened"
    rescue RefreshVisits::Unavailable, ReminderRun::SourceChanged => error
      warn "#{office.clinic.name} · #{error.message}"
      failed = true
    end
    abort "At least one clinic could not finish its reminder run." if failed
  end
end
