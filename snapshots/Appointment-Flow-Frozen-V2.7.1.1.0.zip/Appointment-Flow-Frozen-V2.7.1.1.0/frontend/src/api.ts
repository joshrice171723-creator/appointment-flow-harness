import { useEffect, useRef, useState } from 'react'

interface ResponseError { error?: string }

let csrfToken = document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content

export async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers)
  headers.set('Accept', 'application/json')
  if (init.body) headers.set('Content-Type', 'application/json')
  if (csrfToken && init.method) headers.set('X-CSRF-Token', csrfToken)
  const response = await fetch('/api' + path, { ...init, headers })
  if (!response.ok) {
    const result: ResponseError = await response.json().catch(() => ({}))
    throw new Error(result.error ?? 'The request failed. Refresh to check the current state.')
  }
  return response.json() as Promise<T>
}

export async function selectWorkspace(selection: object | null) {
  const result = await request<{ csrf_token: string }>('/workspace', {
    method: selection ? 'POST' : 'DELETE',
    body: selection ? JSON.stringify(selection) : undefined,
  })
  csrfToken = result.csrf_token
}

interface Query<T> { key: string; data?: T; error?: string }

export function useQuery<T>(path: string | null, version = 0) {
  const [result, setResult] = useState<Query<T>>()
  const key = JSON.stringify([path, version])
  useEffect(() => {
    if (!path) return
    const controller = new AbortController()
    request<T>(path, { signal: controller.signal })
      .then((data) => { if (!controller.signal.aborted) setResult({ key, data }) })
      .catch((error: unknown) => {
        if (!controller.signal.aborted) setResult({ key, error: errorMessage(error) })
      })
    return () => controller.abort()
  }, [key, path])
  return result?.key === key ? result : undefined
}

export function errorMessage(error: unknown) {
  if (error instanceof TypeError) return 'Connection lost. Refresh to check the saved result or retry the same form.'
  return error instanceof Error ? error.message : 'The request could not be completed.'
}

export function useRequestKey() {
  const latest = useRef<{ fingerprint: string; key: string }>(null)
  return (payload: object) => {
    const fingerprint = JSON.stringify(payload)
    if (latest.current?.fingerprint !== fingerprint) latest.current = { fingerprint, key: crypto.randomUUID() }
    return latest.current.key
  }
}
