import type { ReactNode } from 'react'
import type { Page } from './types'

export function Header({ leave, context, busy, children }: {
  leave?: () => void; context?: string; busy?: boolean; children?: ReactNode
}) {
  return <header className="topbar">
    <div className="brand"><span className="brand-mark" aria-hidden="true">A<span>↗</span></span>
      <span><strong>APEX</strong><small>Appointment Flow</small></span>
    </div>
    <nav aria-label="Workspace navigation">
      {children}
      {context && <strong>{context}</strong>}
      {leave && <button className="text-button" type="button" onClick={leave} disabled={busy}>Workspaces ↗</button>}
    </nav>
  </header>
}

export function ErrorNotice({ children }: { children?: ReactNode }) {
  return children ? <p className="notice error" role="alert">{children}</p> : null
}

export function Loading() {
  return <p className="muted" role="status">Loading…</p>
}

export function Tabs<T extends string>({ items, value, change, label }: {
  items: ReadonlyArray<readonly [T, string]>
  value: T
  change: (value: T) => void
  label: string
}) {
  return <div className="tabs" role="group" aria-label={label}>
    {items.map(([id, title]) =>
      <button type="button" key={id} aria-pressed={id === value} onClick={() => change(id)}>{title}</button>)}
  </div>
}

export function Pager({ page, pages, total, change }: Page & { change: (page: number) => void }) {
  if (pages < 2) return null
  return <nav className="pager" aria-label="Pagination">
    <button disabled={page <= 1} onClick={() => change(page - 1)}>Previous</button>
    <span>Page {page} of {pages} · {total} records</span>
    <button disabled={page >= pages} onClick={() => change(page + 1)}>Next</button>
  </nav>
}

export function dateInZone(zone: string) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(new Date())
  const date = Object.fromEntries(parts.map(({ type, value }) => [type, value]))
  return `${date.year}-${date.month}-${date.day}`
}

export function shiftDate(iso: string, days: number) {
  const date = new Date(iso + 'T12:00:00Z')
  date.setUTCDate(date.getUTCDate() + days)
  return date.toISOString().slice(0, 10)
}

export function readableDate(iso: string, includeYear = false) {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'UTC', weekday: 'short', month: 'short', day: 'numeric',
    year: includeYear ? 'numeric' : undefined,
  }).format(new Date(iso + 'T12:00:00Z'))
}

export function readableInstant(iso: string, zone: string) {
  return new Intl.DateTimeFormat('en-US', { timeZone: zone, dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso))
}
