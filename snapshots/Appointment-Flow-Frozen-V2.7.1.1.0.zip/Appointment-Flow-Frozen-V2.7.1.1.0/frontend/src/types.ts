export interface Office {
  id: number
  name: string
  time_zone: string
  staff_names: string[]
}

export type Role = 'staff' | 'leadership' | 'patient'
export interface Selection {
  role: Role | null
  office_id: number | null
  staff_name: string | null
}

export interface Workspace {
  offices: Office[]
  selection: Selection
}

export interface Patient {
  id: string
  name: string
}

export interface Visit {
  id: number
  patient: Patient
  date: string
  time: string
  confirmed: boolean
  needs_review: boolean
  provider: string | null
  minutes: number | null
  outcome: string
}

export interface Page {
  page: number
  pages: number
  total: number
}
