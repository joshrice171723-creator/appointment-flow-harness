import { useState } from 'react'
import { useQuery } from './api'
import { dateInZone, ErrorNotice, Loading } from './ui'

const outcomeFields = [
  ['completed', 'Completed'], ['rescheduled', 'Rescheduled'], ['canceled', 'Canceled'], ['unknown', 'Unknown'],
] as const
type Outcome = (typeof outcomeFields)[number][0]
interface Clinic extends Record<Outcome, number> {
  name: string; recorded: number; confirmed: number; completion_rate: number | null
  deliveries: Record<'sms' | 'email', { sent: number; failed: number }>
  holds: { open: number; resolved: number }
  follow_ups: Record<'attempted' | 'confirmed' | 'rescheduled' | 'canceled' | 'reviewed' | 'contact_verified', number>
}
interface Report { month: string; clinics: Clinic[] }

export function Leadership() {
  const [month, setMonth] = useState(dateInZone('America/Chicago').slice(0, 7))
  const query = useQuery<Report>('/outcomes?' + new URLSearchParams({ month }))
  const report = query?.data
  const monthName = new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })
    .format(new Date(month + '-01T12:00:00Z'))

  return <>
    <header className="split-heading section-heading">
      <div><h1>Appointment outcomes</h1><p className="muted">Clinic totals from recorded visits and follow-up activity.</p></div>
      <label>Outcome month<input type="month" value={month} onChange={(event) => { if (event.target.value) setMonth(event.target.value) }} /></label>
    </header>
    <ErrorNotice>{query?.error}</ErrorNotice>
    {!query && <Loading />}
    {report && <div className="stack reports">
      <section className="panel">
        <h2>{monthName}</h2>
        {!report.clinics.length && <p className="empty">No reporting clinics are available.</p>}
        <div className="grid-two outcome-grid">{report.clinics.map((clinic) => <ClinicSummary key={clinic.name} clinic={clinic} />)}</div>
      </section>
      <section className="panel">
        <h2>Clinic comparison</h2>
        <p className="muted">Completion rate divides completed visits by visits dated through each clinic’s current date. Unknown outcomes include visits without a recorded result. These records do not identify no-shows.</p>
        <div className="table-wrap"><table><thead><tr>
          <th>Clinic</th><th>Completion rate</th><th>Recorded visits</th>
          <th>Completed</th><th>Rescheduled</th><th>Canceled</th><th>Unknown</th>
        </tr></thead><tbody>
          {report.clinics.map((clinic) => <tr key={clinic.name}><th scope="row">{clinic.name}</th>
            <td>{clinic.completion_rate === null ? '—' : `${clinic.completion_rate}%`}</td><td>{clinic.recorded}</td>
            {outcomeFields.map(([key]) => <td key={key}>{clinic[key]}</td>)}
          </tr>)}
        </tbody></table></div>
      </section>
      <MetricTable title="Monthly reminder activity" clinics={report.clinics} text="Fake delivery attempts dated in the selected month."
        columns={['Text accepted', 'Text failed', 'Email accepted', 'Email failed']}
        values={(clinic) => [clinic.deliveries.sms.sent, clinic.deliveries.sms.failed, clinic.deliveries.email.sent, clinic.deliveries.email.failed]} />
      <MetricTable title="Contact holds" clinics={report.clinics} text="Tasks opened in the selected month, grouped by current state."
        columns={['Open', 'Resolved']} values={(clinic) => [clinic.holds.open, clinic.holds.resolved]} />
      <MetricTable title="Contact and follow-up" clinics={report.clinics} text="Staff actions recorded in the selected month."
        columns={['Attempted', 'Confirmed', 'Rescheduled', 'Canceled', 'Reviewed', 'Contact verified']}
        values={(clinic) => [clinic.follow_ups.attempted, clinic.follow_ups.confirmed, clinic.follow_ups.rescheduled,
          clinic.follow_ups.canceled, clinic.follow_ups.reviewed, clinic.follow_ups.contact_verified]} />
    </div>}
  </>
}

function ClinicSummary({ clinic }: { clinic: Clinic }) {
  return <section className="outcome-card">
    <div className="split-heading"><h3>{clinic.name}</h3><span className="muted">{clinic.recorded} recorded visits</span></div>
    <div className="outcome-bar" aria-hidden="true">
      {outcomeFields.map(([key]) => <span key={key} className={key} style={{ flexGrow: clinic[key], display: clinic[key] ? undefined : 'none' }} />)}
    </div>
    <dl>{outcomeFields.map(([key, label]) => <div key={key}>
      <dt><span aria-hidden="true" className={'legend ' + key} />{label}</dt>
      <dd>{clinic[key]} <small>{clinic.recorded ? `${(100 * clinic[key] / clinic.recorded).toFixed(1)}%` : '—'}</small></dd>
    </div>)}</dl>
  </section>
}

function MetricTable({ title, clinics, text, columns, values }: {
  title: string; clinics: Clinic[]; text: string; columns: string[]; values: (clinic: Clinic) => number[];
}) {
  return <details className="panel">
    <summary>{title}</summary><p className="muted">{text}</p>
    <div className="table-wrap"><table><thead><tr><th>Clinic</th>{columns.map((title) => <th key={title}>{title}</th>)}</tr></thead>
      <tbody>{clinics.map((clinic) => <tr key={clinic.name}><th scope="row">{clinic.name}</th>
        {values(clinic).map((value, index) => <td key={columns[index]}>{value}</td>)}
      </tr>)}</tbody>
    </table></div>
  </details>
}
