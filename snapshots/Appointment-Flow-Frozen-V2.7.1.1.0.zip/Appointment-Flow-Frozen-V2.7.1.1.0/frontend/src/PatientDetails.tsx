import { useState } from 'react'
import { errorMessage, request, useQuery, useRequestKey } from './api'
import type { Office } from './types'
import { ErrorNotice, Loading, readableInstant, Tabs } from './ui'

const tabs = [['follow-up', 'Follow-up'], ['appointments', 'Appointments'], ['activity', 'Activity']] as const
const contactFields = [
  ['birthdate', 'Birthdate'], ['wireless_phone', 'Mobile phone'],
  ['email', 'Email'], ['preferred_language', 'Preferred language'],
] as const
type ContactField = (typeof contactFields)[number][0]
type ContactValues = Record<ContactField, string | null>
interface Contact {
  source: ContactValues; values: ContactValues; verified: ContactField[]; conflicts: ContactField[];
  hold: string | null; revision: string
}
interface PatientVisit {
  id: number; time: string; provider: string | null; confirmed: boolean; outcome: string; open: boolean; revision: number
}
interface WorkItem {
  id: number; kind: string; state: string; reason: string; assignee: string | null; visit_id: number;
  visit_time: string; current: boolean; reply: string | null; visit_revision: number;
  candidates: Array<{ id: number; name: string; time: string; revision: number }>;
}
interface Activity { id: number; created_at: string; outcome: string; note: string; staff_name: string }
interface Details {
  id: string; name: string; contact: Contact; visits: PatientVisit[]; work_items: WorkItem[]; activity: Activity[]
}

export function PatientDetails({ selection, office, staffName, close }: {
  selection: { patientId: string; itemId?: number; visitId?: number }; office: Office; staffName: string; close: () => void
}) {
  const [tab, setTab] = useState<(typeof tabs)[number][0]>('follow-up')
  const [version, setVersion] = useState(0)
  const [notice, setNotice] = useState('')
  const path = '/staff_patients/' + selection.patientId
  const priority = new URLSearchParams()
  if (selection.itemId) priority.set('item_id', String(selection.itemId))
  if (selection.visitId) priority.set('visit_id', String(selection.visitId))
  const query = useQuery<Details>(priority.size ? path + '?' + priority : path, version)
  const patient = query?.data
  const selectedItem = patient?.work_items.find(({ id }) => id === selection.itemId)
  const selectedVisit = patient?.visits.find(({ id }) => id === selection.visitId)

  function saved(message: string) {
    setNotice(message)
    setVersion((value) => value + 1)
  }

  return <>
    <div className="section-heading">
      <button className="text-button" onClick={close}>← Back to results</button>
      <p className="eyebrow">{office.name}</p>
      <h1>{patient?.name ?? 'Patient details'}</h1>
    </div>
    {notice && <p className="notice" role="status">{notice}</p>}
    <ErrorNotice>{query?.error}</ErrorNotice>
    {!query && <Loading />}
    {patient && <div className="patient-grid">
      <ContactCard contact={patient.contact} path={path} saved={saved} />
      <section className="panel">
        <Tabs items={tabs} value={tab} change={setTab} label="Patient detail view" />
        {tab === 'follow-up' && <>
          {selectedVisit && <div className="notice">
            <strong>{selectedVisit.time}</strong><p>{selectedVisit.provider ?? 'Provider unavailable'} · {selectedVisit.confirmed ? 'Confirmed' : 'Unconfirmed'}</p>
            {!selectedItem && selectedVisit.open && <FollowUpForm path={path} visitId={selectedVisit.id}
              visitRevision={selectedVisit.revision} saved={saved} />}
          </div>}
          {selectedItem && <Case item={selectedItem} path={path} staffName={staffName} saved={saved} />}
          {patient.work_items.filter(({ id }) => id !== selectedItem?.id).map((item) =>
            <details className="case" key={item.id}>
              <summary>{item.state === 'resolved' ? 'Resolved · ' : ''}{item.reason}</summary>
              <Case item={item} path={path} staffName={staffName} saved={saved} />
            </details>)}
          {!patient.work_items.length && !selectedVisit && <p className="empty">No follow-up items for this patient.</p>}
        </>}
        {tab === 'appointments' && <>
          <h2>Appointments</h2>
          {patient.visits.map((visit) => <article className="case" key={visit.id}>
            <h3>{visit.time}</h3><p>{visit.provider ?? 'Provider unavailable'}</p>
            <p><span className="badge">{visit.confirmed ? 'Confirmed' : 'Unconfirmed'}</span> · {visit.outcome}</p>
          </article>)}
        </>}
        {tab === 'activity' && <>
          <h2>Staff activity</h2>
          {!patient.activity.length && <p className="empty">No staff activity recorded.</p>}
          {patient.activity.map((entry) => <article key={entry.id} className="case">
            <h3>{outcomeLabels[entry.outcome] ?? entry.outcome}</h3><p>{entry.note}</p>
            <p className="muted">{entry.staff_name} · {readableInstant(entry.created_at, office.time_zone)}</p>
          </article>)}
        </>}
      </section>
    </div>}
  </>
}

function ContactCard({ contact, path, saved }: { contact: Contact; path: string; saved: (message: string) => void }) {
  const [draft, setDraft] = useState(contact.values)
  const [editing, setEditing] = useState(false)
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)
  const requestKey = useRequestKey()

  async function verify() {
    const payload = { contact: draft, revision: contact.revision }
    setPending(true)
    setError('')
    try {
      await request(path + '/contact_verification', { method: 'PATCH', body: JSON.stringify({ ...payload, event_key: requestKey(payload) }) })
      saved('Local contact details verified.')
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setPending(false)
    }
  }

  return <aside className="panel contact-card">
    <h2>Contact details</h2>
    {contact.hold && <p className="notice">{contact.hold}</p>}
    {editing ? <form className="stack" onSubmit={(event) => { event.preventDefault(); void verify() }}>
      {contactFields.map(([field, label]) => <label key={field}>{label}
        {field === 'preferred_language' ?
          <select value={draft[field] ?? ''} onChange={(event) => setDraft({ ...draft, [field]: event.target.value })}>
            <option value="">Unknown</option><option value="en">English</option><option value="es">Spanish</option>
          </select> :
          <input type={field === 'birthdate' ? 'date' : field === 'email' ? 'email' : 'tel'} value={draft[field] ?? ''}
            onChange={(event) => setDraft({ ...draft, [field]: event.target.value })} />}
      </label>)}
      <ErrorNotice>{error}</ErrorNotice>
      <div className="actions"><button className="primary" disabled={pending}>Save verification</button>
        <button type="button" disabled={pending} onClick={() => { setEditing(false); setError('') }}>Cancel</button></div>
    </form> : <>
      <dl>{contactFields.map(([field, label]) => <div key={field}>
        <dt>{label}</dt>
        <dd>{displayValue(field, contact.values[field])}</dd>
        <dd className="muted">{contact.conflicts.includes(field) ?
          `PMS changed to ${displayValue(field, contact.source[field])}` :
          contact.verified.includes(field) ? 'Verified locally' : 'Unverified · PMS'}</dd>
      </div>)}</dl>
      <button onClick={() => { setDraft(contact.values); setEditing(true) }}>Verify or correct</button>
    </>}
  </aside>
}

function displayValue(field: ContactField, raw: string | null) {
  if (field === 'preferred_language') return raw === 'en' ? 'English' : raw === 'es' ? 'Spanish' : raw ?? 'Unknown'
  return raw || 'Unavailable'
}

function Case({ item, path, staffName, saved }: { item: WorkItem; path: string; staffName: string; saved: (message: string) => void }) {
  const [pending, setPending] = useState(false)
  const [error, setError] = useState('')
  const owned = item.assignee === staffName
  const available = !item.assignee || owned
  const resolved = item.state === 'resolved'

  async function assign() {
    setPending(true)
    setError('')
    try {
      await request('/work_items/' + item.id, { method: 'PATCH', body: JSON.stringify({ assigned: !owned }) })
      saved(owned ? 'Assignment released.' : 'Follow-up assigned to you.')
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setPending(false)
    }
  }

  return <section className="case">
    <div className="split-heading"><h3>{item.reason}</h3>
      <span className={'badge' + (resolved ? '' : ' attention')}>{resolved ? 'Resolved' : owned ? 'Assigned to you' : item.assignee ?? 'Unassigned'}</span>
    </div>
    <p className="muted">{item.visit_time}{!item.current && ' · Previous appointment version'}</p>
    {item.reply && <blockquote>{item.reply}</blockquote>}
    <ErrorNotice>{error}</ErrorNotice>
    {!resolved && available && <>
      <button onClick={() => void assign()} disabled={pending}>{owned ? 'Release assignment' : 'Assign to me'}</button>
      <FollowUpForm path={path} visitId={item.visit_id} visitRevision={item.visit_revision} item={item} saved={saved} />
    </>}
  </section>
}

const outcomeLabels: Record<string, string> = {
  attempted: 'Contact attempted', confirmed: 'Confirmed', rescheduled: 'Rescheduled',
  canceled: 'Canceled', reviewed: 'Close after review', contact_verified: 'Contact verified',
}

function FollowUpForm({ path, visitId, visitRevision, item, saved }: {
  path: string; visitId: number; visitRevision: number; item?: WorkItem; saved: (message: string) => void
}) {
  const [note, setNote] = useState('')
  const [outcome, setOutcome] = useState('attempted')
  const [selected, setSelected] = useState<number[]>([])
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)
  const requestKey = useRequestKey()
  const needsSelection = item?.kind === 'reply_review' && ['confirmed', 'rescheduled', 'canceled'].includes(outcome)
  const canChange = !item || (item.current && (item.kind !== 'reply_review' || item.candidates.length > 0))
  const outcomes = canChange ? ['attempted', 'confirmed', 'rescheduled', 'canceled', 'reviewed'] : ['attempted', 'reviewed']

  async function submit() {
    const candidates = needsSelection ? item?.candidates.filter(({ id }) => selected.includes(id))
      .map(({ id, revision }) => ({ id, revision })) : []
    const payload = { visit_id: visitId, visit_revision: visitRevision, work_item_id: item?.id, note, outcome, candidates }
    setPending(true)
    setError('')
    try {
      await request(path + '/follow_ups', { method: 'POST', body: JSON.stringify({ ...payload, event_key: requestKey(payload) }) })
      saved('Follow-up recorded.')
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setPending(false)
    }
  }

  return <form className="stack follow-up-form" onSubmit={(event) => { event.preventDefault(); void submit() }}>
    <label>Outcome<select value={outcome} onChange={(event) => setOutcome(event.target.value)}>
      {outcomes.map((id) => <option key={id} value={id}>{outcomeLabels[id]}</option>)}
    </select></label>
    {needsSelection && item && <fieldset><legend>Appointments clarified with the patient</legend>
      {item.candidates.map((candidate) => <label className="checkbox" key={candidate.id}>
        <input type="checkbox" checked={selected.includes(candidate.id)} onChange={(event) =>
          setSelected(event.target.checked ? [...selected, candidate.id] : selected.filter((id) => id !== candidate.id))} />
        {candidate.name} · {candidate.time}
      </label>)}
    </fieldset>}
    <label>Follow-up note<textarea required maxLength={500} value={note} onChange={(event) => setNote(event.target.value)} /></label>
    <ErrorNotice>{error}</ErrorNotice>
    <div><button className="primary" disabled={pending || !note.trim() || (needsSelection && !selected.length)}>Record follow-up</button></div>
  </form>
}
