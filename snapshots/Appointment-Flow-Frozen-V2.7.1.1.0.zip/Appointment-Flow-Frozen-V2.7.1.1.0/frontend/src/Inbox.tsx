import { useState } from 'react'
import { errorMessage, request, useQuery, useRequestKey } from './api'
import type { Office, Patient } from './types'
import { ErrorNotice, Loading, readableInstant, Tabs } from './ui'

const channels = [['sms', 'Text messages'], ['email', 'Email']] as const
type Channel = (typeof channels)[number][0]
interface Message { id: number; body: string; created_at: string }
interface Reply extends Message { result: string }
interface Thread extends Message { replies: Reply[] }

const replyResults: Record<string, string> = {
  confirmed: 'Appointment confirmed',
  needs_review: 'Sent to the front desk for review',
  opted_out: 'Text reminders stopped',
}

export function Inbox({ offices }: { offices: Office[] }) {
  const [officeId, setOfficeId] = useState('')
  const [patientId, setPatientId] = useState('')
  const office = offices.find(({ id }) => String(id) === officeId)
  const path = office ? '/offices/' + office.id + '/patients' : null
  const query = useQuery<Patient[]>(path)

  return <>
    <header className="section-heading"><h1>Patient inbox</h1><p className="muted">Demo messages for fictional patients.</p></header>
    <div className="stack">
      <label>Clinic<select value={officeId} onChange={(event) => { setOfficeId(event.target.value); setPatientId('') }}>
        <option value="">Choose a clinic</option>
        {offices.map(({ id, name }) => <option key={id} value={id}>{name}</option>)}
      </select></label>
      {office && !query && <Loading />}
      <ErrorNotice>{query?.error}</ErrorNotice>
      {query?.data && <label>Patient<select value={patientId} onChange={(event) => setPatientId(event.target.value)}>
        <option value="">{query.data.length ? 'Choose a patient' : 'No patients in this clinic'}</option>
        {query.data.map(({ id, name }) => <option key={id} value={id}>{name}</option>)}
      </select></label>}
    </div>
    {path && patientId && office && <Conversation key={path + '/' + patientId} path={path + '/' + patientId} zone={office.time_zone} />}
  </>
}

function Conversation({ path, zone }: { path: string; zone: string }) {
  const [channel, setChannel] = useState<Channel>('sms')
  const [version, setVersion] = useState(0)
  const [notice, setNotice] = useState('')
  const query = useQuery<Thread[]>(path + '/inbox?channel=' + channel, version)
  const threads = query?.data
  const history = threads && [...threads].reverse()

  return <>
    <Tabs items={channels} value={channel} change={(next) => { setChannel(next); setNotice('') }} label="Message channel" />
    {notice && <p className="notice" role="status">{notice}</p>}
    <ErrorNotice>{query?.error}</ErrorNotice>
    {!query && <Loading />}
    {history?.length === 0 && <p className="empty">{channel === 'sms' ? 'No simulated texts' : 'No simulated emails'} for this patient yet.</p>}
    {history && history.length > 0 && <>
      <ol className="message-history">
        {history.map((message) => <li key={message.id}>
          <article className="panel message">
            <div className="split-heading"><strong>Clinic reminder</strong><time dateTime={message.created_at}>{readableInstant(message.created_at, zone)}</time></div>
            <p>{message.body}</p>
          </article>
          {message.replies.map((reply) => <article className="panel message patient-message" key={reply.id}>
            <div className="split-heading"><strong>Patient reply</strong><time dateTime={reply.created_at}>{readableInstant(reply.created_at, zone)}</time></div>
            <p>{reply.body}</p><span className="badge">{replyResults[reply.result] ?? 'Received'}</span>
          </article>)}
        </li>)}
      </ol>
      <ReplyForm key={channel} threads={threads ?? []} path={path} zone={zone} onSent={(result) => {
        setNotice(replyResults[result] ?? 'Reply received.')
        setVersion((value) => value + 1)
      }} />
    </>}
  </>
}

function ReplyForm({ path, threads, zone, onSent }: {
  path: string; threads: Thread[]; zone: string; onSent: (result: string) => void
}) {
  const [deliveryId, setDeliveryId] = useState(threads[0]?.id)
  const [body, setBody] = useState('')
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)
  const requestKey = useRequestKey()

  async function reply() {
    const payload = { delivery_id: deliveryId, body }
    setPending(true)
    setError('')
    try {
      const response = await request<{ result: string }>(path + '/replies', {
        method: 'POST', body: JSON.stringify({ ...payload, event_key: requestKey(payload) }),
      })
      onSent(response.result)
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setPending(false)
    }
  }

  return <form className="panel stack" onSubmit={(event) => { event.preventDefault(); void reply() }}>
    <h2>Simulate reply</h2>
    <label>Reply to reminder<select value={deliveryId} onChange={(event) => setDeliveryId(Number(event.target.value))}>
      {threads.map((message) => <option key={message.id} value={message.id}>{readableInstant(message.created_at, zone)} · Message {message.id}</option>)}
    </select></label>
    <label>Reply<textarea required maxLength={500} value={body} onChange={(event) => setBody(event.target.value)} placeholder="Enter a message" /></label>
    <ErrorNotice>{error}</ErrorNotice>
    <div><button className="primary" disabled={pending || !body.trim()}>{pending ? 'Submitting…' : 'Send simulated reply'}</button></div>
  </form>
}
