import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { afterEach, beforeEach, expect, test, vi } from 'vitest'
import { App } from './App'

const offices = [
  { id: 1, name: 'Austin, TX', time_zone: 'America/Chicago', staff_names: ['Robin Shaw'] },
  { id: 2, name: 'Phoenix, AZ', time_zone: 'America/Phoenix', staff_names: ['Jordan Rivers'] },
]
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status })

beforeEach(() => { vi.stubGlobal('fetch', vi.fn()) })
afterEach(() => { cleanup(); vi.unstubAllGlobals() })

test('switching the clinic selects only that clinic’s staff and opens the scoped board', async () => {
  const fetch = vi.mocked(globalThis.fetch)
  fetch.mockResolvedValueOnce(json({ offices, selection: {} }))
    .mockResolvedValueOnce(json({ csrf_token: 'new-token' }))
    .mockResolvedValueOnce(json({ offices, selection: { role: 'staff', office_id: 2, staff_name: 'Jordan Rivers' } }))
    .mockResolvedValueOnce(json({ items: [], totals: {}, kinds: {}, page: 1, pages: 1, total: 0 }))
  render(<App />)
  await screen.findByRole('heading', { name: 'Workspaces' })
  fireEvent.change(screen.getByLabelText('Clinic'), { target: { value: '2' } })
  expect(within(screen.getByLabelText(/staff member/i)).queryByText('Robin Shaw')).toBeNull()
  fireEvent.click(screen.getByRole('button', { name: /open front desk/i }))
  await screen.findByRole('heading', { name: 'Patient flow' })
  expect(screen.getByText('Front desk · Jordan Rivers')).toBeTruthy()
  expect(JSON.parse(String(fetch.mock.calls[1][1]?.body))).toEqual({
    role: 'staff', office_id: 2, staff_name: 'Jordan Rivers',
  })
})

test('email can be empty and a rejected SMS reply retains its draft', async () => {
  const fetch = vi.mocked(globalThis.fetch)
  const threads = [{ id: 5, body: 'Clinic reminder text.', created_at: '2026-11-16T18:00:00Z', replies: [] }]
  fetch.mockImplementation(async (input, init) => {
    const path = String(input)
    if (path === '/api/workspace') return json({ offices, selection: { role: 'patient' } })
    if (path.endsWith('/patients')) return json([{ id: '3', name: 'Mara Lin' }])
    if (path.endsWith('channel=email')) return json([])
    if (path.endsWith('channel=sms')) return json(threads)
    if (path.endsWith('/replies') && init?.method === 'POST') return json({ error: 'Refresh the inbox before trying again.' }, 409)
    throw new Error('Unexpected request ' + path)
  })
  render(<App />)
  await screen.findByRole('heading', { name: 'Patient inbox' })
  fireEvent.change(screen.getByLabelText('Clinic'), { target: { value: '1' } })
  const patient = await screen.findByLabelText('Patient')
  fireEvent.change(patient, { target: { value: '3' } })
  await screen.findByText('Clinic reminder text.')
  fireEvent.click(screen.getByRole('button', { name: 'Email' }))
  await screen.findByText('No simulated emails for this patient yet.')
  fireEvent.click(screen.getByRole('button', { name: 'Text messages' }))
  const draft = await screen.findByRole('textbox', { name: 'Reply' })
  fireEvent.change(draft, { target: { value: 'YES' } })
  fireEvent.click(screen.getByRole('button', { name: 'Send simulated reply' }))
  const warning = await screen.findByRole('alert')
  expect(warning.textContent).toMatch(/refresh the inbox/i)
  expect((draft as HTMLTextAreaElement).value).toBe('YES')
  const first = fetch.mock.calls.find(([url]) => String(url).endsWith('/replies'))
  fireEvent.click(screen.getByRole('button', { name: 'Send simulated reply' }))
  await waitFor(() => expect(fetch.mock.calls.filter(([url]) => String(url).endsWith('/replies'))).toHaveLength(2))
  expect(fetch.mock.calls.at(-1)?.[1]?.body).toBe(first?.[1]?.body)
})
