import { useState } from 'react'
import { errorMessage, request, useQuery } from './api'
import { PatientDetails } from './PatientDetails'
import type { Office, Page, Patient, Visit } from './types'
import { dateInZone, ErrorNotice, Header, Loading, Pager, readableDate, readableInstant, shiftDate, Tabs } from './ui'

const boardViews = [['active', 'Active work'], ['resolved', 'Resolved'], ['all', 'All work']] as const
const appointmentViews = [['all', 'All appointments'], ['confirmed', 'Confirmed'],
  ['unconfirmed', 'Unconfirmed'], ['review', 'Replies to review']] as const
const states = [['needs_attention', 'Needs attention'], ['in_progress', 'In progress'], ['resolved', 'Resolved']] as const

interface DetailsSelection { patientId: string; itemId?: number; visitId?: number }
type OpenDetails = (selection: DetailsSelection) => void

export function Staff({ office, staffName, leave, error, busy }: {
  office: Office; staffName: string; leave: () => void; error: string; busy: boolean
}) {
  const [view, setView] = useState<'board' | 'appointments'>('board')
  const [details, setDetails] = useState<DetailsSelection>()
  const [version, setVersion] = useState(0)
  const [action, setAction] = useState('')
  const [notice, setNotice] = useState('')
  const [failure, setFailure] = useState('')

  async function update(kind: 'refreshes' | 'reminder_runs') {
    setAction(kind)
    setNotice('')
    setFailure('')
    try {
      const result = await request<{ sent: number; failed: number; tasks: number }>('/' + kind, { method: 'POST' })
      setVersion((value) => value + 1)
      setNotice(kind === 'refreshes' ? 'Appointments refreshed.' :
        `Simulated reminders: ${result.sent} accepted, ${result.failed} failed. New follow-up tasks: ${result.tasks}.`)
    } catch (problem) {
      setFailure(errorMessage(problem))
    } finally {
      setAction('')
    }
  }

  function navigate(next: typeof view) {
    setView(next)
    if (details) closeDetails()
  }

  function closeDetails() {
    setDetails(undefined)
    setVersion((value) => value + 1)
  }

  return <>
    <Header leave={leave} busy={busy}>
      <button className="text-button" onClick={() => navigate('board')} aria-current={view === 'board' ? 'page' : undefined}>Patient flow</button>
      <button className="text-button" onClick={() => navigate('appointments')} aria-current={view === 'appointments' ? 'page' : undefined}>Appointments</button>
    </Header>
    <main className="shell">
      <ErrorNotice>{error || failure}</ErrorNotice>
      {notice && <p className="notice" role="status">{notice}</p>}
      {details && <PatientDetails key={details.patientId + ':' + (details.itemId ?? details.visitId ?? '')}
        selection={details} office={office} staffName={staffName} close={closeDetails} />}
      <div hidden={!!details}>
        <header className="section-heading split-heading">
          <div><p className="eyebrow">{office.name}</p><h1>{view === 'board' ? 'Patient flow' : 'Appointments'}</h1>
            <p className="muted">Front desk · {staffName}</p></div>
          <div className="actions">
            <button disabled={!!action} onClick={() => void update('refreshes')}>{action === 'refreshes' ? 'Refreshing…' : 'Refresh PMS'}</button>
            <button className="primary" disabled={!!action} onClick={() => void update('reminder_runs')}>
              {action === 'reminder_runs' ? 'Running reminders…' : 'Run demo reminders'}
            </button>
          </div>
        </header>
        {view === 'board' ? <Board version={version} office={office} open={setDetails} /> :
          <Appointments version={version} office={office} open={setDetails} />}
      </div>
    </main>
  </>
}

interface BoardItem { id: number; patient: Patient; reason: string; kind: string; state: string; assignee: string | null; visit: string }
interface BoardResponse extends Page {
  items: BoardItem[]
  totals: Record<string, number>
  kinds: Record<string, string>
  refreshed_at: string | null
}

function Board({ office, version, open }: { office: Office; version: number; open: OpenDetails }) {
  const [view, setView] = useState<(typeof boardViews)[number][0]>('active')
  const [search, setSearch] = useState('')
  const [draft, setDraft] = useState('')
  const [kind, setKind] = useState('')
  const [page, setPage] = useState(1)
  const params = new URLSearchParams({ view, search, kind, page: String(page) })
  const query = useQuery<BoardResponse>('/work_items?' + params, version)
  const data = query?.data
  const columns = view === 'active' ? states.slice(0, 2) : view === 'resolved' ? states.slice(2) : states
  const kinds = data?.kinds ?? {
    no_reply: 'No confirmation', contact_hold: 'Contact hold', delivery_failed: 'Delivery failed', reply_review: 'Reply to review',
  }

  return <>
    <LastRefresh instant={data?.refreshed_at} zone={office.time_zone} />
    {data && <div className="stat-grid">{states.map(([id, label]) => <section className="panel stat" key={id}>
      <span>{label}</span><strong>{data.totals[id] ?? 0}</strong>
    </section>)}</div>}
    <Tabs items={boardViews} value={view} change={(next) => { setView(next); setPage(1) }} label="Board view" />
    <form className="panel filters" onSubmit={(event) => { event.preventDefault(); setSearch(draft.trim()); setPage(1) }}>
      <label>Patient name<input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="First or last name" /></label>
      <button type="submit">Search</button>
      <label>Issue type<select value={kind} onChange={(event) => { setKind(event.target.value); setPage(1) }}>
        <option value="">All issue types</option>
        {Object.entries(kinds).map(([id, label]) => <option key={id} value={id}>{label}</option>)}
      </select></label>
    </form>
    <ErrorNotice>{query?.error}</ErrorNotice>
    {!query && <Loading />}
    {data && <>
      <div className="board-columns">{columns.map(([id, label]) => <section className="board-column" key={id}>
        <h2>{label}</h2>
        {data.items.filter((item) => item.state === id).length === 0 && <p className="empty">No matching work on this page.</p>}
        {data.items.filter((item) => item.state === id).map((item) => <article className="panel work-card" key={item.id}>
          <div className="split-heading"><h3>{item.patient.name}</h3><span className="badge attention">{kinds[item.kind]}</span></div>
          <p>{item.reason}</p><p className="muted">{item.visit} · {item.assignee ?? 'Unassigned'}</p>
          <button onClick={() => open({ patientId: item.patient.id, itemId: item.id })}>Open follow-up →</button>
        </article>)}
      </section>)}</div>
      <Pager {...data} change={setPage} />
    </>}
  </>
}

interface AppointmentsResponse extends Page {
  visits: Array<Visit & { time_uncertain: boolean }>
  totals: Record<string, number>
  week: Array<{ date: string; count: number }>
  refreshed_at: string | null
}

function Appointments({ office, version, open }: { office: Office; version: number; open: OpenDetails }) {
  const today = dateInZone(office.time_zone)
  const [date, setDate] = useState(today)
  const [view, setView] = useState<(typeof appointmentViews)[number][0]>('all')
  const [page, setPage] = useState(1)
  const params = new URLSearchParams({ date, view, page: String(page) })
  const query = useQuery<AppointmentsResponse>('/appointments?' + params, version)
  const data = query?.data

  function go(next: string) {
    if (next) { setDate(next); setPage(1) }
  }

  return <>
    <LastRefresh instant={data?.refreshed_at} zone={office.time_zone} />
    <section className="panel stack">
      <div className="filters calendar-tools">
        <button onClick={() => go(shiftDate(date, -7))}>← Previous week</button>
        <button onClick={() => go(today)}>Today</button>
        <button onClick={() => go(shiftDate(date, 7))}>Next week →</button>
        <label>Jump to date<input type="date" value={date} onChange={(event) => go(event.target.value)} /></label>
      </div>
      <div className="week">
        {data?.week.map((day) => <button key={day.date} aria-pressed={day.date === date} onClick={() => go(day.date)}>
          {readableDate(day.date)}<small>{day.count} {day.count === 1 ? 'visit' : 'visits'}</small>
        </button>)}
      </div>
    </section>
    <Tabs items={appointmentViews.map(([id, label]) => [id, data ? `${label} (${data.totals[id]})` : label] as const)}
      value={view} change={(next) => { setView(next); setPage(1) }} label="Appointment status" />
    <ErrorNotice>{query?.error}</ErrorNotice>
    {!query && <Loading />}
    {data && <section className="panel">
      <h2>{readableDate(date, true)}</h2>
      {!data.visits.length ? <p className="empty">No appointments match this date and status.</p> :
        <div className="table-wrap"><table><thead><tr>
          <th>Patient</th><th>Appointment</th><th>Confirmation</th><th>Visit outcome</th><th>Next step</th>
        </tr></thead><tbody>
          {data.visits.map((visit) => <tr key={visit.id}>
            <td><strong>{visit.patient.name}</strong></td>
            <td>{visit.time} · {visit.minutes ?? '—'} min<small>{visit.provider}{visit.time_uncertain && ' · Verify source time'}</small></td>
            <td><span className={'badge' + (visit.needs_review ? ' attention' : '')}>{visit.needs_review ? 'Reply to review' :
              visit.confirmed ? 'Confirmed' : 'Unconfirmed'}</span></td>
            <td>{visit.outcome}</td>
            <td><button className="text-button" onClick={() => open({ patientId: visit.patient.id, visitId: visit.id })}>Patient details →</button></td>
          </tr>)}
        </tbody></table></div>}
      <Pager {...data} change={setPage} />
    </section>}
  </>
}

function LastRefresh({ instant, zone }: { instant?: string | null; zone: string }) {
  return <p className="muted refresh-time">Last PMS sync {instant ? readableInstant(instant, zone) : 'not recorded'} · {zone}</p>
}
