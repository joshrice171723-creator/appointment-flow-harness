import { useState } from 'react'
import { errorMessage, selectWorkspace, useQuery } from './api'
import type { Office, Role, Selection, Workspace } from './types'
import { ErrorNotice, Header, Loading } from './ui'
import { Staff } from './Staff'
import { Leadership } from './Leadership'
import { Inbox } from './Inbox'

export function App() {
  const [version, setVersion] = useState(0)
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)
  const query = useQuery<Workspace>('/workspace', version)
  const workspace = query?.data
  const selection = workspace?.selection
  const office = workspace?.offices.find(({ id }) => id === selection?.office_id)

  async function open(role?: Role, officeId?: number, staffName?: string) {
    setError('')
    setPending(true)
    try {
      await selectWorkspace(role ? { role, office_id: officeId, staff_name: staffName } : null)
      setVersion((value) => value + 1)
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setPending(false)
    }
  }

  if (selection?.role === 'staff' && office && selection.staff_name) {
    return <Staff key={office.id} office={office} staffName={selection.staff_name}
      leave={() => void open()} error={error} busy={pending} />
  }

  return <>
    <Header leave={selection?.role ? () => void open() : undefined} busy={pending}
      context={selection?.role === 'leadership' ? 'Apex leadership' : undefined} />
    <main className={containerClass(selection)}>
      <ErrorNotice>{error || query?.error}</ErrorNotice>
      {!query && <Loading />}
      {workspace && !selection?.role && <Workspaces offices={workspace.offices} open={open} pending={pending} />}
      {workspace && selection?.role === 'patient' && <Inbox offices={workspace.offices} />}
      {workspace && selection?.role === 'leadership' && <Leadership />}
    </main>
  </>
}

function containerClass(selection?: Selection) {
  if (selection?.role === 'patient') return 'shell narrow'
  if (selection?.role === 'leadership') return 'shell'
  return 'shell landing'
}

function Workspaces({ offices, open, pending }: {
  offices: Office[]
  open: (role: Role, officeId?: number, staffName?: string) => Promise<void>
  pending: boolean
}) {
  const [officeId, setOfficeId] = useState(offices[0]?.id)
  const [staffName, setStaffName] = useState('')
  const office = offices.find(({ id }) => id === officeId)
  const staff = staffName || office?.staff_names[0] || ''

  return <>
    <h1>Workspaces</h1>
    <div className="workspace-grid">
      <form className="panel workspace-card" onSubmit={(event) => {
        event.preventDefault()
        if (office && staff) void open('staff', office.id, staff)
      }}>
        <h2>Front desk</h2>
        <p>Review appointments and follow up with patients.</p>
        <label>Clinic
          <select value={officeId ?? ''} onChange={(event) => {
            setOfficeId(Number(event.target.value)); setStaffName('')
          }}>
            {!offices.length && <option value="">No clinics available</option>}
            {offices.map(({ id, name }) => <option key={id} value={id}>{name}</option>)}
          </select>
        </label>
        <label>Staff member <span className="muted">Demo sign-in</span>
          <select value={staff} onChange={(event) => setStaffName(event.target.value)}>
            {office?.staff_names.map((name) => <option key={name}>{name}</option>)}
          </select>
        </label>
        <button className="primary card-action" disabled={pending || !staff}>Open front desk <span aria-hidden="true">→</span></button>
      </form>
      <section className="panel workspace-card sage">
        <h2>Apex leadership</h2>
        <p>Review appointment outcomes and follow-up totals by clinic.</p>
        <div className="clinic-count"><strong>{offices.length}</strong><span>{offices.length === 1 ? 'clinic' : 'clinics'}</span></div>
        <button className="primary card-action" disabled={pending} onClick={() => void open('leadership')}>
          Open Apex leadership <span aria-hidden="true">→</span>
        </button>
      </section>
      <section className="panel workspace-card">
        <h2>Patient</h2>
        <p>View a fictional patient’s text and email history and simulate a reply.</p>
        <button className="primary card-action" disabled={pending || !offices.length} onClick={() => void open('patient')}>
          Open patient inbox <span aria-hidden="true">→</span>
        </button>
      </section>
    </div>
  </>
}
