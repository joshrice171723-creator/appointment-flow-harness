import { defineConfig } from '@playwright/test'
import { fileURLToPath } from 'node:url'

const baseURL = process.env.APEX_SMOKE_URL ?? 'http://127.0.0.1:3107'

export default defineConfig({
  testDir: 'e2e',
  workers: 1,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  use: { baseURL, channel: process.platform === 'win32' ? 'msedge' : undefined, trace: 'retain-on-failure' },
  webServer: process.env.APEX_SMOKE_URL ? undefined : {
    command: 'bundle exec ruby bin/rails server -b 127.0.0.1 -p 3107',
    cwd: fileURLToPath(new URL('..', import.meta.url)),
    url: baseURL + '/up',
    timeout: 120_000,
  },
})
