module FictionalPms
  class Clinic < ApplicationRecord
    self.table_name = "clinics"
  end

  class Patient < ApplicationRecord
    self.table_name = "patients"
  end

  class Appointment < ApplicationRecord
    self.table_name = "appointments"
  end

  def create_office(name: "Austin", zone: "America/Chicago")
    clinic = Clinic.create!(name: name)
    Office.create!(clinic_id: clinic.id, time_zone: zone, staff_names: [ "Robin Shaw" ])
  end

  def create_patient(**attributes)
    defaults = {
      first_name: "Dana", last_name: "Grove", birthdate: Date.new(1987, 6, 8),
      wireless_phone: "+1 512 555 0101", email: "dana@example.invalid", preferred_language: "en"
    }
    Patient.create!(defaults.merge(attributes))
  end

  def create_appointment(office, patient, **attributes)
    defaults = {
      clinic_id: office.clinic_id, patient_id: patient.id,
      start_at: Time.utc(2026, 11, 23, 11), status: "scheduled",
      length_minutes: 40, provider_name: "Dr. Finch"
    }
    Appointment.create!(defaults.merge(attributes))
  end
end
