ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"
require_relative "support/fictional_pms"

class ActiveSupport::TestCase
  include FictionalPms
end
