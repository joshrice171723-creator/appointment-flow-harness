require "test_helper"
require Rails.root.join("quality/rails_workload_probe")

class StaffWorkspacesTest < ActionDispatch::IntegrationTest
  setup do
    @office = create_office
    @other = create_office(name: "Phoenix", zone: "America/Phoenix")
    @patient = create_patient
    @other_patient = create_patient(first_name: "Avery", email: nil, wireless_phone: "480-555-0102")
    @appointment = create_appointment(@office, @patient, start_at: Time.utc(2026, 11, 17, 11))
    create_appointment(@other, @other_patient, start_at: Time.utc(2026, 11, 17, 11))
    travel_to Time.utc(2026, 11, 16, 18)
    ReminderRun.new(@office).call
    ReminderRun.new(@other).call
    sign_in_staff
  end

  test "appointment counts and fixed page size survive unrelated clinic and date growth" do
    visit = @office.visits.sole
    visit.update!(confirmed_at: Time.current)
    base = { clinic_id: @office.clinic_id, patient_id: @patient.id, start_at: @appointment.start_at, status: "scheduled" }
    FictionalPms::Appointment.insert_all!(Array.new(31, base))
    post "/api/refreshes"
    assert_response :created
    _, baseline = RailsWorkloadProbe.measure { get "/api/appointments", params: { date: "2026-11-17" } }
    assert_response :ok
    result = response.parsed_body
    assert_equal 25, result.fetch("visits").size
    assert_equal({ "all" => 32, "confirmed" => 1, "unconfirmed" => 31, "review" => 0 }, result.fetch("totals"))
    assert_equal 2, result.fetch("pages")
    assert_equal visit.id, result.fetch("visits").first.fetch("id")
    assert_equal 32, result.fetch("week").find { |day| day["date"] == "2026-11-17" }.fetch("count")

    FictionalPms::Appointment.insert_all!(
      Array.new(200, base.merge(clinic_id: @other.clinic_id)) +
      Array.new(200, base.merge(start_at: Time.utc(2026, 11, 30, 11)))
    )
    RefreshVisits.new(@other).call
    RefreshVisits.new(@office).call
    _, growth = RailsWorkloadProbe.measure { get "/api/appointments", params: { date: "2026-11-17" } }
    assert_equal result, response.parsed_body
    assert_equal baseline.values_at(:database_statements, :read_rows, :instantiated_records),
      growth.values_at(:database_statements, :read_rows, :instantiated_records)
    puts "Appointments baseline #{baseline.inspect}; unrelated growth #{growth.inspect}" if ENV["WORKLOAD"]
    get "/api/appointments", params: { date: "2026-11-17", view: "confirmed" }
    assert_equal 1, response.parsed_body.fetch("total")
    assert_equal result.fetch("totals"), response.parsed_body.fetch("totals")
    get "/api/appointments", params: { date: "2026-11-17", page: 2 }
    assert_equal 7, response.parsed_body.fetch("visits").size
  end

  test "board search, assignment, validation and staff confirmation are clinic scoped" do
    item = @office.work_items.sole
    get "/api/work_items", params: { search: "dana GROVE", kind: "no_reply" }
    assert_response :ok
    assert_equal [ item.id ], response.parsed_body.fetch("items").map { |row| row.fetch("id") }
    assert_equal 1, response.parsed_body.fetch("totals").fetch("needs_attention")
    get "/api/work_items", params: { search: "Avery" }
    assert_empty response.parsed_body.fetch("items")
    patch "/api/work_items/#{@other.work_items.sole.id}", params: { assigned: true }, as: :json
    assert_response :not_found
    get "/api/staff_patients/#{@other_patient.id}"
    assert_response :not_found
    patch "/api/work_items/#{item.id}", params: { assigned: true }, as: :json
    assert_response :ok
    assert_equal "Robin Shaw", item.reload.assignee

    assert_no_difference -> { StaffEvent.count } do
      follow_up(item, outcome: "attempted", note: "")
      assert_response :unprocessable_content
    end
    follow_up(item, outcome: "attempted", note: "Left a voicemail.")
    assert_response :created
    assert_equal "in_progress", item.reload.state

    assert_difference -> { StaffEvent.count }, 1 do
      2.times do
        follow_up(item, outcome: "confirmed", note: "Patient verified the appointment time by phone.")
        assert_response :created
      end
    end
    assert_equal "resolved", item.reload.state
    assert_equal Time.current, item.visit.reload.confirmed_at
  end

  test "a selected older board task stays visible in the bounded patient details" do
    selected = @office.work_items.sole
    foreign = @other.work_items.sole
    30.times do |index|
      selected.visit.work_items.create!(revision: selected.revision, kind: "contact_hold",
        key: "historic-#{index}", reason: "Fictional review")
    end
    path = "/api/staff_patients/#{@patient.id}"
    get path, params: { item_id: selected.id }
    assert_response :ok
    items = response.parsed_body.fetch("work_items")
    assert_equal 30, items.size
    assert_equal selected.id, items.first.fetch("id")
    get path, params: { item_id: foreign.id }
    refute_includes response.parsed_body.fetch("work_items").pluck("id"), foreign.id
  end

  test "a stale staff outcome changes neither the visit nor its staff audit history" do
    item = @office.work_items.sole
    @appointment.update!(start_at: Time.utc(2026, 11, 18, 12))
    assert_no_difference -> { StaffEvent.count } do
      follow_up(item, outcome: "confirmed", note: "Attempted confirmation.")
      assert_response :conflict
    end
    assert_nil item.visit.reload.confirmed_at
    assert_equal "needs_attention", item.reload.state
  end

  test "the appointment form rejects a rescheduled revision even after the PMS refresh succeeds" do
    visit = @office.visits.sole
    get "/api/staff_patients/#{@patient.id}"
    revision = response.parsed_body.fetch("visits").first.fetch("revision")
    @appointment.update!(start_at: @appointment.start_at + 2.days)
    post "/api/refreshes"
    assert_response :created

    path = "/api/staff_patients/#{@patient.id}/follow_ups"
    payload = { visit_id: visit.id, visit_revision: revision, outcome: "confirmed",
      note: "Patient confirmed the original appointment time.", event_key: "stale-appointment" }
    assert_no_difference -> { StaffEvent.count } do
      post path, params: payload, as: :json
      assert_response :conflict
    end
    assert_nil visit.reload.confirmed_at
    assert_equal revision + 1, visit.revision
  end

  test "contact corrections keep raw PMS intact and retain a conflict when raw changes" do
    @patient.update!(wireless_phone: "bad input")
    path = "/api/staff_patients/#{@patient.id}/contact_verification"
    get "/api/staff_patients/#{@patient.id}"
    revision = response.parsed_body.fetch("contact").fetch("revision")
    payload = { event_key: "verified-phone", contact: { wireless_phone: "512-555-0107" }, revision: revision }
    assert_difference -> { StaffEvent.count }, 1 do
      2.times do
        patch path, params: payload, as: :json
        assert_response :ok
      end
    end
    assert_equal "bad input", @patient.reload.wireless_phone
    get "/api/staff_patients/#{@patient.id}"
    assert_response :ok
    contact = response.parsed_body.fetch("contact")
    assert_equal "512-555-0107", contact.fetch("values").fetch("wireless_phone")
    assert_equal "bad input", contact.fetch("source").fetch("wireless_phone")
    @patient.update!(wireless_phone: "512-555-0109")
    get "/api/staff_patients/#{@patient.id}"
    assert_equal [ "wireless_phone" ], response.parsed_body.fetch("contact").fetch("conflicts")
  end

  test "a stale contact form cannot establish a new baseline after PMS contact changes" do
    get "/api/staff_patients/#{@patient.id}"
    revision = response.parsed_body.fetch("contact").fetch("revision")
    @patient.update!(wireless_phone: "512-555-0108")
    assert_no_difference [ "StaffEvent.count", "ContactVerification.count" ] do
      patch "/api/staff_patients/#{@patient.id}/contact_verification", as: :json,
        params: { contact: { wireless_phone: "512-555-0111" }, event_key: "stale-phone", revision: revision }
      assert_response :conflict
    end
  end

  test "contact verification rolls back when saving its audit event fails" do
    path = "/api/staff_patients/#{@patient.id}"
    get path
    revision = response.parsed_body.fetch("contact").fetch("revision")
    assert_no_difference [ "StaffEvent.count", "ContactVerification.count" ] do
      patch path + "/contact_verification", as: :json,
        params: { contact: { wireless_phone: "512-555-0111" }, event_key: "x" * 101, revision: revision }
      assert_response :unprocessable_content
    end
    assert_equal "+1 512 555 0101", @patient.reload.wireless_phone
  end

  test "leadership returns outcome totals without names, identities, message text or other patient data" do
    completed = create_appointment(@office, @patient, start_at: Time.utc(2026, 11, 15, 11), status: "complete")
    scheduled = create_appointment(@office, @patient, start_at: Time.utc(2026, 11, 16, 10))
    RefreshVisits.new(@office).call
    @office.visits.find_by!(source_id: scheduled.id).update!(confirmed_at: Time.current)
    assert_equal "complete", completed.status
    get "/api/outcomes", params: { month: "2026-11" }
    assert_response :forbidden
    post "/api/workspace", params: { role: "leadership" }
    assert_response :ok
    get "/api/outcomes", params: { month: "2026-11" }
    assert_response :ok
    records = response.parsed_body.fetch("clinics")
    assert_equal %w[Austin Phoenix], records.map { |clinic| clinic.fetch("name") }
    assert_equal [ 2, 1, 1, 50 ], records.first.values_at("recorded", "completed", "confirmed", "completion_rate")
    [ @patient.first_name, @patient.last_name, @patient.email, @patient.wireless_phone, @patient.birthdate.to_s,
      Delivery.first.body, "patient_id", "staff_name", "destination", "provider" ].each do |secret|
      refute_includes response.body, secret
    end
    get "/api/staff_patients/#{@patient.id}"
    assert_response :forbidden
  end

  test "an inbox preserves recipient identity when the source visit switches patients" do
    delivery = @office.deliveries.sole
    assert_equal @patient.id, delivery.patient_id
    @appointment.update!(patient_id: @other_patient.id)
    RefreshVisits.new(@office).call
    post "/api/workspace", params: { role: "patient" }
    assert_response :ok
    get "/api/offices/#{@office.id}/patients/#{@patient.id}/inbox"
    assert_response :ok
    assert_equal [ delivery.id ], response.parsed_body.map { |thread| thread.fetch("id") }
    get "/api/offices/#{@office.id}/patients/#{@other_patient.id}/inbox"
    assert_response :ok
    assert_empty response.parsed_body
  end

  test "adjacent source bigint patient identifiers survive browser-facing JSON exactly" do
    base = 9_007_199_254_740_992
    2.times do |index|
      patient = create_patient(id: base + index)
      create_appointment(@office, patient)
    end
    RefreshVisits.new(@office).call
    post "/api/workspace", params: { role: "patient" }
    get "/api/offices/#{@office.id}/patients"
    assert_response :ok
    ids = response.parsed_body.pluck("id")
    assert_includes ids, base.to_s
    assert_includes ids, (base + 1).to_s
  end

  test "inbox returns a bounded set of recent replies in chronological order" do
    delivery = @office.deliveries.sole
    Reply.insert_all!(55.times.map do |index|
      { office_id: @office.id, delivery_id: delivery.id, event_key: "test-#{index}",
        body: "Synthetic reply #{index}", result: "needs_review" }
    end)
    post "/api/workspace", params: { role: "patient" }
    get "/api/offices/#{@office.id}/patients/#{@patient.id}/inbox"
    assert_response :ok
    replies = response.parsed_body.first.fetch("replies")
    assert_equal 50, replies.size
    assert_equal "Synthetic reply 5", replies.first.fetch("body")
    assert_equal "Synthetic reply 54", replies.last.fetch("body")
  end

  private

  def sign_in_staff
    post "/api/workspace", params: { role: "staff", office_id: @office.id, staff_name: "Robin Shaw" }
    assert_response :ok
  end

  def follow_up(item, outcome:, note:)
    post "/api/staff_patients/#{@patient.id}/follow_ups", as: :json,
      params: { visit_id: item.visit_id, visit_revision: item.revision, work_item_id: item.id,
        outcome: outcome, note: note, event_key: outcome }
  end
end
