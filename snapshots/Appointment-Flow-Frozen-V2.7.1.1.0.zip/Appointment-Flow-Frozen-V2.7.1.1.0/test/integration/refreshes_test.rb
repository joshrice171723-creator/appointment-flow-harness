require "test_helper"
require Rails.root.join("quality/rails_workload_probe")

class RefreshesTest < ActionDispatch::IntegrationTest
  setup do
    @austin = create_office
    @phoenix = create_office(name: "Phoenix", zone: "America/Phoenix")
    @patient = create_patient
    @appointment = create_appointment(@austin, @patient)
    travel_to Time.utc(2026, 11, 16, 18)
  end

  test "refresh uses the staff clinic and interprets source wall time" do
    create_appointment(@phoenix, @patient)
    post "/api/refreshes"
    assert_response :forbidden
    sign_in
    post "/api/refreshes", params: { office_id: @phoenix.id }
    assert_response :created
    visit = @austin.visits.sole
    assert_equal @appointment.id, visit.source_id
    assert_equal Time.utc(2026, 11, 23, 17), visit.starts_at
    assert_empty @phoenix.visits
  end

  test "a changed visit invalidates confirmation and a missing row preserves the prior snapshot" do
    sign_in
    post "/api/refreshes"
    assert_response :created
    visit = @austin.visits.sole
    visit.update!(confirmed_at: Time.current)
    @appointment.update!(start_at: Time.utc(2026, 12, 30, 11))
    post "/api/refreshes"
    assert_response :created
    assert_equal 2, visit.reload.revision
    assert_nil visit.confirmed_at
    travel 1.day
    # Put the same row back inside the tracking window before simulating loss.
    @appointment.update!(start_at: Time.utc(2026, 11, 25, 11))
    post "/api/refreshes"
    assert_response :created
    watermark = @austin.reload.refreshed_at
    @appointment.destroy!
    travel 1.hour
    post "/api/refreshes"
    assert_response :service_unavailable
    assert_equal watermark, @austin.reload.refreshed_at
    assert_equal 3, visit.reload.revision
  end

  test "spring gaps and ambiguous fall clock times are held" do
    assert_nil @austin.interpret_wall_time(Time.utc(2026, 3, 8, 2, 30))
    assert_nil @austin.interpret_wall_time(Time.utc(2026, 11, 1, 1, 30))
    assert_equal Time.utc(2026, 3, 8, 8, 30), @austin.interpret_wall_time(Time.utc(2026, 3, 8, 3, 30))
    assert_equal Time.utc(2026, 3, 8, 9, 30), @phoenix.interpret_wall_time(Time.utc(2026, 3, 8, 2, 30))
    assert_raises(ActiveRecord::ReadOnlyRecord) { Pms::Appointment.find(@appointment.id).update!(status: "broken") }
  end

  test "same-day refresh cost stays bounded with unrelated source rows" do
    sign_in
    post "/api/refreshes"
    assert_response :created

    _, baseline = RailsWorkloadProbe.measure { post "/api/refreshes" }
    assert_response :created
    source = { patient_id: @patient.id, status: "scheduled" }
    FictionalPms::Appointment.insert_all!(
      Array.new(500, source.merge(clinic_id: @phoenix.clinic_id, start_at: @appointment.start_at)) +
      Array.new(500, source.merge(clinic_id: @austin.clinic_id, start_at: 1.year.ago))
    )
    _, growth = RailsWorkloadProbe.measure { post "/api/refreshes" }
    assert_response :created
    assert_equal [ @appointment.id ], @austin.visits.pluck(:source_id)
    assert_equal baseline.values_at(:read_rows, :instantiated_records, :database_statements),
      growth.values_at(:read_rows, :instantiated_records, :database_statements)
    puts "Refresh baseline #{baseline.inspect}; unrelated growth #{growth.inspect}" if ENV["WORKLOAD"]
  end

  private

  def sign_in
    post "/api/workspace", params: { role: "staff", office_id: @austin.id, staff_name: "Robin Shaw" }
    assert_response :success
  end
end
