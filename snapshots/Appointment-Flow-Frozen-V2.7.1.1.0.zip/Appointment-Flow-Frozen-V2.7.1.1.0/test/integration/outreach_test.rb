require "test_helper"
require Rails.root.join("quality/rails_workload_probe")

class OutreachTest < ActionDispatch::IntegrationTest
  setup do
    @office = create_office
    @patient = create_patient
    @source = create_appointment(@office, @patient)
    travel_to Time.utc(2026, 11, 16, 18)
  end

  test "one SMS accepts one YES and the final message is informational" do
    sign_in_staff
    assert_difference -> { Delivery.count }, 1 do
      post "/api/reminder_runs"
      assert_response :created
    end
    post "/api/reminder_runs"
    assert_equal 0, response.parsed_body["sent"]
    delivery = Delivery.sole
    assert_equal "sms", delivery.channel
    assert_match(/Nov 23, 2026 at 11:00 AM/, delivery.body)
    sign_in_patient
    reply(delivery)
    assert_response :created
    assert_equal "confirmed", response.parsed_body["result"]
    assert_equal Time.current, delivery.visit.reload.confirmed_at
    assert_no_difference -> { Reply.count } do
      reply(delivery)
      assert_response :created
    end
    reply(delivery, body: "NO", key: "different")
    assert_equal "needs_review", response.parsed_body["result"]
    assert_not_nil delivery.visit.reload.confirmed_at
    delivery.visit.work_items.open.update_all(state: "resolved")
    travel 6.days
    sign_in_staff
    post "/api/reminder_runs"
    final = delivery.visit.deliveries.find_by!(stage: "final")
    assert_not final.asks_confirmation
    assert_not_includes final.body, "Reply YES"
  end

  test "failed SMS is retained and an authorized email reply confirms" do
    @patient.update!(wireless_phone: "(512) 555-0199", preferred_language: "es")
    sign_in_staff
    post "/api/reminder_runs"
    assert_response :created
    assert_equal 1, response.parsed_body["sent"]
    assert_equal 1, response.parsed_body["failed"]
    assert_equal "delivery_failed", WorkItem.sole.kind
    refute Delivery.find_by!(channel: "sms").successful
    email = Delivery.find_by!(channel: "email")
    assert_includes email.body, "Responda YES"
    sign_in_patient
    reply(email, body: "yes")
    assert_equal "confirmed", response.parsed_body["result"]
  end

  test "changed PMS time blocks an old YES before and after refresh" do
    deliver
    @source.update!(start_at: Time.utc(2026, 11, 24, 11))
    sign_in_patient
    reply(Delivery.sole)
    assert_equal "needs_review", response.parsed_body["result"]
    assert_nil Visit.sole.confirmed_at
    travel 1.day
    sign_in_staff
    post "/api/reminder_runs"
    assert_equal 2, Visit.sole.revision
    assert_equal [ 1, 2 ], Delivery.order(:id).pluck(:revision)
    sign_in_patient
    reply(Delivery.find_by!(revision: 1), key: "stale")
    assert_equal "needs_review", response.parsed_body["result"]
    assert_nil Visit.sole.confirmed_at
  end

  test "a broken source appointment and its replacement have separate lifecycles" do
    deliver
    original = Delivery.sole
    @source.update!(status: "broken")
    replacement = create_appointment(@office, @patient)
    post "/api/reminder_runs"
    assert_response :created
    assert_equal "broken", original.visit.reload.status
    assert_equal 1, original.visit.deliveries.count
    assert_equal replacement.id, Delivery.order(:id).last.visit.source_id
    sign_in_patient
    reply(original)
    assert_equal "needs_review", response.parsed_body["result"]
    assert_empty Visit.where.not(confirmed_at: nil)
  end

  test "an unrelated patient or clinic cannot replay a delivery" do
    deliver
    other = create_office(name: "Phoenix", zone: "America/Phoenix")
    patient = create_patient
    sign_in_patient
    assert_no_difference -> { Reply.count } do
      reply(Delivery.sole, office: other)
      assert_response :not_found
      reply(Delivery.sole, patient: patient)
      assert_response :not_found
    end
  end

  test "a shared contact cannot receive an SMS or use an earlier SMS to confirm" do
    deliver
    sibling = create_patient(wireless_phone: "512.555.0101", email: nil)
    create_appointment(@office, sibling)
    old_sms = Delivery.sole
    sign_in_staff
    post "/api/reminder_runs"
    assert_equal 1, Delivery.count
    assert WorkItem.where(kind: "contact_hold").exists?
    sign_in_patient
    reply(old_sms)
    assert_equal "needs_review", response.parsed_body["result"]
    assert_equal @office.visits.ids.sort, WorkItem.find_by!(kind: "reply_review").candidate_visit_ids.sort
    assert_empty Visit.where.not(confirmed_at: nil)

    item = WorkItem.find_by!(kind: "reply_review")
    sibling_visit = @office.visits.find_by!(patient_id: sibling.id)
    sign_in_staff
    payload = { visit_id: item.visit_id, visit_revision: item.revision, work_item_id: item.id, outcome: "confirmed",
      note: "Verified the sibling’s new visit in a separate call.", event_key: "staff-clarification" }
    path = "/api/staff_patients/#{@patient.id}/follow_ups"
    post path, params: payload, as: :json
    assert_response :unprocessable_content
    assert_empty Visit.where.not(confirmed_at: nil)
    candidate = { id: sibling_visit.id, revision: sibling_visit.revision }
    sibling_source = FictionalPms::Appointment.find(sibling_visit.source_id)
    sibling_source.update!(start_at: sibling_source.start_at + 1.day)
    RefreshVisits.new(@office).call
    assert_no_difference -> { StaffEvent.count } do
      post path, params: payload.merge(candidates: [ candidate ]), as: :json
      assert_response :conflict
    end
    assert_nil sibling_visit.reload.confirmed_at
    post path, params: payload.merge(candidates: [ { id: sibling_visit.id, revision: sibling_visit.revision } ]), as: :json
    assert_response :created
    assert_not_nil sibling_visit.reload.confirmed_at
    assert_nil old_sms.visit.reload.confirmed_at
    assert_equal "resolved", item.reload.state
  end

  test "STOP persists across refresh, a malformed command goes to review, and late YES never confirms" do
    deliver
    sms = Delivery.sole
    sign_in_patient
    reply(sms, body: "stop", key: "opt-out")
    assert_equal "opted_out", response.parsed_body["result"]
    travel 4.days
    sign_in_staff
    post "/api/reminder_runs"
    assert_equal [ "email", "sms" ], Delivery.order(:channel).pluck(:channel)
    assert_equal sms.destination, SmsOptOut.sole.destination
    sign_in_patient
    email = Delivery.find_by!(channel: "email")
    reply(email, body: "STOP please", key: "malformed")
    assert_equal "needs_review", response.parsed_body["result"]
    travel 4.days
    reply(email, key: "late")
    assert_equal "needs_review", response.parsed_body["result"]
    assert_nil Visit.sole.confirmed_at
  end

  test "a destination claimed in two clinics' verified corrections cannot receive either reminder" do
    @patient.update!(email: nil)
    other = create_office(name: "Phoenix", zone: "America/Phoenix")
    other_patient = create_patient(wireless_phone: "480-555-0113", email: nil)
    create_appointment(other, other_patient)
    [ [ @office, @patient ], [ other, other_patient ] ].each do |office, patient|
      RefreshVisits.new(office).call
      sign_in_staff(office: office)
      path = "/api/staff_patients/#{patient.id}"
      get path
      revision = response.parsed_body.fetch("contact").fetch("revision")
      patch path + "/contact_verification", as: :json,
        params: { contact: { wireless_phone: "737-555-0120" }, event_key: "verify-shared", revision: revision }
      assert_response :ok
    end
    [ @office, other ].each do |office|
      sign_in_staff(office: office)
      post "/api/reminder_runs"
      assert_response :created
      assert_equal "contact_hold", office.work_items.sole.kind
    end
    assert_empty Delivery.all
  end

  test "unsafe age, unknown language, and outside-window visits produce no outreach" do
    @patient.update!(birthdate: Date.new(2016, 1, 1))
    deliver
    assert_empty Delivery.all
    assert_match(/responsible party/, WorkItem.sole.reason)
    @patient.update!(birthdate: Date.new(1995, 1, 1), preferred_language: "unknown")
    post "/api/reminder_runs"
    assert_match(/language/, WorkItem.sole.reason)
    get "/api/staff_patients/#{@patient.id}"
    revision = response.parsed_body.fetch("contact").fetch("revision")
    patch "/api/staff_patients/#{@patient.id}/contact_verification", as: :json,
      params: { contact: { preferred_language: "en" }, event_key: "verify-language", revision: revision }
    assert_response :ok
    assert_equal "unknown", @patient.reload.preferred_language
    travel_to Time.utc(2026, 11, 16, 15)
    post "/api/reminder_runs"
    assert_empty Delivery.all
    travel_to Time.utc(2026, 11, 16, 16)
    post "/api/reminder_runs"
    assert_equal 1, Delivery.count
    assert_equal "resolved", WorkItem.sole.state
  end

  test "source failure prevents sends and a failure during a batch rolls back prior fake acceptance" do
    other = create_patient(wireless_phone: "512-555-0105", email: "other@example.invalid")
    create_appointment(@office, other)
    messenger = Class.new(FakeMessenger) do
      def self.accepts?(destination)
        raise IOError, "Simulated adapter error" if destination.end_with?("0105")

        true
      end
    end

    assert_raises(IOError) do
      ReminderRun.new(@office, messenger: messenger).call
    end
    assert_empty Delivery.all
    assert_empty WorkItem.all
    assert_equal 2, @office.visits.count

    @source.destroy!
    sign_in_staff
    post "/api/reminder_runs"
    assert_response :service_unavailable
    assert_empty Delivery.all
  end

  test "a source change after the refresh watermark aborts the planned sends" do
    sign_in_staff
    changed = false
    new_time = Time.utc(2026, 11, 16, 10)
    move_source = lambda do |event|
      if !changed && event.payload[:name] == "Office Update"
        changed = true
        @source.update!(start_at: new_time)
      end
    end
    ActiveSupport::Notifications.subscribed(move_source, "sql.active_record") do
      post "/api/reminder_runs"
    end
    assert changed
    assert_response :conflict
    assert_empty Delivery.all
    assert_equal new_time, @source.reload.start_at
    post "/api/reminder_runs"
    assert_response :created
    assert_empty Delivery.all
  end

  test "per-message clock prevents a running batch from sending at visit start" do
    start = Time.utc(2026, 11, 16, 18, 1)
    wall_time = Time.utc(2026, 11, 16, 12, 1)
    @source.update!(start_at: wall_time)
    other = create_patient(wireless_phone: "512-555-0110", email: "next@example.invalid")
    create_appointment(@office, other, start_at: wall_time)
    clock = self
    messenger = Class.new(FakeMessenger) do
      define_singleton_method(:deliver) do |**arguments|
        receipt = super(**arguments)
        clock.travel_to(start)
        receipt
      end
    end

    result = ReminderRun.new(@office, messenger: messenger).call
    assert_equal 1, result.fetch(:sent)
    assert_equal @patient.id, Delivery.sole.patient_id
    assert_operator Delivery.sole.created_at, :<, start
  end

  test "reminder retry and eligible growth record the expected persisted delivery count" do
    sign_in_staff
    post "/api/refreshes"
    _, initial = RailsWorkloadProbe.measure { post "/api/reminder_runs" }
    assert_response :created
    assert_equal 1, response.parsed_body["sent"]
    target = ENV.fetch("WORKLOAD_SCALE", "10").to_i.clamp(2, 400)
    (target - 1).times do |index|
      phone = format("%d-555-%04d", 201 + index / 90, 101 + index % 90)
      patient = create_patient(wireless_phone: phone, email: "extra#{index}@example.invalid")
      create_appointment(@office, patient)
    end
    _, eligible = RailsWorkloadProbe.measure { post "/api/reminder_runs" }
    assert_response :created
    assert_equal target - 1, response.parsed_body["sent"]
    _, retry_cost = RailsWorkloadProbe.measure { post "/api/reminder_runs" }
    assert_response :created
    assert_equal 0, response.parsed_body["sent"]
    assert_equal target, Delivery.count
    assert_operator retry_cost[:direct_write_statements], :<, eligible[:direct_write_statements]
    puts "Reminder initial #{initial.inspect}; eligible growth #{eligible.inspect}; retry #{retry_cost.inspect}" if ENV["WORKLOAD"]
  end

  private

  def deliver
    sign_in_staff
    post "/api/reminder_runs"
    assert_response :created
  end

  def sign_in_staff(office: @office)
    post "/api/workspace", params: { role: "staff", office_id: office.id, staff_name: "Robin Shaw" }
    assert_response :success
  end

  def sign_in_patient
    post "/api/workspace", params: { role: "patient" }
    assert_response :success
  end

  def reply(delivery, body: "YES", key: "reply-event", office: @office, patient: @patient)
    post "/api/offices/#{office.id}/patients/#{patient.id}/replies",
      params: { delivery_id: delivery.id, body: body, event_key: key }
  end
end
