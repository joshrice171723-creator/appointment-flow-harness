require "test_helper"

class ParallelReminderTest < ActiveSupport::TestCase
  self.use_transactional_tests = false

  test "parallel database connections sharing a clinic cannot persist duplicate fake sends" do
    office = create_office(name: "Parallel test clinic")
    patient = create_patient(wireless_phone: "737-555-0111", email: "parallel@example.invalid")
    source = create_appointment(office, patient)
    now = Time.utc(2026, 11, 16, 18)
    ready = Queue.new
    start = Queue.new
    workers = 2.times.map do
      Thread.new do
        Rails.application.executor.wrap do
          ready << true
          start.pop
          separate_office = Office.find(office.id)
          ReminderRun.new(separate_office, now: now).call.fetch(:sent)
        end
      end
    end
    2.times { ready.pop }
    2.times { start << true }
    assert_equal [ 0, 1 ], workers.map(&:value).sort
    assert_equal 1, office.deliveries.accepted.count
  ensure
    if office
      Delivery.where(visit_id: office.visits.select(:id)).delete_all
      WorkItem.where(visit_id: office.visits.select(:id)).delete_all
      Visit.where(office_id: office.id).delete_all
      office.destroy!
      source&.destroy!
      patient&.destroy!
      FictionalPms::Clinic.find_by(id: office.clinic_id)&.destroy!
    end
  end
end
