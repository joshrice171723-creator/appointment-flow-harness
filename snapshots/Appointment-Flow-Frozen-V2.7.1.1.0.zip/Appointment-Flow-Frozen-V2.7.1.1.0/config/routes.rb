Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check
  root "workspaces#show"

  scope :api, defaults: { format: :json } do
    resource :workspace, only: %i[show create destroy]
    resources :refreshes, only: :create
    resources :reminder_runs, only: :create
    resources :appointments, only: :index
    resources :work_items, only: %i[index update]
    resources :staff_patients, only: :show do
      resource :contact_verification, only: :update
      resources :follow_ups, only: :create
    end
    resource :outcomes, only: :show
    resources :offices, only: [] do
      resources :patients, only: :index do
        resource :inbox, only: :show
        resources :replies, only: :create
      end
    end
  end

  # Render dynamic PWA files from app/views/pwa/* (remember to link manifest in application.html.erb)
  # get "manifest" => "rails/pwa#manifest", as: :pwa_manifest
  # get "service-worker" => "rails/pwa#service_worker", as: :pwa_service_worker

  # Defines the root path route ("/")
  # root "posts#index"
end
