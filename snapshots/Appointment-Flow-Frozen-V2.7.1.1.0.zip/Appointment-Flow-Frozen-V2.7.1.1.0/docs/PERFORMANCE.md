# Database work and performance

Measure the useful result, time for the complete operation, and work done as the data grows. Start at the existing entry point and follow shared services, association reads, writes and retries. Keep clinic, revision, authorization and transaction boundaries intact.

Always use standard Active Record methods for application queries. Avoid handwritten SQL strings and expressions, including fragments passed into Active Record. Keep Arel out of application queries.

## Choose the query by its result

Before implementing a material database decision, identify the eligible rows and the smallest result the caller needs. Note it in the existing slice plan. Read the actual Rails version's [Active Record Query Interface](https://guides.rubyonrails.org/active_record_querying.html) for the patterns you use.

| Caller needs | Start with |
|---|---|
| Whether a matching record exists | Scoped `exists?` on an unloaded relation. Reuse a suitable collection when it is already loaded and the answer needs the same snapshot. |
| A few scalar values | `pluck` or `pick`. Use `select` when a caller still needs specific model attributes or behavior. |
| Totals by category | `group(...).count`. Keep the intended grouping and date boundary. |
| A list and related rows | Filter and bound the parent list first, then load the required associations together. Check the rendered or serialized result for lazy per-row queries. |
| Related rows or keys already read | Reuse them within the consistency boundary. If an existing write can return the needed keys, check the adapter's return options instead of automatically reading them again. |
| A set of similar writes | Check whether a bulk API preserves validation, callbacks, timestamps, uniqueness, and rollback. Verify the affected rows and return only values the caller uses. |

Keep a clear leading scope. Make null, range endpoints, ordering, and revision or tenant predicates explicit. Check the SQL Active Record sends to PostgreSQL when changing a relation, join, or index. Make an expensive shared read or source refresh visible at the owning workflow, with the time-critical section and expected failure easy to find.

For list endpoints, give the full scope, any rule-specific subset, and the displayed rows names that distinguish them. Keep filtering, ordering, counts, and limits in the relation. Preload associations required by the displayed rows. If a tab filters only displayed rows, verify that it preserves full-scope totals. Use focused endpoint checks for applicable clinic scope, date boundaries, ordering, limits, flags, response fields, and query growth.

## Verify growth during implementation

Choose a consequential read and write or batch from the normal callers. A shared operation is in scope even when it lives several calls below the entry point. Add a focused check to the current slice when the first material path works. Reuse this evidence in review if the final source and workload still match.

1. Establish the expected response and persisted effects in a small synthetic fixture. Run the complete operation with setup and assertions outside the measured block.
2. Keep the useful work fixed. Add data the current query could scan or load even though the result should be unchanged. Choose this extra data from the actual query scope. Include rows inside broad ranges, if relevant, and measure the important query as well as the caller.
3. Grow the eligible work for a batch. Compare reads, written rows, and object loading. For a workflow that can retry, repeat with existing results and check both the persisted effects and what work repeats. Include the scope of any lock or transaction.
4. Record statement counts, returned rows when available, model instantiations, relevant writes, elapsed time, and the query or application source location behind meaningful growth. For a JSON aggregate or wide result, inspect record cardinality or payload size as appropriate. Use a plan to assess a scan or an index. Record which metrics are available and conditions that affect timing.

Use the existing test instrumentation or `quality/rails_workload_probe.rb` for synchronous Rails operations. It measures Active Record events on the calling thread. Check external connections or work on other threads separately when they are material. Framework schema work and cache hits have separate counters. A large payload, misleading aggregate row count, or unnecessary work under a lock matters even when the query count stays flat.

During grading, use equivalent results and trace evidence to distinguish necessary work from avoidable work. For any verified material finding, change the smallest responsible code, rerun the same scenario, and check correctness and performance together. Explain unavoidable growth and distinguish measured facts from a source prediction.
