# Rails + React coding standards — v1

These are project **decisions for the harness**, informed by official framework documentation and thoughtbot guides (see `docs/SOURCES.md`). They are not claims that every listed rule is an official framework mandate.

## Global standards

- **Readable at a glance:** explicit names, small coherent units, flat branching when it improves comprehension, ordinary control flow, comments explaining *why* rather than narrating *what*.
- **No speculative abstraction:** solve this version first. Extract only to remove meaningful duplication, separate a distinct responsibility, or permit focused testing.
- **Keep changes narrow:** no opportunistic directory reshuffles, pointless wrappers, or adding dependencies for a few lines of code.
- **No "defensive" code that hides bugs:** don't swallow errors, invent fallback values, cast away types, or skip failing tests.
- **Human-maintainable tests:** name scenarios and observable behavior; avoid mocks for every internal method and fragile implementation-specific assertions.
- **No magic constants:** put domain-significant reminder intervals/status values in one clear location; avoid unnecessary configuration layers.
- **Be explicit with dates:** `start_at` is **clinic-local wall-clock time**; do not silently treat it as UTC. Establish a timezone decision and test DST boundaries.

## Ruby and Rails

- **Query for what the caller needs.** Always use standard Active Record methods for application queries. Avoid handwritten SQL strings and expressions, including fragments passed into Active Record. Keep Arel out of application queries. Filter, check existence, and aggregate in the database before loading rows. Use named scopes for shared conditions. Inspect how often the caller runs, how many rows are read or materialized, what repeats in loops, and how long transactions or locks are held.
- **Make the workflow visible.** Write the entry point in execution order. Give each business rule one obvious owner and keep the decision close to the writes it controls. Extract a helper when its name reduces reading effort or gives a meaningful rule a home. Use plain verbs for custom methods. Reserve `!` for established API conventions or a meaningful distinction for the caller.
- **Make failures understandable.** Make the transaction owner and the writes it covers visible. Catch expected failures where their cause can be identified, preserve the cause, and handle recovery at the operation boundary. Use a savepoint when the caller has a defined way to recover from an inner failure and continue. Persist any required failure state outside the rollback it must survive.
- Follow the Rails responsibility boundaries in `docs/ARCHITECTURE_GUARDRAILS.md`. Keep HTTP concerns in controllers and put business decisions and their writes at an obvious owner.
- Prefer straightforward Ruby methods with descriptive parameters and early returns where they clarify branches.
- Use database constraints/indexes where needed for integrity and idempotency; application validation is not sufficient for concurrent uniqueness.
- Do not assume replicated source tables can be mutated safely. Decide and document ownership boundaries for locally managed reminder/confirmation data.
- Use Active Job if async work materially improves the implementation; don't introduce Sidekiq, Redis, schedulers, or distributed systems by default.
- Handle provider failure and retry without duplicate sends; represent delivery attempts and confirmation state distinctly if required by behavior.
- Use UTC for internally controlled instants when applicable and a well-defined clinic timezone for displaying/interpreting appointment wall time. Document conversions; don't guess timezone from a state's abbreviation when the clinic timezone is ambiguous.
- Prefer Rails default Minitest initially; use RSpec only if intentionally chosen with a reason. Test database behavior, domain transitions, and endpoints.
- Follow consistent formatting and RuboCop/RuboCop Rails checks (configured to installed versions); don't disable cops wholesale.

### Multi-step Rails services

- **Make the entry point tell the story.** A reader should see the order of the operation's main steps, the transaction or lock it owns, and the result that goes back to the caller. For example, an import might read the input, validate it, reconcile records, and return the result. The public entry point exposes that sequence in execution order.
- **Order reads, validation, and writes deliberately.** Check cheap input and prerequisite failures before doing costly work when consistency allows. Load only the records the operation needs and reuse them across its steps. Check rules that depend on current database state before writing, within the transaction or lock that protects that state.
- **Make rejection as clear as success.** Identify expected failures at the boundary that can explain them, such as an external read or invalid input. Preserve the original cause of an unexpected failure. Make clear which writes can happen on each path, what rolls back, and where the caller handles the result.
- **Keep implementation steps private.** Name substantial helpers for the domain decision or action they own. Keep the rule close to the writes or outcome it controls. Mark internal instance or class helpers private. Each public method should have a clear reason for callers to use it.
- **Keep small operations direct.** Extract a step when its name makes the flow easier to follow or gives a rule a clear home. Keep straightforward guards and short operations readable in place.

## Performance

Use `docs/PERFORMANCE.md` for efficient query design and the post-build workload check.

## React and TypeScript

- Prefer **functional components**, explicit props, and clear types. TypeScript is a proposed default, not a requirement from the employer brief.
- Keep state as local as possible; avoid mirroring props, storing derivable values, contradictory status booleans, or unnecessary global contexts.
- Avoid effects for calculations or event-driven work. Use `useEffect` only to synchronize with an external system or similar lifecycle need; handle cleanup/cancellation for async effects.
- Write clear loading, error, empty, and success states for staff actions. Avoid data flashes that display another clinic's appointments.
- Keep API request/response types close to usage; create a shared layer only if duplication appears. Avoid introducing Redux, complex data-fetching libraries, form frameworks, or generic component systems before a demonstrated need.
- Prefer semantic HTML, explicit labels, understandable status text, and testable user-facing behavior.
- Avoid `any`, non-null assertions, and disabled lint rules unless documented with a specific reason. `unknown` plus validation is preferable for untrusted input.
- Use the starter's ESLint and TypeScript setup; add React Hooks rules. Follow React's official guidance on state and effects.

## Security and sensitive data

- Seed **synthetic** patients only. Keep procedure notes/medical details out of SMS/email bodies, logs, screenshots, and unnecessary UI views.
- Never log message bodies or patient contact details in routine error output. Store only the minimum data needed for the demo.
- Validate clinic boundaries **server-side**; a frontend clinic selector is not authorization.
- Stub staff auth because the brief says so, but explicitly document how identity, authorization, consent/opt-out, audit, and data protection would work in production.
- No live sends. The default test adapter must be deterministic and inspectable locally.

## The readability test

Before finishing, ask: "Can a Rails/React engineer explain the execution path and major state changes in five minutes without reading an AI-authored architectural essay?" If not, simplify and verify again.
