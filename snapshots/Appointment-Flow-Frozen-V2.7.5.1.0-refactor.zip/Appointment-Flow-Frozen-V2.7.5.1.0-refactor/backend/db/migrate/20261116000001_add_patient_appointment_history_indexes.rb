class AddPatientAppointmentHistoryIndexes < ActiveRecord::Migration[8.1]
  def change
    add_index "pms.appointments", [:clinic_id, :patient_id, :start_at, :id],
      name: :appointment_patient_history
    add_index "desk.visits", :appointment_id, name: :visit_appointment
  end
end
