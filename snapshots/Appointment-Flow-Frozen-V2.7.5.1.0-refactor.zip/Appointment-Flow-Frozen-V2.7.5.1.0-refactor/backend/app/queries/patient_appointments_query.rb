class PatientAppointmentsQuery
  def initialize(patient, clinic, now: Time.current)
    @patient = patient
    @clinic = clinic
    @now = now
    @appointments = Appointment.for_clinic(clinic.id).where(patient_id: patient.id)
    @visits = Visit.for_clinic(clinic.id).for_patient(patient.id)
    @policy = ContactPolicy.new(now)
  end

  def next_appointment
    @appointments.scheduled.where.not(start_at: ..clinic_wall_time).chronological.first
  end

  def page(filter:, before:, limit:, appointment_id: nil)
    source = appointment_id ? @appointments.where(id: appointment_id) : @appointments
    tracked = appointment_id ? @visits.where(appointment_id: appointment_id) : @visits

    # Both projections must see the same mirror when a source refresh commits.
    ApplicationRecord.transaction(isolation: :repeatable_read) do
      source_keys = page_dates(source, :id, filter, before)
        .order(start_at: :desc, id: :desc).limit(limit).pluck(:id, :start_at)
      # A full source page sets the oldest key that could reach the merged page.
      source_floor = source_keys.last if source_keys.size == limit
      tracked_keys = tracked_page(tracked, filter, before, source_floor, limit)

      (source_keys + tracked_keys).sort_by { |id, time| [time, id] }.last(limit).reverse
    end
  end

  def rows(ids)
    appointments = @appointments.where(id: ids).includes(:patient).index_by(&:id)
    visits = @visits.where(appointment_id: ids).with_context.includes(:events).order(id: :desc).to_a
    revisions = visits.group_by(&:appointment_id)
    issues = FollowUpIssue.group_by_visit(FollowUpIssue.open.for_visits(visits.map(&:id)).order(:id))
    pending = @visits.where(id: visits.map(&:id)).with_pending_pms_change.pluck(:id).to_set

    ids.filter_map do |id|
      versions = revisions.fetch(id, [])
      appointment = appointments[id]
      visit = if appointment
        versions.find { |version| version.matches_appointment?(appointment) && version.current } ||
          (versions.find { |version| version.matches_appointment?(appointment) } unless appointment.status == "scheduled")
      else
        versions.first
      end
      next unless appointment || visit

      # A replacement booking belongs to its own patient and clinic. Keep the old visit facts separate.
      row = AppointmentSerializer.new(appointment: appointment, visit: visit,
        hold: visit && outreach_for(visit, pending: pending.include?(visit.id)).fetch(:hold),
        issues: visit ? issues.fetch(visit.id, []) : [], patient_reply: visit&.latest_patient_reply).as_json
      [id, row.merge("revisions" => versions.map do |version|
        version.attributes.slice("id", "start_at", "current", "confirmed_at", "confirmed_by")
      end)]
    end.to_h
  end

  def next_outreach(appointment, permission)
    return { hold: nil, allowed_channels: [] } unless appointment

    visit = @visits.current.find_by(appointment_id: appointment.id)
    if visit&.matches_appointment?(appointment)
      return outreach_for(visit, pending: visit.pending_pms_change?)
    end

    visit = Visit.new(patient: @patient, appointment: appointment, clinic_id: @clinic.id,
      clinic_setting: @clinic.setting, start_at: appointment.start_at)
    visit.contact_permission = permission if permission
    outreach_for(visit)
  end

  private

  def tracked_page(visits, filter, before, source_floor, limit)
    missing_or_reassigned = Appointment.where(id: nil)
      .or(Appointment.where.not(clinic_id: @clinic.id, patient_id: @patient.id))
    candidates = page_dates(visits, :appointment_id, filter, before)
      .left_joins(:appointment).merge(missing_or_reassigned)

    if before || filter == "past"
      # An older revision cannot qualify when this appointment's latest date is past the page end.
      end_of_page = page_end(Visit.all, :appointment_id, filter, before)
      later_visits = visits.and(end_of_page.invert_where)
      candidates = candidates.where.not(appointment_id: later_visits.select(:appointment_id))
    end

    if source_floor
      id, time = source_floor
      candidates = candidates.where(start_at: time..).where.not(start_at: time, appointment_id: ..id)
    end

    ordered_keys = candidates.order(start_at: :desc, appointment_id: :desc)
      .limit(limit).pluck(:appointment_id, :start_at)
    unique_keys = ordered_keys.uniq(&:first)
    return unique_keys if ordered_keys.size < limit || unique_keys.size == limit

    # Repeated revisions used up the limit. Rank one maximum date per appointment in the database.
    candidates.group(:appointment_id).order(maximum_start_at: :desc, appointment_id: :desc)
      .limit(limit).maximum(:start_at).to_a
  end

  def page_dates(scope, id_column, filter, before)
    scope = scope.where.not(start_at: ..clinic_wall_time) if filter == "upcoming"
    page_end(scope, id_column, filter, before)
  end

  def page_end(scope, id_column, filter, before)
    scope = scope.where(start_at: ..clinic_wall_time) if filter == "past"
    return scope unless before

    time, id = before
    scope.where(start_at: ..time).where.not(start_at: time, id_column => id..)
  end

  def outreach_for(visit, pending: false)
    return { hold: "Awaiting PMS update. Reminders paused for this time.", allowed_channels: [] } if pending
    return { hold: nil, allowed_channels: [] } unless visit.starts_at_utc.nil? || visit.starts_at_utc > @now

    @opt_outs ||= OptOut.where(clinic_id: @clinic.id).pluck(:destination).to_set
    decision = @policy.decision(visit, opt_outs: @opt_outs)
    { hold: decision.reason, allowed_channels: decision.destinations.keys }
  end

  def clinic_wall_time
    @now.in_time_zone(@clinic.setting.timezone).strftime("%F %T.%6N")
  end
end
