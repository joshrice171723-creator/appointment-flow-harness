require_relative "test_helper"

class PatientWorkspaceTest < Minitest::Test
  include Rack::Test::Methods

  def app = Rails.application

  def setup
    restore_demo_fixture
    get "/"
    header "X-CSRF-Token", last_response.body[/name="csrf-token" content="([^"]+)"/, 1]
    header "Content-Type", "application/json"
    post "/api/enter", JSON.generate(workspace: "desk", clinic: 1, staff: 11)
    assert last_response.ok?
  end

  def test_both_entries_load_the_same_patient_workspace
    entry = FollowUpCase.for_clinic(1).where(patient_id: ContactProfilesQuery.scope(1).select(:id)).first!
    get "/api/board", clinic: 1
    assert last_response.ok?, last_response.body
    card = JSON.parse(last_response.body).fetch("cases").find { |row| row.fetch("id") == entry.id }
    assert_equal entry.patient_id, card.fetch("patient_id")

    get "/api/work/#{entry.id}"
    assert last_response.ok?, last_response.body
    from_case = JSON.parse(last_response.body)

    get "/api/patient-details/#{entry.patient_id}"
    assert last_response.ok?, last_response.body
    from_patient = JSON.parse(last_response.body)

    assert_equal entry.patient_id, from_patient.dig("person", "id")
    assert_equal entry.id, from_patient.dig("case", "id")
    assert_equal from_case.fetch("details"), from_patient.fetch("details")
    assert_equal from_case.fetch("issues"), from_patient.fetch("issues")
    assert_equal from_case.slice("next_appointment"), from_patient.slice("next_appointment")
  end

  def test_history_pages_include_old_source_appointments_and_keep_cursor_in_scope
    appointment = Appointment.for_clinic(1).find(103)
    inserted_ids = (7_000_000...7_000_027).to_a
    tracked_ids = inserted_ids.first(2)
    tie = TEST_NOW - 40.days + Rational(123456, 1_000_000)
    Appointment.insert_all!((inserted_ids - tracked_ids).map do |id|
      appointment.attributes.merge("id" => id, "start_at" => tie, "status" => "complete")
    end)
    visit = { patient_id: appointment.patient_id, clinic_id: 1, revision: "tracked", current: false }
    repeated_revisions = Array.new(26) { visit.merge(appointment_id: tracked_ids.last, start_at: tie) }
    Visit.insert_all!(repeated_revisions + [
      visit.merge(appointment_id: tracked_ids.first, start_at: tie),
      visit.merge(appointment_id: tracked_ids.last, start_at: tie - 1.day)
    ])

    path = "/api/patient-details/#{appointment.patient_id}/history"
    get path, section: "appointments", filter: "past"
    assert last_response.ok?, last_response.body
    page = JSON.parse(last_response.body)
    assert_equal 25, page.fetch("rows").size
    first_cursor = page.fetch("next_cursor")
    assert first_cursor
    ids = page.fetch("rows").pluck("appointment_id")
    while page["next_cursor"]
      get path, section: "appointments", filter: "past", cursor: page.fetch("next_cursor")
      assert last_response.ok?, last_response.body
      page = JSON.parse(last_response.body)
      ids.concat(page.fetch("rows").pluck("appointment_id"))
    end
    assert_equal ids.uniq, ids
    assert_equal inserted_ids.reverse, ids & inserted_ids

    get path, section: "activity", cursor: first_cursor
    assert_equal 409, last_response.status

    outside = Appointment.for_clinic(5).where.not(patient_id: ContactProfilesQuery.scope(1).select(:id)).first!
    get "/api/patient-details/#{outside.patient_id}/history", section: "appointments"
    assert_equal 409, last_response.status
  end

  def test_appointment_history_uses_scoped_source_dates_and_preserves_missing_visit_facts
    patient_id = 7_100_000
    Patient.insert_all!([{ id: patient_id, first_name: "Demo", last_name: "Patient" }])
    wall_time = Time.utc(2026, 11, 5, 10)
    just_after_wall_time = wall_time + Rational(1, 1_000_000)
    source = { patient_id: patient_id, clinic_id: 1, status: "scheduled", provider_name: "Demo Provider" }
    Appointment.insert_all!([
      source.merge(id: 7_100_001, start_at: wall_time),
      source.merge(id: 7_100_002, start_at: just_after_wall_time),
      source.merge(id: 7_100_003, start_at: just_after_wall_time),
      source.merge(id: 7_100_004, start_at: wall_time - 2.days, status: "complete"),
      source.merge(id: 7_100_006, start_at: wall_time + 6.days, clinic_id: 5),
      source.merge(id: 7_100_007, start_at: wall_time + 7.days, patient_id: 103),
      source.merge(id: 7_100_008, start_at: wall_time + 8.days, clinic_id: 5)
    ])
    visit = { patient_id: patient_id, clinic_id: 1, revision: "tracked", current: false,
      confirmed_at: TEST_NOW, confirmed_by: "Patient" }
    Visit.insert_all!([
      visit.merge(id: 7_200_001, appointment_id: 7_100_004, start_at: wall_time + 3.days),
      visit.merge(id: 7_200_002, appointment_id: 7_100_005, start_at: wall_time + 5.days),
      visit.merge(id: 7_200_003, appointment_id: 7_100_005, start_at: wall_time - 1.day),
      visit.merge(id: 7_200_004, appointment_id: 7_100_006, start_at: wall_time - 1.day),
      visit.merge(id: 7_200_005, appointment_id: 7_100_007, start_at: wall_time - 1.day),
      visit.merge(id: 7_200_006, appointment_id: 7_100_006, start_at: wall_time + 6.days, clinic_id: 5),
      visit.merge(id: 7_200_007, appointment_id: 7_100_007, start_at: wall_time + 7.days, patient_id: 103)
    ])

    path = "/api/patient-details/#{patient_id}"
    get path
    assert last_response.ok?, last_response.body
    assert_equal 7_100_002, JSON.parse(last_response.body).dig("next_appointment", "appointment_id")

    get "#{path}/history", section: "appointments", filter: "upcoming"
    assert last_response.ok?, last_response.body
    upcoming = JSON.parse(last_response.body).fetch("rows")
    assert_equal [7_100_005, 7_100_003, 7_100_002], upcoming.pluck("appointment_id")
    assert_equal [7_200_003, 7_200_002], upcoming.first.fetch("revisions").pluck("id")
    assert_equal wall_time - 1.day, Time.iso8601(upcoming.first.fetch("start_at"))
    assert_equal TEST_NOW, Time.iso8601(upcoming.first.fetch("confirmed_at"))
    refute upcoming.first.key?("status")

    get "#{path}/history", section: "appointments", filter: "past"
    assert last_response.ok?, last_response.body
    past = JSON.parse(last_response.body).fetch("rows")
    assert_equal [7_100_001, 7_100_007, 7_100_006, 7_100_004], past.pluck("appointment_id")
    assert_equal [[7_200_005], [7_200_004]], past.slice(1, 2).map { |row| row.fetch("revisions").pluck("id") }
    assert_equal [nil, nil], past.slice(1, 2).pluck("provider_name")
    assert past.slice(1, 2).none? { |row| row.key?("status") }
    assert_equal "completed", past.last.fetch("outcome")
    assert_nil past.last.fetch("confirmed_at")
    assert_equal [7_200_001], past.last.fetch("revisions").pluck("id")

    get "#{path}/history", section: "appointments", filter: "past", appointment_id: "7100005"
    assert last_response.ok?, last_response.body
    assert_empty JSON.parse(last_response.body).fetch("rows")
  end

  def test_receipt_lookup_keeps_the_recorded_destination_and_unmatched_reply
    message = Message.create!(clinic_id: 1, clinic_name: "Austin", patient_id: 103,
      recipient_id: 190, sender: "+15125550100", destination: "+17375550190",
      channel: "SMS", status: "sent", body: "Original reminder", token: SecureRandom.hex(16), created_at: TEST_NOW)
    ActivityEvent.record(actor: "Patient", kind: "late_reply", body: "Please call me.",
      message_id: message.id, at: TEST_NOW + 1.minute)

    get "/api/patient-details/103/history", section: "activity", message_id: message.id
    assert last_response.ok?, last_response.body
    reply, receipt = JSON.parse(last_response.body).fetch("rows")
    assert_equal ["event", "receipt"], [reply.fetch("entry_type"), receipt.fetch("entry_type")]
    assert_equal message.id, reply.fetch("message_id")
    assert_empty reply.fetch("appointment_ids")
    assert_equal "+17375550190", receipt.fetch("destination")
    assert_equal 190, receipt.fetch("recipient_id")

    get "/api/patient-details/104/history", section: "activity", message_id: message.id
    assert last_response.ok?, last_response.body
    assert_empty JSON.parse(last_response.body).fetch("rows")
  end

end
