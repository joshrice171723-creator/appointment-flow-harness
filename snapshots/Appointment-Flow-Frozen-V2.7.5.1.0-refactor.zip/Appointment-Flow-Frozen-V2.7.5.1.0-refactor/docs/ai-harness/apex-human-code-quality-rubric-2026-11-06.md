# Ruby and Rails code quality rubric

Rebuilt 2026-11-10 as a source-linked review checklist. The earlier numerical weights, pass threshold, cap, and mandatory scoring exercises are retired. This operational checklist is an editorial translation of the cited guidance, not a grading system supplied by the books.

Use this source-linked review checklist to assess whether a developer can understand and safely change the code. The criteria below turn named passages from the [Ruby/Rails guide](Ruby-and-Rails-Coding-Guide.md#start) and documented Rails behavior into review questions. The evidence workflow and Appointment Flow constraints are project choices. Record findings without a numerical score.

<a id="focused-review"></a>
## Focused review of a change

Complete the review independently using source traces and checks you can run. Assess readability by tracing concrete inputs, decisions, and outcomes to their owners. Use automated checks for claims about executed behavior and mark unavailable checks Unverified.

1. Name the entry point, behavior and constraint under review. Start with a real case and inspect its callers and tests.
2. Use the applicable rows below. For a refactor, trace the same case before and after. Explain which fact is easier to find or which dependency is easier to understand.
3. Record **Meets**, **Revise**, **Unverified** or **Outside scope** for each area. Use Meets when the cited evidence supports the criterion, Revise for a concrete deficiency, Unverified when necessary evidence is missing, and Outside scope when the criterion does not apply. Use a file and line, an observed consequence and a concrete correction for each finding. Distinguish a demonstrated defect, an unresolved risk and a preference.
4. Report evidence separately. Source review establishes what the code says. An executed check establishes behavior in the checked environment.

Use the [40-chapter reference](Ruby-and-Rails-Coding-Guide.md#chapter-reference) for the principle behind an applicable criterion. Cite the entry and its page reference when the principle supports a recommendation. Explain the reading burden or behavior in the code under review.

| Criterion | What a reviewer should be able to show | Basis |
| --- | --- | --- |
| Business cases | Describe normal, rejected and special outcomes from the action and its rule. Point to the place each outcome is decided. | [B1](Ruby-and-Rails-Coding-Guide.md#b1), [Eloquent Ruby ch. 2](Ruby-and-Rails-Coding-Guide.md#er-02) |
| Proportion | Describe the burden removed by an extraction. Show the concrete cases it unifies and the requirement that makes them change together. Confirm the replaced path is gone. | [B2](Ruby-and-Rails-Coding-Guide.md#b2), [B9](Ruby-and-Rails-Coding-Guide.md#b9), [POODR ch. 1](Ruby-and-Rails-Coding-Guide.md#po-01), [POODR ch. 8](Ruby-and-Rails-Coding-Guide.md#po-08) |
| Dependencies | List the information a rule consumes. Identify the decision owner and the result callers request. Locate any changing external interface. | [B4](Ruby-and-Rails-Coding-Guide.md#b4), [B12](Ruby-and-Rails-Coding-Guide.md#b12), [POODR ch. 2](Ruby-and-Rails-Coding-Guide.md#po-02), [POODR ch. 3](Ruby-and-Rails-Coding-Guide.md#po-03), [POODR ch. 4](Ruby-and-Rails-Coding-Guide.md#po-04) |
| Call-site contract | Explain ambiguous arguments, units, returned values and missing data by inspecting the call and its definition. | [B6](Ruby-and-Rails-Coding-Guide.md#b6), [B8](Ruby-and-Rails-Coding-Guide.md#b8), [Eloquent Ruby ch. 8](Ruby-and-Rails-Coding-Guide.md#er-08) |
| Request flow | Follow the route to the action, allowed input and scoped lookup, then to the response. Locate business decisions in their owners and identify any guarantee provided by a callback or block wrapper. | [R1](Ruby-and-Rails-Coding-Guide.md#r1), [R2](Ruby-and-Rails-Coding-Guide.md#r2), [Eloquent Ruby ch. 10](Ruby-and-Rails-Coding-Guide.md#er-10), [Eloquent Ruby ch. 18](Ruby-and-Rails-Coding-Guide.md#er-18) |
| Persistence and side effects | Predict state after success, failure and relevant retry. Show transaction and connection ownership. Check writes against the read-only PMS boundary. | [R3–R4](Ruby-and-Rails-Coding-Guide.md#state-changes) |
| Behavioral evidence | Identify the exact regression a check catches. Pick a check at the rule, request, database or runtime boundary appropriate to the claim. | [B3](Ruby-and-Rails-Coding-Guide.md#b3), [R5](Ruby-and-Rails-Coding-Guide.md#behavior-tests), [Eloquent Ruby ch. 9](Ruby-and-Rails-Coding-Guide.md#er-09), [POODR ch. 9](Ruby-and-Rails-Coding-Guide.md#po-09) |

## Scope and evidence

For a patch, review affected callers and consequential behavior. For an application-wide change, sample each changed workflow and all affected write, permission and retry boundaries. Trace the React side using the [frontend rubric](Frontend-Code-Quality-Rubric.md) when the API or a visible workflow changes.

A demonstrated wrong recipient, cross-clinic access, duplicate delivery, lost history, PMS write or broken supported setup requires correction. Preserve the accepted assessment scope, including the disposable synthetic experience and SELECT-only PMS boundary. Deliberate exclusions stay outside the review.

Keep observed facts and evidence gaps visible. A successful suite alone cannot tell you whether the next developer will find the business rule. Count files, lines or jumps only when that helps locate a concrete burden. The review ends with supported findings and the remaining verification gaps.

## Example finding

An illustrative controller passes `refresh: true` into a shared transaction helper. The call site does not show whether a completed refresh survives a rejected action. Trace both paths and cite the transaction boundary before recommending a change. If the two operations have separate commit requirements, make their order visible while preserving how each path persists. [R3](Ruby-and-Rails-Coding-Guide.md#state-changes)

## Handoff

Record the revision and paths reviewed, a before-and-after trace where relevant, findings by consequence, and the checks run at each boundary. Mark any untested behavior as such. Review results apply to the examined paths and revision.

For a historical comparison, record the code revision, rubric revision, reviewed workflows, criterion ratings, and evidence used. Compare ratings across runs with matching criteria and scope.
