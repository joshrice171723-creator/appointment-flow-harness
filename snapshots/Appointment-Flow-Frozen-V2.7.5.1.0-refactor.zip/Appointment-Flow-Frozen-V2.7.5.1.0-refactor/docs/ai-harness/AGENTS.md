# Project motto

**Know at a glance, and understand in a click**

Use this principle when designing, building, and reviewing each view. Identify the first question its user needs answered. Make the answer visible on the main screen and put the reason, evidence, or next action one click away.

## Keep the system explainable

A small system with clear, well-reasoned decisions beats a large one reviewers cannot follow. Use the smallest complete fix for a demonstrated requirement or defect. Do not add features or layers just to raise a private audit score. Keep the two databases and the SELECT-only PMS boundary intentional and easy to trace. Write decisions in plain language so Joshua can review, challenge, and explain each choice.

## Supported display

Target standard desktop monitors. Mobile and tablet layouts are outside this take-home's scope; do not add dedicated small-screen styles or treat mobile testing as an unfinished requirement. Check the desktop layout at 1366×768 and 1920×1080. Preserve keyboard access, browser zoom, and reduced-motion support.

## Product copy

Use plain screen titles, labels, status messages, and instructions that help people use the app. For example, call the workspace chooser **Workspaces**.

Add promotional hero copy, taglines, slogans, product pitches, or decorative filler only when the user explicitly requests that kind of copy for that screen. Requests to design, redesign, or polish a screen call for functional copy by default.

Before handing off UI work, review every new or changed user-visible string. Keep it if it helps someone understand where they are, what happened, or what they can do next. Remove unsolicited promotional or decorative text and flag it in review.

## Examiner experience

This is a disposable assessment with synthetic data. Keep setup and the walkthrough direct. Do not add reviewer passwords, access tokens, typed confirmation phrases, or extra entry gates unless Joshua explicitly requests them or the brief requires them. Preserve source permissions and ordinary request protection without burdening the examiner.


## Human-readable code is a required outcome

### Required coding and review workflow

- For Ruby/Rails implementation, fixes, refactoring, and review, use [Writing Ruby and Rails for humans](Ruby-and-Rails-Coding-Guide.md#start) as the primary design guide and the [human code quality rubric](apex-human-code-quality-rubric-2026-11-06.md) to assess the result. For React, JavaScript, CSS, and browser interaction, use [Writing React frontends for humans](Frontend-Coding-Guide.md#start) and the [frontend rubric](Frontend-Code-Quality-Rubric.md). These are required project instructions, not optional references.
- Before coding or reviewing, read the applicable guide's **Start here** workflow, source/access notes, and task index, then the relevant source-linked entries. For an application-wide refactor, read both guides completely. Cross-boundary changes require both guides and relevant criteria from both review checklists. Apply shared design principles without imposing Ruby idioms on React.
- Use the [Ruby chapter reference](Ruby-and-Rails-Coding-Guide.md#chapter-reference) for all 31 chapters of *Eloquent Ruby* and all nine chapters of *Practical Object-Oriented Design in Ruby*. Use the [JavaScript chapter reference](Frontend-Coding-Guide.md#bottles-js-chapters) for the nine chapters of *99 Bottles of OOP*. For a focused change, follow the task index to the chapter that addresses the decision. When a book principle materially supports a design or review finding, cite its guide entry and the page reference. Use the frontend guide's React and browser entries for framework-specific behavior.
- For React work, use [Current React practice](Frontend-Coding-Guide.md#react-practice). It connects the supplied *Learning React* and *The Road to learn React* passages to current React.dev guidance. Confirm an API is available in the project's installed version and follow its existing build and browser test setup.
- Use existing code to establish behavior, callers, and constraints; do not treat its structure as the preferred design. Prefer familiar Rails or React/browser conventions, as applicable, and the simplest complete design supported by the guides. Keep custom plumbing only when its purpose and guarantees justify it.
- Name the concrete comprehension or behavior problem and select the relevant guide sections before choosing a design. Keep rule ownership, inputs, outputs, transaction boundaries, and failure behavior apparent. Do not mechanically copy examples or extract a class for every action.
- Before handing off a code change, apply the applicable source-linked review checklist to the affected paths and their callers. The rubric filenames are retained for existing links; their previous invented numerical weights, thresholds, and grading exercises are retired. Do not introduce replacement scores or architecture mandates without Joshua's explicit agreement. A finding needs a concrete reading or behavior problem, evidence, and the relevant source or project requirement.
- Keep actual book teaching, official framework guidance, Joshua's project requirements, and editorial applications visibly distinct. Follow the cited passage for consequential design choices. Never infer chapter contents from titles, present original examples as book examples, or claim full-book access from a sample. If a source is unavailable, report that limit rather than inventing its teaching. Reader ratings help select sources; they do not prove an implementation is good.
- Report the guide sections used, the meaningful readability or behavior improvement, checks actually run, and material evidence gaps. Keep source evidence, automated checks, running behavior, and Joshua's acceptance distinct. Do not add scope, change the guide or rubric, or introduce layers merely to improve a score.
- Scale reading and verification to the task. Documentation-only work needs relevant content and reference checks, not an unrelated application suite. Joshua's explicit instructions and accepted project scope take precedence.

- Do not describe code as clean or readable solely because tests pass, files shrink, SQL disappears, or models/services/serializers exist.
- Name the concrete comprehension problem before refactoring. Demonstrate the before/after path for an actual behavior; remove superseded code.
- Keep each business rule with an obvious owner. Response serializers format results; they must not hide recipient or permission decisions. Do not immediately flatten domain records into undocumented hashes for internal workflow use.
- Make inputs, units, outputs, and transaction ownership apparent. Prefer meaningful keyword arguments where positional meanings are unclear. Avoid passing an entire coordinator into a child service that delegates back to it.
- Extract only when it reduces the reader's working knowledge or change burden. Do not create forwarding classes or enforce arbitrary method/file-length limits.
- Treat readable tests and fixtures as part of maintainability. Report automated checks separately from human comprehension and Joshua's acceptance; never invent a human review result.
