# Writing React frontends for humans

Revised 2026-11-10. The source table identifies the editions and passages consulted. The task index connects them to React, JavaScript and browser decisions in Appointment Flow.

<a id="start"></a>
## Start here

Use the [task index](#router) for the immediate design decision. [Current React practice](#react-practice) combines selected passages from *Learning React* and *The Road to learn React* with React.dev guidance. The [99 Bottles of OOP chapter reference](#bottles-js-chapters) covers all nine chapters of the supplied JavaScript edition with page references and examples.

Pick one user action. Follow it from the screen to the state owner, event handler, request, Rails outcome, and visible result. Write down where a reader has to open unrelated files, guess at state, or infer what an error means. Use the entries below to address that concrete problem. After the change, trace the same action again and record any behavioral checks that ran.

This guide separates the source principle from its application to Appointment Flow. The code fragments are original illustrations of the application, with names and interfaces chosen for the example. Read the actual route, contract, and surrounding code before applying them.

## What was read

| Book | Text consulted | Selection evidence |
| --- | --- | --- |
| Marijn Haverbeke, *Eloquent JavaScript*, fourth edition (2024) | The author hosts the full edition. This guide uses passages in chapters 5, 8, 10, and 18, linked below. [Author's edition](https://eloquentjavascript.net/) | 4.14/5 from 3,261 ratings in the indexed Goodreads snapshot. The listing includes reviews from earlier editions, so treat the rating as evidence about the work. [Goodreads](https://www.goodreads.com/book/show/216522872-eloquent-javascript-4th-edition) |
| Kyle Simpson, *You Don't Know JS Yet: Scope & Closures*, second edition (2020) | The author hosts the manuscript. This guide uses passages in chapters 6–8. [Author's manuscript](https://github.com/getify/You-Dont-Know-JS/tree/2nd-ed/scope-closures) | 4.31/5 from 98 ratings in the indexed Goodreads snapshot for the second-edition paperback. [Goodreads](https://www.goodreads.com/book/show/53253140) |
| Ilya Grigorik, *High Performance Browser Networking* (2013) | The complete book is available on its official site. This guide uses the resource waterfall discussion in chapter 10 and the roundtrip discussion in chapter 13. [Official book](https://hpbn.co/) | 4.50/5 from 865 ratings in the indexed Goodreads snapshot for the work. [Goodreads](https://www.goodreads.com/book/show/18510298-high-performance-browser-networking) |
| Sandi Metz, Katrina Owen and TJ Stankus, *99 Bottles of OOP*, second edition, JavaScript v2.0.0 (2020) | Selected passages from all nine chapters of the supplied 297-page PDF. [Chapter reference](#bottles-js-chapters) | 4.55/5 from 676 ratings in the indexed Goodreads snapshot. Goodreads aggregates editions of the work. [Goodreads](https://www.goodreads.com/book/show/54500642-99-bottles-of-oop) |
| Alex Banks and Eve Porcello, *Learning React: Functional Web Development with React and Redux*, first edition (2017, second release 2018) | Supplied 350-page PDF. Selected passages on components, data transformations, state, effects, tests, routing and the server. [Current React practice](#react-practice) | Supplied edition requested for this guide. |
| Robin Wieruch, *The Road to learn React*, supplied 2018 edition | Supplied 208-page PDF. Selected passages on composition, inputs, API reads, module boundaries, tests, refs and state. [Current React practice](#react-practice) | Supplied edition requested for this guide. |

Ratings describe reader reception in indexed listings. Live counts may differ. The chapters determine which ideas apply. React documentation supplies React-specific guidance, W3C materials supply accessibility guidance, RFC 9110 supplies retry semantics, and Playwright documentation supplies browser testing guidance. Each is identified below.

<a id="router"></a>
## Find guidance by task

| Task | Read |
| --- | --- |
| Name an extraction, choose file boundaries, expose a hook interface | [F01](#f01), [F02](#f02), [F03](#f03) |
| Compose a screen, mount a root or keep rendering pure | [F17](#f17), [F18](#f18) |
| Decide whether to extract shared JavaScript behavior | [Simplicity](#bottles-js-01), [Concepts](#bottles-js-03), [Responsibilities](#bottles-js-05) |
| Choose defaults, select a variant or compose collaborators | [Defaults](#bottles-js-04), [Variants](#bottles-js-06), [Factories](#bottles-js-07), [Dependencies](#bottles-js-08) |
| Locate draft and selection state, derive display values, represent request progress | [F04](#f04), [F05](#f05), [F06](#f06) |
| Preserve row identity, reset an editor deliberately or focus an invalid field | [F19](#f19), [F20](#f20) |
| Choose an effect, a reducer, context or a custom hook | [F21](#f21), [F23](#f23) |
| Submit an action, load data for a different selection, handle a late result | [F07](#f07), [F08](#f08) |
| Interpret HTTP failures, keep drafts on rejection, distinguish ambiguous writes | [F09](#f09), [F10](#f10), [F11](#f11) |
| Scope URL and request results, then apply an accepted server outcome | [F22](#f22), [F24](#f24) |
| Label forms, keep tables readable, verify desktop and motion behavior | [F12](#f12), [F13](#f13), [F14](#f14) |
| Verify a browser interaction, check a transformation or investigate performance | [F15](#f15), [F16](#f16), [F25](#f25) |
| Check JavaScript behavior before and after a refactor | [Behavior tests](#bottles-js-02), [Unit and integration checks](#bottles-js-09) |

<a id="f01"></a>
### F01. Put the operation in the name

**Book principle.** Haverbeke's chapter on higher-order functions contrasts working in the vocabulary of the problem with exposing counters and other incidental mechanics. [Eloquent JavaScript, chapter 5](https://eloquentjavascript.net/05_higher_order.html)

**Appointment Flow application.** A reader of a workspace screen should see that the user is opening a follow-up or saving a contact note. A generic action dispatcher whose arguments encode several behaviors makes that reader reconstruct which action runs. Extract when the new name explains a recognizable operation and the caller can remain ignorant of the hidden detail. Keep a simple expression where the meaning is already apparent.

**Original illustration.**

```js
const awaitingReply = appointments.filter(appointment => appointment.status === "awaiting_reply");
```

**Review.** Ask a reader to point to the operation in the call site and explain the data it uses.

<a id="f02"></a>
### F02. Give a module a small visible interface

**Book principle.** Haverbeke describes modules through their stated dependencies and interfaces. Simpson explains how code serving a common purpose can be colocated and exposed selectively. [Eloquent JavaScript, chapter 10](https://eloquentjavascript.net/10_modules.html) · [Scope & Closures, chapter 8](https://github.com/getify/You-Dont-Know-JS/blob/2nd-ed/scope-closures/ch8.md)

**Appointment Flow application.** Group functions by the behavior they own. A shared transport can own headers and response decoding. A follow-up editor owns its draft, recovery message, and navigation decisions. A transport interface that exposes setters for the editor's fields blurs that boundary. Put the test at the level whose contract it checks.

**Review.** Follow the module's public calls and identify which details a caller must know to use it correctly.

<a id="f03"></a>
### F03. Keep temporary values near their use

**Book principle.** Simpson's least-exposure discussion connects narrow scope to fewer accidental dependencies, name collisions, and surprising mutations. His closure chapter shows how callbacks retain access to values in their enclosing scope. [Scope & Closures, chapter 6](https://github.com/getify/You-Dont-Know-JS/blob/2nd-ed/scope-closures/ch6.md) · [Scope & Closures, chapter 7](https://github.com/getify/You-Dont-Know-JS/blob/2nd-ed/scope-closures/ch7.md)

**Appointment Flow application.** Capture the identity relevant to a request near the call. A callback that completes later should still know which follow-up started it. Give the screen a meaningful result rather than exposing the request's temporary flags. Scope helps explain identity, while F08 covers whether the result may still update the screen.

**Review.** Read the handler in isolation. Identify every mutable value it can affect and every captured value it will read later.

<a id="f04"></a>
### F04. Choose a single owner for editable state

**Framework principle.** React assigns each piece of state to a specific component. Coordinated children can receive the state and event handlers from their closest common owner. [React, Sharing State Between Components](https://react.dev/learn/sharing-state-between-components#a-single-source-of-truth-for-each-state)

**Appointment Flow application.** A note editor may own unsaved text while the screen owns the selected follow-up. The persisted note from Rails and the current draft represent different facts. Decide what happens to the draft when the selected record changes, when saving succeeds, and when Rails rejects a write.

**Review.** Point to the code that initializes, edits, retains, and clears the draft. Verify a rejected submission preserves what the user typed when the editor stays open.

<a id="f05"></a>
### F05. Calculate display values from their inputs

**Framework principle.** React recommends calculating information available from existing state or props during render. Independent copies create synchronization work. [React, Choosing the State Structure](https://react.dev/learn/choosing-the-state-structure#avoid-redundant-state)

**Appointment Flow application.** Compute the displayed row count from displayed records. A total over all appointments comes from Rails when the client only has a subset. Keep those labels distinct. Derive status text from the authoritative response without writing a second independent status into state.

**Original illustration.**

```js
const shownCount = visibleAppointments.length;
const totalCount = response.totalAppointments;
```

**Review.** Identify what changes either count. Confirm the labels reflect the actual population each count describes.

<a id="f06"></a>
### F06. Represent states the reader can reason about

**Framework principle.** React advises structuring related state to avoid contradictory combinations. [React, Choosing the State Structure](https://react.dev/learn/choosing-the-state-structure#avoid-contradictions-in-state)

**Appointment Flow application.** Distinguish initial load, successful empty results, and failed load. A background refresh can coexist with populated data, and a save can fail while those data remain usable. Model those separate operations deliberately. Use a status or a small named result where it makes a transition easier to see.

**Review.** Explain which state renders before a response, after success with zero records, and after refresh fails with existing records.

<a id="f07"></a>
### F07. Start the write in the interaction that asks for it

**Framework principle.** React distinguishes a POST triggered by displaying a screen from one triggered by submitting a form. It places the submission in the event handler. [React, You Might Not Need an Effect](https://react.dev/learn/you-might-not-need-an-effect#sending-a-post-request)

**Book principle.** The HTTP and forms chapter shows interception at the form submit event and describes disabling a control while its server action is pending. [Eloquent JavaScript, chapter 18](https://eloquentjavascript.net/18_http.html)

**Appointment Flow application.** A note save starts at the form's submit handler, including keyboard submission. The handler shows which inputs are sent and when saving disables the control. Backend duplicate protection still owns the consequences of a repeated request.

**Review.** Submit with the keyboard. Trigger a rerender or refresh while the editor is open and confirm that it does not initiate an extra write.

<a id="f08"></a>
### F08. Keep obsolete responses from updating the active view

**Framework principle.** React's synchronization guide shows cleaning up a read by aborting it or ignoring a result for the previous selection. [React, Synchronizing with Effects](https://react.dev/learn/synchronizing-with-effects#fetching-data)

**Appointment Flow application.** A slow result for clinic A must not replace a faster result for clinic B. Apply the same identity check to errors. A late save completion can refer to a real committed write even if the editor that sent it has closed. Keep the previous record's result from clearing the current record's draft. Preserve enough identity in the request and response handling to explain the outcome.

**Review.** Delay A, select B, return B, then release A. Check the displayed records, alert, and draft against B. Check server persistence separately for writes.

<a id="f09"></a>
### F09. Keep response status and decoding distinct

**Book principle.** Haverbeke explains that fetch can fulfill with a non-success HTTP response. Network failures and body parsing failures reject through different paths. [Eloquent JavaScript, chapter 18, Fetch](https://eloquentjavascript.net/18_http.html)

**Appointment Flow application.** A stale-edit response, a lost connection, and an invalid response body require different conclusions. Preserve the status at the request boundary and validate the response shape where it matters. An empty list can mean a successful query with zero records. An unrecognized payload cannot establish that result.

**Review.** Force an HTTP rejection and a transport failure independently. Confirm what each tells the user and what the current editor retains.

<a id="f10"></a>
### F10. Handle known failures at the right boundary

**Book principle.** Haverbeke's selective-catching discussion explains how a broad catch can bury a programming error under a message for an expected failure. His cleanup discussion explains how a finally block releases local work after either outcome. [Eloquent JavaScript, chapter 8](https://eloquentjavascript.net/08_error.html)

**Appointment Flow application.** Convert known rejection responses into useful feedback. Trace and preserve the actual reporting path for unexpected failures; if none exists, record that gap rather than assuming an error boundary is present. Release the pending marker for the action that owns it. A successful save followed by a failed refresh is still a successful save, so handle that refresh outcome separately.

**Review.** Read the catch and its guarded calls. Point to how a reader can distinguish save rejection, save acceptance with stale display, and unexpected failure.

<a id="f11"></a>
### F11. Check whether a write can safely be repeated

**Protocol principle.** HTTP Semantics limits automatic retries of non-idempotent requests to cases where the client knows repeating is safe or can establish that the initial request never applied. [RFC 9110, §9.2.2](https://www.rfc-editor.org/rfc/rfc9110.html#section-9.2.2)

**Appointment Flow application.** A lost response can leave confirmation status unknown to the browser. Preserve the user's input when needed and direct them to check the record. Any automatic repeat must follow the endpoint's actual duplicate protection contract. Distinguish a disabled button from proof that the server prevents duplicate effects.

**Review.** Trace what happens if Rails commits and the response is lost. Check the real record or events when claiming a repeat is harmless.

<a id="f12"></a>
### F12. Connect errors to their form controls

**Accessibility guidance.** W3C's forms tutorial associates field errors with inputs through descriptions and explains giving people information they can act on after submission. [W3C WAI, User Notification](https://www.w3.org/WAI/tutorials/forms/notifications/)

**Appointment Flow application.** Name the contact note field, associate relevant feedback with it, and keep the entered value available for correction. Place feedback where users can find it by keyboard and describe the next action in plain language.

**Original illustration.**

```jsx
<>
  <label htmlFor="contact-note">Contact note</label>
  <textarea
    id="contact-note"
    value={note}
    onChange={event => setNote(event.target.value)}
    aria-invalid={Boolean(noteError)}
    aria-describedby={noteError ? "contact-note-error" : undefined}
  />
  {noteError && <p id="contact-note-error">{noteError}</p>}
</>
```

This fragment assumes a single instance. Use unique IDs when multiple forms can render together.

**Review.** Submit a rejected value by keyboard. Locate the field, its error, and the next usable action.

<a id="f13"></a>
### F13. Preserve relationships in operational tables

**Accessibility guidance.** W3C's tables tutorial describes using header and data cells so assistive technology can identify how the information relates. [W3C WAI, Tables Tutorial](https://www.w3.org/WAI/tutorials/tables/)

**Appointment Flow application.** Use a table where readers compare the same columns across appointment rows. Give columns meaningful names and preserve the header association when adding sorting, scroll containers, or wrapping long values. Use layout CSS where the content has no row-to-column relationship.

**Review.** Check a dense list at the supported desktop sizes. Inspect whether keyboard users can reach its controls and whether cell and header relationships remain available.

<a id="f14"></a>
### F14. Preserve desktop access when text or motion preferences change

**Accessibility guidance.** W3C describes preserving content and functionality when text resizes, and documents a CSS media query for reducing motion. [W3C WAI, Resize Text](https://www.w3.org/WAI/WCAG22/Understanding/resize-text.html) · [W3C WAI, Animation from Interactions](https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html)

**Appointment Flow application.** Check the required 1366×768 and 1920×1080 desktop layouts when changing a view. Include long names, enlarged text, keyboard reachability, and reduced motion where the change affects them. Allow critical actions to wrap or scroll in the relevant region. Mobile and tablet layouts are outside the assessment's defined scope.

**Review.** Verify the primary action and its feedback remain reachable at the applicable sizes and zoom. Record the actual settings used.

<a id="f15"></a>
### F15. Verify the behavior that can regress

**Tool guidance.** Playwright recommends checking user-visible behavior and choosing locators that reflect the way users identify controls. [Playwright, Best Practices](https://playwright.dev/docs/best-practices#test-user-visible-behavior)

**Appointment Flow application.** A useful regression check changes a selection, submits an action, or inspects meaningful feedback. A controlled response order isolates a race. A stubbed result establishes how the browser handles that response, while a server-backed check establishes persistence and the real API contract. State those results separately.

**Original illustration.**

```js
await page.getByRole("button", { name: "Save note" }).click();
await expect(page.getByRole("status")).toHaveText("Note saved.");
```

Use the actual screen's name and role. Add record or event assertions when the claim concerns persistence.

**Review.** Name the failure the check would catch. Identify any remaining gap between the stubbed contract and the real endpoint.

<a id="f16"></a>
### F16. Read the resource waterfall before optimizing

**Book principle.** Grigorik separates the stages of fetching a resource and shows how resource ordering, server response time, and connection delay contribute to a waterfall. He explains why unnecessary roundtrips can matter even when response bodies are small. [High Performance Browser Networking, chapter 10](https://hpbn.co/primer-on-web-performance/#analyzing-the-resource-waterfall) · [High Performance Browser Networking, chapter 13](https://hpbn.co/optimizing-application-delivery/)

**Appointment Flow application.** Measure from opening the workspace to the list becoming useful under comparable settings and data. Separate network delay from browser rendering before proposing a cache or changing how requests run. The book's old protocol and browser examples supply historical context. Use current measurements for today's application.

**Review.** Report the scenario, conditions, and observed bottleneck. For a claimed improvement, rerun the same scenario after the change.

<a id="react-practice"></a>
## Current React practice from both books

Banks and Porcello's *Learning React: Functional Web Development with React and Redux* is the May 2017 first edition, February 2018 second release. Wieruch's *The Road to learn React* is the supplied 2018 PDF with the February 2018 changelog. In both PDFs printed page 1 is PDF page 15. The entries below identify the passages consulted and use original examples adapted for this project's React 19.1.1 setup.

The books use class components and tooling from their publication period. For a change here, use the app's installed version and the relevant React.dev reference. The current documentation explains function components, hooks and their rules. Treat routing, state libraries, tooling changes and server rendering as separate design decisions with their own costs.

<a id="f17"></a>
### F17. Compose the screen around what it does

**Book basis.** Banks and Porcello separate the description of a view from mounting it. Wieruch splits a search-and-results screen into components that receive the values and actions they need. *Learning React*, printed pp. 59, 62, 67, 81–83 (PDF pp. 73, 76, 81, 95–97). *The Road to learn React*, printed pp. 62, 66 (PDF pp. 76, 80).

**Use today.** Start with the user action. Keep the screen's coordination visible and give a reusable or independently meaningful part explicit props. Let the root entry point own mounting. A client root uses `createRoot`. Hydration applies when React previously rendered the matching HTML on the server. See [Thinking in React](https://react.dev/learn/thinking-in-react), [createRoot](https://react.dev/reference/react-dom/client/createRoot), and [hydrateRoot](https://react.dev/reference/react-dom/client/hydrateRoot).

A header receives two facts and leaves filtering and fetching with their owners.

```jsx
function FollowUpHeading({ clinicName, openCount }) {
  return (
    <header>
      <h1>{clinicName}</h1>
      <p>{openCount} open follow-ups</p>
    </header>
  );
}
```

An entry-point fragment mounts an existing view into its known container.

```jsx
import { createRoot } from "react-dom/client";

const container = document.getElementById("workspace-root");
createRoot(container).render(<Workspace />);
```

**Review.** Read from the entry point through the screen. Which split removes a real detail from the reader's view? Which component owns the decision that selects the records?

<a id="f18"></a>
### F18. Keep render and state transformations pure

**Book basis.** Banks and Porcello distinguish transformations that create new values from operations that change inputs. Wieruch derives a sorted display list from the data and the selected sort. *Learning React*, printed pp. 19, 22, 36, 38, 41 (PDF pp. 33, 36, 50, 52, 55). *The Road to learn React*, printed p. 169 (PDF p. 183).

**Use today.** Rendering should calculate the UI from the current props, state and context. Treat those inputs as read-only. Derive a visible list while rendering when it is already available from the inputs. Put writes and external work at an event or synchronization boundary. Keep [F05](#f05)'s distinction between a displayed subset and a server total. See [Keeping Components Pure](https://react.dev/learn/keeping-components-pure) and [You Might Not Need an Effect](https://react.dev/learn/you-might-not-need-an-effect).

Return a changed record in a new array and preserve the other records.

```js
function renameClinic(rows, clinicId, name) {
  return rows.map((clinic) =>
    clinic.id === clinicId ? { ...clinic, name } : clinic,
  );
}
```

Filter into a new array, then sort that array in place. The original rows stay intact.

```js
const sortedRows = rows
  .filter((row) => row.status === "open")
  .sort((a, b) => a.patientName.localeCompare(b.patientName));
```

**Review.** Would the same inputs describe the same screen on the next render? Check that the original array and changed record remain intact after a local transformation.

Measure an expensive calculation before memoizing it. The calculation should produce the correct result when React discards the cache. See [useMemo](https://react.dev/reference/react/useMemo).

<a id="f19"></a>
### F19. Preserve identity through reorder and record changes

**Book basis.** Both books map data into elements. Wieruch's list example connects a row and its interaction to an identifier. *Learning React*, printed pp. 67, 83 (PDF pp. 81, 97). *The Road to learn React*, printed pp. 20, 35 (PDF pp. 34, 49).

**Use today.** Give list siblings stable keys from the records. Array positions can change after filtering, sorting or removal. A component's type, position and key affect whether its local state is preserved. Use a new editor key to reset local state when the product contract calls for a fresh draft for a different record. Decide what happens to unsaved work before making a reset automatic. See [Rendering Lists](https://react.dev/learn/rendering-lists) and [Preserving and Resetting State](https://react.dev/learn/preserving-and-resetting-state).

Use the record ID where it is unique among the siblings.

```jsx
<ul aria-label="Open follow-ups">
  {sortedRows.map((row) => (
    <li key={row.id}>{row.summary}</li>
  ))}
</ul>
```

If the editor should start fresh after the user changes records, scope its local state to that record. This assumes the navigation flow has resolved any unsaved draft.

```jsx
<FollowUpEditor
  key={JSON.stringify([clinicId, followUp.id])}
  followUp={followUp}
/>
```

**Review.** Sort and filter while a row owns editable state. Change clinics or records while a draft exists. Verify what stays with each record and what resets.

<a id="f20"></a>
### F20. Give an editable field one owner and use a ref for focus

**Book basis.** Banks and Porcello pass values down and callbacks back to the state owner. Wieruch connects a controlled input to the displayed filter and uses a DOM reference for focus. *Learning React*, printed pp. 109, 130, 134 (PDF pp. 123, 144, 148). *The Road to learn React*, printed pp. 60, 148 (PDF pp. 74, 162).

**Use today.** Keep a draft in the nearest component that coordinates it. Pass a consistent string value to a controlled text field and update that value in its change handler. Keep a DOM ref for imperative work such as focus. Associate the label and error with the field so keyboard users can find and correct it. See [Sharing State Between Components](https://react.dev/learn/sharing-state-between-components), [textarea](https://react.dev/reference/react-dom/components/textarea) and [Manipulating the DOM with Refs](https://react.dev/learn/manipulating-the-dom-with-refs).

The parent supplies the draft and owns the change.

```jsx
function NoteField({ note, onNoteChange }) {
  return (
    <label>
      Follow-up note
      <textarea value={note} onChange={(event) => onNoteChange(event.target.value)} />
    </label>
  );
}
```

Inside the form component, focus the field on a validation error. This fragment assumes the form renders the associated error text.

```jsx
const noteRef = useRef(null);

function handleInvalidNote() {
  setNoteError("Enter a follow-up note.");
  noteRef.current?.focus();
}

<textarea
  ref={noteRef}
  id="follow-up-note"
  aria-invalid={Boolean(noteError)}
  aria-describedby={noteError ? "note-error" : undefined}
/>;
```

**Review.** Follow input, save, rejection and reset to their owners. Check that a rejected save keeps the intended draft and brings the user to useful feedback.

<a id="f21"></a>
### F21. Put effects at synchronization boundaries

**Book basis.** Banks and Porcello use component lifecycle methods to connect to timers, requests and other libraries. Wieruch introduces fetching and conditional rendering as the list comes from an API. *Learning React*, printed pp. 141–142, 159, 172 (PDF pp. 155–156, 173, 186). *The Road to learn React*, printed pp. 93, 113 (PDF pp. 107, 127).

**Use today.** Name the external system and the conditions for starting and stopping synchronization. Keep dependencies aligned with the values the effect reads. Call ordinary hooks at the top level of a component or custom hook. A write requested by a user starts in its event handler, as in [F07](#f07). See [Lifecycle of Reactive Effects](https://react.dev/learn/lifecycle-of-reactive-effects), [Removing Effect Dependencies](https://react.dev/learn/removing-effect-dependencies), and [Rules of Hooks](https://react.dev/reference/rules/rules-of-hooks).

Register and remove the same listener. The callback belongs to the existing refresh flow.

```jsx
import { useEffect } from "react";

function RefreshWhenOnline({ refreshAvailability }) {
  useEffect(() => {
    window.addEventListener("online", refreshAvailability);
    return () => window.removeEventListener("online", refreshAvailability);
  }, [refreshAvailability]);

  return null;
}
```

Capture the record and draft at submit. The surrounding request flow owns rejection, duplicate prevention and uncertain outcomes.

```js
async function handleSubmit(event) {
  event.preventDefault();
  const outcome = await saveFollowUp({ id: followUpId, note: draft });
  showSaveOutcome(outcome);
}
```

**Review.** Describe a start and stop cycle, including a dependency change. When the operation is a user action, locate the handler and identify the record it submits.

<a id="f22"></a>
### F22. Give each read a clear identity and outcome

**Book basis.** Wieruch distinguishes filtering loaded rows from querying a larger server dataset. His examples preserve the search term when loading another page and identify cached results by the query they answer. Banks and Porcello also use URL parameters for view choices. *The Road to learn React*, printed pp. 96, 101, 106, 113, 152 (PDF pp. 110, 115, 120, 127, 166). *Learning React*, printed pp. 273, 286, 292 (PDF pp. 287, 300, 306).

**Use today.** Use URL state when a view choice should survive copying the address, reloading or browser navigation. Distinguish initial loading, successful empty results, failure and refreshing an existing result. Keep each result and error tied to the relevant clinic and query. Cleanup for an effect-driven read should abort it or ignore an obsolete completion. Treat request identity separately from whether the same scope may show a previous successful result while refreshing. Decide what a cache would retain and invalidate before adding one. See [Synchronizing with Effects](https://react.dev/learn/synchronizing-with-effects#fetching-data) and [Choosing the State Structure](https://react.dev/learn/choosing-the-state-structure).

Preserve the other filters when building a link for a view choice. The route is illustrative.

```js
function followUpSortUrl(search, sort) {
  const query = new URLSearchParams(search);
  query.set("sort", sort);
  return `/follow-ups?${query}`;
}
```

Choose what to display from the active request and the tagged result. Here requestKey identifies the latest request for the visible clinic, filters and page.

```js
function visibleListState(result, requestKey) {
  if (!result || result.requestKey !== requestKey) {
    return { kind: "loading" };
  }

  return result;
}
```

**Review.** Delay clinic A, load clinic B, then release A. Check that rows and errors remain scoped to B. Verify that pagination keeps its search, and that an empty successful response differs from a load failure.

<a id="f23"></a>
### F23. Choose state tools by the coordination problem

**Book basis.** Banks and Porcello show pure reducer transitions and compare passing a shared store with accessing it through context. Wieruch moves state closer to the component that uses it and demonstrates computing a change from previous state. *Learning React*, printed pp. 184, 187, 198, 213, 216, 220–221 (PDF pp. 198, 201, 212, 227, 230, 234–235). *The Road to learn React*, printed pp. 174, 178, 185 (PDF pp. 188, 192, 199).

**Use today.** Use local state for a local value. Lift a value to the nearest owner when components need to coordinate. Try props or composition before context. Use a reducer if related transitions are becoming hard to follow across handlers. A custom hook can share the behavior of using state, while each call still has its own state. Keep network work in the appropriate event or effect. See [Extracting State Logic into a Reducer](https://react.dev/learn/extracting-state-logic-into-a-reducer), [Passing Data Deeply with Context](https://react.dev/learn/passing-data-deeply-with-context), and [Reusing Logic with Custom Hooks](https://react.dev/learn/reusing-logic-with-custom-hooks).

Use an updater for a local list change that depends on the latest state. This example dismisses a row from the current view.

```js
setVisibleRows((rows) => rows.filter((row) => row.id !== dismissedId));
```

A small reducer names related draft transitions. Rejection leaves the draft available to edit or retry.

```js
function editorReducer(state, action) {
  switch (action.type) {
    case "noteEdited":
      return { ...state, note: action.note, rejection: null };
    case "saveRejected":
      return { ...state, rejection: action.message };
    default:
      throw new Error(`Unknown editor action: ${action.type}`);
  }
}
```

**Review.** Identify the owner and the transition that changes each value. Explain why adding a reducer, context or hook helps that particular flow. Confirm the updater is pure. See [Queueing a Series of State Updates](https://react.dev/learn/queueing-a-series-of-state-updates).

<a id="f24"></a>
### F24. Render the server outcome the user actually received

**Book basis.** Banks and Porcello show that client-rendered changes can appear before the backend persists them. Their server chapter distinguishes data communication from rendering and demonstrates passing the same initial data to server and browser views. *Learning React*, printed pp. 297–299, 306, 318, 321 (PDF pp. 311–313, 320, 332, 335).

**Use today.** Keep Rails authoritative for permissions, records, totals and writes. The browser owns the draft, selection and feedback. Decode the response at the existing request boundary and map it to an explicit outcome. Separate a rejected action, an unknown outcome after a transport failure and an accepted action whose refresh later fails. See [F09](#f09), [F10](#f10) and [F11](#f11).

Apply the returned record only on a confirmed save. This fragment assumes the request boundary has validated the shape and the current screen owns the result.

```js
function applySaveResult(result, { replaceRow, reportRejection }) {
  switch (result.kind) {
    case "saved":
      replaceRow(result.followUp);
      return;
    case "rejected":
      reportRejection(result.message);
      return;
    default:
      throw new Error(`Unexpected save outcome: ${result.kind}`);
  }
}
```

A separate refresh failure leaves the confirmed save visible. This fragment assumes the accepted result has already been applied and reload returns a status.

```js
const refresh = await reloadCurrentList();

if (refresh.kind === "failed") {
  showNotice("Follow-up saved. The list could not refresh.");
}
```

**Review.** Trace who owns the server fact and how it reaches the screen. Verify what the editor shows after a rejection, a lost response and a successful save followed by a failed reload.

<a id="f25"></a>
### F25. Test a visible promise at its boundary

**Book basis.** Banks and Porcello show focused tests of state transformations and separate tests of the UI. Wieruch distinguishes tests of an isolated function, interactions between parts and an end-to-end scenario. He also uses named modules to organize a growing screen. *Learning React*, printed pp. 229, 233, 245, 258 (PDF pp. 243, 247, 259, 272). *The Road to learn React*, printed pp. 127, 132 (PDF pp. 141, 146).

**Use today.** Use a small pure-function check when it establishes the rule. Use the existing Playwright setup when the claim concerns interaction or visible recovery. Keep source, stubbed browser behavior and server-backed persistence evidence distinct. Extract a named module when its responsibility helps a reader find the code. See [Playwright, Best Practices](https://playwright.dev/docs/best-practices) and [F15](#f15).

A test fragment uses the transformation from [F18](#f18). It checks both the returned value and the unchanged input.

```js
import assert from "node:assert/strict";

const clinics = [{ id: 7, name: "East" }];
const renamed = renameClinic(clinics, 7, "East Clinic");

assert.equal(renamed[0].name, "East Clinic");
assert.equal(clinics[0].name, "East");
```

A browser test fragment checks recovery with a rejected-save fixture already in place.

```js
const note = page.getByRole("textbox", { name: "Follow-up note" });
await note.fill("Called the clinic");
await page.getByRole("button", { name: "Save" }).click();
await expect(page.getByRole("alert")).toHaveText("Review the current follow-up.");
await expect(note).toHaveValue("Called the clinic");
```

**Review.** Name the regression the check catches. Identify the separate evidence needed for a real server effect.

## Handoff

Review the changed path with the [frontend rubric](Frontend-Code-Quality-Rubric.md). For work that crosses Rails, include the relevant [backend guide](Ruby-and-Rails-Coding-Guide.md) and [backend rubric](apex-human-code-quality-rubric-2026-11-06.md). Keep evidence from the source trace, executed checks, and human acceptance separate.

<a id="bottles-js-chapters"></a>
## 99 Bottles of OOP for JavaScript

Sandi Metz, Katrina Owen and TJ Stankus. Second edition, JavaScript version 2.0.0, 2020. The supplied PDF has 297 pages. Printed page 1 is PDF page 15. The summaries draw on the cited passages in all nine numbered chapters.

These examples apply the book's reasoning to JavaScript used by the frontend. They are original fragments with illustrative names. Use the [frontend task index](#router) for React state, browser behavior and testing. Add a class, factory or wrapper when its responsibility reduces what callers need to understand.

- [1. Rediscovering Simplicity](#bottles-js-01)
- [2. Test Driving Shameless Green](#bottles-js-02)
- [3. Unearthing Concepts](#bottles-js-03)
- [4. Practicing Horizontal Refactoring](#bottles-js-04)
- [5. Separating Responsibilities](#bottles-js-05)
- [6. Achieving Openness](#bottles-js-06)
- [7. Manufacturing Intelligence](#bottles-js-07)
- [8. Developing a Programming Aesthetic](#bottles-js-08)
- [9. Reaping the Benefits of Design](#bottles-js-09)

<a id="bottles-js-01"></a>
### 1. Rediscovering Simplicity

**Passages consulted.** Printed pp. 1, 8, 14–15, 21 (PDF pp. 15, 22, 28–29, 35).

**Chapter summary.** The authors compare solutions that all produce the same output. The straightforward one reveals the business cases more clearly than the denser or more general designs. Judge a first implementation by what a reader can learn from it and the cost of changing it.

**Example 1.** Give each result its own visible text.

```js
function saveFeedback(result) {
  switch (result.kind) {
    case "saved": return "Follow-up saved.";
    case "conflict": return "Review the current follow-up.";
    case "rejected": return result.message;
    default: throw new Error(`Unknown save result: ${result.kind}`);
  }
}
```

**Example 2.** Use a small direct decision for the status of an illustrative list.

```js
function listStatus(rows, loading) {
  if (loading) return "Loading follow-ups";
  if (rows.length === 0) return "No open follow-ups";
  return "Open follow-ups";
}
```

**Review question.** Can you name the cases without reading several helpers or decoding a dense expression?

<a id="bottles-js-02"></a>
### 2. Test Driving Shameless Green

**Passages consulted.** Printed pp. 22, 44–46, 50–51 (PDF pp. 36, 58–60, 64–65).

**Chapter summary.** Start with an observable behavior and build a simple implementation in small steps. The book shows how comparing two related implementation results can let the same mistake pass on both sides. State the expected output independently so the test tells a future reader what should happen.

**Example 1.** A pure function test names the empty state and states the expected result. It assumes the listStatus helper above.

```js
import assert from "node:assert/strict";

assert.equal(listStatus([], false), "No open follow-ups");
```

**Example 2.** A conflict example names the user outcome directly. It assumes the saveFeedback helper above.

```js
import assert from "node:assert/strict";

assert.equal(
  saveFeedback({ kind: "conflict" }),
  "Review the current follow-up.",
);
```

**Review question.** Would these assertions still protect the behavior if the function's internal branches were reorganized?

<a id="bottles-js-03"></a>
### 3. Unearthing Concepts

**Passages consulted.** Printed pp. 52, 59–60, 64–65, 73 (PDF pp. 66, 73–74, 78–79, 87).

**Chapter summary.** The authors first rearrange working code to make a new requirement easier. They compare the closest cases, isolate a small difference and name the concept behind it. Keep an existing behavior check in place while making structural changes.

**Example 1.** Start with two concrete cases that differ only by label. These examples assume urgent and routine are the only priority values.

```js
function summaryLine(row) {
  if (row.priority === "urgent") return `${row.patientName} · Urgent`;
  return `${row.patientName} · Routine`;
}
```

**Example 2.** Once the difference is understood, name it. This alternative preserves both results.

```js
function priorityLabel(priority) {
  return priority === "urgent" ? "Urgent" : "Routine";
}

function summaryLine(row) {
  return `${row.patientName} · ${priorityLabel(row.priority)}`;
}
```

**Review question.** Which real cases should change together, and what check would reveal that you combined two different rules?

<a id="bottles-js-04"></a>
### 4. Practicing Horizontal Refactoring

**Passages consulted.** Printed pp. 74, 85–86, 106 (PDF pp. 88, 99–100, 120).

**Chapter summary.** Apply the same small improvement to adjacent variants, keeping working intermediate states. The example introduces a default that makes an intermediate call valid, then removes it when all callers supply the value. The final arrangement reveals concepts that the earlier branch structure obscured.

**Example 1.** A presentation helper uses a default with an intentional meaning for callers that omit it.

```js
function clinicLabel(clinic, { includeCode = false } = {}) {
  if (!includeCode) return clinic.name;
  return `${clinic.name} (${clinic.code})`;
}
```

**Example 2.** Use an explicit input once every caller can say which view it needs.

```js
function appointmentSummary(row, { showTime }) {
  return showTime ? `${row.patientName} · ${row.timeLabel}` : row.patientName;
}

const calendarSummary = appointmentSummary(row, { showTime: true });
const rosterSummary = appointmentSummary(row, { showTime: false });
```

**Review question.** Which callers still rely on the default, and is omission a real supported choice?

<a id="bottles-js-05"></a>
### 5. Separating Responsibilities

**Passages consulted.** Printed pp. 107, 116, 142 (PDF pp. 121, 130, 156).

**Chapter summary.** The authors notice a group of methods repeatedly interpreting the same number and move that behavior together. This helps the caller ask a question without knowing how to interpret the underlying value. In frontend code, keep presentation decisions local and leave authorization and persisted state with their server owners.

**Example 1.** Map a server-provided permission into display state. The browser uses this fact to render the control.

```js
function claimButtonState({ canClaim, claimBlockedReason }) {
  return {
    disabled: !canClaim,
    explanation: canClaim ? null : claimBlockedReason,
  };
}
```

**Example 2.** Derive a local display label from an explicit record field.

```js
function assignmentLabel({ assignedStaffName }) {
  return assignedStaffName ?? "Unassigned";
}
```

**Review question.** If the rule for who may claim a record changes, which file owns that change and which code merely displays the answer?

<a id="bottles-js-06"></a>
### 6. Achieving Openness

**Passages consulted.** Printed pp. 143, 146–148, 175–176 (PDF pp. 157, 160–162, 189–190).

**Chapter summary.** The authors consolidate values that belong together, then move recurring variants behind a shared interface. This lets the new case supply its own behavior at the point where it differs. Their final example distinguishes correcting underlying domain facts from changing only the resulting text.

**Example 1.** Group the view facts that change together for two client outcomes.

```js
function savePresentation(result) {
  switch (result.kind) {
    case "saved":
      return { notice: "Saved", keepDraft: false };
    case "conflict":
      return { notice: "Review the current record", keepDraft: true };
    default:
      throw new Error(`Unsupported result: ${result.kind}`);
  }
}
```

**Example 2.** Apply the presentation result without decoding a formatted message. This fragment assumes the editor owns its draft.

```js
const presentation = savePresentation(saveResult);
setNotice(presentation.notice);
if (!presentation.keepDraft) {
  clearDraft();
}
```

**Review question.** Can the next variant supply its own behavior without adding parallel branches to multiple components?

<a id="bottles-js-07"></a>
### 7. Manufacturing Intelligence

**Passages consulted.** Printed pp. 177, 180, 190 (PDF pp. 191, 194, 204).

**Chapter summary.** The chapter compares ways to choose and construct a variant. A simple selection point makes the available cases visible. More dynamic selection changes the dependencies and adds indirection. Choose the amount of machinery that fits the number of real variants and who owns their selection.

**Example 1.** Select from two known formatters in one place.

```js
function selectFormatter(format, { csv, json }) {
  switch (format) {
    case "csv": return csv;
    case "json": return json;
    default: throw new Error(`Unsupported report format: ${format}`);
  }
}
```

**Example 2.** Pass the selected formatter to a consumer that only needs the format contract.

```js
function renderReport(rows, formatRows) {
  return formatRows(rows);
}

const formatRows = selectFormatter(selectedFormat, formatters);
const reportBody = renderReport(reportRows, formatRows);
```

**Review question.** Does the code that uses a variant need to know how it was selected?

<a id="bottles-js-08"></a>
### 8. Developing a Programming Aesthetic

**Passages consulted.** Printed pp. 191, 196, 206, 228 (PDF pp. 205, 210, 220, 242).

**Chapter summary.** The authors use a sketch of possible variations to understand what needs to change. They identify the role that varies, separate creation from use and examine how much each collaborator needs to know. Treat the additional indirection as a cost to justify against an actual change.

**Example 1.** Make the transport explicit when a save operation has independent callers or needs a substitute at its boundary. This transport accepts an object body and returns the decoded result.

```js
function makeFollowUpSaver({ request }) {
  return function saveFollowUp({ id, note }) {
    return request(`/follow-ups/${id}`, { method: "PATCH", body: { note } });
  };
}
```

**Example 2.** Assemble that operation where the transport is known. The caller still owns draft handling and feedback.

```js
const saveFollowUp = makeFollowUpSaver({ request: requestJson });
const result = await saveFollowUp({ id: followUpId, note: draft });
showSaveResult(result);
```

**Review question.** Does the extraction make a meaningful dependency easier to replace, or does it add a second place to understand one simple call?

<a id="bottles-js-09"></a>
### 9. Reaping the Benefits of Design

**Passages consulted.** Printed pp. 229, 268–269 (PDF pp. 243, 282–283).

**Chapter summary.** The final chapter revisits the tests after the design changes. Tests can explain the domain, reveal coupling and protect behavior across interchangeable collaborators. Choose which guarantees need focused tests and which need a real integration path. Keep the claims from those checks distinct.

**Example 1.** A deterministic substitute checks the request that crosses the transport boundary. This fragment uses makeFollowUpSaver above.

```js
import assert from "node:assert/strict";

const save = makeFollowUpSaver({
  request: async (path, { body }) => {
    assert.equal(path, "/follow-ups/7");
    assert.deepEqual(body, { note: "Called clinic" });
    return { kind: "saved" };
  },
});

assert.deepEqual(await save({ id: 7, note: "Called clinic" }), { kind: "saved" });
```

**Example 2.** A browser-test fragment exercises visible success and reload using an existing server-backed fixture.

```js
await page.getByRole("button", { name: "Save follow-up" }).click();
await expect(page.getByRole("status")).toHaveText("Follow-up saved.");
await page.reload();
await expect(page.getByText("Called clinic", { exact: true })).toBeVisible();
```

**Review question.** Which check verifies what the caller sends, and which check establishes that the real server persisted the update?
