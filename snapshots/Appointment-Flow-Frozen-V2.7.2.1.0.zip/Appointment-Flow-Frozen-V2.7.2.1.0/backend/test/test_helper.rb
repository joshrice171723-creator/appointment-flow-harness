ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"
require_relative "../db/demo_source"

module ClinicTestData
  def seed_clinic(source_id: 1, now: Time.utc(2026, 11, 16, 17))
    office = Office.find_by!(source_id:)
    DemoSource::Clinic.create!(id: source_id, name: office.name)
    patient = DemoSource::Patient.create!(first_name: "Maya", last_name: "Reed",
      birthdate: Date.new(1987, 8, 2), wireless_phone: "512-555-0102",
      email: "maya@example.test", preferred_language: "en")
    appointment = DemoSource::Appointment.create!(clinic_id: source_id, patient_id: patient.id,
      start_at: office.local_time(now).to_date.next_day(7).to_time(:utc).change(hour: 14),
      provider_name: "Dr. Ellis", status: "scheduled", length_minutes: 45)
    [ office, patient, appointment ]
  end
end


class ActiveSupport::TestCase
  setup do
    Office.find_or_create_by!(source_id: 1) { |office| office.assign_attributes(name: "Austin", timezone: "America/Chicago") }
    Office.find_or_create_by!(source_id: 2) { |office| office.assign_attributes(name: "Phoenix", timezone: "America/Phoenix") }
  end
end
