require "test_helper"

class OutreachTest < ActionDispatch::IntegrationTest
  include ClinicTestData

  NOW = Time.utc(2026, 11, 16, 17)

  setup do
    @office, @source_person, @source_appointment = seed_clinic(now: NOW)
    @base = "/api/offices/#{@office.id}"
    @headers = { "X-Demo-Staff" => @office.staff_names.first }
  end

  test "first fake SMS is visible and an idempotent YES confirms exactly the current visit" do
    travel_to NOW do
      assert_difference("Delivery.count", 1) { run_reminders }
      assert_response :success
      assert_equal({ "sent" => 1, "failed" => 0 }, response.parsed_body)
      assert_no_difference("Delivery.count") { run_reminders }
      person = @office.people.sole
      path = "#{@base}/patients/#{person.id}"
      get "#{path}/conversation", params: { channel: "sms" }
      assert_equal [ Delivery.sole.id ], response.parsed_body.fetch("messages").pluck("id")
      answer(person, "YES", "sms-1")
      assert_equal "confirmed", response.parsed_body["result"]
      confirmed_at = @office.visits.sole.confirmed_at
      assert_equal NOW, confirmed_at

      assert_no_difference("Reply.count") { answer(person, "YES", "sms-1") }
      assert_equal "confirmed", response.parsed_body["result"]
      answer(person, "NO", "sms-2")
      assert_equal "review", response.parsed_body["result"]
      assert_equal confirmed_at, @office.visits.sole.confirmed_at
      assert_equal "reply", WorkItem.open.sole.kind
    end

    travel_to NOW + 4.days do
      assert_no_difference("Delivery.count") { run_reminders }
    end
    travel_to NOW + 6.days do
      assert_difference("Delivery.count", 1) { run_reminders }
      assert_equal "final", Delivery.order(:id).last.step
      assert_no_match(/Reply YES/, Delivery.order(:id).last.body)
    end
  end

  test "failed fake SMS records the failure and one backup email confirms with message context" do
    @source_person.update!(wireless_phone: "512-555-0199")
    travel_to(NOW) do
      run_reminders
      assert_equal "failed", Delivery.sole.status
      assert_equal "delivery", WorkItem.open.sole.kind
    end

    travel_to NOW + 1.day do
      run_reminders
      delivery = Delivery.sent.sole
      assert_equal [ "backup", "email" ], [ delivery.step, delivery.channel ]
      person = @office.people.sole
      answer(person, "yes", "email-1", channel: "email", delivery_id: delivery.id)
      assert_equal "confirmed", response.parsed_body["result"]
      assert_equal NOW + 1.day, @office.visits.sole.confirmed_at
      assert_no_difference("Delivery.count") { run_reminders }
    end
  end

  test "source reschedule and an old text route to review before and after refresh" do
    travel_to NOW do
      run_reminders
      person = @office.people.sole
      answer(person, "YES", "old-yes")
      assert_equal "confirmed", response.parsed_body["result"]
      @source_appointment.update!(start_at: @source_appointment.start_at - 5.days)
      answer(person, "YES", "new-yes")
      assert_equal "review", response.parsed_body["result"]
      run_reminders
      visit = @office.visits.sole
      assert_equal 2, visit.revision
      assert_nil visit.confirmed_at
      answer(person, "YES", "ambiguous-version")
      assert_equal "review", response.parsed_body["result"]
      assert_nil visit.reload.confirmed_at
    end
  end

  test "minor and shared phone are held while exact STOP survives refresh" do
    second = DemoSource::Patient.create!(first_name: "Sam", last_name: "Reed",
      birthdate: Date.new(2015, 3, 8), wireless_phone: "(512) 555-0102", preferred_language: "en")
    DemoSource::Appointment.create!(clinic_id: @office.source_id, patient_id: second.id,
      status: "scheduled", start_at: @source_appointment.start_at)
    @source_person.update!(email: nil)

    travel_to NOW do
      assert_no_difference("Delivery.count") { run_reminders }
      assert_equal 2, WorkItem.open.where(kind: "hold").count
      person = @office.people.find_by!(source_id: @source_person.id)
      answer(person, "YES", "shared")
      assert_equal "review", response.parsed_body["result"]
      assert_equal @office.visits.ids.sort, ReplyCandidate.order(:visit_id).pluck(:visit_id)
      assert_equal [ nil, nil ], @office.visits.pluck(:confirmed_at)
      answer(person, "STOP please", "ambiguous-opt-out")
      assert_equal "review", response.parsed_body["result"]
      assert_empty OptOut.all
      answer(person, " stop ", "valid-stop")
      assert_equal "opted_out", response.parsed_body["result"]
      assert_equal "+15125550102", OptOut.sole.recipient
      second.update!(wireless_phone: "512-555-0103")
      assert_no_difference("Delivery.count") { run_reminders }
    end
  end

  test "live clinic contact ownership includes patients outside the dispatch horizon" do
    travel_to NOW do
      @source_person.update!(email: nil)
      run_reminders
      person = @office.people.sole

      distant = DemoSource::Patient.create!(first_name: "Casey", last_name: "Test",
        birthdate: Date.new(1987, 8, 2), wireless_phone: "1 (512) 555-0102", preferred_language: "en")
      DemoSource::Appointment.create!(clinic_id: @office.source_id, patient_id: distant.id,
        start_at: @source_appointment.start_at + 20.days, status: "scheduled")

      answer(person, "YES", "shared-after-send")
      assert_equal "review", response.parsed_body["result"]
      assert_nil @office.visits.sole.confirmed_at

      @source_appointment.update!(start_at: @source_appointment.start_at - 4.days)
      assert_no_difference("Delivery.count") { run_reminders }
      assert WorkItem.open.where(office: @office, kind: "hold").exists?
      assert_equal [ person.id ], @office.people.ids
    end
  end

  test "a source phone replaced between replica reads cannot receive a fake text" do
    travel_to NOW do
      @source_person.update!(email: nil)
      changed = false
      change_phone_after_snapshot = lambda do |event|
        if !changed && event.payload[:name] == "Pms::Patient Load"
          changed = true
          @source_person.update!(wireless_phone: "512-555-0170")
        end
      end

      ActiveSupport::Notifications.subscribed(change_phone_after_snapshot, "sql.active_record") do
        assert_no_difference("Delivery.count") { run_reminders }
      end
      assert_response :success
      assert changed, "The source contact must change after the snapshot read"
      assert_equal "512-555-0170", @source_person.reload.wireless_phone
      assert_equal "hold", WorkItem.open.sole.kind
      assert_difference("Delivery.count", 1) { run_reminders }
      assert_equal "+15125550170", Delivery.sole.recipient
    end
  end

  test "a new reminder for a moved slot still cannot disambiguate a bare SMS after the old message ages out" do
    travel_to(NOW) { run_reminders }
    @source_appointment.update!(start_at: @source_appointment.start_at + 14.days)
    travel_to(NOW + 14.days) do
      assert_difference("Delivery.count", 1) { run_reminders }
      assert_equal [ 1, 2 ], Delivery.order(:id).pluck(:revision)
      answer(@office.people.sole, "YES", "stale-thread")
      assert_equal "review", response.parsed_body["result"]
      assert_nil @office.visits.sole.confirmed_at
    end
  end

  test "breaking the old appointment and creating a replacement leaves the old visit ineligible" do
    travel_to NOW do
      run_reminders
      old = @office.visits.sole
      @source_appointment.update!(status: "broken")
      replacement = DemoSource::Appointment.create!(clinic_id: @office.source_id, patient_id: @source_person.id,
        start_at: @source_appointment.start_at + 1.hour, status: "scheduled")
      assert_difference("Delivery.count", 1) { run_reminders }
      assert_equal "broken", old.reload.source_status
      replacement_visit = @office.visits.find_by!(source_id: replacement.id)
      assert_equal [ old.id, replacement_visit.id ], Delivery.order(:id).pluck(:visit_id)
      answer(@office.people.sole, "YES", "replacement-ambiguous")
      assert_equal "review", response.parsed_body["result"]
      assert_nil replacement_visit.reload.confirmed_at
    end
  end

  test "outside the sending window and at or after start no dispatch occurs" do
    travel_to NOW - 3.hours do
      assert_no_difference("Delivery.count") { run_reminders }
    end
    travel_to NOW do
      run_reminders
    end
    travel_to Time.utc(2026, 11, 23, 20) do
      assert_no_difference("Delivery.count") { run_reminders }
      answer(@office.people.sole, "YES", "late")
      assert_equal "review", response.parsed_body["result"]
      assert_nil @office.visits.sole.confirmed_at
    end
  end

  test "empty or incomplete snapshot prevents further sends and leaves the prior visit" do
    travel_to NOW do
      run_reminders
      visit_id = @office.visits.sole.id
      @source_appointment.destroy!
      assert_no_difference("Delivery.count") { run_reminders }
      assert_response :service_unavailable
      assert_equal visit_id, @office.visits.sole.id
    end
  end

  test "wrong clinic cannot read or mutate the patient inbox" do
    travel_to NOW do
      run_reminders
      person = @office.people.sole
      other = Office.find_by!(source_id: 2)
      path = "/api/offices/#{other.id}/patients/#{person.id}"
      get "#{path}/conversation", params: { channel: "sms" }
      assert_response :not_found
      assert_no_difference("Reply.count") do
        post "#{path}/replies", params: { channel: "sms", body: "YES", event_key: "cross-clinic" }, as: :json
      end
      assert_response :not_found
    end
  end

  private

  def run_reminders
    post "#{@base}/reminder_runs", headers: @headers
  end

  def answer(person, body, event_key, channel: "sms", delivery_id: nil)
    post "#{@base}/patients/#{person.id}/replies", params: { channel:, body:, event_key:, delivery_id: }, as: :json
    assert_response :success
  end
end
