require "test_helper"

class SynchronizationsTest < ActionDispatch::IntegrationTest
  include ClinicTestData

  test "front desk refreshes its replica and protects a tracked visit if the source disappears" do
    travel_to Time.utc(2026, 11, 16, 17) do
      office, _patient, appointment = seed_clinic
      path = "/api/offices/#{office.id}/synchronization"
      headers = { "X-Demo-Staff" => office.staff_names.first }

      post path, headers: { "X-Demo-Staff" => "Morgan" }
      assert_response :not_found
      assert_empty office.visits

      post path, headers: headers
      assert_response :success
      visit = office.visits.sole
      assert_equal Time.utc(2026, 11, 23, 20), visit.starts_at
      assert_equal appointment.start_at, Pms::Appointment.find(appointment.id).start_at
      assert_raises(ActiveRecord::ReadOnlyRecord) { Pms::Appointment.find(appointment.id).update!(status: "broken") }
      synced_at = office.reload.synced_at

      appointment.destroy!
      post path, headers: headers
      assert_response :service_unavailable
      assert_match(/missing tracked/, response.parsed_body["error"])
      assert_equal synced_at, office.reload.synced_at
      assert_equal visit.id, office.visits.sole.id
    end
  end

  test "a failed replica query reports failure without changing the last good snapshot" do
    travel_to Time.utc(2026, 11, 16, 17) do
      office, = seed_clinic
      path = "/api/offices/#{office.id}/synchronization"
      headers = { "X-Demo-Staff" => office.staff_names.first }
      post path, headers: headers
      assert_response :success
      visit = office.visits.sole
      synced_at = office.reload.synced_at
      ApplicationRecord.connection.execute("ALTER TABLE pms.appointments RENAME TO unavailable_appointments")

      post path, headers: headers
      assert_response :service_unavailable
      assert_equal "PMS schema is unavailable.", office.reload.sync_error
      assert_equal synced_at, office.synced_at
      assert_equal visit.id, office.visits.sole.id
    end
  end

  test "ambiguous and nonexistent Austin wall times cannot be scheduled for outreach" do
    office = Office.find_by!(source_id: 1)
    assert_nil office.interpret_wall_time(Time.utc(2026, 3, 8, 2, 30))
    assert_nil office.interpret_wall_time(Time.utc(2026, 11, 1, 1, 30))
    assert_equal Time.utc(2026, 11, 1, 7, 30),
      Office.find_by!(source_id: 2).interpret_wall_time(Time.utc(2026, 11, 1, 0, 30))
  end
end
