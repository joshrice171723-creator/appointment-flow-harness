require "test_helper"

class ConcurrentRemindersTest < ActiveSupport::TestCase
  self.use_transactional_tests = false

  test "parallel batches on separate connections store a logical delivery once" do
    now = Time.utc(2026, 11, 16, 17)
    office = Office.create!(source_id: 571, name: "Concurrency Test", timezone: "America/Chicago")
    clinic = DemoSource::Clinic.create!(id: office.source_id, name: office.name)
    patient = DemoSource::Patient.create!(first_name: "Demo", last_name: "Concurrent",
      birthdate: Date.new(1990, 3, 12), wireless_phone: "512-555-0160", preferred_language: "en")
    appointment = DemoSource::Appointment.create!(clinic_id: clinic.id, patient_id: patient.id,
      start_at: Time.utc(2026, 11, 23, 14), status: "scheduled")

    ready = Queue.new
    begin_batch = Queue.new
    workers = Array.new(2) do
      Thread.new do
        ApplicationRecord.connection_pool.with_connection do
          independent = Office.find(office.id)
          ready << true
          begin_batch.pop
          ReminderBatch.new(independent, now:).call
        end
      end
    end
    2.times { ready.pop(timeout: 15) }
    2.times { begin_batch << true }
    results = workers.map(&:value)

    assert_equal [ 0, 1 ], results.pluck(:sent).sort
    delivery = Delivery.where(office:).sole
    assert_equal [ 1, "initial" ], [ delivery.revision, delivery.step ]
  ensure
    if office&.persisted?
      Delivery.where(office:).delete_all
      WorkItem.where(office:).delete_all
      Visit.where(office:).delete_all
      Person.where(office:).delete_all
      office.destroy!
    end
    appointment&.destroy!
    patient&.destroy!
    clinic&.destroy!
  end
end
