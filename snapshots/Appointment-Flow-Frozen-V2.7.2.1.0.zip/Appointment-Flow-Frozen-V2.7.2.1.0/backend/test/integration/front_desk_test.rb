require "test_helper"
require_relative "../../../quality/rails_workload_probe"

class FrontDeskTest < ActionDispatch::IntegrationTest
  include ClinicTestData

  NOW = Time.utc(2026, 11, 16, 17)

  setup do
    @office, @source_person, @source_appointment = seed_clinic(now: NOW)
    @other, _other_person, _other_appointment = seed_clinic(source_id: 2, now: NOW)
    @headers = { "X-Demo-Staff" => @office.staff_names.first }
    @base = "/api/offices/#{@office.id}"
  end

  test "appointment day, total counts, exact bound, and reply filters are clinic scoped" do
    travel_to NOW do
      assert ClinicRefresh.new(@office).call
      assert ClinicRefresh.new(@other).call
      visit = @office.visits.sole
      params = { date: visit.local_date.iso8601, filter: "all" }
      get "/api/offices"
      assert_response :success

      baseline = measure_read(params)
      expected = response.parsed_body
      assert_equal [ visit.id ], expected.fetch("visits").pluck("id")
      assert_equal({ "all" => 1, "confirmed" => 0, "unconfirmed" => 1, "review" => 0 }, expected["counts"])

      add_visits(400, @office, day: visit.local_date + 10, source_base: 10_000)
      add_visits(400, @other, day: visit.local_date, source_base: 20_000)
      grown = measure_read(params)
      assert_equal expected, response.parsed_body
      %i[database_statements read_rows instantiated_records response_bytes].each { |key| assert_equal baseline[key], grown[key], key.to_s }
      report_metric("appointments baseline", baseline)
      report_metric("appointments unrelated growth", grown)

      add_visits(52, @office, day: visit.local_date, source_base: 30_000, confirmed: true)
      get "#{@base}/appointments", params: params.merge(filter: "confirmed"), headers: @headers
      assert_equal 53, response.parsed_body.dig("counts", "all")
      assert_equal 52, response.parsed_body.dig("counts", "confirmed")
      ids = response.parsed_body.fetch("visits").pluck("id")
      assert_equal 50, ids.length
      get "#{@base}/appointments", params: params.merge(filter: "confirmed", page: 2), headers: @headers
      assert_equal 2, response.parsed_body.fetch("visits").length
      assert_empty ids & response.parsed_body.fetch("visits").pluck("id")

      reply = Reply.create!(office: @office, person: visit.person, channel: "sms", event_key: "review",
        result: "review", recipient: visit.person.sms_recipient, body: "Which time?", received_at: NOW)
      ReplyCandidate.create!(visit:, reply:, revision: visit.revision)
      get "#{@base}/appointments", params: params.merge(filter: "review"), headers: @headers
      assert_equal [ visit.id ], response.parsed_body.fetch("visits").pluck("id")
      assert_equal true, response.parsed_body["visits"].sole["reply_review"]
    end
  end

  test "staff claims work, records attempted contact, and confirms once through normal routes" do
    travel_to NOW do
      @source_appointment.update!(start_at: @source_appointment.start_at - 6.days)
      post "#{@base}/reminder_runs", headers: @headers
      assert_response :success
      item = WorkItem.where(office: @office, kind: "no_reply").sole
      path = "#{@base}/work_items/#{item.id}"
      get "#{@base}/work_items", params: { search: "reed", kind: "no_reply" }, headers: @headers
      assert_response :success
      assert_equal [ item.id ], response.parsed_body.dig("queues", "attention", "items").pluck("id")

      patch "#{path}/assignment", headers: @headers, as: :json
      assert_response :success
      patch "#{path}/assignment", headers: { "X-Demo-Staff" => @office.staff_names.last }, as: :json
      assert_response :conflict
      other_path = "/api/offices/#{@other.id}/work_items/#{item.id}"
      patch "#{other_path}/assignment", headers: { "X-Demo-Staff" => @other.staff_names.first }, as: :json
      assert_response :not_found

      post "#{path}/follow_ups", params: { outcome: "confirmed", note: "", event_key: "bad" }, headers: @headers, as: :json
      assert_response :unprocessable_entity
      assert_nil item.reload.resolved_at
      assert_empty StaffEntry.all
      params = { outcome: "attempted", note: "Left a callback number.", event_key: "first" }
      post "#{path}/follow_ups", params:, headers: @headers, as: :json
      assert_response :success
      assert_nil item.reload.resolved_at

      params = { outcome: "confirmed", note: "Patient verified the visit time.", event_key: "second" }
      assert_difference("StaffEntry.count", 1) do
        2.times { post "#{path}/follow_ups", params:, headers: @headers, as: :json }
      end
      assert_response :success
      assert_equal NOW, item.reload.resolved_at
      assert_equal NOW, item.visit.confirmed_at
      assert_no_difference("WorkItem.count") do
        post "#{@base}/work_items", params: { visit_id: item.visit_id }, headers: @headers, as: :json
      end
      assert_response :conflict

      get "#{@base}/patients/#{item.person_id}", headers: @headers
      assert_response :success
      assert_equal [ "confirmed", "attempted" ], response.parsed_body.fetch("activity").pluck("action")
      get "/api/offices/#{@other.id}/patients/#{item.person_id}", headers: { "X-Demo-Staff" => @other.staff_names.first }
      assert_response :not_found
    end
  end

  test "contact correction unblocks outreach and later PMS changes create a conflict without overwriting it" do
    travel_to NOW do
      @source_person.update!(birthdate: nil, email: nil)
      post "#{@base}/reminder_runs", headers: @headers
      assert_response :success
      assert_empty Delivery.all
      person = @office.people.sole
      assert_equal "hold", WorkItem.open.sole.kind

      path = "#{@base}/patients/#{person.id}/contact_verification"
      params = { field: "birthdate", value: "1987-08-02", event_key: "birthdate-correction" }
      assert_difference("StaffEntry.count", 1) do
        2.times { patch path, params:, headers: @headers, as: :json }
      end
      assert_response :success
      assert_nil @source_person.reload.birthdate
      post "#{@base}/reminder_runs", headers: @headers
      assert_response :success
      assert_equal "sent", Delivery.sole.status
      assert_empty WorkItem.open

      @source_person.update!(birthdate: Date.new(2015, 12, 10))
      post "#{@base}/reminder_runs", headers: @headers
      assert_response :success
      assert person.reload.contact_conflict?
      assert_equal "1987-08-02", person.contact("birthdate")
      assert_equal "hold", WorkItem.open.sole.kind
    end
  end

  test "leadership reports source completion and exposes only aggregate fields for every clinic" do
    travel_to NOW do
      @source_appointment.update!(start_at: @source_appointment.start_at - 8.days)
      ClinicRefresh.new(@office).call
      austin_visit = @office.visits.sole
      austin_visit.update!(confirmed_at: NOW - 2.days)
      get "/api/leadership_report", params: { month: "2026-11" }
      assert_response :success
      austin = response.parsed_body.fetch("clinics").find { |clinic| clinic["clinic"] == "Austin" }
      assert_equal 0, austin.dig("outcomes", "completed")
      assert_equal 1, austin.dig("outcomes", "unknown")

      @source_appointment.update!(status: "complete")
      ClinicRefresh.new(@office).call
      assert austin_visit.reload.confirmed_at
      get "/api/leadership_report", params: { month: "2026-11" }
      assert_response :success
      payload = response.parsed_body
      assert_equal %w[Austin Phoenix], payload.fetch("clinics").pluck("clinic")
      assert_equal %w[clinic messages outcomes recorded work_open work_resolved], payload.fetch("clinics").first.keys.sort
      assert_equal 1, payload.fetch("clinics").first.dig("outcomes", "completed")
      assert_equal %w[2026-10 2026-09], payload.fetch("history").pluck("month")
      assert_no_match(/Maya|Reed|example\.test|birthdate|recipient|patient|provider|note|message_body/i, response.body)
    end
  end

  private

  def add_visits(count, office, day:, source_base:, confirmed: false)
    person = office.people.sole
    wall = day.to_time(:utc).change(hour: 15)
    Visit.insert_all!(Array.new(count) do |index|
      { office_id: office.id, person_id: person.id, source_id: source_base + index, wall_time: wall, local_date: day,
        source_status: "scheduled", starts_at: office.interpret_wall_time(wall), confirmed_at: confirmed ? NOW : nil }
    end)
  end

  def measure_read(params)
    ApplicationRecord.clear_query_caches_for_current_thread
    _, metrics = RailsWorkloadProbe.measure do
      ApplicationRecord.uncached { get "#{@base}/appointments", params:, headers: @headers }
    end
    assert_response :success
    metrics.merge(response_bytes: response.body.bytesize)
  end

  def report_metric(label, metrics)
    puts "#{label}: #{metrics.to_json}" if ENV["APEX_WORKLOAD"]
  end
end
