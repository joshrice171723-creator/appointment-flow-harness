require "test_helper"
require_relative "../../../quality/rails_workload_probe"

class ReminderWorkloadTest < ActionDispatch::IntegrationTest
  include ClinicTestData

  NOW = Time.utc(2026, 11, 16, 17)

  test "real reminder caller keeps irrelevant work bounded and retry writes no extra delivery" do
    travel_to NOW do
      office, source_person, appointment = seed_clinic(now: NOW)
      other, other_person, = seed_clinic(source_id: 2, now: NOW)
      @path = "/api/offices/#{office.id}/reminder_runs"
      @headers = { "X-Demo-Staff" => office.staff_names.first }

      first = measure_run(sent: 1)
      initial_id = Delivery.sole.id
      small_retry = measure_run(sent: 0)
      add_source_visits(300, clinic: office, patient: source_person, at: appointment.start_at + 25.days)
      add_source_visits(300, clinic: other, patient: other_person, at: appointment.start_at)
      grown_retry = measure_run(sent: 0)
      %i[database_statements read_rows instantiated_records affected_rows].each do |key|
        assert_equal small_retry[key], grown_retry[key], key.to_s
      end
      assert_equal [ initial_id ], Delivery.ids

      historical_people = DemoSource::Patient.insert_all!(Array.new(180) do |index|
        { first_name: "Historical", last_name: "Demo #{index}", wireless_phone: nil,
          email: "history.#{index}@example.test", preferred_language: "en" }
      end, returning: [ :id ]).rows.flatten
      DemoSource::Appointment.insert_all!(historical_people.map do |patient_id|
        { clinic_id: office.source_id, patient_id:, start_at: appointment.start_at - 1.month, status: "complete" }
      end)
      owner_growth = measure_run(sent: 0)
      assert_equal small_retry[:database_statements], owner_growth[:database_statements]
      assert_equal small_retry[:read_rows] + historical_people.size, owner_growth[:read_rows]
      assert_equal small_retry[:instantiated_records], owner_growth[:instantiated_records]
      assert_equal [ initial_id ], Delivery.ids

      15.times do |index|
        patient = DemoSource::Patient.create!(first_name: "Demo", last_name: "Patient #{index}",
          birthdate: Date.new(1991, 6, 12), email: "workload.#{index}@example.test", preferred_language: "en")
        add_source_visits(1, clinic: office, patient:, at: appointment.start_at)
      end
      large = measure_run(sent: 15)
      repeated = measure_run(sent: 0)
      assert_equal 16, Delivery.count
      assert_equal 16, Delivery.distinct.count(:visit_id)
      assert_operator repeated[:direct_write_statements], :<, large[:direct_write_statements]
      if ENV["APEX_WORKLOAD"]
        { first:, small_retry:, grown_retry:, owner_growth:, large:, repeated: }.each do |label, result|
          puts "reminder #{label}: #{result.to_json}"
        end
      end
    end
  end

  test "prior delivery revisions do not grow current reminder work" do
    travel_to NOW do
      office, = seed_clinic(now: NOW)
      @path = "/api/offices/#{office.id}/reminder_runs"
      @headers = { "X-Demo-Staff" => office.staff_names.first }
      measure_run(sent: 1)
      visit = office.visits.sole
      delivery = Delivery.sole
      visit.update!(revision: 51)
      delivery.update!(revision: 51)

      baseline = measure_run(sent: 0)
      Delivery.insert_all!(Array.new(50) do |index|
        delivery.attributes.except("id").merge("revision" => index + 1)
      end)
      grown = measure_run(sent: 0)
      %i[database_statements read_rows instantiated_records affected_rows].each do |key|
        assert_equal baseline[key], grown[key], key.to_s
      end
      assert_equal [ delivery.id ], Delivery.where(revision: 51).ids
      assert_equal 51, Delivery.count
      puts "reminder prior revisions: #{grown.to_json}" if ENV["APEX_WORKLOAD"]
    end
  end

  test "a fake transport fault after refresh rolls back the clinic snapshot and all staged effects" do
    office, _source_person, _ = seed_clinic(now: NOW)
    error = Class.new(StandardError)
    transport = Object.new
    transport.define_singleton_method(:deliver) do |**|
      raise error, "injected transport fault"
    end

    caught = assert_raises(error) { ReminderBatch.new(office, now: NOW, transport:).call }
    assert_equal "injected transport fault", caught.message
    assert_nil office.reload.synced_at
    assert_empty office.people
    assert_empty office.visits
    assert_empty Delivery.all
    assert_empty WorkItem.all
    assert_equal({ sent: 1, failed: 0 }, ReminderBatch.new(office, now: NOW).call)
  end

  private

  def measure_run(sent:)
    result, metrics = RailsWorkloadProbe.measure do
      ApplicationRecord.uncached { post @path, headers: @headers, as: :json }
      response.parsed_body
    end
    assert_response :success
    assert_equal({ "sent" => sent, "failed" => 0 }, result)
    metrics.merge(response_bytes: response.body.bytesize)
  end

  def add_source_visits(count, clinic:, patient:, at:)
    DemoSource::Appointment.insert_all!(Array.new(count) do
      { clinic_id: clinic.source_id, patient_id: patient.id, start_at: at, status: "scheduled" }
    end)
  end
end
