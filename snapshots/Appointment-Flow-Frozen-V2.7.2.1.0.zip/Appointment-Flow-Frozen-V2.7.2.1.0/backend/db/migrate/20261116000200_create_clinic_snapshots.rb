class CreateClinicSnapshots < ActiveRecord::Migration[8.1]
  def change
    create_table :offices do |t|
      t.bigint :source_id, null: false, index: { unique: true }
      t.string :name, null: false
      t.string :timezone, null: false
      t.datetime :synced_at
      t.string :sync_error
    end

    create_table :people do |t|
      t.references :office, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.string :first_name, null: false
      t.string :last_name, null: false
      t.string :search_name, null: false
      t.date :birthdate
      t.string :wireless_phone
      t.string :email
      t.string :preferred_language
      t.bigint :guarantor_id
      t.jsonb :corrections, null: false, default: {}
      t.string :sms_recipient
      t.string :email_recipient
      t.index %i[office_id source_id], unique: true
      t.index %i[office_id sms_recipient]
      t.index %i[office_id email_recipient]
    end

    create_table :visits do |t|
      t.references :office, null: false, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.bigint :source_id, null: false, index: { unique: true }
      t.date :local_date, null: false
      t.datetime :wall_time, null: false
      t.datetime :starts_at
      t.string :provider_name
      t.integer :length_minutes
      t.string :source_status, null: false
      t.integer :revision, null: false, default: 1
      t.datetime :confirmed_at
      t.string :disposition
      t.index %i[office_id local_date id]
      t.index %i[office_id source_status starts_at]
    end
  end
end
