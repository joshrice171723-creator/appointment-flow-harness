class ScopeVisitsByClinic < ActiveRecord::Migration[8.1]
  def change
    remove_index :visits, :source_id, unique: true
    add_index :visits, %i[office_id source_id], unique: true
    add_index :visits, %i[office_id local_date wall_time id]
  end
end
