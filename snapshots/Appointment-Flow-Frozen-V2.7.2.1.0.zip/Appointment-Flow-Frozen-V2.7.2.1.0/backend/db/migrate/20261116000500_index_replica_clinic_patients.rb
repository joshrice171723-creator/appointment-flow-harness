class IndexReplicaClinicPatients < ActiveRecord::Migration[8.1]
  def change
    add_index "pms.appointments", %i[clinic_id patient_id]
  end
end
