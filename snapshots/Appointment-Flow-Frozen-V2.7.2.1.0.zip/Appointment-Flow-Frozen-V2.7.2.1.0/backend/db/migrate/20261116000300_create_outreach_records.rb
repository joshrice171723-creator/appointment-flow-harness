class CreateOutreachRecords < ActiveRecord::Migration[8.1]
  def change
    add_column :people, :correction_baselines, :jsonb, null: false, default: {}
    add_column :people, :search_last_name, :string, null: false, default: ""
    add_index :people, %i[office_id search_name]
    add_index :people, %i[office_id search_last_name]

    create_table :deliveries do |t|
      t.references :office, null: false, foreign_key: true
      t.references :visit, null: false, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.integer :revision, null: false
      t.string :step, null: false
      t.string :channel, null: false
      t.string :recipient, null: false
      t.string :status, null: false
      t.text :body, null: false
      t.datetime :attempted_at, null: false
      t.index %i[visit_id revision step], unique: true
      t.index %i[office_id channel recipient attempted_at], name: "index_delivery_conversation"
      t.index %i[person_id channel attempted_at], name: "index_delivery_history"
    end

    create_table :opt_outs do |t|
      t.references :office, null: false, foreign_key: true
      t.string :channel, null: false
      t.string :recipient, null: false
      t.datetime :created_at, null: false
      t.index %i[office_id channel recipient], unique: true
    end

    create_table :replies do |t|
      t.references :office, null: false, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.references :delivery, foreign_key: true
      t.string :channel, null: false
      t.string :recipient, null: false
      t.string :event_key, null: false
      t.text :body, null: false
      t.string :result, null: false
      t.datetime :received_at, null: false
      t.index %i[office_id event_key], unique: true
      t.index %i[person_id channel received_at]
    end

    create_table :reply_candidates do |t|
      t.references :reply, null: false, foreign_key: true
      t.references :visit, null: false, foreign_key: true
      t.integer :revision, null: false
      t.index %i[reply_id visit_id], unique: true
    end

    create_table :work_items do |t|
      t.references :office, null: false, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.references :visit, foreign_key: true
      t.references :reply, foreign_key: true
      t.integer :revision
      t.string :work_key, null: false
      t.string :kind, null: false
      t.string :detail, null: false
      t.string :assigned_to
      t.datetime :resolved_at
      t.timestamps
      t.index %i[office_id work_key], unique: true
      t.index %i[office_id resolved_at assigned_to id], name: "index_work_queue"
    end

    create_table :staff_entries do |t|
      t.references :office, null: false, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.references :work_item, foreign_key: true
      t.string :event_key, null: false
      t.string :author, null: false
      t.string :action_name, null: false
      t.text :note, null: false
      t.jsonb :details, null: false, default: {}
      t.datetime :created_at, null: false
      t.index %i[office_id event_key], unique: true
      t.index %i[person_id created_at]
    end
  end
end
