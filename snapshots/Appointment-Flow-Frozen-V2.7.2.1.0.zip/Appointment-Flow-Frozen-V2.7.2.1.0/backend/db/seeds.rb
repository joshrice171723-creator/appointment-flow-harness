require_relative "demo_source"

names = [
  [ "Mia", "Ramos" ], [ "Leo", "Vega" ], [ "Nora", "Bell" ], [ "Ember", "Lane" ],
  [ "Felix", "Cole" ], [ "Nova", "Gray" ], [ "Elias", "Quinn" ], [ "Thea", "Fox" ],
  [ "Iris", "Soto" ], [ "Luca", "Reed" ], [ "Ari", "Stone" ], [ "Wren", "Lake" ]
]
directory = {
  1 => { name: "Austin", timezone: "America/Chicago", state: "TX", area: 512 },
  2 => { name: "Phoenix", timezone: "America/Phoenix", state: "AZ", area: 602 }
}

directory.each do |id, settings|
  office = Office.find_or_create_by!(source_id: id) do |record|
    record.assign_attributes(settings.slice(:name, :timezone))
  end
  today = office.local_time(Time.current).to_date
  first_batch_day = today.prev_day(2)
  replica_exists = DemoSource::Clinic.exists?(id)

  unless replica_exists
    DemoSource::Clinic.transaction do
      DemoSource::Clinic.create!(id:, name: settings[:name], city: settings[:name], state: settings[:state])
      people = names.each_with_index.map do |(first_name, last_name), index|
        first_name = %w[Owen Isla Rowan June Milo Eden Caleb Alma Elio Nia Remy Sage][index] if id == 2
        phone = format("%d-555-01%02d", settings[:area], index + 10)
        phone = nil if index == 1
        phone = "#{settings[:area]}-555-0199" if index == 2
        email = "#{first_name.downcase}.#{last_name.downcase}.#{id}@example.test" unless index == 5
        phone = "not on file" if index == 5
        DemoSource::Patient.create!(first_name:, last_name:, wireless_phone: phone, email:,
          birthdate: index == 3 ? today.years_ago(12) : Date.new(1984 + index, 4, 14),
          preferred_language: index == 1 ? "es" : "en")
      end
      people.each_with_index do |person, index|
        offset = [ 5, 5, 5, 1, 1, 1, 0, 0, 2, 2, 3, 6 ].fetch(index)
        DemoSource::Appointment.create!(clinic_id: id, patient_id: person.id,
          start_at: today.next_day(offset).to_time(:utc).change(hour: 9 + index % 7, min: index.odd? ? 30 : 0),
          status: "scheduled", length_minutes: 30 + 15 * (index % 3), provider_name: index.even? ? "Dr. Ellis" : "Dr. Grant")
      end
      [ -2, -1, 0 ].each do |offset|
        month = today.beginning_of_month.next_month(offset)
        people.each_with_index do |person, index|
          date = [ month.next_day(index * 2), today.prev_day(1) ].min
          status = (index + id) % 4 == 0 ? "broken" : "complete"
          DemoSource::Appointment.create!(clinic_id: id, patient_id: person.id, start_at: date.to_time(:utc).change(hour: 9 + index % 7),
            status:, provider_name: "Dr. Ellis", length_minutes: 45)
        end
      end
    end

    ClinicRefresh.new(office).call
    [ first_batch_day, first_batch_day.next_day ].each do |day|
      at = office.interpret_wall_time(day.to_time(:utc).change(hour: 11))
      ReminderBatch.new(office, now: at).call
    end

    # Exercise the same write paths used by the staff application for demo history.
    attempted = WorkItem.where(office:, kind: "no_reply").open.order(:id).first
    if attempted
      attempted.update!(assigned_to: office.staff_names.first)
      StaffFollowUp.new(office, author: office.staff_names.first, item_id: attempted.id, outcome: "attempted",
        note: "Called and left the clinic callback number.", event_key: "seed-attempt-#{id}", visit_ids: []).call
    end
  end

  ClinicRefresh.new(office).call
end
