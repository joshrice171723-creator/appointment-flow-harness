module DemoSource
  class Clinic < ApplicationRecord
    self.table_name = "pms.clinics"
  end

  class Patient < ApplicationRecord
    self.table_name = "pms.patients"
  end

  class Appointment < ApplicationRecord
    self.table_name = "pms.appointments"
  end
end
