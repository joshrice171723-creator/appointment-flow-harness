SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pms; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pms;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.appointments (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    provider_name text,
    start_at timestamp(6) without time zone NOT NULL,
    length_minutes integer,
    procedure_note text,
    status text NOT NULL,
    updated_at timestamp(6) without time zone
);


--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.appointments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.appointments_id_seq OWNED BY pms.appointments.id;


--
-- Name: clinics; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.clinics (
    id bigint NOT NULL,
    name text NOT NULL,
    address_line text,
    city text,
    state character(2),
    phone text
);


--
-- Name: clinics_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.clinics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinics_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.clinics_id_seq OWNED BY pms.clinics.id;


--
-- Name: patients; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.patients (
    id bigint NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    birthdate date,
    wireless_phone text,
    email text,
    preferred_language text,
    guarantor_id bigint
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.patients_id_seq OWNED BY pms.patients.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deliveries (
    id bigint NOT NULL,
    office_id bigint NOT NULL,
    visit_id bigint NOT NULL,
    person_id bigint NOT NULL,
    revision integer NOT NULL,
    step character varying NOT NULL,
    channel character varying NOT NULL,
    recipient character varying NOT NULL,
    status character varying NOT NULL,
    body text NOT NULL,
    attempted_at timestamp(6) without time zone NOT NULL
);


--
-- Name: deliveries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deliveries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deliveries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deliveries_id_seq OWNED BY public.deliveries.id;


--
-- Name: offices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offices (
    id bigint NOT NULL,
    source_id bigint NOT NULL,
    name character varying NOT NULL,
    timezone character varying NOT NULL,
    synced_at timestamp(6) without time zone,
    sync_error character varying
);


--
-- Name: offices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.offices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: offices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.offices_id_seq OWNED BY public.offices.id;


--
-- Name: opt_outs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opt_outs (
    id bigint NOT NULL,
    office_id bigint NOT NULL,
    channel character varying NOT NULL,
    recipient character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: opt_outs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.opt_outs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: opt_outs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.opt_outs_id_seq OWNED BY public.opt_outs.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.people (
    id bigint NOT NULL,
    office_id bigint NOT NULL,
    source_id bigint NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    search_name character varying NOT NULL,
    birthdate date,
    wireless_phone character varying,
    email character varying,
    preferred_language character varying,
    guarantor_id bigint,
    corrections jsonb DEFAULT '{}'::jsonb NOT NULL,
    sms_recipient character varying,
    email_recipient character varying,
    correction_baselines jsonb DEFAULT '{}'::jsonb NOT NULL,
    search_last_name character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.people_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.people_id_seq OWNED BY public.people.id;


--
-- Name: replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.replies (
    id bigint NOT NULL,
    office_id bigint NOT NULL,
    person_id bigint NOT NULL,
    delivery_id bigint,
    channel character varying NOT NULL,
    recipient character varying NOT NULL,
    event_key character varying NOT NULL,
    body text NOT NULL,
    result character varying NOT NULL,
    received_at timestamp(6) without time zone NOT NULL
);


--
-- Name: replies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.replies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: replies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.replies_id_seq OWNED BY public.replies.id;


--
-- Name: reply_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_candidates (
    id bigint NOT NULL,
    reply_id bigint NOT NULL,
    visit_id bigint NOT NULL,
    revision integer NOT NULL
);


--
-- Name: reply_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_candidates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_candidates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_candidates_id_seq OWNED BY public.reply_candidates.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: staff_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_entries (
    id bigint NOT NULL,
    office_id bigint NOT NULL,
    person_id bigint NOT NULL,
    work_item_id bigint,
    event_key character varying NOT NULL,
    author character varying NOT NULL,
    action_name character varying NOT NULL,
    note text NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: staff_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_entries_id_seq OWNED BY public.staff_entries.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    office_id bigint NOT NULL,
    person_id bigint NOT NULL,
    source_id bigint NOT NULL,
    local_date date NOT NULL,
    wall_time timestamp(6) without time zone NOT NULL,
    starts_at timestamp(6) without time zone,
    provider_name character varying,
    length_minutes integer,
    source_status character varying NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    confirmed_at timestamp(6) without time zone,
    disposition character varying
);


--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_items (
    id bigint NOT NULL,
    office_id bigint NOT NULL,
    person_id bigint NOT NULL,
    visit_id bigint,
    reply_id bigint,
    revision integer,
    work_key character varying NOT NULL,
    kind character varying NOT NULL,
    detail character varying NOT NULL,
    assigned_to character varying,
    resolved_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: work_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_items_id_seq OWNED BY public.work_items.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments ALTER COLUMN id SET DEFAULT nextval('pms.appointments_id_seq'::regclass);


--
-- Name: clinics id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics ALTER COLUMN id SET DEFAULT nextval('pms.clinics_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients ALTER COLUMN id SET DEFAULT nextval('pms.patients_id_seq'::regclass);


--
-- Name: deliveries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries ALTER COLUMN id SET DEFAULT nextval('public.deliveries_id_seq'::regclass);


--
-- Name: offices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offices ALTER COLUMN id SET DEFAULT nextval('public.offices_id_seq'::regclass);


--
-- Name: opt_outs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opt_outs ALTER COLUMN id SET DEFAULT nextval('public.opt_outs_id_seq'::regclass);


--
-- Name: people id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.people ALTER COLUMN id SET DEFAULT nextval('public.people_id_seq'::regclass);


--
-- Name: replies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies ALTER COLUMN id SET DEFAULT nextval('public.replies_id_seq'::regclass);


--
-- Name: reply_candidates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_candidates ALTER COLUMN id SET DEFAULT nextval('public.reply_candidates_id_seq'::regclass);


--
-- Name: staff_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_entries ALTER COLUMN id SET DEFAULT nextval('public.staff_entries_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: work_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items ALTER COLUMN id SET DEFAULT nextval('public.work_items_id_seq'::regclass);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (id);


--
-- Name: offices offices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offices
    ADD CONSTRAINT offices_pkey PRIMARY KEY (id);


--
-- Name: opt_outs opt_outs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opt_outs
    ADD CONSTRAINT opt_outs_pkey PRIMARY KEY (id);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: replies replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_pkey PRIMARY KEY (id);


--
-- Name: reply_candidates reply_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_candidates
    ADD CONSTRAINT reply_candidates_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: staff_entries staff_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_entries
    ADD CONSTRAINT staff_entries_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (id);


--
-- Name: index_appointments_on_clinic_id_and_patient_id; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX index_appointments_on_clinic_id_and_patient_id ON pms.appointments USING btree (clinic_id, patient_id);


--
-- Name: index_appointments_on_clinic_id_and_start_at; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX index_appointments_on_clinic_id_and_start_at ON pms.appointments USING btree (clinic_id, start_at);


--
-- Name: index_deliveries_on_office_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deliveries_on_office_id ON public.deliveries USING btree (office_id);


--
-- Name: index_deliveries_on_person_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deliveries_on_person_id ON public.deliveries USING btree (person_id);


--
-- Name: index_deliveries_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deliveries_on_visit_id ON public.deliveries USING btree (visit_id);


--
-- Name: index_deliveries_on_visit_id_and_revision_and_step; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_deliveries_on_visit_id_and_revision_and_step ON public.deliveries USING btree (visit_id, revision, step);


--
-- Name: index_delivery_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_delivery_conversation ON public.deliveries USING btree (office_id, channel, recipient, attempted_at);


--
-- Name: index_delivery_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_delivery_history ON public.deliveries USING btree (person_id, channel, attempted_at);


--
-- Name: index_offices_on_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_offices_on_source_id ON public.offices USING btree (source_id);


--
-- Name: index_opt_outs_on_office_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_opt_outs_on_office_id ON public.opt_outs USING btree (office_id);


--
-- Name: index_opt_outs_on_office_id_and_channel_and_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_opt_outs_on_office_id_and_channel_and_recipient ON public.opt_outs USING btree (office_id, channel, recipient);


--
-- Name: index_people_on_office_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_people_on_office_id ON public.people USING btree (office_id);


--
-- Name: index_people_on_office_id_and_email_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_people_on_office_id_and_email_recipient ON public.people USING btree (office_id, email_recipient);


--
-- Name: index_people_on_office_id_and_search_last_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_people_on_office_id_and_search_last_name ON public.people USING btree (office_id, search_last_name);


--
-- Name: index_people_on_office_id_and_search_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_people_on_office_id_and_search_name ON public.people USING btree (office_id, search_name);


--
-- Name: index_people_on_office_id_and_sms_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_people_on_office_id_and_sms_recipient ON public.people USING btree (office_id, sms_recipient);


--
-- Name: index_people_on_office_id_and_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_people_on_office_id_and_source_id ON public.people USING btree (office_id, source_id);


--
-- Name: index_replies_on_delivery_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_delivery_id ON public.replies USING btree (delivery_id);


--
-- Name: index_replies_on_office_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_office_id ON public.replies USING btree (office_id);


--
-- Name: index_replies_on_office_id_and_event_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_replies_on_office_id_and_event_key ON public.replies USING btree (office_id, event_key);


--
-- Name: index_replies_on_person_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_person_id ON public.replies USING btree (person_id);


--
-- Name: index_replies_on_person_id_and_channel_and_received_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_person_id_and_channel_and_received_at ON public.replies USING btree (person_id, channel, received_at);


--
-- Name: index_reply_candidates_on_reply_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reply_candidates_on_reply_id ON public.reply_candidates USING btree (reply_id);


--
-- Name: index_reply_candidates_on_reply_id_and_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_reply_candidates_on_reply_id_and_visit_id ON public.reply_candidates USING btree (reply_id, visit_id);


--
-- Name: index_reply_candidates_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reply_candidates_on_visit_id ON public.reply_candidates USING btree (visit_id);


--
-- Name: index_staff_entries_on_office_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_entries_on_office_id ON public.staff_entries USING btree (office_id);


--
-- Name: index_staff_entries_on_office_id_and_event_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_staff_entries_on_office_id_and_event_key ON public.staff_entries USING btree (office_id, event_key);


--
-- Name: index_staff_entries_on_person_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_entries_on_person_id ON public.staff_entries USING btree (person_id);


--
-- Name: index_staff_entries_on_person_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_entries_on_person_id_and_created_at ON public.staff_entries USING btree (person_id, created_at);


--
-- Name: index_staff_entries_on_work_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_entries_on_work_item_id ON public.staff_entries USING btree (work_item_id);


--
-- Name: index_visits_on_office_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_office_id ON public.visits USING btree (office_id);


--
-- Name: index_visits_on_office_id_and_local_date_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_office_id_and_local_date_and_id ON public.visits USING btree (office_id, local_date, id);


--
-- Name: index_visits_on_office_id_and_local_date_and_wall_time_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_office_id_and_local_date_and_wall_time_and_id ON public.visits USING btree (office_id, local_date, wall_time, id);


--
-- Name: index_visits_on_office_id_and_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_visits_on_office_id_and_source_id ON public.visits USING btree (office_id, source_id);


--
-- Name: index_visits_on_office_id_and_source_status_and_starts_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_office_id_and_source_status_and_starts_at ON public.visits USING btree (office_id, source_status, starts_at);


--
-- Name: index_visits_on_person_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_person_id ON public.visits USING btree (person_id);


--
-- Name: index_work_items_on_office_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_office_id ON public.work_items USING btree (office_id);


--
-- Name: index_work_items_on_office_id_and_work_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_work_items_on_office_id_and_work_key ON public.work_items USING btree (office_id, work_key);


--
-- Name: index_work_items_on_person_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_person_id ON public.work_items USING btree (person_id);


--
-- Name: index_work_items_on_reply_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_reply_id ON public.work_items USING btree (reply_id);


--
-- Name: index_work_items_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_visit_id ON public.work_items USING btree (visit_id);


--
-- Name: index_work_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_queue ON public.work_items USING btree (office_id, resolved_at, assigned_to, id);


--
-- Name: appointments fk_rails_12044a3e25; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT fk_rails_12044a3e25 FOREIGN KEY (patient_id) REFERENCES pms.patients(id);


--
-- Name: patients fk_rails_6a0da623bd; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT fk_rails_6a0da623bd FOREIGN KEY (guarantor_id) REFERENCES pms.patients(id);


--
-- Name: appointments fk_rails_adda5689a7; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT fk_rails_adda5689a7 FOREIGN KEY (clinic_id) REFERENCES pms.clinics(id);


--
-- Name: opt_outs fk_rails_352a5f34e7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opt_outs
    ADD CONSTRAINT fk_rails_352a5f34e7 FOREIGN KEY (office_id) REFERENCES public.offices(id);


--
-- Name: staff_entries fk_rails_489cf643b7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_entries
    ADD CONSTRAINT fk_rails_489cf643b7 FOREIGN KEY (person_id) REFERENCES public.people(id);


--
-- Name: reply_candidates fk_rails_53446720a6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_candidates
    ADD CONSTRAINT fk_rails_53446720a6 FOREIGN KEY (reply_id) REFERENCES public.replies(id);


--
-- Name: staff_entries fk_rails_65c1c58aee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_entries
    ADD CONSTRAINT fk_rails_65c1c58aee FOREIGN KEY (work_item_id) REFERENCES public.work_items(id);


--
-- Name: reply_candidates fk_rails_68293db4ec; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_candidates
    ADD CONSTRAINT fk_rails_68293db4ec FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: deliveries fk_rails_770a16cb57; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT fk_rails_770a16cb57 FOREIGN KEY (person_id) REFERENCES public.people(id);


--
-- Name: work_items fk_rails_786737efa4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_786737efa4 FOREIGN KEY (reply_id) REFERENCES public.replies(id);


--
-- Name: replies fk_rails_7bfc443a12; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT fk_rails_7bfc443a12 FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: replies fk_rails_7cbcbd1b76; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT fk_rails_7cbcbd1b76 FOREIGN KEY (person_id) REFERENCES public.people(id);


--
-- Name: work_items fk_rails_7f5d56038e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_7f5d56038e FOREIGN KEY (office_id) REFERENCES public.offices(id);


--
-- Name: replies fk_rails_898c79097d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT fk_rails_898c79097d FOREIGN KEY (office_id) REFERENCES public.offices(id);


--
-- Name: people fk_rails_9ccc898f49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT fk_rails_9ccc898f49 FOREIGN KEY (office_id) REFERENCES public.offices(id);


--
-- Name: deliveries fk_rails_a1b2888975; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT fk_rails_a1b2888975 FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: work_items fk_rails_b4fd8e137e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_b4fd8e137e FOREIGN KEY (person_id) REFERENCES public.people(id);


--
-- Name: visits fk_rails_bb5d9d80da; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_bb5d9d80da FOREIGN KEY (office_id) REFERENCES public.offices(id);


--
-- Name: staff_entries fk_rails_c1ca81ab9d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_entries
    ADD CONSTRAINT fk_rails_c1ca81ab9d FOREIGN KEY (office_id) REFERENCES public.offices(id);


--
-- Name: work_items fk_rails_dcefa2a8ff; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_dcefa2a8ff FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: visits fk_rails_e0859280ba; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_e0859280ba FOREIGN KEY (person_id) REFERENCES public.people(id);


--
-- Name: deliveries fk_rails_e2e795b821; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT fk_rails_e2e795b821 FOREIGN KEY (office_id) REFERENCES public.offices(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO "$user", public;

INSERT INTO "schema_migrations" (version) VALUES
('20261116000500'),
('20261116000400'),
('20261116000300'),
('20261116000200'),
('20261116000100');
