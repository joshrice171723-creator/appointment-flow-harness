Rails.application.routes.draw do
  get "up" => "rails/health#show"
  scope :api do
    resource :leadership_report, only: :show
    resources :offices, only: :index do
      resource :synchronization, only: :create
      resources :reminder_runs, only: :create
      resources :patient_choices, only: :index
      resources :appointments, only: :index
      resources :work_items, only: [ :index, :create ] do
        resource :assignment, only: :update
        resources :follow_ups, only: :create
      end
      resources :patients, only: :show do
        resource :conversation, only: :show
        resource :contact_verification, only: :update
        resources :replies, only: :create
      end
    end
  end
end
