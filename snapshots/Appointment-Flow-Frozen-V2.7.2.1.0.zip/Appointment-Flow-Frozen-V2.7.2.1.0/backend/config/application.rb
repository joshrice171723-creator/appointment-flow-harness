require_relative "boot"

require "rails"
require "active_record/railtie"
require "action_controller/railtie"
require "rails/test_unit/railtie"

Bundler.require(*Rails.groups)

module ApexFlow
  class Application < Rails::Application
    config.load_defaults 8.1
    config.api_only = true
    config.active_record.schema_format = :sql
    config.autoload_lib(ignore: %w[assets tasks])
    config.filter_parameters += %i[body note phone mobile email address birthdate first_name last_name search recipient corrections details value]
  end
end
