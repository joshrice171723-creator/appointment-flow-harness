class StaffFollowUp
  class Rejected < StandardError; end

  OUTCOMES = %w[attempted confirmed rescheduled canceled reviewed].freeze

  def initialize(office, author:, item_id:, outcome:, note:, event_key:, visit_ids:, now: Time.current)
    @office = office
    @author = author
    @item_id = item_id
    @outcome = outcome
    @note = note.to_s.strip
    @event_key = event_key.to_s
    ids = Array(visit_ids).map { |id| Integer(id, exception: false) }
    raise Rejected, "Select a valid appointment from this follow-up." if ids.any?(&:nil?)

    @requested_ids = ids.uniq.sort
    @now = now
  end

  def call
    validate_form
    @office.with_lock do
      item = WorkItem.where(office: @office).find(@item_id)
      prior = StaffEntry.find_by(office: @office, event_key: @event_key)
      next replay(prior, item) if prior

      raise Rejected, "Assign this open follow-up to yourself first." if item.resolved_at || item.assigned_to != @author

      raise Rejected, "Choose an outcome for this appointment follow-up." if @outcome == "reviewed" && !item.reply

      visits = appointment_targets(item)
      apply_outcome(item, visits)
      StaffEntry.create!(office: @office, person_id: item.person_id, work_item: item, author: @author,
        event_key: @event_key, action_name: @outcome, note: @note, details: { visit_ids: @requested_ids }, created_at: @now)
    end
  end

  private

  def validate_form
    unless OUTCOMES.include?(@outcome) && @note.length.between?(1, 500) &&
        @event_key.match?(/\A[a-zA-Z0-9_-]{1,100}\z/) && @requested_ids.length <= ReplyProcessing::CANDIDATE_LIMIT
      raise Rejected, "Choose an outcome and enter a note up to 500 characters."
    end
  end

  def replay(entry, item)
    if entry.work_item_id != item.id || entry.author != @author || entry.action_name != @outcome ||
        entry.note != @note || entry.details["visit_ids"] != @requested_ids
      raise Rejected, "That save identifier was already used. Refresh the follow-up."
    end
    entry
  end

  def appointment_targets(item)
    return [] if %w[attempted reviewed].include?(@outcome)

    revisions = if item.reply
      item.reply.reply_candidates.where(visit_id: @requested_ids).pluck(:visit_id, :revision).to_h
    else
      { item.visit_id => item.revision }
    end
    requested = item.reply ? @requested_ids : [ item.visit_id ]
    visits = @office.visits.where(id: requested).preload(:person).to_a
    source = Pms::Appointment.where(id: visits.map(&:source_id), clinic_id: @office.source_id, status: "scheduled")
      .pluck(:id, :patient_id, :start_at).to_h { |id, patient_id, wall_time| [ id, [ patient_id, wall_time ] ] }
    valid = visits.any? && visits.size == requested.size && visits.all? do |visit|
      visit.revision == revisions[visit.id] && visit.open_at?(@now) &&
        source[visit.source_id] == [ visit.person.source_id, visit.wall_time ]
    end
    raise Rejected, "Select a current appointment from this follow-up before saving the outcome." unless valid

    visits
  end

  def apply_outcome(item, visits)
    return if @outcome == "attempted"

    visits.each do |visit|
      if @outcome == "confirmed"
        visit.update!(confirmed_at: visit.confirmed_at || @now)
      else
        visit.update!(disposition: @outcome, confirmed_at: nil)
      end
    end
    WorkItem.where(office: @office, visit: visits).open.where.not(kind: "reply")
      .update_all(resolved_at: @now, updated_at: @now) if visits.any?
    item.update!(resolved_at: @now)
    item.reply&.update!(result: "reviewed")
  end
end
