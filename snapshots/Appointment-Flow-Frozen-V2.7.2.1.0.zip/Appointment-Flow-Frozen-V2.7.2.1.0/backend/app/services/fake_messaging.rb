class FakeMessaging
  def self.deliver(channel:, recipient:)
    # The reserved demo number ending in 0199 exercises backup and follow-up.
    channel == "sms" && recipient.end_with?("5550199") ? "failed" : "sent"
  end
end
