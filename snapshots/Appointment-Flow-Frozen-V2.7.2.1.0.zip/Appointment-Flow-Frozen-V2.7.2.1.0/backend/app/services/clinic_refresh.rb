class ClinicRefresh
  class IncompleteSource < StandardError; end

  def initialize(office, now: Time.current, dates: nil)
    @office = office
    @now = now
    @dates = dates
  end

  def call
    @office.with_lock do
      rows, previous = read_snapshot
      reconcile(rows, previous)
      @office.update!(synced_at: @now, sync_error: nil)
      block_given? ? yield : true
    rescue IncompleteSource => error
      @office.update!(sync_error: error.message)
      false
    end
  end

  private

  def read_snapshot
    today = @office.local_time(@now).to_date
    dates = @dates || (today.beginning_of_month.prev_month(2)...today.beginning_of_month.next_month(2))
    wall_range = dates.begin.to_time(:utc)...(dates.exclude_end? ? dates.end : dates.end.next_day).to_time(:utc)
    existing = @office.visits.where(local_date: dates)
    tracked_ids = existing.where(source_status: "scheduled").pluck(:source_id)
    rows = read_replica(wall_range, tracked_ids)

    previous = @office.visits.where(source_id: rows.map(&:id)).index_by(&:source_id)
    [ rows, previous ]
  end

  def read_replica(wall_range, tracked_ids)
    Pms::Record.transaction(requires_new: true) do
      raise IncompleteSource, "PMS clinic is unavailable." unless Pms::Clinic.exists?(@office.source_id)

      source = Pms::Appointment.where(clinic_id: @office.source_id)
      rows = source.where(start_at: wall_range).or(source.where(id: tracked_ids))
        .select(:id, :patient_id, :start_at, :status, :provider_name, :length_minutes)
        .preload(:patient).to_a
      if rows.any? { |row| row.patient.nil? } || (tracked_ids - rows.map(&:id)).any? || (rows.empty? && !source.exists?)
        raise IncompleteSource, "PMS refresh is empty or missing tracked appointments."
      end
      rows
    end
  rescue ActiveRecord::ConnectionNotEstablished, ActiveRecord::QueryCanceled => error
    raise IncompleteSource, "PMS query could not finish.", cause: error
  rescue ActiveRecord::StatementInvalid => error
    raise unless error.cause.is_a?(PG::UndefinedTable) || error.cause.is_a?(PG::UndefinedColumn)

    raise IncompleteSource, "PMS schema is unavailable.", cause: error
  end

  def reconcile(rows, previous)
    source_people = rows.map(&:patient).uniq(&:id)
    people = @office.people.where(source_id: source_people.map(&:id)).index_by(&:source_id)
    source_people.each do |source_person|
      person = people[source_person.id] ||= @office.people.build(source_id: source_person.id)
      person.assign_attributes(source_person.attributes.slice(
        "first_name", "last_name", "birthdate", "wireless_phone", "email", "preferred_language", "guarantor_id"
      ))
      person.save! if person.changed?
    end

    expired_tasks = []
    rows.each do |row|
      visit = previous[row.id] || @office.visits.build(source_id: row.id)
      person = people.fetch(row.patient_id)
      changed_slot = visit.persisted? && (
        [ visit.person_id, visit.wall_time ] != [ person.id, row.start_at ] ||
        (visit.source_status != "scheduled" && row.status == "scheduled")
      )
      left_schedule = visit.persisted? && visit.source_status == "scheduled" && row.status != "scheduled"
      expired_tasks << visit.id if changed_slot || left_schedule
      visit.assign_attributes(person:, wall_time: row.start_at, local_date: row.start_at.to_date,
        starts_at: @office.interpret_wall_time(row.start_at), provider_name: row.provider_name,
        length_minutes: row.length_minutes, source_status: row.status)
      if changed_slot
        visit.revision += 1
        visit.confirmed_at = nil
        visit.disposition = nil
      end
      visit.save! if visit.changed?
    end
    WorkItem.open.where(office: @office, visit_id: expired_tasks).where.not(kind: "reply")
      .update_all(resolved_at: @now, updated_at: @now) if expired_tasks.any?
  end
end
