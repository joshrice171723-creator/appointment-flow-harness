class ContactEligibility
  SOURCE_FIELDS = { "sms" => :wireless_phone, "email" => :email }.freeze

  def initialize(office, people, date:)
    @date = date
    @blocked = OptOut.where(office:, recipient: people.flat_map { |person| [ person.sms_recipient, person.email_recipient ] }.compact)
      .pluck(:channel, :recipient).to_set
    @shared = Person::RECIPIENT_COLUMNS.transform_values do |column|
      recipients = people.filter_map { |person| person[column] }.uniq
      office.people.where(column => recipients).group(column).count
    end
    @source_owners, @source_values = source_contacts(office, people)
  end

  def hold_reason(person)
    birthdate = person.contact("birthdate")
    return "Verify the patient's birthdate." if birthdate.blank? || Date.iso8601(birthdate) > @date
    return "Verify an authorized adult contact." if Date.iso8601(birthdate) > @date.years_ago(18)
    return "Review the change to verified PMS details." if person.contact_conflict?
    return "Review the patient's preferred language." unless %w[en es].include?(person.contact("preferred_language"))

    "Check for a usable, permitted contact unique to this patient." if channels(person).empty?
  end

  def channels(person)
    Person::RECIPIENT_COLUMNS.keys.select do |channel|
      recipient = person.recipient(channel)
      next false unless recipient && @shared.fetch(channel)[recipient] == 1 && !@blocked.include?([ channel, recipient ])

      source_values = @source_values[person.source_id]
      next false unless source_values && source_values[channel] == person[SOURCE_FIELDS.fetch(channel)]

      @source_owners.fetch([ channel, recipient ], []).all? { |id| id == person.source_id }
    end
  end

  private

  def source_contacts(office, people)
    recipients = Person::RECIPIENT_COLUMNS.keys.to_h do |channel|
      [ channel, people.filter_map { |person| person.recipient(channel) }.to_set ]
    end
    recipients.reject! { |_channel, values| values.empty? }
    return [ {}, {} ] if recipients.empty?

    # Raw PMS values can be formatted differently. Check current owners even for patients outside the reminder horizon.
    fields = SOURCE_FIELDS.values_at(*recipients.keys)
    candidates = people.map(&:source_id).to_set
    clinic_patients = Pms::Appointment.where(clinic_id: office.source_id).select(:patient_id)
    owners = Hash.new { |hash, key| hash[key] = [] }
    candidate_values = {}
    Pms::Patient.where(id: clinic_patients).pluck(:id, *fields).each do |id, *values|
      candidate_values[id] = recipients.keys.zip(values).to_h if candidates.include?(id)
      recipients.each_key.with_index do |channel, index|
        normalized = Person.normalize(channel, values[index])
        owners[[ channel, normalized ]] << id if recipients.fetch(channel).include?(normalized)
      end
    end
    [ owners, candidate_values ]
  end
end
