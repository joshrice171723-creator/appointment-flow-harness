class ReplyProcessing
  class InvalidReply < StandardError; end

  LOOKBACK = 10.days
  CANDIDATE_LIMIT = 40

  def initialize(person, channel:, body:, event_key:, delivery_id: nil, now: Time.current)
    @person = person
    @office = person.office
    @channel = channel
    @body = body.to_s.strip
    @event_key = event_key.to_s
    @delivery_id = delivery_id
    @now = now
  end

  def call
    validate_request
    @office.with_lock do
      prior = Reply.find_by(office: @office, event_key: @event_key)
      next replay(prior) if prior

      @person.reload
      recipient = @person.recipient(@channel)
      raise InvalidReply, "This patient has no usable address for that channel." unless recipient

      if @channel == "sms" && @body.casecmp?("STOP")
        OptOut.create_or_find_by!(office: @office, channel: @channel, recipient:) { |opt_out| opt_out.created_at = @now }
        next record_reply(recipient, "opted_out")
      end

      history = conversation(recipient)
      candidates = possible_visits(recipient, history)
      if (delivery = confirmation_delivery(history, recipient))
        confirm(delivery, recipient)
      else
        review_reply(recipient, candidates)
      end
    end
  end

  private

  def validate_request
    unless Person::RECIPIENT_COLUMNS.key?(@channel) && @body.length.between?(1, 1000) &&
        @event_key.match?(/\A[a-zA-Z0-9_-]{1,100}\z/)
      raise InvalidReply, "Enter a reply between 1 and 1,000 characters."
    end
  end

  def replay(prior)
    if prior.person_id != @person.id || prior.channel != @channel || prior.body != @body
      raise InvalidReply, "That reply identifier was already used. Refresh the inbox."
    end
    prior
  end

  def conversation(recipient)
    messages = Delivery.sent.where(office: @office, recipient:, channel: @channel,
      attempted_at: (@now - LOOKBACK)..@now)
    messages = messages.where(id: @delivery_id) if @channel == "email" && @delivery_id.present?
    messages.order(attempted_at: :desc, id: :desc).limit(CANDIDATE_LIMIT + 1).preload(:visit).to_a
  end

  def possible_visits(recipient, history)
    found = history.first(CANDIDATE_LIMIT).uniq(&:visit_id).to_h { |message| [ message.visit_id, message.revision ] }
    return found if found.any?

    matching_people = @office.people.where(Person::RECIPIENT_COLUMNS.fetch(@channel) => recipient)
    @office.visits.open_for_outreach.where(person_id: matching_people.select(:id),
      starts_at: @now..(@now + LOOKBACK)).order(:starts_at, :id).limit(CANDIDATE_LIMIT).pluck(:id, :revision).to_h
  end

  def confirmation_delivery(history, recipient)
    return unless @body.casecmp?("YES") && history.length.between?(1, CANDIDATE_LIMIT)
    return if @office.sync_error.present?
    return unless history.map { |message| [ message.visit_id, message.revision ] }.uniq.one?
    return if @channel == "email" && @delivery_id.blank?

    delivery = history.first
    visit = delivery.visit
    return unless delivery.person_id == @person.id && visit.person_id == @person.id &&
      delivery.revision == visit.revision && visit.open_at?(@now)
    return if stale_sms_thread?(delivery)
    return unless contact_still_matches?(recipient)

    delivery if visit.source_slot_current?
  end

  def stale_sms_thread?(delivery)
    return false unless @channel == "sms" && delivery.revision > 1

    Delivery.sent.exists?(office: @office, visit_id: delivery.visit_id, recipient: delivery.recipient,
      channel: "sms", revision: (...delivery.revision))
  end

  def contact_still_matches?(recipient)
    date = @office.local_time(@now).to_date
    eligibility = ContactEligibility.new(@office, [ @person ], date:)
    return false if eligibility.hold_reason(@person) || !eligibility.channels(@person).include?(@channel)

    @person.recipient(@channel) == recipient && Pms::Patient.exists?(
      @person.attributes.slice(*Person::CONTACT_FIELDS).merge("id" => @person.source_id)
    )
  end

  def confirm(delivery, recipient)
    visit = delivery.visit
    visit.update!(confirmed_at: @now) unless visit.confirmed_at
    WorkItem.open.where(office: @office, visit:, revision: visit.revision, kind: "no_reply")
      .update_all(resolved_at: @now, updated_at: @now)
    record_reply(recipient, "confirmed", delivery)
  end

  def review_reply(recipient, candidates)
    reply = record_reply(recipient, "review")
    if candidates.any?
      ReplyCandidate.insert_all!(candidates.map { |visit_id, revision| { reply_id: reply.id, visit_id:, revision: } })
    end
    visit_id, revision = candidates.first if candidates.one?
    WorkItem.create!(office: @office, person: @person, reply:, kind: "reply", visit_id:, revision:,
      detail: "Review this reply and confirm which visit it concerns.", work_key: "reply/#{reply.id}")
    reply
  end

  def record_reply(recipient, result, delivery = nil)
    Reply.create!(office: @office, person: @person, recipient:, delivery:, result:, channel: @channel,
      body: @body, event_key: @event_key, received_at: @now)
  end
end
