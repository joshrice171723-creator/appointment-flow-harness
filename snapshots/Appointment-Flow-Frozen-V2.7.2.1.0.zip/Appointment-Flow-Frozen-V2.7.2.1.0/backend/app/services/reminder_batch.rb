class ReminderBatch
  INITIAL_DAYS = 7
  BACKUP_DAYS = 6
  FOLLOW_UP_DAYS = 3
  FINAL_DAYS = 1
  REVIEW_SECONDS = 48.hours

  def initialize(office, now: Time.current, transport: FakeMessaging)
    @office = office
    @now = now
    @transport = transport
    @local = office.local_time(now)
  end

  def call
    date = @local.to_date
    # Refresh the dispatch horizon on every run, including tracked visits moved out of it.
    ClinicRefresh.new(@office, now: @now, dates: date..date.next_day(INITIAL_DAYS)).call do
      visits = due_visits
      eligibility = ContactEligibility.new(@office, visits.map(&:person).uniq, date:)
      histories = delivery_histories(visits)
      attempts, tasks, cleared_holds = plan_outreach(visits, histories, eligibility)
      save_outreach(attempts, tasks, cleared_holds)
    end
  end

  private

  def due_visits
    @office.visits.open_for_outreach.where(local_date: @local.to_date..@local.to_date.next_day(INITIAL_DAYS))
      .where(starts_at: (@now..)).or(
        @office.visits.open_for_outreach.where(local_date: @local.to_date..@local.to_date.next_day(INITIAL_DAYS), starts_at: nil)
      ).preload(:person).to_a
  end

  def delivery_histories(visits)
    deliveries = Delivery.where(office: @office)
    current = visits.group_by(&:revision).reduce(deliveries.none) do |scope, (revision, batch)|
      scope.or(deliveries.where(revision:, visit_id: batch.map(&:id)))
    end
    current.select(:visit_id, :step, :channel, :status, :attempted_at).order(:attempted_at).group_by(&:visit_id)
  end

  def plan_outreach(visits, histories, eligibility)
    attempts = []
    tasks = []
    cleared_holds = []
    visits.each do |visit|
      next if visit.starts_at && visit.starts_at <= @now

      reason = visit.starts_at.nil? ? "Appointment time needs review." : eligibility.hold_reason(visit.person)
      if reason
        tasks << WorkItem.visit_task(visit, "hold", reason) unless visit.confirmed_at
        next
      end
      cleared_holds << WorkItem.visit_task(visit, "hold", "")[:work_key]

      if visit.confirmed_at.nil? && visit.starts_at <= @now + REVIEW_SECONDS
        tasks << WorkItem.visit_task(visit, "no_reply", "Contact the patient to verify this appointment.")
      end
      next unless @local.hour.between?(10, 17)

      history = histories.fetch(visit.id, [])
      attempt = prepare_delivery(visit, history, eligibility.channels(visit.person))
      next unless attempt

      attempts << attempt
      if attempt[:status] == "failed"
        tasks << WorkItem.visit_task(visit, "delivery", "Delivery failed. Verify the patient's contact details.")
      end
    end
    [ attempts, tasks, cleared_holds ]
  end

  def prepare_delivery(visit, history, channels)
    days = (visit.local_date - @local.to_date).to_i
    step, channel = select_step(visit, history, channels, days)
    return unless channel
    return if history.any? { |attempt| attempt.step == step || @office.local_time(attempt.attempted_at).to_date == @local.to_date }

    recipient = visit.person.recipient(channel)
    {
      office_id: @office.id, visit_id: visit.id, person_id: visit.person_id, revision: visit.revision,
      channel:, recipient:, step:, body: message_for(visit, channel),
      status: @transport.deliver(channel:, recipient:), attempted_at: @now
    }
  end

  def select_step(visit, history, channels, days)
    return if days < FINAL_DAYS
    return [ "final", channels.first ] if days == FINAL_DAYS
    return if visit.confirmed_at
    return [ "follow_up", preferred_channel(history, channels) ] if days <= FOLLOW_UP_DAYS

    initial = history.find { |attempt| attempt.step == "initial" }
    return [ "initial", channels.first ] unless initial
    return unless initial.channel == "sms" && days <= BACKUP_DAYS

    [ "backup", "email".presence_in(channels) ]
  end

  def preferred_channel(history, channels)
    successful = history.reverse.find { |attempt| attempt.status == "sent" && channels.include?(attempt.channel) }
    successful&.channel || channels.first
  end

  def message_for(visit, channel)
    time = @office.local_time(visit.starts_at)
    spanish = visit.person.contact("preferred_language") == "es"
    date = spanish ? time.strftime("%d/%m/%Y a las %H:%M") : time.strftime("%b %-d, %Y at %-I:%M %p")
    body = spanish ? "Cita en Apex #{@office.name}: #{date}." : "Appointment at Apex #{@office.name}: #{date}."
    unless visit.confirmed_at
      body += spanish ? " Responda YES para confirmar o NO si necesita ayuda." : " Reply YES to confirm or NO for help."
    end
    if channel == "sms"
      body += spanish ? " Responda STOP para dejar de recibir mensajes de texto." : " Reply STOP to stop texts."
    end
    body
  end

  def save_tasks(scope, tasks)
    previous = scope.where(work_key: tasks.pluck(:work_key)).pluck(:work_key, :detail, :resolved_at)
      .to_h { |key, detail, resolved_at| [ key, [ detail, resolved_at ] ] }
    changed = tasks.reject { |task| previous[task[:work_key]] == [ task[:detail], nil ] }
    return if changed.empty?

    scope.upsert_all(changed.map { |task| task.merge(resolved_at: nil) }, unique_by: %i[office_id work_key],
      update_only: %i[detail resolved_at], returning: false)
  end

  def save_outreach(attempts, tasks, cleared_holds)
    Delivery.insert_all!(attempts) if attempts.any?
    scope = WorkItem.where(office: @office)
    save_tasks(scope, tasks) if tasks.any?
    scope.open.where(work_key: cleared_holds).update_all(resolved_at: @now, updated_at: @now) if cleared_holds.any?
    { sent: attempts.count { |attempt| attempt[:status] == "sent" },
      failed: attempts.count { |attempt| attempt[:status] == "failed" } }
  end
end
