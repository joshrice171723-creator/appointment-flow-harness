module WorkItemSummary
  def self.for(item)
    {
      id: item.id, kind: item.kind, detail: item.detail, person_id: item.person_id,
      patient: item.person.name, assigned_to: item.assigned_to, resolved_at: item.resolved_at,
      visit: VisitSummary.for(item.visit)
    }
  end
end
