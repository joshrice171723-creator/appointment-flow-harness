module VisitSummary
  def self.for(visit, reply_review: false)
    return unless visit

    {
      id: visit.id, source_id: visit.source_id, person_id: visit.person_id,
      local_date: visit.local_date, starts_at: visit.starts_at, wall_time: visit.wall_time,
      provider_name: visit.provider_name, length_minutes: visit.length_minutes,
      confirmed: visit.confirmed_at.present?, outcome: visit.source_status == "complete" ? "Completed" : "Unknown",
      disposition: visit.disposition, revision: visit.revision, reply_review:
    }
  end
end
