class Reply < ApplicationRecord
  belongs_to :office
  belongs_to :person
  belongs_to :delivery, optional: true
  has_many :reply_candidates
end
