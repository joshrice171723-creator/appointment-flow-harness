class Delivery < ApplicationRecord
  belongs_to :office
  belongs_to :visit
  belongs_to :person

  scope :sent, -> { where(status: "sent") }
end
