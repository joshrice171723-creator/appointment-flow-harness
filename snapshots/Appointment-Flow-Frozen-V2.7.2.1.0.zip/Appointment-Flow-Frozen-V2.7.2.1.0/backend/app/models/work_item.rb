class WorkItem < ApplicationRecord
  belongs_to :office
  belongs_to :person
  belongs_to :visit, optional: true
  belongs_to :reply, optional: true

  scope :open, -> { where(resolved_at: nil) }

  def self.visit_task(visit, kind, detail)
    {
      office_id: visit.office_id, person_id: visit.person_id, visit_id: visit.id,
      revision: visit.revision, kind:, detail:, work_key: "#{visit.id}/#{visit.revision}/#{kind}"
    }
  end
end
