class Office < ApplicationRecord
  has_many :people
  has_many :visits

  def local_time(time)
    time.in_time_zone(timezone)
  end

  def interpret_wall_time(wall_time)
    zone = TZInfo::Timezone.get(timezone)
    zone.local_to_utc(wall_time)
  rescue TZInfo::AmbiguousTime, TZInfo::PeriodNotFound
    nil
  end

  def staff_names
    { 1 => %w[Jordan Taylor], 2 => %w[Morgan Casey] }.fetch(source_id, [])
  end
end
