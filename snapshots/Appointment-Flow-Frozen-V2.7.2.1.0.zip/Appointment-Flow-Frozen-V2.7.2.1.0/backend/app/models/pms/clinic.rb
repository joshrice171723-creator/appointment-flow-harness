module Pms
  class Clinic < Record
    self.table_name = "pms.clinics"

    has_many :appointments, class_name: "Pms::Appointment"
  end
end
