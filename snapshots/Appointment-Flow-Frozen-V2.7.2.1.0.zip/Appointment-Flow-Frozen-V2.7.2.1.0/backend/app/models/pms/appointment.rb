module Pms
  class Appointment < Record
    self.table_name = "pms.appointments"

    belongs_to :patient, class_name: "Pms::Patient"
  end
end
