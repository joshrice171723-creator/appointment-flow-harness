class Person < ApplicationRecord
  CONTACT_FIELDS = %w[birthdate wireless_phone email preferred_language].freeze
  RECIPIENT_COLUMNS = { "sms" => :sms_recipient, "email" => :email_recipient }.freeze

  belongs_to :office
  has_many :visits
  before_validation :prepare_contact_index

  scope :named_like, ->(prefix) do
    range = prefix..."#{prefix}\u{10FFFF}"
    where(search_name: range).or(where(search_last_name: range))
  end

  def name
    "#{first_name} #{last_name}"
  end

  def contact(field)
    corrections.fetch(field) { self[field] }&.to_s
  end

  def contact_conflict?
    correction_baselines.any? { |field, value| value != self[field]&.to_s }
  end

  def recipient(channel)
    self[RECIPIENT_COLUMNS.fetch(channel)]
  end

  def self.normalize(channel, value)
    raw = value.to_s.strip
    if channel == "sms"
      return unless raw.match?(/\A[\d ()+.-]+\z/)

      digits = raw.delete("^0-9").sub(/\A1(?=\d{10}\z)/, "")
      "+1#{digits}" if digits.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
    elsif raw.match?(URI::MailTo::EMAIL_REGEXP)
      raw.downcase
    end
  end

  private

  def prepare_contact_index
    self.search_name = name.downcase
    self.search_last_name = last_name.downcase
    self.sms_recipient = self.class.normalize("sms", contact("wireless_phone"))
    self.email_recipient = self.class.normalize("email", contact("email"))
  end
end
