class ReplyCandidate < ApplicationRecord
  belongs_to :reply
  belongs_to :visit
end
