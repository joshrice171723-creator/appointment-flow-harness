class StaffEntry < ApplicationRecord
  belongs_to :office
  belongs_to :person
  belongs_to :work_item, optional: true
end
