class Visit < ApplicationRecord
  belongs_to :office
  belongs_to :person

  scope :open_for_outreach, -> { where(source_status: "scheduled", disposition: nil) }

  def open_at?(time)
    source_status == "scheduled" && disposition.nil? && starts_at.present? && starts_at > time
  end
  def source_slot_current?
    Pms::Appointment.exists?(id: source_id, clinic_id: office.source_id,
      patient_id: person.source_id, start_at: wall_time, status: "scheduled")
  end
end
