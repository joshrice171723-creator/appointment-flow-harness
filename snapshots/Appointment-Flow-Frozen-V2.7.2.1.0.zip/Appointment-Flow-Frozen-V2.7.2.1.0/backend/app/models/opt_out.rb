class OptOut < ApplicationRecord
  belongs_to :office
end
