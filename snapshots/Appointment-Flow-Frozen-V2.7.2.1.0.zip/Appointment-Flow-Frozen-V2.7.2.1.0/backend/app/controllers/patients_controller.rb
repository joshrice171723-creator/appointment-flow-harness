class PatientsController < ApplicationController
  HISTORY_LIMIT = 50

  def show
    staff
    person = office.people.find(params[:id])
    visits = person.visits.where(office:).order(wall_time: :desc, id: :desc).limit(HISTORY_LIMIT)
    next_visit = person.visits.where(office:).open_for_outreach.where(starts_at: (Time.current..))
      .order(:starts_at, :id).first
    work = WorkItem.where(office:, person:)
    work = work.open.or(work.where(id: work.where.not(resolved_at: nil).order(id: :desc).limit(HISTORY_LIMIT).select(:id)))
      .order(id: :desc).limit(HISTORY_LIMIT).preload(:person, :visit, reply: { reply_candidates: { visit: :person } })
    entries = StaffEntry.where(office:, person:).order(created_at: :desc, id: :desc).limit(HISTORY_LIMIT)
      .pluck(:id, :action_name, :note, :author, :created_at)
    render json: {
      id: person.id, name: person.name, contacts: contact_details(person), next_visit: VisitSummary.for(next_visit),
      visits: visits.map { |visit| VisitSummary.for(visit) }, work: work.map { |item| detail(item) },
      activity: entries.map { |id, action, note, author, at| { id:, action:, note:, author:, at: } },
      synced_at: office.synced_at, sync_error: office.sync_error
    }
  end

  private

  def contact_details(person)
    Person::CONTACT_FIELDS.to_h do |field|
      [ field, { value: person.contact(field), source: person[field]&.to_s, verified: person.corrections.key?(field),
        conflict: person.correction_baselines.key?(field) && person.correction_baselines[field] != person[field]&.to_s } ]
    end
  end

  def detail(item)
    reply = item.reply
    now = Time.current
    WorkItemSummary.for(item).merge(reply: reply && {
      body: reply.body,
      candidates: reply.reply_candidates.map do |candidate|
        visit = candidate.visit
        VisitSummary.for(visit).merge(patient: visit.person.name,
          eligible: candidate.revision == visit.revision && visit.open_at?(now))
      end
    })
  end
end
