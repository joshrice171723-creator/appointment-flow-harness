class FollowUpsController < ApplicationController
  def create
    author = staff
    entry = StaffFollowUp.new(office, author:, item_id: params[:work_item_id], outcome: params[:outcome],
      note: params[:note], event_key: params[:event_key], visit_ids: params[:visit_ids]).call

    render json: { id: entry.id, outcome: entry.action_name }
  rescue StaffFollowUp::Rejected => error
    render json: { error: error.message }, status: :unprocessable_entity
  end
end
