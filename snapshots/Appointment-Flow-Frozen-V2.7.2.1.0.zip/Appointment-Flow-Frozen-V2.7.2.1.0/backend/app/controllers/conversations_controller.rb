class ConversationsController < ApplicationController
  LIMIT = 50

  def show
    person = office.people.find(params[:patient_id])
    channel = params[:channel].presence_in(Person::RECIPIENT_COLUMNS.keys) || raise(InvalidRequest)
    deliveries = Delivery.sent.where(office:, person:, channel:).order(attempted_at: :desc, id: :desc)
      .limit(LIMIT).pluck(:id, :body, :attempted_at)
    replies = Reply.where(office:, person:, channel:).order(received_at: :desc, id: :desc)
      .limit(LIMIT).pluck(:id, :body, :received_at)

    messages = messages_from(deliveries, "reminder") + messages_from(replies, "reply")
    render json: { messages: messages.sort_by { |message| message[:at] }.last(LIMIT),
      can_reply: person.recipient(channel).present? }
  end

  private

  def messages_from(records, direction)
    records.map { |id, body, at| { id:, body:, at:, direction: } }
  end
end
