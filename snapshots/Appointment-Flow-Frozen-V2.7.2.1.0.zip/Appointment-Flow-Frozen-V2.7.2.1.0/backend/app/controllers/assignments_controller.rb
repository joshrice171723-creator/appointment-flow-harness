class AssignmentsController < ApplicationController
  def update
    author = staff
    office.with_lock do
      item = WorkItem.where(office:).open.find(params[:work_item_id])
      if item.assigned_to.present? && item.assigned_to != author
        render json: { error: "This follow-up is already assigned to another staff member." }, status: :conflict
      else
        item.update!(assigned_to: author)
        render json: { assigned_to: item.assigned_to }
      end
    end
  end
end
