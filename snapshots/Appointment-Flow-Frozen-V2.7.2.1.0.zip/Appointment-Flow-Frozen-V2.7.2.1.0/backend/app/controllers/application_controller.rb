class ApplicationController < ActionController::API
  class InvalidRequest < StandardError; end

  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "The requested record was not found in this clinic." }, status: :not_found
  end

  rescue_from ActionController::ParameterMissing, InvalidRequest, Date::Error do
    render json: { error: "Check the requested values and try again." }, status: :unprocessable_entity
  end

  private

  def office
    @office ||= Office.find(params[:office_id])
  end

  def staff
    request.headers["X-Demo-Staff"].presence_in(office.staff_names) ||
      raise(ActiveRecord::RecordNotFound)
  end
end
