class RepliesController < ApplicationController
  def create
    person = office.people.find(params[:patient_id])
    reply = ReplyProcessing.new(person, channel: params[:channel], body: params[:body],
      event_key: params[:event_key], delivery_id: params[:delivery_id]).call

    render json: { id: reply.id, result: reply.result }
  rescue ReplyProcessing::InvalidReply => error
    render json: { error: error.message }, status: :unprocessable_entity
  end
end
