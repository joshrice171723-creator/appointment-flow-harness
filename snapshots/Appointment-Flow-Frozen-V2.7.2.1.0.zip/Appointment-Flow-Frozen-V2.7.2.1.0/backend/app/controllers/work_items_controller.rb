class WorkItemsController < ApplicationController
  PAGE_SIZES = [ 10, 20, 40 ].freeze
  KINDS = %w[hold delivery no_reply reply].freeze

  def index
    staff
    full = WorkItem.where(office:)
    counts = { attention: full.open.where(assigned_to: nil).count, in_progress: full.open.where.not(assigned_to: nil).count,
      resolved: full.where.not(resolved_at: nil).count }

    filtered = filter_work(full)
    queues = if params[:view] == "resolved"
      { resolved: queue(filtered.where.not(resolved_at: nil), :resolved_page) }
    else
      {
        attention: queue(filtered.open.where(assigned_to: nil), :attention_page),
        in_progress: queue(filtered.open.where.not(assigned_to: nil), :progress_page)
      }
    end
    render json: { counts:, queues:, synced_at: office.synced_at, sync_error: office.sync_error }
  end

  def create
    author = staff
    office.with_lock do
      visit = office.visits.find(params[:visit_id])
      unless visit.open_at?(Time.current) && visit.source_slot_current?
        return render json: { error: "Refresh PMS before starting follow-up on this visit." }, status: :unprocessable_entity
      end

      attributes = WorkItem.visit_task(visit, "no_reply", "Staff opened this appointment for follow-up.")
      item = WorkItem.create_or_find_by!(office:, work_key: attributes[:work_key]) do |work|
        work.assign_attributes(attributes.merge(assigned_to: author))
      end
      if item.resolved_at
        render json: { error: "Follow-up for this appointment was already resolved." }, status: :conflict
      else
        render json: { id: item.id }
      end
    end
  end

  private

  def filter_work(scope)
    if (prefix = params[:search].to_s.strip.downcase.presence)
      scope = scope.where(person_id: office.people.named_like(prefix).select(:id))
    end
    if (kind = params[:kind].presence_in(KINDS))
      scope = scope.where(kind:)
    end
    scope
  end

  def queue(scope, page_param)
    page_size = params[:page_size].to_i.presence_in(PAGE_SIZES) || PAGE_SIZES.first
    total = scope.count
    upper = [ (total.to_f / page_size).ceil, 1 ].max
    page = params[page_param].to_i.clamp(1, upper)
    items = scope.order(id: :desc).limit(page_size).offset((page - 1) * page_size).preload(:person, :visit)
    { page:, total:, page_size:, items: items.map { |item| WorkItemSummary.for(item) } }
  end
end
