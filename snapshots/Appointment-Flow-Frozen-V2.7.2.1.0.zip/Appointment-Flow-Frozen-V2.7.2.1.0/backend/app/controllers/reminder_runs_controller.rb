class ReminderRunsController < ApplicationController
  def create
    staff
    result = ReminderBatch.new(office).call
    if result
      render json: result
    else
      render json: { error: office.sync_error }, status: :service_unavailable
    end
  end
end
