class ContactVerificationsController < ApplicationController
  def update
    author = staff
    field = params[:field].presence_in(Person::CONTACT_FIELDS) || raise(InvalidRequest)
    value = params[:value].to_s.strip.presence
    key = params[:event_key].to_s
    raise InvalidRequest unless key.match?(/\A[a-zA-Z0-9_-]{1,100}\z/)

    office.with_lock do
      person = office.people.find(params[:patient_id])
      prior = StaffEntry.find_by(office:, event_key: key)
      if prior
        unless prior.person_id == person.id && prior.author == author && prior.action_name == "verified" &&
            prior.details.values_at("field", "value") == [ field, value ]
          raise InvalidRequest
        end
      else
        verify_contact(person, field, value, key, author)
      end
      render json: { verified: true }
    end
  end

  private

  def verify_contact(person, field, value, key, author)
    validate_contact(field, value)
    person.update!(
      corrections: person.corrections.merge(field => value),
      correction_baselines: person.correction_baselines.merge(field => person[field]&.to_s)
    )
    StaffEntry.create!(office:, person:, event_key: key, author:, action_name: "verified", note: "Verified #{field.humanize.downcase}.",
      details: { field:, value: }, created_at: Time.current)
  end

  def validate_contact(field, value)
    return unless value

    valid = case field
    when "birthdate" then Date.iso8601(value).iso8601 == value && Date.iso8601(value) <= office.local_time(Time.current).to_date
    when "wireless_phone" then Person.normalize("sms", value).present?
    when "email" then value.length <= 254 && Person.normalize("email", value).present?
    when "preferred_language" then value.match?(/\A[a-z]{2}\z/i)
    end
    raise InvalidRequest unless valid
  end
end
