class OfficesController < ApplicationController
  def index
    render json: Office.order(:name).map { |office| { id: office.id, name: office.name, timezone: office.timezone, staff: office.staff_names } }
  end
end
