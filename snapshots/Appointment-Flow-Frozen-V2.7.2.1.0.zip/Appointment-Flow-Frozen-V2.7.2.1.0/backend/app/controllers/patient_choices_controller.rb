class PatientChoicesController < ApplicationController
  LIMIT = 50

  def index
    people = office.people.order(:search_name, :id)
    if (prefix = params[:search].to_s.strip.downcase.presence)
      people = people.named_like(prefix)
    end
    names = people.limit(LIMIT).pluck(:id, :first_name, :last_name)
    render json: names.map { |id, first, last| { id:, name: "#{first} #{last}" } }
  end
end
