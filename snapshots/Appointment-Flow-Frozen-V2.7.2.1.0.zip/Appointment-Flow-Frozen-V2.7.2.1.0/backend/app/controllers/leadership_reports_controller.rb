class LeadershipReportsController < ApplicationController
  def show
    month = params[:month].present? ? Date.iso8601("#{params[:month]}-01") : Date.current.beginning_of_month
    raise InvalidRequest unless month.day == 1

    offices = Office.order(:name).to_a
    snapshots = (0..2).map do |offset|
      reporting_month = month.prev_month(offset)
      { month: reporting_month.strftime("%Y-%m"), clinics: report_month(offices, reporting_month) }
    end
    render json: { month: snapshots.first[:month], clinics: snapshots.first[:clinics], history: snapshots.drop(1) }
  end

  private

  def report_month(offices, month)
    visits = offices.reduce(Visit.none) do |scope, clinic|
      local_last_day = [ clinic.local_time(Time.current).to_date, month.end_of_month ].min
      scope.or(Visit.where(office: clinic, local_date: month..local_last_day))
    end
    outcomes = visits.group(:office_id, :source_status, :disposition).count
    monthly_visits = Visit.where(office: offices, local_date: month..month.end_of_month)
    deliveries = Delivery.sent.where(visit: monthly_visits).group(:office_id, :channel).count
    work = WorkItem.where(visit: monthly_visits)
    open = work.open.group(:office_id, :kind).count
    resolved = work.where.not(resolved_at: nil).group(:office_id, :kind).count

    offices.map do |clinic|
      counts = { completed: 0, rescheduled: 0, canceled: 0, unknown: 0 }
      outcomes.each do |(office_id, source_status, disposition), count|
        next unless office_id == clinic.id

        key = if source_status == "complete"
          :completed
        else
          { "rescheduled" => :rescheduled, "canceled" => :canceled }.fetch(disposition, :unknown)
        end
        counts[key] += count
      end
      {
        clinic: clinic.name, outcomes: counts, recorded: counts.values.sum,
        messages: { sms: deliveries.fetch([ clinic.id, "sms" ], 0), email: deliveries.fetch([ clinic.id, "email" ], 0) },
        work_open: by_kind(open, clinic.id), work_resolved: by_kind(resolved, clinic.id)
      }
    end
  end

  def by_kind(counts, id)
    counts.filter_map { |(office, kind), count| [ kind, count ] if office == id }.to_h
  end
end
