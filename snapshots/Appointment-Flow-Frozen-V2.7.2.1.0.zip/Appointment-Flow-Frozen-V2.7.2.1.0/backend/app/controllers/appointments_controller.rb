class AppointmentsController < ApplicationController
  LIMIT = 50

  def index
    staff
    date = params[:date].presence ? Date.iso8601(params[:date].to_s) : office.local_time(Time.current).to_date
    week = date.beginning_of_week..date.end_of_week
    day = office.visits.where(local_date: date)
    review_ids = ReplyCandidate.where(reply: Reply.where(office:, result: "review")).select(:visit_id)
    counts = {
      all: day.count, confirmed: day.where.not(confirmed_at: nil).count,
      unconfirmed: day.where(confirmed_at: nil).count, review: day.where(id: review_ids).count
    }

    page = [ params[:page].to_i, 1 ].max.clamp(1, [ (counts.fetch(filter).to_f / LIMIT).ceil, 1 ].max)
    shown = filter_appointments(day, review_ids).order(:wall_time, :id)
      .limit(LIMIT).offset((page - 1) * LIMIT).preload(:person).to_a
    review = ReplyCandidate.where(visit_id: shown.map(&:id), reply: Reply.where(office:, result: "review"))
      .distinct.pluck(:visit_id).to_set

    render json: {
      date:, days: office.visits.where(local_date: week).group(:local_date).count, counts:, page:, page_size: LIMIT,
      visits: shown.map { |visit| VisitSummary.for(visit, reply_review: review.include?(visit.id)).merge(patient: visit.person.name) },
      synced_at: office.synced_at, sync_error: office.sync_error
    }
  end

  private

  def filter
    params[:filter].to_s.to_sym.presence_in(%i[all confirmed unconfirmed review]) || :all
  end

  def filter_appointments(day, review_ids)
    case filter
    when :confirmed then day.where.not(confirmed_at: nil)
    when :unconfirmed then day.where(confirmed_at: nil)
    when :review then day.where(id: review_ids)
    else day
    end
  end
end
