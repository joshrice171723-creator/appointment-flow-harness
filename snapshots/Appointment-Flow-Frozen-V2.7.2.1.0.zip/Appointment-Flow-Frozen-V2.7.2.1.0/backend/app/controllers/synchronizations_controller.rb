class SynchronizationsController < ApplicationController
  def create
    staff
    if ClinicRefresh.new(office).call
      render json: { synced_at: office.synced_at }
    else
      render json: { error: office.sync_error, synced_at: office.synced_at }, status: :service_unavailable
    end
  end
end
