namespace :outreach do
  desc "Refresh and run fake reminders for all configured clinics (optional ISO8601 APEX_AT)"
  task reminders: :environment do
    now = ENV["APEX_AT"] ? Time.iso8601(ENV.fetch("APEX_AT")) : Time.current
    succeeded = true
    Office.order(:name).each do |office|
      result = ReminderBatch.new(office, now:).call
      if result
        puts "#{office.name}: #{result[:sent]} sent, #{result[:failed]} failed"
      else
        succeeded = false
        warn "#{office.name}: #{office.sync_error}"
      end
    end
    abort "A PMS refresh failed." unless succeeded
  end
end
