# Rubric results

Application revision `a5304169dcad1a0fd7fa24f7c66f65584e51c7ff`. Overall **PASS**. Codex implemented the rebuild. A separate Codex reviewer inspected the clean-room source and exercised the server with an isolated PostgreSQL database.

## First review and repair

At `935ee57` the grade was **REVISE**. The first configured gate exposed a calendar measurement taken from a cache and a concurrency test that attempted to nullify a required association during cleanup. The independent challenger also reproduced the following application defects.

- A clinic contact shared by a PMS patient outside the dispatch horizon did not block a send or a YES. The repaired eligibility check projects raw contacts from the selected clinic's current PMS patient ownership and compares the selected patient's current raw values with the snapshot. A later challenge that changed a phone between replica reads also passed after the comparison was added.
- A valid-looking SMS could confirm a moved visit after the prior outbound message aged out. The reply checks an earlier delivery revision for the same visit and recipient before accepting a bare YES.
- Adding 48 obsolete delivery revisions increased normal batch returned rows from 13 to 61 and records instantiated from 9 to 57. Scheduling now queries only current revisions. The same independent probe returned 14 rows and 9 instantiated records, with 20 statements, 0 affected rows and 21 response bytes both before and after growth.
- Starting work on an already resolved appointment returned success with the old resolved item. The endpoint now returns 409, and the patient screen removes the action on a confirmed visit.

## Final criterion results

| Criterion | Grade | Failure tested and evidence |
| --- | --- | --- |
| Required behavior | PASS | Real browser requests opened the front desk, ran the Phoenix fake batch (3 sent, 0 failed), submitted an SMS YES and a Spanish email YES linked to its outgoing message, and showed both visits in the calendar's Confirmed tab. Rails verifies dispatch, email fallback, attempts, skipped steps and reply replay. [Outreach tests](../backend/test/integration/outreach_test.rb) |
| Safety and data boundaries | PASS | The wrong clinic got 404 for inbox and staff mutations. A same-clinic shared address, a changed source contact, late YES, old-version YES, missing birthdate, and unverified minor did not create unsafe effects. STOP survived refresh. Source record updates through the runtime model were rejected. Leadership returned aggregate fields only for both clinics. [Outreach tests](../backend/test/integration/outreach_test.rb) · [Sync tests](../backend/test/integration/synchronizations_test.rb) · [Front-desk tests](../backend/test/integration/front_desk_test.rb) |
| Performance and Rails queries | PASS | See the complete HTTP measurements below. Calendar pagination returned the first 50 of 52 filtered results and the final 2 with no overlap. The reminder batch and app use standard Active Record relations, and current-revision history remained flat with 50 older delivery rows. |
| Material workflow coverage | PASS | POST refresh and reminders, GET work queues and calendar, GET patient detail, PATCH assignment and contact verification, POST staff follow-up and reply, GET inbox and GET leadership were traced through their resource actions and exercised by Rails tests or browser checks. The board found an exact last-name match, kept attempted contact open and closed confirmed work with one keyed audit entry. The React tests verify draft retention and same-key retry when the email HTTP response fails, and immediate clearing of the previous clinic's patient on clinic switch. [Front-desk tests](../backend/test/integration/front_desk_test.rb) · [React interaction tests](../frontend/src/App.test.tsx) |
| Human readability | PASS | The reviewer traced reminder HTTP and CLI callers to `ReminderBatch`, the clinic lock and source refresh to `ClinicRefresh`, current contact decisions to `ContactEligibility`, and reply and staff writes to their respective workflows. For example, the final-step rule has a single edit in `ReminderBatch::FINAL_DAYS`, applied in `select_step` before a fake attempt is prepared. [Reminder batch](../backend/app/services/reminder_batch.rb) |
| Ease of change | PASS | In a disposable worktree of `a530416`, changed `FINAL_DAYS` from 1 to 2 and moved the associated test clock one day earlier. `ruby bin/rails test test/integration/outreach_test.rb --include '/first_fake_SMS\|outside_the_sending/'` passed 2 tests and 32 assertions. The new final timing, unchanged initial text, skipped confirmation request and late-reply rejection were exercised. The patch changed one production file and one test file in the disposable copy. |
| Failure and transaction behavior | PASS | Renaming the demo replica appointments table caused a real refresh query error and returned 503 with the prior timestamp and snapshot intact. Throwing a fake transport error after refresh rolled back the clinic snapshot and staged effects. The independent reviewer raised immediately after the real staff-entry INSERT during the POST and observed an unchanged visit and work item plus no audit row. Separate connections running parallel batches persisted a single logical delivery. [Sync tests](../backend/test/integration/synchronizations_test.rb) · [Reminder workload tests](../backend/test/integration/reminder_workload_test.rb) · [Parallel batch test](../backend/test/integration/concurrent_reminders_test.rb) |
| Verification and handoff | PASS | From an empty PostgreSQL database, migrations alone served health and an empty clinic directory. The documented preparation and seed then exposed Austin and Phoenix, 96 visits and both fake transport channels. The Python demo command started Rails and Vite. On the final application revision the gate ran 22 Rails tests with 243 assertions, RuboCop across 63 files, Brakeman with zero warnings, React lint and types, 2 Vitest tests, and the Vite build. All seven checks succeeded. [README](../README.md) · [Configured gate](../quality/checks.json) |

## Measured HTTP workloads

Measurements came from `APEX_WORKLOAD=1 python quality/run_checks.py` on the application revision above. Setup and assertions ran outside the measured block. Database statements include transaction control. Rows are the adapter's counts, and payloads are the JSON bodies in bytes.

| Caller and fixture | Statements | Read rows | Model instances | Affected rows | Response bytes | Time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Calendar, one matching visit | 9 | 8 | 3 | 0 | 507 | 28.9 ms |
| Calendar, 800 out-of-scope rows added | 9 | 8 | 3 | 0 | 507 | 30.1 ms |
| Reminders, first eligible visit | 24 | 10 | 6 | 4 | 21 | 42.1 ms |
| Reminders, one retry | 20 | 14 | 9 | 0 | 21 | 41.9 ms |
| Reminders, retry with 600 unrelated appointments | 20 | 14 | 9 | 0 | 21 | 45.3 ms |
| Reminders, retry with 180 distinct clinic contact owners added | 20 | 194 | 9 | 0 | 21 | 57.9 ms |
| Reminders, 15 new eligible visits plus the prior visit | 51 | 284 | 69 | 45 | 22 | 187.9 ms |
| Reminders, repeat after 16 logical deliveries | 20 | 344 | 114 | 0 | 21 | 81.7 ms |
| Reminders, 50 obsolete revisions added to a current visit | 20 | 14 | 9 | 0 | 21 | 66.9 ms |

The calendar response was identical after adding 400 other-clinic rows on the selected day and 400 same-clinic rows outside its week. The batch counts were identical after adding irrelevant appointments with already-known contact owners, and retries wrote zero affected rows. The scalar ownership projection grows with distinct patients in the clinic because the supplied PMS stores unnormalized raw contacts. It transfers the candidate channels and ID, with no patient model materialization in that projection. PostgreSQL planned a hash join between appointments in the clinic and patient IDs for the small seeded demo. It chose a small table scan and sort for that demo's calendar and used the visit/revision/step index on delivery history. New eligible records require first-time patient and visit snapshot writes. Retries reused the same persisted delivery IDs. These timings are local samples.

## Independent regrade

The independent regrade ran 7 tests and 49 assertions with zero failures, errors or skips. It exercised both shared-recipient cases, older SMS after reschedule, a changed raw phone between source reads, retry history growth, the already-resolved work request, and staff audit rollback. The reviewed workflow blobs match `a530416`. The rule exercise and browser smoke also ran on that revision. Technical freeze retains the app and checks from this revision.
