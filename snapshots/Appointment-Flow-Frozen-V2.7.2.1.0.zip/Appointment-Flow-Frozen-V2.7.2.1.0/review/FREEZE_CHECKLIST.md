# Technical freeze

- [x] Application commit `a5304169dcad1a0fd7fa24f7c66f65584e51c7ff`.
- [x] Verified Ruby 3.4.10, Bundler 4.0.15, Rails 8.1.4.1, PostgreSQL 17.11, Node 24.19.0, npm 11.17.0, React 19.3.1, Vite 8.3.8, TypeScript 5.9.3, and Python 3.11.15.
- [x] Phase times and elapsed time are in the [build log](../notes/BUILD_LOG.md).
- [x] Fresh database migrations, demo seed and Rails/Vite startup verified locally.
- [x] Ran fake reminders from the Phoenix front desk. Observed 3 sent and 0 failed.
- [x] Confirmed seeded appointments through SMS and email in Chrome. Checked the resulting calendar and the leadership layout at 390 px.
- [x] Final gate passed all 7 checks, including 22 Rails tests with 243 assertions and 2 React tests.
- [x] Independent regrade passed 7 probes with 49 assertions. [Rubric and workload evidence](RUBRIC_RESULTS.md)
- [x] The candidate notes, architecture and AI usage record reflect the observed implementation.
- [x] The rebuild used the packaged clean-room inputs and a new local Git history.

Candidate-authored `DECISIONS.md` and the live defense remain Joshua's assessment work. Comparison and publication require separate authorization. The repository has no remote.
