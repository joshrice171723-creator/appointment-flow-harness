from pathlib import Path
import subprocess
import time


ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"


def main():
    subprocess.run(["ruby", "bin/rails", "db:prepare"], cwd=BACKEND, check=True)
    subprocess.run(["ruby", "bin/rails", "db:seed"], cwd=BACKEND, check=True)

    processes = []
    try:
        processes.append(subprocess.Popen(
            ["ruby", "bin/rails", "server", "-b", "127.0.0.1", "-p", "3000"], cwd=BACKEND,
        ))
        processes.append(subprocess.Popen(
            ["node", "node_modules/vite/bin/vite.js", "--strictPort", "--port", "5173"], cwd=FRONTEND,
        ))
        print("Open http://127.0.0.1:5173. Press Ctrl+C to stop the demo.", flush=True)
        while all(process.poll() is None for process in processes):
            time.sleep(0.5)
        raise SystemExit("A demo process exited. Check its output above.")
    except KeyboardInterrupt:
        pass
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
        for process in processes:
            process.wait()


if __name__ == "__main__":
    main()
