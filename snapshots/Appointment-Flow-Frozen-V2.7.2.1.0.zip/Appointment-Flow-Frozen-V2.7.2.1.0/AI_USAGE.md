# AI usage

OpenAI Codex implemented and verified the clean-room Rails and React application from the packaged assignment PDF, ten screenshots and sanitized product specifications. It used local Ruby, Node, PostgreSQL, test and browser tools, and the official Rails Active Record query guide. Optional skills and external review plugins were disabled. The implementation used a new local Git repository and fictional data.

Joshua required the packaged preflight to pass before application work and asked the agent to proceed with the rebuild. The agent recovered from tooling compatibility problems, corrected the demo state's PostgreSQL column width after a seed failure, and used uncached equivalent HTTP calls for the workload comparisons after the first measurement showed a query-cache artifact. A separate Codex reviewer used an isolated database to reproduce contact matching and reschedule defects, test staff rollback, and measure obsolete delivery history. The implementing agent repaired the confirmed findings and reran the gate. The build log and review evidence record the results and revisions.

This file records agent activity. Joshua owns the assessment's personal decisions and live defense. The agent supplied factual tradeoff notes in `notes/CANDIDATE_DECISION_NOTES.md`.
