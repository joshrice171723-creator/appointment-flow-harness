import { useState } from 'react'
import { clinicPath, useApi, type StaffSession, type SyncStatus, type Visit } from './api'
import { dateLabel, officeDate, shiftDate } from './format'
import { Notice, SyncLine, Tab, Tabs, VisitState, VisitTime } from './ui'

type Filter = 'all' | 'confirmed' | 'unconfirmed' | 'review'
type VisitPage = SyncStatus & {
  date: string; days: Record<string, number>; counts: Record<Filter, number>; page: number; page_size: number
  visits: (Visit & { patient: string })[]
}

const tabLabels: Record<Filter, string> = {
  all: 'All appointments', confirmed: 'Confirmed', unconfirmed: 'Unconfirmed', review: 'Replies to review',
}

export function Appointments({ session }: { session: StaffSession }) {
  const { office, name } = session
  const today = officeDate(office.timezone)
  const [date, setDate] = useState(today)
  const [filter, setFilter] = useState<Filter>('all')
  const [page, setPage] = useState(1)
  const { data, ...status } = useApi<VisitPage>(clinicPath(office, 'appointments?' + new URLSearchParams({
    date, filter, page: String(page),
  })), name)
  const weekday = new Date(date + 'T12:00:00Z').getUTCDay()
  const monday = shiftDate(date, -((weekday + 6) % 7))
  const days = Array.from({ length: 7 }, (_, offset) => shiftDate(monday, offset))

  function chooseDate(next: string) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(next)) return
    setDate(next)
    setPage(1)
  }

  return <main className="shell stack-lg">
    <div>
      <div className="page-heading">
        <div><div className="clinic-name">{office.name}</div><h1>Appointments</h1></div>
        <a className="button" href="#/front-desk/board">Open patient flow →</a>
      </div>
      {data && <SyncLine sync={data} office={office} />}
    </div>
    <section className="panel stack" aria-label="Appointment calendar">
      <div className="row">
        <button className="button" type="button" onClick={() => chooseDate(shiftDate(date, -7))}>← Previous week</button>
        <button className="button" type="button" onClick={() => chooseDate(today)}>Today</button>
        <button className="button" type="button" onClick={() => chooseDate(shiftDate(date, 7))}>Next week →</button>
      </div>
      <label>Jump to date<input type="date" value={date} onChange={(event) => chooseDate(event.target.value)} /></label>
      <div className="days">
        {days.map((day) => <button type="button" className="button day" key={day}
          aria-pressed={day === date} onClick={() => chooseDate(day)}>
          {dateLabel(day)}{data && <small className="muted">{data.days[day] ?? 0} {data.days[day] === 1 ? 'visit' : 'visits'}</small>}
        </button>)}
      </div>
    </section>
    <Tabs>
      {(Object.keys(tabLabels) as Filter[]).map((tab) => <Tab key={tab} active={tab === filter}
        onClick={() => { setFilter(tab); setPage(1) }}>{tabLabels[tab]}{data && <span>{data.counts[tab]}</span>}</Tab>)}
    </Tabs>
    <Notice {...status} />
    {data && <section className="panel stack" aria-label="Visits for the selected day">
      {data.visits.length ? <div className="table-wrap"><table>
        <thead><tr><th>Patient</th><th>Appointment · {office.timezone}</th><th>Confirmation or reply</th><th>PMS outcome</th><th>Follow-up</th></tr></thead>
        <tbody>
          {data.visits.map((visit) => <tr key={visit.id}>
            <td><a href={'#/front-desk/patients/' + visit.person_id}><strong>{visit.patient}</strong></a><small>Appointment #{visit.source_id}</small></td>
            <td><VisitTime visit={visit} office={office} /><small>{[visit.provider_name, visit.length_minutes && visit.length_minutes + ' min'].filter(Boolean).join(' · ')}</small></td>
            <td><VisitState visit={visit} /></td>
            <td>{visit.outcome}</td>
            <td>{visit.disposition ? <span className="badge">{visit.disposition}</span> :
              <a href={'#/front-desk/patients/' + visit.person_id}>Review follow-up →</a>}</td>
          </tr>)}
        </tbody>
      </table></div> : <p>No appointments match this date and filter.</p>}
      {data.counts[filter] > data.page_size && <div className="row between">
        <p className="small">{(data.page - 1) * data.page_size + 1}–{Math.min(data.counts[filter], data.page * data.page_size)} of {data.counts[filter]}</p>
        <div className="row">
          <button className="button compact" type="button" disabled={data.page <= 1} onClick={() => setPage(data.page - 1)}>Previous page</button>
          <button className="button compact" type="button" disabled={data.page * data.page_size >= data.counts[filter]} onClick={() => setPage(data.page + 1)}>Next page</button>
        </div>
      </div>}
    </section>}
  </main>
}
