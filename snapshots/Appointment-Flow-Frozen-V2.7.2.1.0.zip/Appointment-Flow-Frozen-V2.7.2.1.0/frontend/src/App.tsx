import { useState, useSyncExternalStore } from 'react'
import { useApi, type Office, type StaffSession } from './api'
import { Appointments } from './Appointments'
import { Board } from './Board'
import { Inbox } from './Inbox'
import { Leadership } from './Leadership'
import { PatientDetails } from './PatientDetails'
import { Notice, OfficeSelect } from './ui'

function subscribeToLocation(callback: () => void) {
  window.addEventListener('hashchange', callback)
  return () => window.removeEventListener('hashchange', callback)
}

function currentPath() {
  return window.location.hash.slice(1) || '/'
}

export function App() {
  const path = useSyncExternalStore(subscribeToLocation, currentPath)
  const { data: offices, ...status } = useApi<Office[]>('/offices')
  const [selection, setSelection] = useState(() => ({
    officeId: sessionStorage.getItem('apex.office'),
    staff: sessionStorage.getItem('apex.staff'),
  }))
  const office = offices?.find((item) => String(item.id) === selection.officeId)
  const session = office && selection.staff && office.staff.includes(selection.staff)
    ? { office, name: selection.staff }
    : undefined

  function openFrontDesk(next: StaffSession) {
    const officeId = String(next.office.id)
    setSelection({ officeId, staff: next.name })
    sessionStorage.setItem('apex.office', officeId)
    sessionStorage.setItem('apex.staff', next.name)
    window.location.hash = '/front-desk/board'
  }

  const inFrontDesk = path.startsWith('/front-desk/')
  const patientId = path.match(/^\/front-desk\/patients\/(\d+)$/)?.[1]

  if (path === '/patient' && offices) return <Inbox offices={offices} />

  return <>
    <Header path={path} frontDesk={Boolean(inFrontDesk && session)} />
    {!offices && <main className="shell"><Notice {...status} /></main>}
    {offices && path === '/' && <Workspaces offices={offices} onOpen={openFrontDesk} current={session} />}
    {offices && path === '/leadership' && <Leadership />}
    {offices && inFrontDesk && !session && <main className="shell stack">
      <h1>Front desk</h1><p>Choose a clinic and staff member from <a href="#/">Workspaces</a>.</p>
    </main>}
    {inFrontDesk && session && <>
      {path === '/front-desk/board' && <Board key={session.office.id} session={session} />}
      {path === '/front-desk/appointments' && <Appointments key={session.office.id} session={session} />}
      {patientId && <PatientDetails key={session.office.id + ':' + patientId} session={session} personId={patientId} />}
    </>}
    {offices && !inFrontDesk && !['/', '/patient', '/leadership'].includes(path) &&
      <main className="shell stack"><h1>Page unavailable</h1><a href="#/">Return to Workspaces</a></main>}
  </>
}

function Header({ path, frontDesk }: { path: string; frontDesk: boolean }) {
  return <header className="topbar">
    <a className="brand" href="#/" aria-label="Apex Appointment Flow workspaces">
      <span className="brand-mark" aria-hidden="true"><span>A<sup>↗</sup></span></span>
      <span><span className="brand-name">APEX</span><span className="brand-subtitle">Appointment Flow</span></span>
    </a>
    <nav className="nav" aria-label="Workspace navigation">
      {frontDesk && <>
        <a href="#/front-desk/board" aria-current={path === '/front-desk/board' ? 'page' : undefined}>Patient flow</a>
        <a href="#/front-desk/appointments" aria-current={path === '/front-desk/appointments' ? 'page' : undefined}>Appointments</a>
      </>}
      {path === '/leadership' && <a href="#/leadership" aria-current="page">Apex leadership</a>}
      <a href="#/" aria-current={path === '/' ? 'page' : undefined}>Workspaces <span aria-hidden="true">↗</span></a>
    </nav>
  </header>
}

function Workspaces({ offices, onOpen, current }: {
  offices: Office[]; onOpen: (session: StaffSession) => void; current?: StaffSession
}) {
  const [clinic, setClinic] = useState(String(current?.office.id ?? offices[0]?.id ?? ''))
  const [staff, setStaff] = useState(current?.name ?? '')
  const office = offices.find((item) => String(item.id) === clinic)
  const name = office?.staff.includes(staff) ? staff : office?.staff[0] ?? ''
  return <main className="shell landing">
    <h1>Workspaces</h1>
    {offices.length === 0 && <p className="notice">Load the demo seed to open a clinic workspace.</p>}
    <div className="workspaces">
      <section className="panel workspace">
        <div>
          <h2 className="serif">Front desk</h2>
          <p className="muted">Review appointments and follow up with patients.</p>
        </div>
        <div className="workspace-form">
          <OfficeSelect offices={offices} value={clinic} onChange={(value) => { setClinic(value); setStaff('') }} />
          <label>Staff member
            <select value={name} disabled={!office} onChange={(event) => setStaff(event.target.value)}>
              {!office && <option value="">Choose a clinic first</option>}
              {office?.staff.map((member) => <option key={member}>{member}</option>)}
            </select>
          </label>
        </div>
        <button className="button primary" disabled={!office || !name}
          onClick={() => office && onOpen({ office, name })}>Open front desk <span aria-hidden="true">→</span></button>
      </section>
      <section className="panel workspace workspace-featured">
        <div>
          <h2 className="serif">Apex leadership</h2>
          <p className="muted">Compare appointment outcomes across clinics.</p>
        </div>
        <div className="metric"><strong>{offices.length}</strong><span className="muted small">Reporting clinics</span></div>
        <a className="button primary" href="#/leadership">Open Apex leadership <span aria-hidden="true">→</span></a>
      </section>
      <section className="panel workspace">
        <div>
          <h2 className="serif">Patient</h2>
          <p className="muted">Read simulated text and email reminders and send test replies.</p>
        </div>
        <a className="button primary" href="#/patient">Open patient workspace <span aria-hidden="true">→</span></a>
      </section>
    </div>
  </main>
}
