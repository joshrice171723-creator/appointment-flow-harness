export const workLabels: Record<string, string> = {
  hold: 'Reminders blocked',
  delivery: 'Delivery failed',
  no_reply: 'No confirmation yet',
  reply: 'Reply needs review',
}

export function officeDate(timezone: string) {
  return new Intl.DateTimeFormat('sv-SE', { timeZone: timezone }).format(new Date())
}

export function shiftDate(date: string, days: number) {
  const value = new Date(date + 'T12:00:00Z')
  value.setUTCDate(value.getUTCDate() + days)
  return value.toISOString().slice(0, 10)
}

export function dateLabel(date: string) {
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC',
  }).format(new Date(date + 'T12:00:00Z'))
}

export function timestamp(value: string, timezone: string) {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: timezone,
  }).format(new Date(value))
}

export function monthLabel(month: string) {
  return new Intl.DateTimeFormat('en-US', {
    month: 'long', year: 'numeric', timeZone: 'UTC',
  }).format(new Date(month + '-01T12:00:00Z'))
}
