import { useEffect, useState } from 'react'

export interface Office {
  id: number
  name: string
  timezone: string
  staff: string[]
}

export interface SyncStatus {
  synced_at: string | null
  sync_error: string | null
}

export interface PersonChoice { id: number; name: string }

export interface Visit {
  id: number
  source_id: number
  person_id: number
  local_date: string
  starts_at: string | null
  wall_time: string
  provider_name: string | null
  length_minutes: number | null
  confirmed: boolean
  outcome: string
  disposition: string | null
  reply_review: boolean
  revision: number
}

export interface WorkItem {
  id: number
  kind: string
  detail: string
  person_id: number
  patient: string
  assigned_to: string | null
  resolved_at: string | null
  visit: Visit | null
  reply?: { body: string; candidates: (Visit & { patient: string; eligible: boolean })[] } | null
}

export interface StaffSession { office: Office; name: string }

interface RequestOptions {
  staff?: string
  method?: 'POST' | 'PATCH'
  body?: object
  signal?: AbortSignal
}

export async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers = new Headers({ Accept: 'application/json' })
  if (options.body) headers.set('Content-Type', 'application/json')
  if (options.staff) headers.set('X-Demo-Staff', options.staff)
  const response = await fetch('/api' + path, {
    headers,
    method: options.method,
    body: options.body ? JSON.stringify(options.body) : undefined,
    signal: options.signal,
  })
  if (!response.ok) {
    const data: unknown = await response.json().catch(() => null)
    if (typeof data === 'object' && data !== null && 'error' in data && typeof data.error === 'string') {
      throw new Error(data.error)
    }
    throw new Error('The request could not be completed. Try again.')
  }
  return response.json()
}

export function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Something went wrong. Try again.'
}

type Result<T> = { key: string; data?: T; error?: string }

export function useApi<T>(path: string | null, staff?: string, revision = 0) {
  const [result, setResult] = useState<Result<T>>({ key: '' })
  const key = JSON.stringify([path, staff, revision])
  useEffect(() => {
    if (path === null) return
    const controller = new AbortController()
    void request<T>(path, { staff, signal: controller.signal }).then(
      (data) => setResult({ key, data }),
      (error: unknown) => {
        if (!controller.signal.aborted) setResult({ key, error: errorMessage(error) })
      },
    )
    return () => controller.abort()
  }, [key, path, staff])
  const current = result.key === key ? result : undefined
  return { data: current?.data, error: current?.error, loading: path !== null && current === undefined }
}

export function clinicPath(office: Office, resource: string) {
  return '/offices/' + office.id + '/' + resource
}
