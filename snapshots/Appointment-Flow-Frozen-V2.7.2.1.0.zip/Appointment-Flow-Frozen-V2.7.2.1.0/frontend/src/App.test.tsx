import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { App } from './App'

const offices = [
  { id: 10, name: 'Austin', timezone: 'America/Chicago', staff: ['Jordan'] },
  { id: 20, name: 'Phoenix', timezone: 'America/Phoenix', staff: ['Morgan'] },
]

afterEach(() => {
  cleanup()
  vi.unstubAllGlobals()
  sessionStorage.clear()
  history.replaceState({}, '', '/')
})

describe('Patient inbox', () => {
  it('sends an email reply using the selected message and retains the draft and key if the response is lost', async () => {
    history.replaceState({}, '', '/#/patient')
    const submissions: object[] = []
    const handler = vi.fn(async (url: string, options: RequestInit) => {
      if (url === '/api/offices') return Response.json(offices)
      if (url.includes('patient_choices')) return Response.json([{ id: 72, name: 'Mia Ramos' }])
      if (url.endsWith('channel=sms')) return Response.json({ can_reply: true, messages: [] })
      if (url.endsWith('channel=email')) return Response.json({
        can_reply: true,
        messages: [{ id: 4, direction: 'reminder', body: 'Email reminder', at: '2026-11-16T17:00:00Z' }],
      })
      if (url.endsWith('/replies')) {
        submissions.push(JSON.parse(String(options.body)))
        if (submissions.length === 1) throw new Error('Connection closed')
        return Response.json({ result: 'confirmed' })
      }
      throw new Error('Unexpected request ' + url)
    })
    vi.stubGlobal('fetch', handler)
    render(<App />)

    fireEvent.change(await screen.findByLabelText('Clinic'), { target: { value: '10' } })
    fireEvent.change(await screen.findByLabelText('Patient', { exact: true }), { target: { value: '72' } })
    expect(await screen.findByText('No simulated text messages for this patient yet.')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Email' }))
    expect(await screen.findByText('Email reminder', { selector: 'p' })).toBeTruthy()
    fireEvent.change(screen.getByLabelText('Reply to'), { target: { value: '4' } })
    fireEvent.change(screen.getByLabelText('Your reply'), { target: { value: 'yes' } })
    fireEvent.click(screen.getByRole('button', { name: 'Send reply' }))
    expect(await screen.findByRole('alert')).toHaveProperty('textContent', 'Connection closed Your reply was kept. You can retry the same reply.')
    expect(screen.getByLabelText('Your reply')).toHaveProperty('value', 'yes')
    fireEvent.click(screen.getByRole('button', { name: 'Send reply' }))
    expect(await screen.findByText('Appointment confirmed.')).toBeTruthy()
    expect(submissions).toHaveLength(2)
    expect(submissions[0]).toMatchObject({ body: 'yes', channel: 'email', delivery_id: '4', event_key: expect.any(String) })
    expect(submissions[1]).toEqual(submissions[0])
  })

  it('removes the previous clinic patient immediately while a new clinic loads', async () => {
    history.replaceState({}, '', '/#/patient')
    const handler = vi.fn(async (url: string) => {
      if (url === '/api/offices') return Response.json(offices)
      if (url.includes('/10/')) return Response.json([{ id: 72, name: 'Mia Ramos' }])
      if (url.includes('/20/')) return Response.json([{ id: 85, name: 'Owen Ramos' }])
      throw new Error('Unexpected request ' + url)
    })
    vi.stubGlobal('fetch', handler)
    render(<App />)

    const clinic = await screen.findByLabelText('Clinic')
    fireEvent.change(clinic, { target: { value: '10' } })
    expect(await screen.findByRole('option', { name: 'Mia Ramos' })).toBeTruthy()
    fireEvent.change(clinic, { target: { value: '20' } })
    expect(screen.queryByRole('option', { name: 'Mia Ramos' })).toBeNull()
    await waitFor(() => expect(screen.getByRole('option', { name: 'Owen Ramos' })).toBeTruthy())
  })
})
