import { useState } from 'react'
import { clinicPath, errorMessage, request, useApi, type StaffSession, type SyncStatus, type WorkItem } from './api'
import { workLabels } from './format'
import { Notice, SyncLine, Tab, Tabs, VisitTime } from './ui'

type QueueName = 'attention' | 'in_progress' | 'resolved'
type Queue = { page: number; total: number; page_size: number; items: WorkItem[] }
type BoardData = SyncStatus & { counts: Record<QueueName, number>; queues: Partial<Record<QueueName, Queue>> }

const labels: Record<QueueName, string> = {
  attention: 'Needs attention', in_progress: 'In progress', resolved: 'Resolved',
}

export function Board({ session }: { session: StaffSession }) {
  const { office, name } = session
  const [view, setView] = useState<'active' | 'resolved'>('active')
  const [search, setSearch] = useState('')
  const [kind, setKind] = useState('')
  const [pageSize, setPageSize] = useState('10')
  const [pages, setPages] = useState({ attention: 1, in_progress: 1, resolved: 1 })
  const [revision, refresh] = useState(0)
  const [busy, setBusy] = useState('')
  const [feedback, setFeedback] = useState('')
  const [error, setError] = useState('')
  const filters = new URLSearchParams({
    view, search, kind, page_size: pageSize, attention_page: String(pages.attention),
    progress_page: String(pages.in_progress), resolved_page: String(pages.resolved),
  })
  const { data, ...status } = useApi<BoardData>(clinicPath(office, 'work_items?' + filters), name, revision)

  function resetPages() {
    setPages({ attention: 1, in_progress: 1, resolved: 1 })
  }

  async function run(action: 'synchronization' | 'reminder_runs') {
    setBusy(action)
    setError('')
    setFeedback('')
    try {
      if (action === 'synchronization') {
        await request(clinicPath(office, action), { method: 'POST', staff: name, body: {} })
        setFeedback('PMS refresh complete.')
      } else {
        const result = await request<{ sent: number; failed: number }>(clinicPath(office, action), {
          method: 'POST', staff: name, body: {},
        })
        setFeedback(`Fake reminder run finished · ${result.sent} sent · ${result.failed} failed`)
      }
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      refresh((value) => value + 1)
      setBusy('')
    }
  }

  return <main className="shell stack-lg">
    <div>
      <div className="page-heading">
        <div><div className="clinic-name">{office.name}</div><h1>Patient flow</h1></div>
        <div className="muted">{name} · {office.timezone}</div>
      </div>
      {data && <SyncLine sync={data} office={office} />}
    </div>
    {data && <div className="summary-grid">
      {(Object.keys(labels) as QueueName[]).map((queue) => <div className="panel metric" key={queue}>
        <span className="muted small">{labels[queue]}</span><strong>{data.counts[queue]}</strong>
      </div>)}
    </div>}
    <div className="row">
      <button type="button" className="button" disabled={!!busy} onClick={() => void run('synchronization')}>
        {busy === 'synchronization' ? 'Refreshing…' : 'Refresh PMS'}
      </button>
      <button type="button" className="button primary" disabled={!!busy} onClick={() => void run('reminder_runs')}>
        {busy === 'reminder_runs' ? 'Running…' : 'Run fake reminders'}
      </button>
    </div>
    {feedback && <p className="notice" role="status">{feedback}</p>}
    {error && <Notice error={error} />}
    <Tabs>
      <Tab active={view === 'active'} onClick={() => setView('active')}>Active work</Tab>
      <Tab active={view === 'resolved'} onClick={() => setView('resolved')}>Resolved</Tab>
      <a className="small" href="#/front-desk/appointments">All appointments →</a>
    </Tabs>
    <div className="row">
      <label>Find a patient
        <input type="search" value={search} onChange={(event) => { setSearch(event.target.value); resetPages() }} />
      </label>
      <label>Follow-up type
        <select value={kind} onChange={(event) => { setKind(event.target.value); resetPages() }}>
          <option value="">All follow-up types</option>
          {Object.entries(workLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
        </select>
      </label>
      <label>Per queue
        <select value={pageSize} onChange={(event) => { setPageSize(event.target.value); resetPages() }}>
          {[10, 20, 40].map((size) => <option key={size}>{size}</option>)}
        </select>
      </label>
    </div>
    <Notice {...status} />
    {data && <div className={view === 'active' ? 'board' : ''}>
      {(Object.keys(labels) as QueueName[]).map((key) => {
        const queue = data.queues[key]
        return queue && <section className={'queue stack ' + (key === 'in_progress' ? 'in-progress' : '')} key={key}>
          <div className="row between"><h2>{labels[key]}</h2><span className="badge">{queue.total}</span></div>
          {queue.total > 0 && <div className="row between">
            <span className="small muted">{(queue.page - 1) * queue.page_size + 1}–{Math.min(queue.total, queue.page * queue.page_size)} of {queue.total}</span>
            <div className="row">
              <button type="button" className="button compact" disabled={queue.page === 1}
                onClick={() => setPages({ ...pages, [key]: queue.page - 1 })}>Previous</button>
              <button type="button" className="button compact" disabled={queue.page * queue.page_size >= queue.total}
                onClick={() => setPages({ ...pages, [key]: queue.page + 1 })}>Next</button>
            </div>
          </div>}
          {queue.items.length === 0 && <p className="small muted">No matching work items.</p>}
          {queue.items.map((item) => <a className="panel work-card" href={'#/front-desk/patients/' + item.person_id} key={item.id}>
            <div className="row between"><span className={'badge ' + item.kind}>{workLabels[item.kind]}</span><span aria-hidden="true">↗</span></div>
            <span className="work-title">{item.patient}</span>
            <p className="muted small">{item.detail}</p>
            {item.visit && <p className="small"><VisitTime visit={item.visit} office={office} /></p>}
            <div className="work-owner small">{item.assigned_to || (item.resolved_at ? 'Resolved' : 'Unassigned')}</div>
          </a>)}
        </section>
      })}
    </div>}
  </main>
}
