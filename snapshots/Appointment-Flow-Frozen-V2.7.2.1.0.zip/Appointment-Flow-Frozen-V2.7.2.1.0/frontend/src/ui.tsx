import type { ReactNode } from 'react'
import type { Office, SyncStatus, Visit } from './api'
import { timestamp } from './format'

export function Notice({ error, loading }: { error?: string; loading?: boolean }) {
  if (error) return <p className="notice error" role="alert">{error}</p>
  if (loading) return <p className="notice" role="status">Loading…</p>
  return null
}

export function Tabs({ children }: { children: ReactNode }) {
  return <div className="tabs">{children}</div>
}

export function Tab({ active, children, onClick }: {
  active: boolean; children: ReactNode; onClick: () => void
}) {
  return <button type="button" className="tab" aria-pressed={active} onClick={onClick}>{children}</button>
}

export function OfficeSelect({ offices, value, onChange }: {
  offices: Office[]; value: string; onChange: (value: string) => void
}) {
  return <label>Clinic
    <select value={value} onChange={(event) => onChange(event.target.value)}>
      <option value="">Choose a clinic</option>
      {offices.map((office) => <option key={office.id} value={office.id}>{office.name}</option>)}
    </select>
  </label>
}

export function SyncLine({ sync, office }: { sync: SyncStatus; office: Office }) {
  return <>
    <p className="muted small">Last PMS sync · {sync.synced_at ? timestamp(sync.synced_at, office.timezone) : 'Waiting for first sync'} · {office.timezone}</p>
    {sync.sync_error && <Notice error={sync.sync_error} />}
  </>
}

export function VisitTime({ visit, office }: { visit: Visit; office: Office }) {
  return <>{visit.starts_at ? timestamp(visit.starts_at, office.timezone) : 'Appointment time needs review'}</>
}

export function VisitState({ visit }: { visit: Visit }) {
  if (visit.reply_review) return <span className="badge reply">Reply needs review</span>
  return <span className={'badge ' + (visit.confirmed ? 'confirmed' : '')}>
    {visit.confirmed ? 'Confirmed' : 'Unconfirmed'}
  </span>
}
