import { useState, type FormEvent } from 'react'
import { clinicPath, errorMessage, request, useApi, type StaffSession, type SyncStatus, type Visit, type WorkItem } from './api'
import { timestamp, workLabels } from './format'
import { Notice, SyncLine, Tab, Tabs, VisitState, VisitTime } from './ui'

type Contact = { value: string | null; source: string | null; verified: boolean; conflict: boolean }
type Activity = { id: number; action: string; note: string; author: string; at: string }
type PatientData = SyncStatus & {
  id: number; name: string; contacts: Record<string, Contact>; visits: Visit[]
  next_visit: Visit | null; work: WorkItem[]; activity: Activity[]
}

const contactLabels: Record<string, string> = {
  birthdate: 'Birthdate', wireless_phone: 'Mobile phone', email: 'Email', preferred_language: 'Preferred language',
}

const outcomeLabels: Record<string, string> = {
  attempted: 'Contact attempted', confirmed: 'Confirmed by staff', rescheduled: 'Rescheduled',
  canceled: 'Canceled', reviewed: 'Reviewed · no change to appointment', verified: 'Contact verified',
}

export function PatientDetails({ session, personId }: { session: StaffSession; personId: string }) {
  const [revision, setRevision] = useState(0)
  const [tab, setTab] = useState<'follow-up' | 'visits' | 'activity'>('follow-up')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const { office, name } = session
  const path = clinicPath(office, 'patients/' + personId)
  const { data, ...status } = useApi<PatientData>(path, name, revision)

  function saved(text: string) {
    setMessage(text)
    setRevision((value) => value + 1)
  }

  async function openFollowUp(visit: Visit) {
    setBusy(true)
    setError('')
    try {
      await request(clinicPath(office, 'work_items'), { method: 'POST', staff: name, body: { visit_id: visit.id } })
      setTab('follow-up')
      saved('Follow-up opened.')
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setBusy(false)
    }
  }

  const open = data?.work.filter((item) => !item.resolved_at) ?? []
  const resolved = data?.work.filter((item) => !!item.resolved_at) ?? []
  return <main className="shell stack-lg">
    <a className="small" href="#/front-desk/board">← Patient flow / {office.name}</a>
    <Notice {...status} />
    {message && <p role="status" className="notice">{message}</p>}
    {error && <Notice error={error} />}
    {data && <>
      <div>
        <div className="page-heading">
          <div><div className="clinic-name">{office.name}</div><h1>{data.name}</h1></div>
          {open.length > 0 && <span className="badge hold">{open.length} open follow-up{open.length > 1 ? 's' : ''}</span>}
        </div>
        <SyncLine sync={data} office={office} />
      </div>
      <section className="row between">
        <div>
          <h3>Next scheduled appointment</h3>
          <p>{data.next_visit ? <VisitTime visit={data.next_visit} office={office} /> : 'No upcoming appointment recorded.'}</p>
        </div>
        {data.next_visit && !data.next_visit.confirmed && <button type="button" className="button" disabled={busy || open.some((item) => item.visit?.id === data.next_visit?.id)}
          onClick={() => { if (data.next_visit) void openFollowUp(data.next_visit) }}>
          {busy ? 'Opening…' : 'Start appointment follow-up'}
        </button>}
      </section>
      <div className="person-grid">
        <section className="panel stack">
          <h2>Patient details</h2>
          {Object.entries(data.contacts).map(([field, contact]) =>
            <ContactField key={field} field={field} contact={contact} path={path} staff={name} onSaved={saved} />)}
        </section>
        <div className="stack">
          <Tabs>
            <Tab active={tab === 'follow-up'} onClick={() => setTab('follow-up')}>Follow-up <span>{open.length}</span></Tab>
            <Tab active={tab === 'visits'} onClick={() => setTab('visits')}>Appointments</Tab>
            <Tab active={tab === 'activity'} onClick={() => setTab('activity')}>Activity log</Tab>
          </Tabs>
          {tab === 'follow-up' && <section className="panel stack-lg">
            <h2>Follow-up items</h2>
            {open.length === 0 && <p>No open follow-up items.</p>}
            {open.map((item) => <FollowUp key={item.id} item={item} session={session} onSaved={saved} />)}
            <details className="follow-up">
              <summary>Resolved follow-up records ({resolved.length})</summary>
              <div className="stack">
                {resolved.length === 0 && <p>No resolved records.</p>}
                {resolved.map((item) => <div key={item.id}>
                  <span className={'badge ' + item.kind}>{workLabels[item.kind]}</span>
                  <p>{item.detail} {item.resolved_at && <small>· {timestamp(item.resolved_at, office.timezone)}</small>}</p>
                </div>)}
              </div>
            </details>
          </section>}
          {tab === 'visits' && <section className="panel stack">
            <h2>Appointment history</h2>
            {data.visits.length === 0 && <p>No appointments recorded.</p>}
            {data.visits.map((visit) => <div className="row between follow-up" key={visit.id}>
              <div><VisitTime visit={visit} office={office} /><p className="small muted">Appointment #{visit.source_id} · {visit.provider_name || 'Provider unavailable'}</p></div>
              <div className="row"><VisitState visit={visit} /><span>{visit.outcome}</span></div>
            </div>)}
          </section>}
          {tab === 'activity' && <section className="panel stack">
            <h2>Activity log</h2>
            {data.activity.length === 0 && <p>No staff activity recorded.</p>}
            {data.activity.map((entry) => <div className="follow-up wrap" key={entry.id}>
              <strong>{outcomeLabels[entry.action] ?? entry.action}</strong>
              <p>{entry.note}</p>
              <small className="muted">{entry.author} · {timestamp(entry.at, office.timezone)}</small>
            </div>)}
          </section>}
        </div>
      </div>
    </>}
  </main>
}

function ContactField({ field, contact, path, staff, onSaved }: {
  field: string; contact: Contact; path: string; staff: string; onSaved: (message: string) => void
}) {
  const [editing, setEditing] = useState(false)
  const [value, setValue] = useState(contact.value ?? '')
  const [key, setKey] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const label = contactLabels[field] ?? field

  async function save(event: FormEvent) {
    event.preventDefault()
    const eventKey = key || crypto.randomUUID()
    setKey(eventKey)
    setError('')
    setBusy(true)
    try {
      await request(path + '/contact_verification', { method: 'PATCH', staff, body: { field, value, event_key: eventKey } })
      onSaved('Contact verification saved.')
    } catch (failure) {
      setError(errorMessage(failure) + ' Your entry was kept.')
    } finally {
      setBusy(false)
    }
  }

  return <div className="contact-field wrap">
    <div className="row between">
      <div>
        <div className="small muted">{label}</div>
        <strong>{contact.value || 'No value on file'}</strong>
      </div>
      {!editing && <button type="button" className="button compact" onClick={() => setEditing(true)} aria-label={'Verify ' + label.toLowerCase()}>Verify</button>}
    </div>
    <span className={'badge ' + (contact.conflict ? 'hold' : contact.verified ? 'confirmed' : '')}>
      {contact.conflict ? 'PMS change needs review' : contact.verified ? 'Verified locally' : 'Not verified'}
    </span>
    {(contact.conflict || (contact.verified && contact.source !== contact.value)) &&
      <p className="small muted">PMS value · {contact.source || 'No value on file'}</p>}
    {editing && <form className="stack follow-up" onSubmit={save}>
      <label>{label}
        <input type={field === 'birthdate' ? 'date' : field === 'email' ? 'email' : field === 'wireless_phone' ? 'tel' : 'text'}
          value={value} disabled={busy} maxLength={254} onChange={(event) => { setValue(event.target.value); setKey('') }} />
      </label>
      {field === 'preferred_language' && <small className="muted">Use en for English or es for Spanish.</small>}
      {error && <Notice error={error} />}
      <div className="row">
        <button className="button primary compact" disabled={busy}>{busy ? 'Saving…' : 'Save verification'}</button>
        <button className="button compact" type="button" disabled={busy} onClick={() => setEditing(false)}>Cancel</button>
      </div>
    </form>}
  </div>
}

function FollowUp({ item, session, onSaved }: {
  item: WorkItem; session: StaffSession; onSaved: (message: string) => void
}) {
  const [outcome, setOutcome] = useState('attempted')
  const [note, setNote] = useState('')
  const [visitIds, setVisitIds] = useState<number[]>([])
  const [key, setKey] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const path = clinicPath(session.office, 'work_items/' + item.id)
  const needsSelection = item.reply && ['confirmed', 'rescheduled', 'canceled'].includes(outcome)

  async function assign() {
    setError('')
    setBusy(true)
    try {
      await request(path + '/assignment', { method: 'PATCH', staff: session.name, body: {} })
      onSaved('Follow-up assigned to you.')
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setBusy(false)
    }
  }

  async function save(event: FormEvent) {
    event.preventDefault()
    const eventKey = key || crypto.randomUUID()
    setKey(eventKey)
    setError('')
    setBusy(true)
    try {
      await request(path + '/follow_ups', { method: 'POST', staff: session.name,
        body: { outcome, note, event_key: eventKey, visit_ids: needsSelection ? visitIds : [] } })
      onSaved('Follow-up saved.')
    } catch (failure) {
      setError(errorMessage(failure) + ' Your draft was kept. You can retry this save.')
    } finally {
      setBusy(false)
    }
  }

  return <article className="follow-up stack">
    <div className="row between">
      <span className={'badge ' + item.kind}>{workLabels[item.kind]}</span>
      <small>{item.assigned_to ? 'Assigned to ' + item.assigned_to : 'Unassigned'}</small>
    </div>
    <p>{item.detail}</p>
    {item.visit && <p className="small muted">Appointment #{item.visit.source_id} · <VisitTime visit={item.visit} office={session.office} /></p>}
    {item.reply && <blockquote>{item.reply.body}</blockquote>}
    {error && <Notice error={error} />}
    {!item.assigned_to && <div>
      <button type="button" className="button primary compact" disabled={busy} onClick={() => void assign()}>Assign to me</button>
    </div>}
    {item.assigned_to === session.name && <form className="stack" onSubmit={save}>
      <label>Outcome
        <select value={outcome} disabled={busy} onChange={(event) => { setOutcome(event.target.value); setKey('') }}>
          {Object.entries(outcomeLabels).filter(([name]) => name !== 'verified' && (name !== 'reviewed' || item.reply))
            .map(([name, label]) => <option key={name} value={name}>{label}</option>)}
        </select>
      </label>
      {needsSelection && <fieldset><legend>Appointments confirmed by your conversation</legend>
        {item.reply?.candidates.length ? item.reply.candidates.map((visit) => {
          const current = visit.eligible
          return <label className="check" key={visit.id}>
            <input type="checkbox" checked={visitIds.includes(visit.id)} disabled={busy || !current}
              onChange={(event) => {
                setVisitIds(event.target.checked ? [...visitIds, visit.id] : visitIds.filter((id) => id !== visit.id))
                setKey('')
              }} />
            {visit.patient} · <VisitTime visit={visit} office={session.office} />{!current && ' · Appointment changed or passed'}
          </label>
        }) : <p>No matching appointment was found. Choose Reviewed to close without changing a visit.</p>}
      </fieldset>}
      <label>Follow-up note
        <textarea required value={note} maxLength={500} disabled={busy} onChange={(event) => { setNote(event.target.value); setKey('') }} />
      </label>
      <div><button className="button primary" disabled={busy || !note.trim() || (!!needsSelection && !visitIds.length)}>
        {busy ? 'Saving…' : 'Save follow-up'}
      </button></div>
    </form>}
  </article>
}
