import { useState, type FormEvent } from 'react'
import { clinicPath, errorMessage, request, useApi, type Office, type PersonChoice } from './api'
import { timestamp } from './format'
import { Notice, OfficeSelect, Tab, Tabs } from './ui'

type Channel = 'sms' | 'email'
type Message = { id: number; body: string; at: string; direction: 'reminder' | 'reply' }
type ConversationData = { messages: Message[]; can_reply: boolean }

export function Inbox({ offices }: { offices: Office[] }) {
  const [clinic, setClinic] = useState('')
  const office = offices.find((item) => String(item.id) === clinic)

  return <main className="shell inbox">
    <a className="small" href="#/">← Workspaces</a>
    <h1>Patient inbox</h1>
    <div className="stack-lg">
      <OfficeSelect offices={offices} value={clinic} onChange={setClinic} />
      {office && <PatientPicker key={office.id} office={office} />}
    </div>
  </main>
}

function PatientPicker({ office }: { office: Office }) {
  const [search, setSearch] = useState('')
  const [patient, setPatient] = useState('')
  const [channel, setChannel] = useState<Channel>('sms')
  const { data: people, ...status } = useApi<PersonChoice[]>(clinicPath(office, 'patient_choices?search=' + encodeURIComponent(search)))
  const selected = people?.find((person) => String(person.id) === patient)

  return <>
    <label>Find a demo patient
      <input type="search" value={search} onChange={(event) => { setSearch(event.target.value); setPatient('') }} />
    </label>
    <Notice {...status} />
    {people && <label>Patient
      <select value={patient} onChange={(event) => { setPatient(event.target.value); setChannel('sms') }}>
        <option value="">{people.length ? 'Choose a patient' : 'No matching patients'}</option>
        {people.map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}
      </select>
    </label>}
    {selected && <div className="stack">
      <Tabs>
        <Tab active={channel === 'sms'} onClick={() => setChannel('sms')}>Text messages</Tab>
        <Tab active={channel === 'email'} onClick={() => setChannel('email')}>Email</Tab>
      </Tabs>
      <Conversation key={selected.id + channel} office={office} patient={selected.id} channel={channel} />
    </div>}
  </>
}

function Conversation({ office, patient, channel }: { office: Office; patient: number; channel: Channel }) {
  const base = clinicPath(office, 'patients/' + patient)
  const [revision, refresh] = useState(0)
  const { data, ...status } = useApi<ConversationData>(base + '/conversation?channel=' + channel, undefined, revision)
  const [body, setBody] = useState('')
  const [messageId, setMessageId] = useState('')
  const [eventKey, setEventKey] = useState('')
  const [saving, setSaving] = useState(false)
  const [outcome, setOutcome] = useState('')
  const [error, setError] = useState('')

  async function send(event: FormEvent) {
    event.preventDefault()
    if (saving) return
    const key = eventKey || crypto.randomUUID()
    setEventKey(key)
    setSaving(true)
    setError('')
    setOutcome('')
    try {
      const result = await request<{ result: string }>(base + '/replies', {
        method: 'POST', body: { body, channel, event_key: key, delivery_id: messageId || undefined },
      })
      setOutcome({
        confirmed: 'Appointment confirmed.',
        opted_out: 'Text messages stopped for this number at this clinic.',
        review: 'Reply recorded for front-desk review.',
      }[result.result] ?? 'Reply recorded.')
      setEventKey('')
      setBody('')
      refresh((value) => value + 1)
    } catch (failure) {
      setError(errorMessage(failure) + ' Your reply was kept. You can retry the same reply.')
    } finally {
      setSaving(false)
    }
  }

  const messages = data?.messages ?? []
  return <div className="stack">
    <Notice {...status} />
    {data && (messages.length > 0 ? <>
      <h2 className="serif">Message history</h2>
      <div className="messages">
        {messages.map((item) => <article className={'message ' + item.direction} key={item.direction + item.id}>
          <div className="muted small">{item.direction === 'reply' ? 'Your reply' : 'Clinic reminder'} · {timestamp(item.at, office.timezone)}</div>
          <p>{item.body}</p>
        </article>)}
      </div>
    </> : <p>{channel === 'email' ? 'No simulated emails for this patient yet.' : 'No simulated text messages for this patient yet.'}</p>)}
    {data?.can_reply && <form className="panel stack" onSubmit={send}>
      {channel === 'email' && <label>Reply to
        <select value={messageId} disabled={saving} onChange={(event) => { setMessageId(event.target.value); setEventKey('') }}>
          <option value="">Choose an email to confirm a visit</option>
          {messages.filter((item) => item.direction === 'reminder').map((item) =>
            <option key={item.id} value={item.id}>{timestamp(item.at, office.timezone)} · {item.body.slice(0, 80)}</option>)}
        </select>
      </label>}
      <label>Your reply
        <textarea required maxLength={1000} value={body} disabled={saving}
          onChange={(event) => { setBody(event.target.value); setEventKey('') }} />
      </label>
      <div><button className="button primary" disabled={saving || !body.trim()}>{saving ? 'Sending…' : 'Send reply'}</button></div>
    </form>}
    {data && !data.can_reply && <p className="muted">This patient has no usable contact for this channel.</p>}
    {error && <Notice error={error} />}
    {outcome && <p className="notice" role="status">{outcome}</p>}
  </div>
}
