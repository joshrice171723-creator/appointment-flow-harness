import { useState, type CSSProperties } from 'react'
import { useApi } from './api'
import { monthLabel, workLabels } from './format'
import { Notice } from './ui'

type Outcome = 'completed' | 'rescheduled' | 'canceled' | 'unknown'
type ClinicReport = {
  clinic: string; outcomes: Record<Outcome, number>; recorded: number
  messages: { sms: number; email: number }; work_open: Record<string, number>; work_resolved: Record<string, number>
}
type MonthReport = { month: string; clinics: ClinicReport[] }
type Report = MonthReport & { history: MonthReport[] }

const outcomes: { key: Outcome; label: string; color: string }[] = [
  { key: 'completed', label: 'Completed', color: '#2d725e' },
  { key: 'rescheduled', label: 'Rescheduled', color: '#557a95' },
  { key: 'canceled', label: 'Canceled', color: '#a9543f' },
  { key: 'unknown', label: 'Unknown', color: '#8d9991' },
]

function percentage(value: number, total: number) {
  return total ? (value / total * 100).toFixed(1) + '%' : '—'
}

export function Leadership() {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7))
  const { data, ...status } = useApi<Report>('/leadership_report?month=' + encodeURIComponent(month))

  return <main className="shell stack-lg">
    <div className="page-heading">
      <h1>Appointment outcomes</h1>
      <label>Outcome month<input type="month" value={month} onChange={(event) => { if (event.target.value) setMonth(event.target.value) }} /></label>
    </div>
    <Notice {...status} />
    {data && <>
      <section className="panel stack">
        <h2 className="serif">{monthLabel(data.month)}</h2>
        <div className="report-grid">
          {data.clinics.map((clinic) => <article key={clinic.clinic}>
            <div className="row between"><h3>{clinic.clinic}</h3><span className="muted small">{clinic.recorded} recorded visits</span></div>
            <div className="outcome-bar" aria-hidden="true">
              {outcomes.map(({ key, color }) => <span key={key}
                style={{ '--outcome-color': color, flexGrow: clinic.outcomes[key] } as CSSProperties} />)}
            </div>
            <div className="outcome-legend">
              {outcomes.map(({ key, label, color }) => <div key={key}>
                <span className="legend-dot" style={{ '--outcome-color': color } as CSSProperties} />{label}
                <strong>{clinic.outcomes[key]} <small className="muted">{percentage(clinic.outcomes[key], clinic.recorded)}</small></strong>
              </div>)}
            </div>
          </article>)}
        </div>
      </section>
      <section className="panel stack">
        <div className="row between">
          <h2 className="serif">Clinic comparison</h2>
          <details className="small">
            <summary>How rates are calculated</summary>
            <p>Completion rate is completed PMS visits divided by recorded visits through the clinic’s current date. Rescheduled and canceled counts use staff outcomes when the PMS has no completion. Unknown outcomes cannot identify no-shows.</p>
          </details>
        </div>
        <div className="table-wrap"><table>
          <thead><tr><th>Clinic</th><th>Completion rate</th><th>Recorded visits</th><th>Rescheduled</th><th>Canceled</th><th>Unknown</th></tr></thead>
          <tbody>{data.clinics.map((clinic) => <tr key={clinic.clinic}>
            <td><strong>{clinic.clinic}</strong></td>
            <td>{percentage(clinic.outcomes.completed, clinic.recorded)}<small>{clinic.outcomes.completed} completed</small></td>
            <td>{clinic.recorded}</td><td>{clinic.outcomes.rescheduled}</td><td>{clinic.outcomes.canceled}</td><td>{clinic.outcomes.unknown}</td>
          </tr>)}</tbody>
        </table></div>
      </section>
      <details className="panel">
        <summary>Monthly history and reminder activity</summary>
        <p className="small muted">Successful fake sends grouped by appointment month, including upcoming visits.</p>
        <div className="table-wrap"><table>
          <thead><tr><th>Month</th><th>Clinic</th><th>Completed / recorded</th><th>Texts sent</th><th>Emails sent</th></tr></thead>
          <tbody>{[data, ...data.history].flatMap((period) => period.clinics.map((clinic) => <tr key={period.month + clinic.clinic}>
            <td>{monthLabel(period.month)}</td><td>{clinic.clinic}</td><td>{clinic.outcomes.completed} / {clinic.recorded}</td>
            <td>{clinic.messages.sms}</td><td>{clinic.messages.email}</td>
          </tr>))}</tbody>
        </table></div>
      </details>
      <details className="panel">
        <summary>Contact holds</summary>
        <p className="small muted">Follow-up records linked to visits in the selected month.</p>
        <div className="table-wrap"><table>
          <thead><tr><th>Clinic</th><th>Open holds</th><th>Resolved holds</th></tr></thead>
          <tbody>{data.clinics.map((clinic) => <tr key={clinic.clinic}>
            <td>{clinic.clinic}</td><td>{clinic.work_open.hold ?? 0}</td><td>{clinic.work_resolved.hold ?? 0}</td>
          </tr>)}</tbody>
        </table></div>
      </details>
      <details className="panel">
        <summary>Contact and follow-up</summary>
        <p className="small muted">Work records are counted once by appointment month. Replies count here when linked to a single appointment.</p>
        <div className="table-wrap"><table>
          <thead><tr><th>Clinic</th><th>Follow-up type</th><th>Open</th><th>Resolved</th></tr></thead>
          <tbody>{data.clinics.flatMap((clinic) => Object.entries(workLabels).map(([key, label]) => <tr key={clinic.clinic + key}>
            <td>{clinic.clinic}</td><td>{label}</td><td>{clinic.work_open[key] ?? 0}</td><td>{clinic.work_resolved[key] ?? 0}</td>
          </tr>))}</tbody>
        </table></div>
      </details>
    </>}
  </main>
}
