# Architecture

```mermaid
flowchart LR
    PMS["PostgreSQL PMS replica"] -->|"Scoped read"| Refresh["ClinicRefresh"]
    Refresh --> Snapshot["Clinic, patient and visit snapshots"]
    Staff["React front desk"] -->|"Clinic + demo staff"| Rails["Rails resource endpoints"]
    Inbox["React patient inbox"] -->|"Fake replies"| Rails
    Lead["React leadership"] -->|"Grouped outcomes only"| Rails
    Rails --> Snapshot
    Rails --> Workflow["ReminderBatch, ReplyProcessing, StaffFollowUp"]
    Workflow --> Snapshot
    Workflow --> Ledger["Fake deliveries, replies, suppressions, tasks and staff entries"]
    Ledger --> Rails
```

The assignment's PMS tables live in the `pms` schema. Migrations set up that demo schema. Only the seed and test fixture writers modify it. Runtime Rails source models are read-only. Local data in `public` holds the last good PMS snapshot and app-owned facts. The batch refreshes today's date through the next seven clinic-local days and rechecks tracked scheduled IDs in that window, including appointments moved outside it. Staff refresh covers two previous months, the current month and the following month. A missing tracked visit rejects the refresh before any snapshots change.

The per-office row lock orders refreshes, batches, replies, local corrections, and staff follow-up. The fake transport returns an outcome with no external side effect. Attempts and work are committed together with the refreshed clinic snapshot. A unique index on visit, revision and step is the final duplicate-send guard. An external transport would need durable provider idempotency and reconciliation for unknown outcomes.

```mermaid
stateDiagram-v2
    [*] --> Unconfirmed: Scheduled PMS visit
    Unconfirmed --> Confirmed: Clear linked YES or staff verification
    Unconfirmed --> Review: Unclear, stale, late or NO reply
    Confirmed --> Review: Later conflicting reply creates work
    Review --> Confirmed: Staff selects a current visit
    Review --> Unconfirmed: Staff closes review without confirmation
    Confirmed --> Unconfirmed: New version after slot or patient change
    Unconfirmed --> Closed: PMS closes visit or staff records disposition
    Confirmed --> Closed: PMS closes visit or staff records disposition
```

Review is a parallel work record. An existing confirmation survives a later unclear reply and stays visible when the PMS marks the same slot complete. Same-row appointment moves start a fresh revision. A separate PMS appointment ID has its own history. SMS requires exactly one visit revision in the recent conversation and a unique eligible recipient. A prior SMS for an older revision of the same visit prevents automatic confirmation on that thread, even after the old message leaves the lookback. Email requires the selected message. Exact SMS STOP creates a durable clinic/channel/address suppression. Shared contact matches can be reviewed by a staff member. Guarantor messaging is held for human verification.

Recipient checks include the office's current PMS contact owners even outside the dispatch horizon. The supplied replica has raw text contacts, so the app selects only IDs and the candidate channels from people with appointments at that clinic. It checks the current raw candidate values against the refresh snapshot and normalizes the projected fields for ownership comparison. This scan grows with distinct clinic patient records. Delivery history for scheduling queries only current visit revisions.

Internally, event instants use UTC. Office rows carry IANA timezone IDs. Source wall time is retained for reconciliation; the app separately stores the interpreted UTC instant. DST gaps and repeated hours trigger a hold. Reporting counts observed PMS completions, staff dispositions and unknown outcomes for recorded visits through the clinic's current date.

Local demo identities are scoped server-side by clinic. The names are public fictional selectors. Production would require authenticated identities, verified clinic grants, a database role restricted to SELECT on the PMS, provider signature verification, explicit channel consent, and operational auditing and retention policies.
