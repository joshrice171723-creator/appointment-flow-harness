# Apex Appointment Flow

A Rails and React take-home demo for appointment confirmations. Front desk staff can see upcoming visits and record follow-up. The patient inbox simulates texts and emails. Apex leadership sees outcome totals for Austin and Phoenix.

## Run locally

Verified runtime targets are Ruby 3.4.10, Bundler 4.0.15, Rails 8.1.4.1, PostgreSQL 17.11, Node 24.19.0, npm 11.17.0, React 19.3.1, and Python 3.10 or later. Use PostgreSQL client tools from the same major version as the server. The seed supplies the demo clinic directory and scheduling data.

Create empty `apex_flow_development` and `apex_flow_test` databases. The default connection is `127.0.0.1:55432` as `apex`. Set `APEX_DB_HOST`, `APEX_DB_PORT`, `APEX_DB_USER`, and, if needed, `APEX_DB_PASSWORD` for a different local instance.

For a disposable PostgreSQL instance, put its binaries on PATH and run these commands from the project root. On Windows the existing install used `C:\PostgreSQL\17\bin`.

```text
initdb -D tmp/postgres -U apex --auth=trust --encoding=UTF8 --locale=C
pg_ctl -D tmp/postgres -l tmp/postgres.log -o "-h 127.0.0.1 -p 55432" start
createdb -h 127.0.0.1 -p 55432 -U apex apex_flow_development
createdb -h 127.0.0.1 -p 55432 -U apex apex_flow_test
```

Use the loopback-only disposable instance for fictional data. Run `bundle install` from `backend` and `npm ci` from `frontend`. Run the following command from the project root.

```text
python scripts/demo.py
```

Open the [local workspaces](http://127.0.0.1:5173). The script prepares and seeds the development database, runs Rails on port 3000, and starts Vite on port 5173. Press Ctrl+C to stop both. The seed derives visit dates from the first run. It preserves the sample clinic records on subsequent runs.

## Exercise the workflows

1. Open the Austin front desk and choose Jordan or Taylor. Use Patient flow to assign a task, record an attempted call, or save the outcome of a staff conversation. Appointments shows the selected clinic's calendar and separate confirmation and PMS outcome columns.
2. Use **Refresh PMS** for an explicit clinic refresh and **Run fake reminders** to run the live clock through the reminder rules. A repeat run for the same step reports zero new dispatches. A clinic can send from 10 AM to 6 PM local time, with 6 PM excluded.
3. Open the Patient workspace, choose Austin and **Mia Ramos**, and send `YES` from **Text messages**. For email, choose **Leo Vega**, open **Email**, select a message under **Reply to**, and send `YES`. The seeded messages come from the same fake reminder path. Both visits are five clinic-local days after the initial seed. Confirmed visits appear in the front-desk Confirmed tab on that day. The inbox shows successfully delivered fake messages and inbound replies. Failed attempts remain inspectable in front-desk work and the local database.
4. Try `NO` or an unclear reply to see a review item. An exact SMS `STOP` suppresses that clinic's future texts to the number. The leadership workspace shows only clinic totals and their definitions.

To exercise the batch independently, run `ruby bin/rails outreach:reminders` from `backend`. Set `APEX_AT` to an ISO 8601 instant with an offset to simulate a different time for that invocation. The normal app uses the real clock.

Inspect the fake provider's delivery ledger with `ruby bin/rails console` in `backend`. The following query shows delivery status and timing.

```ruby
Delivery.order(:attempted_at, :id).pluck(:channel, :step, :status, :attempted_at)
```

## Verify

Leave PostgreSQL running with both databases present. From the root run `python quality/run_checks.py`. The configured gate runs Rails tests, RuboCop, Brakeman, React lint and type checking, Vitest, and the Vite build. From `backend`, run `ruby bin/rails test` for Rails alone. Set `APEX_WORKLOAD=1` to print the workload counters for the calendar and reminder-run tests.

The harness input verification was run before scaffolding. Its manifest includes starter copies of the build log and completion checklist. To reproduce preflight, check out the original harness input checkpoint, `9641ff9`, into a disposable Git worktree and run `python quality/verify_harness.py` there.

See [Architecture](ARCHITECTURE.md), [AI usage](AI_USAGE.md), [decision notes](notes/CANDIDATE_DECISION_NOTES.md), and [review evidence](review/RUBRIC_RESULTS.md). The assessment asks Joshua to author `DECISIONS.md` in his own words.
