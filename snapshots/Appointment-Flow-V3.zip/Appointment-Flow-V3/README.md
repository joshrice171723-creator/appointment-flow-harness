# Apex Appointment Flow — independent V3 rebuild

Rails + React/TypeScript + PostgreSQL. Fictional patients, local fake SMS/email only. This is an assessment demo, not a deployed clinical service. The supplied V3 harness and ten visual references were the only product inputs; no other implementation was inspected.

## Start on Windows

Prerequisites: Ruby 3.4, Rails 8.1 dependencies, Node 24, Python 3, PostgreSQL 17 binaries. `POSTGRES_BIN` may point to another PostgreSQL bin directory. Default is `C:\Program Files\PostgreSQL\17\bin`. Ports 5543 (database), 3105 (Rails), 5175 (Vite) must be free.

From this directory:

```powershell
cd backend
ruby -S bundle config set --local path vendor/bundle
ruby -S bundle install
cd ..
python scripts/dev.py
```

Dependencies install under this project rather than changing the system Ruby gems. The startup script installs the locked frontend dependencies with `npm ci` when absent, initializes an isolated database under `.runtime/postgres`, prepares both databases, seeds an empty development database, and starts both servers. It does not touch an existing PostgreSQL service. Open **http://127.0.0.1:5175**. Ctrl+C stops the two application servers; PostgreSQL stays available for console/checks. Stop only this project's cluster using:

```powershell
& "$env:ProgramFiles\PostgreSQL\17\bin\pg_ctl.exe" -D .runtime/postgres stop
```

The cluster uses trust authentication on loopback for local fictional data. Do not expose its port or reuse this configuration for real data. Standard PGHOST/PGPORT/PGUSER/PGPASSWORD variables can point Rails at an independently provisioned database, but the startup script always manages its own local cluster.

## Exercise the workflows

- **Front desk:** select Austin or Phoenix and a demo staff member. Inspect Patient flow, search and type filters, Active/Resolved tabs and pagination. Open a patient, assign work, record a required note and outcome. Attempted contact stays open; Confirmed updates the current visit; canceled/rescheduled outcomes stop local outreach without writing the PMS. Source status is shown separately.
- **Appointments:** previous/next week, day buttons and date jump select a clinic-local date. Confirmation tabs filter the table; Patient details opens follow-up and history.
- **Patient:** choose a clinic and patient, then Text messages or Email. Type YES to confirm, NO/unclear text for review, or exact STOP to suppress SMS. The simulator associates a reply with the latest message in that channel. Shared contacts, multiple future visits, stale versions and late replies require staff clarification. The picker is a simulation of provider identity, not authentication.
- **Leadership:** choose an appointment month; inspect outcome counts, comparison and expandable activity/hold/follow-up summaries. API responses contain aggregate values only. Completed / recorded visits is not a no-show rate or proof of reminder impact. For this demo `complete` maps to completed, `broken` to canceled, `unscheduled` to rescheduled, everything else to unknown. These mappings need PMS-owner validation.
- **Contact corrections:** change a field and provide a verification note. Local values and original PMS values remain inspectable. Corrections are audited; later source changes create a conflict that blocks outreach until reviewed. Permissions are seeded explicit local assumptions, never inferred from the existence of a phone number. Minors and unknown birthdates are held for staff; automatic guardian routing is deliberately excluded until authorization is established.

Seeds include two clinics, sixteen fictional patients and thirty-two appointments, missing/invalid contacts, unsupported language, no-reply follow-up and historical outcomes. Dates are relative to seed day, with deterministic identities/scenario structure. `db:prepare` seeds only an empty database. Do not run `db:seed` over populated data; it intentionally refuses duplicate source creation. Use a separately named empty database for a fresh demo.

## Reminder and reply simulation

The **Run reminders** button refreshes PMS and processes only the chosen clinic. Global command-line batch:

```powershell
cd backend
ruby bin/rails reminders:run
# Optional explicit instant, inside the clinic-local 10:00–18:00 window:
$env:AT = '2026-11-15T17:00:00Z'
$env:FAIL_SMS = '1'
ruby bin/rails reminders:run
Remove-Item Env:AT, Env:FAIL_SMS
```

Use an instant appropriate to your seed dates. A failed SMS remains recorded and permitted email is still attempted; repeated runs do not retry that logical attempt. No external service is contacted. Inspect accepted/failed attempts in the patient inbox and staff Activity log. `fake_accepted` is database acceptance, never evidence of delivery. For unattended operation a local scheduler can invoke this task periodically; no worker, Redis or scheduler daemon is required by this demo.

Cadence: both permitted channels at seven days, three days and one day before the visit. Missed steps coalesce to the current step; no catch-up burst. Confirmation suppresses further requests; the final step is informational. The source timestamp is a clinic wall-clock value: Austin uses America/Chicago; Phoenix uses America/Phoenix. Ambiguous/nonexistent DST times are held. No messages at or after start.

Simulate a change made externally in the PMS:

```powershell
ruby bin/rails 'demo:move[101,2026-11-25T15:00:00]'
```

Then Refresh PMS or run reminders. This explicitly named simulator and database seeds are the only source-writing paths. Runtime PMS models reject record writes; app-owned snapshots, contact facts, confirmations and history are separate. A changed time/status generates a new revision, including when a time changes back. The previous confirmation and old replies cannot apply to it. Empty, missing-row or failed refreshes preserve the prior snapshot and prevent outreach. STOP is recorded independently of refresh, against the message's actual recipient.

## Verification

Start the app first for the real-backend browser test, then in another terminal:

```powershell
python quality/run_checks.py
```

The configured gate runs Rails Minitest, eager loading, RuboCop, Brakeman, Ruby/npm advisory scans, ESLint/React Hooks, strict TypeScript, React behavioral tests, production build and Playwright using installed Microsoft Edge. No browser download is needed. Test databases are isolated from development. Advisory checks need network access to public package advisory databases. The concurrency test explicitly truncates only the test database, then races two database connections. Browser tests use the running Rails API and fictional development data and may confirm Morgan Demo. Repeat runs remain idempotent.

Individual commands from backend: `ruby bin/rails test`, `ruby -S bundle exec rubocop`, `ruby -S bundle exec brakeman --no-pager`. From frontend: `npm run lint`, `npm run typecheck`, `npm test`, `npm run build`, `npm run smoke`. If the RubyMine host exports NPM_CONFIG_ALLOW_SCRIPTS, remove that variable for project installs; scripts/dev.py handles it without changing global config. Dependency security audit results and exact checks are in review/VERIFICATION.md.

## Where to change a rule

`backend/app/models/reminder_batch.rb` owns cadence and fake attempts. `receive_reply.rb` owns reply matching and opt-outs. `pms_refresh.rb` owns snapshot/version/timezone interpretation. `contact.rb` owns safe contact eligibility; `follow_up.rb` owns staff resolutions. Controllers select a demo role/clinic and handle HTTP. React screens own their local drafts and cancel obsolete reads. See ARCHITECTURE.md for transaction and lifecycle diagrams.

Known boundaries: authentication is a header-based demo stub, not authorization suitable for deployment; shared contact handling is conservative; guardian authorization and live transport are excluded; source replication can lag about five minutes; a complete-looking but stale replica cannot be detected without a producer watermark. Any new clinic needs explicit timezone configuration. All-source refresh and one serialization lock favor clarity over throughput and require measurement before rollout. Missing-row refresh fails closed and requires investigating the replica, rather than silently deleting work. Production must add real access controls, database SELECT-only PMS credentials, signed provider callbacks, transport outbox/reconciliation, secrets/data protection and a reliable replica watermark before using actual data.

`DECISIONS.md` is reserved for Joshua's own narrative. AI-authored implementation facts and alternatives are in notes/CANDIDATE_DECISION_NOTES.md. No push, submission or comparison with other implementations is authorized or performed.
