# Architecture

```mermaid
flowchart LR
  PMS[Read-only replicated PMS tables] --> Refresh[PmsRefresh: atomic snapshot + local time conversion]
  Refresh --> Visits[(Local contacts and visit revisions)]
  React[React workspaces] --> API[Rails scoped HTTP controllers]
  API --> Visits
  CLI[Periodic/manual reminder task] --> Batch[ReminderBatch]
  API --> Batch
  Batch --> Refresh
  Batch --> History[(Fake message attempts)]
  Inbox[Patient reply simulator] --> Reply[ReceiveReply]
  Reply --> History
  Reply --> Visits
  Reply --> OptOut[(Clinic and recipient SMS suppression)]
  API --> Aggregates[Leadership: aggregate whitelist]
```

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: current source revision
  Unconfirmed --> Confirmed: exact YES / safe identity or staff note
  Unconfirmed --> Review: ambiguous, stale, late, NO or failed contact
  Review --> Confirmed: staff clarifies specific current appointment
  Review --> Review: attempted contact
  Unconfirmed --> Stopped: staff canceled/rescheduled or PMS no longer scheduled
  Confirmed --> Stopped: source no longer scheduled
  Confirmed --> Unconfirmed: new source time/status revision
  Stopped --> Unconfirmed: new source revision
```

Rails ActiveRecord owns ordinary persistence, without repositories, an event bus or worker infrastructure. A single RefreshState row lock and repeatable-read transaction enclose refresh and dependent writes. Database uniqueness protects logical attempts, inbound events and staff request IDs. Serialization conflicts retry at most three times; only database-local fake effects occur in those transactions. This is not an external delivery transaction. Real vendor integration would require an outbox, provider idempotency and uncertain-outcome reconciliation.

The replicated assessment schema is preserved in clinics/patients/appointments. Runtime read models report readonly; seeds and the explicitly named external-PMS simulator use SQL. Production needs separate SELECT-only credentials to enforce the boundary independently of Ruby. Local visits keep the raw source snapshot and a monotonic revision identity; source identity reassignment fails closed rather than transferring message history to a different patient/clinic. Patient local verification retains original source provenance. Permission assumptions and opt-outs stay local and source refresh never resets them.

Global command-line reminders process all clinics. The staff endpoint filters reminder decisions by its selected clinic. Staff and patient queries scope every contact lookup server-side. Leadership has a distinct role-checked endpoint and returns no patient objects, messages or contact facts. Headers are explicit demo identity stubs; they must be replaced by authenticated server-side clinic memberships before deployment.

Clinic wall-clock timestamps use explicit IANA mappings and TZInfo periods; ambiguous/missing local instants block rather than guess. App-owned instants use UTC. Confirmation is independent of source outcome. Reporting states the source mapping and denominator and makes no causal claim.

React uses ordinary components for Workspaces, Staff, PatientDetails, Inbox and Leadership. There is no global store or custom lifecycle hook. Reads cancel on selection changes and ignore aborted results. Write drafts remain on rejection; stable event/request IDs make retry safe. Assignment preserves unrelated edits. Successful writes are shown separately from subsequent refresh failures. Browser tests exercise the real backend; unit UI tests stub responses to intentionally reorder reads and reject saves.
