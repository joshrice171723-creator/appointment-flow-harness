# Authorized inputs

Archive: Apex_Clean_Room_V3_RubyMine_Harness_UPDATED.zip, supplied by Joshua.
SHA-256: 6060b158ae5d62e6cfe602c7c9c3eecdf06031159469e5ffe71ac9fa6c6dcfcc

The initial supplied verify_harness.py passed before application code: manifest, PDF, ten PNG signatures/count. The V3 variant verifier also passed after implementation. Source authority: official five-page PDF, then sanitized specs, then screenshots for visible states. Prior application source, repositories, histories, notes and cross-version comparisons were not consulted. No memory files were read.

Harness guidance/specifications/reference inputs remain included. Build log, candidate notes, freeze checklist and .gitignore are intentionally maintained during development; the original archive manifest describes the input archive, not the finished application's changed files. Final code provenance is its independent Git commit and lockfiles. Comparison remains unauthorized.
