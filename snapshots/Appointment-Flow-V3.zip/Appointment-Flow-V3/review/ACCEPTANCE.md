# Acceptance evidence and limits

Official application paths are implemented: source appointment selection, fake SMS/email cadence, recorded confirmation, clinic-scoped staff dashboard, seeds/local startup/tests and documentation. Personal DECISIONS narrative remains candidate-owned and unfinished; human acceptance/live defense are not claimed.

Automated domain/request evidence: test/models/confirmation_test.rb covers matching YES, email-only, stale/rescheduled/recreated appointment versions, conflicting NO, late replies, STOP during source failure and phone changes, delivery failure, retries, source loss, unsafe age/language/permissions, local windows/DST, verified corrections and preserved audit values. test/models/concurrency_test.rb races two real database connections. test/integration/workspaces_test.rb covers cross-clinic access rejection, scoped staff batches, aggregate response whitelist and idempotent/validated follow-up saves.

UI behavioral evidence: App.test.tsx and PatientDetails.test.tsx use stubbed HTTP responses to cover clinic selection, reordered reads, assignment/contact draft preservation and rejected follow-up saves. These tests do not establish database persistence.

Browser evidence: e2e/workflows.spec.ts uses real Rails/PostgreSQL, runs reminders, submits SMS/email YES, reloads staff state, checks persisted confirmation, opens leadership and verifies patient names absent, and captures desktop/mobile views. It does not cover every filter, pagination boundary, contact verification, follow-up outcome, ambiguous shared-family clarification or browser-level network failure. Source and backend tests support those implemented paths where named above; unexercised UI interactions remain unverified in the browser.

Source boundaries: no live provider or asynchronous delivery-event endpoint exists. Fake acceptance and failed attempts are atomic database events; send/reply idempotency is tested, not a real provider's delivery guarantee. Guardian automation is held rather than guessed. Full authentication, deployment and booking/rescheduling UI are deliberately out of scope. Source freshness needs a producer watermark before a real rollout. No claims about measured capacity, no-show reduction, comprehensive accessibility or human maintainability acceptance are made.

Visual evidence is broad layout/color/workspace identity from the ten supplied screenshots. Desktop leadership and 390px workspace images were inspected; no pixel-perfect comparison or prior source comparison occurred.
