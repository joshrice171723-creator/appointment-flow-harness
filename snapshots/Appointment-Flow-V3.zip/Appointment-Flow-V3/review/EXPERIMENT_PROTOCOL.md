# Controlled V2 / V3 / V4 harness experiment

## What changes and what stays fixed

- **V2:** Original clean-room harness, published quality rules, automated checks, and an independent reviewer.
- **V3:** Same product spec, screenshots, assignment and baseline quality workflow, **plus task-specific Rails and frontend coding guidance**; remove formal code-quality rubric scoring/review criteria.
- **V4:** Same as V3 with a V4-only **structured evidence-based independent review** using Rails and frontend rubrics.

## Isolation

Each version must be extracted into its **own fresh directory**, used with a **different new repository**, and finished without browsing, cloning, searching, reading or importing source or history from V1, V2 or other runs. The old GitHub repository is a comparison baseline **only after each variant is frozen**. Do not configure old Git remotes or let agents search sibling projects. The user's former code is not included in any ZIP.

To compare versions, keep the implementation model/agent version, environment, time budget, task acceptance inputs, and validation suite as similar as practical. Record deviations; don't claim a causal win if many variables changed. Run the same acceptance tests against each finished version. Evaluate maintainability through a blind human reviewer where possible, separately from V4's development review.

The V4 rubrics should **not** be fed to the implementing agent as a new design specification. The independent reviewer applies them after the implementation phase, allowing the additional effect of formal review to be measured.

## Freeze criteria

Freeze and record each version's commit, dependencies and checks run **before** opening previous implementations. If a version is not runnable, note the blocker and compare only supported dimensions. Never auto-push or auto-merge.
