# V3 independent defect review

A separate Codex reviewer session followed agent-prompts/03_INDEPENDENT_REVIEW.md. It read the current new-project source and relevant guides; no scores, quality rubric, previous source or comparison was used. Reviewer ran no checks; execution evidence belongs to the implementation session.

Confirmed findings and fixes:

- receive_reply.rb: valid STOP depended on PMS refresh. STOP now persists before refresh, and its regression deliberately removes a tracked source appointment.
- receive_reply.rb: STOP could suppress the new phone after a source change. It now uses the original message recipient; the regression asserts old-number suppression and no new-number suppression.
- workspaces_controller.rb/reminder_batch.rb: selected-clinic staff button ran a global batch. Endpoint passes clinic_id; a request regression checks Phoenix messages/tasks remain untouched by Austin's run.
- workspaces_controller.rb: verification merged a Contact loaded before the lock. It now reloads inside the serialization lock.
- reminder_batch.rb: corrected contacts left obsolete holds open. Eligibility reevaluation resolves those holds; regression asserts messages can proceed and old hold resolves.
- PatientDetails.tsx: assignment discarded unsaved fields. ContactVerification and each FollowUpForm now own independent drafts/request IDs/feedback. Tests preserve contact edits through assignment and follow-up saving and retain a rejected note.

The reviewer reread the narrow fixes and reported no residual finding in those fixes. This is source review, not proof of every browser path or production readiness. Implementation checks and browser evidence are separately recorded in VERIFICATION.md.

Subsequent narrow audit-history correction stores appointment/time/revision with staff outcomes and before/after values with verified contact changes. Additional boundary tests cover email-only confirmation, broken/recreated source rows and resolving a late reply without retroactive confirmation. Dependency versions were updated in response to actual advisory scan failures, followed by the recorded final gate.

The reviewer also inspected the final clinic-local birthday cutoff, contact before/after audit values, appointment revision details, migration/activity display and past-visit reviewed-only path. It reported no concrete defects in that narrow final review. It did not execute checks.
