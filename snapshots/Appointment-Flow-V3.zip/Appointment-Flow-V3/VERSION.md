# V3 clean-room coding quality harness

Original V2 product specification, assessment and screenshots preserved.

V3 = V2 workflow + selected Ruby/Rails and React implementation guidance; V2 formal review rubric removed.

See `standards/INTEGRATION_NOTES.md` and `review/EXPERIMENT_PROTOCOL.md`.
