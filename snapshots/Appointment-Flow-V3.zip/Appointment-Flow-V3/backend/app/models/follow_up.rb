class FollowUp < ApplicationRecord
  belongs_to :visit

  def record!(outcome:, note:, staff:, request_id:)
    raise ArgumentError, "A staff member and note are required" if staff.blank? || note.blank?
    raise ArgumentError, "Unknown outcome" unless %w[attempted confirmed canceled rescheduled reviewed].include?(outcome)
    return if visit.contact.activities.exists?(request_id: request_id)
    raise ArgumentError, "Appointment changed; refresh before saving" unless outcome == "reviewed" || visit.upcoming?
    visit.contact.activities.create!(staff: staff, note: note, action: outcome, request_id: request_id, details: { appointment: visit.source_id, start_at: visit.source.fetch("start_at"), revision: visit.revision })
    update!(owner: staff, state: outcome == "attempted" ? "in_progress" : "resolved")
    visit.update!(confirmed: true) if outcome == "confirmed"
    visit.update!(local_outcome: outcome) if %w[canceled rescheduled].include?(outcome)
    visit.resolve! if %w[confirmed canceled rescheduled].include?(outcome)
  end
end
