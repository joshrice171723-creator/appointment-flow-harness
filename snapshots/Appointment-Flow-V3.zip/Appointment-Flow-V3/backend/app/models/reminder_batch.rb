class ReminderBatch
  def self.call(now: Time.current, fail_sms: false, clinic_id: nil)
    RefreshState.serialized do
      PmsRefresh.call
      visits = Visit.includes(:contact)
      visits = visits.where(contact_id: Contact.where(clinic_id: clinic_id).select(:id)) if clinic_id
      visits.find_each do |visit|
        next unless visit.upcoming?(now)
        contact = visit.contact
        if contact.channels.empty?
          visit.open_issue!(contact.hold_reason || "No permitted reminder channel")
          next
        end
        visit.follow_ups.where.not(kind: [ "Reply needs review", "No reply near appointment", "Delivery failed" ]).where.not(state: "resolved").update_all(state: "resolved", updated_at: now)
        local_now = now.in_time_zone(visit.source.fetch("timezone"))
        days = (visit.starts_at.in_time_zone(local_now.time_zone).to_date - local_now.to_date).to_i
        visit.open_issue!("No reply near appointment") if !visit.confirmed && visit.starts_at <= now + 48.hours
        next unless (10...18).cover?(local_now.hour) && days <= 7
        step = days <= 1 ? "final" : days <= 3 ? "follow_up" : "initial"
        next if visit.confirmed && step != "final"
        contact.channels.each do |channel|
          next if visit.messages.exists?(revision: visit.revision, step: step, channel: channel)
          failed = fail_sms && channel == "sms"
          visit.messages.create!(revision: visit.revision, step: step, channel: channel,
            recipient: contact.recipient(channel), body: body(visit, channel),
            status: failed ? "failed" : "fake_accepted", created_at: now)
          visit.open_issue!("Delivery failed") if failed
        end
      end
    end
  rescue StandardError => error
    RefreshState.first!.update!(error: "#{error.class}: refresh or batch failed; no partial batch committed")
    raise
  end

  def self.body(visit, channel)
    time = visit.starts_at.in_time_zone(visit.source.fetch("timezone")).strftime("%a %b %d, %Y %H:%M %Z")
    spanish = visit.contact.facts["preferred_language"] == "es"
    text = spanish ? "Cita: #{time}, #{visit.source['clinic_name']}." : "Appointment: #{time}, #{visit.source['clinic_name']}."
    unless visit.confirmed
      text += spanish ? " Responda YES para confirmar o NO para ayuda." : " Reply YES to confirm or NO for help."
    end
    text += spanish ? " STOP para dejar mensajes de texto." : " Reply STOP to stop texts." if channel == "sms"
    text
  end
end
