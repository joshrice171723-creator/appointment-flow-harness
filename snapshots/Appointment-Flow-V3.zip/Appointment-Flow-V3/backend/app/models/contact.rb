class Contact < ApplicationRecord
  has_many :visits
  has_many :activities
  has_many :replies

  def facts = source.merge(verified)
  def name = [ source["first_name"], source["last_name"] ].join(" ")

  def recipient(channel)
    value = facts[channel == "sms" ? "wireless_phone" : "email"].to_s.strip
    return value.downcase if channel == "email" && value.match?(URI::MailTo::EMAIL_REGEXP)
    digits = value.gsub(/\D/, "")
    digits = "1#{digits}" if digits.length == 10
    "+#{digits}" if channel == "sms" && digits.match?(/\A1[2-9]\d{9}\z/)
  end

  def conflict?
    verified_source.any? { |key, value| source[key] != value }
  end

  def channels
    return [] if hold_reason
    %w[sms email].select do |channel|
      permitted = channel == "sms" ? sms_allowed : email_allowed
      address = recipient(channel)
      shared = address && Contact.where(clinic_id: clinic_id).where.not(id: id).any? { |other| other.recipient(channel) == address }
      permitted && address && !shared && !(channel == "sms" && OptOut.exists?(clinic_id: clinic_id, recipient: address))
    end
  end

  def hold_reason
    return "Source and verified details conflict" if conflict?
    birthdate = Date.iso8601(facts["birthdate"].to_s) rescue nil
    timezone = PmsRefresh::TIMEZONES.fetch(PmsClinic.find(clinic_id).city)
    today = Time.current.in_time_zone(timezone).to_date
    return "Verify birthdate and authorized adult contact" unless birthdate && birthdate <= today.advance(years: -18)
    return "Preferred language needs review" unless %w[en es].include?(facts["preferred_language"])
    nil
  end

  def verify!(attributes, staff:, note:, request_id:)
    raise ArgumentError, "A staff member and note are required" if staff.blank? || note.blank?
    allowed = attributes.slice("birthdate", "wireless_phone", "email", "preferred_language")
    Date.iso8601(allowed["birthdate"]) if allowed["birthdate"].present?
    previous = facts.slice(*allowed.keys())
    update!(verified: verified.merge(allowed), verified_source: verified_source.merge(source.slice(*allowed.keys())))
    activities.create!(staff: staff, note: note, action: "Contact verified", request_id: request_id, details: { before: previous, after: allowed })
  end
end
