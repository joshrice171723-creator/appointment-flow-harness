class OptOut < ApplicationRecord
end
