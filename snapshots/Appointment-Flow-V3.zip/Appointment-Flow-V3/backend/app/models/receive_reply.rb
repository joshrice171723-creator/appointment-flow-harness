class ReceiveReply
  def self.call(contact:, channel:, body:, external_id:, message_id:, now: Time.current)
    raise ArgumentError, "Channel, reply and event ID are required" unless %w[sms email].include?(channel) && body.is_a?(String) && body.present? && body.length <= 2000 && external_id.is_a?(String) && external_id.present? && external_id.length <= 200
    RefreshState.serialized do
      prior = contact.replies.find_by(external_id: external_id)
      return prior if prior
      message = Message.joins("INNER JOIN visits ON visits.id = messages.visit_id")
        .where(visits: { contact_id: contact.id }, channel: channel).find_by(id: message_id)
      reply = contact.replies.create!(channel: channel, body: body, external_id: external_id,
        message_id: message&.id, result: "review", created_at: now)
      if body.strip.casecmp?("STOP") && channel == "sms"
        recipient = message ? message.recipient : contact.recipient("sms")
        raise ArgumentError, "No known SMS recipient" unless recipient
        OptOut.find_or_create_by!(clinic_id: contact.clinic_id, recipient: recipient)
        reply.update!(result: "sms_stopped")
        return reply
      end
      PmsRefresh.call
      contact.reload
      visit = message && Visit.find(message.visit_id)
      peers = Contact.where(clinic_id: contact.clinic_id).select { |other| other.recipient(channel) == contact.recipient(channel) }
      pending = contact.visits.select { |item| item.upcoming?(now) }
      safe = message && message.status == "fake_accepted" && visit.upcoming?(now) &&
        message.revision == visit.revision && message.recipient == contact.recipient(channel) &&
        contact.channels.include?(channel) && peers.one? && pending.one?
      if safe && body.strip.casecmp?("YES")
        visit.update!(confirmed: true)
        visit.resolve!
        reply.update!(result: "confirmed")
      else
        # Preserve ambiguous candidates for staff; the demo picker is not recipient authentication.
        candidates = peers.flat_map { |peer| peer.visits.select { |item| item.upcoming?(now) } }
        candidates = [ visit ].compact if candidates.empty?
        candidates.each { |item| item.open_issue!("Reply needs review") }
      end
      reply
    end
  end
end
