class RefreshState < ApplicationRecord
  def self.serialized
    attempts = 0
    begin
      transaction(isolation: connection.transaction_open? ? nil : :repeatable_read) do
        first!.lock!
        yield
      end
    rescue ActiveRecord::SerializationFailure
      attempts += 1
      retry if attempts < 3
      raise
    end
  end
end
