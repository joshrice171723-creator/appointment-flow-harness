class Reply < ApplicationRecord
end
