class PmsRefresh
  TIMEZONES = { "Austin" => "America/Chicago", "Phoenix" => "America/Phoenix" }.freeze

  # Caller holds RefreshState's row lock; refresh and dependent decisions commit together.
  def self.call
    clinics = PmsClinic.all.index_by(&:id)
    patients = PmsPatient.all.index_by(&:id)
    appointments = PmsAppointment.all.to_a
    raise ArgumentError, "PMS refresh was empty; outreach paused" if clinics.empty? || patients.empty? || appointments.empty?
    missing = Visit.pluck(:source_id) - appointments.map(&:id)
    raise ArgumentError, "PMS refresh lost tracked appointments; outreach paused" if missing.any?

    appointments.each do |appointment|
      clinic = clinics.fetch(appointment.clinic_id)
      patient = patients.fetch(appointment.patient_id)
      contact = Contact.find_or_initialize_by(clinic_id: clinic.id, patient_id: patient.id)
      contact.update!(source: patient.attributes.except("id"))
      raw = appointment.attributes.merge("clinic_name" => clinic.name, "timezone" => TIMEZONES.fetch(clinic.city))
      wall_time = appointment.start_at
      zone = TZInfo::Timezone.get(raw["timezone"])
      periods = zone.periods_for_local(wall_time)
      instant = periods.one? ? wall_time - periods.first.utc_total_offset : nil
      visit = Visit.find_or_initialize_by(source_id: appointment.id)
      if visit.persisted? && (visit.contact.patient_id != patient.id || visit.contact.clinic_id != clinic.id)
        raise ArgumentError, "PMS appointment identity changed; outreach paused for review"
      end
      same_version = visit.persisted? && visit.source.values_at("patient_id", "start_at", "status") == raw.as_json.values_at("patient_id", "start_at", "status")
      revision = same_version ? visit.revision : SecureRandom.uuid
      if visit.revision != revision
        visit.resolve! if visit.persisted?
        visit.assign_attributes(confirmed: false, local_outcome: nil)
      end
      visit.update!(contact: contact, source: raw, revision: revision, starts_at: instant)
      visit.resolve! unless visit.upcoming?
      visit.open_issue!("Appointment time needs review") unless instant
    end
    RefreshState.first!.update!(succeeded_at: Time.current, error: nil)
  end
end
