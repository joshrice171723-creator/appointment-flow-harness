class Visit < ApplicationRecord
  belongs_to :contact
  has_many :messages
  has_many :follow_ups

  def upcoming?(now = Time.current)
    source["status"] == "scheduled" && local_outcome.nil? && starts_at && starts_at > now
  end

  def open_issue!(kind)
    issue = follow_ups.find_or_initialize_by(kind: kind)
    issue.update!(state: issue.owner.present? ? "in_progress" : "needs_attention")
  end

  def resolve!
    follow_ups.update_all(state: "resolved", updated_at: Time.current)
  end

  def payload
    as_json(only: %i[id source_id revision starts_at confirmed local_outcome]).merge(
      source: source.except("procedure_note"), patient: contact.name,
      patient_id: contact.patient_id, contact_id: contact.id,
      follow_ups: follow_ups.order(:id).as_json
    )
  end
end
