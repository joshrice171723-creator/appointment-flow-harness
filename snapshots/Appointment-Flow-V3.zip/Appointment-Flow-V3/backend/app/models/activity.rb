class Activity < ApplicationRecord
end
