class PmsPatient < ApplicationRecord
  self.table_name = "patients"
  def readonly? = true
end
