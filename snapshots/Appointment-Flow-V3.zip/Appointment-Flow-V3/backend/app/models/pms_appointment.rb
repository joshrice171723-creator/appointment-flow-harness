class PmsAppointment < ApplicationRecord
  self.table_name = "appointments"
  def readonly? = true
end
