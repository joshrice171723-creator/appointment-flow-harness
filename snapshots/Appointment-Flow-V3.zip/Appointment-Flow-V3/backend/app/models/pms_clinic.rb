class PmsClinic < ApplicationRecord
  self.table_name = "clinics"
  def readonly? = true
end
