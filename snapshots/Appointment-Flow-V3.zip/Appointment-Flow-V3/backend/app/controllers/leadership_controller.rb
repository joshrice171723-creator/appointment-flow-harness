class LeadershipController < ApplicationController
  def index
    workspace!(%w[leadership])
    month = Date.iso8601("#{params.fetch(:month, Date.current.strftime('%Y-%m'))}-01")
    rows = PmsClinic.order(:id).map do |clinic|
      visits = Visit.where(contact_id: Contact.where(clinic_id: clinic.id).select(:id))
        .where("source->>'start_at' >= ? AND source->>'start_at' < ?", month.iso8601, month.next_month.iso8601)
      counts = visits.group("source->>'status'").count
      total = visits.count
      { clinic: clinic.name, recorded: total, completed: counts.fetch("complete", 0),
        canceled: counts.fetch("broken", 0), rescheduled: counts.fetch("unscheduled", 0),
        unknown: total - counts.fetch("complete", 0) - counts.fetch("broken", 0) - counts.fetch("unscheduled", 0),
        completion_rate: total.zero? ? nil : (100.0 * counts.fetch("complete", 0) / total).round(1),
        messages: Message.where(visit_id: visits.select(:id)).group(:status).count,
        issues: FollowUp.where(visit_id: visits.select(:id)).group(:state).count,
        holds: FollowUp.where(visit_id: visits.select(:id)).where.not(kind: [ "Reply needs review", "No reply near appointment", "Delivery failed" ]).where.not(state: "resolved").count }
    end
    render json: { month: month.strftime("%Y-%m"), clinics: rows }
  end
end
