class WorkspacesController < ApplicationController
  def clinics
    render json: PmsClinic.order(:id).map { |clinic| { id: clinic.id, name: clinic.name, timezone: PmsRefresh::TIMEZONES[clinic.city] } }
  end

  def visits
    contacts = scoped_contacts
    staff if request.headers["X-Workspace"] == "staff"
    render json: { visits: Visit.where(contact: contacts).includes(:contact, :follow_ups).order(:starts_at).map(&:payload),
      patients: contacts.order(:patient_id).map { |contact| { id: contact.id, name: contact.name } },
      sync: RefreshState.first!.as_json(only: %i[succeeded_at error]) }
  end

  def contact
    item = scoped_contacts.find(params[:id])
    render json: { id: item.id, name: item.name, source: item.source, facts: item.facts,
      verified: item.verified, conflict: item.conflict?, channels: item.channels,
      sms_allowed: item.sms_allowed, email_allowed: item.email_allowed,
      visits: item.visits.includes(:contact, :follow_ups).order(:starts_at).map(&:payload),
      messages: Message.where(visit_id: item.visits.select(:id)).order(:created_at).as_json,
      replies: item.replies.order(:created_at).as_json, activities: item.activities.order(:created_at).as_json }
  end

  def verify
    workspace!(%w[staff])
    item = scoped_contacts.find(params[:id])
    RefreshState.serialized do
      item.reload
      unless item.activities.exists?(request_id: params.require(:request_id))
        item.verify!(params.require(:contact).permit(:birthdate, :wireless_phone, :email, :preferred_language).to_h,
          staff: staff, note: params[:note], request_id: params[:request_id])
      end
    end
    render json: { result: "Contact details verified locally; PMS unchanged" }
  end

  def follow_up
    workspace!(%w[staff])
    RefreshState.serialized do
      PmsRefresh.call
      issue = FollowUp.joins(visit: :contact).where(contacts: { clinic_id: clinic_id }).find(params[:id])
      if issue.visit.revision != params.require(:revision)
        raise ArgumentError, "Appointment changed; refresh before saving"
      end
      if params[:outcome] == "assign"
        issue.update!(owner: staff, state: "in_progress") unless issue.state == "resolved"
      else
        issue.record!(outcome: params[:outcome], note: params[:note], staff: staff, request_id: params.require(:request_id))
      end
    end
    render json: { result: "Follow-up saved" }
  end

  def reply
    workspace!(%w[patient])
    item = scoped_contacts.find(params.require(:contact_id))
    result = ReceiveReply.call(contact: item, channel: params[:channel], body: params[:body],
      external_id: params.require(:external_id), message_id: params[:message_id])
    render json: { result: result.result }
  end

  def reminders
    workspace!(%w[staff])
    staff
    ReminderBatch.call(clinic_id: clinic_id)
    render json: { result: "Batch completed using fake transport; inspect patient history" }
  end

  def refresh
    workspace!(%w[staff])
    staff
    RefreshState.serialized { PmsRefresh.call }
    render json: { result: "PMS refreshed" }
  rescue StandardError => error
    RefreshState.first!.update!(error: "PMS refresh failed; previous snapshot retained")
    raise error if error.is_a?(ArgumentError)
    render json: { error: "PMS unavailable; previous snapshot retained" }, status: :service_unavailable
  end
end
