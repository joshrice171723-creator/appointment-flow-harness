class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "Record not found in this workspace" }, status: :not_found
  end
  rescue_from ArgumentError, ActiveRecord::RecordInvalid do |error|
    render json: { error: error.message }, status: :unprocessable_entity
  end

  rescue_from ActiveRecord::SerializationFailure, ActiveRecord::ConnectionNotEstablished, ActiveRecord::StatementInvalid do
    render json: { error: "Data changed or the database is unavailable. Refresh and check the outcome before retrying." }, status: :service_unavailable
  end

  private

  def workspace!(allowed)
    raise ArgumentError, "Choose an authorized demo workspace" unless allowed.include?(request.headers["X-Workspace"])
  end

  def clinic_id
    Integer(request.headers.fetch("X-Clinic-Id"))
  rescue KeyError, TypeError
    raise ArgumentError, "Choose a clinic"
  end

  def staff
    value = request.headers["X-Staff"]
    raise ArgumentError, "Choose a demo staff member" unless [ "Taylor Morgan", "Jordan Lee" ].include?(value)
    value
  end

  def scoped_contacts
    workspace!(%w[staff patient])
    Contact.where(clinic_id: clinic_id)
  end
end
