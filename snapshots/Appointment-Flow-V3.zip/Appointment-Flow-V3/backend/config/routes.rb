Rails.application.routes.draw do
  get "up" => "rails/health#show", as: :rails_health_check
  get "api/clinics", to: "workspaces#clinics"
  get "api/leadership", to: "leadership#index"
  get "api/visits", to: "workspaces#visits"
  get "api/contacts/:id", to: "workspaces#contact"
  post "api/contacts/:id/verify", to: "workspaces#verify"
  post "api/follow_ups/:id", to: "workspaces#follow_up"
  post "api/replies", to: "workspaces#reply"
  post "api/reminders", to: "workspaces#reminders"
  post "api/refresh", to: "workspaces#refresh"
end
