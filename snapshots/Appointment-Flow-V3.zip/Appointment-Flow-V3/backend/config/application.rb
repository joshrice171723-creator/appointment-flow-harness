require_relative "boot"
require "rails"
require "active_record/railtie"
require "action_controller/railtie"
require "rails/test_unit/railtie"
Bundler.require(*Rails.groups)
module Backend
  class Application < Rails::Application
    config.load_defaults 8.1
    config.api_only = true
    config.log_level = :info
    config.autoload_lib(ignore: %w[assets tasks])
    config.filter_parameters += %i[body note phone email birthdate contact]
  end
end
