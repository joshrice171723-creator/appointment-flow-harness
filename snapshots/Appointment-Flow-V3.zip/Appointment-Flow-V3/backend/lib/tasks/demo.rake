namespace :demo do
  desc "Simulate an external PMS time change: demo:move[appointment_id,YYYY-MM-DDTHH:MM:SS]"
  task :move, [ :id, :wall_time ] => :environment do |_task, args|
    raise "Local simulation only" unless Rails.env.development? || Rails.env.test?
    id = Integer(args.fetch(:id))
    wall_time = DateTime.iso8601(args.fetch(:wall_time)).strftime("%Y-%m-%d %H:%M:%S")
    connection = ActiveRecord::Base.connection
    connection.execute("UPDATE appointments SET start_at=#{connection.quote(wall_time)}, updated_at=CURRENT_TIMESTAMP WHERE id=#{id}")
    puts "External PMS simulation updated. Refresh in the app; the app itself never writes source rows."
  end
end
