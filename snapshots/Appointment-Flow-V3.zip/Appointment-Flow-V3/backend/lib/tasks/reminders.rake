namespace :reminders do
  desc "Refresh PMS and record due fake SMS/email attempts"
  task run: :environment do
    now = ENV["AT"].present? ? Time.iso8601(ENV.fetch("AT")) : Time.current
    ReminderBatch.call(now: now, fail_sms: ENV["FAIL_SMS"] == "1")
    puts "Fake reminder batch completed. #{Message.count} attempts stored; no live sends."
  end
end
