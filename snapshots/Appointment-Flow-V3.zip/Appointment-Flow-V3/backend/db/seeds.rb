# This is the only source-writing path. Runtime PMS models are read-only.
connection = ActiveRecord::Base.connection
raise "Seed requires empty source tables" if PmsClinic.exists?
connection.execute("INSERT INTO clinics (id,name,city,state,phone) VALUES (1,'Austin, TX','Austin','TX','512-555-0100'),(2,'Phoenix, AZ','Phoenix','AZ','602-555-0100')")
RefreshState.create!(id: 1)
names = %w[Avery Morgan Casey Riley Cameron Quinn Dakota Sage]
[ 1, 2 ].each do |clinic|
  names.each_with_index do |name, index|
    id = clinic * 100 + index
    phone = index == 3 ? "invalid" : "+1512555#{id.to_s.rjust(4, '0')}"
    email = index == 3 ? "" : "patient#{id}@example.test"
    birthdate = index == 4 ? nil : "1990-04-12"
    language = index == 5 ? "fr" : index == 6 ? "es" : "en"
    connection.execute("INSERT INTO patients (id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (#{id},#{connection.quote(name)},'Demo',#{connection.quote(birthdate)},#{connection.quote(phone)},#{connection.quote(email)},#{connection.quote(language)})")
    date = Date.current + [ 7, 3, 1, 2, 4, 5, 6, 7 ][index]
    connection.execute("INSERT INTO appointments (id,patient_id,clinic_id,provider_name,start_at,length_minutes,status,updated_at) VALUES (#{id},#{id},#{clinic},'Dr. Taylor',#{connection.quote("#{date} 15:00:00")},30,'scheduled',CURRENT_TIMESTAMP)")
    old_id = id + 1000
    status = %w[complete complete broken unscheduled][index % 4]
    connection.execute("INSERT INTO appointments (id,patient_id,clinic_id,provider_name,start_at,length_minutes,status,updated_at) VALUES (#{old_id},#{id},#{clinic},'Dr. Taylor',#{connection.quote("#{Date.current.beginning_of_month} 09:00:00")},30,#{connection.quote(status)},CURRENT_TIMESTAMP)")
  end
end
RefreshState.serialized { PmsRefresh.call }
Contact.update_all(sms_allowed: true, email_allowed: true)
now = Time.current.change(hour: 17, min: 0)
ReminderBatch.call(now: now)
puts "Seeded 2 clinics, 16 fictional patients, 32 appointments and inspectable fake reminders."
