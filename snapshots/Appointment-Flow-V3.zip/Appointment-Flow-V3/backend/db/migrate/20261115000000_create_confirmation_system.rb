class CreateConfirmationSystem < ActiveRecord::Migration[8.1]
  def change
    create_table :clinics do |t|
      t.text :name, null: false
      t.text :address_line, :city, :state, :phone
    end
    create_table :patients do |t|
      t.text :first_name, :last_name, null: false
      t.date :birthdate
      t.text :wireless_phone, :email, :preferred_language
      t.bigint :guarantor_id
    end
    add_foreign_key :patients, :patients, column: :guarantor_id
    create_table :appointments do |t|
      t.references :patient, null: false, foreign_key: true
      t.references :clinic, null: false, foreign_key: true
      t.text :provider_name, :procedure_note
      t.datetime :start_at, null: false
      t.integer :length_minutes
      t.text :status, null: false
      t.datetime :updated_at
    end
    create_table :refresh_states do |t|
      t.datetime :succeeded_at
      t.text :error
    end
    create_table :contacts do |t|
      t.bigint :clinic_id, :patient_id, null: false
      t.jsonb :source, null: false, default: {}
      t.jsonb :verified, null: false, default: {}
      t.jsonb :verified_source, null: false, default: {}
      t.boolean :sms_allowed, :email_allowed, null: false, default: false
    end
    add_index :contacts, [ :clinic_id, :patient_id ], unique: true
    create_table :visits do |t|
      t.bigint :source_id, null: false
      t.references :contact, null: false, foreign_key: true
      t.jsonb :source, null: false, default: {}
      t.text :revision, null: false
      t.datetime :starts_at
      t.boolean :confirmed, null: false, default: false
      t.text :local_outcome
    end
    add_index :visits, :source_id, unique: true
    create_table :messages do |t|
      t.references :visit, null: false, foreign_key: true
      t.text :revision, :channel, :recipient, :body, :step, :status, null: false
      t.datetime :created_at, null: false
    end
    add_index :messages, [ :visit_id, :revision, :channel, :step ], unique: true
    create_table :replies do |t|
      t.references :contact, null: false, foreign_key: true
      t.text :external_id, :channel, :body, :result, null: false
      t.bigint :message_id
      t.datetime :created_at, null: false
    end
    add_index :replies, [ :contact_id, :external_id ], unique: true
    create_table :opt_outs do |t|
      t.bigint :clinic_id, null: false
      t.text :recipient, null: false
    end
    add_index :opt_outs, [ :clinic_id, :recipient ], unique: true
    create_table :follow_ups do |t|
      t.references :visit, null: false, foreign_key: true
      t.text :kind, :state, null: false
      t.text :owner
      t.timestamps
    end
    add_index :follow_ups, [ :visit_id, :kind ], unique: true
    create_table :activities do |t|
      t.references :contact, null: false, foreign_key: true
      t.text :staff, :note, :action, null: false
      t.text :request_id, null: false
      t.datetime :created_at, null: false
    end
    add_index :activities, [ :contact_id, :request_id ], unique: true
  end
end
