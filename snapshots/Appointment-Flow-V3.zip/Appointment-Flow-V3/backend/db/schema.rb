# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_11_15_000001) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "activities", force: :cascade do |t|
    t.bigint "contact_id", null: false
    t.text "staff", null: false
    t.text "note", null: false
    t.text "action", null: false
    t.text "request_id", null: false
    t.datetime "created_at", null: false
    t.jsonb "details", default: {}, null: false
    t.index ["contact_id", "request_id"], name: "index_activities_on_contact_id_and_request_id", unique: true
    t.index ["contact_id"], name: "index_activities_on_contact_id"
  end

  create_table "appointments", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "clinic_id", null: false
    t.text "provider_name"
    t.text "procedure_note"
    t.datetime "start_at", null: false
    t.integer "length_minutes"
    t.text "status", null: false
    t.datetime "updated_at"
    t.index ["clinic_id"], name: "index_appointments_on_clinic_id"
    t.index ["patient_id"], name: "index_appointments_on_patient_id"
  end

  create_table "clinics", force: :cascade do |t|
    t.text "name", null: false
    t.text "address_line"
    t.text "city"
    t.text "state"
    t.text "phone"
  end

  create_table "contacts", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.bigint "patient_id", null: false
    t.jsonb "source", default: {}, null: false
    t.jsonb "verified", default: {}, null: false
    t.jsonb "verified_source", default: {}, null: false
    t.boolean "sms_allowed", default: false, null: false
    t.boolean "email_allowed", default: false, null: false
    t.index ["clinic_id", "patient_id"], name: "index_contacts_on_clinic_id_and_patient_id", unique: true
  end

  create_table "follow_ups", force: :cascade do |t|
    t.bigint "visit_id", null: false
    t.text "kind", null: false
    t.text "state", null: false
    t.text "owner"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["visit_id", "kind"], name: "index_follow_ups_on_visit_id_and_kind", unique: true
    t.index ["visit_id"], name: "index_follow_ups_on_visit_id"
  end

  create_table "messages", force: :cascade do |t|
    t.bigint "visit_id", null: false
    t.text "revision", null: false
    t.text "channel", null: false
    t.text "recipient", null: false
    t.text "body", null: false
    t.text "step", null: false
    t.text "status", null: false
    t.datetime "created_at", null: false
    t.index ["visit_id", "revision", "channel", "step"], name: "index_messages_on_visit_id_and_revision_and_channel_and_step", unique: true
    t.index ["visit_id"], name: "index_messages_on_visit_id"
  end

  create_table "opt_outs", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.text "recipient", null: false
    t.index ["clinic_id", "recipient"], name: "index_opt_outs_on_clinic_id_and_recipient", unique: true
  end

  create_table "patients", force: :cascade do |t|
    t.text "first_name", null: false
    t.text "last_name", null: false
    t.date "birthdate"
    t.text "wireless_phone"
    t.text "email"
    t.text "preferred_language"
    t.bigint "guarantor_id"
  end

  create_table "refresh_states", force: :cascade do |t|
    t.datetime "succeeded_at"
    t.text "error"
  end

  create_table "replies", force: :cascade do |t|
    t.bigint "contact_id", null: false
    t.text "external_id", null: false
    t.text "channel", null: false
    t.text "body", null: false
    t.text "result", null: false
    t.bigint "message_id"
    t.datetime "created_at", null: false
    t.index ["contact_id", "external_id"], name: "index_replies_on_contact_id_and_external_id", unique: true
    t.index ["contact_id"], name: "index_replies_on_contact_id"
  end

  create_table "visits", force: :cascade do |t|
    t.bigint "source_id", null: false
    t.bigint "contact_id", null: false
    t.jsonb "source", default: {}, null: false
    t.text "revision", null: false
    t.datetime "starts_at"
    t.boolean "confirmed", default: false, null: false
    t.text "local_outcome"
    t.index ["contact_id"], name: "index_visits_on_contact_id"
    t.index ["source_id"], name: "index_visits_on_source_id", unique: true
  end

  add_foreign_key "activities", "contacts"
  add_foreign_key "appointments", "clinics"
  add_foreign_key "appointments", "patients"
  add_foreign_key "follow_ups", "visits"
  add_foreign_key "messages", "visits"
  add_foreign_key "patients", "patients", column: "guarantor_id"
  add_foreign_key "replies", "contacts"
  add_foreign_key "visits", "contacts"
end
