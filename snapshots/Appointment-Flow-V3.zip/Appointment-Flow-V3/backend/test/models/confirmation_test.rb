require "test_helper"
class ConfirmationTest < ActiveSupport::TestCase
  setup { travel_to at; setup_source }
  teardown { travel_back }
  def send_reply(body, external_id: SecureRandom.uuid, message: Message.where(channel: "sms").first)
    ReceiveReply.call(contact: Contact.find_by!(patient_id: 1), channel: message.channel, body: body,
      external_id: external_id, message_id: message.id, now: Time.current)
  end

  test "both channels are fake accepted once and YES confirms only matching visit" do
    2.times { ReminderBatch.call(now: at) }
    assert_equal 4, Message.count
    assert Message.all.all? { |item| item.status == "fake_accepted" }
    reply = send_reply("yes", external_id: "event-1")
    assert_equal "confirmed", reply.result
    assert Visit.find_by!(source_id: 1).confirmed
    assert_not Visit.find_by!(source_id: 2).confirmed
    assert_equal reply.id, send_reply("yes", external_id: "event-1").id
    ReminderBatch.call(now: at + 4.days)
    assert_equal 6, Message.count
    assert_equal 2, Message.where(visit: Visit.find_by!(source_id: 1)).count
    send_reply("NO")
    assert Visit.find_by!(source_id: 1).reload.confirmed
    assert FollowUp.exists?(kind: "Reply needs review")
  end

  test "reschedule invalidates confirmation and old message reply" do
    ReminderBatch.call(now: at)
    message = Message.where(channel: "sms").first
    send_reply("YES", message: message)
    sql("UPDATE appointments SET start_at='2026-11-23 15:00:00' WHERE id=1")
    assert_equal "review", send_reply("YES", message: message).result
    assert_not Visit.find_by!(source_id: 1).confirmed
  end

  test "STOP survives refresh and suppresses SMS while keeping email" do
    ReminderBatch.call(now: at)
    assert_equal "sms_stopped", send_reply("STOP").result
    ReminderBatch.call(now: at + 4.days)
    assert_equal 1, Message.joins(:visit).where(visits: { source_id: 1 }, channel: "sms").count
    assert_not Contact.find_by!(patient_id: 1).channels.include?("sms")
  end

  test "shared numbers require review" do
    ReminderBatch.call(now: at)
    sql("INSERT INTO patients (id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (3,'Casey','Demo','1990-01-01','5125550101','casey@example.test','en')")
    sql("INSERT INTO appointments (id,clinic_id,patient_id,start_at,status) VALUES (3,1,3,'2026-11-22 16:00:00','scheduled')")
    ReminderBatch.call(now: at)
    assert_equal "review", send_reply("YES").result
    assert_not Visit.find_by!(source_id: 1).confirmed
  end

  test "late replies never confirm and post-start reminders are skipped" do
    ReminderBatch.call(now: at)
    travel_to Time.utc(2026, 11, 22, 22)
    assert_equal "review", send_reply("YES").result
    ReminderBatch.call
    assert_equal 4, Message.count
  end

  test "failed SMS recorded once with permitted email and task" do
    2.times { ReminderBatch.call(now: at, fail_sms: true) }
    assert_equal 2, Message.where(status: "failed").count
    assert_equal 2, Message.where(channel: "email", status: "fake_accepted").count
    assert_equal 2, FollowUp.where(kind: "Delivery failed").count
  end

  test "failed or incomplete refresh rolls back and blocks sends" do
    ReminderBatch.call(now: at)
    sql("DELETE FROM appointments WHERE id=1")
    assert_raises(ArgumentError) { ReminderBatch.call(now: at + 4.days) }
    assert_equal 4, Message.count
    assert_equal 2, Visit.count
    assert RefreshState.first.error.present?
  end

  test "unsafe age language and no permission create holds" do
    sql("UPDATE patients SET birthdate=NULL WHERE id=1")
    Contact.where(patient_id: 2).update_all(sms_allowed: false, email_allowed: false)
    ReminderBatch.call(now: at)
    assert_equal 0, Message.count
    assert_equal 2, FollowUp.count
  end

  test "clinic window and DST wall clock are explicit" do
    ReminderBatch.call(now: Time.utc(2026, 11, 15, 14))
    assert_equal 0, Message.count
    assert_equal Time.utc(2026, 11, 22, 21), Visit.find_by!(source_id: 1).starts_at
    assert_equal Time.utc(2026, 11, 22, 22), Visit.find_by!(source_id: 2).starts_at
    sql("UPDATE appointments SET start_at='2026-11-01 01:30:00' WHERE id=1")
    RefreshState.serialized { PmsRefresh.call }
    assert_nil Visit.find_by!(source_id: 1).starts_at
  end

  test "source records reject runtime writes and verified changes preserve original" do
    assert_raises(ActiveRecord::ReadOnlyRecord) { PmsPatient.first.update!(email: "bad@example.test") }
    contact = Contact.find_by!(patient_id: 1)
    RefreshState.serialized { contact.verify!({ "email" => "new@example.test" }, staff: "Taylor Morgan", note: "Verified by phone", request_id: "verify1") }
    assert_equal "avery@example.test", PmsPatient.find(1).email
    assert_equal "new@example.test", contact.facts["email"]
    assert_equal "avery@example.test", Activity.last.details.fetch("before").fetch("email")
    assert_equal "new@example.test", Activity.last.details.fetch("after").fetch("email")
    sql("UPDATE patients SET email='changed@example.test' WHERE id=1")
    RefreshState.serialized { PmsRefresh.call }
    assert contact.reload.conflict?
    assert_empty contact.channels
  end
  test "correcting contact clears prior hold on next batch" do
    sql("UPDATE patients SET birthdate=NULL WHERE id=1")
    ReminderBatch.call(now: at)
    contact = Contact.find_by!(patient_id: 1)
    RefreshState.serialized { contact.verify!({ "birthdate" => "1990-01-01" }, staff: "Taylor Morgan", note: "Verified adult", request_id: "age1") }
    ReminderBatch.call(now: at)
    assert_equal [ "resolved" ], contact.visits.first.follow_ups.pluck(:state)
    assert_equal 2, contact.visits.first.messages.count
  end

  test "moving time back never revalidates an earlier message" do
    ReminderBatch.call(now: at)
    message = Message.where(channel: "sms").first
    sql("UPDATE appointments SET start_at='2026-11-23 15:00:00' WHERE id=1")
    RefreshState.serialized { PmsRefresh.call }
    sql("UPDATE appointments SET start_at='2026-11-22 15:00:00' WHERE id=1")
    assert_equal "review", send_reply("YES", message: message).result
    assert_not Visit.find_by!(source_id: 1).confirmed
  end

  test "recipient and clinic reassignment blocks refresh without leaking history" do
    ReminderBatch.call(now: at)
    sql("UPDATE appointments SET clinic_id=2,patient_id=2 WHERE id=1")
    assert_raises(ArgumentError) { ReminderBatch.call(now: at) }
    assert_equal 1, Visit.find_by!(source_id: 1).contact.patient_id
  end

  test "STOP works during source outage and suppresses the actual sent number" do
    ReminderBatch.call(now: at)
    message = Message.where(channel: "sms").first
    sql("UPDATE patients SET wireless_phone='5125550199' WHERE id=1")
    RefreshState.serialized { PmsRefresh.call }
    sql("DELETE FROM appointments WHERE id=2")
    assert_equal "sms_stopped", send_reply("STOP", message: message).result
    assert OptOut.exists?(clinic_id: 1, recipient: "+15125550101")
    assert_not OptOut.exists?(clinic_id: 1, recipient: "+15125550199")
  end
  test "email alone can confirm when SMS is unavailable" do
    sql("UPDATE patients SET wireless_phone=NULL WHERE id=1")
    ReminderBatch.call(now: at)
    visit = Visit.find_by!(source_id: 1)
    assert_equal [ "email" ], visit.messages.pluck(:channel)
    assert_equal "confirmed", send_reply("YES", message: visit.messages.first).result
  end

  test "broken and recreated appointment has its own lifecycle" do
    ReminderBatch.call(now: at)
    message = Message.where(channel: "sms").first
    sql("UPDATE appointments SET status='broken' WHERE id=1")
    sql("INSERT INTO appointments (id,clinic_id,patient_id,start_at,status) VALUES (3,1,1,'2026-11-22 15:00:00','scheduled')")
    ReminderBatch.call(now: at)
    assert_equal 2, Visit.find_by!(source_id: 1).messages.count
    assert_equal 2, Visit.find_by!(source_id: 3).messages.count
    assert_equal "review", send_reply("YES", message: message).result
    assert_not Visit.find_by!(source_id: 3).confirmed
  end

  test "staff can resolve a late reply without retroactively confirming" do
    ReminderBatch.call(now: at)
    travel_to Time.utc(2026, 11, 22, 22)
    send_reply("YES")
    visit = Visit.find_by!(source_id: 1)
    issue = visit.follow_ups.find_by!(kind: "Reply needs review")
    RefreshState.serialized { issue.record!(outcome: "reviewed", note: "Late reply reviewed", staff: "Taylor Morgan", request_id: "late1") }
    assert_equal "resolved", issue.reload.state
    assert_not visit.reload.confirmed
  end
  test "adult eligibility uses the clinic date at a UTC birthday boundary" do
    travel_to Time.utc(2026, 11, 16, 0, 30)
    sql("UPDATE patients SET birthdate='2008-11-16' WHERE id=1")
    RefreshState.serialized { PmsRefresh.call }
    contact = Contact.find_by!(patient_id: 1)
    assert_equal "Verify birthdate and authorized adult contact", contact.hold_reason
    assert_empty contact.channels
  end
end
