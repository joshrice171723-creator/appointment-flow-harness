require "test_helper"
class ConcurrencyTest < ActiveSupport::TestCase
  self.use_transactional_tests = false
  setup do
    sql("TRUNCATE activities, follow_ups, opt_outs, replies, messages, visits, contacts, refresh_states, appointments, patients, clinics RESTART IDENTITY CASCADE")
    setup_source
  end
  teardown do
    sql("TRUNCATE activities, follow_ups, opt_outs, replies, messages, visits, contacts, refresh_states, appointments, patients, clinics RESTART IDENTITY CASCADE")
  end
  test "two database connections produce one logical attempt per visit channel step" do
    ready = Queue.new
    start = Queue.new
    workers = 2.times.map do
      Thread.new do
        ActiveRecord::Base.connection_pool.with_connection do
          ready << true
          start.pop
          ReminderBatch.call(now: at)
        end
      end
    end
    2.times { ready.pop }
    2.times { start << true }
    workers.each(&:value)
    assert_equal 4, Message.count
    assert_equal 4, Message.distinct.count(:id)
  end
end
