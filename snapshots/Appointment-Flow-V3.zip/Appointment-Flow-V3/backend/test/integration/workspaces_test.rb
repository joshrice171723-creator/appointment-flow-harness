require "test_helper"
class WorkspacesTest < ActionDispatch::IntegrationTest
  setup { travel_to at; setup_source }
  teardown { travel_back }
  def headers(role = "staff", clinic = "1")
    { "X-Workspace" => role, "X-Clinic-Id" => clinic, "X-Staff" => "Taylor Morgan" }
  end
  test "clinic scoped reads and writes reject another clinic" do
    get "/api/visits", headers: headers
    assert_response :success
    assert_equal [ 1 ], response.parsed_body["visits"].map { |v| v["source_id"] }
    other = Contact.find_by!(clinic_id: 2)
    get "/api/contacts/#{other.id}", headers: headers
    assert_response :not_found
    post "/api/contacts/#{other.id}/verify", headers: headers, params: { contact: { email: "wrong@example.test" }, request_id: "bad", note: "wrong" }
    assert_response :not_found
  end
  test "leadership responds with only aggregate whitelist and rejects staff role" do
    get "/api/leadership", headers: headers("leadership"), params: { month: "2026-11" }
    assert_response :success
    data = response.parsed_body
    assert_equal 2, data["clinics"].length
    %w[Avery Riley email phone birthdate procedure_note recipient body].each { |word| assert_not_includes response.body, word }
    assert_equal 0, data["clinics"].first["completed"]
    get "/api/contacts/#{Contact.first.id}", headers: headers("leadership")
    assert_response :unprocessable_entity
  end
  test "follow-up note validation and idempotent save" do
    ReminderBatch.call(now: at + 6.days)
    issue = FollowUp.joins(:visit).find_by!(visits: { source_id: 1 })
    post "/api/follow_ups/#{issue.id}", headers: headers, params: { outcome: "confirmed", note: "", request_id: "save1", revision: issue.visit.revision }
    assert_response :unprocessable_entity
    2.times do
      post "/api/follow_ups/#{issue.id}", headers: headers, params: { outcome: "confirmed", note: "Reached by phone", request_id: "save1", revision: issue.visit.revision }
      assert_response :success
    end
    assert_equal 1, Activity.count
    assert_equal 1, Activity.first.details.fetch("appointment")
    assert issue.visit.reload.confirmed
  end
  test "staff reminder run affects selected clinic only" do
    post "/api/reminders", headers: headers
    assert_response :success
    assert_equal [ 1 ], Message.joins(visit: :contact).distinct.pluck("contacts.clinic_id")
    assert_equal 0, FollowUp.joins(visit: :contact).where(contacts: { clinic_id: 2 }).count
  end
end
