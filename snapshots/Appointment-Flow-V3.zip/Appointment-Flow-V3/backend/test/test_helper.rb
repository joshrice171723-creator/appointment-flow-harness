ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"
class ActiveSupport::TestCase
  self.use_transactional_tests = true
  def setup_source
    connection = ActiveRecord::Base.connection
    connection.execute("INSERT INTO clinics (id,name,city,state) VALUES (1,'Austin, TX','Austin','TX'),(2,'Phoenix, AZ','Phoenix','AZ')")
    connection.execute("INSERT INTO patients (id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (1,'Avery','Demo','1990-01-01','512-555-0101','avery@example.test','en'),(2,'Riley','Demo','1990-01-01','602-555-0102','riley@example.test','en')")
    connection.execute("INSERT INTO appointments (id,clinic_id,patient_id,start_at,status) VALUES (1,1,1,'2026-11-22 15:00:00','scheduled'),(2,2,2,'2026-11-22 15:00:00','scheduled')")
    RefreshState.create!(id: 1)
    RefreshState.serialized { PmsRefresh.call }
    Contact.update_all(sms_allowed: true, email_allowed: true)
  end
  def at = Time.utc(2026, 11, 15, 17)
  def sql(text) = ActiveRecord::Base.connection.execute(text)
end
