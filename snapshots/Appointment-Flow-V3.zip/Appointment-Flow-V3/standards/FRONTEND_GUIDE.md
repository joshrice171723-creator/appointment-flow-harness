# Frontend (React and TypeScript) guide — V3+ clean-room edition

**Role:** task-specific engineering guidance, not a list of required hooks, components, libraries, or file names. Read the relevant sections when building or changing React behavior. Distilled from the user-provided *Frontend-Coding-Guide.md*; prior project source and illustrative API/code examples are intentionally omitted.

## Trace the whole user action

For each screen action, be able to follow: selected clinic/patient/appointment -> state owner -> event handler -> request -> server outcome -> visible feedback. If the path requires opening numerous unrelated files to find one decision, consider a simpler boundary.

## Components and state ownership

- Organize components around meaningful user responsibilities and clear prop contracts. Split when it isolates independent behavior or a reusable concept—not merely to make files shorter.
- Each editable value needs a single owner. Derive display values during render instead of maintaining competing copies of the same fact.
- Keep rendering and state transformations pure. Use stable record IDs as React keys; confirm that state does not migrate to a different patient/appointment after filtering, reordering, or switching records.
- Keep temporary values close to their usage. Don't introduce global state, context, custom hooks, generic fetchers, state-machine libraries, or UI frameworks without a demonstrated coordination problem.
- Effects are for synchronization with systems outside React, **not** for calculating values from props/state or responding to a user click that can be handled in that click handler.

## Asynchronous correctness and failure handling

- When a user changes clinic, patient, or tab while a request is pending, prevent obsolete read results from replacing the currently selected record's data. Use request identity, effect cleanup, or cancellation as appropriate; tests must intentionally reorder responses when applicable.
- Distinguish HTTP rejection, network failure, invalid response data, and valid empty results. A failed request is not an empty list.
- Don't assume a failed refresh means an earlier save failed. Show an accepted write separately from whether the newest server state can currently be displayed.
- If an action may have committed but the response was lost, don't automatically repeat a consequential write unless the server contract makes the retry safe. Keep edits recoverable and describe the uncertain outcome.
- Keep pending/error state scoped to the relevant action or record so a stale response cannot clear a different record's form or success notice.

## Accessible, inspectable screens

- Use semantic form labels, useful action text, keyboard-reachable controls, visible focus, understandable status and error messages, and associations between errors and inputs.
- Use actual semantic tables for columnar appointment data. Preserve header/data relationships when adding scroll areas or sorting.
- Build meaningful loading, success, empty and error states for each workflow. Show exactly what a fake SMS/email simulation did or did not do; do not imply live delivery.
- Compare against the provided screenshots for major layout and information hierarchy; screenshots are visual examples, not proof of hidden interactions. Confirm visual behavior at relevant desktop sizes, long values, zoom, and reduced motion where affected.

## Tests and performance

- Test user-visible promises: selecting a clinic, opening a patient, confirming or rejecting a reply, navigating back, displaying error feedback, and keeping correct current data after reordered requests.
- State whether browser tests used a stubbed API or a real app backend. A mocked accepted response does not establish database persistence.
- Avoid snapshot-only tests as proof of behavior. Prefer accessible role/label locators and explicit expected outcomes.
- Optimize only after establishing a measurable user-facing delay and its cause; do not install caching layers speculatively.

## When to consult this guide

| Work | Start with |
|---|---|
| Appointments table / multi-clinic navigation | stable record identity, state ownership, backend scope |
| Patient inbox / reply simulation | request identity, pending state, repeat/uncertain writes |
| Form and feedback | explicit outcome, failure handling, accessibility |
| Component refactoring | real responsibility boundary, fewer unnecessary jumps |
| UI regression testing | visible contract and controlled race/failure scenarios |

**Source basis:** User-provided Frontend Coding Guide topics F01–F25, with references to official React guidance, W3C accessibility patterns, browser request semantics, and *99 Bottles of OOP* as a design source. No earlier source code, route shape, or component architecture has been imported.
