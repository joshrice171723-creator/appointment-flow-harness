# What V3/V4 imported from the four supplied documents

The user asked for selective integration rather than adding all original files verbatim. The original uploaded guides contain task-specific examples and references to the earlier application, which would contaminate this independent rebuild. They are **not** distributed to the coding agent. We retained transferable principles and wrote new clean-room summaries.

| Uploaded source | Clean-room treatment |
|---|---|
| `Ruby-and-Rails-Coding-Guide.md` | Distilled B1–B19 and R1–R6 into `standards/RUBY_RAILS_GUIDE.md`. |
| `Frontend-Coding-Guide.md` | Distilled F01–F25 into `standards/FRONTEND_GUIDE.md`. |
| `apex-human-code-quality-rubric-2026-11-06.md` | Deliberately **excluded** from V3. V4 has an adapted, source-independent operational review checklist. |
| `Frontend-Code-Quality-Rubric.md` | Deliberately **excluded** from V3. V4 has an adapted, source-independent operational review checklist. |

## Exclusions common to V3 and V4

- No earlier application's models, route names, service names, job implementation, API shapes, or source snippets.
- No book chapter excerpts or long reproductions of copyrighted texts; principles have been paraphrased into actionable rules.
- No unverified claims that a cited book mandates a particular Rails/React architecture.
- No forced folders, service objects, state managers, or tool installation solely because an example uses them.
- No automatic refactoring or speculative reviewer fixes; evidence and successful regression tests matter.

## Precedence and workflow

Official assessment and accepted behavior > product screenshots for visible styling > mandatory `AGENTS.md` safety/engineering constraints > `docs/CODING_STANDARDS.md` > applicable details in `standards/`. If two recommendations conflict, prefer the smallest solution that preserves tested behavior and document the tradeoff.

**V3:** Full V2 clean-room harness, its existing testing/CI and independent defect review, plus the two distilled coding guides. No scoring or formal quality-review rubric is provided or required.

**V4:** Exactly the V3 engineering standards and product inputs, plus a **separate, structured independent review stage** using two new evidence-based rubrics. Those rubrics are not mandatory reading for the implementing agent before feature development. This isolates rubric-driven review as the principal experimental variable.
