# Ruby and Rails guide — V3+ clean-room edition

**Role:** task-specific engineering guidance, not an architecture specification. Read relevant sections before implementing the associated feature. `AGENTS.md`, the official assessment, and the current project's proven behavior take precedence. This is distilled from the user-provided *Ruby-and-Rails-Coding-Guide.md*; no original application's code or architecture is included.

## Trace a real behavior before choosing an abstraction

1. Identify the entry point (request, scheduled task, reply), the inputs, the business decision, database reads/writes, external effect, and user-visible outcome.
2. Show normal, rejected, and boundary cases in terms the next engineer can understand. Prefer explicit branches to compact expressions that hide domain decisions.
3. Use a straightforward implementation for the first concrete case. Introduce a new class/module only when it gives a real concept one owner, isolates a changing dependency, or removes meaningful duplication.
4. Keep each method at a consistent level of explanation; name operations by the guarantee or result they provide. When an abstraction creates more navigation than clarity, inline it.
5. Choose descriptive argument names and units; don't make a caller guess whether a value is a clock time, timezone, appointment ID, patient ID, or status. Avoid broad hashes of loosely-defined options when a clear interface is feasible.

## Responsibilities and dependencies

- Prefer standard Rails routes, controllers, model associations and ordinary ActiveRecord relations. Do not create a service object as a rule of style; use one if it has a real, independently understandable domain responsibility.
- Keep request parsing/authorization scoping visibly separate from business decisions. A UI clinic selector does not establish data access authorization.
- Depend on a collaborator's *documented useful behavior*, not its internal representation. Keep external or volatile adapters at a narrow boundary; use simple fakes for this take-home.
- Give rules a clear owner. The caller should ask for an outcome, not reach into several internal fields to make a decision itself.
- When a domain abstraction is genuinely shared, demonstrate the concrete cases and the specific change it lets them share. No speculative inheritance, DSLs, callbacks, or metaprogramming.

## Persistence, concurrency, and external effects

- Show exactly which updates must commit together. Prefer narrow transactions; do not assume an in-memory or UI check prevents duplicate writes under concurrency.
- Decide transaction and idempotency boundaries explicitly for reminder runs, outbound attempts, and replies. Verify relevant mutable facts inside a transaction/lock **when correctness requires it**; use appropriate uniqueness constraints for races.
- Do not treat an external fake-provider call as part of a database transaction. Represent uncertain outcomes accurately and distinguish queued/attempted/accepted/delivered/confirmed when the product requires the distinctions.
- Read-only PMS replication is authoritative for source rows. Do not mutate replicated source records as an implementation shortcut; choose local persistence for app-owned state and explain its boundary.
- Appointment timestamps in the assessment are clinic-local wall-clock values without timezone data. Choose explicit timezone mapping and test ambiguities; do not silently parse them as UTC or infer a single timezone for an entire state.
- Keep data-exposure constraints concrete: no real patient data, no live provider messages, no procedure notes or sensitive details in reminder bodies and ordinary logs.

## Tests and small refactors

- Write tests for observable outcomes, persistence invariants, and critical failure cases. A test that asserts two calls to the same flawed production calculation proves little.
- Choose database/request-level tests for data boundaries and meaningful external effect tests for adapter contracts. Avoid mocking internal methods just to stabilize an implementation detail.
- For each refactor, name the before/after behavior being preserved; run the narrow relevant test and the project checks. If a test cannot run, report that precisely.
- Review the actual call site to see whether an extraction reduces knowledge the caller needs. Do not optimize for fewer lines or arbitrary method length limits.

## When to consult this guide

| Work | Start with |
|---|---|
| Eligibility/status rules | explicit cases, rule ownership, behavioral tests |
| Reminder scheduling, retries | transaction boundary, idempotency, fake-provider boundary |
| Patient confirmation/reply matching | request scope, identity, competing updates, outcome tests |
| Database/source replication | PMS read-only ownership, timestamps/timezones, constraints |
| Code simplification | call-site clarity, speculative abstraction, preservation tests |

**Source basis:** User-provided Ruby/Rails guide sections B1–B19 and R1–R6, incorporating ideas from *Eloquent Ruby*, *Practical Object-Oriented Design in Ruby*, *99 Bottles of OOP*, and Rails official documentation. This file is a concise practical synthesis, not a reproduction of the source books.
