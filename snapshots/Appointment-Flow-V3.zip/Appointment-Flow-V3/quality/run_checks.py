"""Run explicitly configured app checks; never return green for missing setup."""
from pathlib import Path
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "quality" / "checks.json"


def fail(message: str) -> int:
    print(f"QUALITY GATE FAILED: {message}")
    return 2


def main() -> int:
    if not CONFIG.is_file():
        return fail("quality/checks.json does not exist. Scaffold the app first, then adapt checks.example.json.")
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        checks = data["checks"]
    except (OSError, ValueError, KeyError) as exc:
        return fail(f"Invalid config: {exc}")
    if not isinstance(checks, list) or not checks:
        return fail("No checks configured; an empty list is not a passing quality gate.")

    errors = []
    for i, item in enumerate(checks, start=1):
        if not isinstance(item, dict):
            return fail(f"Check #{i} is not an object")
        name, cwd, command = item.get("name"), item.get("cwd"), item.get("command")
        if not isinstance(name, str) or not name.strip():
            return fail(f"Check #{i} has no name")
        if not isinstance(cwd, str) or not cwd.strip():
            return fail(f"Check {name!r} has no working directory")
        if not isinstance(command, list) or not command or not all(isinstance(arg, str) and arg for arg in command):
            return fail(f"Check {name!r} requires a nonempty command argv array")
        workdir = (ROOT / cwd).resolve()
        if not workdir.is_relative_to(ROOT.resolve()) or not workdir.is_dir():
            return fail(f"Check {name!r} references missing/outside directory: {cwd}")
        print(f"\n=== {name} ===", flush=True)
        print("Directory:", cwd, "| Command:", " ".join(command), flush=True)
        try:
            environment = os.environ.copy()
            environment.pop("NPM_CONFIG_ALLOW_SCRIPTS", None)
            environment["NPM_CONFIG_CACHE"] = str(ROOT / ".runtime" / "npm-cache")
            proc = subprocess.run(command, cwd=workdir, env=environment, check=False, timeout=900)
        except (OSError, subprocess.TimeoutExpired) as exc:
            errors.append((name, str(exc)))
            print("FAIL:", exc, flush=True)
            continue
        if proc.returncode != 0:
            errors.append((name, f"exit {proc.returncode}"))
            print("FAIL: exit", proc.returncode, flush=True)
        else:
            print("PASS", flush=True)

    if errors:
        print("\nQUALITY GATE FAILED:")
        for name, reason in errors:
            print(f"- {name}: {reason}")
        return 1
    print(f"\nQUALITY GATE PASS: all {len(checks)} configured checks succeeded.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
