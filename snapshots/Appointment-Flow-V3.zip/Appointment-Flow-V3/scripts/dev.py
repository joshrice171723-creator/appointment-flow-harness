"""Start this project's PostgreSQL cluster, Rails API and Vite; Ctrl+C stops app servers."""
from pathlib import Path
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
PG = Path(os.environ.get("POSTGRES_BIN", r"C:\Program Files\PostgreSQL\17\bin"))
ENV = os.environ.copy()
ENV.pop("NPM_CONFIG_ALLOW_SCRIPTS", None)
ENV["NPM_CONFIG_CACHE"] = str(ROOT / ".runtime" / "npm-cache")
ENV["TEMP"] = ENV["TMP"] = str(ROOT / ".runtime" / "tmp")
Path(ENV["TEMP"]).mkdir(parents=True, exist_ok=True)

def run(args, cwd=ROOT):
    subprocess.run(args, cwd=cwd, env=ENV, check=True)

def main():
    if not (ROOT / ".runtime/postgres/PG_VERSION").exists():
        run([str(PG / "initdb.exe"), "-D", ".runtime/postgres", "-U", "apex", "--auth=trust", "--encoding=UTF8", "--locale=C"])
    ready = subprocess.run([str(PG / "pg_isready.exe"), "-h", "127.0.0.1", "-p", "5543", "-U", "apex", "-d", "postgres"], capture_output=True)
    if ready.returncode:
        run([str(PG / "pg_ctl.exe"), "-D", ".runtime/postgres", "-l", ".runtime/postgres.log", "-o", "-p 5543 -h 127.0.0.1", "start"])
    run(["ruby", "-S", "bundle", "check"], ROOT / "backend")
    if not (ROOT / "frontend/node_modules").exists():
        run([shutil.which("npm.cmd") or "npm", "ci", "--no-audit", "--no-fund"], ROOT / "frontend")
    run(["ruby", "bin/rails", "db:prepare"], ROOT / "backend")
    processes = []
    try:
        processes.append(subprocess.Popen(["ruby", "bin/rails", "server", "-b", "127.0.0.1", "-p", "3105"], cwd=ROOT / "backend", env=ENV))
        processes.append(subprocess.Popen(["node", "node_modules/vite/bin/vite.js", "--host", "127.0.0.1"], cwd=ROOT / "frontend", env=ENV))
        print("Open http://127.0.0.1:5175 — fictional data and fake transport only", flush=True)
        while all(process.poll() is None for process in processes):
            time.sleep(1)
        raise RuntimeError("An app server stopped; inspect its output above")
    except KeyboardInterrupt:
        pass
    finally:
        for process in processes:
            if process.poll() is None:
                subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True)
    return 0

if __name__ == "__main__":
    sys.exit(main())
