Review the current **new-project** diff only. Focus strictly on simpler, more idiomatic, human-readable Ruby on Rails / React / TypeScript implementations. Do not modify unrelated files or introduce new abstractions to satisfy abstract clean-code slogans.

For each potential change, explain the real maintenance/correctness benefit. Prefer fewer layers, direct control flow, descriptive names, less duplicated domain logic, no redundant React state/effects, and appropriate Rails idioms. **Do not flatten necessary domain boundaries**, delete important tests, change externally visible behavior, or weaken privacy and idempotency logic.

Make only high-confidence improvements. Run the same tests/checks again. Report what became simpler and any proposals intentionally rejected as style-only or speculative.

Use the two `standards/` guides to inspect call-site legibility and state ownership, not to require extra layers. Preserve tests and observable behavior.
