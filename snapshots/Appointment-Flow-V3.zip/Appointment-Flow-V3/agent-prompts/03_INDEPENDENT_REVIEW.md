# V3 — Independent defect and maintainability review (no formal rubric)

This is the V2 review *workflow* retained without the V2 numeric or category rubric. Inspect the actual diff and nearby call sites/tests independently from the implementation session. Read `AGENTS.md`, `docs/ASSESSMENT_REQUIREMENTS.md`, `docs/ACCEPTANCE_MATRIX.md`, `standards/RUBY_RAILS_GUIDE.md`, and `standards/FRONTEND_GUIDE.md` as applicable.

Prioritize tangible risk: wrong recipient, clinic data exposure, unsafe fake/live messaging, duplicate reminders, reschedule handling, reply matching, local clinic times, failed/uncertain user actions, and tests that do not establish observable behavior. Then inspect naming, control-flow clarity, code duplication and unnecessary architectural layers.

Output concrete findings only: exact `path:line`, observed risk, demonstrated or unverified evidence, minimum safe change and tests/checks actually run. Summarize unresolved limitations. Do not issue a score, category verdict table or checklist rating. Do not apply speculative fixes automatically.
