# AI-authored decision notes for Joshua

These are implementation facts to evaluate, not your personal narrative.

- Chosen: Rails API + Vite React/TypeScript, PostgreSQL, standard Minitest; five cohesive screens and ordinary model-owned rules. Alternative: Rails serving the built SPA. Separate Vite dev server costs one local process but keeps the JS build familiar.
- Chosen cadence: both permitted channels at 7/3/1 days, latest eligible step only, 10–18 local. Confirmed visits get an informational final reminder. Optional day-six email was omitted because email already accompanies the initial request. Clinical preference and patient burden need validation.
- Source timestamps are wall-clock; explicit Austin/Chicago and Phoenix mappings. DST ambiguity fails closed. State abbreviation alone is insufficient.
- UUID revisions invalidate confirmation across moves, cancellations and returning to the original time. Source identity reassignment is rejected to avoid transferring history to the wrong patient. Deletion/partial refresh is investigated rather than guessed.
- Permissions are explicit synthetic seed assumptions. Unknown age/minors, unsupported language, shared recipients and source/verification conflicts block unsafe channels. No inferred guardian authority. A signed, verified production contact/consent process is still needed.
- One global row lock plus uniqueness constraints and bounded serialization retry are enough for an inspectable fake transport demo. This is a deliberate throughput limit, not a measured capacity claim for 4,000 appointments/day. A real provider would need an outbox and reconciliation rather than holding this transaction around network calls.
- STOP records suppression even if PMS is unavailable and uses the recipient of the original message. Other replies require a trusted current source read and a single safe appointment candidate; staff clarifies ambiguity per appointment with a required note.
- Staff/role headers are a stub, with server-side clinic scopes. A production identity must supply clinic memberships, role permissions, audit policy and signed provider callbacks. SELECT-only PMS credentials must enforce source ownership at the database boundary.
- Reporting uses PMS status mappings: complete/completed, broken/canceled, unscheduled/rescheduled, other/unknown. Validate those with the source owner. Completion rates are descriptive; they cannot establish no-show reduction or causation.
- One more week: stakeholder validation of consent/guardian rules and statuses, replica watermark, broader browser failure scenarios/accessibility review, real identity boundaries, operational measurement. No booking, full rescheduling, deployment or live messaging was added.

Open questions: authoritative consent source; guarantor permission proof; clinic timezone registry; how source deletes/corrections are communicated; desired reminder burden; whether broken/unscheduled imply cancellation/reschedule; retention; production failure recovery and no-show study design.
