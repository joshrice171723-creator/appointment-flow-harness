import { test, expect } from "@playwright/test";
test("staff, patient and leadership use persisted application data", async ({
  page,
}) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Workspaces" })).toBeVisible();
  await page.getByLabel("Clinic", { exact: true }).selectOption("1");
  await page.getByRole("button", { name: "Open front desk" }).click();
  await expect(
    page.getByRole("heading", { name: "Patient flow", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Run reminders", exact: true })
    .click();
  await expect(page.getByRole("status")).toContainText("fake transport");
  await page.getByRole("button", { name: "Appointments", exact: true }).click();
  await expect(page.getByRole("table")).toBeVisible();
  await page.getByRole("button", { name: "Workspaces" }).click();
  await page.getByRole("button", { name: "Open patient workspace" }).click();
  await page.getByLabel("Clinic", { exact: true }).selectOption("1");
  await page
    .getByLabel("Patient", { exact: true })
    .selectOption({ label: "Morgan Demo" });
  await expect(
    page.getByRole("heading", { name: "Message history" }),
  ).toBeVisible();
  await page.getByLabel("Your reply").fill("YES");
  await page.getByRole("button", { name: "Send simulated reply" }).click();
  await expect(page.getByRole("status")).toContainText("confirmed");
  await page.getByRole("button", { name: "Email", exact: true }).click();
  await page.getByLabel("Your reply").fill("YES");
  await page.getByRole("button", { name: "Send simulated reply" }).click();
  await expect(page.getByRole("status")).toContainText("confirmed");
  await page.reload();
  await page.getByLabel("Clinic", { exact: true }).selectOption("1");
  await page.getByRole("button", { name: "Open front desk" }).click();
  await page.getByRole("button", { name: "Appointments", exact: true }).click();
  const date = new Date();
  date.setDate(date.getDate() + 3);
  await page.getByLabel("Jump to date").fill(date.toLocaleDateString("en-CA"));
  await expect(
    page.getByRole("row").filter({ hasText: "Morgan Demo" }),
  ).toContainText("Confirmed");
  await page.getByRole("button", { name: "Workspaces" }).click();
  await page.getByRole("button", { name: "Open Apex leadership" }).click();
  await expect(
    page.getByRole("heading", { name: "Appointment outcomes" }),
  ).toBeVisible();
  await expect(page.getByRole("table")).toBeVisible();
  await expect(page.getByText("Morgan Demo")).toHaveCount(0);
  await page.screenshot({
    path: "test-results/leadership-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole("button", { name: "Workspaces" }).click();
  await expect(
    page.getByRole("button", { name: "Open patient workspace" }),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/workspaces-mobile.png",
    fullPage: true,
  });
});
