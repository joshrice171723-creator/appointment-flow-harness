import {
  render,
  screen,
  fireEvent,
  waitFor,
  cleanup,
} from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import PatientDetails from "./PatientDetails";
const patient = {
  id: 1,
  name: "Avery Demo",
  facts: { email: "avery@example.test" },
  source: { email: "avery@example.test" },
  verified: {},
  conflict: false,
  channels: ["email"],
  messages: [],
  replies: [],
  activities: [],
  visits: [
    {
      id: 1,
      source_id: 1,
      revision: "revision1",
      starts_at: "2026-11-22T21:00:00Z",
      confirmed: false,
      local_outcome: null,
      patient: "Avery Demo",
      contact_id: 1,
      source: {
        start_at: "2026-11-22T15:00:00Z",
        status: "scheduled",
        timezone: "America/Chicago",
      },
      follow_ups: [
        {
          id: 1,
          kind: "No reply near appointment",
          state: "needs_attention",
          owner: null,
        },
      ],
    },
  ],
};
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});
it("assignment preserves unsaved contact edits and notes", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn((_url: string, options?: RequestInit) =>
      Promise.resolve({
        ok: true,
        json: () =>
          Promise.resolve(
            options?.method === "POST"
              ? { result: "Follow-up saved" }
              : patient,
          ),
      }),
    ),
  );
  render(
    <PatientDetails
      id={1}
      workspace={{ role: "staff", clinic: "1", staff: "Taylor Morgan" }}
      onBack={() => {}}
    />,
  );
  await screen.findByText("Avery Demo");
  fireEvent.change(screen.getByLabelText("Email"), {
    target: { value: "corrected@example.test" },
  });
  fireEvent.change(screen.getByLabelText("Follow-up note"), {
    target: { value: "Keep my draft" },
  });
  fireEvent.click(screen.getByRole("button", { name: "Assign to me" }));
  await screen.findByRole("status");
  expect(screen.getByLabelText("Email")).toHaveValue("corrected@example.test");
  expect(screen.getByLabelText("Follow-up note")).toHaveValue("Keep my draft");
  fireEvent.click(screen.getByRole("button", { name: "Record follow-up" }));
  await waitFor(() =>
    expect(screen.getByLabelText("Follow-up note")).toHaveValue(""),
  );
  expect(screen.getByLabelText("Email")).toHaveValue("corrected@example.test");
});
it("a rejected follow-up retains the note and displays a recoverable error", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn((_url: string, options?: RequestInit) =>
      Promise.resolve({
        ok: options?.method !== "POST",
        json: () =>
          Promise.resolve(
            options?.method === "POST"
              ? { error: "Appointment changed; refresh before saving" }
              : patient,
          ),
      }),
    ),
  );
  render(
    <PatientDetails
      id={1}
      workspace={{ role: "staff", clinic: "1", staff: "Taylor Morgan" }}
      onBack={() => {}}
    />,
  );
  await screen.findByText("Avery Demo");
  fireEvent.change(screen.getByLabelText("Follow-up note"), {
    target: { value: "Keep after rejection" },
  });
  fireEvent.click(screen.getByRole("button", { name: "Record follow-up" }));
  await waitFor(() =>
    expect(screen.getByRole("alert")).toHaveTextContent("Appointment changed"),
  );
  expect(screen.getByLabelText("Follow-up note")).toHaveValue(
    "Keep after rejection",
  );
});
