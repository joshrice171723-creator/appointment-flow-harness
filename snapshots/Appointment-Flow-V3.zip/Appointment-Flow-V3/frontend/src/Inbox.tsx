import { useEffect, useState } from "react";
import { api, failure } from "./api";
import type { Clinic, Dashboard, Patient, Workspace } from "./types";
export default function Inbox({ clinics }: { clinics: Clinic[] }) {
  const [clinic, setClinic] = useState("");
  const [patients, setPatients] = useState<Dashboard["patients"]>([]);
  const [patient, setPatient] = useState("");
  const [data, setData] = useState<Patient | null>(null);
  const [channel, setChannel] = useState("sms");
  const [body, setBody] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [revision, setRevision] = useState(0);
  const [eventId, setEventId] = useState(crypto.randomUUID());
  const workspace: Workspace = { role: "patient", clinic, staff: "" };
  useEffect(() => {
    if (!clinic) return;
    const c = new AbortController();
    api<Dashboard>(
      "visits",
      { role: "patient", clinic, staff: "" },
      undefined,
      c.signal,
    )
      .then((d) => {
        if (!c.signal.aborted) setPatients(d.patients);
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(failure(e));
      });
    return () => c.abort();
  }, [clinic]);
  useEffect(() => {
    if (!patient) return;
    const c = new AbortController();
    api<Patient>(
      `contacts/${patient}`,
      { role: "patient", clinic, staff: "" },
      undefined,
      c.signal,
    )
      .then((d) => {
        if (!c.signal.aborted) setData(d);
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(failure(e));
      });
    return () => c.abort();
  }, [clinic, patient, revision]);
  async function send() {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const messages =
        data?.messages.filter((m) => m.channel === channel) ?? [];
      const result = await api<{ result: string }>("replies", workspace, {
        contact_id: patient,
        channel,
        body,
        external_id: eventId,
        message_id: messages.at(-1)?.id,
      });
      setNotice(
        `Reply recorded: ${result.result.replaceAll("_", " ")}. No live message was sent.`,
      );
      setBody("");
      setEventId(crypto.randomUUID());
      setRevision((r) => r + 1);
    } catch (e) {
      setError(
        `${failure(e)}. Draft retained; check history before retrying. The event ID is retained for a safe retry.`,
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="inbox">
      <h1>Patient inbox</h1>
      <p>Fictional patients · fake SMS and email</p>
      <label>
        Clinic
        <select
          disabled={busy}
          aria-label="Clinic"
          value={clinic}
          onChange={(e) => {
            setClinic(e.target.value);
            setPatient("");
            setPatients([]);
            setData(null);
            setBody("");
            setError("");
            setNotice("");
            setEventId(crypto.randomUUID());
          }}
        >
          <option value="">Choose a clinic</option>
          {clinics.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </label>
      {clinic && (
        <label>
          Patient
          <select
            disabled={busy}
            aria-label="Patient"
            value={patient}
            onChange={(e) => {
              setPatient(e.target.value);
              setData(null);
              setBody("");
              setNotice("");
              setEventId(crypto.randomUUID());
            }}
          >
            <option value="">Choose a patient</option>
            {patients.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {notice && (
        <p className="notice" role="status">
          {notice}
        </p>
      )}
      {patient && !data && <p>Loading message history…</p>}
      {data && (
        <>
          <nav className="tabs">
            {[
              ["sms", "Text messages"],
              ["email", "Email"],
            ].map(([value, label]) => (
              <button
                disabled={busy}
                className={channel === value ? "" : "secondary"}
                key={value}
                onClick={() => {
                  setChannel(value);
                  setBody("");
                  setNotice("");
                  setEventId(crypto.randomUUID());
                }}
              >
                {label}
              </button>
            ))}
          </nav>
          <h2>Message history</h2>
          {data.messages
            .filter((m) => m.channel === channel)
            .map((m) => (
              <article className="bubble" key={m.id}>
                <small>
                  Clinic reminder · {m.status} ·{" "}
                  {new Date(m.created_at).toLocaleString()}
                </small>
                <p>{m.body}</p>
              </article>
            ))}
          {data.replies
            .filter((r) => r.channel === channel)
            .map((r) => (
              <article className="bubble reply" key={r.id}>
                <small>
                  Your reply · {r.result} ·{" "}
                  {new Date(r.created_at).toLocaleString()}
                </small>
                <p>{r.body}</p>
              </article>
            ))}
          {data.messages.filter((m) => m.channel === channel).length === 0 && (
            <p>
              No simulated {channel === "sms" ? "text messages" : "emails"} for
              this patient yet.
            </p>
          )}
          <form
            className="card"
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
          >
            <label>
              Your reply
              <textarea
                required
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="YES, NO, STOP, or a reply for staff review"
              />
            </label>
            <button disabled={busy}>Send simulated reply</button>
          </form>
        </>
      )}
    </main>
  );
}
