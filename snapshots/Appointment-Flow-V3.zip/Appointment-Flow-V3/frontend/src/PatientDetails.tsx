import { useEffect, useState } from "react";
import { api, failure, localTime } from "./api";
import type { Issue, Patient, Visit, Workspace } from "./types";

export default function PatientDetails({
  id,
  workspace,
  onBack,
}: {
  id: number;
  workspace: Workspace;
  onBack: () => void;
}) {
  const [data, setData] = useState<Patient | null>(null);
  const [revision, setRevision] = useState(0);
  const [tab, setTab] = useState("Follow-up");
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    api<Patient>(`contacts/${id}`, workspace, undefined, controller.signal)
      .then((patient) => {
        if (!controller.signal.aborted) {
          setData(patient);
          setError("");
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) setError(failure(e));
      });
    return () => controller.abort();
  }, [id, workspace, revision]);
  function refresh() {
    setRevision((value) => value + 1);
  }
  return (
    <>
      <button className="link" onClick={onBack}>
        ← Patient flow
      </button>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {!data ? (
        <p>Loading patient…</p>
      ) : (
        <>
          <h2>{data.name}</h2>
          <div className="patient-layout">
            <ContactVerification
              patient={data}
              workspace={workspace}
              onSaved={refresh}
            />
            <section>
              <nav className="tabs">
                {["Follow-up", "Appointments", "Activity log"].map((value) => (
                  <button
                    key={value}
                    className={tab === value ? "" : "secondary"}
                    onClick={() => setTab(value)}
                  >
                    {value}
                  </button>
                ))}
              </nav>
              {tab === "Follow-up" ? (
                <>
                  {data.visits.flatMap((visit) =>
                    visit.follow_ups.map((issue) => (
                      <FollowUpForm
                        key={issue.id}
                        issue={issue}
                        visit={visit}
                        workspace={workspace}
                        onSaved={refresh}
                      />
                    )),
                  )}
                  {data.visits.every(
                    (visit) => visit.follow_ups.length === 0,
                  ) && (
                    <section className="card">
                      <p>No follow-up items.</p>
                    </section>
                  )}
                </>
              ) : tab === "Appointments" ? (
                data.visits.map((visit) => (
                  <article className="card" key={visit.id}>
                    <h3>Appointment #{visit.source_id}</h3>
                    <p>{localTime(visit)}</p>
                    <p>
                      {visit.confirmed ? "Confirmed" : "Unconfirmed"} · PMS:{" "}
                      {visit.source.status}
                    </p>
                  </article>
                ))
              ) : (
                <section className="card">
                  <h3>Activity log</h3>
                  {data.activities.map((activity) => (
                    <p key={activity.id}>
                      {activity.action} · {activity.staff} ·{" "}
                      {new Date(activity.created_at).toLocaleString()}
                      <br />
                      {activity.note}
                      {activity.details?.appointment && (
                        <small>
                          Appointment #{activity.details.appointment} · recorded
                          time:{" "}
                          {activity.details.start_at
                            ?.replace("T", " ")
                            .replace("Z", "")}
                        </small>
                      )}
                      {activity.details?.after &&
                        Object.entries(activity.details.after).map(
                          ([field, value]) => (
                            <small key={field}>
                              {field.replaceAll("_", " ")}:{" "}
                              {activity.details.before?.[field] || "No value"} →{" "}
                              {value || "No value"}
                            </small>
                          ),
                        )}
                    </p>
                  ))}
                  {data.replies.map((reply) => (
                    <p key={`reply-${reply.id}`}>
                      Reply: {reply.body} · {reply.result}
                    </p>
                  ))}
                  {data.messages.map((message) => (
                    <p key={`message-${message.id}`}>
                      {message.channel} · {message.status} · {message.body}
                    </p>
                  ))}
                  {data.activities.length +
                    data.replies.length +
                    data.messages.length ===
                    0 && <p>No activity recorded.</p>}
                </section>
              )}
            </section>
          </div>
        </>
      )}
    </>
  );
}

function ContactVerification({
  patient,
  workspace,
  onSaved,
}: {
  patient: Patient;
  workspace: Workspace;
  onSaved: () => void;
}) {
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [note, setNote] = useState("");
  const [requestId, setRequestId] = useState(crypto.randomUUID());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  async function verify() {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const result = await api<{ result: string }>(
        `contacts/${patient.id}/verify`,
        workspace,
        { contact: edits, note, request_id: requestId },
      );
      setNotice(result.result);
      setEdits({});
      setNote("");
      setRequestId(crypto.randomUUID());
      onSaved();
    } catch (error) {
      setError(
        `${failure(error)}. Draft retained. Check the saved outcome before retrying.`,
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <aside className="card">
      <h2>Patient details</h2>
      <p>Local verification · source remains unchanged</p>
      {patient.conflict && (
        <p className="error">
          Source and verified details conflict. Review source values before
          verifying again.
        </p>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {notice && (
        <p className="notice" role="status">
          {notice}
        </p>
      )}
      <form
        onSubmit={(event) => {
          event.preventDefault();
          verify();
        }}
      >
        {[
          ["birthdate", "Birthdate"],
          ["wireless_phone", "Mobile phone"],
          ["email", "Email"],
          ["preferred_language", "Preferred language"],
        ].map(([field, label]) => (
          <label key={field}>
            {label}
            <input
              aria-label={label}
              type={field === "birthdate" ? "date" : "text"}
              value={edits[field] ?? patient.facts[field] ?? ""}
              onChange={(event) =>
                setEdits({ ...edits, [field]: event.target.value })
              }
            />
            <small>
              {field in patient.verified ? "Verified locally" : "Not verified"}{" "}
              · PMS: {patient.source[field] || "No value"}
            </small>
          </label>
        ))}
        <label>
          Verification note
          <textarea
            required
            value={note}
            onChange={(event) => setNote(event.target.value)}
          />
        </label>
        <button disabled={busy || Object.keys(edits).length === 0}>
          Verify local details
        </button>
      </form>
      <p>Available channels: {patient.channels.join(", ") || "None"}</p>
    </aside>
  );
}

function FollowUpForm({
  issue,
  visit,
  workspace,
  onSaved,
}: {
  issue: Issue;
  visit: Visit;
  workspace: Workspace;
  onSaved: () => void;
}) {
  const [note, setNote] = useState("");
  const [outcome, setOutcome] = useState("attempted");
  const [requestId, setRequestId] = useState(crypto.randomUUID());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  async function save(assign = false) {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const result = await api<{ result: string }>(
        `follow_ups/${issue.id}`,
        workspace,
        {
          outcome: assign ? "assign" : outcome,
          note,
          request_id: requestId,
          revision: visit.revision,
        },
      );
      setNotice(result.result);
      if (!assign) {
        setNote("");
        setRequestId(crypto.randomUUID());
      }
      onSaved();
    } catch (error) {
      setError(
        `${failure(error)}. Draft retained. Check the saved outcome before retrying.`,
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <article className="card">
      <span className="pill">{issue.state.replaceAll("_", " ")}</span>
      <h3>{issue.kind}</h3>
      <p>
        Appointment #{visit.source_id} · {localTime(visit)}
      </p>
      <p>{issue.owner || "Unassigned"}</p>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {notice && (
        <p className="notice" role="status">
          {notice}
        </p>
      )}
      {issue.state !== "resolved" && (
        <>
          <button
            className="secondary"
            disabled={busy}
            onClick={() => save(true)}
          >
            Assign to me
          </button>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              save();
            }}
          >
            <label>
              Outcome
              <select
                value={outcome}
                onChange={(event) => setOutcome(event.target.value)}
              >
                {[
                  "attempted",
                  "confirmed",
                  "canceled",
                  "rescheduled",
                  "reviewed",
                ].map((value) => (
                  <option key={value}>{value}</option>
                ))}
              </select>
            </label>
            <label>
              Follow-up note
              <textarea
                required
                value={note}
                onChange={(event) => setNote(event.target.value)}
              />
            </label>
            <button disabled={busy}>Record follow-up</button>
          </form>
        </>
      )}
    </article>
  );
}
