import { useEffect, useState } from "react";
import { api, failure } from "./api";
import type { Report, Workspace } from "./types";
export default function Leadership({ workspace }: { workspace: Workspace }) {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [data, setData] = useState<Report | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    const c = new AbortController();
    api<Report>(`leadership?month=${month}`, workspace, undefined, c.signal)
      .then((d) => {
        if (!c.signal.aborted) {
          setData(d);
          setError("");
        }
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(failure(e));
      });
    return () => c.abort();
  }, [workspace, month]);
  return (
    <main>
      <div className="toolbar">
        <h1>Appointment outcomes</h1>
        <label>
          Outcome month
          <input
            type="month"
            value={month}
            onChange={(e) => {
              setMonth(e.target.value);
              setData(null);
            }}
          />
        </label>
      </div>
      <p>
        Completion = completed PMS visits ÷ all recorded visits in the selected
        appointment month. These records do not establish no-shows or reminder
        effectiveness.
      </p>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {!data ? (
        <p>Loading outcomes…</p>
      ) : (
        <>
          <section className="card clinic-grid">
            {data.clinics.map((c) => (
              <article key={c.clinic}>
                <h2>{c.clinic}</h2>
                <p>{c.recorded} recorded visits</p>
                <div
                  className="outcome-bar"
                  aria-label={`${c.completion_rate ?? 0}% completed`}
                >
                  {(
                    ["completed", "rescheduled", "canceled", "unknown"] as const
                  ).map((k) => (
                    <span
                      key={k}
                      className={k}
                      style={{
                        width: `${c.recorded ? (100 * c[k]) / c.recorded : 0}%`,
                      }}
                    />
                  ))}
                </div>
                <div className="stats">
                  {(
                    ["completed", "rescheduled", "canceled", "unknown"] as const
                  ).map((k) => (
                    <p key={k}>
                      {k}
                      <strong className="big">{c[k]}</strong>
                    </p>
                  ))}
                </div>
              </article>
            ))}
          </section>
          <section className="card table-wrap">
            <h2>Clinic comparison</h2>
            <table>
              <thead>
                <tr>
                  <th>Clinic</th>
                  <th>Completion rate</th>
                  <th>Recorded visits</th>
                  <th>Rescheduled</th>
                  <th>Canceled</th>
                  <th>Unknown</th>
                </tr>
              </thead>
              <tbody>
                {data.clinics.map((c) => (
                  <tr key={c.clinic}>
                    <td>{c.clinic}</td>
                    <td>
                      {c.completion_rate === null
                        ? "Unavailable"
                        : `${c.completion_rate}%`}
                    </td>
                    <td>{c.recorded}</td>
                    <td>{c.rescheduled}</td>
                    <td>{c.canceled}</td>
                    <td>{c.unknown}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
          <details className="card">
            <summary>Reminder activity</summary>
            <p>
              Attempts for visits in {month}. Fake accepted does not mean
              delivered.
            </p>
            {data.clinics.map((c) => (
              <p key={c.clinic}>
                {c.clinic}:{" "}
                {Object.entries(c.messages)
                  .map(([key, value]) => `${key}: ${value}`)
                  .join(", ") || "No attempts"}
              </p>
            ))}
          </details>
          <details className="card">
            <summary>Contact holds</summary>
            <p>
              Open contact or timing issues for visits in the selected
              appointment month.
            </p>
            {data.clinics.map((c) => (
              <p key={c.clinic}>
                {c.clinic}: {c.holds}
              </p>
            ))}
          </details>
          <details className="card">
            <summary>Contact and follow-up</summary>
            {data.clinics.map((c) => (
              <p key={c.clinic}>
                {c.clinic}:{" "}
                {Object.entries(c.issues)
                  .map(
                    ([key, value]) => `${key.replaceAll("_", " ")}: ${value}`,
                  )
                  .join(", ") || "No follow-up items"}
              </p>
            ))}
          </details>
        </>
      )}
    </main>
  );
}
