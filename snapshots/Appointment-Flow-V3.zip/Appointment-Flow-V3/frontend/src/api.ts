import type { Workspace } from "./types";
export async function api<T>(
  path: string,
  workspace?: Workspace,
  body?: unknown,
  signal?: AbortSignal,
): Promise<T> {
  const response = await fetch(`/api/${path}`, {
    method: body === undefined ? "GET" : "POST",
    signal,
    headers: {
      "Content-Type": "application/json",
      ...(workspace
        ? {
            "X-Workspace": workspace.role,
            "X-Clinic-Id": workspace.clinic,
            "X-Staff": workspace.staff,
          }
        : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok)
    throw new Error(data.error || `Request rejected (${response.status})`);
  return data as T;
}
export function failure(error: unknown): string {
  return error instanceof Error ? error.message : "Request failed";
}
export function localTime(visit: {
  starts_at: string | null;
  source: { timezone: string };
}): string {
  return visit.starts_at
    ? new Intl.DateTimeFormat("en-US", {
        dateStyle: "medium",
        timeStyle: "short",
        timeZone: visit.source.timezone,
      }).format(new Date(visit.starts_at))
    : "Appointment time needs review";
}
export function localDate(visit: { source: { start_at: string } }): string {
  return visit.source.start_at.slice(0, 10);
}
