import {
  render,
  screen,
  fireEvent,
  waitFor,
  cleanup,
} from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";
import Inbox from "./Inbox";
const clinics = [
  { id: 1, name: "Austin, TX", timezone: "America/Chicago" },
  { id: 2, name: "Phoenix, AZ", timezone: "America/Phoenix" },
];
const response = (data: unknown) =>
  Promise.resolve({ ok: true, json: () => Promise.resolve(data) } as Response);
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});
beforeEach(() =>
  vi.stubGlobal(
    "fetch",
    vi.fn(() => response(clinics)),
  ),
);
describe("workspace flows", () => {
  it("requires a clinic before opening the front desk", async () => {
    render(<App />);
    expect(screen.getByText("Open front desk →")).toBeDisabled();
    await screen.findByText("Austin, TX");
    fireEvent.change(screen.getByLabelText("Clinic"), {
      target: { value: "1" },
    });
    expect(screen.getByText("Open front desk →")).toBeEnabled();
  });
  it("ignores a late response after switching clinics", async () => {
    let finish: ((value: Response) => void) | undefined;
    let calls = 0;
    vi.stubGlobal(
      "fetch",
      vi.fn(() => {
        calls++;
        return calls === 1
          ? new Promise<Response>((resolve) => {
              finish = resolve;
            })
          : response({ patients: [{ id: 2, name: "Phoenix Demo" }] });
      }),
    );
    render(<Inbox clinics={clinics} />);
    fireEvent.change(screen.getByLabelText("Clinic"), {
      target: { value: "1" },
    });
    fireEvent.change(screen.getByLabelText("Clinic"), {
      target: { value: "2" },
    });
    await screen.findByText("Phoenix Demo");
    finish?.({
      ok: true,
      json: () =>
        Promise.resolve({ patients: [{ id: 1, name: "Austin Demo" }] }),
    } as Response);
    await waitFor(() =>
      expect(screen.queryByText("Austin Demo")).not.toBeInTheDocument(),
    );
  });
});
