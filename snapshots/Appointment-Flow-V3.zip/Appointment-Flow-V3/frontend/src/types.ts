export type Clinic = { id: number; name: string; timezone: string };
export type Workspace = {
  role: "staff" | "patient" | "leadership";
  clinic: string;
  staff: string;
};
export type Issue = {
  id: number;
  kind: string;
  state: string;
  owner: string | null;
};
export type Visit = {
  id: number;
  source_id: number;
  revision: string;
  starts_at: string | null;
  confirmed: boolean;
  local_outcome: string | null;
  patient: string;
  contact_id: number;
  source: {
    start_at: string;
    status: string;
    clinic_name: string;
    timezone: string;
    provider_name: string;
  };
  follow_ups: Issue[];
};
export type Dashboard = {
  visits: Visit[];
  patients: { id: number; name: string }[];
  sync: { succeeded_at: string | null; error: string | null };
};
export type Message = {
  id: number;
  channel: string;
  body: string;
  status: string;
  created_at: string;
  visit_id: number;
};
export type Patient = {
  id: number;
  name: string;
  facts: Record<string, string | null>;
  source: Record<string, string | null>;
  verified: Record<string, string>;
  conflict: boolean;
  channels: string[];
  visits: Visit[];
  messages: Message[];
  replies: {
    id: number;
    body: string;
    channel: string;
    result: string;
    created_at: string;
  }[];
  activities: {
    id: number;
    staff: string;
    note: string;
    action: string;
    details: {
      appointment?: number;
      start_at?: string;
      before?: Record<string, string | null>;
      after?: Record<string, string | null>;
    };
    created_at: string;
  }[];
};
export type Report = {
  month: string;
  clinics: {
    clinic: string;
    recorded: number;
    completed: number;
    canceled: number;
    rescheduled: number;
    unknown: number;
    completion_rate: number | null;
    messages: Record<string, number>;
    issues: Record<string, number>;
    holds: number;
  }[];
};
