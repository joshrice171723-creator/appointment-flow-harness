import { useEffect, useState } from "react";
import { api, failure } from "./api";
import type { Clinic, Workspace } from "./types";
import Staff from "./Staff";
import Inbox from "./Inbox";
import Leadership from "./Leadership";
export default function App() {
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [clinic, setClinic] = useState("");
  const [staff, setStaff] = useState("Taylor Morgan");
  const [workspace, setWorkspace] = useState<Workspace | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    const c = new AbortController();
    api<Clinic[]>("clinics", undefined, undefined, c.signal)
      .then((d) => {
        if (!c.signal.aborted) setClinics(d);
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(failure(e));
      });
    return () => c.abort();
  }, []);
  return (
    <>
      <header>
        <a className="brand" href="#" onClick={() => setWorkspace(null)}>
          <span className="mark">A↗</span>
          <span>
            APEX<small>APPOINTMENT FLOW</small>
          </span>
        </a>
        <button className="link" onClick={() => setWorkspace(null)}>
          Workspaces ↗
        </button>
      </header>
      {error && (
        <p role="alert" className="error">
          {error}. Check that Rails is running, then reload.
        </p>
      )}
      {!workspace ? (
        <main className="landing">
          <h1>Workspaces</h1>
          <div className="workspace-grid">
            <section className="card workspace">
              <h2>Front desk</h2>
              <p>Review appointments and record patient follow-up.</p>
              <label>
                Clinic
                <select
                  aria-label="Clinic"
                  value={clinic}
                  onChange={(e) => setClinic(e.target.value)}
                >
                  <option value="">Choose a clinic</option>
                  {clinics.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Staff member · demo sign-in
                <select
                  value={staff}
                  onChange={(e) => setStaff(e.target.value)}
                >
                  <option>Taylor Morgan</option>
                  <option>Jordan Lee</option>
                </select>
              </label>
              <button
                disabled={!clinic}
                onClick={() => setWorkspace({ role: "staff", clinic, staff })}
              >
                Open front desk →
              </button>
            </section>
            <section className="card workspace leadership">
              <h2>Apex leadership</h2>
              <p>Aggregate clinic outcomes. No patient details.</p>
              <strong className="big">{clinics.length}</strong>
              <p>reporting clinics</p>
              <button
                onClick={() =>
                  setWorkspace({ role: "leadership", clinic: "", staff: "" })
                }
              >
                Open Apex leadership →
              </button>
            </section>
            <section className="card workspace">
              <h2>Patient</h2>
              <p>Internal demo. Inspect fake messages and simulate a reply.</p>
              <button
                onClick={() =>
                  setWorkspace({ role: "patient", clinic: "", staff: "" })
                }
              >
                Open patient workspace →
              </button>
            </section>
          </div>
        </main>
      ) : workspace.role === "staff" ? (
        <Staff key={workspace.clinic} workspace={workspace} clinics={clinics} />
      ) : workspace.role === "patient" ? (
        <Inbox clinics={clinics} />
      ) : (
        <Leadership workspace={workspace} />
      )}
    </>
  );
}
