import { useEffect, useState } from "react";
import { api, failure, localDate, localTime } from "./api";
import type { Clinic, Dashboard, Visit, Workspace } from "./types";
import PatientDetails from "./PatientDetails";
export default function Staff({
  workspace,
  clinics,
}: {
  workspace: Workspace;
  clinics: Clinic[];
}) {
  const clinic = clinics.find((c) => String(c.id) === workspace.clinic);
  const [data, setData] = useState<Dashboard | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [revision, setRevision] = useState(0);
  const [view, setView] = useState("board");
  const [patient, setPatient] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState("");
  const [state, setState] = useState("active");
  const [page, setPage] = useState(1);
  const [date, setDate] = useState(
    new Date().toLocaleDateString("en-CA", { timeZone: clinic?.timezone }),
  );
  const [filter, setFilter] = useState("All");
  useEffect(() => {
    const c = new AbortController();
    api<Dashboard>("visits", workspace, undefined, c.signal)
      .then((d) => {
        if (!c.signal.aborted) {
          setData(d);
          setError("");
        }
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(failure(e));
      });
    return () => c.abort();
  }, [workspace, revision]);
  async function run(action: string) {
    setBusy(true);
    setNotice("");
    setError("");
    try {
      const result = await api<{ result: string }>(action, workspace, {});
      setNotice(result.result);
      setRevision((r) => r + 1);
    } catch (e) {
      setError(failure(e));
    } finally {
      setBusy(false);
    }
  }
  const issues =
    data?.visits.flatMap((v) =>
      v.follow_ups.map((i) => ({ ...i, visit: v })),
    ) ?? [];
  const matches = issues.filter(
    (i) =>
      (state === "resolved"
        ? i.state === "resolved"
        : i.state !== "resolved") &&
      (!kind || i.kind === kind) &&
      i.visit.patient.toLowerCase().includes(search.toLowerCase()),
  );
  const pages = Math.max(1, Math.ceil(matches.length / 10));
  const currentPage = Math.min(page, pages);
  const appointments = (data?.visits ?? []).filter(
    (v) =>
      localDate(v) === date &&
      (filter === "All" ||
        (filter === "Confirmed"
          ? v.confirmed
          : filter === "Unconfirmed"
            ? !v.confirmed
            : v.follow_ups.some(
                (i) =>
                  i.kind === "Reply needs review" && i.state !== "resolved",
              ))),
  );
  function moveDate(days: number) {
    const next = new Date(date + "T12:00:00");
    next.setDate(next.getDate() + days);
    setDate(next.toLocaleDateString("en-CA"));
  }
  function open(v: Visit) {
    setPatient(v.contact_id);
  }
  return (
    <main>
      <div className="toolbar">
        <div>
          <p className="eyebrow">
            {clinic?.name} · {workspace.staff}
          </p>
          <h1>
            {patient
              ? "Patient follow-up"
              : view === "board"
                ? "Patient flow"
                : "Appointments"}
          </h1>
          <p className="muted">
            Last PMS sync:{" "}
            {data?.sync.succeeded_at
              ? new Date(data.sync.succeeded_at).toLocaleString()
              : "Not refreshed"}{" "}
            · {clinic?.timezone}
          </p>
        </div>
        <nav>
          <button
            className="secondary"
            onClick={() => {
              setView("board");
              setPatient(null);
            }}
          >
            Patient flow
          </button>
          <button
            className="secondary"
            onClick={() => {
              setView("appointments");
              setPatient(null);
            }}
          >
            Appointments
          </button>
        </nav>
      </div>
      <div className="toolbar">
        <p>Demo sign-in · fake transport only</p>
        <div>
          <button
            className="secondary"
            disabled={busy}
            onClick={() => run("refresh")}
          >
            Refresh PMS
          </button>{" "}
          <button disabled={busy} onClick={() => run("reminders")}>
            Run reminders
          </button>
        </div>
      </div>
      {(error || data?.sync.error) && (
        <p role="alert" className="error">
          {error || data?.sync.error}
        </p>
      )}
      {notice && (
        <p role="status" className="notice">
          {notice}
        </p>
      )}
      {!data ? (
        <p>Loading appointments…</p>
      ) : patient ? (
        <PatientDetails
          key={patient}
          id={patient}
          workspace={workspace}
          onBack={() => {
            setPatient(null);
            setRevision((r) => r + 1);
          }}
        />
      ) : view === "board" ? (
        <>
          <div className="stats">
            {["needs_attention", "in_progress", "resolved"].map((s, i) => (
              <section className="card" key={s}>
                <p>{["Needs attention", "In progress", "Resolved"][i]}</p>
                <strong className="big">
                  {issues.filter((item) => item.state === s).length}
                </strong>
              </section>
            ))}
          </div>
          <div className="toolbar">
            <nav>
              {["active", "resolved"].map((s) => (
                <button
                  className={state === s ? "" : "secondary"}
                  key={s}
                  onClick={() => {
                    setState(s);
                    setPage(1);
                  }}
                >
                  {s === "active" ? "Active work" : "Resolved"}
                </button>
              ))}
            </nav>
            <label>
              Find a patient
              <input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
              />
            </label>
            <label>
              Follow-up type
              <select
                value={kind}
                onChange={(e) => {
                  setKind(e.target.value);
                  setPage(1);
                }}
              >
                <option value="">All follow-up types</option>
                {[...new Set(issues.map((i) => i.kind))].map((k) => (
                  <option key={k}>{k}</option>
                ))}
              </select>
            </label>
          </div>
          <div className="board">
            {(state === "resolved"
              ? ["resolved"]
              : ["needs_attention", "in_progress"]
            ).map((column) => (
              <section className="column" key={column}>
                <h2>
                  {column === "needs_attention"
                    ? "Needs attention"
                    : column === "in_progress"
                      ? "In progress"
                      : "Resolved"}
                </h2>
                {matches
                  .slice((currentPage - 1) * 10, currentPage * 10)
                  .filter((i) => i.state === column)
                  .map((i) => (
                    <article className="card issue" key={i.id}>
                      <span className="pill">{i.kind}</span>
                      <h3>
                        <button className="link" onClick={() => open(i.visit)}>
                          {i.visit.patient} ↗
                        </button>
                      </h3>
                      <p>{localTime(i.visit)}</p>
                      <p className="muted">
                        {i.owner || "Unassigned"} · Appointment #
                        {i.visit.source_id}
                      </p>
                    </article>
                  ))}
                {!matches.some((i) => i.state === column) && (
                  <p>No matching work.</p>
                )}
              </section>
            ))}
          </div>
          <div className="toolbar">
            <span>
              {matches.length} matching items · Page {currentPage} of {pages}
            </span>
            <nav>
              <button
                className="secondary"
                disabled={currentPage <= 1}
                onClick={() => setPage(currentPage - 1)}
              >
                Previous
              </button>
              <button
                className="secondary"
                disabled={currentPage >= pages}
                onClick={() => setPage(currentPage + 1)}
              >
                Next
              </button>
            </nav>
          </div>
        </>
      ) : (
        <>
          <section className="card">
            <div className="toolbar">
              <nav>
                <button className="secondary" onClick={() => moveDate(-7)}>
                  ← Previous week
                </button>
                <button
                  className="secondary"
                  onClick={() =>
                    setDate(
                      new Date().toLocaleDateString("en-CA", {
                        timeZone: clinic?.timezone,
                      }),
                    )
                  }
                >
                  Today
                </button>
                <button className="secondary" onClick={() => moveDate(7)}>
                  Next week →
                </button>
              </nav>
              <label>
                Jump to date
                <input
                  type="date"
                  value={date}
                  onChange={(e) => {
                    if (e.target.value) setDate(e.target.value);
                  }}
                />
              </label>
            </div>
            <div className="week">
              {Array.from({ length: 7 }, (_, i) => {
                const d = new Date(date + "T12:00:00");
                d.setDate(d.getDate() - d.getDay() + i);
                const day = d.toLocaleDateString("en-CA");
                return (
                  <button
                    className={day === date ? "" : "secondary"}
                    key={day}
                    onClick={() => setDate(day)}
                  >
                    {d.toLocaleDateString("en-US", {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                    })}
                    <small>
                      {data.visits.filter((v) => localDate(v) === day).length}{" "}
                      visits
                    </small>
                  </button>
                );
              })}
            </div>
          </section>
          <nav className="tabs">
            {["All", "Confirmed", "Unconfirmed", "Replies to review"].map(
              (f) => (
                <button
                  className={filter === f ? "" : "secondary"}
                  key={f}
                  onClick={() => setFilter(f)}
                >
                  {f}
                </button>
              ),
            )}
          </nav>
          <div className="card table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Appointment · {clinic?.timezone}</th>
                  <th>Confirmation</th>
                  <th>PMS outcome</th>
                  <th>Next step</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((v) => (
                  <tr key={v.id}>
                    <td>
                      {v.patient}
                      <small>#{v.source_id}</small>
                    </td>
                    <td>
                      {localTime(v)}
                      <small>{v.source.provider_name}</small>
                    </td>
                    <td>
                      <span className="pill">
                        {v.confirmed ? "Confirmed" : "Unconfirmed"}
                      </span>
                    </td>
                    <td>
                      {v.source.status}
                      <small>
                        {v.local_outcome
                          ? `Staff recorded: ${v.local_outcome}`
                          : ""}
                      </small>
                    </td>
                    <td>
                      <button className="link" onClick={() => open(v)}>
                        Patient details →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {appointments.length === 0 && (
              <p>No appointments match this date and filter.</p>
            )}
          </div>
        </>
      )}
    </main>
  );
}
