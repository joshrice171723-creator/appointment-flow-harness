import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5175,
    strictPort: true,
    proxy: { "/api": "http://127.0.0.1:3105" },
  },
  test: {
    include: ["src/**/*.test.{ts,tsx}"],
    maxWorkers: 1,
    testTimeout: 15000,
    environment: "jsdom",
    setupFiles: ["./src/test-setup.ts"],
  },
});
