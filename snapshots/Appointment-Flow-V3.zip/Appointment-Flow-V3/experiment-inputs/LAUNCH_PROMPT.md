# V3 launch prompt

Verbatim saved user messages, in chronological order. Headings are packaging annotations; message bodies are unchanged.

## User message 1 ? 2026-11-15T16:10:07.294Z

@C:/Users/joshr/Downloads/Apex_Clean_Room_V3_RubyMine_Harness_UPDATED.zip
You are the lead software engineer responsible for independently rebuilding the Apex Appointment Confirmation System using the clean-room engineering harness provided in this project.

## Your Mission

Build a complete, functional, production-quality Ruby on Rails + React application from scratch.

This is a controlled experiment to evaluate whether a disciplined AI engineering harness produces better, more readable, maintainable code.

Your goal is not to generate code quickly. Your goal is to build a correct, understandable application that an experienced software engineer could confidently maintain.

**Engineering priorities, in order:**
1. Correctness
2. Readability
3. Simplicity
4. Maintainability
5. Performance, where relevant

## Phase 1 — Initialize the Harness

Before writing ANY application code:

1. Read `AGENTS.md` completely.
2. Read `START_HERE.md`.
3. Read and execute the instructions in `RUN_THIS_IN_RUBYMINE.md`.
4. Review the original assessment PDF, product specifications, acceptance criteria, workflows, scenarios, and all 10 screenshots.
5. Load the Rails and React engineering standards and applicable review instructions.
6. Run the included harness verification script.
7. Identify which harness version you're using and activate only that version's intended workflow.
8. Check the available Ruby, Rails, Node, PostgreSQL, and testing tools.
9. Establish a concise implementation plan and record important assumptions.

Do not begin application development until the harness has been verified and its instructions understood.

## Phase 2 — Independent Implementation

You have complete freedom to choose the architecture and implementation, subject to the product requirements and engineering standards.

- Reproduce the documented product behavior and key visual workflows.
- Use the assessment PDF as the authoritative scope.
- Follow conventional Rails and React practices.
- Prefer simple, well-understood solutions over clever abstractions.
- Keep functions, classes, and components cohesive.
- Avoid unnecessary service objects, custom hooks, wrappers, dependencies, and files.
- Do not invent functionality that isn't required.
- Build in small, testable vertical slices.
- Write meaningful tests and verify behavior continuously.
- After each substantial feature, inspect the code for unnecessary complexity and simplify where justified.

## Phase 3 — Quality Assurance

Follow the harness's existing quality-control workflow.

Run applicable automated tests, linting, type checks, and security checks.

Perform independent code review as instructed by the selected harness version.

For V3, use the normal engineering review without formal quality rubrics.

For V4, additionally execute the supplied evidence-based review rubrics at the specified review stage.

Correct confirmed problems, rerun affected checks, and record anything that remains unverified.

Never report a test as passed unless it actually ran successfully.

## Phase 4 — Deliver and Freeze

Produce the required runnable application, seed data, tests, README, AI usage documentation, architecture documentation, and decision notes.

The human developer will personally write the final `DECISIONS.md` narrative.

Document:
- How to start the application.
- How to exercise its main workflows.
- How to simulate patient replies and reminders.
- How to run all verification checks.
- What architectural decisions were made and why.
- Known limitations and unfinished work.

Record the final verification results and freeze checklist.

## Critical Clean-Room Rules

- Never access, inspect, clone, or reference the original Appointment Flow GitHub repository.
- Never inspect source code from V1, V2, V3, or V4 outside your current project.
- Do not compare versions until explicitly authorized.
- Do not copy code or architecture from previous implementations.
- The provided screenshots are visual references, not architectural instructions.
- Do not modify files outside the current project.
- Do not push to GitHub or submit the assessment without permission.

## Autonomy

Work autonomously through the complete process.

Make reasonable engineering decisions without repeatedly asking for confirmation.

Ask only when blocked by missing prerequisites, required permissions, or consequential irreversible decisions.

Keep a concise progress log, but prioritize completing and verifying the application.

**Begin immediately with Phase 1. Do not write application code until the harness is initialized and verified. Then proceed through implementation, testing, review, and documentation.**


context: renderer=paths title=Files source=manualPaths project=C:\Users\joshr\RubymineProjects\appointment-flow_v3
path: C:\Users\joshr\Downloads\Apex_Clean_Room_V3_RubyMine_Harness_UPDATED.zip

