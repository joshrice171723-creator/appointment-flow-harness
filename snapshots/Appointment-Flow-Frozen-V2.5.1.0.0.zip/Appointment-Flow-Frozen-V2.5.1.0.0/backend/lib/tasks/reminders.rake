namespace :reminders do
  desc "Refresh the demo PMS and record due fake reminders"
  task run: :environment do
    now = ENV["APEX_DEMO_AT"] ? Time.iso8601(ENV.fetch("APEX_DEMO_AT")) : Time.current
    clinics = Clinic.order(:id)
    clinics = clinics.where(id: ENV.fetch("APEX_CLINIC")) if ENV["APEX_CLINIC"]
    results = clinics.map do |clinic|
      result = ReminderRun.call(clinic, now: now)
      puts "#{clinic.name}: #{result.to_json}"
      result
    end
    abort("A clinic refresh failed.") if results.any? { |result| result[:error] }
  end
end
