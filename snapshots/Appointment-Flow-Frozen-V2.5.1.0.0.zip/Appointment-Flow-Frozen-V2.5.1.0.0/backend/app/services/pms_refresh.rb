class PmsRefresh
  class Unavailable < StandardError; end

  # The caller holds the clinic lock through refresh and any dependent writes.
  def self.call(clinic, now:)
    new(clinic, now).refresh
  end

  def initialize(clinic, now)
    @clinic = clinic
    @now = now
    @today = clinic.local_time(now).to_date
    @zone = TZInfo::Timezone.get(clinic.timezone)
  end

  def refresh
    Clinic.transaction(requires_new: true) do
      upcoming_ids = @clinic.visits.scheduled.where(local_date: @today..).pluck(:source_id)
      rows, clinic_name = read_source(upcoming_ids)
      reject_incomplete_snapshot!(rows, upcoming_ids)
      contacts = update_contacts(rows)
      existing = @clinic.visits.where(source_id: rows.map { |row| row.fetch("id") }).index_by(&:source_id)
      update_visits(rows, contacts, existing)
      @clinic.update!(name: clinic_name, last_synced_at: @now, sync_error: nil)
    end
    true
  rescue Unavailable => error
    @clinic.update!(sync_error: error.message)
    false
  end

  private

  def date_range
    (@today - 14)..(@today + 30)
  end

  def read_source(tracked_ids)
    connection = ApplicationRecord.lease_connection
    tracked_condition = tracked_ids.empty? ? "FALSE" : "a.id IN (#{tracked_ids.join(',')})"
    connection.execute("SET LOCAL statement_timeout = '5s'")
    rows = ApplicationRecord.while_preventing_writes do
      connection.select_all(<<~SQL).to_a
        SELECT c.name AS clinic_name, a.id, a.patient_id, a.provider_name, a.start_at::text AS wall_start, a.length_minutes,
               a.status, p.first_name, p.last_name, p.birthdate::text, p.wireless_phone, p.email,
               p.preferred_language, p.guarantor_id
        FROM pms.clinics c
        LEFT JOIN pms.appointments a ON a.clinic_id = c.id AND (
          (a.start_at >= #{connection.quote(date_range.begin)} AND a.start_at < #{connection.quote(date_range.end + 1)})
          OR #{tracked_condition})
        LEFT JOIN pms.patients p ON p.id = a.patient_id
        WHERE c.id = #{@clinic.id}
      SQL
    end
    connection.execute("SET LOCAL statement_timeout = DEFAULT")
    raise Unavailable, "The clinic is missing from the PMS. Messaging is paused." if rows.empty?

    [ rows.reject { |row| row["id"].nil? }, rows.first.fetch("clinic_name") ]
  rescue ActiveRecord::StatementInvalid, ActiveRecord::ConnectionNotEstablished => error
    Rails.logger.warn("PMS read failed for clinic #{@clinic.id}: #{error.class}")
    raise Unavailable, "The PMS could not be refreshed. Messaging is paused."
  end

  def reject_incomplete_snapshot!(rows, upcoming_ids)
    present = rows.to_set { |row| row.fetch("id") }
    if upcoming_ids.any? { |id| !present.include?(id) } || (rows.empty? && @clinic.visits.where(local_date: date_range).exists?)
      raise Unavailable, "The PMS is missing previously tracked appointments. Messaging is paused."
    end
  end

  def update_contacts(rows)
    patients = rows.index_by { |row| row.fetch("patient_id") }
    existing = @clinic.contacts.where(patient_id: patients.keys).index_by(&:patient_id)
    changes = patients.filter_map do |id, row|
      contact = existing[id] || Contact.new(clinic_id: @clinic.id, patient_id: id)
      contact.assign_attributes(name: "#{row.fetch('first_name')} #{row.fetch('last_name')}",
                                source: row.slice(*Contact::FIELDS, "guarantor_id"))
      contact.assign_attributes(contact.addresses)
      contact.attributes.slice("clinic_id", "patient_id", "name", "source", "sms", "email") if contact.changed?
    end
    Contact.upsert_all(changes, unique_by: %i[clinic_id patient_id]) if changes.any?
    @clinic.contacts.where(patient_id: patients.keys).pluck(:patient_id, :id).to_h
  end

  def update_visits(rows, contacts, tracked)
    obsolete = []
    changes = rows.filter_map do |row|
      id = row.fetch("id")
      visit = tracked[id] || Visit.new(clinic_id: @clinic.id, source_id: id)
      assign_visit(visit, row, contacts)
      if visit.persisted? && revision_changed?(visit)
        obsolete << visit.id
        visit.revision += 1
        visit.state = "unconfirmed"
      elsif visit.persisted? && visit.will_save_change_to_source_status? && visit.source_status != "scheduled"
        obsolete << visit.id
      end
      visit.attributes.except("id") if visit.changed?
    end
    Visit.upsert_all(changes, unique_by: %i[clinic_id source_id]) if changes.any?
    @clinic.work_items.open.where(visit_id: obsolete).where.not(kind: "reply_review").update_all(resolved_at: @now) if obsolete.any?
  end

  def assign_visit(visit, row, contacts)
    wall = DateTime.iso8601(row.fetch("wall_start").tr(" ", "T"))
    local = wall.to_time
    instant = @zone.local_to_utc(local) if @zone.periods_for_local(local).one?
    visit.assign_attributes(contact_id: contacts.fetch(row.fetch("patient_id")), provider: row["provider_name"],
                            length_minutes: row["length_minutes"], wall_start: row.fetch("wall_start"),
                            local_date: wall.to_date, starts_at: instant, source_status: row.fetch("status"))
  end

  def revision_changed?(visit)
    visit.will_save_change_to_wall_start? || visit.will_save_change_to_contact_id? ||
      (visit.will_save_change_to_source_status? && visit.source_status == "scheduled")
  end
end
