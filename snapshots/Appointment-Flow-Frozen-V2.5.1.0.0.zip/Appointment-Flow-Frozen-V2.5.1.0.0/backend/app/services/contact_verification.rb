class ContactVerification
  class Invalid < StandardError; end

  def self.call(clinic, contact_id:, staff:, field:, value:, event_key:, now: Time.current)
    raise Invalid, "Choose a contact field to verify." unless Contact::FIELDS.include?(field)
    validate_value!(field, value, clinic.local_time(now).to_date)

    clinic.with_lock do
      contact = clinic.contacts.find(contact_id)
      existing = clinic.activities.find_by(event_key: event_key)
      if existing
        unless existing.action == "verified" && existing.contact_id == contact.id && existing.staff == staff &&
            existing.changes_recorded.values_at("field", "value") == [ field, value ]
          raise Invalid, "That verification request was already used for another update."
        end
        return contact
      end

      prior = contact.effective[field]
      contact.verified = contact.verified.merge(field => { "value" => value, "source" => contact.source[field] })
      contact.update!(contact.addresses)
      clinic.activities.create!(contact: contact, staff: staff, action: "verified", note: "Verified contact details",
                                event_key: event_key, created_at: now,
                                changes_recorded: { field: field, prior: prior, value: value, source: contact.source[field] })
      contact
    end
  end

  def self.validate_value!(field, value, today)
    valid = case field
    when "birthdate"
      birthday = Contact.parse_birthday(value)
      birthday && birthday <= today
    when "wireless_phone" then Contact.normalize("sms", value)
    when "email" then Contact.normalize("email", value)
    when "preferred_language" then Contact::LANGUAGES.key?(value.downcase)
    end
    raise Invalid, "Enter a valid value before verifying this field." unless valid
  end
  private_class_method :validate_value!
end
