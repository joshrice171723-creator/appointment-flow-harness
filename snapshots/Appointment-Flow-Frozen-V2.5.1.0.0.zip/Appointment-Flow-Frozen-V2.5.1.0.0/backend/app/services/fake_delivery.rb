class FakeDelivery
  def deliver(channel:, recipient:, body:)
    raise ArgumentError, "Message body is required" if body.blank?

    channel == "sms" && recipient.end_with?("0199") ? "failed" : "sent"
  end
end
