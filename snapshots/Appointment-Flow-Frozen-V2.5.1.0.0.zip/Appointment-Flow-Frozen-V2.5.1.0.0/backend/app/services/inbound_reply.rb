class InboundReply
  class Invalid < StandardError; end

  def self.call(clinic, channel:, recipient:, body:, event_key:, reply_to_id: nil, contact_id: nil, now: Time.current)
    address = Contact.normalize(channel, recipient)
    raise Invalid, "This channel has no usable reply address." unless address

    clinic.with_lock do
      if reply_to_id && !clinic.messages.delivered.where(channel: channel).exists?(reply_to_id)
        raise Invalid, "The selected message is unavailable."
      end
      existing = clinic.messages.find_by(direction: "inbound", event_key: event_key)
      if existing
        unless [ existing.channel, existing.recipient, existing.body, existing.in_reply_to_id ] == [ channel, address, body, reply_to_id ] &&
            (!contact_id || existing.contact_id == contact_id)
          raise Invalid, "That reply was already recorded with different details."
        end
        existing
      else
        new(clinic, channel, address, body, event_key, reply_to_id, contact_id, now).receive
      end
    end
  end

  def initialize(clinic, channel, address, body, event_key, reply_to_id, contact_id, now)
    @clinic = clinic
    @channel = channel
    @address = address
    @body = body
    @key = event_key
    @reply_to_id = reply_to_id
    @contact_id = contact_id
    @now = now
  end

  def receive
    if @channel == "sms" && command == "STOP"
      @clinic.sms_opt_outs.find_or_create_by!(recipient: @address)
      recipients = matching_contacts
      return record("opted_out", contact: @clinic.contacts.find_by(id: @contact_id) || (recipients.first if recipients.one?))
    end

    fresh = PmsRefresh.call(@clinic, now: @now)
    recipients = matching_contacts
    message, candidates = match_reminders
    return review("The PMS refresh failed. Check the appointment in the source system.", recipients, candidates) unless fresh
    if recipients.many? || shared_address?(recipients.first)
      shared_visits = @clinic.visits.live.where(contact_id: recipients.map(&:id), starts_at: @now..)
      return review("This reply address belongs to more than one patient.", recipients, (candidates + shared_visits).uniq)
    end
    return review("This reply does not match a single appointment version.", recipients, candidates) unless message
    visit = message.visit
    contact = recipients.first
    if !contact || contact.id != message.contact_id || (@contact_id && @contact_id != contact.id) ||
        contact.safety_hold(@clinic.local_time(@now).to_date)
      return review("The recipient could not be verified against current contact details.", recipients, candidates)
    end
    if !visit.active_at?(@now) || visit.revision != message.revision
      return review("The reply refers to an appointment that changed or has already started.", recipients, candidates)
    end
    unless command == "YES" && message.requests_confirmation
      reason = command == "NO" ? "The patient replied NO and may need help." : "The reply needs staff interpretation."
      return review(reason, recipients, candidates)
    end

    visit.update!(state: "confirmed")
    @clinic.work_items.open.where(visit_id: visit.id, revision: visit.revision, kind: "no_reply").update_all(resolved_at: @now)
    record("confirmed", contact: contact, visit: visit)
  rescue ContactAddressOwnership::Unavailable => error
    review(error.message, recipients, candidates)
  end

  private

  def command
    @body.strip.upcase
  end

  def matching_contacts
    @clinic.contacts.where(@channel => @address).to_a
  end

  def shared_address?(contact)
    return false unless contact

    owners = ContactAddressOwnership.new(@clinic, @channel.to_sym => [ @address ])
    owners.shared?(@channel, @address, contact.patient_id)
  end

  def match_reminders
    scope = @clinic.messages.delivered.where(channel: @channel, recipient: @address, created_at: ..@now)
    if @reply_to_id
      message = scope.find_by(id: @reply_to_id)
      return [ message, [ message&.visit ].compact ]
    end

    versions = scope.distinct.limit(2).pluck(:visit_id, :revision)
    if versions.one?
      id, revision = versions.first
      message = scope.where(visit_id: id, revision: revision)
                     .order(requests_confirmation: :desc, created_at: :desc, id: :desc).first
      return [ message, [ message.visit ] ]
    end

    candidates = @clinic.visits.live.where(starts_at: @now.., id: scope.select(:visit_id))
    [ nil, candidates.to_a ]
  end

  def review(reason, recipients, visits)
    contact = @clinic.contacts.find_by(id: @contact_id) || (recipients.first if recipients.one?)
    reply = record("needs_review", contact: contact, visit: (visits.first if visits.one?))
    @clinic.work_items.create!(contact: contact, visit: reply.visit, revision: reply.revision, message: reply,
                               candidate_visit_ids: visits.map(&:id), kind: "reply_review", work_key: "reply/#{reply.id}",
                               detail: reason, created_at: @now)
    reply
  end

  def record(status, contact:, visit: nil)
    @clinic.messages.create!(direction: "inbound", channel: @channel, recipient: @address, body: @body,
                             status: status, event_key: @key, contact: contact, visit: visit,
                             revision: visit&.revision, in_reply_to_id: @reply_to_id, created_at: @now)
  end
end
