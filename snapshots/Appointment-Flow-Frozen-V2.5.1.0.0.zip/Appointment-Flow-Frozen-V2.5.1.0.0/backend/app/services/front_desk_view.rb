module FrontDeskView
  def self.visit(visit, contact = visit.contact)
    {
      id: visit.id, source_id: visit.source_id, contact_id: contact.id, patient: contact.name, revision: visit.revision,
      local_date: visit.local_date, wall_start: visit.wall_start, starts_at: visit.starts_at, provider: visit.provider,
      length_minutes: visit.length_minutes, state: visit.state, outcome: Visit::OUTCOMES.fetch(visit.source_status, "Unknown"),
      source_status: visit.source_status
    }
  end

  def self.work(item, contact = item.contact)
    {
      id: item.id, contact_id: contact&.id, patient: contact&.name, kind: item.kind, label: WorkItem::KINDS.fetch(item.kind),
      detail: item.detail, visit_at: item.visit&.wall_start, assignee: item.assignee,
      created_at: item.created_at, resolved_at: item.resolved_at
    }
  end

  def self.activity(item)
    item.as_json(only: %i[id staff action note created_at changes_recorded])
  end
end
