class OutcomeReport
  def self.call(month)
    clinics = Clinic.order(:name).to_a
    first_month = month << 5
    result = source_outcomes(clinics, first_month, month.next_month)
    counts = result.group_by { |row| [ row.fetch("clinic_id"), row.fetch("month") ] }

    clinics.map do |clinic|
      months = 5.downto(0).map do |offset|
        key = (month << offset).strftime("%Y-%m")
        outcomes = counts.fetch([ clinic.id, key ], [])
        statuses = Hash.new(0)
        outcomes.each do |row|
          label = Visit::OUTCOMES.fetch(row.fetch("status"), "Unknown")
          statuses[label.downcase] += row.fetch("total")
        end
        { month: key, total: statuses.values.sum, completed: statuses["completed"], rescheduled: statuses["rescheduled"],
          canceled: statuses["canceled"], unknown: statuses["unknown"] }
      end
      range = local_month(clinic, month)...local_month(clinic, month.next_month)
      {
        clinic: clinic.name, outcomes: months.last, history: months,
        deliveries: clinic.messages.outbound.where(created_at: range).group(:status, :channel).count.map do |(status, channel), count|
          { status: status, channel: channel, count: count }
        end,
        contact_holds: clinic.work_items.where(kind: "contact_hold", created_at: range).group(Arel.sql("resolved_at IS NOT NULL")).count,
        follow_ups: clinic.activities.where(created_at: range).group(:action).count
      }
    end
  end

  def self.source_outcomes(clinics, from, until_date)
    return [] if clinics.empty?

    connection = ApplicationRecord.lease_connection
    ApplicationRecord.while_preventing_writes do
      connection.select_all(<<~SQL).to_a
        SELECT clinic_id, to_char(start_at, 'YYYY-MM') AS month, status, count(*) AS total
        FROM pms.appointments
        WHERE clinic_id IN (#{clinics.map(&:id).join(',')})
          AND start_at >= #{connection.quote(from)} AND start_at < #{connection.quote(until_date)}
        GROUP BY clinic_id, month, status
      SQL
    end
  end
  private_class_method :source_outcomes

  def self.local_month(clinic, date)
    ActiveSupport::TimeZone[clinic.timezone].local(date.year, date.month, 1)
  end
  private_class_method :local_month
end
