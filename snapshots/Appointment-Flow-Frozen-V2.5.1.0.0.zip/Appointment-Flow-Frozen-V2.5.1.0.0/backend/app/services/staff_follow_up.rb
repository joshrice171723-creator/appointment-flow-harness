class StaffFollowUp
  class Invalid < StandardError; end

  OUTCOMES = { "confirmed" => "confirmed", "canceled" => "canceled", "rescheduled" => "rescheduled" }.freeze
  ACTIONS = %w[attempted clarified].concat(OUTCOMES.keys).freeze

  def self.call(clinic, item_id:, staff:, action:, note:, event_key:, selections:, now: Time.current)
    raise Invalid, "Choose a follow-up outcome and enter a note." unless ACTIONS.include?(action) && note.present? && note.size <= 500

    result = clinic.with_lock do
      item = clinic.work_items.find(item_id)
      activity = clinic.activities.find_by(event_key: event_key)
      if activity
        unless activity.work_item_id == item.id && activity.staff == staff && activity.action == action &&
            activity.note == note && activity.changes_recorded["selections"] == selections
          raise Invalid, "That follow-up request was already used for another update."
        end
        return activity
      end
      raise Invalid, "This work item has already been resolved." if item.resolved_at

      if OUTCOMES.key?(action) && !PmsRefresh.call(clinic, now: now)
        next
      end

      begin
        visits = selected_visits(clinic, item, selections, action, now)
      rescue Invalid => error
        next error
      end
      item.update!(assignee: staff, resolved_at: action == "attempted" ? nil : now)
      visits.each { |visit| visit.update!(state: OUTCOMES.fetch(action)) }
      if visits.any?
        remaining = clinic.work_items.open.where(visit_id: visits.map(&:id))
        remaining = action == "confirmed" ? remaining.where(kind: "no_reply") : remaining.where.not(kind: "reply_review")
        remaining.update_all(resolved_at: now)
      end
      clinic.activities.create!(staff: staff, work_item: item, contact: item.contact, action: action,
                                note: note, event_key: event_key, changes_recorded: { selections: selections }, created_at: now)
    end
    raise result if result.is_a?(Invalid)

    result || raise(Invalid, "The PMS could not be refreshed. Check the appointment and try again.")
  end

  def self.selected_visits(clinic, item, selections, action, now)
    return [] if action == "attempted"
    if action == "clarified"
      raise Invalid, "Only a reply review can be resolved as clarified." unless item.kind == "reply_review"
      return []
    end

    allowed = item.candidate_visit_ids.presence || [ item.visit_id ].compact
    if selections.empty? || selections.keys.any? { |id| !allowed.include?(id.to_i) }
      raise Invalid, "Select an appointment associated with this work item."
    end
    visits = clinic.visits.where(id: selections.keys).to_a
    unless visits.size == selections.size && visits.all? { |visit| visit.active_at?(now) && selections[visit.id.to_s] == visit.revision }
      raise Invalid, "An appointment changed. Reload the work item before recording the outcome."
    end
    visits
  end
  private_class_method :selected_visits
end
