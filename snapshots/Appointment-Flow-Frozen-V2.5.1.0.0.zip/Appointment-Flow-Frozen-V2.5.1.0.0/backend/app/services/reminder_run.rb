class ReminderRun
  FIRST_DAY = 7
  BACKUP_DAY = 6
  FOLLOW_UP_DAY = 3
  FINAL_DAY = 1
  SEND_HOURS = 10...18

  def self.call(clinic, now: Time.current, delivery: FakeDelivery.new)
    clinic.with_lock(requires_new: true) do
      Clinic.transaction(requires_new: true) do
        if PmsRefresh.call(clinic, now: now)
          new(clinic, now, delivery).run
        else
          { error: clinic.sync_error }
        end
      end
    rescue ContactAddressOwnership::Unavailable => error
      clinic.reload.update!(sync_error: error.message)
      { error: error.message }
    end
  end

  def initialize(clinic, now, delivery)
    @clinic = clinic
    @now = now
    @local = clinic.local_time(now)
    @delivery = delivery
    @messages = []
    @work = []
    @hold_changes = []
    @clear_holds = []
  end

  def run
    visits = @clinic.visits.live.where(local_date: @local.to_date..(@local.to_date + FIRST_DAY))
                    .where("starts_at > ? OR starts_at IS NULL", @now).includes(:contact).to_a
    load_batch_context(visits)
    visits.each { |visit| plan_visit(visit) }
    Message.insert_all!(@messages) if @messages.any?
    WorkItem.insert_all(@work, unique_by: %i[clinic_id work_key]) if @work.any?
    if @hold_changes.any?
      WorkItem.upsert_all(@hold_changes, unique_by: %i[clinic_id work_key], update_only: %i[detail resolved_at])
    end
    @clinic.work_items.open.where(id: @clear_holds).update_all(resolved_at: @now) if @clear_holds.any?
    { sent: @messages.count { |message| message[:status] == "sent" }, failed: @messages.count { |message| message[:status] == "failed" } }
  end

  private

  def load_batch_context(visits)
    ids = visits.map(&:id)
    @attempts = @clinic.messages.outbound.joins(:visit).where(visit_id: ids)
                       .where("messages.revision = visits.revision")
                       .pluck(:visit_id, :event_key, :channel, :status, :recipient).group_by(&:first)
    @existing_work = @clinic.work_items.joins(:visit).where(visit_id: ids)
                            .where("work_items.revision = visits.revision").where.not(kind: "reply_review").index_by(&:work_key)
    phones = visits.filter_map { |visit| visit.contact.sms }.uniq
    emails = visits.filter_map { |visit| visit.contact.email }.uniq
    @opt_outs = @clinic.sms_opt_outs.where(recipient: phones).pluck(:recipient).to_set
    @ownership = ContactAddressOwnership.new(@clinic, sms: phones, email: emails)
  end

  def plan_visit(visit)
    unless visit.starts_at
      add_work(visit, "visit_review", "The source time is ambiguous or does not exist in this clinic’s timezone.")
      return
    end

    days = (visit.local_date - @local.to_date).to_i
    if visit.state == "unconfirmed" && visit.starts_at <= @now + 48.hours
      add_work(visit, "no_reply", "This appointment starts within 48 hours and still needs confirmation.")
    end

    hold = visit.contact.safety_hold(@local.to_date)
    channels = hold ? [] : allowed_channels(visit.contact)
    existing_hold = @existing_work[WorkItem.for_visit(visit, "contact_hold", "", @now).fetch(:work_key)]
    if channels.empty?
      detail = hold || "No unique, permitted text number or email is available."
      if !existing_hold || existing_hold.resolved_at || existing_hold.detail != detail
        @hold_changes << WorkItem.for_visit(visit, "contact_hold", detail, @now).merge(resolved_at: nil)
      end
      return
    end
    @clear_holds << existing_hold.id if existing_hold && !existing_hold.resolved_at

    return unless SEND_HOURS.cover?(@local.hour)

    attempts = @attempts.fetch(visit.id, [])
    channels.reject! do |channel|
      attempts.any? { |_, _, prior_channel, status, address| prior_channel == channel && status == "failed" && address == visit.contact.public_send(channel) }
    end
    step = due_step(visit, days, attempts)
    return unless step
    return if attempted?(attempts, visit, step)

    channel = step == "backup" ? "email" : channels.first
    return unless channels.include?(channel)

    status = attempt(visit, step, channel)
    if status == "failed" && channel == "sms" && channels.include?("email") && !attempted?(attempts, visit, "backup")
      attempt(visit, "backup", "email")
    end
  end

  def allowed_channels(contact)
    Message::CHANNELS.select do |channel|
      address = contact.public_send(channel)
      address && !@ownership.shared?(channel, address, contact.patient_id) && (channel != "sms" || !@opt_outs.include?(address))
    end
  end

  def due_step(visit, days, attempts)
    return "final" if days == FINAL_DAY
    return if visit.state == "confirmed"
    return "follow_up" if days.between?(FINAL_DAY + 1, FOLLOW_UP_DAY)
    return unless days.between?(BACKUP_DAY, FIRST_DAY)

    initial = attempts.find { |_, key, _, _| key == event_key(visit, "initial") }
    return "initial" unless initial

    "backup" if days == BACKUP_DAY && initial[2] == "sms"
  end

  def attempt(visit, step, channel)
    recipient = visit.contact.public_send(channel)
    requesting = visit.state == "unconfirmed"
    body = message_body(visit, channel, requesting)
    status = @delivery.deliver(channel: channel, recipient: recipient, body: body)
    @messages << { clinic_id: @clinic.id, contact_id: visit.contact_id, visit_id: visit.id, revision: visit.revision,
                   direction: "outbound", event_key: event_key(visit, step), channel: channel, recipient: recipient,
                   status: status, requests_confirmation: requesting, body: body, created_at: @now }
    add_work(visit, "delivery_failed", "A simulated delivery failed. Review the contact details.") if status == "failed"
    status
  end

  def message_body(visit, channel, requesting)
    time = @clinic.local_time(visit.starts_at).strftime("%Y-%m-%d %H:%M %Z")
    if visit.contact.language == "es"
      [ "Recordatorio de cita en #{@clinic.name} el #{time}.", ("Responda YES para confirmar o NO si necesita ayuda." if requesting),
        ("Responda STOP para dejar de recibir mensajes de texto." if channel == "sms") ].compact.join(" ")
    else
      [ "Appointment reminder at #{@clinic.name} on #{time}.", ("Reply YES to confirm or NO for help." if requesting),
        ("Reply STOP to stop text messages." if channel == "sms") ].compact.join(" ")
    end
  end

  def event_key(visit, step)
    "visit/#{visit.id}/#{visit.revision}/#{step}"
  end

  def attempted?(attempts, visit, step)
    attempts.any? { |_, key, _, _| key == event_key(visit, step) }
  end

  def add_work(visit, kind, detail)
    item = WorkItem.for_visit(visit, kind, detail, @now)
    @work << item unless @existing_work.key?(item.fetch(:work_key))
  end
end
