class ContactAddressOwnership
  class Unavailable < StandardError; end

  def initialize(clinic, sms: [], email: [])
    @owners = {}
    local_contacts = clinic.contacts.where(sms: sms).or(clinic.contacts.where(email: email))
    local_contacts.pluck(:patient_id, :sms, :email).each { |id, phone, address| add_owner(id, phone, address) }
    replica_contacts(sms, email).each do |id, phone, address|
      add_owner(id, Contact.normalize("sms", phone), Contact.normalize("email", address))
    end
  end

  def shared?(channel, address, patient_id)
    @owners.fetch([ channel, address ], []).any? { |id| id != patient_id }
  end

  private

  def add_owner(id, phone, email)
    (@owners[[ "sms", phone ]] ||= Set.new) << id if phone
    (@owners[[ "email", email ]] ||= Set.new) << id if email
  end

  def replica_contacts(sms, email)
    return [] if sms.empty? && email.empty?

    ApplicationRecord.transaction(requires_new: true) do
      connection = ApplicationRecord.lease_connection
      phones = sms.map { |address| connection.quote(address.last(10)) }
      emails = email.map { |address| connection.quote(address) }
      phone_match = phones.empty? ? "FALSE" : "right(regexp_replace(wireless_phone, '[^0-9]', '', 'g'), 10) IN (#{phones.join(',')})"
      email_match = emails.empty? ? "FALSE" : "regexp_replace(lower(email), '^[[:space:]]+|[[:space:]]+$', '', 'g') IN (#{emails.join(',')})"
      connection.execute("SET LOCAL statement_timeout = '5s'")
      rows = ApplicationRecord.while_preventing_writes do
        connection.select_rows(<<~SQL)
          SELECT id, wireless_phone, email FROM pms.patients WHERE #{phone_match} OR #{email_match}
        SQL
      end
      connection.execute("SET LOCAL statement_timeout = DEFAULT")
      rows
    end
  rescue ActiveRecord::StatementInvalid, ActiveRecord::ConnectionNotEstablished => error
    Rails.logger.warn("PMS address ownership lookup failed: #{error.class}")
    raise Unavailable, "Contact ownership could not be verified. Messaging is paused."
  end
end
