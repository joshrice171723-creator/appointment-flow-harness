class Contact < ApplicationRecord
  FIELDS = %w[birthdate wireless_phone email preferred_language].freeze
  LANGUAGES = { "en" => "en", "english" => "en", "es" => "es", "spanish" => "es", "español" => "es" }.freeze

  belongs_to :clinic
  has_many :visits

  def effective
    source.merge(verified.transform_values { |field| field.fetch("value") })
  end

  def conflicts
    verified.keys.select do |field|
      prior = verified.fetch(field)
      source[field] != prior.fetch("source") && source[field] != prior.fetch("value")
    end
  end

  def self.normalize(channel, value)
    return if value.blank?
    return value.strip.downcase if channel == "email" && value.strip.match?(URI::MailTo::EMAIL_REGEXP)
    return unless channel == "sms" && value.match?(/\A[+\d ().-]+\z/)

    digits = value.gsub(/\D/, "")
    digits = digits.delete_prefix("1") if digits.length == 11
    "+1#{digits}" if digits.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
  end

  def addresses
    { sms: self.class.normalize("sms", effective["wireless_phone"]), email: self.class.normalize("email", effective["email"]) }
  end

  def language
    LANGUAGES[effective["preferred_language"].to_s.strip.downcase]
  end

  def safety_hold(date)
    return "Source and verified contact details disagree." if conflicts.any?
    return "Preferred language needs verification." unless language

    birthday = self.class.parse_birthday(effective["birthdate"])
    return "Birthdate needs verification." unless birthday && birthday <= date
    "Guardian authorization needs review." if birthday > date.prev_year(18) || source["guarantor_id"].present?
  end

  def self.parse_birthday(value)
    Date.iso8601(value.to_s) if value.to_s.match?(/\A\d{4}-\d{2}-\d{2}\z/)
  rescue Date::Error
    nil
  end
end
