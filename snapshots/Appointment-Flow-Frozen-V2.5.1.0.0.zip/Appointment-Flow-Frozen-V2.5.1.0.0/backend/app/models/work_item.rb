class WorkItem < ApplicationRecord
  belongs_to :clinic
  belongs_to :contact, optional: true
  belongs_to :visit, optional: true
  belongs_to :message, optional: true

  KINDS = {
    "no_reply" => "No confirmation", "contact_hold" => "Contact hold",
    "delivery_failed" => "Delivery failed", "reply_review" => "Reply to review",
    "visit_review" => "Appointment time needs review"
  }.freeze

  scope :open, -> { where(resolved_at: nil) }

  def self.for_visit(visit, kind, detail, now)
    { clinic_id: visit.clinic_id, contact_id: visit.contact_id, visit_id: visit.id, revision: visit.revision,
      kind: kind, detail: detail, work_key: "visit/#{visit.id}/#{visit.revision}/#{kind}", created_at: now }
  end
end
