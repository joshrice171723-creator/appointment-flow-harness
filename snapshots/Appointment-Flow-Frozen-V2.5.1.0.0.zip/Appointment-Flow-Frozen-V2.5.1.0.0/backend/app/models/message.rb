class Message < ApplicationRecord
  belongs_to :clinic
  belongs_to :contact, optional: true
  belongs_to :visit, optional: true
  belongs_to :in_reply_to, class_name: "Message", optional: true

  CHANNELS = %w[sms email].freeze
  scope :outbound, -> { where(direction: "outbound") }
  scope :delivered, -> { outbound.where(status: "sent") }
end
