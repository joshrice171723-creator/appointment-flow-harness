class Clinic < ApplicationRecord
  has_many :contacts
  has_many :visits
  has_many :messages
  has_many :sms_opt_outs
  has_many :work_items
  has_many :activities

  def local_time(time)
    time.in_time_zone(timezone)
  end
end
