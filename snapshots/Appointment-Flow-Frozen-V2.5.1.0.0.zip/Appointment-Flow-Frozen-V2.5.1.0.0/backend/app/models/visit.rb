class Visit < ApplicationRecord
  belongs_to :clinic
  belongs_to :contact

  scope :scheduled, -> { where(source_status: "scheduled") }
  scope :live, -> { scheduled.where(state: %w[unconfirmed confirmed]) }

  OUTCOMES = { "complete" => "Completed", "broken" => "Canceled", "unscheduled" => "Rescheduled" }.freeze

  def active_at?(now)
    source_status == "scheduled" && state.in?(%w[unconfirmed confirmed]) && starts_at && starts_at > now
  end
end
