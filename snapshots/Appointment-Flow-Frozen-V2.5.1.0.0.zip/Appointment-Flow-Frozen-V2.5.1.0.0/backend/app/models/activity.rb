class Activity < ApplicationRecord
  belongs_to :clinic
  belongs_to :contact, optional: true
  belongs_to :work_item, optional: true
end
