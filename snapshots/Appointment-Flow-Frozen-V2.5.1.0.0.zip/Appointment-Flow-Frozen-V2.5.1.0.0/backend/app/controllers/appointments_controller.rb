class AppointmentsController < FrontDeskController
  def index
    today = @clinic.local_time(Time.current).to_date
    date = params[:date].present? ? Date.iso8601(input_string(:date, limit: 10)) : today
    week = date.beginning_of_week
    selected = @clinic.visits.where(local_date: date).includes(:contact).order(:starts_at, :id)
    reviews = @clinic.work_items.open.where(kind: "reply_review")
    review_ids = reviews.where(visit_id: selected.select(:id)).pluck(:visit_id).to_set
    selected_ids = selected.map(&:id)
    if selected_ids.any?
      overlap = "candidate_visit_ids && ARRAY[#{selected_ids.join(',')}]::bigint[]"
      review_ids.merge(reviews.where(overlap).pluck(:candidate_visit_ids).flatten & selected_ids)
    end
    render json: {
      date: date, today: today, week_counts: @clinic.visits.where(local_date: week..(week + 6)).group(:local_date).count,
      visits: selected.map { |visit| FrontDeskView.visit(visit).merge(review: review_ids.include?(visit.id)) }, **sync_status
    }
  rescue Date::Error
    render json: { error: "Choose a valid appointment date." }, status: :unprocessable_entity
  end
end
