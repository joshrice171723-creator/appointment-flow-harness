class WorkspaceController < ApplicationController
  def show
    entry = Rails.public_path.join("ui/index.html")
    if entry.file?
      send_file entry, disposition: :inline, type: "text/html"
    else
      render plain: "Build the React workspace using bin/start.rb, or run Vite for development.", status: :service_unavailable
    end
  end
end
