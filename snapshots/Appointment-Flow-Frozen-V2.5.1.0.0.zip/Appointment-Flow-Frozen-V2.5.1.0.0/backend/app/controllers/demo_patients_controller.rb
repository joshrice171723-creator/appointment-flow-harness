class DemoPatientsController < ApplicationController
  def index
    clinic = Clinic.find(params[:clinic_id])
    render json: clinic.contacts.order(:name).as_json(only: %i[id name])
  end
end
