class ReportsController < ApplicationController
  def index
    month = input_string(:month, limit: 7, required: false)
    date = month.empty? ? Date.current.beginning_of_month : Date.iso8601("#{month}-01")
    render json: { month: date.strftime("%Y-%m"), clinics: OutcomeReport.call(date) }
  rescue Date::Error
    render json: { error: "Choose a valid reporting month." }, status: :unprocessable_entity
  rescue ActiveRecord::StatementInvalid => error
    Rails.logger.warn("Outcome report unavailable: #{error.class}")
    render json: { error: "Appointment outcomes are temporarily unavailable." }, status: :service_unavailable
  end
end
