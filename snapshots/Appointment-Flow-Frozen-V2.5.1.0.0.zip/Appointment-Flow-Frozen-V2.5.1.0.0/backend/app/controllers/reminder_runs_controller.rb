class ReminderRunsController < FrontDeskController
  def create
    result = ReminderRun.call(@clinic)
    render json: result.merge(sync_status), status: result[:error] ? :service_unavailable : :created
  end
end
