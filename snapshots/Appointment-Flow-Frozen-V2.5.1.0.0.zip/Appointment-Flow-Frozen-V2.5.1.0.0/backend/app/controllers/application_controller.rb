class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "This record is unavailable in this workspace." }, status: :not_found
  end

  rescue_from ActionController::ParameterMissing, InboundReply::Invalid, StaffFollowUp::Invalid, ContactVerification::Invalid do |error|
    render json: { error: error.message }, status: :unprocessable_entity
  end

  private

  def demo_sessions
    Rails.application.message_verifier(:front_desk)
  end

  def event_key
    value = params[:event_key]
    unless value.is_a?(String) && value.match?(/\A[\w-]{1,100}\z/)
      raise ActionController::ParameterMissing.new(:event_key)
    end
    value
  end

  def input_string(name, limit:, required: true)
    value = params[name]
    return "" if value.nil? && !required
    unless value.is_a?(String) && value.size <= limit && (!required || value.strip.present?)
      raise ActionController::ParameterMissing.new(name)
    end
    value.strip
  end
end
