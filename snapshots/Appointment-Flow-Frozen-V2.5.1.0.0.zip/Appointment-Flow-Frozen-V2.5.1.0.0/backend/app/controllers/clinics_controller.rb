class ClinicsController < ApplicationController
  def index
    render json: Clinic.order(:name).as_json(only: %i[id name timezone staff])
  end
end
