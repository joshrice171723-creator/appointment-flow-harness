class FrontDeskController < ApplicationController
  before_action :load_demo_session

  private

  def load_demo_session
    identity = demo_sessions.verified(request.headers["X-Demo-Session"].to_s)
    if identity
      @clinic = Clinic.find(identity.first)
      @staff = identity.last
      return if @clinic.staff.include?(@staff)
    end
    render json: { error: "Open Front desk and select a clinic and staff member." }, status: :unauthorized
  end

  def sync_status
    { last_synced_at: @clinic.last_synced_at, sync_error: @clinic.sync_error }
  end
end
