class FollowUpsController < FrontDeskController
  def create
    selections = params[:selections]
    selections = selections.to_unsafe_h if selections.is_a?(ActionController::Parameters)
    selections ||= {}
    unless selections.is_a?(Hash) && selections.size <= 20 &&
        selections.all? { |id, revision| id.match?(/\A\d{1,18}\z/) && revision.is_a?(Integer) && revision.positive? }
      raise StaffFollowUp::Invalid, "Choose valid appointment revisions."
    end
    activity = StaffFollowUp.call(@clinic, item_id: params[:work_item_id], staff: @staff,
                                  action: input_string(:action_taken, limit: 30), note: input_string(:note, limit: 500),
                                  event_key: event_key, selections: selections)
    render json: FrontDeskView.activity(activity), status: :created
  end
end
