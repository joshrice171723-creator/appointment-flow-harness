class WorkItemsController < FrontDeskController
  PAGE_SIZE = 12

  def index
    base = @clinic.work_items
    counts = base.group(Arel.sql("CASE WHEN resolved_at IS NOT NULL THEN 'resolved' WHEN assignee IS NOT NULL THEN 'progress' ELSE 'attention' END")).count
    scope = filtered_items(base)
    total = scope.count
    page = (total.fdiv(PAGE_SIZE).ceil).clamp(1, Float::INFINITY)
    current = (Integer(params[:page].to_s, exception: false) || 1).clamp(1, page)
    items = scope.includes(:visit, :contact).order(created_at: :desc, id: :desc)
                 .offset((current - 1) * PAGE_SIZE).limit(PAGE_SIZE)
    render json: { counts: counts, items: items.map { |item| FrontDeskView.work(item) }, page: current, pages: page, **sync_status }
  end

  def show
    item = @clinic.work_items.includes(:visit, :contact, :message).find(params[:id])
    candidates = item.candidate_visit_ids.presence || [ item.visit_id ].compact
    visits = @clinic.visits.includes(:contact).where(id: candidates).order(:starts_at, :id)
    render json: FrontDeskView.work(item).merge(
      message: item.message&.body, candidates: visits.map { |visit| FrontDeskView.visit(visit) },
      activities: @clinic.activities.where(work_item: item).order(created_at: :desc, id: :desc).limit(50).map { |action| FrontDeskView.activity(action) },
      **sync_status
    )
  end

  def update
    @clinic.with_lock do
      item = @clinic.work_items.find(params[:id])
      if item.resolved_at || (item.assignee && item.assignee != @staff)
        return render json: { error: "This item is resolved or assigned to another staff member." }, status: :conflict
      end
      item.update!(assignee: @staff)
      render json: FrontDeskView.work(item)
    end
  end

  private

  def filtered_items(scope)
    scope = case params[:status]
    when "resolved" then scope.where.not(resolved_at: nil)
    when "all" then scope
    else scope.open
    end
    kind = input_string(:kind, limit: 30, required: false)
    scope = scope.where(kind: kind) if WorkItem::KINDS.key?(kind)
    search = input_string(:q, limit: 100, required: false)
    if search.present?
      pattern = "%#{Contact.sanitize_sql_like(search)}%"
      scope = scope.where(contact_id: @clinic.contacts.where("name ILIKE ?", pattern).select(:id))
    end
    scope
  end
end
