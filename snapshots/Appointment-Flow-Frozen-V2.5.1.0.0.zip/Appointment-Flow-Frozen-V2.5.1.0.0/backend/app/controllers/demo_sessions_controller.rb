class DemoSessionsController < ApplicationController
  def create
    clinic = Clinic.find(params[:clinic_id])
    staff = input_string(:staff, limit: 100)
    unless clinic.staff.include?(staff)
      return render json: { error: "Choose a staff member for this clinic." }, status: :unprocessable_entity
    end

    token = demo_sessions.generate([ clinic.id, staff ], expires_in: 8.hours)
    render json: { token: token }, status: :created
  end
end
