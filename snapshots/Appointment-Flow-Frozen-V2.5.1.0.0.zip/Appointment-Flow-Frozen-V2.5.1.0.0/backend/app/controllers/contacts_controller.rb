class ContactsController < FrontDeskController
  def show
    contact = @clinic.contacts.find(params[:id])
    render json: {
      id: contact.id, name: contact.name, effective: contact.effective.slice(*Contact::FIELDS),
      source: contact.source.slice(*Contact::FIELDS), verified: contact.verified.keys, conflicts: contact.conflicts,
      visits: @clinic.visits.where(contact: contact).order(local_date: :desc, id: :desc).limit(50).map { |visit| FrontDeskView.visit(visit, contact) },
      items: @clinic.work_items.where(contact: contact).includes(:visit).order(created_at: :desc, id: :desc).limit(50).map { |item| FrontDeskView.work(item, contact) },
      activities: @clinic.activities.where(contact: contact).order(created_at: :desc, id: :desc).limit(50).map { |item| FrontDeskView.activity(item) },
      **sync_status
    }
  end

  def update
    contact = ContactVerification.call(@clinic, contact_id: params[:id], staff: @staff,
                                       field: input_string(:field, limit: 30), value: input_string(:value, limit: 254), event_key: event_key)
    render json: { verified: contact.verified.keys }
  end
end
