class DemoRepliesController < ApplicationController
  def create
    clinic = Clinic.find(params[:clinic_id])
    contact = clinic.contacts.find(params[:patient_id])
    channel = input_string(:channel, limit: 5)
    raise InboundReply::Invalid, "Choose Text messages or Email." unless Message::CHANNELS.include?(channel)

    reply_to = if params[:reply_to_id].present?
      clinic.messages.delivered.find_by!(id: params[:reply_to_id], channel: channel, contact: contact)
    end
    message = InboundReply.call(clinic, channel: channel, recipient: reply_to&.recipient || contact.public_send(channel),
                                body: input_string(:body, limit: 500), event_key: event_key, reply_to_id: reply_to&.id,
                                contact_id: contact.id)
    render json: DemoMessagesController.message_view(message), status: :created
  end
end
