class DemoMessagesController < ApplicationController
  def index
    clinic = Clinic.find(params[:clinic_id])
    contact = clinic.contacts.find(params[:patient_id])
    channel = input_string(:channel, limit: 5)
    raise InboundReply::Invalid, "Choose Text messages or Email." unless Message::CHANNELS.include?(channel)

    messages = clinic.messages.where(contact: contact, channel: channel).where.not(status: "failed")
                     .order(created_at: :desc, id: :desc).limit(100)
    render json: { messages: messages.reverse.map { |message| DemoMessagesController.message_view(message) },
                   can_reply: contact.public_send(channel).present? }
  end

  def self.message_view(message)
    message.as_json(only: %i[id direction body status created_at in_reply_to_id])
  end
end
