Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  scope "/api", as: :api do
    resources :clinics, only: :index do
      resources :patients, only: :index, controller: :demo_patients do
        resources :messages, only: :index, controller: :demo_messages
        resources :replies, only: :create, controller: :demo_replies
      end
    end
    resources :demo_sessions, only: :create
    resources :appointments, only: :index
    resources :work_items, only: %i[index show update] do
      resources :follow_ups, only: :create
    end
    resources :contacts, only: %i[show update]
    resources :reminder_runs, only: :create
    resources :reports, only: :index
  end

  root "workspace#show"
end
