SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pms; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pms;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.appointments (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    provider_name text,
    start_at timestamp without time zone NOT NULL,
    length_minutes integer,
    procedure_note text,
    status text NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: clinics; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.clinics (
    id bigint NOT NULL,
    name text NOT NULL,
    address_line text,
    city text,
    state character(2),
    phone text
);


--
-- Name: patients; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.patients (
    id bigint NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    birthdate date,
    wireless_phone text,
    email text,
    preferred_language text,
    guarantor_id bigint
);


--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    contact_id bigint,
    work_item_id bigint,
    staff character varying NOT NULL,
    action character varying NOT NULL,
    event_key character varying NOT NULL,
    note text NOT NULL,
    changes_recorded jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: clinics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinics (
    id bigint NOT NULL,
    name character varying NOT NULL,
    timezone character varying NOT NULL,
    staff character varying[] NOT NULL,
    last_synced_at timestamp(6) without time zone,
    sync_error character varying
);


--
-- Name: clinics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clinics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clinics_id_seq OWNED BY public.clinics.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    name character varying NOT NULL,
    source jsonb NOT NULL,
    verified jsonb DEFAULT '{}'::jsonb NOT NULL,
    sms character varying,
    email character varying
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    contact_id bigint,
    visit_id bigint,
    revision integer,
    in_reply_to_id bigint,
    direction character varying NOT NULL,
    channel character varying NOT NULL,
    recipient character varying NOT NULL,
    event_key character varying NOT NULL,
    status character varying NOT NULL,
    requests_confirmation boolean DEFAULT false NOT NULL,
    body text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: sms_opt_outs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_opt_outs (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    recipient character varying NOT NULL
);


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_opt_outs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_opt_outs_id_seq OWNED BY public.sms_opt_outs.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    source_id bigint NOT NULL,
    contact_id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    provider character varying,
    length_minutes integer,
    wall_start character varying NOT NULL,
    local_date date NOT NULL,
    starts_at timestamp(6) without time zone,
    source_status character varying NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    state character varying DEFAULT 'unconfirmed'::character varying NOT NULL
);


--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_items (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    contact_id bigint,
    visit_id bigint,
    message_id bigint,
    revision integer,
    candidate_visit_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    kind character varying NOT NULL,
    work_key character varying NOT NULL,
    detail character varying NOT NULL,
    assignee character varying,
    resolved_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL
);


--
-- Name: work_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_items_id_seq OWNED BY public.work_items.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: clinics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics ALTER COLUMN id SET DEFAULT nextval('public.clinics_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: sms_opt_outs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs ALTER COLUMN id SET DEFAULT nextval('public.sms_opt_outs_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: work_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items ALTER COLUMN id SET DEFAULT nextval('public.work_items_id_seq'::regclass);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sms_opt_outs sms_opt_outs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs
    ADD CONSTRAINT sms_opt_outs_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (id);


--
-- Name: appointments_clinic_start; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX appointments_clinic_start ON pms.appointments USING btree (clinic_id, start_at);


--
-- Name: patients_email_address; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX patients_email_address ON pms.patients USING btree (regexp_replace(lower(email), '^[[:space:]]+|[[:space:]]+$'::text, ''::text, 'g'::text));


--
-- Name: patients_phone_digits; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX patients_phone_digits ON pms.patients USING btree ("right"(regexp_replace(wireless_phone, '[^0-9]'::text, ''::text, 'g'::text), 10));


--
-- Name: index_activities_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_activities_on_clinic_id ON public.activities USING btree (clinic_id);


--
-- Name: index_activities_on_clinic_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_activities_on_clinic_id_and_created_at ON public.activities USING btree (clinic_id, created_at);


--
-- Name: index_activities_on_clinic_id_and_event_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_activities_on_clinic_id_and_event_key ON public.activities USING btree (clinic_id, event_key);


--
-- Name: index_activities_on_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_activities_on_contact_id ON public.activities USING btree (contact_id);


--
-- Name: index_activities_on_work_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_activities_on_work_item_id ON public.activities USING btree (work_item_id);


--
-- Name: index_contacts_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contacts_on_clinic_id ON public.contacts USING btree (clinic_id);


--
-- Name: index_contacts_on_clinic_id_and_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contacts_on_clinic_id_and_email ON public.contacts USING btree (clinic_id, email);


--
-- Name: index_contacts_on_clinic_id_and_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_contacts_on_clinic_id_and_patient_id ON public.contacts USING btree (clinic_id, patient_id);


--
-- Name: index_contacts_on_clinic_id_and_sms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contacts_on_clinic_id_and_sms ON public.contacts USING btree (clinic_id, sms);


--
-- Name: index_messages_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_clinic_id ON public.messages USING btree (clinic_id);


--
-- Name: index_messages_on_clinic_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_clinic_id_and_created_at ON public.messages USING btree (clinic_id, created_at);


--
-- Name: index_messages_on_clinic_id_and_direction_and_event_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_messages_on_clinic_id_and_direction_and_event_key ON public.messages USING btree (clinic_id, direction, event_key);


--
-- Name: index_messages_on_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_contact_id ON public.messages USING btree (contact_id);


--
-- Name: index_messages_on_in_reply_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_in_reply_to_id ON public.messages USING btree (in_reply_to_id);


--
-- Name: index_messages_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_visit_id ON public.messages USING btree (visit_id);


--
-- Name: index_messages_on_visit_id_and_revision_and_event_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_visit_id_and_revision_and_event_key ON public.messages USING btree (visit_id, revision, event_key);


--
-- Name: index_sms_opt_outs_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sms_opt_outs_on_clinic_id ON public.sms_opt_outs USING btree (clinic_id);


--
-- Name: index_sms_opt_outs_on_clinic_id_and_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_sms_opt_outs_on_clinic_id_and_recipient ON public.sms_opt_outs USING btree (clinic_id, recipient);


--
-- Name: index_visits_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_clinic_id ON public.visits USING btree (clinic_id);


--
-- Name: index_visits_on_clinic_id_and_local_date_and_starts_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_clinic_id_and_local_date_and_starts_at ON public.visits USING btree (clinic_id, local_date, starts_at);


--
-- Name: index_visits_on_clinic_id_and_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_visits_on_clinic_id_and_source_id ON public.visits USING btree (clinic_id, source_id);


--
-- Name: index_visits_on_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_contact_id ON public.visits USING btree (contact_id);


--
-- Name: index_work_items_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_clinic_id ON public.work_items USING btree (clinic_id);


--
-- Name: index_work_items_on_clinic_id_and_resolved_at_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_clinic_id_and_resolved_at_and_created_at ON public.work_items USING btree (clinic_id, resolved_at, created_at);


--
-- Name: index_work_items_on_clinic_id_and_work_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_work_items_on_clinic_id_and_work_key ON public.work_items USING btree (clinic_id, work_key);


--
-- Name: index_work_items_on_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_contact_id ON public.work_items USING btree (contact_id);


--
-- Name: index_work_items_on_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_message_id ON public.work_items USING btree (message_id);


--
-- Name: index_work_items_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_visit_id ON public.work_items USING btree (visit_id);


--
-- Name: messages_recipient_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_recipient_lookup ON public.messages USING btree (clinic_id, recipient, channel, direction);


--
-- Name: appointments appointments_clinic_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES pms.clinics(id);


--
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES pms.patients(id);


--
-- Name: patients patients_guarantor_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_guarantor_id_fkey FOREIGN KEY (guarantor_id) REFERENCES pms.patients(id);


--
-- Name: contacts fk_rails_1ce78c131f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT fk_rails_1ce78c131f FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: messages fk_rails_2350000638; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_2350000638 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: activities fk_rails_4f81fb35a0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT fk_rails_4f81fb35a0 FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: sms_opt_outs fk_rails_583ef9e326; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs
    ADD CONSTRAINT fk_rails_583ef9e326 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: visits fk_rails_67f7d0e40e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_67f7d0e40e FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: messages fk_rails_7e8ca78ca8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_7e8ca78ca8 FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: activities fk_rails_8e6c8052c1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT fk_rails_8e6c8052c1 FOREIGN KEY (work_item_id) REFERENCES public.work_items(id);


--
-- Name: visits fk_rails_902d69750b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_902d69750b FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: work_items fk_rails_9064596223; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_9064596223 FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: messages fk_rails_ad35b6f034; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_ad35b6f034 FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: work_items fk_rails_c4c21280ea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_c4c21280ea FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: work_items fk_rails_d67ee6520f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_d67ee6520f FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: work_items fk_rails_dcefa2a8ff; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_dcefa2a8ff FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: activities fk_rails_e0462495bf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT fk_rails_e0462495bf FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: messages fk_rails_fa961db538; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_fa961db538 FOREIGN KEY (in_reply_to_id) REFERENCES public.messages(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO "$user", public;

INSERT INTO "schema_migrations" (version) VALUES
('20261116000002'),
('20261116000001'),
('20261116000000');

