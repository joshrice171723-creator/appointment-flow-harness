# Only the fixture loader writes to the replica. Runtime code reads it.
connection = ApplicationRecord.lease_connection
seed_time = Time.current
clinics = [
  { id: 1, name: "Austin", timezone: "America/Chicago", staff: [ "Taylor Morgan", "Jamie Cruz" ] },
  { id: 2, name: "Phoenix", timezone: "America/Phoenix", staff: [ "Alex Bennett", "Sam Rivera" ] }
]
return if Clinic.where(id: clinics.pluck(:id)).where.not(last_synced_at: nil).count == clinics.size
people = [
  [ "Maya", "Chen", "(512) 555-0101", "en", 6 ],
  [ "Luis", "Santos", nil, "es", 2 ],
  [ "Amelia", "Hart", "(512) 555-0199", "en", 6 ],
  [ "Owen", "Price", "(512) 555-0104", "en", 0 ],
  [ "Nora", "Bell", "(512) 555-0105", "en", 1 ],
  [ "Eli", "Bell", "(512) 555-0105", "en", 2 ],
  [ "Devon", "Reed", "unverified", nil, 1 ],
  [ "Riley", "Lane", "(512) 555-0108", "en", 3 ],
  [ "Parker", "Wells", "(512) 555-0109", "en", -1 ],
  [ "Jules", "Hayes", "(512) 555-0110", "en", -2 ],
  [ "Robin", "Park", "(512) 555-0111", "en", 3 ],
  [ "Avery", "Gray", "(512) 555-0112", "en", 0 ]
]
# A second seed run can fill missing fixtures while preserving local demo history.
statuses = { 8 => "complete", 9 => "broken" }
connection.transaction do
  Clinic.upsert_all(clinics, unique_by: :id)
  clinic_rows = clinics.map do |clinic|
    [ clinic.fetch(:id), clinic.fetch(:name), clinic.fetch(:name), clinic.fetch(:id) == 1 ? "TX" : "AZ" ]
  end
  patients = []
  visits = []
  clinics.each do |clinic|
    clinic_id = clinic.fetch(:id)
    today = seed_time.in_time_zone(clinic.fetch(:timezone)).to_date
    people.each_with_index do |(first, last, phone, language, offset), index|
      patient_id = clinic_id * 100 + index + 1
      first = %w[Emery Mateo Briar Cameron Sky Rowan Reese Kai Sydney Taylor Jordan Casey].fetch(index) if clinic_id == 2
      phone = phone&.sub("512", "602") if clinic_id == 2
      email = [ 4, 5, 6 ].include?(index) ? nil : "#{first.downcase}.#{last.downcase}@example.test"
      birthday = index == 7 ? (today << (12 * 12)) : Date.new(1975 + index, 5, 12)
      patients << [ patient_id, first, last, birthday, phone, email, language ]
      visits << [ patient_id * 10, patient_id, clinic_id, index.even? ? "Dr. Jordan Patel" : "Dr. Avery Ellis",
                  "#{today + offset} #{index.even? ? '14:30:00' : '16:15:00'}", 45, statuses.fetch(index, "scheduled") ]
      # Historical replica visits make the reporting trends inspectable.
      1.upto(5) do |months_ago|
        day = (today.beginning_of_month << months_ago) + index
        outcome = %w[complete complete complete broken unscheduled complete].rotate(clinic_id + months_ago)[index % 6]
        visits << [ patient_id * 10 + months_ago, patient_id, clinic_id, "Dr. Jordan Patel", "#{day} 11:30:00", 45, outcome ]
      end
    end
  end

  {
    "clinics (id, name, city, state)" => clinic_rows,
    "patients (id, first_name, last_name, birthdate, wireless_phone, email, preferred_language)" => patients,
    "appointments (id, patient_id, clinic_id, provider_name, start_at, length_minutes, status)" => visits
  }.each do |target, rows|
    tuples = rows.map { |values| "(#{values.map { |value| connection.quote(value) }.join(', ')})" }.join(", ")
    connection.execute("INSERT INTO pms.#{target} VALUES #{tuples} ON CONFLICT (id) DO NOTHING")
  end
end

Clinic.order(:id).find_each do |clinic|
  local = clinic.local_time(seed_time)
  yesterday = local.to_date.yesterday
  demo_run = ActiveSupport::TimeZone[clinic.timezone].local(yesterday.year, yesterday.month, yesterday.day, 16)
  [ demo_run, seed_time ].each do |time|
    result = ReminderRun.call(clinic, now: time)
    abort("#{clinic.name}: #{result.fetch(:error)}") if result[:error]
    puts "#{clinic.name}: #{result.fetch(:sent)} simulated sends, #{result.fetch(:failed)} simulated failures"
  end
end
