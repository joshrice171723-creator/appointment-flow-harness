class CreatePmsReplica < ActiveRecord::Migration[8.1]
  def up
    execute <<~SQL
      CREATE SCHEMA pms;
      CREATE TABLE pms.clinics (
        id bigint PRIMARY KEY, name text NOT NULL, address_line text,
        city text, state char(2), phone text
      );
      CREATE TABLE pms.patients (
        id bigint PRIMARY KEY, first_name text NOT NULL, last_name text NOT NULL,
        birthdate date, wireless_phone text, email text, preferred_language text,
        guarantor_id bigint REFERENCES pms.patients(id)
      );
      CREATE TABLE pms.appointments (
        id bigint PRIMARY KEY, patient_id bigint NOT NULL REFERENCES pms.patients(id),
        clinic_id bigint NOT NULL REFERENCES pms.clinics(id), provider_name text,
        start_at timestamp without time zone NOT NULL, length_minutes integer,
        procedure_note text, status text NOT NULL, updated_at timestamp without time zone
      );
      CREATE INDEX appointments_clinic_start ON pms.appointments(clinic_id, start_at);
    SQL
  end

  def down
    execute "DROP SCHEMA pms CASCADE"
  end
end
