class IndexPmsContactAddresses < ActiveRecord::Migration[8.1]
  def up
    execute <<~SQL
      CREATE INDEX patients_phone_digits ON pms.patients (right(regexp_replace(wireless_phone, '[^0-9]', '', 'g'), 10));
      CREATE INDEX patients_email_address ON pms.patients (regexp_replace(lower(email), '^[[:space:]]+|[[:space:]]+$', '', 'g'));
    SQL
  end

  def down
    execute "DROP INDEX pms.patients_phone_digits, pms.patients_email_address"
  end
end
