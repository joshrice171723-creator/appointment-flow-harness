class CreateAppointmentWorkflow < ActiveRecord::Migration[8.1]
  def change
    create_table :clinics, id: false do |t|
      t.bigint :id, primary_key: true
      t.string :name, null: false
      t.string :timezone, null: false
      t.string :staff, array: true, null: false
      t.datetime :last_synced_at
      t.string :sync_error
    end

    create_table :contacts do |t|
      t.references :clinic, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.string :name, null: false
      t.jsonb :source, null: false
      t.jsonb :verified, null: false, default: {}
      t.string :sms
      t.string :email
      t.index [ :clinic_id, :patient_id ], unique: true
      t.index [ :clinic_id, :sms ]
      t.index [ :clinic_id, :email ]
    end

    create_table :visits do |t|
      t.bigint :source_id, null: false
      t.references :contact, null: false, foreign_key: true
      t.references :clinic, null: false, foreign_key: true
      t.string :provider
      t.integer :length_minutes
      t.string :wall_start, null: false
      t.date :local_date, null: false
      t.datetime :starts_at
      t.string :source_status, null: false
      t.integer :revision, null: false, default: 1
      t.string :state, null: false, default: "unconfirmed"
      t.index [ :clinic_id, :source_id ], unique: true
      t.index [ :clinic_id, :local_date, :starts_at ]
    end

    create_table :messages do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :contact, foreign_key: true
      t.references :visit, foreign_key: true
      t.integer :revision
      t.references :in_reply_to, foreign_key: { to_table: :messages }
      t.string :direction, null: false
      t.string :channel, null: false
      t.string :recipient, null: false
      t.string :event_key, null: false
      t.string :status, null: false
      t.boolean :requests_confirmation, null: false, default: false
      t.text :body, null: false
      t.datetime :created_at, null: false
      t.index [ :clinic_id, :direction, :event_key ], unique: true
      t.index [ :clinic_id, :recipient, :channel, :direction ], name: "messages_recipient_lookup"
      t.index [ :visit_id, :revision, :event_key ]
      t.index [ :clinic_id, :created_at ]
    end

    create_table :sms_opt_outs do |t|
      t.references :clinic, null: false, foreign_key: true
      t.string :recipient, null: false
      t.index [ :clinic_id, :recipient ], unique: true
    end

    create_table :work_items do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :contact, foreign_key: true
      t.references :visit, foreign_key: true
      t.references :message, foreign_key: true
      t.integer :revision
      t.bigint :candidate_visit_ids, array: true, null: false, default: []
      t.string :kind, null: false
      t.string :work_key, null: false
      t.string :detail, null: false
      t.string :assignee
      t.datetime :resolved_at
      t.datetime :created_at, null: false
      t.index [ :clinic_id, :work_key ], unique: true
      t.index [ :clinic_id, :resolved_at, :created_at ]
    end

    create_table :activities do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :contact, foreign_key: true
      t.references :work_item, foreign_key: true
      t.string :staff, null: false
      t.string :action, null: false
      t.string :event_key, null: false
      t.text :note, null: false
      t.jsonb :changes_recorded, null: false, default: {}
      t.datetime :created_at, null: false
      t.index [ :clinic_id, :event_key ], unique: true
      t.index [ :clinic_id, :created_at ]
    end
  end
end
