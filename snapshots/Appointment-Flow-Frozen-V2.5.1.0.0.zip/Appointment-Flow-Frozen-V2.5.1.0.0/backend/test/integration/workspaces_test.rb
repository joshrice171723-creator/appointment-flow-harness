require "test_helper"

class WorkspacesTest < ActionDispatch::IntegrationTest
  setup do
    travel_to DEMO_NOW
    @clinic = add_clinic
    @phoenix = add_clinic(2, timezone: "America/Phoenix")
    add_patient
    add_patient(2, phone: "(602) 555-0102")
    add_visit(1, start: "2026-02-11 14:00:00")
    add_visit(2, clinic: 2, patient: 2, start: "2026-02-11 14:00:00")
    run_reminders
    run_reminders(@phoenix)
    @contact = @clinic.contacts.sole
    @other_contact = @phoenix.contacts.sole
  end

  test "S10 a staff session scopes reads, updates and assignment to one clinic" do
    get "/api/work_items"
    assert_response :unauthorized
    austin = headers_for(@clinic)
    phoenix = headers_for(@phoenix)
    item = @clinic.work_items.sole
    other_item = @phoenix.work_items.sole

    get "/api/work_items", headers: austin
    assert_response :success
    assert_equal [ item.id ], response.parsed_body.fetch("items").pluck("id")
    get "/api/work_items", headers: phoenix
    assert_equal [ other_item.id ], response.parsed_body.fetch("items").pluck("id")
    patch "/api/work_items/#{item.id}", headers: phoenix, params: {}, as: :json
    assert_response :not_found
    assert_nil item.reload.assignee
    patch "/api/work_items/#{item.id}", headers: austin, params: {}, as: :json
    assert_response :success
    assert_equal @clinic.staff.first, item.reload.assignee
    get "/api/contacts/#{@contact.id}", headers: phoenix
    assert_response :not_found
    patch "/api/contacts/#{@other_contact.id}", headers: austin, as: :json,
          params: { field: "email", value: "updated@example.test", event_key: "wrong-clinic" }
    assert_response :not_found
    assert_empty @other_contact.reload.verified
    get "/api/clinics/#{@phoenix.id}/patients/#{@contact.id}/messages", params: { channel: "sms" }
    assert_response :not_found
    post "/api/clinics/#{@phoenix.id}/patients/#{@contact.id}/replies", as: :json,
         params: { channel: "sms", body: "YES", event_key: "wrong-clinic-reply" }
    assert_response :not_found
  end

  test "S16 and S17 completion is a PMS outcome and the report only returns aggregate fields" do
    outbound = @clinic.messages.delivered.sole
    assert_equal "confirmed", reply("YES", reply_to_id: outbound.id).status
    get "/api/appointments", params: { date: "2026-02-11" }, headers: headers_for(@clinic)
    view = response.parsed_body.fetch("visits").sole
    assert_equal [ "confirmed", "Unknown" ], view.values_at("state", "outcome")

    revise_visit(1, status: "complete")
    run_reminders
    get "/api/appointments", params: { date: "2026-02-11" }, headers: headers_for(@clinic)
    assert_equal [ "confirmed", "Completed" ], response.parsed_body.fetch("visits").sole.values_at("state", "outcome")
    get "/api/reports", params: { month: "2026-02" }
    assert_response :success
    report = response.parsed_body.fetch("clinics")
    assert_equal [ 1, 0 ], report.map { |clinic| clinic.fetch("outcomes").fetch("completed") }
    assert_equal %w[clinic contact_holds deliveries follow_ups history outcomes], report.first.keys.sort
    [ @contact.name, @contact.sms, @contact.email, "PRIVATE_CLINICAL_NOTE", outbound.body ].each do |private_value|
      assert_not_includes response.body, private_value
    end
  end

  test "S18 search, status, date, and clinic context apply to the normal endpoints" do
    staff = headers_for(@clinic)
    get "/api/appointments", params: { date: "2026-02-11" }, headers: staff
    assert_equal [ @contact.name ], response.parsed_body.fetch("visits").pluck("patient")
    assert_equal 1, response.parsed_body.fetch("week_counts").fetch("2026-02-11")
    get "/api/appointments", params: { date: "2026-02-12" }, headers: staff
    assert_empty response.parsed_body.fetch("visits")
    get "/api/work_items", params: { q: "patient 2" }, headers: staff
    assert_empty response.parsed_body.fetch("items")
    get "/api/work_items", params: { q: "patient 1", kind: "no_reply", status: "active" }, headers: staff
    assert_equal 1, response.parsed_body.fetch("items").size
    get "/api/work_items", params: { kind: "contact_hold", status: "active" }, headers: staff
    assert_empty response.parsed_body.fetch("items")
  end

  test "S19 invalid server-side follow-up has no persisted effect and a repeat is idempotent" do
    item = @clinic.work_items.sole
    path = "/api/work_items/#{item.id}/follow_ups"
    headers = headers_for(@clinic)
    post path, params: { action_taken: "confirmed", note: "Called the patient.", event_key: "wrong-selection", selections: [] },
         headers: headers, as: :json
    assert_response 422
    post path, params: { action_taken: "confirmed", note: " ", event_key: "invalid" }, headers: headers, as: :json
    assert_response 422
    assert_empty @clinic.activities
    assert_nil item.reload.assignee
    assert_equal "unconfirmed", @clinic.visits.sole.state

    2.times do
      post path, params: { action_taken: "attempted", note: "Left voicemail.", event_key: "accepted" }, headers: headers, as: :json
      assert_response :created
    end
    assert_equal 1, @clinic.activities.count
    assert_nil item.reload.resolved_at
  end

  test "S20 Email inbox exposes an email and its simulated reply confirms the visit" do
    db.execute("UPDATE pms.patients SET wireless_phone = NULL WHERE id = 1")
    run_reminders(now: DEMO_NOW - 2.days)
    base = "/api/clinics/#{@clinic.id}/patients/#{@contact.id}"
    get "#{base}/messages", params: { channel: "email" }
    assert_response :success
    email = response.parsed_body.fetch("messages").sole
    assert_equal "outbound", email.fetch("direction")
    post "#{base}/replies", params: { channel: "email", body: "YES", reply_to_id: email.fetch("id"), event_key: "email" }, as: :json
    assert_response :created
    assert_equal "confirmed", response.parsed_body.fetch("status")
    get "#{base}/messages", params: { channel: "email" }
    assert_equal %w[outbound inbound], response.parsed_body.fetch("messages").pluck("direction")
    get "/api/work_items", params: { status: "resolved" }, headers: headers_for(@clinic)
    assert_equal 1, response.parsed_body.fetch("items").size
  end

  test "a stale staff action rejects the outcome and retains the refreshed appointment version" do
    staff = headers_for(@clinic)
    item = @clinic.work_items.sole
    visit = @clinic.visits.sole
    revise_visit(1, start_at: "2026-02-11 15:00:00")
    post "/api/work_items/#{item.id}/follow_ups", headers: staff, as: :json, params: {
      action_taken: "confirmed", note: "Confirmed the displayed time.", event_key: "stale-follow-up",
      selections: { visit.id.to_s => visit.revision }
    }
    assert_response 422
    assert_empty @clinic.activities
    assert_equal [ 2, "unconfirmed", "2026-02-11 15:00:00" ], visit.reload.values_at(:revision, :state, :wall_start)
    get "/api/work_items/#{item.id}", headers: staff
    assert_equal 2, response.parsed_body.fetch("candidates").sole.fetch("revision")
  end

  private

  def headers_for(clinic)
    post "/api/demo_sessions", params: { clinic_id: clinic.id, staff: clinic.staff.first }, as: :json
    assert_response :created
    { "X-Demo-Session" => response.parsed_body.fetch("token") }
  end
end
