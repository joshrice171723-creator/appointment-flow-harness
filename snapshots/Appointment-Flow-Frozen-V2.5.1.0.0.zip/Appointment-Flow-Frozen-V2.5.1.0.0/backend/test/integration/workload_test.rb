require "test_helper"
require_relative "../../../quality/rails_workload_probe"

class WorkloadTest < ActionDispatch::IntegrationTest
  test "dated appointment read keeps work bounded as unrelated clinic history grows" do
    travel_to DEMO_NOW
    clinic = prepare_clinic(id: 30, count: 2)
    run_reminders(clinic)
    post "/api/demo_sessions", params: { clinic_id: clinic.id, staff: clinic.staff.first }, as: :json
    headers = { "X-Demo-Session" => response.parsed_body.fetch("token") }
    read = lambda do
      get "/api/appointments", params: { date: "2026-02-17" }, headers: headers
      response.parsed_body.fetch("visits").map { |visit| visit.fetch("source_id") }.sort
    end
    read.call # Exclude request and schema initialization from either comparison.

    db.clear_query_cache
    first, baseline = measure(&read)
    add_unrelated_history(clinic)
    db.clear_query_cache
    second, with_history = measure(&read)

    assert_equal [ 3001, 3002 ], first
    assert_equal first, second
    assert_equal baseline.except(:elapsed_ms), with_history.except(:elapsed_ms)
    assert_equal 0, with_history.fetch(:direct_write_statements)
    report("appointment index", small: baseline, unrelated_history: with_history)
  end

  test "reminder run keeps statement count constant while relevant batch size grows" do
    first = prepare_clinic(id: 40, count: 2)
    second = prepare_clinic(id: 41, count: 2)
    third = prepare_clinic(id: 42, count: 24)
    add_unrelated_history(second, local: false)

    sent_first, baseline = measure { run_reminders(first) }
    sent_second, with_history = measure { run_reminders(second) }
    sent_third, larger = measure { run_reminders(third) }
    repeated, retry_metrics = measure { run_reminders(third) }

    assert_equal [ 2, 2, 24, 0 ], [ sent_first, sent_second, sent_third, repeated ].pluck(:sent)
    assert_equal [ 2, 2, 24 ], [ first, second, third ].map { |clinic| clinic.messages.delivered.count }
    assert_equal baseline.except(:elapsed_ms), with_history.except(:elapsed_ms)
    assert_equal baseline.fetch(:database_statements), larger.fetch(:database_statements)
    assert_equal baseline.fetch(:direct_write_statements), larger.fetch(:direct_write_statements)
    assert_operator larger.fetch(:select_rows), :>, baseline.fetch(:select_rows)
    assert_equal 0, retry_metrics.fetch(:direct_write_statements)
    report("reminder run", small: baseline, unrelated_history: with_history, larger_batch: larger, retry: retry_metrics)
  end

  private

  def prepare_clinic(id:, count:)
    clinic = add_clinic(id)
    1.upto(count) do |index|
      key = id * 100 + index
      add_patient(key, phone: nil)
      add_visit(key, clinic: id, patient: key)
    end
    clinic
  end

  def add_unrelated_history(clinic, local: true)
    patient = clinic.id * 100 + 1
    db.execute(<<~SQL)
      INSERT INTO pms.appointments (id, patient_id, clinic_id, start_at, status)
      SELECT n, #{patient}, #{clinic.id}, '2025-01-01 12:00:00', 'complete' FROM generate_series(10001, 10600) n
    SQL
    return unless local

    contact = clinic.contacts.find_by!(patient_id: patient)
    db.execute(<<~SQL)
      INSERT INTO visits (source_id, clinic_id, contact_id, wall_start, local_date, starts_at, source_status)
      SELECT n, #{clinic.id}, #{contact.id}, '2025-01-01 12:00:00', '2025-01-01', '2025-01-01 18:00:00', 'complete'
      FROM generate_series(10001, 10600) n
    SQL
  end

  def measure(&work)
    select_rows = 0
    subscriber = lambda do |event|
      payload = event.payload
      if payload[:name] != "SCHEMA" && !payload[:cached] && payload[:sql].to_s.match?(/\A\s*SELECT/i)
        select_rows += payload.fetch(:row_count, 0)
      end
    end
    result, metrics = ActiveSupport::Notifications.subscribed(subscriber, "sql.active_record") do
      RailsWorkloadProbe.measure(&work)
    end
    [ result, metrics.merge(select_rows: select_rows) ]
  end

  def report(name, **metrics)
    puts "#{name}: #{metrics.to_json}" if ENV["APEX_WORKLOAD"]
  end
end
