module ReplicaFixtures
  DEMO_NOW = Time.utc(2026, 2, 10, 18)
  DEMO_PHONE = "+15125550101"

  def add_clinic(id = 1, timezone: "America/Chicago")
    insert_replica(:clinics, id: id, name: "Clinic #{id}")
    Clinic.create!(id: id, name: "Clinic #{id}", timezone: timezone, staff: [ "Taylor Morgan", "Jamie Cruz" ])
  end

  def add_patient(id = 1, phone: DEMO_PHONE, email: "patient#{id}@example.test", language: "en", birthday: "1980-04-08", guarantor: nil)
    insert_replica(:patients, id: id, first_name: "Fictional", last_name: "Patient #{id}", birthdate: birthday,
                   wireless_phone: phone, email: email, preferred_language: language, guarantor_id: guarantor)
  end

  def add_visit(id = 1, clinic: 1, patient: 1, start: "2026-02-17 14:00:00", status: "scheduled")
    insert_replica(:appointments, id: id, clinic_id: clinic, patient_id: patient, start_at: start, status: status,
                   provider_name: "Dr. Fiction", length_minutes: 30, procedure_note: "PRIVATE_CLINICAL_NOTE")
  end

  def revise_visit(id, **columns)
    assignments = columns.map { |key, value| "#{key} = #{db.quote(value)}" }.join(", ")
    db.execute("UPDATE pms.appointments SET #{assignments} WHERE id = #{Integer(id)}")
  end

  def insert_replica(table, **columns)
    values = columns.values.map { |value| db.quote(value) }.join(", ")
    db.execute("INSERT INTO pms.#{table} (#{columns.keys.join(', ')}) VALUES (#{values})")
  end

  def db
    ApplicationRecord.lease_connection
  end

  def run_reminders(clinic = @clinic, now: DEMO_NOW, **options)
    ReminderRun.call(clinic, now: now, **options)
  end

  def reply(body, key: "response", channel: "sms", recipient: DEMO_PHONE, clinic: @clinic, now: DEMO_NOW + 1.hour, **options)
    InboundReply.call(clinic, channel: channel, recipient: recipient, body: body, event_key: key, now: now, **options)
  end
end
