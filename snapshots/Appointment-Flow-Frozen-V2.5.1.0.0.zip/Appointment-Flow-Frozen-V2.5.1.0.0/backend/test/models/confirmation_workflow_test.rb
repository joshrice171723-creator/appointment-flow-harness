require "test_helper"

class ConfirmationWorkflowTest < ActiveSupport::TestCase
  setup do
    @clinic = add_clinic
    add_patient
    add_visit
  end

  test "S01 SMS confirms the version and the final reminder is informational" do
    assert_equal({ sent: 1, failed: 0 }, run_reminders)
    first = @clinic.messages.delivered.sole
    assert_equal "sms", first.channel
    assert_includes first.body, "2026-02-17 14:00 CST"
    assert_includes first.body, "Clinic 1"
    assert_includes first.body, "STOP"
    assert_not_includes first.body, "PRIVATE_CLINICAL_NOTE"

    assert_equal "confirmed", reply("  yes ").status
    assert_equal "confirmed", @clinic.visits.sole.state
    assert_equal 0, run_reminders(now: DEMO_NOW + 4.days)[:sent]
    assert_equal 1, run_reminders(now: DEMO_NOW + 6.days)[:sent]
    assert_not @clinic.messages.delivered.order(:created_at).last.requests_confirmation
    assert_equal "scheduled", db.select_value("SELECT status FROM pms.appointments WHERE id = 1")
  end

  test "S02 authorized email works without a phone and matches its original reminder" do
    db.execute("UPDATE pms.patients SET wireless_phone = NULL, preferred_language = 'es' WHERE id = 1")
    run_reminders
    outbound = @clinic.messages.delivered.sole
    assert_equal "email", outbound.channel
    assert_includes outbound.body, "Responda YES"
    result = reply("yes", channel: "email", recipient: "PATIENT1@example.test", reply_to_id: outbound.id)
    assert_equal "confirmed", result.status
    assert_equal outbound.id, result.in_reply_to_id
  end

  test "S03 an old YES goes to review after a reschedule on the same PMS row" do
    run_reminders
    assert_equal "confirmed", reply("YES").status
    revise_visit(1, start_at: "2026-02-17 15:00:00")
    assert_equal 1, run_reminders(now: DEMO_NOW + 2.hours)[:sent]
    assert_equal "needs_review", reply("YES", key: "stale", now: DEMO_NOW + 3.hours).status
    assert_equal [ 2, "unconfirmed" ], @clinic.visits.sole.values_at(:revision, :state)
    assert_equal 2, @clinic.messages.outbound.count
    assert_equal [ @clinic.visits.sole.id ], @clinic.work_items.where(kind: "reply_review").sole.candidate_visit_ids
  end

  test "S04 replacement and original appointment have separate lifecycles" do
    run_reminders
    revise_visit(1, status: "broken")
    add_visit(2, start: "2026-02-18 14:00:00")
    run_reminders(now: DEMO_NOW + 1.day)
    assert_equal [ 1, 2 ], @clinic.messages.outbound.includes(:visit).order(:created_at).map { |record| record.visit.source_id }
    assert_equal "broken", @clinic.visits.find_by!(source_id: 1).source_status
    assert_equal "unconfirmed", @clinic.visits.find_by!(source_id: 2).state
  end

  test "S05 failed SMS is retained and triggers one backup email" do
    db.execute("UPDATE pms.patients SET wireless_phone = '512-555-0199' WHERE id = 1")
    assert_equal({ sent: 1, failed: 1 }, run_reminders)
    assert_equal({ sent: 0, failed: 0 }, run_reminders(now: DEMO_NOW + 1.day))
    assert_equal [ [ "sms", "failed" ], [ "email", "sent" ] ], @clinic.messages.outbound.order(:id).pluck(:channel, :status)
    assert_equal "delivery_failed", @clinic.work_items.sole.kind
    run_reminders(now: DEMO_NOW + 4.days)
    assert_equal 1, @clinic.messages.outbound.where(channel: "sms").count
  end

  test "S06 and S07 duplicate inbound id is safe and a later NO goes to review" do
    run_reminders
    response = reply("YES")
    assert_equal response.id, reply("YES").id
    assert_raises(InboundReply::Invalid) { reply("NO") }
    assert_equal "needs_review", reply("NO", key: "later-no").status
    assert_equal "confirmed", @clinic.visits.sole.state
    assert_equal 2, @clinic.messages.where(direction: "inbound").count
    assert_equal "reply_review", @clinic.work_items.sole.kind
  end

  test "S08 a reply at start is saved for review and the elapsed visit receives no messages" do
    run_reminders
    start = @clinic.visits.sole.starts_at
    assert_equal "needs_review", reply("YES", now: start).status
    assert_equal "unconfirmed", @clinic.visits.sole.state
    assert_equal 0, run_reminders(now: start)[:sent]
  end

  test "S09 STOP persists through a refresh and applies to SMS only" do
    run_reminders
    assert_equal "needs_review", reply("STOP?!", key: "unsafe-stop").status
    assert_empty @clinic.sms_opt_outs
    assert_equal "opted_out", reply(" stop ").status
    assert_equal DEMO_PHONE, @clinic.sms_opt_outs.sole.recipient
    run_reminders(now: DEMO_NOW + 4.days)
    assert_equal [ "sms", "email" ], @clinic.messages.delivered.order(:created_at).pluck(:channel)
    assert_equal DEMO_PHONE, db.select_value("SELECT wireless_phone FROM pms.patients WHERE id = 1")
  end

  test "S11 attempt stays open, then staff confirmation resolves the appointment work" do
    run_reminders(now: DEMO_NOW + 6.days)
    item = @clinic.work_items.find_by!(kind: "no_reply")
    visit = @clinic.visits.sole
    now = DEMO_NOW + 6.days + 1.hour
    common = { item_id: item.id, staff: @clinic.staff.first, note: "Reached the clinic voicemail.", now: now }
    attempt = StaffFollowUp.call(@clinic, **common, action: "attempted", event_key: "attempt", selections: {})
    assert_nil item.reload.resolved_at
    assert_equal @clinic.staff.first, item.assignee
    assert_equal attempt.id, StaffFollowUp.call(@clinic, **common, action: "attempted", event_key: "attempt", selections: {}).id
    StaffFollowUp.call(@clinic, **common, action: "confirmed", event_key: "confirm", selections: { visit.id.to_s => visit.revision })
    assert item.reload.resolved_at
    assert_equal "confirmed", visit.reload.state
    assert_equal 2, @clinic.activities.count
  end

  test "S12 shared contact is held and a reply links all relevant visits for review" do
    add_patient(2, email: nil)
    add_visit(2, patient: 2)
    run_reminders
    assert_empty @clinic.messages.outbound.where(channel: "sms")
    assert_equal "needs_review", reply("YES").status
    assert_equal @clinic.visits.ids.sort, @clinic.work_items.where(kind: "reply_review").sole.candidate_visit_ids.sort
    assert_equal [ "unconfirmed" ], @clinic.visits.distinct.pluck(:state)
  end

  test "S12 an owner outside the appointment projection makes the channel unsafe" do
    add_patient(2, phone: "(512) 555-0101", email: nil)
    add_visit(2, patient: 2, start: "2026-01-15 14:00:00", status: "complete")
    run_reminders
    assert_equal [ "email" ], @clinic.messages.delivered.pluck(:channel)
    assert_equal 1, @clinic.contacts.count

    db.execute("UPDATE pms.patients SET wireless_phone = '512-555-0102' WHERE id = 2")
    run_reminders(now: DEMO_NOW + 4.days)
    assert_equal 1, @clinic.messages.delivered.where(channel: "sms").count
    db.execute("UPDATE pms.patients SET wireless_phone = '512-555-0101' WHERE id = 2")
    assert_equal "needs_review", reply("YES", now: DEMO_NOW + 4.days + 1.hour).status
    assert_equal "unconfirmed", @clinic.visits.sole.state
  end

  test "an unthreaded old YES cannot confirm a later appointment after the old visit elapsed" do
    run_reminders
    older = @clinic.messages.delivered.sole
    revise_visit(1, status: "complete")
    add_visit(2, start: "2026-03-17 14:00:00")
    later = DEMO_NOW + 28.days
    run_reminders(now: later)
    current = @clinic.messages.delivered.order(:created_at).last

    assert_equal "needs_review", reply("YES", now: later + 1.hour).status
    assert_equal "needs_review", reply("YES", now: later + 1.hour, key: "old", reply_to_id: older.id).status
    assert_equal "unconfirmed", @clinic.visits.find_by!(source_id: 2).state
    assert_equal "confirmed", reply("YES", now: later + 1.hour, key: "new", reply_to_id: current.id).status
  end

  test "S13 a local correction unblocks messages and conflicting subsequent PMS data reopens the hold" do
    db.execute("UPDATE pms.patients SET birthdate = '2014-01-01' WHERE id = 1")
    assert_equal 0, run_reminders[:sent]
    hold = @clinic.work_items.sole
    assert_includes hold.detail, "Guardian"
    ContactVerification.call(@clinic, contact_id: @clinic.contacts.sole.id, staff: @clinic.staff.first, field: "birthdate",
                             value: "1985-04-16", event_key: "verify", now: DEMO_NOW)
    assert_equal 1, run_reminders[:sent]
    assert hold.reload.resolved_at
    assert_equal Date.new(2014, 1, 1), db.select_value("SELECT birthdate FROM pms.patients WHERE id = 1")
    db.execute("UPDATE pms.patients SET birthdate = '1987-01-01' WHERE id = 1")
    assert_equal 0, run_reminders(now: DEMO_NOW + 1.day)[:sent]
    assert_nil hold.reload.resolved_at
    assert_includes hold.detail, "disagree"
  end

  test "S14 incomplete or failed refresh keeps the previous state and pauses sends" do
    run_reminders
    db.execute("DELETE FROM pms.appointments WHERE id = 1")
    assert run_reminders(now: DEMO_NOW + 1.day)[:error]
    assert_equal DEMO_NOW, @clinic.reload.last_synced_at
    assert_equal 1, @clinic.visits.count
    assert_equal 1, @clinic.messages.outbound.count
    db.execute("ALTER TABLE pms.appointments RENAME TO unavailable_appointments")
    assert_match(/could not be refreshed/, run_reminders[:error])
    assert_equal DEMO_NOW, @clinic.reload.last_synced_at
  end

  test "S15 local send window and DST gaps or folds never create invalid send times" do
    phoenix = add_clinic(2, timezone: "America/Phoenix")
    add_visit(2, clinic: 2)
    assert_equal 1, run_reminders(now: Time.utc(2026, 2, 10, 16, 30))[:sent]
    assert_equal 0, run_reminders(phoenix, now: Time.utc(2026, 2, 10, 16, 30))[:sent]
    assert_equal 1, run_reminders(phoenix, now: Time.utc(2026, 2, 10, 17))[:sent]
    assert_equal Time.utc(2026, 2, 17, 20), @clinic.visits.sole.starts_at
    assert_equal Time.utc(2026, 2, 17, 21), phoenix.visits.sole.starts_at

    [ [ "2026-03-08 02:30:00", Time.utc(2026, 3, 1, 18) ], [ "2026-11-01 01:30:00", Time.utc(2026, 10, 25, 18) ] ].each do |wall, now|
      revise_visit(1, start_at: wall)
      assert_equal 0, run_reminders(now: now)[:sent]
      assert_nil @clinic.visits.sole.starts_at
      assert @clinic.work_items.open.exists?(kind: "visit_review")
    end
  end

  test "fake delivery programming failure rolls back the refresh and any queued fake attempts" do
    add_patient(2, phone: "512-555-0102")
    add_visit(2, patient: 2)
    delivery = Object.new
    def delivery.deliver(recipient:, **)
      raise "simulation interrupted" if recipient.end_with?("0102")
      "sent"
    end

    assert_raises(RuntimeError) { run_reminders(delivery: delivery) }
    assert_empty @clinic.visits
    assert_empty @clinic.messages
    assert_nil @clinic.reload.last_synced_at
    assert_equal 2, run_reminders[:sent]
  end
end
