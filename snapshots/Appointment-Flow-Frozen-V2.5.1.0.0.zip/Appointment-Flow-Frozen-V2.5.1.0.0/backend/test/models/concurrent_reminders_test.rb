require "test_helper"

class ConcurrentRemindersTest < ActiveSupport::TestCase
  self.use_transactional_tests = false

  test "S15 two concurrent batches create one logical send and one retry has no effect" do
    clinic = add_clinic(913)
    add_patient(913)
    add_visit(913, clinic: 913, patient: 913)
    ready = Queue.new
    start = Queue.new
    workers = 2.times.map do
      Thread.new do
        ApplicationRecord.connection_pool.with_connection do
          ready << true
          start.pop
          run_reminders(Clinic.find(913))
        end
      end
    end
    2.times { ready.pop }
    2.times { start << true }
    assert_equal [ 0, 1 ], workers.map(&:value).map { |result| result.fetch(:sent) }.sort
    assert_equal 1, clinic.messages.count
    assert_equal 0, run_reminders(clinic)[:sent]
  ensure
    if clinic
      WorkItem.where(clinic: clinic).delete_all
      Message.where(clinic: clinic).delete_all
      Visit.where(clinic: clinic).delete_all
      Contact.where(clinic: clinic).delete_all
      clinic.destroy!
      db.execute("DELETE FROM pms.appointments WHERE id = 913")
      db.execute("DELETE FROM pms.patients WHERE id = 913")
      db.execute("DELETE FROM pms.clinics WHERE id = 913")
    end
  end
end
