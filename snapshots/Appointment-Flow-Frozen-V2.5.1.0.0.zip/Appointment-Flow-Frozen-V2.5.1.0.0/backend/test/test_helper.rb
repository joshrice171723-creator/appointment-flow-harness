ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"
require_relative "support/replica_fixtures"

class ActiveSupport::TestCase
  include ReplicaFixtures
end
