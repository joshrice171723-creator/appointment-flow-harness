# AGENTS.md — Apex clean-room rebuild contract V2.5.1.0.0

## Read order and precedence
1. `RUN_THIS_IN_RUBYMINE.md` (execution contract)
2. `reference/Appointment-Confirmation-Take-Home.pdf` (official assignment, highest product authority)
3. `product-spec/PRODUCT_BRIEF.md`, `BEHAVIORAL_REQUIREMENTS.md`, `USER_JOURNEYS.md`, `SCENARIOS.md`, and `ACCEPTANCE_TESTS.md` (observed product intent)
4. `product-spec/SCREENSHOT_INDEX.md` and the actual PNGs (visual reference, **not** proof of unseen behavior)
5. `docs/CODING_STANDARDS.md`, `docs/ARCHITECTURE_GUARDRAILS.md`, `docs/REVIEW_RUBRIC.md` (engineering discipline)
6. Other templates, prompts, and reference documents

If sources disagree, keep the official assessment above the baseline behavior and visuals. Note material ambiguity in a decision log; make a narrow, defensible choice rather than inventing facts.

## Absolute clean-room boundary
- Build in this newly extracted directory, as a **brand-new application and Git repository**.
- NEVER open, clone, search, fetch, inspect, or copy code, tests, config, commit history, issues, agent notes, API routes, model names, database migrations, or architecture from the earlier appointment-flow repository. This includes GitHub connector access and local files from that repository. The old project is strictly a post-completion comparison baseline.
- Only the assessment PDF, the ten included UI screenshots, and **sanitized behavior-only documents** are authorized information about the prior product. Do not look for screenshots or more details in the old codebase.
- Do not add the old repository as a Git remote. Do not publish to it. Create a new independent repository if publishing is authorized.
- The screenshot names are descriptive labels, not code or API requirements.
- Do not recreate the former code architecture even if a product example tempts you to do so. Choose your own solution from the problem and justify it.

## Quality hierarchy
Meet the agreed scope, safety, and correctness requirements. Within that scope, judge the code by how easily a reader can follow it, where a maintainer would change a rule, and how its work grows with data.

- Read new-project code before editing it. Take small, reviewable vertical slices.
- Use meaningful domain names, direct control flow, cohesive functions, and minimal, justified abstraction. No decorative service objects, generic frameworks, unnecessary React hooks/contexts, broad base classes, or clever metaprogramming.
- Implement real behavior, not just a screenshot replica. Every important UI action must be connected to an observable state change.
- Add focused automated tests for high-risk behavior: wrong-recipient outreach, clinic data isolation, duplicate sends, ambiguous replies, opt-outs, rescheduled appointments, timezone/clinic-local dates, no PHI in leadership data.
- Do not treat a fake provider's successful API call as proof of real-world SMS/email delivery. No live communications or real patient data.
- Preserve fake PMS source data as read-only from the app's perspective; do not modify the authoritative replica tables at runtime.
- Don't add booking, self-service rescheduling, production infrastructure, full authentication, or live vendor accounts. The brief puts these out of scope.
- Never skip failed or unavailable checks; don't claim unrun tests passed. Use the quality runner after the app is scaffolded.
- Follow `docs/PERFORMANCE.md` for a material data-access change during the slice. Before freeze, verify one consequential read and one write or batch from the actual callers. Reuse evidence for the same implementation and workload. Compare fixtures with the same relevant work and more unrelated history, and with more relevant items when the operation handles a batch. Record observable behavior, SQL and row counts, and applicable write or lock behavior.
- Run a **separate reviewer session** for the final diff; require file/line references, evidence, severity, and the least complex fix. Do not mechanically adopt speculative review requests.
- No automatic push/PR/merge. No destructive operations outside the new workspace. Obtain user authorization to create external resources, access secrets, or install third-party executables.
- The candidate writes `DECISIONS.md` in their **own words**. The agent can produce tradeoff bullet notes, questions, and critique, but must not ghostwrite personal explanations and attribute them to the candidate.

## Before implementing a consequential workflow

For a workflow that makes an important business decision, coordinates writes, or can do increasingly expensive work, trace the normal caller and expected failure before writing the implementation. Keep the reasoning in the existing slice plan.

- Put the stages in execution order at the rule owner's entry point. Use a plain, domain-named private step when it exposes a decision or makes the sequence easier to follow.
- Identify the data needed and what can be rejected before loading more records or writing. Prefer a scoped Active Record relation for filtering, existence checks, or aggregation when it preserves the rule. Check whether lookups or writes repeat as the relevant work grows.
- Identify which writes must succeed together, who owns rollback, and which failures the caller needs to distinguish. Translate an expected failure where its origin is known, preserve its cause, and handle any surviving state at the boundary that can actually persist it. Keep local persistence and programming errors diagnosable.
- At the HTTP boundary, use conventional Rails actions such as `index`, `show`, `create`, `update`, and `destroy` where the operation fits a resource. Give the resource and the workflow meaningful names. Justify a custom action by the contract it represents.

Verify the decision with the slice's focused checks. For consequential multi-write behavior, check the persisted state after a failure that happens during the operation. Use existing evidence when it covers the same behavior.

## At each slice
Summarize requirement IDs, implementation approach, alternatives, tests run and *actual* results, remaining gaps, and a plain-English explanation of why this code is structured this way. Do not pad with generic engineering essays.
