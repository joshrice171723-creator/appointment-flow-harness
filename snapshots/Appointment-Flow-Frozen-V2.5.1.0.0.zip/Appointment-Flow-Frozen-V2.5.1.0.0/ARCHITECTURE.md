# Architecture

```mermaid
flowchart LR
  Desk[Front desk] --> Api[Rails JSON API]
  Inbox[Patient demo inbox] --> Api
  Leadership[Leadership] --> Api
  Task[Manual Rails task] --> Run[Reminder run]
  Api --> Run
  Api --> Reply[Inbound reply]
  Api --> FollowUp[Staff follow-up and contact verification]
  Api --> Report[Outcome report]
  Run --> Refresh[PMS refresh]
  Reply --> Refresh
  FollowUp --> Refresh
  Refresh -->|Read| PMS[(PMS replica)]
  Report -->|Aggregate status counts| PMS
  Refresh -->|Project current visits and contact facts| Local[(App-owned PostgreSQL tables)]
  Run --> Fake[Fake SMS and email]
  Run -->|Record attempts and work| Local
  Reply -->|Record reply, opt-out or confirmation| Local
  FollowUp -->|Record staff decisions| Local
  Report -->|Aggregate activity| Local
```

React sends the selected staff session with each front-desk request. Rails takes the clinic from that signed session and looks up records through clinic associations. The patient demo scopes each contact to the selected fictional clinic. Leadership reads aggregate source and app outcomes.

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed
  Unconfirmed --> Confirmed: Matching YES or explicit staff confirmation
  Unconfirmed --> Unconfirmed: Review item for unclear or late reply
  Confirmed --> Confirmed: Later NO opens a review item
  Unconfirmed --> Stopped: Staff records cancellation or reschedule
  Confirmed --> Stopped: Staff records cancellation or reschedule
  Confirmed --> Unconfirmed: Appointment time or patient changes
  Stopped --> Unconfirmed: Source creates a new appointment version
```

- Visit revisions identify the clinic, patient and wall-clock appointment version. PostgreSQL stores the supplied wall time separately from the converted instant. Austin uses `America/Chicago`, and Phoenix uses `America/Phoenix`. Ambiguous and nonexistent times stay visible for review and do not qualify for outreach.
- Batch, reply, verification, and follow-up writes acquire the selected clinic row lock. The batch commits the source projection, attempts and derived tasks together. A refresh savepoint allows source failures to roll back the read and preserve a clinic-level sync error. Unique constraints protect logical send steps, inbound events and staff requests from replay.
- A reply requires a single eligible recipient and a matching current visit revision. A reply without a reference considers competing delivered revisions across the recipient’s history. The simulator can attach a specific delivered message. Shared contacts and changed visits go to staff review. Exact SMS STOP commits a clinic-scoped opt-out.
- PMS outcome and confirmation have independent lifecycles. A completed PMS visit can still show the confirmation it received earlier.
