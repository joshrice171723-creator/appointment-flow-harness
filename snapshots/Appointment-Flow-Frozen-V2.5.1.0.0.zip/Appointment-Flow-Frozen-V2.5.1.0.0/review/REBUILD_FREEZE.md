# Clean-room rebuild freeze

Application revision `5d9680bc08b4e8ab5c1556929983f2ff9e3da28f`. Verification ran on 2026-11-16 on Windows against PostgreSQL 17.11.

## Acceptance and evidence

| Area | Result | Evidence |
| --- | --- | --- |
| Harness preflight | PASS | `python quality/verify_harness.py` verified all 53 inputs and 10 PNG signatures before scaffolding and again after implementation. |
| PostgreSQL source, fake reminders, and confirmation | PASS | [Confirmation workflow tests](../backend/test/models/confirmation_workflow_test.rb) cover both channels, source status and rebooking, version-bound replies, late replies, opt-outs, contact holds, failed refresh, and local dates. |
| Retry, rollback, and recipient safety | PASS | [Confirmation workflow tests](../backend/test/models/confirmation_workflow_test.rb) verify persisted rollback and address ownership beyond the projection. [Concurrent reminder test](../backend/test/models/concurrent_reminders_test.rb) starts two callers and checks for one logical message. |
| Clinic scope, staff actions, and reporting | PASS | [Workspace integration tests](../backend/test/integration/workspaces_test.rb) exercise signed scope, dashboard reads and writes, stale revisions, local dates, and aggregate response contents. |
| React interactions | PASS | [Workspace tests](../frontend/src/Workspaces.test.tsx) cover clinic selection, the email empty state and reply, plus an explicit retry with an intact draft and stable event key. |
| Local setup and browser smoke | PASS | `ruby bin/start.rb` built and served the app. Headless Edge 157 exercised desktop workspaces, appointment browsing, claiming a case, recording a contact attempt, SMS and email confirmations, clinic switching, leadership expansions, and a 390 px landing layout. The browser smoke was repeated after the review repairs. |
| App quality gate | PASS | `python quality/run_checks.py` passed all seven checks. Rails reported 25 tests and 189 assertions, with zero failures, errors, or skips. React reported 3 passing tests. RuboCop reported zero offenses, Brakeman zero warnings, and lint, typecheck, and build passed. |
| Independent review | PASS | A separate reviewer examined the staged implementation and re-reviewed the repaired paths. See the findings below. |
| Clean-room boundary | PASS | Implementation used the packaged inputs and a new Git repository. |
| GitHub Actions | NOT RUN | The CI workflow is checked in. Verification here used the local harness. |
| Candidate-authored rationale and live defense | NOT RUN | [Candidate decision notes](../notes/REBUILD_DECISION_NOTES.md) are available. The assessment assigns the final `DECISIONS.md` and live defense to the candidate. |

## Independent review findings

| Severity | Finding and repair | Regression |
| --- | --- | --- |
| Blocking | Shared source addresses outside the appointment projection could pass the recipient check. The [indexed source ownership lookup](../backend/app/services/contact_address_ownership.rb#L24) is now checked for sending and replying. | [Out-of-window shared address](../backend/test/models/confirmation_workflow_test.rb#L125) |
| Blocking | An old bare YES could match a newer appointment once the older reminder aged out. [Unthreaded matching](../backend/app/services/inbound_reply.rb#L90) now checks all delivered versions for that address. An explicit simulated reply reference still has to match the current visit. | [Delayed YES and two versions](../backend/test/models/confirmation_workflow_test.rb#L140) |
| Major | A stale staff assertion rejected the outcome and rolled back the successful source refresh. [Staff follow-up](../backend/app/services/staff_follow_up.rb#L7) now commits the refresh before returning the expected rejection. | [Stale staff action](../backend/test/integration/workspaces_test.rb#L124) |

The reviewer traced clinic scope to the signed session and its associations, examined aggregate leadership output, and verified that a clinic row lock and database uniqueness protect logical sends. The reviewer’s final verdict was Ready. The parent session ran the database and browser checks recorded above.

## Workload evidence

[Workload tests](../backend/test/integration/workload_test.rb) exercise the dated appointment endpoint and the Rails caller shared by the front-desk Run fake reminders action and the rake task. The timings exclude fixture setup. SELECT rows are rows returned to Rails. The SQL count includes transaction and lock statements.

| Operation and fixture | SQL statements | SELECT rows | Rails records instantiated | Write statements | Rails run ms | Full gate ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Appointment read with 2 visits | 6 | 6 | 5 | 0 | 10.3 | 20.1 |
| Same read plus 600 unrelated historical visits | 6 | 6 | 5 | 0 | 10.4 | 22.1 |
| Reminder run with 2 due visits | 26 | 13 | 5 | 4 | 24.2 | 144.0 |
| Same batch plus 600 unrelated historical source visits | 26 | 13 | 5 | 4 | 22.1 | 85.2 |
| Reminder run with 24 due visits | 26 | 145 | 49 | 4 | 51.4 | 283.9 |
| Retry of the 24-visit batch at the same clock instant | 22 | 241 | 97 | 0 | 29.6 | 83.5 |

The dated read returned the same two appointments with and without added history. The first three reminder runs committed 2, 2, and 24 simulated sends respectively. A same-instant retry created zero messages and issued zero write statements. More relevant visits increase rows read and projected. The complete batch holds one clinic row lock, and a separate concurrency test verifies persisted deduplication. These fixture measurements record caller behavior and query traffic. Production capacity was outside verification.

## Preserve this revision

Tag the verified application revision locally or export its committed tree for a later blind comparison. Preserve the harness manifest and input files alongside the application. The new repository has no remote configured.
