# Apex Appointment Flow

A local Rails and React demo for appointment reminders, confirmation replies, front-desk follow-up, and clinic outcome reporting. The seed data describes fictional patients in Austin and Phoenix.

## Run locally

The verified Windows toolchain was Ruby 3.4.10, Bundler 4.0.15, Rails 8.1.4.1, PostgreSQL 17.11, Node 24.19.0, and npm 11.17.0. Python 3.10 or newer runs the harness. Put the PostgreSQL client tools, including `psql` and `pg_dump`, on `PATH` before starting.

The local PostgreSQL account needs permission to create `apex_rebuild_development` and `apex_rebuild_test`. Defaults are host `127.0.0.1`, port `5432`, and user `postgres`. Set the standard `PGHOST`, `PGPORT`, `PGUSER`, and `PGPASSWORD` environment variables as required by your local installation. This workstation used port `58122`.

From the repository root, run:

```console
python quality/verify_harness.py
ruby bin/start.rb
```

Open [the local workspace](http://127.0.0.1:3000). The startup command prepares the demo databases, seeds the development database on first setup, builds React, and starts Rails on loopback. Set `APEX_PORT` to use a different HTTP port.

## Demo the workflows

1. Open **Front desk**, select **Austin** and **Taylor Morgan**, then open **Patient flow**. Assign a work item to yourself and record an attempt with a note. Open **Appointments** to browse clinic-local dates and confirmation states. The patient details view shows both source and verified contact values when they conflict.
2. Open **Patient demo** and select **Austin**, then **Maya Chen**. Enter `YES` in **Text messages** to confirm the seeded appointment. Select **Luis Santos** and open **Email** to try the same workflow by email. Select a specific delivered reminder if the inbox has messages for several appointment versions.
3. Return to **Appointments** and choose the date shown in the message to see the confirmation. Use `NO` to create a review item or `STOP` to suppress future texts for that number at the selected clinic.
4. Open **Apex leadership** and choose a month. Completion rate is completed visits divided by recorded visits. A scheduled or otherwise unmapped source status counts as unknown. The source offers no distinct no-show status.

The seed uses relative dates. For example, a fresh seed provides Maya’s first reminder for a visit six local calendar days ahead, and Luis’s email follow-up for a visit two local calendar days ahead. A seed becomes less useful as time advances. Create a fresh demo database to replay the initial state.

## Trigger and inspect reminder runs

Use **Run fake reminders** from Patient flow for the selected clinic, or run the documented task from `backend/`:

```console
ruby -S bundle exec rails reminders:run
```

`APEX_CLINIC` narrows the task to clinic ID `1` or `2`. `APEX_DEMO_AT` supplies an ISO-8601 clock instant for synthetic replay. The HTTP action uses the current clock. The patient inbox displays simulated deliveries and replies. To inspect fake attempts, including failures, run this from `backend/`:

```console
ruby -S bundle exec rails runner "pp Message.outbound.order(:id).pluck(:id, :clinic_id, :visit_id, :channel, :status, :created_at)"
```

The clinic-local sending window is 10:00–18:00. The batch checks eligibility 7–6 days out, uses a backup email at day 6 when the initial text is unanswered, follows up 3–2 days out, and sends a final reminder one day out. A confirmed visit can receive a final informational reminder. A simulated SMS failure can immediately fall back to a permitted email. The demo treats an eligible source mobile or email as permission to contact a fictional adult. SMS opt-outs, shared contacts, unsupported languages, age or guardian uncertainty, and source conflicts constrain eligibility. The fake SMS number ending in `0199` produces a stored delivery failure.

## Run the checks

After installing dependencies, prepare a blank test database and run the quality gate:

```console
cd backend
ruby -S bundle exec rails db:create
ruby -S bundle exec rails db:migrate
cd ..
npm --prefix frontend ci
python quality/run_checks.py
```

The test check loads the checked-in PostgreSQL structure when the test database needs it. Run the workload checks with `APEX_WORKLOAD=1` to print elapsed time, SQL statements and returned rows:

```console
cd backend
ruby -S bundle exec rails test test/integration/workload_test.rb
```

Use `npm run dev` from `frontend/` alongside Rails for live frontend reloads. Set `APEX_RAILS_URL` when the Rails process uses a different port.

## Data and deployment boundaries

The `pms` schema mirrors the supplied PostgreSQL excerpt. Migrations and fixture loading set up the replica. The runtime PMS readers execute SELECT statements through Rails’ write-prevention guard. App-owned tables store the clinic configuration, contacts, current visit revisions, fake communication, opt-outs and work history. The local database owner can administer both schemas. A deployed design would use a separate read-only replica role and explicit patient-contact permissions.

The signed staff selection is a demo identity stub. A deployment would require authenticated staff, authorization by clinic, verified inbound provider identity, and a separate delivery mechanism with provider-level idempotency. Reminder execution here is manual and fake delivery results live in the same database transaction as the decision to send.

See [Architecture](ARCHITECTURE.md), [AI usage](AI_USAGE.md), and [candidate decision notes](notes/REBUILD_DECISION_NOTES.md). The assessment reserves `DECISIONS.md` for the candidate’s own rationale.
