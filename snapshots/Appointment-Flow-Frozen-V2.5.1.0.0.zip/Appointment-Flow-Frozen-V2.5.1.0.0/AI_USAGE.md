# AI usage

Codex read the packaged assessment, sanitized behavior requirements, and ten supplied screenshots. It implemented the Rails and React rebuild and wrote the automated tests, startup commands, architecture diagram, and engineering notes. It used PowerShell, Ruby/Rails, PostgreSQL, Node, Python, Git, Edge, and the quality harness to verify the work.

Joshua directed the clean-room rebuild and required the harness preflight before any application code. Codex chose the implementation details recorded in the decision notes. The session has no evidence of later Joshua edits to those implementation choices. The prior application was kept outside the work.

An independent Codex reviewer identified three problems in the first implementation. It missed shared source addresses outside the operational projection, could attribute a delayed bare reply to a later appointment, and rolled back refreshed data when rejecting a stale staff submission. The implementation added address ownership checks, kept all competing reminder versions eligible for ambiguity detection, and committed successful syncs before returning stale-action errors.

The final rationale and live defense belong to the candidate. This record describes the AI work observed in this session.
