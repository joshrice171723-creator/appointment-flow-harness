import { useState } from 'react'
import type { FormEvent } from 'react'
import { api, errorMessage, mutation, useResource } from './api'
import { VisitTable } from './Appointments'
import { wallLabel } from './format'
import { Badge, Status, SyncStatus, Tab, Tabs } from './shared'
import { ActivityList } from './WorkDetail'
import type { Contact, ContactField, Session } from './types'

const fields: Record<ContactField, string> = {
  birthdate: 'Birthdate', wireless_phone: 'Mobile phone', email: 'Email', preferred_language: 'Preferred language',
}
const tabs = ['Follow-up', 'Appointments', 'Activity log']

export function Patient({ id, session }: { id: string; session: Session }) {
  const [tab, setTab] = useState(tabs[0])
  const [revision, setRevision] = useState(0)
  const [success, setSuccess] = useState('')
  const [field, setField] = useState<ContactField>()
  const { data, error } = useResource<Contact>(`/contacts/${id}`, session.token, revision)
  const next = data?.visits.filter((visit) => visit.source_status === 'scheduled' && visit.starts_at && new Date(visit.starts_at) > new Date())
    .sort((left, right) => left.wall_start.localeCompare(right.wall_start))[0]

  return <main className="container">
    <a className="back" href="#/front-desk">← Patient flow</a>
    <Status error={error} loading={!data && !error} />
    {data && <>
      <div className="page-heading"><p className="eyebrow">{session.clinic.name}</p><h1>{data.name}</h1></div>
      <SyncStatus sync={data} timezone={session.clinic.timezone} />
      <div className="next-visit">
        <strong>Next scheduled appointment</strong>
        <p>{next ? `${wallLabel(next.wall_start)} · Appointment #${next.source_id}` : 'No upcoming appointment recorded.'}</p>
      </div>
      {success && <p className="notice" role="status">{success}</p>}
      <div className="details-grid">
        <aside className="panel details-card">
          <h2>Patient details</h2>
          <dl className="facts">{(Object.keys(fields) as ContactField[]).map((key) => <div key={key}>
            <dt>{fields[key]}</dt><dd><strong>{data.effective[key] ?? 'No value on file'}</strong>
              <button className="text-link edit-link" type="button" onClick={() => setField(key)}>Verify</button></dd>
            <Badge color={data.conflicts.includes(key) ? 'amber' : data.verified.includes(key) ? 'green' : 'neutral'}>
              {data.conflicts.includes(key) ? 'Source conflict' : data.verified.includes(key) ? 'Verified' : 'Unverified'}
            </Badge>
            {data.conflicts.includes(key) && <p className="meta">PMS value {data.source[key] ?? 'unavailable'}</p>}
          </div>)}</dl>
          {field && <Verification key={field} contact={data} field={field} session={session}
            onCancel={() => setField(undefined)} onSaved={() => {
              setField(undefined)
              setSuccess(`${fields[field]} verified.`)
              setRevision((value) => value + 1)
            }} />}
        </aside>
        <div className="details-content">
          <Tabs label="Patient details">{tabs.map((option) => <Tab key={option} active={option === tab} onClick={() => setTab(option)}>{option}</Tab>)}</Tabs>
          <section className="panel details-card">
            <h2>{tab === 'Follow-up' ? 'Follow-up items' : tab}</h2>
            {tab === 'Appointments' && <VisitTable visits={data.visits} />}
            {tab === 'Activity log' && <ActivityList activities={data.activities} timezone={session.clinic.timezone} />}
            {tab === 'Follow-up' && <>
              {data.items.filter((item) => !item.resolved_at).map((item) => <div className="fact-row" key={item.id}>
                <Badge color="amber">{item.label}</Badge>
                <p>{item.detail}</p>
                <a className="text-link" href={`#/front-desk/work/${item.id}`}>Open follow-up →</a>
              </div>)}
              {!data.items.some((item) => !item.resolved_at) && <p className="empty">No open follow-up items.</p>}
              <details><summary>Resolved follow-up records</summary>
                {data.items.filter((item) => item.resolved_at).map((item) => <p key={item.id}>
                  <a className="text-link" href={`#/front-desk/work/${item.id}`}>{item.label}</a></p>)}
                {!data.items.some((item) => item.resolved_at) && <p className="empty">No resolved follow-up items.</p>}
              </details>
            </>}
          </section>
        </div>
      </div>
    </>}
  </main>
}

function Verification({ contact, field, session, onCancel, onSaved }: {
  contact: Contact; field: ContactField; session: Session; onCancel: () => void; onSaved: () => void
}) {
  const [value, setValue] = useState(contact.effective[field] ?? '')
  const [eventKey] = useState(() => crypto.randomUUID())
  const [pending, setPending] = useState(false)
  const [error, setError] = useState('')

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setPending(true)
    setError('')
    try {
      await api(`/contacts/${contact.id}`, mutation('PATCH', { field, value, event_key: eventKey }), session.token)
      onSaved()
    } catch (error) {
      setError(errorMessage(error))
    } finally { setPending(false) }
  }

  const inputType = field === 'birthdate' ? 'date' : field === 'email' ? 'email' : field === 'wireless_phone' ? 'tel' : 'text'
  return <form className="form-stack verify-form" onSubmit={save}>
    <label>Verify {fields[field].toLowerCase()}
      <input type={inputType} maxLength={254} value={value} onChange={(event) => setValue(event.target.value)} required />
    </label>
    <Status error={error} />
    <div className="button-row">
      <button className="button primary" disabled={pending}>{pending ? 'Saving…' : 'Save verification'}</button>
      <button type="button" className="button secondary" onClick={onCancel} disabled={pending}>Cancel</button>
    </div>
  </form>
}
