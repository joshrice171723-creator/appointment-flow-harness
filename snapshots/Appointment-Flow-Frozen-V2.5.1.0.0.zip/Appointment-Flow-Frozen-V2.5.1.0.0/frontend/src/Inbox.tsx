import { useState } from 'react'
import type { FormEvent } from 'react'
import { api, errorMessage, mutation, useResource } from './api'
import { timestamp } from './format'
import { Status, Tab, Tabs } from './shared'
import type { Clinic } from './types'

type DemoPatient = { id: number; name: string }
type Channel = 'sms' | 'email'
type Message = { id: number; direction: 'inbound' | 'outbound'; body: string; status: string; created_at: string }
type ConversationData = { messages: Message[]; can_reply: boolean }
const replyFeedback: Record<string, string> = {
  confirmed: 'Reply recorded. Your appointment is confirmed.',
  opted_out: 'Reply recorded. Text messages are stopped for this number at this clinic.',
  needs_review: 'Reply recorded. The front desk will review it.',
}

export function Inbox({ clinics, error }: { clinics: Clinic[]; error?: string }) {
  const [clinicId, setClinicId] = useState('')
  const clinic = clinics.find((item) => String(item.id) === clinicId)

  return <main className="container inbox">
    <a href="#/" className="back">← Workspaces</a>
    <div className="page-heading"><h1>Patient inbox</h1>
      <p>Messages and replies are simulated.</p></div>
    <Status error={error} />
    <label>Clinic<select value={clinicId} onChange={(event) => setClinicId(event.target.value)}>
      <option value="">Choose a clinic</option>
      {clinics.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}
    </select></label>
    {clinic && <PatientPicker key={clinic.id} clinic={clinic} />}
  </main>
}

function PatientPicker({ clinic }: { clinic: Clinic }) {
  const [patientId, setPatientId] = useState('')
  const path = `/clinics/${clinic.id}/patients`
  const { data, error } = useResource<DemoPatient[]>(path)
  return <>
    <label>Patient<select value={patientId} onChange={(event) => setPatientId(event.target.value)}>
      <option value="">Choose a patient</option>
      {data?.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}
    </select></label>
    <Status error={error} loading={!data && !error} />
    {patientId && <PatientInbox key={patientId} path={`${path}/${patientId}`} timezone={clinic.timezone} />}
  </>
}

function PatientInbox({ path, timezone }: { path: string; timezone: string }) {
  const [channel, setChannel] = useState<Channel>('sms')
  return <>
    <Tabs label="Message channel">
      <Tab active={channel === 'sms'} onClick={() => setChannel('sms')}>Text messages</Tab>
      <Tab active={channel === 'email'} onClick={() => setChannel('email')}>Email</Tab>
    </Tabs>
    <Conversation key={channel} path={path} channel={channel} timezone={timezone} />
  </>
}

function Conversation({ path, channel, timezone }: { path: string; channel: Channel; timezone: string }) {
  const [revision, setRevision] = useState(0)
  const [draft, setDraft] = useState('')
  const [replyTo, setReplyTo] = useState('')
  const [eventKey, setEventKey] = useState(() => crypto.randomUUID())
  const [pending, setPending] = useState(false)
  const [feedback, setFeedback] = useState('')
  const [saveError, setSaveError] = useState('')
  const { data, error } = useResource<ConversationData>(`${path}/messages?channel=${channel}`, undefined, revision)
  const sent = data?.messages.filter((message) => message.direction === 'outbound') ?? []
  const canReply = Boolean(data?.can_reply || replyTo)

  async function reply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setPending(true)
    setSaveError('')
    setFeedback('')
    try {
      const message = await api<Message>(`${path}/replies`, mutation('POST', {
        channel, body: draft, reply_to_id: replyTo || undefined, event_key: eventKey,
      }))
      setFeedback(replyFeedback[message.status] ?? 'Reply recorded.')
      setDraft('')
      setReplyTo('')
      setEventKey(crypto.randomUUID())
      setRevision((value) => value + 1)
    } catch (error) {
      setSaveError(`${errorMessage(error)} Your reply is still in the form.`)
    } finally { setPending(false) }
  }

  return <>
    <Status error={error} loading={!data && !error} />
    {feedback && <p className="notice" role="status">{feedback}</p>}
    {data && <>
      {data.messages.length ? <section className="conversation" aria-label="Message history">
        <h2>Message history</h2>
        <ol>{data.messages.map((message) => <li className={message.direction} key={message.id}>
          <span className="meta">{message.direction === 'outbound' ? 'Clinic reminder' : 'Your reply'} · {timestamp(message.created_at, timezone)}</span>
          <p className="message-body">{message.body}</p>
        </li>)}</ol>
      </section> : <p className="empty">No simulated {channel === 'sms' ? 'text messages' : 'emails'} for this patient yet.</p>}
      {(data.can_reply || sent.length > 0) && <form className="panel reply-form form-stack" onSubmit={reply}>
        {sent.length > 0 && <label>Reply to a reminder
          <select value={replyTo} onChange={(event) => setReplyTo(event.target.value)}>
            <option value="">No specific reminder</option>
            {sent.map((message) => <option key={message.id} value={message.id}>{timestamp(message.created_at, timezone)} · {message.body.slice(0, 65)}</option>)}
          </select>
        </label>}
        <label>Your reply<textarea placeholder="Type your reply" value={draft} onChange={(event) => setDraft(event.target.value)}
          rows={3} required maxLength={500} /></label>
        <Status error={saveError} />
        <button disabled={pending || !canReply || !draft.trim()} className="button primary">{pending ? 'Sending…' : 'Send reply'}</button>
      </form>}
    </>}
  </>
}
