export type Clinic = { id: number; name: string; timezone: string; staff: string[] }
export type Session = { clinic: Clinic; staff: string; token: string }
export type Sync = { last_synced_at: string | null; sync_error: string | null }

export type Visit = {
  id: number
  source_id: number
  contact_id: number
  patient: string
  revision: number
  local_date: string
  wall_start: string
  starts_at: string | null
  provider: string | null
  length_minutes: number | null
  state: string
  outcome: string
  source_status: string
  review?: boolean
}

export type Work = {
  id: number
  contact_id: number | null
  patient: string | null
  kind: string
  label: string
  detail: string
  visit_at: string | null
  assignee: string | null
  created_at: string
  resolved_at: string | null
}

export type Activity = {
  id: number
  staff: string
  action: string
  note: string
  created_at: string
  changes_recorded: { field?: string; prior?: string | null; value?: string; source?: string | null }
}

export type ContactField = 'birthdate' | 'wireless_phone' | 'email' | 'preferred_language'
export type Contact = Sync & {
  id: number
  name: string
  effective: Record<ContactField, string | null>
  source: Record<ContactField, string | null>
  verified: ContactField[]
  conflicts: ContactField[]
  visits: Visit[]
  items: Work[]
  activities: Activity[]
}
