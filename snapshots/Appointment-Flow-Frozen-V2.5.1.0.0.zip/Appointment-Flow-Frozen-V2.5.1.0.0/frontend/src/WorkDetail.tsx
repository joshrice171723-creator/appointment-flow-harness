import { useState } from 'react'
import type { FormEvent } from 'react'
import { api, errorMessage, mutation, useResource } from './api'
import { timestamp, title, wallLabel } from './format'
import { Badge, Status, SyncStatus } from './shared'
import type { Activity, Session, Sync, Visit, Work } from './types'

type Detail = Work & Sync & { candidates: Visit[]; activities: Activity[]; message: string | null }

export function ActivityList({ activities, timezone }: { activities: Activity[]; timezone: string }) {
  if (!activities.length) return <p className="empty">No recorded activity.</p>
  return <ol className="activity-list">{activities.map((activity) => <li key={activity.id}>
    <strong>{title(activity.action)} · {activity.staff}</strong>
    <small>{timestamp(activity.created_at, timezone)}</small>
    <p>{activity.note}</p>
    {activity.changes_recorded.field && <p className="meta">
      {title(activity.changes_recorded.field)} · {activity.changes_recorded.prior ?? 'No previous value'} → {activity.changes_recorded.value}
    </p>}
  </li>)}</ol>
}

export function WorkDetail({ id, session }: { id: string; session: Session }) {
  const [refresh, setRefresh] = useState(0)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [pending, setPending] = useState(false)
  const { data, error: loadError } = useResource<Detail>(`/work_items/${id}`, session.token, refresh)

  async function claim() {
    setPending(true)
    setError('')
    try {
      await api(`/work_items/${id}`, mutation('PATCH'), session.token)
      setRefresh((value) => value + 1)
    } catch (error) {
      setError(errorMessage(error))
    } finally { setPending(false) }
  }

  return <main className="container">
    <a className="back" href="#/front-desk">← Patient flow</a>
    <Status error={loadError} loading={!data && !loadError} />
    {data && <>
      <div className="page-heading heading-actions">
        <div><p className="eyebrow">{session.clinic.name}</p><h1>{data.patient ?? 'Reply to review'}</h1>
          <p>Patient follow-up · {data.resolved_at ? 'Resolved' : data.assignee ? 'In progress' : 'Needs attention'}</p></div>
        <div className="staff-tools"><span>Assigned to <strong>{data.assignee ?? 'Unassigned'}</strong></span>
          {!data.assignee && !data.resolved_at && <button className="button primary" type="button" onClick={claim} disabled={pending}>
            {pending ? 'Assigning…' : 'Assign to me'}
          </button>}
        </div>
      </div>
      <SyncStatus sync={data} timezone={session.clinic.timezone} />
      <Status error={error} />
      {success && <p className="notice" role="status">{success}</p>}
      <div className="details-grid">
        <aside className="panel details-card">
          <h2>Patient details</h2>
          <Badge color={data.kind === 'reply_review' ? 'red' : 'amber'}>{data.label}</Badge>
          <p>{data.detail}</p>
          {data.visit_at && <p><strong>{wallLabel(data.visit_at)}</strong></p>}
          {data.contact_id && <a className="text-link" href={`#/front-desk/patients/${data.contact_id}`}>Open patient details →</a>}
        </aside>
        <div className="details-content">
          {data.message && <section className="panel details-card"><h2>Patient reply</h2><p className="message-body">{data.message}</p></section>}
          {!data.resolved_at && <FollowUpForm item={data} session={session} onReload={() => setRefresh((value) => value + 1)} onSaved={() => {
            setSuccess('Follow-up recorded.')
            setRefresh((value) => value + 1)
          }} />}
          <section className="panel details-card"><h2>Follow-up history</h2>
            <ActivityList activities={data.activities} timezone={session.clinic.timezone} />
          </section>
        </div>
      </div>
    </>}
  </main>
}

function FollowUpForm({ item, session, onReload, onSaved }: {
  item: Detail; session: Session; onReload: () => void; onSaved: () => void
}) {
  const [action, setAction] = useState('attempted')
  const [note, setNote] = useState('')
  const [selection, setSelection] = useState(() => item.candidates.length === 1 ? [item.candidates[0].id] : [])
  const [eventKey] = useState(() => crypto.randomUUID())
  const [pending, setPending] = useState(false)
  const [error, setError] = useState('')
  const appointmentAction = ['confirmed', 'rescheduled', 'canceled'].includes(action)

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setPending(true)
    setError('')
    const selected = appointmentAction ? item.candidates.filter((visit) => selection.includes(visit.id)) : []
    const selections = Object.fromEntries(selected.map((visit) => [visit.id, visit.revision]))
    try {
      await api(`/work_items/${item.id}/follow_ups`, mutation('POST', {
        action_taken: action, note, selections, event_key: eventKey,
      }), session.token)
      onSaved()
    } catch (error) {
      setError(`${errorMessage(error)} Your draft is still here. If the connection dropped, retry the same update or check this record before changing it.`)
    } finally { setPending(false) }
  }

  return <form onSubmit={save} className="panel details-card form-stack">
    <h2>Record follow-up</h2>
    <label>Outcome<select value={action} onChange={(event) => setAction(event.target.value)}>
      <option value="attempted">Contact attempted</option>
      {item.candidates.length > 0 && <>
        <option value="confirmed">Confirmed by staff</option><option value="rescheduled">Rescheduled</option>
        <option value="canceled">Canceled</option>
      </>}
      {item.kind === 'reply_review' && <option value="clarified">Reply reviewed without an appointment change</option>}
    </select></label>
    {appointmentAction && <fieldset>
      <legend>Appointments verified with the patient</legend>
      {item.candidates.map((visit) => <label className="check-line" key={visit.id}>
        <input type="checkbox" checked={selection.includes(visit.id)}
          onChange={(event) => setSelection(event.target.checked ? [...selection, visit.id] : selection.filter((id) => id !== visit.id))} />
        {visit.patient} · {wallLabel(visit.wall_start)} · #{visit.source_id}
      </label>)}
    </fieldset>}
    <label>Note<textarea required maxLength={500} rows={4} value={note} onChange={(event) => setNote(event.target.value)} /></label>
    <Status error={error} />
    <div className="button-row">
      <button className="button primary" disabled={pending || (appointmentAction && selection.length === 0)}>
        {pending ? 'Saving…' : 'Save follow-up'}
      </button>
      {error && <button className="button secondary" type="button" disabled={pending} onClick={onReload}>Reload work item</button>}
    </div>
  </form>
}
