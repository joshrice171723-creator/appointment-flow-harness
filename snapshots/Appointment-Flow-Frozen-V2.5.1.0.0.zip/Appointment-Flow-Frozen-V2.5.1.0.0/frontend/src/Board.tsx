import { useState } from 'react'
import { api, errorMessage, mutation, useResource } from './api'
import { timestamp, wallLabel } from './format'
import { Badge, Status, SyncStatus, Tab, Tabs } from './shared'
import type { Session, Sync, Work } from './types'

type BoardResponse = Sync & { counts: Record<string, number>; items: Work[]; page: number; pages: number }

const columns = [
  { key: 'attention', label: 'Needs attention', empty: 'No unassigned work on this page.' },
  { key: 'progress', label: 'In progress', empty: 'No assigned work on this page.' },
  { key: 'resolved', label: 'Resolved', empty: 'No resolved work on this page.' },
]
const types = {
  no_reply: 'No confirmation', contact_hold: 'Contact hold', delivery_failed: 'Delivery failed',
  reply_review: 'Reply to review', visit_review: 'Appointment time needs review',
}

export function Board({ session }: { session: Session }) {
  const [status, setStatus] = useState('active')
  const [kind, setKind] = useState('')
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [revision, setRevision] = useState(0)
  const [running, setRunning] = useState(false)
  const [runMessage, setRunMessage] = useState('')
  const [runError, setRunError] = useState('')
  const query = new URLSearchParams({ status, kind, q: search, page: String(page) })
  const { data, error } = useResource<BoardResponse>(`/work_items?${query}`, session.token, revision)
  const openColumns = columns.filter(({ key }) => status === 'all' || (status === 'resolved' ? key === 'resolved' : key !== 'resolved'))

  async function runReminders() {
    setRunning(true)
    setRunMessage('')
    setRunError('')
    try {
      const result = await api<{ sent: number; failed: number }>('/reminder_runs', mutation('POST'), session.token)
      setRunMessage(`PMS refreshed. Fake reminders sent ${result.sent} · Failed ${result.failed}.`)
    } catch (error) {
      setRunError(errorMessage(error))
    } finally {
      setRunning(false)
      setRevision((value) => value + 1)
    }
  }

  return <main className="container">
    <div className="page-heading heading-actions">
      <div><p className="eyebrow">{session.clinic.name}</p><h1>Patient flow</h1>
        <p>Review confirmation requests and follow up on upcoming appointments.</p></div>
      <div className="staff-tools">
        <span>Signed in as <strong>{session.staff}</strong></span>
        <button className="button secondary" type="button" disabled={running} onClick={runReminders}>
          {running ? 'Refreshing…' : 'Run fake reminders'}
        </button>
      </div>
    </div>
    <SyncStatus sync={data} timezone={session.clinic.timezone} />
    <Status error={runError} />
    {runMessage && <p className="notice" role="status">{runMessage}</p>}
    <section className="summary-grid" aria-label="Work totals">
      {columns.map((column) => <div className="panel summary" key={column.key}>
        <strong>{data ? data.counts[column.key] ?? 0 : '—'}</strong><span>{column.label}</span>
      </div>)}
    </section>
    <div className="board-controls">
      <Tabs label="Work status">
        {['active', 'resolved', 'all'].map((value) => <Tab key={value} active={status === value} onClick={() => {
          setStatus(value); setPage(1)
        }}>{value === 'active' ? 'Active work' : value === 'resolved' ? 'Resolved' : 'All work'}</Tab>)}
      </Tabs>
      <div className="filter-fields">
        <label>Issue type<select value={kind} onChange={(event) => { setKind(event.target.value); setPage(1) }}>
          <option value="">All issue types</option>
          {Object.entries(types).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
        </select></label>
        <label>Find patient<input type="search" placeholder="Patient name" maxLength={100} value={search}
          onChange={(event) => { setSearch(event.target.value); setPage(1) }} /></label>
      </div>
    </div>
    <Status error={error} loading={!data && !error} />
    {data && <div className="board-grid">
      {openColumns.map((column) => {
        const items = data.items.filter((item) => column.key === (item.resolved_at ? 'resolved' : item.assignee ? 'progress' : 'attention'))
        return <section className="board-column" key={column.key}>
          <h2>{column.label} <span>{data.counts[column.key] ?? 0}</span></h2>
          {items.length === 0 && <p className="empty">{column.empty}</p>}
          {items.map((item) => <article className="panel work-card" key={item.id}>
            <Badge color={item.kind === 'reply_review' ? 'red' : item.kind === 'no_reply' ? 'neutral' : 'amber'}>{item.label}</Badge>
            <h3>{item.patient ?? 'Unmatched reply'}</h3>
            <p>{item.detail}</p>
            <p className="meta">{item.visit_at ? wallLabel(item.visit_at) : timestamp(item.created_at, session.clinic.timezone)}
              {item.assignee && ` · ${item.assignee}`}</p>
            <a className="text-link" href={`#/front-desk/work/${item.id}`}>Open follow-up <span aria-hidden="true">→</span></a>
          </article>)}
        </section>
      })}
    </div>}
    {data && data.pages > 1 && <div className="pagination">
      <button type="button" className="button secondary" disabled={data.page === 1} onClick={() => setPage(data.page - 1)}>Previous</button>
      <span>Page {data.page} of {data.pages}</span>
      <button type="button" className="button secondary" disabled={data.page === data.pages} onClick={() => setPage(data.page + 1)}>Next</button>
    </div>}
  </main>
}
