import { useState } from 'react'
import { useResource } from './api'
import { dayAt, title } from './format'
import { Status } from './shared'

type Outcomes = { month: string; total: number; completed: number; rescheduled: number; canceled: number; unknown: number }
type ClinicReport = {
  clinic: string
  outcomes: Outcomes
  history: Outcomes[]
  deliveries: { status: string; channel: string; count: number }[]
  contact_holds: Record<string, number>
  follow_ups: Record<string, number>
}
type Report = { month: string; clinics: ClinicReport[] }
const categories = ['completed', 'rescheduled', 'canceled', 'unknown'] as const

function rate(count: number, total: number) {
  return total ? `${(100 * count / total).toFixed(1)}%` : '—'
}

function monthLabel(month: string) {
  return new Date(`${month}-01T12:00:00Z`).toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })
}

export function Leadership() {
  const [month, setMonth] = useState(() => dayAt('America/Chicago').slice(0, 7))
  const { data, error } = useResource<Report>(`/reports?month=${encodeURIComponent(month)}`)

  return <main className="container leadership">
    <div className="page-heading heading-actions">
      <div><h1>Appointment outcomes</h1><p>Compare recorded visit outcomes and follow-up activity.</p></div>
      <label>Outcome month<input type="month" value={month} min="1900-01" max="2099-12"
        onChange={(event) => { if (/^\d{4}-\d{2}$/.test(event.target.value)) setMonth(event.target.value) }} /></label>
    </div>
    <Status error={error} loading={!data && !error} />
    {data && <>
      <section className="panel report-panel">
        <h2>{monthLabel(data.month)}</h2>
        <div className="outcome-grid">{data.clinics.map(({ clinic, outcomes }) => <article key={clinic}>
          <div className="spread"><h3>{clinic}</h3><span className="meta">{outcomes.total} recorded visits</span></div>
          <div className="outcome-bar" aria-hidden="true">
            {categories.map((category) => <span key={category} className={category}
              style={{ flexGrow: outcomes[category] }} />)}
          </div>
          <dl className="outcome-stats">{categories.map((category) => <div key={category}>
            <dt><i className={category} />{title(category)}</dt>
            <dd>{outcomes[category]} <small>{rate(outcomes[category], outcomes.total)}</small></dd>
          </div>)}</dl>
        </article>)}</div>
      </section>
      <section className="panel report-panel">
        <h2>Clinic comparison</h2>
        <div className="table-scroll"><table>
          <thead><tr><th>Clinic</th><th>Completion rate</th><th>Recorded visits</th><th>Completed</th><th>Rescheduled</th><th>Canceled</th><th>Unknown</th></tr></thead>
          <tbody>{data.clinics.map(({ clinic, outcomes }) => <tr key={clinic}>
            <td><strong>{clinic}</strong></td><td>{rate(outcomes.completed, outcomes.total)}</td><td>{outcomes.total}</td>
            {categories.map((category) => <td key={category}>{outcomes[category]}</td>)}
          </tr>)}</tbody>
        </table></div>
        <details><summary>How rates are calculated</summary>
          <p>Completion rate is completed visits divided by all recorded visits for the month. Scheduled visits and other unmapped statuses count as unknown. The PMS does not record a distinct no-show outcome.</p>
        </details>
      </section>
      <details className="panel report-panel"><summary>Monthly history and reminder activity</summary>
        <div className="table-scroll"><table>
          <thead><tr><th>Clinic</th><th>Month</th><th>Recorded visits</th><th>Completed</th><th>Completion rate</th></tr></thead>
          <tbody>{data.clinics.flatMap(({ clinic, history }) => history.map((row) => <tr key={`${clinic}-${row.month}`}>
            <td>{clinic}</td><td>{monthLabel(row.month)}</td><td>{row.total}</td><td>{row.completed}</td><td>{rate(row.completed, row.total)}</td>
          </tr>))}</tbody>
        </table></div>
        <h3>Fake delivery attempts this month</h3>
        {data.clinics.map(({ clinic, deliveries }) => <p key={clinic}><strong>{clinic}</strong> · {deliveries.length ?
          deliveries.map(({ status, channel, count }) => `${count} ${channel.toUpperCase()} ${status}`).join(' · ') : 'No attempts'}</p>)}
      </details>
      <details className="panel report-panel"><summary>Contact holds</summary>
        <p>Holds opened during the reporting month, grouped by current status.</p>
        {data.clinics.map(({ clinic, contact_holds: holds }) => <p key={clinic}><strong>{clinic}</strong> · {holds.false ?? 0} open · {holds.true ?? 0} resolved</p>)}
      </details>
      <details className="panel report-panel"><summary>Contact and follow-up</summary>
        <p>Staff actions recorded during the reporting month.</p>
        {data.clinics.map(({ clinic, follow_ups }) => <p key={clinic}><strong>{clinic}</strong> · {Object.keys(follow_ups).length ?
          Object.entries(follow_ups).map(([action, count]) => `${title(action)} ${count}`).join(' · ') : 'No actions recorded'}</p>)}
      </details>
    </>}
  </main>
}
