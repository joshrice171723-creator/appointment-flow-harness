import { useEffect, useState } from 'react'

export async function api<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(token ? { 'X-Demo-Session': token } : {}),
    },
  })
  if (!response.ok) {
    const body: unknown = await response.json().catch(() => null)
    if (body && typeof body === 'object' && 'error' in body && typeof body.error === 'string') {
      throw new Error(body.error)
    }
    throw new Error('The server could not complete the request.')
  }
  return response.json()
}

type Resource<T> = { data?: T; error?: string }

export function useResource<T>(path: string, token?: string, revision = 0): Resource<T> {
  const key = JSON.stringify([path, token, revision])
  const [result, setResult] = useState<{ key: string; value: Resource<T> }>()

  useEffect(() => {
    if (!path) return
    const request = new AbortController()
    api<T>(path, { signal: request.signal }, token).then(
      (data) => { if (!request.signal.aborted) setResult({ key, value: { data } }) },
      (error: unknown) => {
        if (!request.signal.aborted) setResult({ key, value: { error: errorMessage(error) } })
      },
    )
    return () => request.abort()
  }, [key, path, token])

  return result?.key === key ? result.value : {}
}

export function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'The request could not be completed.'
}

export function mutation(method: 'POST' | 'PATCH', body: object = {}): RequestInit {
  return { method, body: JSON.stringify(body) }
}
