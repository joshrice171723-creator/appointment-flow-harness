import type { ReactNode } from 'react'
import { timestamp } from './format'
import type { Sync } from './types'

export function Status({ error, loading }: { error?: string; loading?: boolean }) {
  if (error) return <p className="notice error" role="alert">{error}</p>
  if (loading) return <p className="notice" role="status">Loading…</p>
  return null
}

export function SyncStatus({ sync, timezone }: { sync?: Sync; timezone: string }) {
  if (!sync) return null
  return <>
    <p className="meta">Last PMS sync {sync.last_synced_at ? timestamp(sync.last_synced_at, timezone) : 'pending'} · {timezone}</p>
    <Status error={sync.sync_error ?? undefined} />
  </>
}

export function Tabs({ label, children }: { label: string; children: ReactNode }) {
  return <div className="tabs" role="group" aria-label={label}>{children}</div>
}

export function Tab({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return <button type="button" aria-pressed={active} onClick={onClick}>{children}</button>
}

export function Badge({ children, color = 'green' }: { children: ReactNode; color?: 'green' | 'amber' | 'red' | 'neutral' }) {
  return <span className={`badge ${color}`}>{children}</span>
}
