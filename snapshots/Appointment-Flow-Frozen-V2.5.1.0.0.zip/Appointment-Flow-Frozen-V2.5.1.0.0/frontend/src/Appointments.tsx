import { useState } from 'react'
import { useResource } from './api'
import { dateLabel, dayAt, offsetDay, title, wallLabel } from './format'
import { Badge, Status, SyncStatus, Tab, Tabs } from './shared'
import type { Session, Sync, Visit } from './types'

type AppointmentResponse = Sync & { date: string; today: string; visits: Visit[]; week_counts: Record<string, number> }
const filters = { all: 'All appointments', confirmed: 'Confirmed', unconfirmed: 'Unconfirmed', review: 'Replies to review' }
type Filter = keyof typeof filters

function matches(visit: Visit, filter: Filter) {
  if (filter === 'all') return true
  if (filter === 'review') return visit.review
  return visit.state === filter
}

export function VisitTable({ visits }: { visits: Visit[] }) {
  if (!visits.length) return <p className="empty">No appointments match this view.</p>
  return <div className="table-scroll"><table>
    <thead><tr><th>Patient</th><th>Appointment</th><th>Confirmation or reply</th><th>Visit outcome</th><th>Next step</th></tr></thead>
    <tbody>{visits.map((visit) => <tr key={visit.id}>
      <td><strong>{visit.patient}</strong><small>Appointment #{visit.source_id}</small></td>
      <td><strong>{wallLabel(visit.wall_start)}</strong><small>{visit.provider ?? 'Provider unavailable'}
        {visit.length_minutes ? ` · ${visit.length_minutes} min` : ''}</small></td>
      <td><Badge color={visit.state === 'confirmed' ? 'green' : 'neutral'}>{title(visit.state)}</Badge>
        {visit.review && <small>Reply to review</small>}
        {!visit.starts_at && <small>Appointment time needs review</small>}</td>
      <td>{visit.outcome}</td>
      <td><a className="text-link" href={`#/front-desk/patients/${visit.contact_id}`}>Patient details <span aria-hidden="true">→</span></a></td>
    </tr>)}</tbody>
  </table></div>
}

export function Appointments({ session }: { session: Session }) {
  const today = dayAt(session.clinic.timezone)
  const [date, setDate] = useState(today)
  const [filter, setFilter] = useState<Filter>('all')
  const { data, error } = useResource<AppointmentResponse>(`/appointments?date=${encodeURIComponent(date)}`, session.token)
  const weekday = new Date(`${date}T12:00:00Z`).getUTCDay()
  const monday = offsetDay(date, -((weekday + 6) % 7))
  const days = Array.from({ length: 7 }, (_, index) => offsetDay(monday, index))
  const visits = data?.visits.filter((visit) => matches(visit, filter)) ?? []

  return <main className="container">
    <div className="page-heading heading-actions">
      <div><p className="eyebrow">{session.clinic.name}</p><h1>Appointments</h1>
        <p>Browse the clinic schedule, confirmation status and recorded outcomes.</p></div>
      <a className="button secondary" href="#/front-desk">Open patient flow <span aria-hidden="true">→</span></a>
    </div>
    <SyncStatus sync={data} timezone={session.clinic.timezone} />
    <section className="panel calendar" aria-label="Appointment calendar">
      <div className="calendar-controls">
        <div className="calendar-buttons">
          <button className="button secondary" type="button" onClick={() => setDate(offsetDay(date, -7))}>← Previous week</button>
          <button className="button secondary" type="button" onClick={() => setDate(today)}>Today</button>
          <button className="button secondary" type="button" onClick={() => setDate(offsetDay(date, 7))}>Next week →</button>
        </div>
        <label>Jump to date<input type="date" value={date} min="1900-01-01" max="9999-12-31"
          onChange={(event) => { if (/^\d{4}-\d{2}-\d{2}$/.test(event.target.value)) setDate(event.target.value) }} /></label>
      </div>
      <div className="week-grid">
        {days.map((day) => <button type="button" className="date-chip" key={day} aria-pressed={day === date} onClick={() => setDate(day)}>
          <strong>{dateLabel(day, { weekday: 'short', month: 'short', day: 'numeric' })}</strong>
          <span>{data ? `${data.week_counts[day] ?? 0} visits` : '—'}</span>
        </button>)}
      </div>
    </section>
    <Tabs label="Appointment status">{(Object.keys(filters) as Filter[]).map((key) => <Tab key={key} active={filter === key}
      onClick={() => setFilter(key)}>{filters[key]}{data && <span className="tab-count">{data.visits.filter((visit) => matches(visit, key)).length}</span>}</Tab>)}</Tabs>
    <Status error={error} loading={!data && !error} />
    {data && <section className="panel table-panel" aria-label="Appointments for selected day"><VisitTable visits={visits} /></section>}
  </main>
}
