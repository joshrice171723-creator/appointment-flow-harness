import { cleanup, fireEvent, render, screen, within } from '@testing-library/react'
import { afterEach, expect, test, vi } from 'vitest'
import { App } from './App'
import { WorkDetail } from './WorkDetail'
import type { Clinic } from './types'

const austin: Clinic = { id: 1, name: 'Austin', timezone: 'America/Chicago', staff: ['Taylor Morgan'] }
const phoenix: Clinic = { id: 2, name: 'Phoenix', timezone: 'America/Phoenix', staff: ['Alex Bennett'] }

function json(body: unknown, status = 200) {
  return Promise.resolve(new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } }))
}

afterEach(() => {
  cleanup()
  vi.unstubAllGlobals()
  window.history.replaceState(null, '', '/')
})

test('opens the selected staff workspace and uses its session for board requests', async () => {
  const request = vi.fn((path: string, options?: RequestInit) => {
    if (path === '/api/clinics') return json([austin, phoenix])
    if (path === '/api/demo_sessions') {
      expect(JSON.parse(String(options?.body))).toEqual({ clinic_id: 2, staff: 'Alex Bennett' })
      return json({ token: 'phoenix-session' }, 201)
    }
    expect(new Headers(options?.headers).get('X-Demo-Session')).toBe('phoenix-session')
    return json({ counts: { attention: 0 }, items: [], pages: 1, page: 1, last_synced_at: null, sync_error: null })
  })
  vi.stubGlobal('fetch', request)
  render(<App />)
  await screen.findByRole('option', { name: 'Phoenix' })
  fireEvent.change(screen.getByLabelText('Clinic'), { target: { value: 2 } })
  fireEvent.click(screen.getByRole('button', { name: 'Open front desk' }))
  await screen.findByRole('heading', { name: 'Patient flow' })
  await screen.findByText('No unassigned work on this page.')
  expect(screen.getByText('Alex Bennett')).toBeTruthy()
})

test('exposes the email empty state and sends a typed demo reply on that channel', async () => {
  window.history.replaceState(null, '', '/#/inbox')
  const request = vi.fn((path: string, options?: RequestInit) => {
    if (path === '/api/clinics') return json([austin])
    if (path.endsWith('/patients')) return json([{ id: 8, name: 'Fictional Patient' }])
    if (path.endsWith('/replies')) {
      expect(JSON.parse(String(options?.body))).toMatchObject({ body: 'YES', channel: 'email' })
      return json({ id: 1, status: 'needs_review' }, 201)
    }
    return json({ messages: [], can_reply: true })
  })
  vi.stubGlobal('fetch', request)
  render(<App />)
  await screen.findByRole('option', { name: 'Austin' })
  fireEvent.change(screen.getByLabelText('Clinic'), { target: { value: 1 } })
  await screen.findByRole('option', { name: 'Fictional Patient' })
  fireEvent.change(screen.getByLabelText('Patient'), { target: { value: 8 } })
  await screen.findByText('No simulated text messages for this patient yet.')
  fireEvent.click(screen.getByRole('button', { name: 'Email' }))
  await screen.findByText('No simulated emails for this patient yet.')
  fireEvent.change(screen.getByLabelText('Your reply'), { target: { value: 'YES' } })
  fireEvent.click(screen.getByRole('button', { name: 'Send reply' }))
  await screen.findByText('Reply recorded. The front desk will review it.')
})

test('keeps the follow-up draft after uncertain failure and retries only on request with the same key', async () => {
  let submissions = 0
  let firstKey: string
  const request = vi.fn((path: string, options?: RequestInit) => {
    if (path.endsWith('/follow_ups')) {
      const payload = JSON.parse(String(options?.body))
      expect(payload.note).toBe('Called the patient.')
      submissions += 1
      if (submissions === 1) {
        firstKey = payload.event_key
        return Promise.reject(new Error('Connection dropped.'))
      }
      expect(payload.event_key).toBe(firstKey)
      return json({ id: 1 }, 201)
    }
    return json({
      id: 5, patient: 'Fictional Patient', contact_id: 9, kind: 'no_reply', label: 'No confirmation',
      detail: 'Call this patient.', visit_at: null, assignee: 'Taylor Morgan', resolved_at: null,
      activities: [], candidates: [], last_synced_at: null, sync_error: null,
    })
  })
  vi.stubGlobal('fetch', request)
  render(<WorkDetail id="5" session={{ clinic: austin, staff: 'Taylor Morgan', token: 'austin-session' }} />)
  const note = await screen.findByLabelText<HTMLTextAreaElement>('Note')
  fireEvent.change(note, { target: { value: 'Called the patient.' } })
  fireEvent.click(screen.getByRole('button', { name: 'Save follow-up' }))
  expect(within(await screen.findByRole('alert')).getByText(/Your draft is still here/)).toBeTruthy()
  expect(note.value).toBe('Called the patient.')
  expect(submissions).toBe(1)
  fireEvent.click(screen.getByRole('button', { name: 'Save follow-up' }))
  await screen.findByText('Follow-up recorded.')
  expect(submissions).toBe(2)
})
