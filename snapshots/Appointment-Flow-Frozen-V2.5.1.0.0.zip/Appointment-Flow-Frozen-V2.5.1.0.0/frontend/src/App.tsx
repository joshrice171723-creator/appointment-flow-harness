import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { api, errorMessage, mutation, useResource } from './api'
import { Appointments } from './Appointments'
import { Board } from './Board'
import { Inbox } from './Inbox'
import { Leadership } from './Leadership'
import { Patient } from './Patient'
import { WorkDetail } from './WorkDetail'
import { Status } from './shared'
import type { Clinic, Session } from './types'

function currentRoute() {
  return window.location.hash.slice(1) || '/'
}

export function App() {
  const [route, setRoute] = useState(currentRoute)
  const [session, setSession] = useState<Session>()
  const clinics = useResource<Clinic[]>('/clinics')

  useEffect(() => {
    const followHash = () => setRoute(currentRoute())
    window.addEventListener('hashchange', followHash)
    return () => window.removeEventListener('hashchange', followHash)
  }, [])

  const desk = route.startsWith('/front-desk')
  const patientRoute = route.match(/^\/front-desk\/patients\/(\d+)$/)
  const workRoute = route.match(/^\/front-desk\/work\/(\d+)$/)
  let screen
  if (route === '/leadership') screen = <Leadership />
  else if (route === '/inbox') screen = <Inbox clinics={clinics.data ?? []} error={clinics.error} />
  else if (desk && session) {
    if (patientRoute) screen = <Patient key={route} id={patientRoute[1]} session={session} />
    else if (workRoute) screen = <WorkDetail key={route} id={workRoute[1]} session={session} />
    else if (route === '/front-desk/appointments') screen = <Appointments key={session.token} session={session} />
    else screen = <Board key={session.token} session={session} />
  } else screen = <Workspaces key={route} clinics={clinics.data} loadError={clinics.error} onOpen={setSession} />

  return <>
    <header className="topbar">
      <a className="brand" href="#/" aria-label="Apex workspaces">
        <span className="brand-symbol" aria-hidden="true">A<span>+</span></span>
        <span><strong>APEX</strong><small>APPOINTMENT FLOW</small></span>
      </a>
      <nav aria-label="Main navigation">
        {desk && session && <>
          <a href="#/front-desk" aria-current={route === '/front-desk' ? 'page' : undefined}>Patient flow</a>
          <a href="#/front-desk/appointments" aria-current={route.endsWith('/appointments') ? 'page' : undefined}>Appointments</a>
        </>}
        {route === '/leadership' && <a href="#/leadership" aria-current="page">Apex leadership</a>}
        {route === '/inbox' && <a href="#/inbox" aria-current="page">Patient inbox</a>}
        <a href="#/">Workspaces <span aria-hidden="true">↗</span></a>
      </nav>
    </header>
    {screen}
  </>
}

function Workspaces({ clinics, loadError, onOpen }: {
  clinics?: Clinic[]; loadError?: string; onOpen: (session: Session) => void
}) {
  const [clinicId, setClinicId] = useState<number>()
  const [staff, setStaff] = useState('')
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)
  const clinic = clinics?.find((candidate) => candidate.id === clinicId) ?? clinics?.[0]
  const selectedStaff = clinic?.staff.includes(staff) ? staff : clinic?.staff[0] ?? ''

  async function openDesk(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!clinic || !selectedStaff) return
    setError('')
    setPending(true)
    try {
      const { token } = await api<{ token: string }>('/demo_sessions', mutation('POST', { clinic_id: clinic.id, staff: selectedStaff }))
      onOpen({ clinic, staff: selectedStaff, token })
      window.location.hash = '/front-desk'
    } catch (error) {
      setError(errorMessage(error))
    } finally {
      setPending(false)
    }
  }

  return <main className="container launch">
    <div className="page-heading">
      <h1>Workspaces</h1>
    </div>
    <Status error={loadError} loading={!clinics && !loadError} />
    <div className="workspace-grid">
      <form className="panel workspace-card" onSubmit={openDesk}>
        <h2>Front desk</h2>
        <p>Review appointments and follow up with patients.</p>
        <label>Clinic
          <select value={clinic?.id ?? ''} onChange={(event) => { setClinicId(Number(event.target.value)); setStaff('') }}>
            {clinics?.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}
          </select>
        </label>
        <label>Staff member
          <select value={selectedStaff} onChange={(event) => setStaff(event.target.value)}>
            {clinic?.staff.map((option) => <option key={option}>{option}</option>)}
          </select>
        </label>
        <Status error={error} />
        <button className="button primary spread" disabled={!clinic || pending}>
          {pending ? 'Opening…' : 'Open front desk'} <span aria-hidden="true">→</span>
        </button>
      </form>
      <section className="panel workspace-card leadership-card">
        <h2>Apex leadership</h2>
        <p>Compare appointment outcomes across clinics.</p>
        {clinics && <div className="clinic-figure"><strong>{clinics.length}</strong><span>{clinics.length === 1 ? 'Clinic' : 'Clinics'}</span></div>}
        <a className="button primary spread" href="#/leadership">Open Apex leadership <span aria-hidden="true">→</span></a>
      </section>
      <section className="panel workspace-card">
        <h2>Patient demo</h2>
        <p>Read simulated texts and emails and send a test reply.</p>
        <a className="button primary spread" href="#/inbox">Open patient inbox <span aria-hidden="true">→</span></a>
      </section>
    </div>
  </main>
}
