import react from '@vitejs/plugin-react'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  base: process.env.APEX_UI_BASE ?? '/',
  plugins: [react()],
  server: { proxy: { '/api': process.env.APEX_RAILS_URL ?? 'http://127.0.0.1:3000' } },
  test: { environment: 'jsdom' },
})
