# Rebuild log

## Harness and scope

Preflight passed before application code. The SHA-256 manifest covered 53 inputs, including all 10 PNGs. The Email screenshot showed a selected patient and an empty email inbox. The written requirements supplied the reply behavior. The packaged inputs remain intact so the same verification runs after implementation.

## Source, reminders and confirmation

B02–B05 and scenarios S01–S09, S12–S15 informed the PostgreSQL replica and the Rails workflow. The design uses a scoped source refresh, a clinic transaction, version-bound attempts and replies, and a fake delivery adapter. A manual Rails task provides cadence execution without an additional runtime component. The test suite exercised both channels, reschedules, retries and concurrency, STOP, permission holds, shared addresses, rollback, and clinic-local windows and DST.

## Workspaces and operations

B01 and B06–B11 and scenarios S10–S11 and S16–S20 informed the React workspaces. Each staff request looks up records through the signed clinic selection. Leadership reads aggregate counts, and the inbox submits to the same inbound workflow as the domain tests. Rails integration tests covered the API paths. React tests covered clinic selection, an email reply, and retaining a draft when the network result was uncertain.

## Independent review

The first review identified three reproducible defects. The repair checked source address ownership outside the appointment projection, included historical reminder versions in ambiguity detection, and retained successful source refreshes before returning stale follow-up rejections. Regression tests cover all three. The independent reviewer gave a Ready verdict on the repaired paths. See [freeze results](../review/REBUILD_FREEZE.md) for the executed checks and workload measurements.
