require "test_helper"
require_relative "../../db/demo_seed"

class ClinicTest < ActionDispatch::IntegrationTest
  setup { DemoSeed.call }

  test "S10 backend rejects cross-clinic changes" do
    foreign = Clinic.find(2).visits.first
    patch "/api/clinics/1/visits/#{foreign.id}", params: { staff: "Taylor", outcome: "assign" }, as: :json
    assert_response :not_found
    assert_nil foreign.reload.owner
    get "/api/clinics/1/visits"
    assert_response :success
    assert response.parsed_body["visits"].all? { |v| v["clinic_id"] == 1 }
  end

  test "S17 leadership response allows only aggregate keys" do
    get "/api/leadership", params: { month: Date.current.strftime("%Y-%m") }
    assert_response :success
    response.parsed_body.each do |row|
      assert_equal %w[canceled clinic completed confirmed holds messages rescheduled total unknown], row.keys.sort
      assert_equal row["total"], row.values_at("completed", "canceled", "rescheduled", "unknown").sum
    end
    assert_not_includes response.body, "@example.test"
    assert_not_includes response.body, "Patient"
  end

  test "S19 invalid follow-up preserves existing state and requires ownership" do
    visit = Clinic.first.visits.first
    patch "/api/clinics/1/visits/#{visit.id}", params: { staff: "Taylor", outcome: "confirmed", note: "Called", version: visit.version }, as: :json
    assert_response :unprocessable_entity
    patch "/api/clinics/1/visits/#{visit.id}", params: { staff: "Taylor", outcome: "assign" }, as: :json
    assert_response :success
    patch "/api/clinics/1/visits/#{visit.id}", params: { staff: "Taylor", outcome: "attempted", note: " " }, as: :json
    assert_response :unprocessable_entity
    assert_empty visit.activities
    patch "/api/clinics/1/visits/#{visit.id}", params: { staff: "Taylor", outcome: "attempted", note: "Left callback request" }, as: :json
    assert_response :success
    assert_equal "Taylor", visit.reload.owner
    assert_equal 1, visit.activities.count
  end

  test "local verification leaves raw PMS unchanged and cannot reset STOP" do
    visit = Clinic.first.visits.first
    before = PmsAppointment.snapshot(1)
    visit.contact.update!(sms_stopped: true)
    patch "/api/clinics/1/visits/#{visit.id}/contact", params: { staff: "Taylor", details: { sms: "5125550177", email: "corrected@example.test", birthdate: "1990-01-01", language: "en" }, sms_allowed: true, email_allowed: true, adult_authorized: true }, as: :json
    assert_response :success
    assert_equal before, PmsAppointment.snapshot(1)
    assert visit.contact.reload.sms_stopped
    assert_equal "5125550177", visit.contact.verified["sms"]
  end

  test "S20 email simulator and staff API share confirmation state" do
    visit = Clinic.first.visits.find_by!(source_id: 104)
    post "/api/clinics/1/replies", params: { visit_id: visit.id, channel: "email", body: "YES", event_id: "email-demo" }, as: :json
    assert_response :success
    assert_equal "Confirmed", response.parsed_body["message"]
    assert_equal "confirmed", visit.reload.confirmation
  end
end
