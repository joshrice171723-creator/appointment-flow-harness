require "test_helper"

class WorkflowTest < ActiveSupport::TestCase
  setup do
    @now = Time.utc(2026, 11, 15, 18)
    @clinic = Clinic.create!(id: 1, name: "Austin", timezone: "America/Chicago")
    Clinic.create!(id: 2, name: "Phoenix", timezone: "America/Phoenix")
    sql("INSERT INTO pms.clinics(id,name) VALUES(1,'Austin'),(2,'Phoenix')")
    sql("INSERT INTO pms.patients(id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES(1,'Demo','One','1990-01-01','5125550101','one@example.test','en'),(2,'Demo','Two','1990-01-01','6025550102','two@example.test','en')")
    sql("INSERT INTO pms.appointments(id,patient_id,clinic_id,start_at,status) VALUES(1,1,1,'2026-11-22 15:00:00','scheduled'),(2,2,2,'2026-11-22 15:00:00','scheduled')")
    SourceRefresh.call(@clinic, now: @now)
    @visit = @clinic.visits.first
  end

  def sql(statement) = ActiveRecord::Base.connection.execute(statement)
  def batch(now = @now) = ReminderBatch.call(@clinic, now: now)
  def reply(body, channel: "sms", event: SecureRandom.uuid, now: @now)
    InboundReply.call(@clinic, event_id: event, sender: channel == "sms" ? "5125550101" : "one@example.test", channel: channel, body: body, now: now)
  end

  test "S01 clear YES confirms and subsequent requests stop" do
    batch
    assert_equal "Confirmed", reply("YES").result
    batch
    assert_equal "confirmed", @visit.reload.confirmation
    assert_equal 1, Message.count
    assert_equal "scheduled", @visit.source_status
  end

  test "S02 email only uses same matching" do
    sql("UPDATE pms.patients SET wireless_phone=NULL WHERE id=1")
    batch
    assert_equal "email", Message.first.channel
    assert_equal "Confirmed", reply("yes", channel: "email").result
  end

  test "S03 reschedule invalidates confirmation and rejects old YES" do
    batch
    reply("YES")
    sql("UPDATE pms.appointments SET start_at='2026-11-23 16:00:00' WHERE id=1")
    SourceRefresh.call(@clinic, now: @now)
    assert_equal "unconfirmed", @visit.reload.confirmation
    assert_equal "Needs staff review", reply("YES").result
  end

  test "S04 broken visit stops and recreated appointment is independent" do
    batch
    sql("UPDATE pms.appointments SET status='broken' WHERE id=1")
    sql("INSERT INTO pms.appointments(id,patient_id,clinic_id,start_at,status) VALUES(3,1,1,'2026-11-23 15:00:00','scheduled')")
    batch
    assert_equal 1, @visit.messages.count
    assert_equal "unconfirmed", @clinic.visits.find_by!(source_id: 3).confirmation
  end

  test "S05 failed attempt is retained with one backup email" do
    sql("UPDATE pms.patients SET wireless_phone='5125550199' WHERE id=1")
    batch
    batch
    assert_equal [ "failed", "sent" ], Message.order(:id).pluck(:delivery)
    assert_equal [ "sms", "email" ], Message.order(:id).pluck(:channel)
  end

  test "S06 replayed event has one effect" do
    batch
    first = reply("YES", event: "same")
    assert_equal first.id, reply("YES", event: "same").id
    assert_equal 1, Reply.count
  end

  test "S07 NO after YES preserves confirmation and asks staff" do
    batch
    reply("YES")
    reply("NO")
    assert_equal "confirmed", @visit.reload.confirmation
    assert_equal "Reply needs review", @visit.issue
  end

  test "S08 late YES never retroactively confirms" do
    batch
    assert_equal "Needs staff review", reply("YES", now: @now + 8.days).result
    assert_equal "unconfirmed", @visit.reload.confirmation
  end

  test "S09 STOP survives source refresh and local repermission" do
    batch
    reply("stop")
    @visit.contact.update!(sms_allowed: true)
    SourceRefresh.call(@clinic, now: @now)
    assert @visit.contact.sms_stopped
    assert_nil @visit.contact.recipient(@visit.reload.source_contact, "sms")
  end

  test "S11 overdue confirmation becomes staff work" do
    batch(@now + 5.days)
    assert_equal "No confirmation within 48 hours", @visit.reload.issue
  end

  test "S12 shared number prevents automatic confirmation" do
    sql("INSERT INTO pms.appointments(id,patient_id,clinic_id,start_at,status) VALUES(3,2,1,'2026-11-22 16:00:00','scheduled')")
    sql("UPDATE pms.patients SET wireless_phone='5125550101' WHERE id=2")
    batch
    assert_equal "Needs staff review", reply("YES").result
    assert_equal 0, Visit.where(confirmation: "confirmed").count
  end

  test "S13 unsafe minor and unsupported language cannot send" do
    sql("UPDATE pms.patients SET birthdate='2015-01-01' WHERE id=1")
    batch
    assert_empty Message.all
    assert_match "adult", @visit.reload.issue
    @visit.contact.update!(adult_authorized: true)
    batch
    assert_equal 1, Message.count
    sql("UPDATE pms.patients SET preferred_language='fr' WHERE id=1")
    batch(@now + 4.days)
    assert_equal 1, Message.count
  end

  test "S14 empty source blocks sends and preserves snapshot" do
    sql("DELETE FROM pms.appointments WHERE clinic_id=1")
    assert_not batch
    assert_equal 1, @clinic.visits.count
    assert_empty Message.all
    assert @clinic.reload.sync_error
  end

  test "S15 repeated batch deduplicates and sending window applies" do
    3.times { batch }
    assert_equal 1, Message.count
    batch(Time.utc(2026, 11, 19, 3))
    assert_equal 1, Message.count
  end

  test "no messages at or after start and no burst of missed steps" do
    batch(@now + 6.days)
    assert_equal 1, Message.count
    batch(@now + 8.days)
    assert_equal 1, Message.count
  end

  test "DST gap and fold are held while Phoenix is unambiguous" do
    assert_nil SourceRefresh.wall_instant("2026-03-08 02:30:00", "America/Chicago")
    assert_nil SourceRefresh.wall_instant("2026-11-01 01:30:00", "America/Chicago")
    assert_equal Time.utc(2026, 11, 1, 8, 30), SourceRefresh.wall_instant("2026-11-01 01:30:00", "America/Phoenix")
  end

  test "verification conflict blocks changed source contacts" do
    c = @visit.contact
    c.update!(verified: @visit.source_contact, source_at_verification: @visit.source_contact)
    sql("UPDATE pms.patients SET wireless_phone='5125550190' WHERE id=1")
    batch
    assert_empty Message.all
    assert_match "changed", @visit.reload.issue
  end

  test "PMS runtime model rejects writes and messages omit procedure" do
    assert_raises(ActiveRecord::ReadOnlyRecord) { PmsAppointment.first.update!(status: "complete") }
    sql("UPDATE pms.appointments SET procedure_note='SECRET PROCEDURE' WHERE id=1")
    batch
    assert_not_includes Message.first.body, "SECRET"
  end

  test "old recipient cannot confirm after contact changes" do
    batch
    sql("UPDATE pms.patients SET wireless_phone='5125550190' WHERE id=1")
    SourceRefresh.call(@clinic, now: @now)
    assert_equal "Needs staff review", reply("YES").result
    assert_equal "unconfirmed", @visit.reload.confirmation
  end

  test "unsolicited reply from known contact creates staff work without confirming" do
    assert_equal "Needs staff review", reply("YES").result
    assert_equal "Reply needs review", @visit.reload.issue
    assert_equal [ @visit.id ], Reply.last.candidate_ids
    assert_equal "unconfirmed", @visit.confirmation
  end
end
