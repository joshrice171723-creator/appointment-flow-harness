require "test_helper"
require_relative "../../db/demo_seed"

class ConcurrencyTest < ActiveSupport::TestCase
  self.use_transactional_tests = false

  test "S15 concurrent batches have unique logical sends" do
    DemoSeed.call
    Message.delete_all
    now = Time.find_zone!("America/Chicago").local(Date.current.year, Date.current.month, Date.current.day, 12)
    threads = 3.times.map do
      Thread.new do
        ActiveRecord::Base.connection_pool.with_connection { ReminderBatch.call(Clinic.find(1), now: now) }
      end
    end
    assert threads.map(&:value).all?
    assert_equal Message.count, Message.distinct.count(:id)
    assert_equal 0, Message.group(:visit_id, :version, :step).having("COUNT(*) > 1").count.size
    assert Message.count.positive?
  ensure
    ActiveRecord::Base.connection.execute("TRUNCATE activities, replies, messages, contacts, visits, clinics, pms.appointments, pms.patients, pms.clinics RESTART IDENTITY CASCADE")
  end
end
