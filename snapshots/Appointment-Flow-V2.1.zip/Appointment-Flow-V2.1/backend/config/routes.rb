Rails.application.routes.draw do
  get "/api/clinics", to: "workflow#clinics"
  get "/api/leadership", to: "workflow#leadership"
  get "/api/clinics/:clinic_id/visits", to: "workflow#index"
  post "/api/clinics/:clinic_id/refresh", to: "workflow#refresh"
  post "/api/clinics/:clinic_id/batch", to: "workflow#batch"
  post "/api/clinics/:clinic_id/replies", to: "workflow#reply"
  patch "/api/clinics/:clinic_id/visits/:id", to: "workflow#update"
  patch "/api/clinics/:clinic_id/visits/:id/contact", to: "workflow#contact"
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
end
