class WorkflowController < ApplicationController
  before_action :select_clinic, except: [ :clinics, :leadership ]
  rescue_from ActiveRecord::RecordNotFound, with: -> { render json: { error: "Record not found in selected clinic" }, status: :not_found }
  rescue_from ArgumentError, ActionController::ParameterMissing, with: ->(e) { render json: { error: e.message }, status: :unprocessable_entity }

  def clinics
    render json: Clinic.order(:id).as_json(only: [ :id, :name, :timezone, :synced_at, :sync_error ])
  end

  def index
    visits = @clinic.visits.includes(:messages, :activities).order(:wall_time)
    render json: { clinic: @clinic, visits: visits.map { |v| serialize(v) }, replies: @clinic.replies.order(:id) }
  end

  def refresh
    ok = SourceRefresh.call(@clinic)
    render json: { message: ok ? "PMS snapshot refreshed" : @clinic.reload.sync_error }, status: ok ? :ok : :service_unavailable
  end

  def batch
    now = params[:demo_time].present? ? Time.iso8601(params[:demo_time]) : Time.current
    ok = ReminderBatch.call(@clinic, now: now)
    render json: { message: ok ? "Fake reminder batch complete" : @clinic.reload.sync_error }, status: ok ? :ok : :service_unavailable
  end

  def reply
    # The demo selects a patient to emulate their contact; matching never trusts an appointment ID.
    visit = @clinic.visits.find(params.require(:visit_id))
    channel = params.require(:channel)
    sender = visit.contact.details(visit.source_contact)[channel]
    SourceRefresh.call(@clinic)
    result = InboundReply.call(@clinic, event_id: params.require(:event_id), sender: sender, channel: channel, body: params.require(:body))
    render json: { message: result.result }
  end

  def update
    if params[:outcome] == "confirmed"
      raise ArgumentError, "PMS refresh failed; confirmation blocked" unless SourceRefresh.call(@clinic)
    end
    @clinic.with_lock do
      visit = @clinic.visits.find(params[:id])
      staff = params.require(:staff)
      raise ArgumentError, "Select a staff identity" unless %w[Taylor Jordan].include?(staff)
      if params[:outcome] == "assign"
        raise ArgumentError, "Already assigned to another staff member" if visit.owner && visit.owner != staff
        visit.update!(owner: staff)
      else
        note = params.require(:note).strip
        outcome = params.require(:outcome)
        raise ArgumentError, "Enter a note (1–1000 characters)" unless note.length.between?(1, 1000)
        raise ArgumentError, "Assign this work to yourself first" unless visit.owner == staff
        raise ArgumentError, "Unknown follow-up outcome" unless %w[attempted confirmed canceled rescheduled].include?(outcome)
        if outcome == "confirmed"
          raise ArgumentError, "Appointment changed; refresh and review its new time" unless params[:version] == visit.version
          raise ArgumentError, "Only current upcoming visits can be confirmed" unless visit.upcoming?(Time.current) && @clinic.sync_error.nil?
          visit.update!(confirmation: "confirmed", issue: nil, owner: nil)
        elsif outcome == "attempted"
          visit.update!(issue: visit.issue || "Contact attempted")
        else
          visit.update!(disposition: outcome, issue: nil, owner: nil)
        end
        visit.activities.create!(staff: staff, note: note, outcome: outcome)
      end
    end
    render json: { message: "Follow-up saved" }
  end

  def contact
    @clinic.with_lock do
      visit = @clinic.visits.find(params[:id])
      staff = params.require(:staff)
      raise ArgumentError, "Select staff identity" unless %w[Taylor Jordan].include?(staff)
      details = params.require(:details).permit(:sms, :email, :birthdate, :language).to_h
      raise ArgumentError, "All contact fields are required for verification" unless details.keys.sort == %w[birthdate email language sms]
      Date.iso8601(details["birthdate"])
      raise ArgumentError, "Birthdate cannot be in the future" if Date.iso8601(details["birthdate"]) > Date.current
      raise ArgumentError, "Choose English or Spanish" unless %w[en es].include?(details["language"])
      record = visit.contact
      record.update!(verified: details, source_at_verification: visit.source_contact, adult_authorized: params[:adult_authorized] == true, sms_allowed: params[:sms_allowed] == true, email_allowed: params[:email_allowed] == true)
      visit.activities.create!(staff: staff, outcome: "contact_verified", note: "Local contact details verified; PMS unchanged")
    end
    render json: { message: "Local details verified. Run a batch to reevaluate outreach." }
  end

  def leadership
    month = params.fetch(:month, Date.current.strftime("%Y-%m"))
    raise ArgumentError, "Use YYYY-MM" unless month.match?(/\A\d{4}-\d{2}\z/)
    date = Date.iso8601("#{month}-01")
    result = Clinic.order(:id).map do |clinic|
      scope = clinic.visits.where("wall_time >= ? AND wall_time < ?", date.to_s, date.next_month.to_s)
      counts = scope.group(:source_status).count
      total = counts.values.sum
      { clinic: clinic.name, total: total, completed: counts.fetch("complete", 0), canceled: counts.fetch("broken", 0), rescheduled: counts.fetch("unscheduled", 0), unknown: total - counts.values_at("complete", "broken", "unscheduled").compact.sum,
        messages: Message.joins(:visit).where(visits: { id: scope.select(:id) }).count,
        holds: scope.where.not(issue: nil).count, confirmed: scope.where(confirmation: "confirmed").count }
    end
    render json: result
  end

  private

  def select_clinic
    @clinic = Clinic.find(params[:clinic_id])
  end

  def serialize(visit)
    contact = visit.contact
    visit.as_json.merge("outcome" => visit.outcome, "details" => contact.details(visit.source_contact), "verified" => contact.verified.any?, "sms_stopped" => contact.sms_stopped, "sms_allowed" => contact.sms_allowed, "email_allowed" => contact.email_allowed, "adult_authorized" => contact.adult_authorized, "messages" => visit.messages, "activities" => visit.activities)
  end
end
