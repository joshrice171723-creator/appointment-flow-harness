class ReminderBatch
  WINDOW = 10...18
  def self.call(clinic, now: Time.current)
    return false unless SourceRefresh.call(clinic, now: now)
    clinic.with_lock do
      local = clinic.local_now(now)
      clinic.visits.includes(:messages).find_each do |visit|
        next unless visit.upcoming?(now)
        contact = visit.contact
        hold = contact.hold(visit.source_contact, local.to_date)
        if hold
          visit.update!(issue: hold)
          next
        end
        visit.update!(issue: nil) if visit.issue&.match?(/contact|Language|birthdate|channel/)
        days = (visit.starts_at.in_time_zone(clinic.timezone).to_date - local.to_date).to_i
        visit.update!(issue: "No confirmation within 48 hours") if days <= 2 && visit.confirmation == "unconfirmed" && visit.issue.nil?
        next unless WINDOW.cover?(local.hour) && days <= 7 && visit.confirmation == "unconfirmed"
        step = days <= 1 ? "final" : days <= 3 ? "follow_up" : "initial"
        next if visit.messages.any? { |m| m.version == visit.version && m.step == step }
        channel = contact.recipient(visit.source_contact, "sms") ? "sms" : "email"
        send_fake(visit, contact, channel, step)
      end
      clinic.visits.includes(:messages).find_each do |visit|
        next unless visit.upcoming?(now) && visit.confirmation == "unconfirmed" && WINDOW.cover?(local.hour)
        contact = visit.contact
        next if contact.hold(visit.source_contact, local.to_date)
        days = (visit.starts_at.in_time_zone(clinic.timezone).to_date - local.to_date).to_i
        next unless days.between?(4, 6) || visit.messages.any? { |m| m.version == visit.version && m.delivery == "failed" }
        initial = visit.messages.find { |m| m.version == visit.version && m.step == "initial" && m.channel == "sms" }
        next unless initial && (initial.delivery == "failed" || initial.created_at <= now - 1.day)
        next unless contact.recipient(visit.source_contact, "email")
        next if visit.messages.any? { |m| m.version == visit.version && (m.step == "backup" || m.channel == "email") }
        send_fake(visit, contact, "email", "backup")
      end
    end
    true
  end

  def self.send_fake(visit, contact, channel, step)
    recipient = contact.recipient(visit.source_contact, channel)
    return unless recipient
    spanish = contact.details(visit.source_contact)["language"] == "es"
    text = spanish ? "Responda YES para confirmar o NO para ayuda." : "Reply YES to confirm or NO for help."
    text += " Reply STOP to stop texts." if channel == "sms"
    # Fake transport only: reserved 555-0199 demonstrates failure.
    delivery = recipient.end_with?("5550199") ? "failed" : "sent"
    visit.messages.create!(version: visit.version, step: step, channel: channel, recipient: recipient, body: "#{visit.clinic.name}: #{visit.wall_time} (#{visit.clinic.timezone}). #{text}", delivery: delivery)
    visit.update!(issue: "Delivery failed; review contact") if delivery == "failed"
  end
end
