class Activity < ApplicationRecord
  belongs_to :visit
end
