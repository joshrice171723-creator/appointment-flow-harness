class Visit < ApplicationRecord
  belongs_to :clinic
  has_many :messages
  has_many :activities
  def contact = clinic.contacts.find_by!(patient_id: patient_id)
  def upcoming?(now) = source_status == "scheduled" && disposition.nil? && starts_at && starts_at > now
  def outcome = { "complete" => "Completed", "broken" => "Canceled", "unscheduled" => "Rescheduled" }.fetch(source_status, "Unknown")
end
