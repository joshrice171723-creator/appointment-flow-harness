class Clinic < ApplicationRecord
  has_many :visits
  has_many :contacts
  has_many :replies
  def local_now(now) = now.in_time_zone(timezone)
end
