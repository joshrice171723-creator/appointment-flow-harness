class InboundReply
  def self.call(clinic, event_id:, sender:, channel:, body:, now: Time.current)
    raise ArgumentError, "Invalid reply" unless %w[sms email].include?(channel) && event_id.present? && event_id.length <= 100 && body.present? && body.length <= 2000
    sender = Contact.normalize(sender, channel)
    raise ArgumentError, "Missing sender" if sender.blank?
    clinic.with_lock do
      previous = clinic.replies.find_by(event_id: event_id)
      return previous if previous
      messages = Message.joins(:visit).where(visits: { clinic_id: clinic.id }, channel: channel, recipient: sender, delivery: "sent")
      ids = messages.distinct.pluck(:visit_id)
      clinic.visits.find_each do |visit|
        ids << visit.id if Contact.normalize(visit.contact.details(visit.source_contact)[channel], channel) == sender
      end
      ids.uniq!
      candidates = clinic.visits.where(id: ids).to_a
      command = body.strip.upcase
      result = "Needs staff review"
      if command == "STOP" && channel == "sms"
        clinic.contacts.find_each do |contact|
          source = clinic.visits.find_by(patient_id: contact.patient_id)&.source_contact || {}
          contact.update!(sms_stopped: true) if Contact.normalize(contact.details(source)["sms"], "sms") == sender
        end
        result = "SMS stopped"
      elsif command == "YES" && candidates.one? && clinic.sync_error.nil? && clinic.synced_at && clinic.synced_at >= now - 10.minutes
        visit = candidates.first
        stale = messages.where(visit_id: visit.id).where.not(version: visit.version).exists?
        shared = clinic.visits.where.not(patient_id: visit.patient_id).any? do |other|
          Contact.normalize(other.contact.details(other.source_contact)[channel], channel) == sender
        end
        current_recipient = visit.contact.recipient(visit.source_contact, channel)
        delivered = messages.where(visit_id: visit.id, version: visit.version).exists?
        if visit.upcoming?(now) && delivered && sender == current_recipient && !stale && !shared && !visit.contact.hold(visit.source_contact, clinic.local_now(now).to_date)
          visit.update!(confirmation: "confirmed", issue: nil, owner: nil)
          result = "Confirmed"
        end
      end
      candidates.each { |v| v.update!(issue: "Reply needs review") } if result == "Needs staff review"
      clinic.replies.create!(event_id: event_id, sender: sender, channel: channel, body: body, result: result, candidate_ids: ids)
    end
  end
end
