class SourceRefresh
  def self.call(clinic, now: Time.current)
    clinic.with_lock do
      rows = PmsAppointment.snapshot(clinic.id)
      raise "PMS returned no appointments; previous snapshot preserved" if rows.empty?
      rows.each do |row|
        contact = { "sms" => row["wireless_phone"], "email" => row["email"], "birthdate" => row["birthdate"].to_s, "language" => row["preferred_language"] }
        version = Digest::SHA256.hexdigest([ row["patient_id"], row["clinic_id"], row["wall_time"], row["status"] ].join("|"))
        visit = clinic.visits.find_or_initialize_by(source_id: row["id"])
        visit.assign_attributes(confirmation: "unconfirmed", disposition: nil, owner: nil, issue: nil) if visit.version != version
        starts_at = wall_instant(row["wall_time"], clinic.timezone)
        visit.assign_attributes(patient_id: row["patient_id"], patient_name: "#{row['first_name']} #{row['last_name']}", source_contact: contact, wall_time: row["wall_time"], starts_at: starts_at, source_status: row["status"], provider: row["provider_name"], version: version)
        visit.issue = "Appointment time needs review" unless starts_at
        visit.save!
        clinic.contacts.find_or_create_by!(patient_id: visit.patient_id)
      end
      clinic.visits.where.not(source_id: rows.map { |r| r["id"] }).update_all(source_status: "missing", issue: "Appointment missing from PMS; review required", confirmation: "unconfirmed")
      clinic.update!(synced_at: now, sync_error: nil)
    end
    true
  rescue ActiveRecord::ActiveRecordError, RuntimeError => e
    clinic.update!(sync_error: e.is_a?(RuntimeError) ? e.message : "PMS read failed; snapshot preserved")
    false
  end

  def self.wall_instant(value, zone)
    wall = Time.strptime(value + " UTC", "%Y-%m-%d %H:%M:%S %Z")
    periods = TZInfo::Timezone.get(zone).periods_for_local(wall)
    return unless periods.one?
    Time.utc(wall.year, wall.month, wall.day, wall.hour, wall.min, wall.sec) - periods.first.utc_total_offset
  end
end
