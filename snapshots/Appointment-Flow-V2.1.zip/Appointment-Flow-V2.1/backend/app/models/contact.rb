class Contact < ApplicationRecord
  belongs_to :clinic

  def self.normalize(value, channel)
    return value.to_s.strip.downcase if channel == "email"
    digits = value.to_s.gsub(/\D/, "")
    digits = digits[1..] if digits.length == 11 && digits.start_with?("1")
    digits.length == 10 ? "+1#{digits}" : ""
  end

  def details(source) = source.merge(verified)

  def recipient(source, channel)
    return if channel == "sms" && (sms_stopped || !sms_allowed)
    return if channel == "email" && !email_allowed
    value = Contact.normalize(details(source)[channel], channel)
    return if value.blank?
    return if channel == "email" && !value.match?(/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/)
    value
  end

  def hold(source, today)
    return "Source contact changed after verification" if verified.any? && source != source_at_verification
    facts = details(source)
    return "Language needs review" unless %w[en es].include?(facts["language"])
    birthday = begin
      Date.iso8601(facts["birthdate"].to_s)
    rescue Date::Error
      nil
    end
    return "Verify birthdate and authorized adult contact" unless birthday && birthday <= today
    return "Verify authorized adult contact" if birthday > today.years_ago(18) && !adult_authorized
    return "No permitted usable contact channel" unless recipient(source, "sms") || recipient(source, "email")
    nil
  end
end
