class PmsAppointment < ApplicationRecord
  self.table_name = "pms.appointments"
  self.record_timestamps = false
  def readonly? = true

  def self.snapshot(clinic_id)
    joins("JOIN pms.patients ON pms.patients.id = pms.appointments.patient_id")
      .where(clinic_id: clinic_id)
      .select("pms.appointments.*, pms.appointments.start_at::text AS wall_time, pms.patients.first_name, pms.patients.last_name, pms.patients.birthdate, pms.patients.wireless_phone, pms.patients.email, pms.patients.preferred_language")
      .map(&:attributes)
  end
end
