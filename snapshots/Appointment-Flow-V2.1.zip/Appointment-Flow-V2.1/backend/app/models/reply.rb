class Reply < ApplicationRecord
  belongs_to :clinic
end
