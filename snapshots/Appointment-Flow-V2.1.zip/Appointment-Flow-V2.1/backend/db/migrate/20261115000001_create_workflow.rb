class CreateWorkflow < ActiveRecord::Migration[8.1]
  def change
    create_table :clinics do |t|
      t.string :name, :timezone, null: false
      t.datetime :synced_at
      t.string :sync_error
    end
    create_table :visits do |t|
      t.references :clinic, null: false, foreign_key: true
      t.bigint :source_id, :patient_id, null: false
      t.string :patient_name, :wall_time, :source_status, :version, null: false
      t.jsonb :source_contact, default: {}, null: false
      t.datetime :starts_at
      t.string :provider, :issue, :owner, :disposition
      t.string :confirmation, default: 'unconfirmed', null: false
      t.timestamps
    end
    add_index :visits, :source_id, unique: true
    add_index :visits, [ :clinic_id, :starts_at ]
    create_table :contacts do |t|
      t.references :clinic, null: false, foreign_key: true
      t.bigint :patient_id, null: false
      t.jsonb :verified, :source_at_verification, null: false, default: {}
      t.boolean :sms_stopped, :adult_authorized, null: false, default: false
      t.boolean :sms_allowed, :email_allowed, null: false, default: true
      t.timestamps
    end
    add_index :contacts, [ :clinic_id, :patient_id ], unique: true
    create_table :messages do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :version, :step, :channel, :recipient, :delivery, null: false
      t.text :body, null: false
      t.timestamps
    end
    add_index :messages, [ :visit_id, :version, :step ], unique: true
    create_table :replies do |t|
      t.references :clinic, null: false, foreign_key: true
      t.string :event_id, :channel, :sender, :result, null: false
      t.text :body, null: false
      t.jsonb :candidate_ids, null: false, default: []
      t.timestamps
    end
    add_index :replies, [ :clinic_id, :event_id ], unique: true
    create_table :activities do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :staff, :outcome, null: false
      t.text :note, null: false
      t.timestamps
    end
    reversible do |dir|
      dir.up do
        execute <<~SQL
          CREATE SCHEMA pms;
          CREATE TABLE pms.clinics (id BIGINT PRIMARY KEY, name TEXT NOT NULL, address_line TEXT, city TEXT, state CHAR(2), phone TEXT);
          CREATE TABLE pms.patients (id BIGINT PRIMARY KEY, first_name TEXT NOT NULL, last_name TEXT NOT NULL, birthdate DATE, wireless_phone TEXT, email TEXT, preferred_language TEXT, guarantor_id BIGINT REFERENCES pms.patients(id));
          CREATE TABLE pms.appointments (id BIGINT PRIMARY KEY, patient_id BIGINT NOT NULL REFERENCES pms.patients(id), clinic_id BIGINT NOT NULL REFERENCES pms.clinics(id), provider_name TEXT, start_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, length_minutes INT, procedure_note TEXT, status TEXT NOT NULL, updated_at TIMESTAMP WITHOUT TIME ZONE);
          CREATE INDEX ON pms.appointments(clinic_id, start_at);
        SQL
      end
      dir.down { execute 'DROP SCHEMA pms CASCADE' }
    end
  end
end
