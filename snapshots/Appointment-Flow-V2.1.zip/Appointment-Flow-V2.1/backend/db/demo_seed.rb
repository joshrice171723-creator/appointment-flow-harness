module DemoSeed
  def self.call
    connection = ActiveRecord::Base.connection
    connection.execute('TRUNCATE activities, replies, messages, contacts, visits, clinics, pms.appointments, pms.patients, pms.clinics RESTART IDENTITY CASCADE')
    [ [ 1, 'Austin', 'America/Chicago', 'TX' ], [ 2, 'Phoenix', 'America/Phoenix', 'AZ' ] ].each do |id, name, zone, state|
      Clinic.create!(id: id, name: name, timezone: zone)
      connection.execute("INSERT INTO pms.clinics(id,name,city,state) VALUES (#{id},#{connection.quote(name)},#{connection.quote(name)},#{connection.quote(state)})")
      18.times do |i|
        patient_id = id * 100 + i
        phone = i == 4 ? nil : "(512) 555-#{format('%04d', 100 + i)}"
        phone = '(512) 555-0199' if i == 5
        phone = '(512) 555-0100' if i == 6
        email = i == 4 ? "email.only.#{id}@example.test" : "demo.#{patient_id}@example.test"
        birthdate = i == 7 ? '2015-01-01' : '1990-01-01'
        language = i == 8 ? 'fr' : i == 3 ? 'es' : 'en'
        connection.execute("INSERT INTO pms.patients(id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (#{patient_id},'Demo','Patient #{patient_id}',#{connection.quote(birthdate)},#{connection.quote(phone)},#{connection.quote(email)},#{connection.quote(language)})")
        days = i < 10 ? [ 7, 3, 1, 5, 7, 7, 7, 3, 3, 2 ][i] : -(i - 9)
        wall = (Date.current + days).strftime('%Y-%m-%d') + ' 15:00:00'
        status = i < 10 ? 'scheduled' : %w[complete complete broken unscheduled][i % 4]
        connection.execute("INSERT INTO pms.appointments(id,patient_id,clinic_id,provider_name,start_at,length_minutes,status,updated_at) VALUES (#{patient_id},#{patient_id},#{id},'Dr. Avery',#{connection.quote(wall)},30,#{connection.quote(status)},CURRENT_TIMESTAMP)")
      end
      clinic = Clinic.find(id)
      SourceRefresh.call(clinic)
      noon = Time.find_zone!(zone).local(Date.current.year, Date.current.month, Date.current.day, 12)
      ReminderBatch.call(clinic, now: noon)
    end
  end
end
