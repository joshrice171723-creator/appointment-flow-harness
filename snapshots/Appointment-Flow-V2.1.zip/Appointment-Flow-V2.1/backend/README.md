Use the project-root README.md and dev.py for setup and operation.
