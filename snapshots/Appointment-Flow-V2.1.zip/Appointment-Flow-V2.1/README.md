﻿# Appointment Flow — clean-room rebuild V2.1

Local Rails + React assessment application. Fictional records only; SMS/email are database-backed fake deliveries. The supplied harness passed preflight before scaffolding. No earlier implementation was opened or copied.

## Run on Windows

Prerequisites: Ruby 3.4, Bundler, Node 24, Python 3, PostgreSQL 17 binaries. Put Ruby and Node on PATH. PostgreSQL defaults to `C:\Program Files\PostgreSQL\17\bin`; override `POSTGRES_BIN` if needed. The runner creates a separate loopback-only trust-authenticated demo cluster on port 55421; do not expose it to a network.

From the extracted project root:

```powershell
py dev.py --setup
```

This installs locked dependencies, creates/migrates the two demo databases, resets fictional seed data, and starts Rails on 3181 and Vite on 5181. Open http://127.0.0.1:5181. Later starts: `py dev.py`. Ctrl+C stops the app processes; the demo PostgreSQL cluster remains available. `--setup` deliberately resets demo records; do not use it to preserve a session.

## Exercise the application

- Open Front desk, choose Austin or Phoenix and Taylor or Jordan (identity stub).
- Expand Demo controls. Run fake reminders with a UTC instant corresponding to 10:00–18:00 clinic-local time. Cadence: latest due request at 7, 3, or 1 day; one email backup on days 6–4 after an unanswered initial SMS, or immediately after fake failure. Requests stop after confirmation. Repeated/concurrent runs are deduplicated by appointment revision and step.
- Open Patient demo, choose clinic/patient, inspect Text messages or Email, and type YES, NO or STOP. Email-only Demo Patient 104/204 exercises email. Demo 105/205 demonstrates failed SMS and backup. Shared phone 100/106 routes YES to review. Demo 107 needs authorized adult verification; 108 needs language review.
- The staff board shows unresolved holds and replies. Open a card, assign to yourself, then record a note and outcome. Contact attempted stays open; staff confirmation resolves; canceled/rescheduled suppress outreach locally without editing the PMS.
- Patient details allow audited local corrections and permissions. STOP persists even if staff checks SMS permission. Raw PMS values remain inspectable. No self-service booking or source schedule edits exist.
- Leadership uses a month selector and aggregate-only API. Completion is a PMS outcome; confirmation is separate. No claim about reduced no-shows is made.

## Checks

```powershell
$env:PATH = 'C:\Program Files\PostgreSQL\17\bin;' + $env:PATH
py quality/run_checks.py
```

The demo cluster must be running. All commands are in `quality/checks.json`. Backend tests use the separate `apex_rebuild_test` database. Browser smoke tests require the app running and an installed Playwright Chromium (`cd frontend; npx playwright install chromium` if absent). `npm run test:browser` exercises all three workspaces and a narrow viewport.

## Data and operating boundaries

PMS schema preserves the assignment columns and local wall timestamps. `SourceRefresh` copies a complete clinic read into app-owned visits under a transaction; empty/failed reads preserve prior records and block batches. Runtime source model is read-only; migrations/seeds intentionally own synthetic source setup. A production connection must use a separate SELECT-only PMS role; this local demo's database owner is not a production security boundary. Replication lag can still hide recent changes; there is no claim of authoritative live appointment locking.

US clinic timezones are explicit. DST gaps/folds are held for review. Shared/old-message/reassigned visits never auto-confirm by guessing. When there is any older message revision or more than one candidate appointment in the recipient's history, staff must clarify. This conservative rule can route legitimate recurring replies to staff.

The manual scheduler, per-clinic locks and fake delivery transaction keep the demo small. A real transport requires a durable outbox, provider idempotency and delivery reconciliation before any real sends. Production also needs staff authentication/clinic authorization, audited contact/guardian verification and consent, encryption, retention, and operational monitoring.

See ARCHITECTURE.md, AI_USAGE.md, notes/CANDIDATE_DECISION_NOTES.md and review/FREEZE_CHECKLIST.md. Final candidate-authored DECISIONS.md and a live defense remain human work.
