# Assignment requirements — source: Apex take-home brief

**Source of truth:** `reference/Appointment-Confirmation-Take-Home.pdf` (5 pages). This is a structured summary, not permission to expand scope. Read the PDF before making implementation decisions. The original brief expects AI tools and an in-person defense with a small live change.

## Purpose and stakeholders (page 1)

Build a small, working patient appointment confirmation system for Apex Dental Partners. Patients receive reminders and respond; **front-desk staff at each clinic** see confirmation status and can prioritize follow-up; **operations leaders** need insight into no-shows. The stated cadence (approximately a week before and a couple of days before) is a **starting point, not a fixed specification**.

## Existing read-side data (pages 2–3)

PMS data is replicated into PostgreSQL, with approximately **5-minute** replication lag. Seed realistic **fake** data. Tables/columns from the supplied schema:

| Table | Fields from brief | Notes |
|---|---|---|
| `clinics` | `id BIGINT PK`, `name TEXT NOT NULL`, `address_line TEXT`, `city TEXT`, `state CHAR(2)`, `phone TEXT` | Clinic-specific locality and phone |
| `patients` | `id BIGINT PK`, `first_name TEXT NOT NULL`, `last_name TEXT NOT NULL`, `birthdate DATE`, `wireless_phone TEXT`, `email TEXT`, `preferred_language TEXT`, `guarantor_id BIGINT REFERENCES patients(id)` | Phone is staff-entered free text; guarantor may be responsible party |
| `appointments` | `id BIGINT PK`, `patient_id BIGINT REFERENCES patients(id) NOT NULL`, `clinic_id BIGINT REFERENCES clinics(id) NOT NULL`, `provider_name TEXT`, `start_at TIMESTAMP WITHOUT TIME ZONE NOT NULL`, `length_minutes INT`, `procedure_note TEXT`, `status TEXT NOT NULL`, `updated_at TIMESTAMP WITHOUT TIME ZONE` | `start_at` is **clinic wall-clock time**; statuses: `scheduled`, `complete`, `broken`, `unscheduled` |

An appointment reschedule usually updates `start_at` on the **same appointment row**; sometimes staff mark old appointment broken and create a new one. You may add your own tables/schemas/databases. The assignment calls for an **interface with fake/sandbox SMS and email**; real vendor accounts aren't required.

## Explicit functional requirements (page 3)

- [ ] Find upcoming appointments needing confirmation.
- [ ] Contact patients via **SMS and email**, roughly a week and a couple of days before appointments.
- [ ] Record each patient's confirmation response.
- [ ] Provide a front-desk UI showing the status of upcoming appointments **at each clinic**.
- [ ] Run locally with seed data and tests.

## Volume and proportionality (page 3)

Approximately **60 clinics**, **4,000 appointments/day**, potentially growing. Scale deserves consideration, but the first version should not be dominated by infrastructure complexity.

## Explicitly out of scope (page 3)

- Booking new appointments or full self-service rescheduling.
- Production deployment, infrastructure as code, or live vendor accounts.
- Full staff authentication beyond a stub (but explain production security approach).

## Required deliverables (page 4)

- **Working code**, runnable system, seed data and tests.
- **`README.md`**: run instructions, trigger a reminder run, simulate a patient reply.
- **`DECISIONS.md`**: assumptions, open questions, choices, rejected alternatives, and what one more week would buy; **write it yourself in your own words**. Reviewers read it **before code**.
- **Architecture representation**: components, data flow, confirmation-state lifecycle (any format).
- **`AI_USAGE.md`**: AI tools and their purposes; interventions/overrides/corrections. Transcripts optional.

## Ground rules and evaluation (pages 4–5)

- Any AI coding tools are permitted; no other people and no code taken from a current or former employer.
- Evaluation prioritizes: judgment under ambiguity, correctness where patient harm/embarrassment is possible, ownership and ability to defend/change any code, clarity, and proportion.
- No scoring incentive for lines of code, feature count, or number of technologies.

## Important design decisions not specified by the brief

The agent must **not silently decide** these as if requirements were explicit:

- What is the precise contact schedule/eligibility, and what happens after early confirmation?
- What constitutes an authorized/valid confirmation response? How are ambiguous replies handled?
- How to choose an SMS number/email and handle missing or malformed contact data; when a guarantor should be contacted.
- How to map clinic state to timezone / daylight-saving rules and interpret `start_at`.
- How to handle replicated data being five minutes stale, reschedules, broken/recreated appointments, and concurrent reminder runs.
- Whether a clinic staff member can only view a single selected clinic or more than one (stub auth only).
- What metrics can responsibly describe no-shows, versus confirmation rates (the brief does not require causal proof).

Address these in an explicit assumption/decision log. Favor the least-complex safe approach and test edge cases.
