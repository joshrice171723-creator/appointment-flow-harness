# Deliverables and decisions — author ownership

The employer expressly says `DECISIONS.md` must be written by the candidate **in their own words** and will be read **before the code**. Use `templates/DECISIONS.md` only as a blank structure, then replace every `TODO` with your actual rationale. Never say an AI-authored rationale is yours.

Material decisions worth recording:

- Definition of an appointment needing confirmation; treatment of already confirmed patients.
- Timing cadence, clock source, missed windows, ability to simulate time locally.
- Source data is 5-minute-lagged and appointment `start_at` is clinic wall-clock time; timezone mapping.
- Patient vs guarantor contact, malformed/missing numbers, email validity, safety assumptions and production gaps.
- Confirmation-reply matching/verification, unknown replies, duplicate responses, cancellations/reschedules.
- Idempotency and retries with fake send transports, concurrency guard, delivery attempt storage.
- API/React separation versus Rails-integrated approach; why chosen scope is sufficient.
- Clinic scoping with stub auth and real-world authentication/authorization roadmap.
- Reporting approach: confirmation metrics vs **no-show reduction**. The latter needs historical outcomes and comparison methods and should not be claimed from toy seed data.
- Production vendor choice **if discussed** and rationale (fake implementation only).
- What you'd do next with one additional week.

Use facts and observable tradeoffs. State uncertainty where an assumption cannot be verified. Make sure you can explain each decision in the 60-minute live defense and modify the code without the AI.
