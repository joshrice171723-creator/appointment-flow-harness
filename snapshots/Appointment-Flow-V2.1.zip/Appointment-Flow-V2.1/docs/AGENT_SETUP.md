# RubyMine + agent setup (external tools are NOT bundled)

## Essential

- RubyMine with Ruby/Rails and JS/TS features enabled. RubyMine 2026.3 documents an **Air plugin** that hosts external coding agents and exposes IDE intelligence through an MCP server. Version/plugin availability depends on your installation.
- A working **Codex** or **Claude Code** agent installation/subscription, chosen by the user. This ZIP is agent-agnostic and works through `AGENTS.md` even without external plugins. RubyMine doesn't automatically enable an agent solely because this ZIP is unzipped.
- Python 3 to run the bundled **standard-library-only** harness verification / post-scaffold quality runner.

## Optional primary orchestrator: Compound Engineering

Official install instructions (check latest README before acting): https://github.com/EveryInc/compound-engineering-plugin

**Codex CLI**, after Codex is installed and authenticated:

```sh
codex plugin marketplace add EveryInc/compound-engineering-plugin
codex plugin add compound-engineering@compound-engineering-plugin
```

Restart Codex. In the chosen agent's supported plugin host, run `/ce-setup` and use selected stages (`/ce-brainstorm`, `/ce-plan`, `/ce-work`, `/ce-simplify-code`, `/ce-code-review`, `/ce-compound`) as available in that host. Do **not** use `/lfg` or any unattended git push/PR/commit in this exercise.

**Claude Code** alternative commands inside its tool:

```text
/plugin marketplace add EveryInc/compound-engineering-plugin
/plugin install compound-engineering
```

The plugin may not be exposed as slash commands in every RubyMine agent integration. If so, work directly from `agent-prompts/` and `AGENTS.md`: nothing essential relies on CE installation.

## Optional Clean Code Skill

Repository: https://github.com/patbaumgartner/clean-code-skill

Not included by default because the core harness already covers the same quality criteria, and duplicated reviews/instructions can increase overhead. If independently evaluated and useful, install this skill through a supported agent host; it has a TS/JS guide but **no Ruby-specific guide** in its published README. Your Rails rules here remain authoritative.

## IDE preferences

- Enable RubyMine inspections and review the diff before accepting it. Don't rely solely on AI reviewer suggestions.
- Share relevant `AGENTS.md` and `docs` paths with the agent context if automatic loading is absent.
- Run checks from RubyMine Terminal (`python quality/verify_harness.py`, later `python quality/run_checks.py`).
- Do not configure a second agent orchestrator such as BMAD or Superpowers on top of CE for this project.

## Dependency/version choices

Do not pin Rails, Ruby, Node, PostgreSQL, React, or TypeScript until fresh scaffolding is approved and compatible versions are verified in your environment. Record concrete versions and lockfiles in the resulting application. Avoid prerelease tooling without clear need. A fresh Rails app may use Minitest; a fresh Vite React app can use TypeScript and Vitest if approved.
