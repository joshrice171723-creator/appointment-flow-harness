# Implementation loop for the clean-room rebuild

The user has requested a new, independent rebuild. `RUN_THIS_IN_RUBYMINE.md` grants permission to move from Stage 0 planning to normal in-workspace implementation; do not ask to re-authorize every reversible local change. Respect any approval needed for external resources, secrets, destructive actions, or publishing.

For each vertical slice:
1. Identify the relevant `product-spec/ACCEPTANCE_TESTS.md` checks and observable result.
2. Read only the **new** project code and official/new-product references.
3. Choose the simplest implementation and the highest-risk behavior test.
4. Write/adjust tests first where useful; implement and exercise the UI end-to-end.
5. Run focused checks, then simplify for readability without broad rewrites.
6. Review the diff independently, applying only evidenced fixes.
7. Update `notes/BUILD_LOG.md` and decision *notes* for the candidate.

Suggested order: project setup / sample data; appointment read-side; simple fake reminder; reply and confirmation; clinic-scoped front-desk; reschedule/opt-out/ambiguous reply; visual reference screens; leadership aggregates; final safety/regression pass. This order is not a mandate on code architecture. Preserve official assignment requirements above extended UX if time is limited.

Never import the old repository, even for tests or comparison, until the new result is frozen and the user explicitly authorizes it.
