# DECISIONS — write in your own words

**Candidate: replace this outline with your own explanations. The employer expressly requires the candidate to write this document in their own words.** Do not submit TODOs or an AI-authored essay as your own.

## Scope and assumptions

- TODO: What are we building and not building, and why?
- TODO: What assumptions were necessary because the brief is ambiguous?

## Major decisions

For each decision, answer in your own words:

### Decision: [topic]

- Context / risk: TODO
- Choice and reason: TODO
- Alternative rejected and why: TODO
- What could prove this wrong: TODO
- Test/evidence: TODO

Useful topics: reminder timing; reschedules; time zones; idempotency; patient/guarantor; reply verification; fake providers; local data ownership; clinic scoping; UI/API scope; error and retry strategy.

## Open questions for the team

- TODO

## If I had one more week

- TODO: prioritized improvements and why they matter
