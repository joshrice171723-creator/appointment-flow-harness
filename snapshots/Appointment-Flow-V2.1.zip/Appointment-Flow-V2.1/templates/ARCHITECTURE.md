# Architecture — complete after the design is implemented

> Do not submit a speculative diagram. Replace each placeholder with actual project files and observed behavior.

## Components

TODO: Draw the actual Rails/React/DB/fake messaging components. Show explicit boundaries and data ownership.

## Data flow

TODO: PMS replication → appointment eligibility → fake send attempt → patient reply → confirmation record → clinic dashboard.

## Confirmation-state lifecycle

TODO: Clearly distinguish appointment status, reminder delivery status, and confirmation status. Provide state transition diagram (Mermaid is fine) based on actual code and tests.

## Time and identities

TODO: Explain clinic wall-clock interpretation, timezone mapping, appointment identity across changes, and how duplicates are prevented.

## Local demo commands

TODO: Cite README's actual setup, reminder trigger, and reply simulation commands. Verify by executing them.
