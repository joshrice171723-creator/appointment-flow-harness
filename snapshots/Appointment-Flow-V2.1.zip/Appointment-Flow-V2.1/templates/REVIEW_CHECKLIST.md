# Review checklist (copy to each review when implementation begins)

- [ ] Requirement IDs and scope are explicit; no unauthorized extra features.
- [ ] No older assessment code, history, prompts, or data was imported.
- [ ] Correct recipient, clinic, appointment, timing, and confirmation identity verified.
- [ ] Reschedules/cancellations/replication delay addressed to the agreed extent.
- [ ] Repeated reminder runs and fake provider failures cannot silently create duplicate confirmations/sends.
- [ ] Sensitive details omitted from outbound bodies/logs; fake data and providers only.
- [ ] Plain, idiomatic Ruby/Rails and React/TypeScript; unnecessary abstractions removed.
- [ ] Tests for behavior and important edge cases; test/lint/type checks reported honestly.
- [ ] Narrow diff; no unrelated edits, unneeded deps, or disabled checks.
- [ ] Candidate can explain and change the implementation without AI.
- [ ] `DECISIONS.md` written by candidate; `AI_USAGE.md` accurate; architecture/README complete.
