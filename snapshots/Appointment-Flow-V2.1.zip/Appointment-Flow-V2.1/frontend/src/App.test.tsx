﻿import { afterEach, expect, test, vi } from "vitest";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "./App";
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});
const clinic = {
  id: 1,
  name: "Austin",
  timezone: "America/Chicago",
  synced_at: null,
  sync_error: null,
};
test("workspace entry loads real clinic choices and opens empty staff view", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn(async (url: string) => ({
      ok: true,
      json: async () =>
        url.endsWith("/clinics")
          ? [clinic]
          : { clinic, visits: [], replies: [] },
    })),
  );
  render(<App />);
  await screen.findByRole("option", { name: "Austin" });
  await userEvent.click(
    screen.getByRole("button", { name: /Open front desk/ }),
  );
  await screen.findByRole("heading", { name: "Patient flow" });
  expect(screen.getByText("No appointments match these filters.")).toBeTruthy();
  await userEvent.click(screen.getByRole("button", { name: "Appointments" }));
  expect(screen.getByLabelText("Jump to date")).toBeTruthy();
});
test("API error is visible", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => ({
      ok: false,
      json: async () => ({ error: "Source unavailable" }),
    })),
  );
  render(<App />);
  await waitFor(() =>
    expect(screen.getByRole("alert").textContent).toContain(
      "Source unavailable",
    ),
  );
});
