﻿import { useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import "./App.css";
type Clinic = {
  id: number;
  name: string;
  timezone: string;
  synced_at: string | null;
  sync_error: string | null;
};
type Details = {
  sms: string;
  email: string;
  birthdate: string;
  language: string;
};
type Message = {
  id: number;
  body: string;
  channel: string;
  delivery: string;
  created_at: string;
};
type Activity = {
  id: number;
  staff: string;
  note: string;
  outcome: string;
  created_at: string;
};
export type Visit = {
  id: number;
  patient_id: number;
  patient_name: string;
  wall_time: string;
  provider: string;
  confirmation: string;
  source_status: string;
  version: string;
  outcome: string;
  disposition: string | null;
  issue: string | null;
  owner: string | null;
  details: Details;
  source_contact: Details;
  verified: boolean;
  sms_stopped: boolean;
  sms_allowed: boolean;
  email_allowed: boolean;
  adult_authorized: boolean;
  messages: Message[];
  activities: Activity[];
};
type Reply = {
  id: number;
  body: string;
  channel: string;
  result: string;
  candidate_ids: number[];
};
type Snapshot = { clinic: Clinic; visits: Visit[]; replies: Reply[] };
type Metric = {
  clinic: string;
  total: number;
  completed: number;
  canceled: number;
  rescheduled: number;
  unknown: number;
  messages: number;
  holds: number;
  confirmed: number;
};
type Act = (path: string, body?: object, method?: string) => Promise<boolean>;
async function request<T>(
  path: string,
  method = "GET",
  body?: object,
  signal?: AbortSignal,
): Promise<T> {
  const response = await fetch("/api" + path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
    signal,
  });
  const result = await response.json();
  if (!response.ok)
    throw new Error(result.error || result.message || "Request failed");
  return result as T;
}
function visitState(v: Visit) {
  return (
    v.disposition ||
    (v.issue ? (v.owner ? "In progress" : "Needs attention") : v.confirmation)
  );
}
const today = () => new Date().toLocaleDateString("en-CA");
function shift(date: string, n: number) {
  const d = new Date(date + "T12:00:00");
  d.setDate(d.getDate() + n);
  return d.toLocaleDateString("en-CA");
}
function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label>
      {label}
      {children}
    </label>
  );
}
export default function App() {
  const [clinics, setClinics] = useState<Clinic[]>([]),
    [clinicId, setClinicId] = useState("1"),
    [staff, setStaff] = useState("Taylor"),
    [workspace, setWorkspace] = useState("home"),
    [error, setError] = useState("");
  useEffect(() => {
    const c = new AbortController();
    request<Clinic[]>("/clinics", "GET", undefined, c.signal)
      .then(setClinics)
      .catch((e) => {
        if (!c.signal.aborted) setError(String(e));
      });
    return () => c.abort();
  }, []);
  const picker = (
    <Field label="Clinic">
      <select value={clinicId} onChange={(e) => setClinicId(e.target.value)}>
        {clinics.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name}
          </option>
        ))}
      </select>
    </Field>
  );
  return (
    <>
      <header>
        <a className="brand" href="#" onClick={() => setWorkspace("home")}>
          <span className="mark">A↗</span>
          <span>
            APEX<small>APPOINTMENT FLOW</small>
          </span>
        </a>
        <button className="link" onClick={() => setWorkspace("home")}>
          Workspaces ↗
        </button>
      </header>
      <main className={workspace === "patient" ? "narrow" : ""}>
        {error && <p role="alert">{error}</p>}
        {workspace === "home" ? (
          <>
            <h1>Workspaces</h1>
            <div className="workspace-grid">
              <section className="card entry">
                <h2>Front desk</h2>
                <p>Review appointments and record patient follow-up.</p>
                {picker}
                <Field label="Staff member · demo sign-in">
                  <select
                    value={staff}
                    onChange={(e) => setStaff(e.target.value)}
                  >
                    <option>Taylor</option>
                    <option>Jordan</option>
                  </select>
                </Field>
                <button
                  disabled={!clinics.length}
                  onClick={() => setWorkspace("staff")}
                >
                  Open front desk →
                </button>
              </section>
              <section className="card entry tinted">
                <h2>Apex leadership</h2>
                <p>Compare recorded outcomes. Aggregate data only.</p>
                <strong className="big-number">{clinics.length}</strong>
                <p>clinics</p>
                <button onClick={() => setWorkspace("leadership")}>
                  Open leadership →
                </button>
              </section>
              <section className="card entry">
                <h2>Patient demo</h2>
                <p>Inspect fake messages and simulate patient replies.</p>
                <p className="muted">No live SMS or email is sent.</p>
                <button
                  disabled={!clinics.length}
                  onClick={() => setWorkspace("patient")}
                >
                  Open patient inbox →
                </button>
              </section>
            </div>
          </>
        ) : workspace === "leadership" ? (
          <Leadership />
        ) : (
          <>
            {picker}
            <ClinicWorkspace
              key={clinicId + workspace}
              clinicId={clinicId}
              staff={staff}
              patientMode={workspace === "patient"}
            />
          </>
        )}
      </main>
      <footer>Local demonstration · fictional records · fake messaging</footer>
    </>
  );
}
function ClinicWorkspace({
  clinicId,
  staff,
  patientMode,
}: {
  clinicId: string;
  staff: string;
  patientMode: boolean;
}) {
  const [data, setData] = useState<Snapshot | null>(null),
    [revision, setRevision] = useState(0),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  const [view, setView] = useState("board"),
    [selected, setSelected] = useState<number | null>(null),
    [search, setSearch] = useState(""),
    [filter, setFilter] = useState("active"),
    [type, setType] = useState("all"),
    [page, setPage] = useState(0),
    [date, setDate] = useState(today()),
    [instant, setInstant] = useState(today() + "T18:00");
  const root = "/clinics/" + clinicId;
  useEffect(() => {
    const c = new AbortController();
    request<Snapshot>(root + "/visits", "GET", undefined, c.signal)
      .then(setData)
      .catch((e) => {
        if (!c.signal.aborted) setError(String(e));
      });
    return () => c.abort();
  }, [root, revision]);
  const act: Act = async (path, body, method = "POST") => {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const r = await request<{ message: string }>(root + path, method, body);
      setNotice(r.message);
      setRevision((n) => n + 1);
      return true;
    } catch (e) {
      setError(
        String(e) +
          ". Draft preserved. If the network outcome is uncertain, refresh before submitting again.",
      );
      return false;
    } finally {
      setBusy(false);
    }
  };
  if (!data) return <p role="status">{error || "Loading clinic records…"}</p>;
  const visits = data.visits,
    current = visits.find((v) => v.id === selected),
    issues = visits.filter((v) => v.issue && !v.disposition);
  let visible = visits.filter((v) =>
    v.patient_name.toLowerCase().includes(search.toLowerCase()),
  );
  visible =
    view === "board"
      ? visible
          .filter((v) =>
            filter === "resolved"
              ? !!v.disposition || (!v.issue && v.confirmation === "confirmed")
              : !!v.issue && !v.disposition,
          )
          .filter((v) => type === "all" || v.issue === type)
      : visible
          .filter((v) => v.wall_time.startsWith(date))
          .filter((v) =>
            filter === "confirmed"
              ? v.confirmation === "confirmed"
              : filter === "unconfirmed"
                ? v.confirmation !== "confirmed"
                : filter === "review"
                  ? v.issue === "Reply needs review"
                  : true,
          );
  return (
    <>
      <div className="title-row">
        <div>
          <p className="eyebrow">
            {data.clinic.name} · {staff}
          </p>
          <h1>
            {patientMode
              ? "Patient inbox"
              : current
                ? current.patient_name
                : view === "board"
                  ? "Patient flow"
                  : "Appointments"}
          </h1>
        </div>
        {!patientMode && (
          <nav>
            {["board", "appointments"].map((t) => (
              <button
                key={t}
                onClick={() => {
                  setView(t);
                  setFilter(t === "board" ? "active" : "all");
                  setSelected(null);
                  setPage(0);
                }}
              >
                {t === "board" ? "Patient flow" : "Appointments"}
              </button>
            ))}
          </nav>
        )}
      </div>
      <p className="muted">
        Last PMS sync:{" "}
        {data.clinic.synced_at
          ? new Date(data.clinic.synced_at).toLocaleString()
          : "Never"}{" "}
        · {data.clinic.timezone}
      </p>
      {data.clinic.sync_error && <p role="alert">{data.clinic.sync_error}</p>}
      {error && <p role="alert">{error}</p>}
      {notice && (
        <p role="status" className="notice">
          {notice}
        </p>
      )}
      {patientMode ? (
        <Inbox visits={visits} replies={data.replies} act={act} busy={busy} />
      ) : (
        <>
          {data.replies
            .filter((r) => r.candidate_ids.length === 0)
            .map((r) => (
              <section className="card" key={r.id}>
                <h2>Unmatched reply needs review</h2>
                <p>{r.body}</p>
                <p>
                  {r.channel} · {r.result}. Clarify the patient and visit before
                  recording an outcome.
                </p>
              </section>
            ))}
          <details className="card">
            <summary>Demo controls</summary>
            <p>
              Manual runs use the selected UTC instant. All deliveries are
              simulated.
            </p>
            <Field label="Batch instant (UTC)">
              <input
                type="datetime-local"
                value={instant}
                onChange={(e) => setInstant(e.target.value)}
              />
            </Field>
            <button
              disabled={busy}
              onClick={() => act("/batch", { demo_time: instant + ":00Z" })}
            >
              Run fake reminders
            </button>{" "}
            <button disabled={busy} onClick={() => act("/refresh")}>
              Refresh PMS
            </button>
          </details>
          {current ? (
            <PatientDetail
              key={current.id}
              visit={current}
              staff={staff}
              act={act}
              busy={busy}
              back={() => setSelected(null)}
              replies={data.replies}
            />
          ) : (
            <>
              {view === "board" && (
                <div className="stats">
                  {[
                    ["Needs attention", issues.filter((v) => !v.owner).length],
                    ["In progress", issues.filter((v) => v.owner).length],
                    [
                      "Resolved",
                      visits.filter(
                        (v) =>
                          v.disposition ||
                          (!v.issue && v.confirmation === "confirmed"),
                      ).length,
                    ],
                  ].map(([label, count]) => (
                    <section className="card" key={label}>
                      <span>{label}</span>
                      <strong className="big-number">{count}</strong>
                    </section>
                  ))}
                </div>
              )}
              {view === "appointments" && (
                <section className="card">
                  <div className="toolbar">
                    <button onClick={() => setDate(shift(date, -7))}>
                      ← Previous week
                    </button>
                    <button onClick={() => setDate(today())}>Today</button>
                    <button onClick={() => setDate(shift(date, 7))}>
                      Next week →
                    </button>
                    <Field label="Jump to date">
                      <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                      />
                    </Field>
                  </div>
                  <div className="week">
                    {Array.from({ length: 7 }, (_, i) =>
                      shift(date, i - 3),
                    ).map((d) => (
                      <button
                        key={d}
                        aria-pressed={date === d}
                        onClick={() => setDate(d)}
                      >
                        {d}
                        <small>
                          {
                            visits.filter((v) => v.wall_time.startsWith(d))
                              .length
                          }{" "}
                          visits
                        </small>
                      </button>
                    ))}
                  </div>
                </section>
              )}
              <div className="toolbar">
                <div className="tabs">
                  {(view === "board"
                    ? ["active", "resolved"]
                    : ["all", "confirmed", "unconfirmed", "review"]
                  ).map((f) => (
                    <button
                      key={f}
                      aria-pressed={filter === f}
                      onClick={() => {
                        setFilter(f);
                        setPage(0);
                      }}
                    >
                      {f === "review" ? "Replies to review" : f}
                    </button>
                  ))}
                </div>
                <Field label="Find a patient">
                  <input
                    type="search"
                    value={search}
                    onChange={(e) => {
                      setSearch(e.target.value);
                      setPage(0);
                    }}
                  />
                </Field>
                {view === "board" && (
                  <Field label="Follow-up type">
                    <select
                      value={type}
                      onChange={(e) => {
                        setType(e.target.value);
                        setPage(0);
                      }}
                    >
                      <option value="all">All follow-up types</option>
                      {Array.from(new Set(issues.map((v) => v.issue))).map(
                        (i) => (
                          <option key={i} value={i || ""}>
                            {i}
                          </option>
                        ),
                      )}
                    </select>
                  </Field>
                )}
              </div>
              {!visible.length ? (
                <p className="card">No appointments match these filters.</p>
              ) : view === "board" ? (
                <div className="board">
                  {["Needs attention", "In progress"].map((column) => (
                    <section className="column" key={column}>
                      <h3>{column}</h3>
                      {visible
                        .slice(page * 10, page * 10 + 10)
                        .filter((v) =>
                          filter === "resolved"
                            ? column === "Needs attention"
                            : (v.owner ? "In progress" : "Needs attention") ===
                              column,
                        )
                        .map((v) => (
                          <button
                            className="card work-item"
                            key={v.id}
                            onClick={() => setSelected(v.id)}
                          >
                            <span className="pill">
                              {v.issue || visitState(v)}
                            </span>
                            <h3>{v.patient_name} ↗</h3>
                            <p>
                              {v.wall_time} · {v.provider}
                            </p>
                            <small>{v.owner || "Unassigned"}</small>
                          </button>
                        ))}
                    </section>
                  ))}
                </div>
              ) : (
                <section className="card table-wrap">
                  <table>
                    <thead>
                      <tr>
                        <th>Patient</th>
                        <th>Appointment · local time</th>
                        <th>Confirmation / reply</th>
                        <th>PMS outcome</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visible.slice(page * 10, page * 10 + 10).map((v) => (
                        <tr key={v.id}>
                          <td>
                            <button
                              className="link"
                              onClick={() => setSelected(v.id)}
                            >
                              {v.patient_name} →
                            </button>
                          </td>
                          <td>
                            {v.wall_time}
                            <small>{v.provider}</small>
                          </td>
                          <td>
                            <span className="pill">{v.confirmation}</span>
                            <small>{v.issue}</small>
                          </td>
                          <td>{v.outcome}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </section>
              )}
              <div className="toolbar">
                <span>
                  {visible.length} matching records · Page {page + 1}
                </span>
                <button disabled={!page} onClick={() => setPage((n) => n - 1)}>
                  Previous
                </button>
                <button
                  disabled={(page + 1) * 10 >= visible.length}
                  onClick={() => setPage((n) => n + 1)}
                >
                  Next
                </button>
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
function PatientDetail({
  visit: v,
  staff,
  act,
  busy,
  back,
  replies,
}: {
  visit: Visit;
  staff: string;
  act: Act;
  busy: boolean;
  back: () => void;
  replies: Reply[];
}) {
  const [note, setNote] = useState(""),
    [outcome, setOutcome] = useState("attempted"),
    [details, setDetails] = useState(v.details),
    [adult, setAdult] = useState(v.adult_authorized),
    [sms, setSms] = useState(v.sms_allowed),
    [email, setEmail] = useState(v.email_allowed),
    [tab, setTab] = useState("Follow-up");
  async function save(e: FormEvent) {
    e.preventDefault();
    if (
      await act(
        "/visits/" + v.id,
        { staff, note, outcome, version: v.version },
        "PATCH",
      )
    )
      setNote("");
  }
  return (
    <>
      <button className="link" onClick={back}>
        ← Back to clinic
      </button>
      <p>
        {v.wall_time} · {v.confirmation} · PMS: {v.outcome}
      </p>
      <div className="patient-layout">
        <aside className="card">
          <h2>Patient details</h2>
          <p className="pill">
            {v.verified ? "Locally verified" : "Not verified"}
          </p>
          {v.sms_stopped && <p>SMS opted out</p>}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              act(
                "/visits/" + v.id + "/contact",
                {
                  staff,
                  details,
                  adult_authorized: adult,
                  sms_allowed: sms,
                  email_allowed: email,
                },
                "PATCH",
              );
            }}
          >
            {(["birthdate", "sms", "email", "language"] as const).map((f) => (
              <Field key={f} label={f === "sms" ? "Mobile phone" : f}>
                <input
                  type={f === "birthdate" ? "date" : "text"}
                  value={details[f] || ""}
                  onChange={(e) =>
                    setDetails({ ...details, [f]: e.target.value })
                  }
                />
              </Field>
            ))}
            <label className="check">
              <input
                type="checkbox"
                checked={adult}
                onChange={(e) => setAdult(e.target.checked)}
              />
              Authorized adult contact verified
            </label>
            <label className="check">
              <input
                type="checkbox"
                checked={sms}
                onChange={(e) => setSms(e.target.checked)}
              />
              SMS permission
            </label>
            <label className="check">
              <input
                type="checkbox"
                checked={email}
                onChange={(e) => setEmail(e.target.checked)}
              />
              Email permission
            </label>
            <button disabled={busy}>Verify local details</button>
          </form>
          <details>
            <summary>Original PMS values</summary>
            <pre>{JSON.stringify(v.source_contact, null, 2)}</pre>
          </details>
        </aside>
        <section>
          <div className="tabs">
            {["Follow-up", "Appointments", "Activity log"].map((t) => (
              <button
                key={t}
                aria-pressed={t === tab}
                onClick={() => setTab(t)}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="card">
            {tab === "Follow-up" ? (
              <>
                <h2>Follow-up</h2>
                <p className="pill">{v.issue || visitState(v)}</p>
                <p>Assigned to {v.owner || "nobody"}</p>
                <button
                  disabled={busy || !!v.owner}
                  onClick={() =>
                    act(
                      "/visits/" + v.id,
                      { staff, outcome: "assign" },
                      "PATCH",
                    )
                  }
                >
                  Assign to me
                </button>
                {replies
                  .filter((r) => r.candidate_ids.includes(v.id))
                  .map((r) => (
                    <blockquote key={r.id}>
                      {r.body}
                      <small>
                        {r.result} · candidate visits:{" "}
                        {r.candidate_ids.join(", ")}
                      </small>
                    </blockquote>
                  ))}
                <form onSubmit={save}>
                  <Field label="Outcome">
                    <select
                      value={outcome}
                      onChange={(e) => setOutcome(e.target.value)}
                    >
                      <option value="attempted">
                        Contact attempted · keep open
                      </option>
                      <option value="confirmed">
                        Confirmed by staff clarification
                      </option>
                      <option value="canceled">
                        Canceled · stop reminders
                      </option>
                      <option value="rescheduled">
                        Rescheduled · stop reminders
                      </option>
                    </select>
                  </Field>
                  <Field label="Follow-up note">
                    <textarea
                      required
                      maxLength={1000}
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                    />
                  </Field>
                  <button disabled={busy || v.owner !== staff}>
                    Save follow-up
                  </button>
                </form>
              </>
            ) : tab === "Appointments" ? (
              <>
                <h2>Appointment</h2>
                <p>
                  {v.wall_time} · {v.provider}
                </p>
                <p>
                  {v.confirmation} · PMS outcome: {v.outcome}
                </p>
                <p>Staff disposition: {v.disposition || "None"}</p>
              </>
            ) : (
              <>
                <h2>Activity log</h2>
                {!v.activities.length && <p>No staff activity recorded.</p>}
                {v.activities.map((a) => (
                  <article key={a.id}>
                    <h3>
                      {a.outcome} · {a.staff}
                    </h3>
                    <p>{a.note}</p>
                    <small>{new Date(a.created_at).toLocaleString()}</small>
                  </article>
                ))}
              </>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
function Inbox({
  visits,
  replies,
  act,
  busy,
}: {
  visits: Visit[];
  replies: Reply[];
  act: Act;
  busy: boolean;
}) {
  const [id, setId] = useState(String(visits[0]?.id || "")),
    [channel, setChannel] = useState("sms"),
    [body, setBody] = useState(""),
    [eventId, setEventId] = useState(crypto.randomUUID());
  const v = visits.find((v) => String(v.id) === id),
    history = v?.messages.filter((m) => m.channel === channel) || [];
  async function send(e: FormEvent) {
    e.preventDefault();
    if (
      await act("/replies", { visit_id: id, channel, body, event_id: eventId })
    ) {
      setBody("");
      setEventId(crypto.randomUUID());
    }
  }
  return (
    <>
      <Field label="Patient">
        <select
          value={id}
          onChange={(e) => {
            setId(e.target.value);
            setBody("");
            setEventId(crypto.randomUUID());
          }}
        >
          {visits
            .filter(
              (v, i, all) =>
                all.findIndex((x) => x.patient_id === v.patient_id) === i,
            )
            .map((v) => (
              <option key={v.id} value={v.id}>
                {v.patient_name}
              </option>
            ))}
        </select>
      </Field>
      <div className="tabs">
        <button
          aria-pressed={channel === "sms"}
          onClick={() => {
            setChannel("sms");
            setEventId(crypto.randomUUID());
          }}
        >
          Text messages
        </button>
        <button
          aria-pressed={channel === "email"}
          onClick={() => {
            setChannel("email");
            setEventId(crypto.randomUUID());
          }}
        >
          Email
        </button>
      </div>
      <h2>Message history</h2>
      {!history.length && (
        <p>
          No simulated {channel === "sms" ? "texts" : "emails"} for this patient
          yet.
        </p>
      )}
      {history.map((m) => (
        <article className="bubble" key={m.id}>
          <small>
            Clinic reminder · {m.delivery} ·{" "}
            {new Date(m.created_at).toLocaleString()}
          </small>
          <p>{m.body}</p>
        </article>
      ))}
      {replies
        .filter(
          (r) => v && r.channel === channel && r.candidate_ids.includes(v.id),
        )
        .map((r) => (
          <article className="bubble reply" key={r.id}>
            <small>Your reply · {r.result}</small>
            <p>{r.body}</p>
          </article>
        ))}
      <form className="card" onSubmit={send}>
        <Field label="Your reply">
          <textarea
            required
            maxLength={2000}
            value={body}
            onChange={(e) => {
              setBody(e.target.value);
              setEventId(crypto.randomUUID());
            }}
          />
        </Field>
        <p className="muted">
          YES confirms an unambiguous current visit. NO requests review. STOP
          suppresses SMS.
        </p>
        <button disabled={busy || !v}>Send simulated reply</button>
      </form>
    </>
  );
}
function Leadership() {
  const [month, setMonth] = useState(today().slice(0, 7)),
    [metrics, setMetrics] = useState<Metric[]>([]),
    [error, setError] = useState("");
  useEffect(() => {
    const c = new AbortController();
    request<Metric[]>("/leadership?month=" + month, "GET", undefined, c.signal)
      .then(setMetrics)
      .catch((e) => {
        if (!c.signal.aborted) setError(String(e));
      });
    return () => c.abort();
  }, [month]);
  return (
    <>
      <div className="title-row">
        <h1>Appointment outcomes</h1>
        <Field label="Reporting month">
          <input
            type="month"
            value={month}
            onChange={(e) => {
              setMonth(e.target.value);
              setMetrics([]);
            }}
          />
        </Field>
      </div>
      {error && <p role="alert">{error}</p>}
      <div className="stats">
        {metrics.map((m) => (
          <section className="card" key={m.clinic}>
            <h2>{m.clinic}</h2>
            <p>{m.total} recorded visits</p>
            <div className="bar">
              <span
                style={{
                  width: `${m.total ? (m.completed / m.total) * 100 : 0}%`,
                }}
              />
            </div>
            <strong className="big-number">
              {m.total ? ((m.completed / m.total) * 100).toFixed(1) + "%" : "—"}
            </strong>
            <p>Completed / recorded visits</p>
          </section>
        ))}
      </div>
      <section className="card table-wrap">
        <h2>Clinic comparison</h2>
        <table>
          <thead>
            <tr>
              <th>Clinic</th>
              <th>Completed</th>
              <th>Rescheduled</th>
              <th>Canceled</th>
              <th>Unknown</th>
            </tr>
          </thead>
          <tbody>
            {metrics.map((m) => (
              <tr key={m.clinic}>
                <td>{m.clinic}</td>
                <td>{m.completed}</td>
                <td>{m.rescheduled}</td>
                <td>{m.canceled}</td>
                <td>{m.unknown}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <details>
          <summary>How rates are calculated</summary>
          <p>
            Completed PMS outcomes divided by all recorded visits in the
            selected local appointment month, including future visits. Confirmed
            does not mean completed. These records cannot establish no-shows or
            reminder causation.
          </p>
        </details>
      </section>
      <details className="card">
        <summary>Reminder activity and follow-up</summary>
        {metrics.map((m) => (
          <p key={m.clinic}>
            {m.clinic}: {m.messages} fake message attempts · {m.confirmed}{" "}
            confirmed visits · {m.holds} visits with open issues. Counts use the
            selected appointment month.
          </p>
        ))}
      </details>
    </>
  );
}
