﻿import {defineConfig} from '@playwright/test'
export default defineConfig({testDir:'browser',timeout:90000,expect:{timeout:15000},use:{baseURL:'http://127.0.0.1:5181',channel:'msedge',headless:true},workers:1,reporter:'list'})
