import { test, expect } from "@playwright/test";
test("three workspaces, scoped clinics, email reply and narrow layout", async ({
  page,
}) => {
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Workspaces", exact: true }),
  ).toBeVisible();
  await page.screenshot({
    path: "../review/screenshots/workspaces.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: /Open front desk/ }).click();
  await expect(
    page.getByRole("heading", { name: "Patient flow", exact: true }),
  ).toBeVisible();
  await expect(page.getByText(/^Austin.*Taylor$/)).toBeVisible();
  await page.screenshot({
    path: "../review/screenshots/board.png",
    fullPage: true,
  });
  await page.getByRole("combobox", { name: /^Clinic/ }).selectOption("2");
  await expect(page.getByText(/^Phoenix.*Taylor$/)).toBeVisible();
  await expect(page.getByText(/^Austin.*Taylor$/)).toHaveCount(0);
  await page.getByRole("button", { name: "Appointments", exact: true }).click();
  await expect(page.getByLabel("Jump to date")).toBeVisible();
  await page.getByRole("button", { name: /Workspaces/ }).click();
  await page.getByRole("button", { name: /Open leadership/ }).click();
  await expect(
    page.getByRole("heading", { name: "Appointment outcomes" }),
  ).toBeVisible();
  await expect(page.getByRole("heading", { name: "Austin", exact: true })).toBeVisible();
  await expect(page.getByRole("heading", { name: "Phoenix", exact: true })).toBeVisible();
  await page.screenshot({
    path: "../review/screenshots/leadership.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: /Workspaces/ }).click();
  await page.getByRole("button", { name: /Open patient inbox/ }).click();
  await expect(
    page.getByRole("heading", { name: "Patient inbox" }),
  ).toBeVisible();
  await page.getByRole("combobox", { name: /^Clinic/ }).selectOption("1");
  await page
    .getByRole("combobox", { name: /^Patient/ })
    .selectOption({ label: "Demo Patient 104" });
  await page.getByRole("button", { name: "Email", exact: true }).click();
  await expect(page.getByText(/Reply YES to confirm/).first()).toBeVisible();
  await page.getByLabel("Your reply").fill("YES");
  await page.getByRole("button", { name: "Send simulated reply" }).click();
  await expect(page.getByRole("status")).toContainText("Confirmed");
  await page.screenshot({
    path: "../review/screenshots/email.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(
    page.getByRole("button", { name: "Send simulated reply" }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: "../review/screenshots/mobile.png",
    fullPage: true,
  });
});
