﻿# Input preflight receipt

Before application scaffolding, `py quality/verify_harness.py` returned exit 0:

```
PASS: Clean-room handoff files present; 10 verified PNG screenshots; original PDF present; integrity manifest verified.
NOTE: No application quality checks have run yet.
```

Input: Apex_Appointment_Flow_Harness_V2.1.zip
SHA-256: 16174378b8a1d84d30fedd1efdeb685da546153eddf0eb919adb8d36a570086d

The byte-identical input is retained as reference/input-harness.zip. Extract that archive into a separate empty folder and run its verifier to reproduce input integrity. MANIFEST.sha256 at project root is the original input manifest, not the rebuilt application's manifest: progress notes and freeze checklist are intentionally changed during implementation. Application results are in evidence/quality-gate.txt. The deliverable ZIP has its own file manifest and SHA-256 receipt.

All ten supplied screenshots, including the empty Email-tab view, were visually inspected. Runtime behavior was derived from the PDF and written specification, not inferred from screenshot interiors. No earlier implementation or review archive was accessed.
