﻿# Freeze checklist — clean-room rebuild V2.1

- [x] Original input passed preflight before app code; all ten PNGs/PDF verified. Byte-identical input retained and independently re-extracted/reverified at completion.
- [x] Implemented in a new independent repository; prior application source/archives never opened. No remote configured; no upstream synchronization or push possible.
- [x] `py quality/run_checks.py`: all 7 categories PASS. Rails: 26 tests, 86 assertions, zero failures/errors/skips; RuboCop: 37 files, no offenses; Brakeman: zero errors/warnings; React lint/types/two tests/production build PASS. See evidence/quality-gate.txt.
- [x] Final Edge/Playwright smoke: 1 passed in 17.5 seconds (test body 12.3 seconds). Covers workspace entry, clinic switch, appointment navigation, aggregate leadership loaded, email YES through real backend, 390px layout with no horizontal overflow. See evidence/browser.txt and screenshots/.
- [x] Visually inspected workspace, board, leadership and mobile captures. Broad visual identity retained; no pixel-perfect claim.
- [x] Separate independent review completed; four findings corrected and source rechecked. Verdict: Ready for local assessment/demo gates. Startup runner also reviewed.
- [x] Actual `py dev.py` startup verified: both servers returned HTTP 200. Stale Windows PID issue corrected with per-run PID files. A runtime request marker proved reply body is filtered from routine logs after restart. See evidence/startup.txt and logging.txt.
- [x] README, diagram, honest AI_USAGE, candidate decision notes and acceptance/gap report included. User-visible copy reviewed for functional meaning.
- [ ] Candidate-authored DECISIONS.md and live defense: intentionally remain Joshua's work; not falsely attributed to him.
- [ ] Hosted CI, production-volume performance, live provider delivery, real auth, production SELECT-only role, another-machine clean install and human acceptance: not claimed or performed.

Source is locally committed before packaging; BUILD_INFO.json in the ZIP records its exact commit. Package manifest verifies extracted bytes; adjacent SHA-256 receipt verifies ZIP bytes. This is a source-only archive: runtime databases, dependencies, build output, .git, IDE files and keys are excluded. Install dependencies using README/dev.py.

Known scope limits: manual batches, adult authorization asserted by demo staff, conservative recurring/old-version reply escalation, no automatic guarantor selection, no dedicated unmatched-case resolution workflow, no bulk clarification or monthly-history analytics. Outcome reporting is descriptive and includes future unknowns. See ACCEPTANCE.md for evidence boundaries.

For later blind comparison, preserve this ZIP and hash receipt unchanged. Do not inspect/import a prior implementation until Joshua explicitly requests comparison. This freeze does not authorize submission or external publication.
