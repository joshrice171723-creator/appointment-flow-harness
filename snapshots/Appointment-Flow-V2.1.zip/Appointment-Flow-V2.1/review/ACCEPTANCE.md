﻿# Acceptance evidence

| Area | Actual result / evidence |
|---|---|
| Harness preflight | PASS before code, original input preserved; INPUT_PREFLIGHT.md |
| Official source/confirmation/SMS/email/scoped staff core | PASS focused Rails tests; workflow_test.rb and clinic_test.rb |
| Reschedules, recurrent ambiguity, late replies, wrong recipient | PASS safety tests; conservative staff escalation is intentional |
| Repeated/concurrent send and event replay | PASS PostgreSQL constraints and 3 simultaneous batch test |
| Opt-outs, unsafe minors, language, verification conflicts | PASS focused tests; guardian authorization is an explicit staff assertion |
| Empty refresh and source write boundary | PASS empty-source rollback and runtime readonly model tests; SELECT-only runtime DB role is still a production requirement |
| DST and no post-start sends | PASS gap/fold/Phoenix and start-time tests |
| Leadership privacy and totals | PASS allowlisted aggregate keys and denominator assertions; no causal no-show claims |
| Staff ownership and invalid save | PASS request tests; network-failure draft handling inspected, not exhaustively browser-tested |
| UI lint/types/tests/build | PASS all configured categories; quality-gate.txt |
| Independent review | Final source verdict Ready for local assessment/demo gates after four fixes |
| Candidate decisions / live defense | NOT DONE: must be personally authored/performed by Joshua |

Extended cuts: no automatic guarantor selection, dedicated unmatched-case resolution lifecycle, multi-visit bulk clarification, monthly-history analytics, or calendar grid rendering (date/week navigation plus table is provided). No pixel-perfect claim. These cuts do not change the assignment's core SMS/email/confirmation/dashboard behavior. No production-volume performance or human acceptance is claimed.
