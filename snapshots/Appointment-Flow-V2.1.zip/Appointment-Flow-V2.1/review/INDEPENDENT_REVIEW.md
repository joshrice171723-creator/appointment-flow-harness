﻿# Independent review

Verdict: **Needs fixes** at initial review. This is an independent source review of the new application, not a test-pass or human acceptance certificate. The implementer may append dispositions below after verified fixes.

## Findings

1. **Blocking — source verified, not executed:** `backend/app/models/inbound_reply.rb:26` confirms a historical sender without checking it is the current permitted recipient. `SourceRefresh` hashes patient/clinic/time/status, not phone/email. If unverified PMS contact changes after a send, the old recipient's YES still matches the old message and can confirm the visit. Require `visit.contact.recipient(visit.source_contact, channel) == sender` and add a changed-recipient regression for SMS/email. Hold policies alone do not cover unverified contact changes.
2. **Major — source verified:** `backend/app/models/inbound_reply.rb:31` only creates visit work for IDs from matching historical sent messages. An unknown reply has zero IDs, so its review result is stored but no board card is produced; `frontend/src/App.tsx` displays replies only when candidate IDs include a displayed visit. Provide a clinic-scoped unmatched-reply review section, without guessing an appointment. This is an extended behavior requirement; explicitly record any deliberate incomplete resolution workflow.
3. **Major — source verified:** `backend/config/initializers/filter_parameter_logging.rb:6` lacks filters for reply body, mobile number, birthdate and staff note. Development defaults also log SQL bind values, including persisted message/contact data. Filter sensitive parameters and suppress routine SQL DEBUG output (for example development INFO level). Verify logs with synthetic distinctive markers.
4. **Major — source verified:** `frontend/src/App.tsx` Inbox reuses `eventId` after rejection/network uncertainty while allowing body edits. A reply can commit, lose its response, then a different body reuses that ID; backend returns the old event and UI clears the new draft as successful. Keep idempotency tied to an immutable payload until the uncertain result is resolved; generate a new key when a deliberately new payload is submitted. Add a network-uncertainty UI regression.

No speculative production authentication finding: stub authentication is expressly in scope. Read-only PMS runtime model plus writable demo seed connection is an explicitly documented local limitation; a production SELECT-only role is not required to pretend this is production ready. Conservative staff review for multiple historical visits/old revisions is documented rather than a false confirmation bug.

## Representative operation and costs

`WorkflowController#batch` -> `ReminderBatch.call` -> `SourceRefresh.call` reads the clinic's joined PMS appointments/patients, locks its clinic and updates app-owned visit/contact records; successful refresh records synced_at. The batch then locks the same clinic, applies eligibility and writes fake messages with a unique visit/version/step database key. There is no live transport I/O inside this transaction. Concurrent clinic runs serialize; unrelated clinics do not share that explicit row lock.

Source-inferred costs: refresh materializes all clinic source rows, then uses per-row visit/contact lookups and writes. Batch scans all clinic visits twice, preloads all their message history, and separately queries each visit contact; it does not bound work to upcoming time ranges. Other-clinic rows are filtered, but historical same-clinic data increases work and lock duration. Front-desk index similarly returns all visits/replies and paginates only in React. These are maintainability/scale limits, not measured regressions or grounds to add caches/queues. A future volume change should first scope upcoming queries/preload contacts and measure full operation time.

A plausible cadence change belongs in `ReminderBatch`'s due-step selection and WINDOW constant, with `workflow_test.rb` repeated-send/window/no-burst tests adjusted to the new behavior. Do not change React to implement reminder rules.

Failure trace: an empty PMS snapshot raises before writes; the with_lock transaction unwinds, then rescue persists sync_error outside that rollback. `ReminderBatch` returns false without sends; controller returns 503. A write failure inside fake send should roll back messages and issue changes together; the controller does not currently turn arbitrary database failures into a friendly business result, so UI uses its error path. This is source reasoning; I did not inject faults or measure SQL.

## Done well

- Clinic scoping is enforced in controller record lookup, with a cross-clinic mutation test.
- Confirmation is versioned separately from PMS completion; DST folds/gaps are held rather than guessed.
- Leadership creates an aggregate allowlist response and has a key-level privacy test.
- Unique send/event constraints complement per-clinic row locks; fake delivery is honestly represented as simulated.

## Evidence boundary

Read AGENTS.md, independent-review prompt, rubric, assessment requirements, acceptance matrix, all new domain models, workflow controller, migration, frontend App and source tests, and local runner. Inspected current untracked additions; no older repository or ZIP opened. No database tests, browser checks, benchmarks, packaging extraction or full quality runner executed by this reviewer; implementer owns those gates. Review references describe the initial source and may move after formatting. Candidate-authored DECISIONS and live defense are still human work.

## Focused re-review of corrections

Inspected current source after implementation corrections, without executing database tests:

- Finding 1: **Resolved in source.** `InboundReply` now requires a delivered message for the current version and exact equality with the current permitted recipient. The changed-phone regression and known-unsolicited reply regression are present. Automated outcomes remain the implementer's gate evidence.
- Finding 2: **Partially resolved at re-review.** Replies from a known current contact now receive candidate IDs and create visible staff work even without previous sends. Truly unmatched replies still require the promised clinic review section; no such section was present in the formatted App.tsx at this inspection. This remaining item is extended workflow completeness, not evidence of wrong confirmation.
- Finding 3: **Resolved in source.** Sensitive reply/contact/note parameters are filtered and development INFO level suppresses ordinary SQL DEBUG binds. No distinctive-marker runtime log check was run by the reviewer.
- Finding 4: **Resolved in source for changed payloads.** Body edits, patient selection and channel changes generate a new event ID; unchanged retry retains its key. A network-failure UI regression remains desirable evidence, not claimed executed here.
- DST wall parsing now creates neutral UTC components before IANA local-period interpretation. The existing gap/fold focused test remains the appropriate automated proof.
- Prettier formatting removes the initial compressed JSX presentation concern.

Current verdict: **Needs fixes for remaining unmatched-reply visibility**, then ready for the implementer's final automated/runtime gates. No other blocking finding was identified in this focused source pass. This is not certification of unexamined paths or production readiness.

## Final source disposition

Verified the added clinic-scoped unmatched section in `frontend/src/App.tsx:347–353`: zero-candidate replies now display their body, channel and review result before Demo controls, with an instruction to clarify patient/visit before recording an outcome. Finding 2 is **resolved for visibility**. A dedicated unmatched-case resolution lifecycle remains a documented extended-workflow limitation; no automatic appointment guess was added.

**Final source-review verdict: Ready for local assessment/demo gates.** All four initial findings have source corrections inspected independently. This verdict does not replace the final automated runner, browser evidence, extracted-package validation, candidate-authored decisions or human acceptance. Backend 26-test/86-assertion pass was reported by the implementer, not independently rerun here. No additional broad review was performed after this focused correction check.

## Local runner source check

Inspected only the current `dev.py` after the Windows PID/startup correction; no commands, servers, databases or tests were run by this reviewer. Each Rails launch receives a runner-specific PID-file path; readiness waits for both Rails `/api/clinics` and the frontend, while checking owned children for early exit. Cleanup targets only still-live child PIDs started by this runner, using Windows task-tree termination for npm descendants. No new blocking source defect was identified in this narrow check. Startup/readiness/cleanup success still requires the implementer's runtime self-check; this review makes no cross-platform execution claim. Final source-review verdict remains Ready for local assessment/demo gates.
