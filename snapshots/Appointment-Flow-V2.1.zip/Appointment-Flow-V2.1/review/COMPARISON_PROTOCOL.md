# Post-freeze comparison protocol (DO NOT perform during development)

Purpose: compare the new independently built application with the old baseline only **after** the new code is complete, tested and frozen.

Before comparison:
1. Record new build commit hash and environment versions.
2. Record all tests and quality gates with raw results; freeze `DECISIONS.md` and architecture notes.
3. Create a reproducible test fixture set and document known gaps.
4. Ask the user to **explicitly authorize** opening the original project.

After authorization, compare on the same feature scenarios:
- Correctness in S01–S20; failures and safety regressions.
- Rails/React readability assessed by a human blind-review rubric, not code-size alone.
- Architectural complexity: unnecessary layers and cross-file indirection.
- Feature completeness, UI state coverage, ease of local setup, testing and documentation.
- Engineering ownership: the candidate can explain why each decision was made and change it live.

Don't use the old code to train/refine the new implementation before freezing it. Record all deviations and exclusions in the comparison.
