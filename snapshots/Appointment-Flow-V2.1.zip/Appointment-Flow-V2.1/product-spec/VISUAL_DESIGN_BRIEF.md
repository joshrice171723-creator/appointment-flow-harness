# Visual design brief — reference, not pixel-perfect demand

Ten supplied screenshots show an understated internal healthcare dashboard. Recreate its broad visual language while favoring usable, accessible, straightforward React code.

- Neutral warm off-white page backgrounds; white cards with fine gray-green borders and subtle shadows.
- Dark evergreen headings and action buttons; restrained muted green-gray dashboard surfaces; small color-coded issue/status pills.
- Large editorial-style serif headings for sections, readable sans-serif body/controls, generous whitespace.
- Top brand/navigation band with Apex appointment-flow identity and Workspace navigation.
- Landing page: three large entry cards aligned horizontally on wide viewports (Front desk, Apex leadership, Patient); responsive stacking for narrow widths.
- Front desk: summary counters, filter/search strip, two-column issue board with cards. Content prioritizes open work.
- Appointments: week navigation/date picker, date chips, filter tabs, clean visit table.
- Patient: patient header and status, local appointment summary, contact-details sidebar, right-side Follow-up/Appointments/Activity tabs.
- Leadership: month picker, paired clinic outcome visualization, comparison table, expandable grouped metrics.
- Patient inbox: narrow centered form, clinic and patient dropdowns, Text messages / Email tabs, message timeline, reply composer.

Avoid unnecessary UI frameworks and animations. Use semantic HTML, keyboard-reachable interactions, visible focus indicators, informative validation/error messages, responsive layout, and appropriate contrast. Avoid copying synthetic screenshot dates/counts into static UI: derive numbers from seeded data.

**Evidence caveats:** the available fourth screenshot shows a *resolved patient detail state*, not an open follow-up edit form. The fifth screenshot shows *an open patient concern and contact info*, not the edit/verification modal. These interactions are specified in writing but not visually evidenced here. The Email-tab screenshot shows the selected patient with an empty simulated-email state. Use the written requirements for any behavior that cannot be observed directly in that view.
