# Behavior requirements — not architecture instructions

The following describes desired observable behavior from the user's written notes, supplementing the official assessment. Except for the required Rails + React stack, it intentionally does NOT prescribe class names, route shapes, folder structure, workers, databases beyond the official PMS boundary, or UI component architecture. If complexity conflicts with finishing the assessment, prioritize official requirements and record the deliberate tradeoff.

## B01 — Workspace entry and isolation
- Landing page offers Front desk, Apex leadership, and Patient demo workspaces.
- Front desk selects a clinic and staff identity; this is a demo sign-in **stub**, not real authentication.
- Front-desk board, appointments, patient details, filters and assignments are scoped to the selected clinic. Switching clinics does not leak or mutate other clinics' work.

## B02 — Appointment source and sync
- Appointments and patient/clinic data originate in the provided external PMS schema. The app must not write to the PMS source at runtime. Local app-owned records may store messaging, confirmation, follow-up, and verified contact state.
- A successful sync updates local views; expose the last successful sync time. Changed appointment time or status must be handled safely.
- A failed or timed-out source read must not cause sends using a falsely trusted partial update. A suspiciously empty sync must not silently erase in-flight work. Implement these outcomes using the simplest defensible approach.

## B03 — Reminder eligibility and cadence
- Use clinic-local dates/times; demonstration preference is an initial confirmation request around **7 days** ahead, optional backup email around **6 days** if initial SMS has no answer or failed, follow-up around **3 days**, final reminder around **1 day**. The official brief allows cadence judgment, so document any variation.
- Display date/time/clinic in each reminder. Ask YES to confirm or NO for help in confirmation requests. SMS includes opt-out instructions. Support English and Spanish where supported by seed data; unsupported language should not trigger guessed-language contact.
- Never send at or after appointment start; respect a configured clinic-local sending window (example used by the provided product: 10:00–18:00). Do not send bursts when several reminder steps were missed; coalesce where appropriate.
- Once a visit is confirmed, do not keep requesting confirmation; an optional final informational reminder may still be sent without requiring another YES.
- Repeated invocations, parallel attempts and restarts must not cause duplicate messages for the same logical send step. Record both successful and failed fake delivery attempts.

## B04 — Consent, contact holds and safety
- Respect available channels and channel-specific permission/opt-out, using synthetic contact data only.
- Missing/unusable phone and email, invalid contacts, conflicting verified details, unsafe guardian/minor authorization, missing age-relevant information, and unsupported language block unsafe outreach and create an actionable task instead.
- An opt-out must not be silently reset by later PMS reads. The sample demo recognizes an exact case-insensitive STOP command; malformed/uncertain variants should be safely escalated. This is **demo behavior**, not comprehensive telecom compliance advice.
- Staff can verify/correct local contact details, with a record of the change; the original PMS source remains unchanged. Corrections must affect eligibility on the next run.

## B05 — Reply interpretation
- The patient demo allows typed SMS or email replies. Replaying the same external reply must be idempotent.
- A clear YES from the expected unambiguous recipient can confirm the current visit. NO, ambiguous, shared-number, unrecognized, late, mismatched or stale-revision replies become visible to staff for review. Do not infer appointment identity from a shared family contact.
- An exact STOP suppresses future SMS for the relevant recipient/clinic. A post-appointment reply never retroactively confirms a completed visit.
- A changed appointment time after a confirmation requires a fresh decision about the new appointment version, not blind carryover.

## B06 — Front-desk work board
- Show counts: Needs attention, In progress, Resolved. Organize active work into appropriate columns; allow type filtering, patient search and pagination.
- Tasks include no confirmation/reply near appointment time, blocked outreach, failed delivery and replies needing review. Assigning/opening an item should identify who owns it without cross-clinic leakage.
- Staff can record attempted contact (remains open), confirmed/rescheduled/canceled (closes appropriately and affects further reminders), or clarify the appointment(s) to which an ambiguous reply belongs. Require a short note, record staff identity and time, and provide clear error states.
- Do not silently repeat a save after the network outcome is uncertain. Keep form input intact on rejection and give an understandable recovery path.

## B07 — Appointments
- Provide a week/day calendar, date jump and a clinic-scoped appointment table with filter tabs (All, Confirmed, Unconfirmed, Replies to review).
- Each visit shows the patient, local time, confirmation/reply state, provider/visit details as appropriate, its source-recorded appointment outcome, and a route to patient details/follow-up.
- For a simple outcome legend, PMS statuses can be displayed as Completed, Rescheduled, Canceled or Unknown. Never mislabel "confirmed" as "arrived" or "completed".

## B08 — Patient details
- Show patient demographics/contact facts with clear unverified/verified states and edits for birthdate, mobile, email and preferred language. Sample views display follow-up, appointments and activity log tabs.
- Present conflicts and actionable review when local verified contact data differs from the PMS. Record provenance and history. Do not require full profile management beyond this exercise.

## B09 — Leadership
- Offer reporting month, per-clinic outcomes and comparison table: recorded visits, completed, rescheduled, canceled, unknown. Example completion-rate definition: completed / recorded visits.
- Expandable sections can cover monthly history/reminder activity, contact holds, and contact/follow-up totals, with honest denominators and explanations of unavailable values.
- The PMS statuses do NOT prove no-shows or causation. Say what the metrics measure. Never return or display patient-identifying details to leadership, including in hidden responses and logs.

## B10 — Patient demo inbox
- Select clinic then fictional patient. Tabs for **Text messages** and **Email**, message history, and a typed reply form.
- Replies feed the same confirmation/opt-out/review logic used by any simulated inbound provider, and changes become visible to staff without editing patient or appointment records manually.

## B11 — Operability and deliverables
- One local startup command/path; deterministic synthetic seeds; documented fake send and fake inbound reply flow; automated tests.
- README explains how to run app, trigger reminders and simulate a reply.
- `ARCHITECTURE` illustrates components/data flow and confirmation state lifecycle.
- `AI_USAGE.md` records agent/tool use and corrections honestly. Candidate personally authors `DECISIONS.md` in own words.
