# Provenance and clean-room exclusions

Authorized inputs:
1. Original employer assignment PDF (provided by user).
2. Ten PNG screenshots of app UI (provided by user and preserved verbatim).
3. User-supplied behavioral notes **rewritten to omit old implementation file paths, class names, API routes, worker framework and source architecture**.
4. Public official Ruby/Rails, React and testing documentation solely for generic engineering conventions, never the old repository.

Explicitly excluded:
- All prior `appointment-flow` source code, README from its GitHub repo, tests, fixtures, database schema migrations, commits and PR history.
- Links or references to the user's earlier GitHub repository as a coding resource.
- The original unredacted application-specific Markdown specs (they referred to old code internals), which are **not distributed** in this clean-room ZIP.

The sanitized specs are behavioral expectations, **not** an assertion that the original application was bug-free or that its architecture should be copied. Discovered behavior contradictions should be documented and resolved with the assignment first.

All ten named UI screenshots are present. Do not assume any screenshot proves unseen user interactions.
