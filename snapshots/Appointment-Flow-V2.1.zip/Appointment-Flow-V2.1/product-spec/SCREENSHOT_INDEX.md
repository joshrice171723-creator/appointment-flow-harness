# Screenshot evidence index

These are the **actual PNGs available in this run**. Their numbers and filenames are labels only. The screenshots are permitted product/visual references, **not code or architecture references**.

| File | View | What can be observed | Resolution |
|---|---|---|---|
| `01-launch-workspaces.png` | Landing page | Three role/workspace cards; clinic and staff picker, navigation | 1440×1000 |
| `02-front-desk-board.png` | Front desk patient-flow board | Summary counts, active queues, search/filter/pagination and issue cards | 934×2048 |
| `03-appointments-table.png` | Appointments | Week/date navigation, state tabs, one-day visit table | 1440×1000 |
| `04-work-case-detail.png` | Resolved patient detail state | Patient header marked Resolved, patient sidebar, Follow-up history and collapsed resolved records; not a visible follow-up entry form | 1440×1075 |
| `05-patient-details.png` | Open patient follow-up state | Needs-attention patient, appointment warning, Assign to me and sidebar with unverified contacts; not a visible edit form | 1440×1121 |
| `06-operations-leadership.png` | Leadership collapsed | Clinic outcome totals, rates and closed details | 1440×1112 |
| `07-operations-expanded.png` | Leadership expanded | Monthly history, contact holds, follow-up metrics tables | 867×2048 |
| `08-patient-inbox-picker.png` | Patient inbox initial state | Clinic selection with empty rest of screen | 1440×1000 |
| `09-patient-conversation-reply.png` | Patient SMS conversation | Clinic/patient selectors, Text messages / Email tabs, SMS history and reply form | 1440×1479 |
| `10-patient-inbox-email.png` | Patient email tab | Selected clinic/patient, Email tab active, empty email history message | 1440×1000 |

## All ten screenshots present

`10-patient-inbox-email.png` depicts the selected patient's Email tab and its empty state. It does not establish how to compose, deliver, or simulate email replies beyond what is specified in the written behavior documents.

## Ambiguity reminders

- File `04-work-case-detail.png` displays a *resolved* follow-up history, **not** the actual Record follow-up form.
- File `05-patient-details.png` displays an open patient case with contact facts, **not** an expanded local verification editor.
- Sample seed counts, fictional patients and November 2026 dates illustrate states and are not required hard-coded data.
- Visual similarity is secondary to a functioning, readable and safe implementation.
