﻿# Candidate decision notes — AI-generated prompts, not Joshua's final narrative

- Explain why Rails domain operations own refresh, batch and inbound reply transactions; React is only the presentation/demo interface.
- Cadence chosen: 7/3/1 latest due, backup email days 6–4 or failed SMS. No post-start sends or continued confirmation requests. Why is a manual scheduler sufficient here?
- Clinic-local timestamps are interpreted with explicit IANA zones; ambiguous/nonexistent DST instants require staff. What would the actual clinic configuration process require?
- Source reads are complete per clinic and atomic locally. Empty reads fail closed; partial deletion is marked missing. Replication lag still exists. A production SELECT-only credential is required.
- Local contact changes retain source provenance. Adult authorization is a demo staff assertion; automatic guarantor selection is deliberately omitted because authority cannot be inferred safely.
- Historical messages make recurrence/reschedule matching conservative: old-version or multi-visit replies require staff clarification. Discuss a future verified per-request token protocol.
- Demo messages commit in the local transaction. Real network sends need outbox/idempotency/reconciliation; pretending fake delivery proves transport safety would be misleading.
- Leadership counts recorded PMS outcomes, including future unknowns. Completion rates are descriptive, not causal no-show evidence.
- Staff stub uses clinic path and Taylor/Jordan identity. Production needs actual auth and clinic grants. Do not describe this stub as secure authentication.
- Explain scale cost: bounded clinic batch with per-clinic serialization, indexed appointment start/source and send keys. No performance claim is based on a production-volume measurement.
- One more week: candidate's own priority and rationale, stronger contact/guardian workflow, provider integration design, measured volume tests, broader browser tests.

Final DECISIONS.md is intentionally not ghostwritten. Use these notes to write your own assumptions, alternatives and open questions.
