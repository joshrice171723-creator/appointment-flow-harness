﻿# Build log

## Stage 0 — established before application code
- `py quality/verify_harness.py`: PASS; original PDF and 10 PNGs verified against supplied manifest.
- Read official five-page PDF, all product-spec files, required engineering documents and all ten images. Email image shows an empty history only.
- No old source or archives accessed. Prior-session memory was consulted for generic evidence discipline only, not implementation.
- New workspace has no repository/remote. Initialize independent Git; no upstream exists to synchronize or push.
- Plan: Rails API + React/TypeScript, PostgreSQL source schema with read-only runtime models, app-owned visit snapshots/contact verification/messages/replies/follow-ups. Manual batch with per-clinic transactional locks and unique send keys; no network transport. Snapshot refresh atomically trusts complete nonempty reads; failure blocks sending. Version changes invalidate confirmation and stale replies. Explicit America/Chicago and America/Phoenix zones, rejecting ambiguous/nonexistent wall times. Adult-only outreach until local authorization verified; ambiguous shared contacts go to staff.
- Chosen cadence: latest due 7/3/1-day request, 6-day email backup; sending window 10–18 local; confirmed visits stop requests. Manual scheduler is intentional.
- UI: three workspaces, scoped work board, appointment date/table, local patient verification, SMS/email simulator, aggregate-only leadership.
- Check each slice, then all configured gates, UI smoke, separate independent reviewer, freeze and source-only ZIP in review folder. Candidate writes final DECISIONS; agent provides notes.

## Implementation and verification
- Built independent Rails 8.1.4.1 / Ruby 3.4.10 backend, PostgreSQL 17 read-side schema, React 19.3.1 / TypeScript 7 / Vite 8 frontend on Node 24.22.1. Lockfiles record exact transitive dependencies.
- Slices: source snapshot and contact boundary; fake cadence and replies; scoped staff/inbox/aggregate UI; focused safety tests and concurrency test; startup/docs and independent review.
- First backend pass exposed DST normalization on Windows; fixed parsing of local wall-clock components before timezone interpretation.
- Independent reviewer found old-recipient matching, unmatched reply visibility, request logging and mutable reply keys. Current source fixes were independently rechecked; review/INDEPENDENT_REVIEW.md retains findings and final disposition.
- Final configured gate: 26 backend tests, 86 assertions, zero failures/errors/skips; Ruby style and Brakeman passed; React lint, typecheck, two UI tests and production build passed. Full output in review/evidence/quality-gate.txt.
- No production performance benchmark, live transport, deployment, prior-code comparison or candidate live defense performed. Final candidate DECISIONS remains user-owned.

## Final runtime and freeze
- `py dev.py` started Rails and Vite, waited for both HTTP endpoints, then reported Ready. Windows stale-PID and child-tree handling fixed and separately source-reviewed.
- Final real-browser smoke passed in 17.5 seconds; clinic scopes, all workspaces, loaded leadership data, email confirmation and 390px overflow check verified.
- After restart, distinctive inbound body marker was filtered from routine INFO logs. Original harness ZIP was re-extracted and its preflight passed again.
- Package is source-only with per-file hashes and an adjacent ZIP SHA-256. No remote exists; no push or submission performed.
