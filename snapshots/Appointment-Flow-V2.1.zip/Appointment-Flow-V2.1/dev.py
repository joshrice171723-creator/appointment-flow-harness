﻿"""Local development runner; uses installed Ruby, Node and PostgreSQL binaries."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import time
from urllib.request import urlopen
from urllib.error import URLError

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--setup', action='store_true', help='Install locked dependencies, migrate and reset fictional demo records')
    args = parser.parse_args()
    pg_dir = Path(os.environ.get('POSTGRES_BIN', r'C:\Program Files\PostgreSQL\17\bin'))
    env = os.environ.copy()
    env['PATH'] = str(pg_dir) + os.pathsep + env['PATH']
    # RubyMine may inject a global-only npm option into child processes.
    for key in list(env):
        if key.lower() == 'npm_config_allow_scripts':
            del env[key]
    npm = shutil.which('npm.cmd') or shutil.which('npm')
    bundle = shutil.which('bundle.bat') or shutil.which('bundle')
    if not npm or not bundle:
        raise SystemExit('Install Ruby/Bundler and Node/npm, and put them on PATH.')
    def run(argv, cwd=ROOT):
        subprocess.run([str(x) for x in argv], cwd=cwd, env=env, check=True)
    cluster = ROOT / '.local-postgres'
    if not cluster.exists():
        run([pg_dir/'initdb', '-D', cluster, '-U', 'apex_demo', '-A', 'trust', '--no-locale', '-E', 'UTF8'])
    status = subprocess.run([str(pg_dir/'pg_ctl'), '-D', str(cluster), 'status'], stdout=subprocess.DEVNULL)
    if status.returncode:
        run([pg_dir/'pg_ctl', '-D', cluster, '-l', cluster/'server.log', '-o', '-p 55421 -h 127.0.0.1', 'start'])
    if args.setup:
        run([bundle, 'install'], ROOT/'backend')
        run([npm, 'ci', '--userconfig=NUL'], ROOT/'frontend')
        run(['ruby', 'bin/rails', 'db:create', 'db:migrate', 'db:seed'], ROOT/'backend')
    children = []
    try:
        for command, folder in [(['ruby', 'bin/rails', 'server', '-b', '127.0.0.1', '-p', '3181', '--pid', f'tmp/pids/demo-{os.getpid()}.pid'], 'backend'), ([npm, 'run', 'dev'], 'frontend')]:
            children.append(subprocess.Popen(command, cwd=ROOT/folder, env=env))
        print('Starting Rails and React; waiting for both servers...', flush=True)
        deadline = time.monotonic() + 300
        while True:
            if any(p.poll() is not None for p in children):
                raise RuntimeError('An app server exited; see its error above.')
            try:
                for url in ['http://127.0.0.1:3181/api/clinics', 'http://127.0.0.1:5181']:
                    with urlopen(url, timeout=2) as response:
                        assert response.status == 200
                break
            except (URLError, TimeoutError):
                if time.monotonic() >= deadline:
                    raise RuntimeError('Servers were not ready within 5 minutes.')
                time.sleep(1)
        print('Ready: http://127.0.0.1:5181 - Ctrl+C stops app servers. PostgreSQL stays local.', flush=True)
        while all(p.poll() is None for p in children):
            time.sleep(1)
    finally:
        for child in children:
            if child.poll() is None:
                if os.name == 'nt':
                    subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    child.terminate()
        for child in children:
            child.wait(timeout=15)

if __name__ == '__main__':
    main()
