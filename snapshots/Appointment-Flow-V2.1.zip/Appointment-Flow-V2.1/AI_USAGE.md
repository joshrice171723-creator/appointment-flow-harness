﻿# AI usage

Codex implemented this clean-room rebuild using the supplied PDF, ten screenshots and sanitized specifications. Tools: PowerShell, Ruby/Rails generators, Vite, PostgreSQL, Python, package registries, automated tests and browser automation. A separate agent session is used for the required final review. No old implementation or prior ZIP was opened. Prior-session memory was consulted only for general evidence/reporting discipline before the clean-room instructions were read; it supplied no application design or source.

The agent chose the architecture, assumptions and test cases. Joshua requested the rebuild, preflight gate and review-folder package. This file does not claim Joshua personally authored or accepted any implementation decision. He must write DECISIONS.md and perform the live defense himself.

Corrections during implementation: isolated PostgreSQL rather than modifying an existing service; removed inherited npm install settings in child processes only; added staff revision verification; held ambiguous DST wall times; used conservative staff review for old revisions/shared contacts. Actual gate and reviewer outcomes are recorded in the freeze checklist.

Public version references consulted: https://rubyonrails.org/2026/11/4/Rails-8.0.5.2-and-8.1.4.1-have-been-released and https://react.dev/versions. Exact installed package versions are pinned in lockfiles.
