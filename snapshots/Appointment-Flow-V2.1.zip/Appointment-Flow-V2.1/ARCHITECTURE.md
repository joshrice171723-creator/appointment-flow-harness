﻿# Architecture

```mermaid
flowchart LR
  R[React workspaces] -->|clinic scoped JSON| C[Rails controller]
  C --> S[SourceRefresh]
  P[(Read-only PMS schema)] --> S
  S --> V[(App-owned visits and contacts)]
  C --> B[ReminderBatch]
  V --> B
  B --> M[(Fake messages: sent / failed)]
  C --> I[InboundReply]
  M --> I
  I --> V
  C --> A[(Staff activity and local verification)]
  C --> L[Aggregate-only leadership query]
```

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: source revision
  Unconfirmed --> Confirmed: unambiguous current YES / staff clarification
  Unconfirmed --> Review: unsafe contact / ambiguous NO or reply
  Confirmed --> Review: conflicting later intent
  Review --> Confirmed: staff clarification
  Confirmed --> Unconfirmed: PMS revision changes
  Unconfirmed --> Suppressed: PMS ended / staff canceled or rescheduled
```

SourceRefresh owns its transaction and clinic lock; a failed read rolls back snapshot writes then persists sync_error outside that rollback. ReminderBatch refreshes first, locks the clinic, checks contact/time/cadence rules and inserts a uniquely keyed fake send. InboundReply serializes against the same clinic, records the unique external event, then changes confirmation only when current recipient/revision/age/time checks pass. Fake messages and state writes commit together; no real I/O occurs.

Staff confirmations refresh before locking and require the revision shown in their form. Local contact edits record an audit entry but never touch pms tables. Leadership builds a separate allowlisted aggregate response. The demo clinic selector is an explicit identity stub, not production authorization.
