# Primary agent entrypoint

Open `RUN_THIS_IN_RUBYMINE.md` and execute it in order. **Do not** execute an old pre-code-only bootstrap prompt that stops the task after planning. First validate the harness and establish a plan; then implement the new application independently in the same fresh workspace. Read `AGENTS.md` for all source isolation and quality rules. Never inspect the original appointment-flow repository or its history.
