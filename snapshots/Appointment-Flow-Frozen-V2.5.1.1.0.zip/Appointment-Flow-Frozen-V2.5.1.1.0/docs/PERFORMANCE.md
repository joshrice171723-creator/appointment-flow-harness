# Performance

Performance is the elapsed time of a complete operation and how its database work, application work, and lock scope grow with data or use.

| Dimension | Poor example | Better example |
|---|---|---|
| Data scope | Load the entire record history for a dated, paginated view. | Filter to the requested owner and time window in Active Record, and retrieve the page before loading its related data. |
| Repeated work | Look up or prepare the same parent record for every child in a batch. | Fetch the needed records once and reuse the result. |
| Existence and aggregation | Materialize records for a boolean or issue separate counts for each status. | Use a scoped `exists?` or `group(:status).count` when it answers the same question. |
| Writes | Update one parent timestamp for every child processed. | Record one logically shared update in the transaction that commits the work. |
| Locks and retries | Serialize independent work or repeat already committed work after a partial failure. | Match the lock to the consistency boundary and verify what a retry repeats or skips. |
| Measurement | Time a helper in isolation or count one query that returns an entire history. | Measure the complete caller operation, SQL statements, and rows returned or loaded. |

## Workload check

During Stage 2, exercise the affected caller of a material data-access change that risks growing with history, batch size, or repetition. Use a small synthetic fixture. Hold the relevant work steady and add unrelated history to check for over-fetching. Increase relevant work for operations that process multiple items to check for repeated queries and writes. Compare equivalent behavior and persisted effects for each workload. Time the complete operation with fixture setup outside the timed block.

Use existing test instrumentation or load `quality/rails_workload_probe.rb` in the relevant test and call `result, metrics = RailsWorkloadProbe.measure { ... }` around the normal caller. Record elapsed time, SQL calls, cache hits, instantiated records, and relevant write work. Check transaction or lock scope and retry effects where applicable. The probe is for synchronous Rails work on the current thread. Instantiated records measure application loading. Use a query plan if you need to establish database-side scans or rows. Direct-write counts cover ordinary INSERT, UPDATE, DELETE, MERGE, and TRUNCATE statements. Use statement events or focused assertions if your path writes through other forms.

For final grading, the reviewer chooses one consequential read and one write or batch based on which callers are likely to do the most unnecessary work. Reuse Stage 2 measurements with the same code and conditions. Measure uncovered workloads and rerun evidence affected by repairs. Explain unavoidable growth that follows from more relevant work. Production capacity requires separate evidence.
