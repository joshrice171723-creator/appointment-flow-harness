# V2.5.1.1.0 AI grading rubric

Apply this rubric to the completed clean-room implementation and after each repair round. The AI owns the grade and its evidence. Inspect the source and calls, execute the required checks, and resolve uncertainty through focused investigation.

## Grades

- **PASS** means the criterion is satisfied on the current revision and the report shows the evidence.
- **REVISE** means a specific, material code or behavior issue needs a fix. Cite where it occurs and what it changes.
- **UNVERIFIED** means required evidence is missing. Collect it through source inspection or an executable check appropriate to the criterion.

The overall grade is **PASS** only when every required criterion below passes and the configured quality gate passes on the final implementation. Use **REVISE** while a fix, a check, or other evidence is still needed. Use **BLOCKED** only when a required prerequisite is genuinely unavailable after reasonable diagnosis and recovery attempts. Record the exact blocker, what was attempted, and which evidence is missing.

## Required criteria

| Criterion | Evidence for PASS |
|---|---|
| **Required behavior** | Map the core assignment and adopted scope to actual results. Exercise a real local reminder-and-reply workflow through the normal entry points. Reconcile any scope cuts with the brief. |
| **Safety and data boundaries** | Review and verify the applicable recipient, appointment revision, clinic isolation, opt-out, scheduling, and duplicate-send safeguards. Confirm the demo uses fictional data, fake transport, and read-only PMS access. Exercise the relevant high-risk behavior rather than relying on the names of tests. |
| **Performance and Rails queries** | Choose the consequential read and write or batch for the workload check in `docs/PERFORMANCE.md` from the actual callers. Verify the results or reuse applicable Stage 2 evidence. Explain what grows as the relevant or unrelated data grows, including repeated work and applicable lock or retry behavior. Resolve verified material waste within the agreed scope. |
| **Material workflow coverage** | Identify the material workflows from actual entry points and call sites. Apply relevant rubric criteria to each, including shared operations. Cite existing or newly gathered evidence for the material guarantees. |
| **Human readability** | Trace a normal workflow from entry point through its business decision, writes, and visible result. The names, sequence, and boundaries make the operation understandable from the source. An individual abstraction earns its place by clarifying ownership, reducing reading effort, or serving a concrete need. |
| **Ease of change** | Pick one plausible rule change from the actual implementation. Identify the owner, affected call sites, and focused verification. Show that the rule can be changed without hunting for independent copies. |
| **Failure and transaction behavior** | Trace an applicable failure through the owning transaction and caller. Identify what commits, rolls back, or survives, and verify the caller's response. Show where the error is identified and how its original cause is preserved. Exercise rollback, retry, or uncertain writes where the workflow depends on them. |
| **Verification and handoff** | Run the configured quality gate on the final implementation and record the exact implementation revision or snapshot it checked. Verify that the commands exercised the required behavior and frontend checks and ran real tests. A successful runner exit establishes only the exit status of its configured commands. Verify the documented local startup and demo paths. Check the README, architecture, AI usage record, and decision notes against the implementation. |

## Grading and repair loop

1. **Grade the built revision.** Follow `agent-prompts/03_INDEPENDENT_REVIEW.md`. The grader discovers material workflows after implementation and verifies coverage using the actual code and evidence.
2. **Repair verified findings.** Fix the smallest responsible area. Preserve required behavior, safety boundaries, and proportionate scope. Investigate speculative findings before changing code. Resolve an UNVERIFIED criterion by collecting evidence.
3. **Verify and regrade.** Run focused checks for the changes, then apply the full rubric again to the updated revision. Carry forward evidence when its code and inputs still apply. Refresh evidence invalidated by fixes. Run the full configured gate on the final revision before recording an overall PASS.
4. **Repeat until PASS.** Continue through additional repair and grading rounds as needed. A blocked result is an incomplete build and cannot be frozen as passed.

Use an independent AI reviewer when the environment supports it. If it does not, run a dedicated grading pass using the source and runnable evidence in the current agent and label that result as self-review. A self-review does not supply independent comparison evidence. Keep all code inspection, execution, decisions about findings, and validation with the AI.

## Evidence record

Write `review/RUBRIC_RESULTS.md` during the build. For each round, record the implementation revision or snapshot, overall grade, all criterion grades, and the evidence supporting them. Use file and line references, commands and results, or observed runtime behavior. For REVISE findings, give the impact, smallest remedy, and verification after repair. For UNVERIFIED criteria, say what evidence remains. Record the independent-review mode and final gate result. Report stylistic preferences as optional observations.

The interview's personal authorship and live defense requirements sit outside the AI grade. The agent verifies the decision notes as factual handoff material.
