"""Prepare the fictional local demo and run Rails and React together."""
from argparse import ArgumentParser
from datetime import datetime, timezone
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-only", action="store_true", help="prepare and seed PostgreSQL, then exit")
    args = parser.parse_args()
    env = os.environ.copy()
    env.setdefault("DEMO_NOW", datetime.now(timezone.utc).replace(hour=18, minute=0, second=0, microsecond=0).isoformat())
    api_port = int(env.get("APEX_API_PORT", "3300"))
    web_port = int(env.get("APEX_WEB_PORT", "5273"))
    if sys.platform == "win32":
        pg_bin = Path(env.get("ProgramFiles", r"C:\Program Files")) / "PostgreSQL" / "17" / "bin"
        if pg_bin.is_dir():
            env["PATH"] = str(pg_bin) + os.pathsep + env["PATH"]

    backend = ROOT / "backend"
    frontend = ROOT / "frontend"
    rails = ["ruby", "bin/rails"]
    for task in ("db:create", "db:prepare", "db:seed", "reminders:run"):
        subprocess.run([*rails, task], cwd=backend, env=env, check=True)
    if args.prepare_only:
        return 0

    print(f"Demo clock: {env['DEMO_NOW']}", flush=True)
    print(f"Open http://127.0.0.1:{web_port}. Press Ctrl+C to stop.", flush=True)
    processes = []
    try:
        processes.append(subprocess.Popen([*rails, "server", "-b", "127.0.0.1", "-p", str(api_port)], cwd=backend, env=env))
        processes.append(subprocess.Popen(
            ["node", "node_modules/vite/bin/vite.js", "--host", "127.0.0.1"], cwd=frontend, env=env
        ))
        while True:
            try:
                exit_code = processes[-1].wait(timeout=1)
                return exit_code
            except subprocess.TimeoutExpired:
                exit_code = processes[0].poll()
                if exit_code is not None:
                    return exit_code
    except KeyboardInterrupt:
        return 0
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
        for process in processes:
            process.wait()


if __name__ == "__main__":
    sys.exit(main())
