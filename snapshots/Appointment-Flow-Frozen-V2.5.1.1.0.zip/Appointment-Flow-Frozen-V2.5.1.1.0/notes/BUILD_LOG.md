# Build log

## Preflight and plan

- The packaged harness passed with 53 inputs and 10 screenshot signatures. The Email screenshot shows a clinic/patient picker, Email selected, and empty history.
- The checkout started as an extracted directory. The harness was recorded as the initial commit in a new local repository.
- B01–B05 and B11. Use the provided PostgreSQL schema in `pms`; Rails reads it through read-only models and stores workflow data in its own tables. The Rails reminder command and inbound reply endpoint coordinate decisions using a clinic lock and an appointment revision. A failed source read rolls back the in-flight operation. A persisted fake attempt and its audit state share the same transaction. Choose a manual scheduler entry point to keep the local install small.
- B06–B10. Add clinic-scoped appointment, board, and patient APIs, and query leadership counts in SQL. Build three React workspaces with typed API responses and no global state library. Staff mutations validate their selected clinic, staff identity, and the current visit revision before updating app-owned state. Keep drafts in the browser after a rejected write.
- Verify the reminder/reply path first, then staff writes and reporting, then browser behavior, workload and the full harness gate.

## Rails workflow and workspaces

- B02–B05. The first reminder run recorded four successful fake attempts and one fake failure for Austin and four successful attempts for Phoenix. Rails reads the replica directly. An empty clinic aborts that clinic's transaction and preserves local work. A copied snapshot was considered for outage reads and would add another synchronization and retention boundary.
- B01, B06–B10. React uses a Rails JSON API for the desk board, calendar, patient details, leadership outcomes, and the simulated inbox. State is scoped to a workspace, and Rails owns clinic checks and mutations. The first Edge smoke pass exercised both confirmation channels, clinic switching, leadership, and a follow-up committed before a simulated response loss. The retry used the same request ID and left one activity entry.
- B03, B05, B06. Tests and independent review surfaced same-day catch-up duplicates, stale SMS replies after a number change, and a cross-clinic race during verified contact changes. Rails now suppresses same-day repeat attempts, requires the originating number when SMS history disagrees with the current contact, and serializes contact directory writes against reads across clinics.
- B02, B06, B09, B11. The review also led to per-clinic failure handling in the reminder command, retirement of stale work on a successful scan, retrieval of the selected board item beyond the history cap, filtering name searches from request logs, and preloading active visit work. The portable schema dump includes the PMS schema and relies on PostgreSQL to supply the default public schema.
