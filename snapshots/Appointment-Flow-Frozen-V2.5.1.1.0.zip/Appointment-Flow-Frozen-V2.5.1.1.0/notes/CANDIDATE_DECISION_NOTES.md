# Candidate decision notes

Facts and questions for the candidate's own `DECISIONS.md`.

- Rails reads the supplied schema directly through read-only models. The appointment view derives a version from source timestamps, identity, status and wall time. A local mirror could keep more patient-facing data available during a replica outage, with another consistency and retention boundary to own.
- The seven-day horizon and clinic-local sending window are in `ReminderBatch`. The manual entry point keeps the exercise locally runnable. Discuss where the cadence, retry policy and separate scheduler would belong for a live operation.
- A plain `YES` auto-confirms only when the expected channel identifies one sent version. This includes prior sends, so returning patients may need staff review for unthreaded SMS. Consider the tradeoffs in explicit SMS codes, threaded email, or staff verification.
- The demo presumes valid seeded adult contact addresses are contactable. It records local verification and exact STOP, and holds minors. What source would prove written consent, current phone ownership, and guardian authorization in production?
- The clinic lock coordinates replies, corrections, and send eligibility. Local rows and fake attempts can roll back together. A real delivery provider requires a stable idempotency key and a separate strategy for responses lost after successful delivery.
- Outcomes use PMS complete and current local dispositions. Unclassified statuses stay unknown. Measuring a reduction in missed appointments would require explicit outcome definitions, reliable events, and a comparison design.
- The clinic and staff selection scope demo routes. Discuss real staff identity, authorization, scoped permissions, secrets, audit access, and data retention.
