import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const proxy = { '/api': `http://127.0.0.1:${process.env.APEX_API_PORT || '3300'}` }

export default defineConfig({
  plugins: [react()],
  server: { proxy, strictPort: true, port: Number(process.env.APEX_WEB_PORT || '5273') },
  preview: { proxy },
})
