import assert from 'node:assert/strict'
import { chromium } from 'playwright-core'

const browser = await chromium.launch({
  ...(process.env.BROWSER_PATH ? { executablePath: process.env.BROWSER_PATH } : { channel: 'msedge' }),
  headless: true,
})
const base = process.env.DEMO_URL || `http://127.0.0.1:${process.env.APEX_WEB_PORT || '5273'}`
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
page.setDefaultTimeout(8000)
const errors = []
page.on('pageerror', error => errors.push(error.message))

try {
  await page.goto(base)
  await page.getByRole('heading', { name: 'Workspaces' }).waitFor()
  await page.getByRole('button', { name: 'Open front desk' }).click()
  await page.getByRole('heading', { name: 'Patient flow' }).waitFor()
  await page.getByRole('searchbox', { name: 'Search patients' }).fill('Robin')
  await page.getByRole('link', { name: /Robin Reed.*Reminders blocked|Reminders blocked.*Robin Reed/ }).click()
  const item = page.locator('article.follow-up').filter({ hasText: 'Reminders blocked' })
  await item.waitFor()
  if (await item.getByRole('button', { name: 'Assign to me' }).count()) {
    await item.getByRole('button', { name: 'Assign to me' }).click()
  }

  const submissionIds = []
  await page.route('**/follow_ups', async route => {
    submissionIds.push(route.request().postDataJSON().request_id)
    if (submissionIds.length === 1) {
      const saved = await route.fetch()
      assert.equal(saved.status(), 201)
      await route.abort('failed')
    } else {
      await route.continue()
    }
  })
  const note = 'Browser smoke test ' + Date.now()
  await item.getByLabel('Follow-up note').fill(note)
  await item.getByRole('button', { name: 'Record follow-up' }).click()
  await item.getByRole('alert').getByText(/result is unknown/).waitFor()
  assert.equal(await item.getByLabel('Follow-up note').inputValue(), note)
  await item.getByRole('button', { name: 'Record follow-up' }).click()
  await item.getByText('Follow-up recorded.').waitFor()
  assert.equal(submissionIds.length, 2)
  assert.equal(submissionIds[0], submissionIds[1])
  await page.getByRole('button', { name: 'Activity log' }).click()
  await page.getByText(note, { exact: true }).waitFor()
  assert.equal(await page.getByText(note, { exact: true }).count(), 1)

  await page.goto(base + '/#/patient')
  await page.getByLabel('Clinic', { exact: true }).selectOption('1')
  await page.getByLabel('Patient', { exact: true }).selectOption({ label: 'Avery Morgan' })
  await page.getByText('Message history', { exact: true }).waitFor()
  await page.getByLabel('Your reply').fill('YES')
  await page.getByRole('button', { name: 'Send reply' }).click()
  await page.getByText('Your appointment is confirmed.', { exact: false }).waitFor()

  await page.getByLabel('Patient', { exact: true }).selectOption({ label: 'Jules Bennett' })
  await page.getByRole('button', { name: 'Email', exact: true }).click()
  await page.getByText('Message history', { exact: true }).waitFor()
  await page.getByLabel('Reply to email').selectOption({ index: 1 })
  await page.getByLabel('Your reply').fill('yes')
  await page.getByRole('button', { name: 'Send reply' }).click()
  await page.getByText('Your appointment is confirmed.', { exact: false }).waitFor()

  await page.goto(base + '/#/desk/appointments')
  const clinics = await (await page.request.get(base + '/api/clinics')).json()
  const date = new Date(clinics[0].today + 'T00:00:00Z')
  date.setUTCDate(date.getUTCDate() + 7)
  await page.getByLabel('Jump to date').fill(date.toISOString().slice(0, 10))
  await page.getByRole('row').filter({ hasText: 'Jules Bennett' }).getByText('confirmed', { exact: true }).waitFor()
  await page.getByRole('button', { name: /Confirmed/ }).first().click()
  await page.getByRole('row').filter({ hasText: 'Avery Morgan' }).waitFor()

  await page.goto(base)
  await page.getByLabel('Clinic', { exact: true }).selectOption('2')
  await page.getByRole('button', { name: 'Open front desk' }).click()
  await page.getByText('Jordan · America/Phoenix').waitFor()
  assert.equal(await page.getByText('Robin Reed', { exact: true }).count(), 0)

  await page.goto(base + '/#/leadership')
  await page.getByLabel('Outcome month').fill(clinics[0].today.slice(0, 7))
  await page.getByRole('heading', { name: 'Clinic comparison' }).waitFor()
  await page.getByText('Monthly history and reminder activity', { exact: true }).click()
  await page.getByRole('columnheader', { name: 'Simulated sends' }).waitFor()
  assert.equal(await page.getByText('Avery Morgan').count(), 0)

  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto(base)
  await page.getByRole('heading', { name: 'Workspaces' }).waitFor()
  const hasHorizontalOverflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth)
  assert.equal(hasHorizontalOverflow, false)
  assert.deepEqual(errors, [])
  console.log('PASS: staffed workspaces, uncertain save retry, SMS and Email replies, calendar, clinic switch, leadership, narrow layout.')
} finally {
  await browser.close()
}
