import { useEffect, useRef, useState } from 'react'

class RequestError extends Error {}

const uncertain = 'The result is unknown. Your draft is still here. Retry the same submission or refresh to check the record.'

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(path, options)
  if (!response.ok) {
    if (response.status >= 500) throw new Error('The service is temporarily unavailable.')
    const payload: { error?: string } = await response.json()
    throw new RequestError(payload.error || 'The request could not be completed.')
  }
  return response.json() as Promise<T>
}

export function useRead<T>(path: string | null, staff = '') {
  const [reload, setReload] = useState(0)
  const key = JSON.stringify([path, staff])
  const [result, setResult] = useState<{ key: string, data?: T, error?: string }>()
  useEffect(() => {
    if (!path) return
    const controller = new AbortController()
    request<T>(path, { headers: { 'X-Demo-Staff': staff }, signal: controller.signal }).then(
      data => { if (!controller.signal.aborted) setResult({ key, data }) },
      (error: unknown) => {
        if (!controller.signal.aborted) setResult({ key, error: error instanceof Error ? error.message : 'Unable to load this view.' })
      },
    )
    return () => controller.abort()
  }, [key, path, staff, reload])

  return {
    data: result?.key === key ? result.data : undefined,
    error: result?.key === key ? result.error : undefined,
    refresh: () => setReload(value => value + 1),
  }
}

export function useWrite<T>() {
  const [pending, setPending] = useState(false)
  const [error, setError] = useState('')
  const inFlight = useRef(false)
  const submission = useRef<{ fingerprint: string, id: string } | null>(null)

  async function save(path: string, payload: object, key?: 'external_id' | 'request_id', staff = '') {
    if (inFlight.current) return
    const fingerprint = JSON.stringify([path, staff, payload])
    if (submission.current?.fingerprint !== fingerprint) {
      submission.current = { fingerprint, id: crypto.randomUUID() }
    }

    inFlight.current = true
    setPending(true)
    setError('')
    try {
      const result = await request<T>(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Demo-Staff': staff },
        body: JSON.stringify(key ? { ...payload, [key]: submission.current.id } : payload),
      })
      submission.current = null
      return result
    } catch (error) {
      setError(error instanceof RequestError ? error.message : uncertain)
    } finally {
      inFlight.current = false
      setPending(false)
    }
  }

  return { pending, error, save }
}
