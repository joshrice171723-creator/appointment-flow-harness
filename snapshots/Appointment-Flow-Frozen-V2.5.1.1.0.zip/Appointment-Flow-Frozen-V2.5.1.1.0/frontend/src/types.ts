export type Clinic = { id: number, city: string, name: string, today: string, staff: string[], zone: string }
export type Desk = { clinic: Clinic, staff: string }

export type Visit = {
  id: number, patient_id: number, patient: string, provider: string, wall_time: string, local_time: string | null,
  duration: number | null, pms_status: string, outcome: string, decision: string, review: boolean, upcoming: boolean
}

export type Work = {
  id: number, patient_id: number, appointment_id: number, patient?: string, kind: keyof typeof workKinds,
  assignee: string | null, resolved_at: string | null, reason: string, created_at: string,
  reply?: string, candidates?: { id: number, patient: string, wall_time: string, current: boolean }[]
}
export const workKinds = {
  no_reply: 'Awaiting confirmation',
  contact_hold: 'Reminders blocked',
  delivery_failed: 'Delivery failed',
  reply_review: 'Reply needs review',
}

export const contactLabels = {
  birthdate: 'Birthdate',
  wireless_phone: 'Mobile phone',
  email: 'Email',
  preferred_language: 'Preferred language',
}

export type ContactField = keyof typeof contactLabels
export type Contact = { value: string | null, source: string | null, status: 'unverified' | 'verified' | 'conflict' }
export type Patient = {
  id: number, name: string, contact: Record<ContactField, Contact>,
  appointments: Visit[], items: Work[],
  events: { id: number, staff: string, action: string, note: string, created_at: string }[]
}
