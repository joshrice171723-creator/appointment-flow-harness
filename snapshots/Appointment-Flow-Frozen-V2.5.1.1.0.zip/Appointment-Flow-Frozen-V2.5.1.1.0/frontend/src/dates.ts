const shortDate = new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' })

export function validDay(day: string | null): day is string {
  if (!day || !/^\d{4}-\d{2}-\d{2}$/.test(day)) return false
  const date = new Date(day + 'T00:00:00Z')
  return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === day
}

export function addDays(day: string, amount: number) {
  const date = new Date(day + 'T00:00:00Z')
  date.setUTCDate(date.getUTCDate() + amount)
  return date.toISOString().slice(0, 10)
}

export function weekDays(day: string) {
  const weekday = new Date(day + 'T00:00:00Z').getUTCDay()
  const monday = addDays(day, -((weekday + 6) % 7))
  return Array.from({ length: 7 }, (_, index) => addDays(monday, index))
}

export function dateLabel(day: string) {
  return shortDate.format(new Date(day.slice(0, 10) + 'T00:00:00Z'))
}

export function timestamp(value: string, zone: string) {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: zone, timeZoneName: 'short',
  }).format(new Date(value))
}

export function monthLabel(month: string) {
  return new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })
    .format(new Date(month + '-01T00:00:00Z'))
}
