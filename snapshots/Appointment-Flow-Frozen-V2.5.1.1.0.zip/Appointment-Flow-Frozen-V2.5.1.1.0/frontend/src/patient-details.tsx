import { useState } from 'react'
import { useRead, useWrite } from './api'
import { Empty, FilterTabs, LoadStatus } from './components'
import { dateLabel, timestamp } from './dates'
import { VisitTable } from './front-desk'
import { contactLabels, workKinds, type ContactField, type Desk, type Patient, type Work } from './types'

const actions = {
  attempted: 'Contact attempted',
  confirmed: 'Confirmed',
  rescheduled: 'Rescheduled',
  canceled: 'Canceled',
  clarified: 'Clarified',
  contact_verified: 'Contact verified',
}

export function PatientDetails({ desk, id, selectedItem }: { desk: Desk, id: number, selectedItem: number }) {
  const [tab, setTab] = useState('follow-up')
  const base = `/api/clinics/${desk.clinic.id}`
  const path = `${base}/patients/${id}`
  const profile = useRead<Patient>(selectedItem ? `${path}?item=${selectedItem}` : path, desk.staff)
  const patient = profile.data

  if (!patient) return <main className="desk shell"><a href="#/desk">← Patient flow</a><LoadStatus error={profile.error} retry={profile.refresh} /></main>

  const open = patient.items.filter(item => !item.resolved_at)
  const resolved = patient.items.filter(item => item.resolved_at)
  const next = [...patient.appointments].reverse().find(visit =>
    visit.upcoming && !['canceled', 'rescheduled'].includes(visit.decision))
  const items = [...open].sort((left, right) => Number(right.id === selectedItem) - Number(left.id === selectedItem))

  return <main className="desk shell">
    <a className="text-link back" href="#/desk">← Patient flow / {desk.clinic.city}</a>
    <div className="page-title">
      <p className="eyebrow">{desk.clinic.city}</p><h1>{patient.name}</h1>
      <p className="muted">{open.length ? `${open.length} open follow-up ${open.length === 1 ? 'item' : 'items'}` : 'No open follow-up'}</p>
    </div>
    {next && <div className="visit-intro split">
      <div><strong>Next scheduled appointment</strong><p>{dateLabel(next.wall_time)} · {next.local_time || 'Time needs review'} · Visit #{next.id}</p></div>
      <a className="secondary" href={`#/desk/appointments?date=${next.wall_time.slice(0, 10)}`}>View appointment →</a>
    </div>}
    <div className="profile-layout">
      <ContactDetails patient={patient} path={path} staff={desk.staff} refresh={profile.refresh} />
      <section>
        <FilterTabs labels={[{ value: 'follow-up', label: 'Follow-up', count: open.length }, { value: 'appointments', label: 'Appointments' }, { value: 'activity', label: 'Activity log' }]}
          active={tab} onChange={setTab} />
        {tab === 'appointments' && <VisitTable compact visits={patient.appointments} />}
        {tab === 'activity' && <section className="panel detail-panel"><h2>Activity log</h2>
          {patient.events.length ? <ul className="history">
            {patient.events.map(event => <li key={event.id}><strong>{actions[event.action as keyof typeof actions] || event.action}</strong>
              <small>{event.staff} · {timestamp(event.created_at, desk.clinic.zone)}</small><p>{event.note}</p></li>)}
          </ul> : <Empty>No staff activity recorded.</Empty>}
        </section>}
        {tab === 'follow-up' && <section className="panel detail-panel">
          <h2>Follow-up items</h2>
          {items.length ? items.map(item => <FollowUp key={item.id} item={item} path={`${base}/work_items/${item.id}`}
            staff={desk.staff} refresh={profile.refresh} />) : <Empty>No open follow-up for this patient.</Empty>}
          <details className="resolved-history" open={resolved.some(item => item.id === selectedItem) || undefined}>
            <summary>Resolved follow-up ({resolved.length})</summary>
            {resolved.map(item => <div className="resolved-item" key={item.id}><strong>{workKinds[item.kind]}</strong>
              <p>{item.reason}</p><small>{item.assignee || 'System'} · {item.resolved_at && timestamp(item.resolved_at, desk.clinic.zone)}</small>
            </div>)}
          </details>
        </section>}
      </section>
    </div>
  </main>
}

function ContactDetails({ patient, path, staff, refresh }: { patient: Patient, path: string, staff: string, refresh: () => void }) {
  const [editing, setEditing] = useState<ContactField | null>(null)
  const fields = Object.keys(contactLabels) as ContactField[]
  return <aside className="panel contact-panel">
    <h2>Patient details</h2>
    {fields.map(field => {
      const contact = patient.contact[field]
      return <div className="contact-field" key={field}>
        <div className="split"><span>{contactLabels[field]}</span>
          <button type="button" className="quiet" onClick={() => setEditing(editing === field ? null : field)}
            aria-label={`Edit ${contactLabels[field].toLowerCase()}`}>Edit</button></div>
        <strong>{contact.value || 'No value on file'}</strong>
        <div><span className={`pill ${contact.status}`}>{contact.status === 'conflict' ? 'PMS conflict' : contact.status === 'verified' ? 'Verified locally' : 'Unverified'}</span></div>
        {contact.status === 'conflict' && <small>PMS value · {contact.source || 'No value on file'}</small>}
        {editing === field && <ContactEditor field={field} initial={contact.value ?? ''} path={path} staff={staff}
          finish={() => { setEditing(null); refresh() }} />}
      </div>
    })}
  </aside>
}

function ContactEditor({ field, initial, path, staff, finish }: {
  field: ContactField, initial: string, path: string, staff: string, finish: () => void
}) {
  const [value, setValue] = useState(initial)
  const [note, setNote] = useState('')
  const write = useWrite<{ id: number }>()
  return <form className="inline-form" onSubmit={async event => {
    event.preventDefault()
    if (await write.save(`${path}/contact_verification`, { values: { [field]: value }, note }, 'request_id', staff)) finish()
  }}>
    <label>{contactLabels[field]}
      <input type={field === 'birthdate' ? 'date' : 'text'} value={value} maxLength={254} disabled={write.pending}
        onChange={event => setValue(event.target.value)} />
    </label>
    <label>Verification note<textarea rows={2} required maxLength={1000} disabled={write.pending} value={note}
      onChange={event => setNote(event.target.value)} /></label>
    {write.error && <p role="alert" className="error">{write.error}</p>}
    <button className="primary" disabled={write.pending}>{write.pending ? 'Saving…' : 'Save verification'}</button>
  </form>
}

function FollowUp({ item, path, staff, refresh }: { item: Work, path: string, staff: string, refresh: () => void }) {
  const [action, setAction] = useState('attempted')
  const [note, setNote] = useState('')
  const [candidates, setCandidates] = useState<number[]>([])
  const [success, setSuccess] = useState('')
  const assignment = useWrite<Work>()
  const write = useWrite<{ id: number }>()
  const availableActions = item.kind === 'reply_review' ? ['attempted', 'clarified'] : ['attempted', 'confirmed', 'rescheduled', 'canceled']

  return <article className="follow-up">
    <div className="split"><span className={`pill ${item.kind}`}>{workKinds[item.kind]}</span><small>Visit #{item.appointment_id}</small></div>
    <p>{item.reason}</p>
    {item.reply && <blockquote>{item.reply}</blockquote>}
    <div className="assignment">
      <span>{item.assignee ? `Assigned to ${item.assignee}` : 'Unassigned'}</span>
      {item.assignee !== staff && <button className="secondary" type="button" disabled={assignment.pending}
        onClick={async () => { if (await assignment.save(`${path}/assignment`, {}, undefined, staff)) refresh() }}>Assign to me</button>}
    </div>
    {assignment.error && <p className="error" role="alert">{assignment.error}</p>}
    {item.assignee === staff && <form className="inline-form" onSubmit={async event => {
      event.preventDefault()
      setSuccess('')
      const saved = await write.save(`${path}/follow_ups`, {
        action_name: action, note, candidates: action === 'clarified' ? candidates : [],
      }, 'request_id', staff)
      if (saved) {
        setNote('')
        setCandidates([])
        setSuccess('Follow-up recorded.')
        refresh()
      }
    }}>
      <label>Follow-up outcome<select value={action} disabled={write.pending} onChange={event => setAction(event.target.value)}>
        {availableActions.map(value => <option key={value} value={value}>{actions[value as keyof typeof actions]}</option>)}
      </select></label>
      {action === 'clarified' && <fieldset disabled={write.pending}>
        <legend>Appointments confirmed by the patient</legend>
        {item.candidates?.map(candidate => <label className="check" key={candidate.id}>
          <input type="checkbox" disabled={!candidate.current} checked={candidates.includes(candidate.id)}
            onChange={event => setCandidates(current => event.target.checked ? [...current, candidate.id] : current.filter(id => id !== candidate.id))} />
          {candidate.patient} · {dateLabel(candidate.wall_time)} · Visit #{candidate.id}{!candidate.current && ' · PMS changed'}
        </label>)}
        <small>Leave the list empty to close this review without confirming a visit.</small>
      </fieldset>}
      <label>Follow-up note<textarea required maxLength={1000} value={note} rows={3}
        disabled={write.pending} onChange={event => setNote(event.target.value)} /></label>
      {write.error && <p role="alert" className="error">{write.error}</p>}
      {success && <p role="status">{success}</p>}
      <button className="primary" disabled={write.pending}>{write.pending ? 'Saving…' : 'Record follow-up'}</button>
    </form>}
  </article>
}
