import '@fontsource-variable/inter'
import '@fontsource/instrument-serif'
import './styles.css'
import { StrictMode, useState, useSyncExternalStore } from 'react'
import { createRoot } from 'react-dom/client'
import { useRead } from './api'
import { LoadStatus, PageBar } from './components'
import type { Clinic, Desk } from './types'
import { Board, Appointments } from './front-desk'
import { PatientDetails } from './patient-details'
import { PatientInbox } from './inbox'
import { Leadership } from './leadership'

function subscribe(listener: () => void) {
  window.addEventListener('hashchange', listener)
  return () => window.removeEventListener('hashchange', listener)
}

function route() { return location.hash.slice(1) || '/' }

type SignIn = { clinicId: number, staff: string }

function Workspaces({ clinics, openDesk }: { clinics: Clinic[], openDesk: (selection: SignIn) => void }) {
  const [clinicId, setClinicId] = useState(clinics[0]?.id)
  const [staffName, setStaffName] = useState('')
  const clinic = clinics.find(entry => entry.id === clinicId)
  const staff = clinic?.staff.includes(staffName) ? staffName : clinic?.staff[0]

  return <main className="workspace shell">
    <h1>Workspaces</h1>
    <div className="workspace-grid">
      <form className="workspace-card panel" onSubmit={event => {
        event.preventDefault()
        if (clinic && staff) openDesk({ clinicId: clinic.id, staff })
      }}>
        <h2>Front desk</h2>
        <p>Review appointments and follow up with patients.</p>
        <label>Clinic
          <select aria-label="Clinic" value={clinicId ?? ''} onChange={event => setClinicId(Number(event.target.value))}>
            {clinics.map(entry => <option key={entry.id} value={entry.id}>{entry.city}</option>)}
          </select>
        </label>
        <label>Staff member
          <select value={staff ?? ''} onChange={event => setStaffName(event.target.value)}>
            {clinic?.staff.map(name => <option key={name}>{name}</option>)}
          </select>
        </label>
        <button disabled={!staff} className="primary action-link">Open front desk <span aria-hidden="true">→</span></button>
      </form>
      <section className="workspace-card panel tinted">
        <h2>Apex leadership</h2>
        <p>Compare appointment outcomes across clinics.</p>
        <p className="clinic-total"><strong>{clinics.length}</strong> reporting clinics</p>
        <a className="primary action-link" href="#/leadership">Open Apex leadership <span aria-hidden="true">→</span></a>
      </section>
      <section className="workspace-card panel">
        <h2>Patient</h2>
        <p>Open a fictional patient’s inbox and simulate text or email replies.</p>
        <a className="primary action-link" href="#/patient">Open patient workspace <span aria-hidden="true">→</span></a>
      </section>
    </div>
  </main>
}

function DeskPages({ desk, page, query }: { desk: Desk, page: string, query: URLSearchParams }) {
  const detail = page.match(/^\/desk\/patients\/(\d+)$/)
  const appointmentPage = page === '/desk/appointments'
  return <>
    <PageBar nav={<>
      <a href="#/desk" aria-current={page === '/desk' ? 'page' : undefined}>Patient flow</a>
      <a href="#/desk/appointments" aria-current={appointmentPage ? 'page' : undefined}>Appointments</a>
    </>} />
    {detail ? <PatientDetails desk={desk} id={Number(detail[1])} selectedItem={Number(query.get('item'))} />
      : appointmentPage ? <Appointments desk={desk} initialDay={query.get('date')} />
        : <Board desk={desk} />}
  </>
}

function App() {
  const [page, params = ''] = useSyncExternalStore(subscribe, route).split('?')
  const [signIn, setSignIn] = useState<SignIn | null>(() => {
    const clinicId = Number(sessionStorage.getItem('deskClinic'))
    const staff = sessionStorage.getItem('deskStaff')
    return clinicId && staff ? { clinicId, staff } : null
  })
  const clinics = useRead<Clinic[]>(page === '/leadership' ? null : '/api/clinics')
  const selected = clinics.data?.find(clinic => clinic.id === signIn?.clinicId)
  const desk = selected && signIn && selected.staff.includes(signIn.staff) ? { clinic: selected, staff: signIn.staff } : null

  if (page === '/leadership') return <><PageBar nav={<strong>Apex leadership</strong>} /><Leadership /></>
  if (!clinics.data) return <><PageBar /><main className="shell"><LoadStatus error={clinics.error} retry={clinics.refresh} /></main></>
  if (page === '/patient') return <PatientInbox clinics={clinics.data} />
  if (page.startsWith('/desk') && desk) {
    return <DeskPages key={`${desk.clinic.id}:${desk.staff}:${page}?${params}`} desk={desk} page={page} query={new URLSearchParams(params)} />
  }
  return <><PageBar /><Workspaces clinics={clinics.data} openDesk={next => {
    sessionStorage.setItem('deskClinic', String(next.clinicId))
    sessionStorage.setItem('deskStaff', next.staff)
    setSignIn(next)
    location.hash = '/desk'
  }} /></>
}

const root = document.getElementById('root')
if (!root) throw new Error('Missing application root.')
createRoot(root).render(<StrictMode><App /></StrictMode>)
