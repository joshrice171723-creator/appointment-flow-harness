import type { ReactNode } from 'react'
import { timestamp } from './dates'
import type { Clinic } from './types'

export function LoadStatus({ error, retry }: { error?: string, retry: () => void }) {
  return error ? (
    <div className="notice" role="alert">
      <p>{error}</p>
      <button className="secondary" onClick={retry}>Try again</button>
    </div>
  ) : <p className="muted" role="status">Loading…</p>
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="empty muted">{children}</p>
}

export function PageBar({ nav }: { nav?: ReactNode }) {
  return (
    <header className="page-bar">
      <a className="brand" href="#/" aria-label="Apex Appointment Flow workspaces">
        <span className="brand-mark" aria-hidden="true">A<span>↗</span></span>
        <span><strong>APEX</strong><small>APPOINTMENT FLOW</small></span>
      </a>
      <nav aria-label="Workspace navigation">
        {nav}
        <a href="#/">Workspaces <span aria-hidden="true">↗</span></a>
      </nav>
    </header>
  )
}

export function SyncLabel({ clinic, value, failed }: { clinic: Clinic, value: string | null, failed: string | null }) {
  return <>
    <p className="sync-label">Last PMS sync · {value ? timestamp(value, clinic.zone) : 'No reminder batch run yet'}</p>
    {failed && <p className="notice error" role="alert">The last PMS sync failed. Appointment data may be incomplete.</p>}
  </>
}

export function FilterTabs({ labels, active, onChange }: {
  labels: { value: string, label: string, count?: number }[], active: string, onChange: (value: string) => void
}) {
  return <div className="filter-tabs" role="group" aria-label="View">
    {labels.map(({ value, label, count }) =>
      <button key={value} type="button" aria-pressed={active === value} onClick={() => onChange(value)}>
        {label}{count !== undefined && <span className="tab-count">{count}</span>}
      </button>,
    )}
  </div>
}
