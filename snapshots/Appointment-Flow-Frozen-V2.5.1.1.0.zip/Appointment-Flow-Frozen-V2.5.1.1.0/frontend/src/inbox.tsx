import { useState } from 'react'
import { useRead, useWrite } from './api'
import { Empty, FilterTabs, LoadStatus } from './components'
import { timestamp } from './dates'
import type { Clinic } from './types'

type Person = { id: number, name: string }
type InboxMessage = { id: number, body: string, status: string, direction: 'inbound' | 'outbound', created_at: string }
type Inbox = { messages: InboxMessage[], sms_origins: { id: number, recipient: string }[] }
type ReplyResult = { status: 'confirmed' | 'review' | 'opted_out' }
const results = {
  confirmed: 'Reply recorded. Your appointment is confirmed.',
  review: 'Reply recorded for the front desk to review.',
  opted_out: 'Reply recorded. Text reminders are turned off for this number at this clinic.',
}

export function PatientInbox({ clinics }: { clinics: Clinic[] }) {
  const [clinicId, setClinicId] = useState('')
  const [patientId, setPatientId] = useState('')
  const [channel, setChannel] = useState('sms')
  const clinic = clinics.find(entry => String(entry.id) === clinicId)
  const patients = useRead<Person[]>(clinic ? `/api/clinics/${clinic.id}/patients` : null)

  return <main className="inbox shell">
    <a className="text-link back" href="#/">← Workspaces</a>
    <h1>Patient inbox</h1>
    <label>Clinic
      <select aria-label="Clinic" value={clinicId} onChange={event => { setClinicId(event.target.value); setPatientId(''); setChannel('sms') }}>
        <option value="">Select a clinic</option>
        {clinics.map(entry => <option key={entry.id} value={entry.id}>{entry.city}</option>)}
      </select>
    </label>
    {clinic && (patients.data ? <label>Patient
      <select aria-label="Patient" value={patientId} onChange={event => { setPatientId(event.target.value); setChannel('sms') }}>
        <option value="">Select a fictional patient</option>
        {patients.data.map(person => <option key={person.id} value={person.id}>{person.name}</option>)}
      </select>
    </label> : <LoadStatus error={patients.error} retry={patients.refresh} />)}
    {clinic && patientId && <>
      <FilterTabs active={channel} onChange={setChannel} labels={[{ value: 'sms', label: 'Text messages' }, { value: 'email', label: 'Email' }]} />
      <Conversation key={`${clinicId}:${patientId}:${channel}`} path={`/api/clinics/${clinicId}/patients/${patientId}`}
        channel={channel} zone={clinic.zone} />
    </>}
  </main>
}

function Conversation({ path, channel, zone }: { path: string, channel: string, zone: string }) {
  const inbox = useRead<Inbox>(`${path}/inbox?channel=${channel}`)
  const write = useWrite<ReplyResult>()
  const [body, setBody] = useState('')
  const [messageId, setMessageId] = useState('')
  const [status, setStatus] = useState('')
  const threads = inbox.data?.messages.filter(entry => entry.direction === 'outbound') ?? []
  const origins = inbox.data?.sms_origins ?? []

  return <>
    {!inbox.data ? <LoadStatus error={inbox.error} retry={inbox.refresh} />
      : inbox.data.messages.length ? <section aria-labelledby="history-title">
        <h2 className="inbox-heading" id="history-title">Message history</h2>
        <ol className="conversation">{inbox.data.messages.map(entry => <li className={entry.direction} key={entry.id}>
          <small>{entry.direction === 'outbound' ? 'Clinic reminder' : 'Your reply'} · {timestamp(entry.created_at, zone)}</small>
          <p>{entry.body}</p>
        </li>)}</ol>
      </section> : <Empty>{channel === 'email' ? 'No simulated emails for this patient yet.' : 'No simulated text messages for this patient yet.'}</Empty>}
    <form className="panel composer" onSubmit={async event => {
      event.preventDefault()
      setStatus('')
      const reply = await write.save(`${path}/replies`, {
        body, channel, ...(messageId ? { message_id: Number(messageId) } : {}),
      }, 'external_id')
      if (reply) {
        setBody('')
        setStatus(results[reply.status])
        inbox.refresh()
      }
    }}>
      {channel === 'email' && threads.length > 0 && <label>Reply to email
        <select aria-label="Reply to email" value={messageId} disabled={write.pending} onChange={event => setMessageId(event.target.value)}>
          <option value="">General reply</option>
          {threads.map(entry => <option value={entry.id} key={entry.id}>{timestamp(entry.created_at, zone)} · {entry.body.slice(0, 90)}</option>)}
        </select>
      </label>}
      {channel === 'sms' && origins.length > 0 && <label>Reply from
        <select aria-label="Reply from" value={messageId} disabled={write.pending} onChange={event => setMessageId(event.target.value)}>
          <option value="">Current number</option>
          {origins.map(origin => <option value={origin.id} key={origin.id}>{origin.recipient}</option>)}
        </select>
      </label>}
      <label>Your reply<textarea rows={4} placeholder="Type your reply" maxLength={500} required value={body}
        disabled={write.pending} onChange={event => setBody(event.target.value)} /></label>
      {status && <p className="success" role="status">{status}</p>}
      {write.error && <p role="alert" className="error">{write.error}</p>}
      <button className="primary" disabled={write.pending}>{write.pending ? 'Sending…' : 'Send reply'}</button>
    </form>
  </>
}
