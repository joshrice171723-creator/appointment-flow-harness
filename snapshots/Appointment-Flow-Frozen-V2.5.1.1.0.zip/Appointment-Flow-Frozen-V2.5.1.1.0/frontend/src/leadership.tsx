import { useState } from 'react'
import { useRead } from './api'
import { Empty, LoadStatus } from './components'
import { monthLabel } from './dates'

const outcomes = {
  completed: 'Completed',
  rescheduled: 'Rescheduled',
  canceled: 'Canceled',
  unknown: 'Unknown',
}
type Outcome = keyof typeof outcomes
const keys = Object.keys(outcomes) as Outcome[]

type OutcomeRow = Record<Outcome, number> & { clinic_id: number, clinic: string, month: string, recorded: number }
type Activity = { clinic_id: number, clinic: string, sent: number, failed: number, contact_holds: number, follow_ups: number }
type Report = { clinics: OutcomeRow[], history: OutcomeRow[], activity: Activity[] }

function rate(value: number, denominator: number) {
  return denominator ? new Intl.NumberFormat('en-US', { style: 'percent', maximumFractionDigits: 1 }).format(value / denominator) : '—'
}

export function Leadership() {
  const [month, setMonth] = useState(() => new Date().toISOString().slice(0, 7))
  const report = useRead<Report>(`/api/leadership_report?month=${month}`)
  const data = report.data
  return <main className="desk shell leadership">
    <div className="page-title split">
      <h1>Appointment outcomes</h1>
      <label>Outcome month<input type="month" value={month} onChange={event => { if (/^\d{4}-\d{2}$/.test(event.target.value)) setMonth(event.target.value) }} /></label>
    </div>
    {!data ? <LoadStatus error={report.error} retry={report.refresh} /> : data.clinics.length ? <>
      <section className="panel leadership-panel">
        <h2>{monthLabel(month)}</h2>
        <div className="clinic-outcomes">
          {data.clinics.map(row => <article key={row.clinic_id}>
            <div className="split"><h3>{row.clinic}</h3><span>{row.recorded} recorded visits</span></div>
            <div className="outcome-track" aria-hidden="true">{keys.map(key => <span className={key} key={key}
              style={{ width: `${row.recorded ? row[key] / row.recorded * 100 : 0}%` }} />)}</div>
            <dl>{keys.map(key => <div key={key}><dt><i className={key} />{outcomes[key]}</dt>
              <dd><strong>{row[key]}</strong> <small>{rate(row[key], row.recorded)}</small></dd></div>)}</dl>
          </article>)}
        </div>
      </section>
      <section className="panel leadership-panel">
        <h2>Clinic comparison</h2>
        <p className="muted">Completion rate is completed visits divided by recorded visits. Unknown includes scheduled visits and PMS records without a classified outcome.</p>
        <OutcomeTable rows={data.clinics} />
      </section>
      <details className="panel leadership-panel">
        <summary>Monthly history and reminder activity</summary>
        <p className="muted">Six months of visit outcomes and simulated delivery attempts for the selected month.</p>
        <OutcomeTable rows={data.history} showMonth />
        <ActivityTable rows={data.activity} columns={[['sent', 'Simulated sends'], ['failed', 'Failed attempts']]} />
      </details>
      <details className="panel leadership-panel">
        <summary>Contact holds</summary>
        <p className="muted">Follow-up items opened because outreach was blocked in the selected month.</p>
        <ActivityTable rows={data.activity} columns={[[ 'contact_holds', 'Holds opened' ]]} />
      </details>
      <details className="panel leadership-panel">
        <summary>Contact and follow-up</summary>
        <p className="muted">Staff follow-up entries recorded in the selected month, including contact attempts and resolved items.</p>
        <ActivityTable rows={data.activity} columns={[[ 'follow_ups', 'Follow-up entries' ]]} />
      </details>
    </> : <Empty>No reporting clinics are available.</Empty>}
  </main>
}

function OutcomeTable({ rows, showMonth }: { rows: OutcomeRow[], showMonth?: boolean }) {
  return <div className="table-wrap">
    <table><thead><tr><th>Clinic</th>{showMonth && <th>Month</th>}<th>Completion rate</th><th>Recorded visits</th>
      {keys.map(key => <th key={key}>{outcomes[key]}</th>)}
    </tr></thead><tbody>{rows.map(row => <tr key={`${row.clinic_id}:${row.month}`}>
      <th scope="row">{row.clinic}</th>{showMonth && <td>{monthLabel(row.month)}</td>}
      <td>{rate(row.completed, row.recorded)}</td><td>{row.recorded}</td>{keys.map(key => <td key={key}>{row[key]}</td>)}
    </tr>)}</tbody></table>
  </div>
}

function ActivityTable({ rows, columns }: { rows: Activity[], columns: [keyof Activity, string][] }) {
  return <div className="table-wrap"><table>
    <thead><tr><th>Clinic</th>{columns.map(([key, label]) => <th key={key}>{label}</th>)}</tr></thead>
    <tbody>{rows.map(row => <tr key={row.clinic_id}><th scope="row">{row.clinic}</th>
      {columns.map(([key]) => <td key={key}>{row[key]}</td>)}</tr>)}</tbody>
  </table></div>
}
