import { useState } from 'react'
import { useRead } from './api'
import { Empty, FilterTabs, LoadStatus, SyncLabel } from './components'
import { addDays, dateLabel, validDay, weekDays } from './dates'
import { workKinds, type Desk, type Visit, type Work } from './types'

const columns = [
  { key: 'needs_attention', name: 'Needs attention', hint: 'Unassigned follow-up' },
  { key: 'in_progress', name: 'In progress', hint: 'Assigned to a staff member' },
  { key: 'resolved', name: 'Resolved', hint: 'Closed follow-up' },
] as const

type BoardResponse = {
  page: number, pages: number, items: Work[], counts: Partial<Record<typeof columns[number]['key'], number>>,
  last_synced_at: string | null, source_failed_at: string | null
}

export function Board({ desk }: { desk: Desk }) {
  const [view, setView] = useState('active')
  const [search, setSearch] = useState('')
  const [kind, setKind] = useState('')
  const [page, setPage] = useState(1)
  const params = new URLSearchParams({ view, search, kind, page: String(page) })
  const board = useRead<BoardResponse>(`/api/clinics/${desk.clinic.id}/dashboard?${params}`, desk.staff)
  const result = board.data

  return <main className="desk shell">
    <div className="page-title split">
      <div><p className="eyebrow">{desk.clinic.city}</p><h1>Patient flow</h1></div>
      <div className="desk-identity"><strong>{desk.clinic.city}</strong><p>{desk.staff} · {desk.clinic.zone}</p></div>
    </div>
    {result && <>
      <SyncLabel clinic={desk.clinic} value={result.last_synced_at} failed={result.source_failed_at} />
      <div className="stat-grid">
        {columns.map(column => <div className="panel stat" key={column.key}>
          <p>{column.name}</p><strong>{result.counts[column.key] ?? 0}</strong><small>{column.hint}</small>
        </div>)}
      </div>
    </>}
    <div className="board-toolbar">
      <FilterTabs labels={[{ value: 'active', label: 'Active work' }, { value: 'resolved', label: 'Resolved' }]}
        active={view} onChange={next => { setView(next); setPage(1) }} />
      <a className="text-link" href="#/desk/appointments">All appointments →</a>
      <label className="search-label">Search patients
        <input type="search" placeholder="Find a patient" value={search} onChange={event => { setSearch(event.target.value); setPage(1) }} />
      </label>
    </div>
    <label className="board-filter">Follow-up type
      <select value={kind} onChange={event => { setKind(event.target.value); setPage(1) }}>
        <option value="">All follow-up types</option>
        {Object.entries(workKinds).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
      </select>
    </label>
    {result ? <>
      <div className={view === 'resolved' ? 'board-columns single' : 'board-columns'}>
        {columns.filter(column => view === 'resolved' ? column.key === 'resolved' : column.key !== 'resolved').map(column => {
          const items = result.items.filter(item => view === 'resolved' || !!item.assignee === (column.key === 'in_progress'))
          return <section className={`queue ${column.key}`} key={column.key}>
            <div className="queue-title"><h2><span />{column.name}</h2><span className="pill">{items.length} on page</span></div>
            {items.length ? items.map(item => <WorkCard key={item.id} item={item} />) : <Empty>No matching work in this queue.</Empty>}
          </section>
        })}
      </div>
      <div className="pager">
        <button className="secondary" disabled={result.page === 1} onClick={() => setPage(result.page - 1)}>Previous</button>
        <span>Page {result.page} of {result.pages}</span>
        <button className="secondary" disabled={result.page === result.pages} onClick={() => setPage(result.page + 1)}>Next</button>
      </div>
    </> : <LoadStatus error={board.error} retry={board.refresh} />}
  </main>
}

function WorkCard({ item }: { item: Work }) {
  const content = <>
    <div className="split"><span className={`pill ${item.kind}`}>{workKinds[item.kind]}</span>{item.patient && <span aria-hidden="true">↗</span>}</div>
    <h3>{item.patient ?? 'Patient record unavailable'}</h3><p>{item.reason}</p>
    <small>Visit #{item.appointment_id} · {item.assignee || 'Unassigned'}</small>
  </>
  return item.patient
    ? <a className="panel work-card" href={`#/desk/patients/${item.patient_id}?item=${item.id}`}>{content}</a>
    : <div className="panel work-card">{content}</div>
}

const visitFilters = [
  { value: 'all', label: 'All appointments', matches: () => true },
  { value: 'confirmed', label: 'Confirmed', matches: (visit: Visit) => visit.decision === 'confirmed' },
  { value: 'unconfirmed', label: 'Unconfirmed', matches: (visit: Visit) => visit.decision === 'unconfirmed' && visit.pms_status === 'scheduled' },
  { value: 'review', label: 'Replies to review', matches: (visit: Visit) => visit.review },
]

type CalendarResponse = {
  date: string, last_synced_at: string | null, source_failed_at: string | null,
  week: Record<string, number>, appointments: Visit[]
}

export function Appointments({ desk, initialDay }: { desk: Desk, initialDay: string | null }) {
  const [date, setDate] = useState(validDay(initialDay) ? initialDay : desk.clinic.today)
  const [filter, setFilter] = useState('all')
  const calendar = useRead<CalendarResponse>(`/api/clinics/${desk.clinic.id}/appointments?date=${encodeURIComponent(date)}`, desk.staff)
  const response = calendar.data
  const tabs = visitFilters.map(({ value, label, matches }) => ({ value, label, count: response?.appointments.filter(matches).length }))
  const visits = response?.appointments.filter(visitFilters.find(entry => entry.value === filter)?.matches ?? (() => true))

  return <main className="desk shell">
    <div className="page-title split"><div><p className="eyebrow">{desk.clinic.city}</p><h1>Appointments</h1></div>
      <a className="secondary" href="#/desk">Open patient flow →</a>
    </div>
    {response && <SyncLabel clinic={desk.clinic} value={response.last_synced_at} failed={response.source_failed_at} />}
    <section className="panel calendar">
      <div className="calendar-controls">
        <button className="secondary" onClick={() => setDate(addDays(date, -7))}>← Previous week</button>
        <button className="secondary" onClick={() => setDate(desk.clinic.today)}>Today</button>
        <button className="secondary" onClick={() => setDate(addDays(date, 7))}>Next week →</button>
        <label>Jump to date<input type="date" value={date} onChange={event => { if (validDay(event.target.value)) setDate(event.target.value) }} /></label>
      </div>
      <div className="week">
        {weekDays(date).map(day => <button key={day} aria-pressed={day === date} onClick={() => setDate(day)}>
          <strong>{dateLabel(day)}</strong><small>{response ? `${response.week[day] ?? 0} visits` : '—'}</small>
        </button>)}
      </div>
    </section>
    <FilterTabs labels={tabs} active={filter} onChange={setFilter} />
    {!visits ? <LoadStatus error={calendar.error} retry={calendar.refresh} /> : <VisitTable visits={visits} />}
  </main>
}

export function VisitTable({ visits, compact = false }: { visits: Visit[], compact?: boolean }) {
  return <div className="panel table-wrap">
    {visits.length ? <table>
      <thead><tr><th>{compact ? 'Visit' : 'Patient'}</th><th>Appointment · local time</th><th>Confirmation</th><th>Visit outcome</th>
        {!compact && <th>Next step</th>}</tr></thead>
      <tbody>{visits.map(visit => <tr key={visit.id}>
        <th scope="row">{compact ? `#${visit.id}` : visit.patient}{!compact && <small>Visit #{visit.id}</small>}</th>
        <td>{dateLabel(visit.wall_time)} · {visit.local_time || 'Time needs review'}<small>{visit.provider}</small></td>
        <td><VisitState visit={visit} /></td>
        <td className="capitalize">{visit.outcome}<small>{visit.pms_status === 'broken' ? 'Broken in PMS' : visit.pms_status}</small></td>
        {!compact && <td><a className="text-link" href={`#/desk/patients/${visit.patient_id}`}>Patient details →</a></td>}
      </tr>)}</tbody>
    </table> : <Empty>No appointments match this view.</Empty>}
  </div>
}

export function VisitState({ visit }: { visit: Visit }) {
  return <><span className={`pill capitalize ${visit.decision}`}>{visit.decision}</span>
    {visit.review && <small>Reply needs review</small>}</>
}
