import { describe, expect, it } from 'vitest'
import { addDays, dateLabel, validDay, weekDays } from './dates'

describe('appointment calendar', () => {
  it('builds a Monday-first week across a month and year boundary', () => {
    expect(weekDays('2027-01-01')).toEqual([
      '2026-12-28', '2026-12-29', '2026-12-30', '2026-12-31', '2027-01-01', '2027-01-02', '2027-01-03',
    ])
  })

  it('preserves clinic wall-clock dates through browser timezone and DST boundaries', () => {
    expect(addDays('2026-03-08', 1)).toBe('2026-03-09')
    expect(dateLabel('2026-03-08T00:30:00.000000')).toBe('Sun, Mar 8')
  })

  it('rejects links that contain invalid calendar dates', () => {
    expect(validDay('2026-02-29')).toBe(false)
    expect(validDay('2028-02-29')).toBe(true)
    expect(validDay(null)).toBe(false)
  })
})
