# Architecture

```mermaid
flowchart LR
  PMS["PostgreSQL PMS replica"] -->|Read| Rails["Rails API and reminder command"]
  React["React workspaces"] <-->|JSON| Rails
  Rails -->|SMS or email attempt| Adapter["Local fake transport"]
  Adapter -->|Simulated outcome| Rails
  Rails <-->|Transactions and clinic lock| Workflow["PostgreSQL workflow tables"]
  Rails -->|Aggregate counts| Leadership["Leadership report"]
```

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed
  Unconfirmed --> Confirmed: Matched YES or staff confirmation
  Unconfirmed --> NeedsReview: Unsafe or unclear reply
  NeedsReview --> Confirmed: Staff confirms a current candidate
  NeedsReview --> Unconfirmed: Staff closes review without confirmation
  Confirmed --> Confirmed: Later conflict opens separate staff review
  Unconfirmed --> Closed: Staff cancellation or reschedule
  Confirmed --> Closed: Staff cancellation or reschedule
  Unconfirmed --> NewRevision: PMS changes the visit
  Confirmed --> NewRevision: PMS changes the visit
  NewRevision --> Unconfirmed
```

Reply review is a separate work item, and a PMS outcome is a separate source fact. Changing the source revision removes the previous decision from the current visit view and preserves its historical record.

- The reminder command restricts reads to each clinic and the current seven-day horizon. It looks up each applicable decision, prior attempts for its version, verified details, and opt-outs before simulating delivery. A unique index identifies a send step by clinic, appointment, and revision.
- Incoming replies enter through the patient demo endpoint. Rails checks clinic membership, channel identity, prior sends, freshness, and recipient ambiguity before recording the reply with a confirmation or a staff task. The caller supplies a stable reply event ID. Staff writes use request IDs for explicit retry.
- A clinic row lock serializes local writes inside a repeatable-read transaction. Every committed operation updates the locked row so a transaction with an older snapshot retries before using local permission state. Batch and reply workflows also take a shared lock on the contact directory. Verification takes an exclusive lock and updates that row because recipient ownership spans clinics. Attempts, decisions, and work updates roll back together. The fake adapter runs entirely in-process.
- The Rails source models are read-only. The PostgreSQL appointment view centralizes revision computation over the supplied schema. The migration and fixture loader are the intended source writers. Leadership queries aggregate by clinic and date before serialization.
