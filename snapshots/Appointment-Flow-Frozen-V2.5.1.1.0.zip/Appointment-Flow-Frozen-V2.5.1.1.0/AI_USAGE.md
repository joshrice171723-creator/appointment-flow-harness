# AI usage

OpenAI Codex implemented the clean-room rebuild in a new checkout, reviewed the provided assessment and ten screenshots, and wrote and ran Rails, React, PostgreSQL, and browser checks. The earlier implementation was outside the build context.

Joshua instructed Codex to run and pass the harness preflight before building and to use the harness to verify the application. The preflight ran against the extracted package before application files were written. Decisions made by Codex are recorded as implementation notes for the candidate. The candidate's personal decision narrative and live defense are their own work.

A separate read-only Codex review session evaluated line-numbered source after its terminal integration failed to launch. Its findings drove repairs to SMS origin handling, cross-clinic contact locking, source failure handling, stale board work, board links outside the history cap, search redaction, and repeated queries. The implementation session ran the tests, browser smoke, and workload checks. Review findings and runtime evidence are in the verification record.
