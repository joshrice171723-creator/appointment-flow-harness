Rails.application.config.filter_parameters += %i[ body note birthdate phone email contact recipient search ]
