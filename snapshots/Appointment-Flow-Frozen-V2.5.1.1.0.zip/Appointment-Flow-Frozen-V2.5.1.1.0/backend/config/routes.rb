Rails.application.routes.draw do
  get "up" => "rails/health#show", as: :rails_health_check

  namespace :api do
    resources :clinics, only: :index do
      resource :dashboard, only: :show
      resources :appointments, only: :index
      resources :work_items, only: [] do
        resource :assignment, only: :create
        resources :follow_ups, only: :create
      end
      resources :patients, only: %i[ index show ] do
        resource :contact_verification, only: :create
        resource :inbox, only: :show
        resources :replies, only: :create
      end
    end
    resource :leadership_report, only: :show
  end
end
