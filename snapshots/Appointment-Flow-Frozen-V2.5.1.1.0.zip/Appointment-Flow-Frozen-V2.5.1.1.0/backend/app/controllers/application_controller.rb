class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound, with: :not_found
  rescue_from InvalidWorkflow, with: :invalid_workflow
  rescue_from ClinicState::SourceUnavailable, ActiveRecord::ConnectionNotEstablished, with: :source_unavailable

  before_action { response.headers["Cache-Control"] = "no-store" }

  private

  def not_found
    render json: { error: "This record is unavailable in the selected clinic." }, status: :not_found
  end

  def invalid_workflow(error)
    render json: { error: error.message }, status: :unprocessable_entity
  end

  def source_unavailable
    render json: { error: "The PMS is temporarily unavailable. Refresh before continuing." }, status: :service_unavailable
  end
end
