module Api
  class FollowUpsController < ClinicController
    before_action :require_staff

    def create
      entry = params.permit(:action_name, :note, :request_id, candidates: [])
      event = StaffFollowUp.new(clinic_id: @clinic.id, staff: @staff).record(item_id: params[:work_item_id],
        action: entry[:action_name], note: entry[:note], request_id: entry[:request_id], candidates: entry[:candidates])
      render json: { id: event.id }, status: :created
    end
  end
end
