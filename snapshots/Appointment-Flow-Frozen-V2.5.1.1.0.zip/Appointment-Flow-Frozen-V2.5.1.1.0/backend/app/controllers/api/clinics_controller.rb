module Api
  class ClinicsController < ApplicationController
    def index
      render json: Pms::Clinic.where(id: Pms::Clinic::ZONES.keys).order(:id).map { |clinic|
        { id: clinic.id, name: clinic.name, city: clinic.city, today: DemoClock.now.in_time_zone(clinic.zone).to_date,
          staff: clinic.staff, zone: clinic.zone.tzinfo.identifier }
      }
    end
  end
end
