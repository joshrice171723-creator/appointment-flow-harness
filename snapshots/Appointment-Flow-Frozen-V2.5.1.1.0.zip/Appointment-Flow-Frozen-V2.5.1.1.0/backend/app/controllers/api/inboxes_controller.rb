module Api
  class InboxesController < ClinicController
    def show
      patient = @clinic.patients.find(params[:patient_id])
      channel = params[:channel]
      raise InvalidWorkflow, "Choose Text messages or Email." unless PatientReply::CHANNELS.include?(channel)

      history = Message.where(clinic_id: @clinic.id, patient_id: patient.id, channel: channel)
      messages = history.where.not(status: "failed").order(created_at: :desc, id: :desc).limit(50)
      sms_origins = channel == "sms" ? history.sent.where(created_at: ..DemoClock.now)
        .group(:recipient).maximum(:id).map { |recipient, id| { recipient: recipient, id: id } } : []
      render json: {
        messages: messages.to_a.reverse.as_json(only: %i[ id body status direction created_at ]),
        sms_origins: sms_origins
      }
    end
  end
end
