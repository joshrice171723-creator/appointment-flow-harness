module Api
  class ClinicController < ApplicationController
    before_action :load_clinic

    private

    def load_clinic
      @clinic = Pms::Clinic.where(id: Pms::Clinic::ZONES.keys).find(params[:clinic_id])
    end

    def require_staff
      @staff = request.headers["X-Demo-Staff"]
      raise InvalidWorkflow, "Select a staff member for this clinic." unless @clinic.staff.include?(@staff)
    end
  end
end
