module Api
  class AppointmentsController < ClinicController
    before_action :require_staff

    def index
      date = CalendarDate.parse(params[:date])
      raise InvalidWorkflow, "Choose a valid date." if params[:date].present? && !date

      date ||= DemoClock.now.in_time_zone(@clinic.zone).to_date
      visits = @clinic.appointments.on_dates(date..date).includes(:patient).order(:start_at, :id).to_a
      monday = date.beginning_of_week
      week = @clinic.appointments.on_dates(monday..(monday + 6))
        .group(Arel.sql("start_at::date")).count
      state = ClinicState.find(@clinic.id)
      render json: {
        date: date, last_synced_at: state.last_synced_at, source_failed_at: state.source_failed_at, week: week,
        appointments: AppointmentOverview.new(@clinic, visits).rows
      }
    end
  end
end
