module Api
  class AssignmentsController < ClinicController
    before_action :require_staff

    def create
      item = StaffFollowUp.new(clinic_id: @clinic.id, staff: @staff).assign(params[:work_item_id])
      render json: WorkBoard.item_json(item)
    end
  end
end
