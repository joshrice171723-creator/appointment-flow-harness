module Api
  class PatientsController < ClinicController
    before_action :require_staff, only: :show

    def index
      render json: @clinic.patients.order(:first_name, :last_name, :id).pluck(:id, :first_name, :last_name).map { |id, first, last|
        { id: id, name: "#{first} #{last}" }
      }
    end

    def show
      patient = @clinic.patients.find(params[:id])
      verification = ContactVerification.find_by(clinic_id: @clinic.id, patient_id: patient.id)
      visits = @clinic.appointments.where(patient_id: patient.id).includes(:patient).order(start_at: :desc).limit(50).to_a
      work = WorkItem.where(clinic_id: @clinic.id, patient_id: patient.id).includes(:message)
      items = work.order(id: :desc).limit(50).to_a
      if (selected = params[:item].to_s).match?(/\A\d+\z/) && items.none? { |item| item.id.to_s == selected }
        item = work.find_by(id: selected)
        items.unshift(item) if item
      end
      events = WorkEvent.where(clinic_id: @clinic.id, patient_id: patient.id).order(id: :desc).limit(50)
      render json: {
        id: patient.id, name: patient.name, contact: ContactProfile.new(patient, verification),
        appointments: AppointmentOverview.new(@clinic, visits).rows,
        items: work_history(items),
        events: events.as_json(only: %i[ id staff action note created_at ])
      }
    end

    private

    def work_history(items)
      candidate_ids = items.flat_map { |item| item.message&.candidates.to_a.map { |candidate| candidate.fetch("id") } }
      visits = @clinic.appointments.where(id: candidate_ids).includes(:patient).index_by(&:id)
      items.map do |item|
        payload = WorkBoard.item_json(item)
        next payload unless item.kind == "reply_review" && item.message

        candidates = item.message.candidates.filter_map do |reference|
          visit = visits[reference.fetch("id")]
          next unless visit

          { id: visit.id, patient: visit.patient.name, wall_time: visit.wall_time,
            current: visit.revision == reference.fetch("revision") }
        end
        payload.merge(reply: item.message.body, candidates: candidates)
      end
    end
  end
end
