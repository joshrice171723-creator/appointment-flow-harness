module Api
  class RepliesController < ClinicController
    def create
      entry = params.permit(:channel, :external_id, :body, :message_id)
      reply = PatientReply.new(clinic_id: @clinic.id, patient_id: params[:patient_id], channel: entry[:channel],
        external_id: entry[:external_id], body: entry[:body], message_id: entry[:message_id]).record
      render json: { id: reply.id, status: reply.status }, status: :created
    end
  end
end
