module Api
  class LeadershipReportsController < ApplicationController
    def show
      raw = params[:month].presence || DemoClock.now.strftime("%Y-%m")
      month = CalendarDate.parse("#{raw}-01")
      raise InvalidWorkflow, "Choose a reporting month." unless month

      render json: LeadershipReport.new(month)
    end
  end
end
