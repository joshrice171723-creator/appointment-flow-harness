module Api
  class DashboardsController < ClinicController
    before_action :require_staff

    def show
      page = WorkBoard.new(@clinic).page(view: params[:view], kind: params[:kind],
        search: params[:search].to_s.strip.first(100), page: params[:page].to_i)
      state = ClinicState.find(@clinic.id)
      render json: page.merge(last_synced_at: state.last_synced_at, source_failed_at: state.source_failed_at)
    end
  end
end
