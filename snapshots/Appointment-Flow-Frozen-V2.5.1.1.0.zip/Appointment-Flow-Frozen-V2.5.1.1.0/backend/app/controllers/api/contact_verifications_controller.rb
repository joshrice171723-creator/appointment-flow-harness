module Api
  class ContactVerificationsController < ClinicController
    before_action :require_staff

    def create
      entry = params.permit(:note, :request_id, values: ContactProfile::FIELDS)
      event = VerifyPatientContact.record(clinic_id: @clinic.id, patient_id: params[:patient_id], staff: @staff,
        values: entry.fetch(:values, {}).to_h, note: entry[:note], request_id: entry[:request_id])
      render json: { id: event.id }, status: :created
    end
  end
end
