class PatientReply
  CHANNELS = %w[ sms email ].freeze
  CONFIRMATIONS = %w[ YES SÍ SI ].freeze

  def initialize(clinic_id:, patient_id:, channel:, external_id:, body:, message_id: nil, now: nil)
    @clinic_id = clinic_id
    @patient_id = patient_id
    @channel = channel
    @external_id = external_id
    @body = body.to_s.strip
    @message_id = message_id
    @now = now
  end

  def record
    validate_input!
    ClinicState.with_replica(@clinic_id) do |clinic, _state|
      patient = clinic.patients.find(@patient_id)
      duplicate = Message.inbound.find_by(clinic_id: clinic.id, channel: @channel, external_id: @external_id)
      if duplicate
        unless duplicate.patient_id == patient.id && duplicate.body == @body && duplicate.in_reply_to_id.to_s == @message_id.to_s
          raise InvalidWorkflow, "This reply identifier was already used."
        end
        next duplicate
      end

      now = @now || DemoClock.now
      ContactDirectory.lock_for_read!
      verification = ContactVerification.find_by(clinic_id: clinic.id, patient_id: patient.id)
      profile = ContactProfile.new(patient, verification)
      history = sent_to_patient(clinic, patient).where(created_at: ..now)
      thread = history.find(@message_id) if @message_id.present?
      current_recipient = @channel == "sms" ? profile.phone : profile.email
      if @channel == "sms" && !thread && history.where.not(recipient: current_recipient).exists?
        raise InvalidWorkflow, "Choose the number that received the text before replying."
      end
      recipient = thread&.recipient || current_recipient
      raise InvalidWorkflow, "This patient has no usable address for the selected channel." unless recipient

      if @channel == "sms" && @body.casecmp?("STOP")
        SmsOptOut.find_or_create_by!(clinic_id: clinic.id, recipient: recipient)
        next save_reply(clinic, patient, recipient, "opted_out", [], nil, now)
      end

      owners = ContactProfile.owners(@channel, [ recipient ]).fetch(recipient, [])
      local_now = now.in_time_zone(clinic.zone)
      visits = clinic.appointments.scheduled.where(patient_id: owners | [ patient.id ])
        .on_dates(local_now.to_date..(local_now.to_date + ReminderBatch::LOOKAHEAD_DAYS)).to_a
      visits.each { |visit| visit.clinic = clinic }
      active = active_visits(visits, now)
      sent = Message.sent.where(clinic_id: clinic.id, channel: @channel, recipient: recipient)
      candidates = matching_visits(active, sent, thread, patient, now)
      visit = candidates.first
      hold = profile.hold_on(local_now.to_date)
      opted_out = @channel == "sms" && SmsOptOut.exists?(clinic_id: clinic.id, recipient: recipient)
      can_confirm = CONFIRMATIONS.include?(@body.upcase) && owners == [ patient.id ] &&
        recipient == current_recipient && !hold && !opted_out && candidates.one?

      if can_confirm
        VisitDecision.record!(visit, "confirmed")
        WorkItem.for_visit(visit).open.where(kind: "no_reply").update_all(resolved_at: now, updated_at: now)
        save_reply(clinic, patient, recipient, "confirmed", candidates, visit, now)
      else
        review_candidates = owners == [ patient.id ] ? (candidates.presence || active) : active
        anchor = review_candidates.find { |entry| entry.patient_id == patient.id } ||
          clinic.appointments.where(patient_id: patient.id).order(start_at: :desc).first!
        reply = save_reply(clinic, patient, recipient, "review", review_candidates, anchor, now)
        WorkItem.flag!(anchor, "reply_review", reason: "Review the patient's reply and clarify which visit it concerns.",
          event_key: "reply:#{reply.id}", message: reply)
        reply
      end
    end
  end

  private

  def validate_input!
    raise InvalidWorkflow, "Choose Text messages or Email." unless CHANNELS.include?(@channel)
    raise InvalidWorkflow, "Enter a reply between 1 and 500 characters." unless @body.length.between?(1, 500)
    unless @external_id.to_s.match?(/\A[0-9a-zA-Z_-]{1,100}\z/)
      raise InvalidWorkflow, "A valid reply identifier is required."
    end
  end

  def sent_to_patient(clinic, patient)
    Message.sent.where(clinic_id: clinic.id, patient_id: patient.id, channel: @channel)
  end

  def active_visits(visits, now)
    closed = VisitDecision.where(clinic_id: @clinic_id, appointment_id: visits.map(&:id),
      state: %w[ canceled rescheduled ]).pluck(:appointment_id, :revision).to_set
    visits.select { |visit| visit.upcoming?(now) && !closed.include?([ visit.id, visit.revision ]) }
  end

  def matching_visits(visits, sent, thread, patient, now)
    if thread && @channel == "email"
      return visits.select { |visit| thread.created_at <= now && thread.appointment_id == visit.id && thread.revision == visit.revision }
    end

    # A plain YES has no appointment identifier. More than one historical
    # version on this recipient's channel makes a delayed reply ambiguous.
    versions = sent.where(created_at: ..now).distinct.limit(2).pluck(:appointment_id, :revision, :patient_id)
    return [] unless versions.one?

    visits.select { |visit| versions.first == [ visit.id, visit.revision, patient.id ] }
  end

  def save_reply(clinic, patient, recipient, status, candidates, visit, now)
    Message.create!(clinic_id: clinic.id, patient_id: patient.id, channel: @channel, direction: "inbound",
      recipient: recipient, external_id: @external_id, in_reply_to_id: @message_id, body: @body, status: status, created_at: now,
      appointment_id: visit&.id, revision: visit&.revision,
      candidates: candidates.map { |entry| { id: entry.id, revision: entry.revision } })
  end
end
