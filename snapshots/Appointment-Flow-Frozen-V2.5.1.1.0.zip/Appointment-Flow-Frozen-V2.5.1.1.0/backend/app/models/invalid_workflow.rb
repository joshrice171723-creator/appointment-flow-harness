class InvalidWorkflow < StandardError
end
