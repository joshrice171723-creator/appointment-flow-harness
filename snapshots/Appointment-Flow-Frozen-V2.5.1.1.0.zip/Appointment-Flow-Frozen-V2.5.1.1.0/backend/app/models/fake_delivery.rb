class FakeDelivery
  # Fixture convention for demonstrating delivery failure without a network call.
  def deliver(channel:, recipient:, body:)
    raise ArgumentError, "A message body is required" if body.blank?

    failed = (channel == "sms" && recipient.end_with?("0199")) ||
      (channel == "email" && recipient.start_with?("bounce@"))
    failed ? "failed" : "sent"
  end
end
