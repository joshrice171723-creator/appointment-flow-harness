module Pms
  class Appointment < Record
    self.table_name = "pms.versioned_appointments"
    self.primary_key = "id"
    self.skip_time_zone_conversion_for_attributes = %i[ start_at updated_at ]

    belongs_to :clinic, class_name: "Pms::Clinic"
    belongs_to :patient, class_name: "Pms::Patient"

    scope :scheduled, -> { where(status: "scheduled") }
    scope :on_dates, ->(dates) { where(start_at: dates.begin.midnight...(dates.end + 1).midnight) }

    def wall_time
      start_at.strftime("%Y-%m-%dT%H:%M:%S.%6N")
    end

    # An ambiguous or nonexistent wall time cannot safely drive outreach.
    def starts_at
      return unless clinic.zone.tzinfo.periods_for_local(start_at).one?

      clinic.zone.tzinfo.local_to_utc(start_at)
    end

    def upcoming?(now)
      status == "scheduled" && starts_at && starts_at > now
    end
  end
end
