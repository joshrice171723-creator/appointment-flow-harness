module Pms
  class Record < ApplicationRecord
    self.abstract_class = true

    def readonly?
      true
    end
  end
end
