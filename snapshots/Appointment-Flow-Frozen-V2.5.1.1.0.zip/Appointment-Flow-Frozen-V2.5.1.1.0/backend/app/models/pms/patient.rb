module Pms
  class Patient < Record
    self.table_name = "pms.patients"

    def name
      "#{first_name} #{last_name}"
    end
  end
end
