module Pms
  class Clinic < Record
    self.table_name = "pms.clinics"
    ZONES = { 1 => "America/Chicago", 2 => "America/Phoenix" }.freeze
    STAFF = { 1 => %w[Morgan Riley], 2 => %w[Jordan Casey] }.freeze

    has_many :appointments, class_name: "Pms::Appointment"

    def zone
      ActiveSupport::TimeZone[ZONES.fetch(id)]
    end

    def staff
      STAFF.fetch(id)
    end

    def patients
      Patient.where(id: appointments.select(:patient_id))
    end
  end
end
