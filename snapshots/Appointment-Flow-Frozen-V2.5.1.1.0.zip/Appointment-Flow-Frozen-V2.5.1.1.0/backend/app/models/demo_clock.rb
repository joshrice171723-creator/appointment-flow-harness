class DemoClock
  def self.now
    ENV["DEMO_NOW"].present? ? Time.iso8601(ENV.fetch("DEMO_NOW")) : Time.current
  end
end
