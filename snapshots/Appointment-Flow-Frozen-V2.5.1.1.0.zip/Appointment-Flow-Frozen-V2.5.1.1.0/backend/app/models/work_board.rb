class WorkBoard
  PAGE_SIZE = 12
  KINDS = %w[ no_reply contact_hold delivery_failed reply_review ].freeze

  def initialize(clinic)
    @clinic = clinic
    @items = WorkItem.where(clinic_id: clinic.id)
  end

  def page(view:, kind:, search:, page:)
    relation = view == "resolved" ? @items.where.not(resolved_at: nil) : @items.open
    relation = relation.where(kind: kind) if KINDS.include?(kind)
    if search.present?
      term = "%#{Pms::Patient.sanitize_sql_like(search)}%"
      matching = @clinic.patients.where("concat_ws(' ', first_name, last_name) ILIKE ?", term)
      relation = relation.where(patient_id: matching.select(:id))
    end
    total = relation.count
    last_page = [ (total.to_f / PAGE_SIZE).ceil, 1 ].max
    current = page.clamp(1, last_page)
    items = relation.order(id: :desc).limit(PAGE_SIZE).offset((current - 1) * PAGE_SIZE).to_a
    names = @clinic.patients.where(id: items.map(&:patient_id)).pluck(:id, :first_name, :last_name)
      .to_h { |id, first, last| [ id, "#{first} #{last}" ] }
    {
      counts: counts,
      page: current, pages: last_page,
      items: items.map { |item| WorkBoard.item_json(item).merge(patient: names[item.patient_id]) }
    }
  end

  def self.item_json(item)
    item.as_json(only: %i[ id patient_id appointment_id kind assignee resolved_at reason created_at ])
  end

  private

  def counts
    @items.group(Arel.sql(<<~SQL.squish)).count
      CASE WHEN resolved_at IS NOT NULL THEN 'resolved'
           WHEN assignee IS NOT NULL THEN 'in_progress'
           ELSE 'needs_attention' END
    SQL
  end
end
