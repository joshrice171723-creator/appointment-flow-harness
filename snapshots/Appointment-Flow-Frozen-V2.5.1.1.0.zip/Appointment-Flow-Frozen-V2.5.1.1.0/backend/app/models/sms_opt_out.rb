class SmsOptOut < ApplicationRecord
end
