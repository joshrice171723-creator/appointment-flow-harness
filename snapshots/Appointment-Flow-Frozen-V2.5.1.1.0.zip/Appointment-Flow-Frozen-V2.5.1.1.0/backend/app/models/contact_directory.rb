class ContactDirectory < ApplicationRecord
  # Readers in different clinics can run together. A correction changes the
  # row so any waiting repeatable-read transaction restarts on a new snapshot.
  def self.lock_for_read!
    lock("FOR SHARE").find(1)
  end

  def self.lock_for_change!
    directory = lock.find(1)
    directory.update!(generation: directory.generation + 1)
  end
end
