class WorkEvent < ApplicationRecord
  belongs_to :work_item, optional: true
end
