module CalendarDate
  def self.parse(value)
    value = value.to_s
    return unless /\A\d{4}-\d{2}-\d{2}\z/.match?(value)

    Date.iso8601(value)
  rescue Date::Error
    nil
  end
end
