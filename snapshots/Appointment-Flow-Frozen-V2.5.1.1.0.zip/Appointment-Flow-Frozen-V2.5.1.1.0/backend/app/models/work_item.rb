class WorkItem < ApplicationRecord
  belongs_to :message, optional: true
  has_many :work_events
  scope :open, -> { where(resolved_at: nil) }

  def self.for_visit(visit)
    where(clinic_id: visit.clinic_id, appointment_id: visit.id, revision: visit.revision)
  end

  def self.flag!(visit, kind, reason:, event_key: kind, message: nil)
    for_visit(visit).find_by(event_key: event_key) ||
      build_for(visit, kind, reason: reason, event_key: event_key, message: message).tap(&:save!)
  end

  def self.build_for(visit, kind, reason:, event_key: kind, message: nil)
    for_visit(visit).new(patient_id: visit.patient_id, kind: kind, reason: reason, event_key: event_key, message: message)
  end
end
