class LeadershipReport
  HISTORY_MONTHS = 6
  OUTCOMES = %w[ completed rescheduled canceled unknown ].freeze

  def initialize(month)
    @month = month
    @months = (0...HISTORY_MONTHS).map { |offset| month << offset }
    @clinics = Pms::Clinic.where(id: Pms::Clinic::ZONES.keys).order(:id).to_a
  end

  def as_json(*)
    history = @clinics.flat_map do |clinic|
      counts = outcomes(clinic)
      @months.map do |month|
        statuses = OUTCOMES.to_h { |status| [ status, counts.fetch([ month, status ], 0) ] }
        statuses.merge(clinic_id: clinic.id, clinic: clinic.city, month: month.strftime("%Y-%m"),
          recorded: statuses.values.sum)
      end
    end
    {
      clinics: history.select { |row| row[:month] == @month.strftime("%Y-%m") },
      history: history,
      activity: @clinics.map { |clinic| activity(clinic) }
    }
  end

  private

  def outcomes(clinic)
    join = <<~SQL.squish
      LEFT JOIN visit_decisions
        ON visit_decisions.clinic_id = pms.versioned_appointments.clinic_id
        AND visit_decisions.appointment_id = pms.versioned_appointments.id
        AND visit_decisions.revision = pms.versioned_appointments.revision
    SQL
    outcome = <<~SQL.squish
      CASE WHEN pms.versioned_appointments.status = 'complete' THEN 'completed'
           WHEN visit_decisions.state IN ('rescheduled', 'canceled') THEN visit_decisions.state
           ELSE 'unknown' END
    SQL
    clinic.appointments.on_dates(@months.last..@month.end_of_month).joins(join)
      .group(Arel.sql("date_trunc('month', pms.versioned_appointments.start_at)::date"), Arel.sql(outcome)).count
  end

  def activity(clinic)
    following = @month.next_month
    dates = clinic.zone.local(@month.year, @month.month)...clinic.zone.local(following.year, following.month)
    sent = Message.outbound.where(clinic_id: clinic.id, created_at: dates).group(:status).count
    holds = WorkItem.where(clinic_id: clinic.id, created_at: dates, kind: "contact_hold").count
    follow_ups = WorkEvent.where(clinic_id: clinic.id, created_at: dates).where.not(work_item_id: nil).count
    { clinic_id: clinic.id, clinic: clinic.city, sent: sent.fetch("sent", 0), failed: sent.fetch("failed", 0),
      contact_holds: holds, follow_ups: follow_ups }
  end
end
