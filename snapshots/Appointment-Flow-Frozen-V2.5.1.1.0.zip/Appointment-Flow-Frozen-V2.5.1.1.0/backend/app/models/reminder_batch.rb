class ReminderBatch
  LOOKAHEAD_DAYS = 7
  WINDOW = 10...18
  FOLLOW_UP_DAYS = 3
  BACKUP_DAYS = 6
  NEAR_VISIT_HOURS = 48

  def initialize(now: nil, delivery: FakeDelivery.new)
    @now = now
    @delivery = delivery
  end

  def run(clinic_id)
    ClinicState.with_replica(clinic_id) do |clinic, state|
      now = @now || DemoClock.now
      local = now.in_time_zone(clinic.zone)
      visits = clinic.appointments.scheduled.on_dates(local.to_date..(local.to_date + LOOKAHEAD_DAYS))
        .includes(:patient).to_a
      visits.each { |visit| visit.clinic = clinic }
      ContactDirectory.lock_for_read!
      prepare_contacts(clinic_id, visits)
      visit_keys = { clinic_id: clinic_id, appointment_id: visits.map(&:id), revision: visits.map(&:revision) }
      decisions = VisitDecision.where(visit_keys).index_by(&:appointment_id)
      attempts = Message.outbound.where(visit_keys).group_by(&:appointment_id)
      @work = WorkItem.where(visit_keys.merge(event_key: %w[ no_reply contact_hold ]))
        .index_by { |item| [ item.appointment_id, item.event_key ] }
      reconcile_open_work(clinic, local)
      counts = { sent: 0, failed: 0 }
      visits.each do |visit|
        outcome = process(visit, local, decisions[visit.id]&.state, attempts.fetch(visit.id, []))
        counts[outcome.to_sym] += 1 if outcome
      end
      state.last_synced_at = now
      state.source_failed_at = nil
      counts
    end
  rescue ClinicState::SourceUnavailable
    ClinicState.where(id: clinic_id).update_all(source_failed_at: Time.current)
    raise
  end

  private

  def reconcile_open_work(clinic, local)
    matching = clinic.appointments.where("pms.versioned_appointments.id = work_items.appointment_id")
    closed = matching.where(<<~SQL.squish, local.strftime("%Y-%m-%d %H:%M:%S.%6N"))
      (pms.versioned_appointments.revision <> work_items.revision OR
      pms.versioned_appointments.status <> 'scheduled' OR pms.versioned_appointments.start_at <= ?
      )
    SQL
    retired = closed.arel.exists.or(Arel::Nodes::Not.new(matching.arel.exists))
    WorkItem.open.where(clinic_id: clinic.id).where.not(kind: "reply_review")
      .where(retired).update_all(resolved_at: local, updated_at: local)
  end

  def prepare_contacts(clinic_id, visits)
    verifications = ContactVerification.where(clinic_id: clinic_id, patient_id: visits.map(&:patient_id)).index_by(&:patient_id)
    @profiles = visits.map(&:patient).uniq(&:id).to_h do |patient|
      [ patient.id, ContactProfile.new(patient, verifications[patient.id]) ]
    end
    phones = @profiles.values.filter_map(&:phone).uniq
    emails = @profiles.values.filter_map(&:email).uniq
    @phone_owners = ContactProfile.owners("sms", phones)
    @email_owners = ContactProfile.owners("email", emails)
    @opt_outs = SmsOptOut.where(clinic_id: clinic_id, recipient: phones).pluck(:recipient).to_set
  end

  def process(visit, local, decision, attempts)
    return if %w[ canceled rescheduled ].include?(decision)
    unless visit.starts_at
      hold_visit(visit, "Verify the appointment's local time.")
      return
    end
    return unless visit.upcoming?(local)

    confirmed = decision == "confirmed"
    if !confirmed && visit.starts_at <= local + NEAR_VISIT_HOURS.hours
      ensure_work(visit, "no_reply", "This visit starts within 48 hours and still needs confirmation.")
    end

    profile = @profiles.fetch(visit.patient_id)
    sms = profile.phone if @phone_owners[profile.phone] == [ visit.patient_id ] && !@opt_outs.include?(profile.phone)
    email = profile.email if @email_owners[profile.email] == [ visit.patient_id ]
    hold = profile.hold_on(local.to_date)
    hold ||= "Check for shared contacts, invalid details, or an SMS opt-out." unless sms || email
    if hold
      hold_visit(visit, hold)
      return
    end
    previous_hold = @work[[ visit.id, "contact_hold" ]]
    previous_hold.update!(resolved_at: local) if previous_hold && !previous_hold.resolved_at
    return unless WINDOW.include?(local.hour)
    return if attempts.any? { |attempt| attempt.created_at >= local.beginning_of_day }

    days = (visit.start_at.to_date - local.to_date).to_i
    step, channel = next_step(days, confirmed, attempts, sms, email)
    return if step.nil? || attempts.any? { |attempt| attempt.step == step }
    return unless @now || (visit.upcoming?(DemoClock.now) && WINDOW.include?(DemoClock.now.in_time_zone(visit.clinic.zone).hour))

    recipient = channel == "sms" ? sms : email
    body = message_body(visit, profile, channel, confirmed)
    status = @delivery.deliver(channel: channel, recipient: recipient, body: body)
    message = Message.create!(clinic_id: visit.clinic_id, patient_id: visit.patient_id, appointment_id: visit.id,
      revision: visit.revision, step: step, channel: channel, direction: "outbound",
      recipient: recipient, body: body, status: status, created_at: local)
    if status == "failed"
      WorkItem.flag!(visit, "delivery_failed", reason: "The simulated #{channel.upcase} delivery failed.",
        event_key: "delivery:#{step}", message: message)
    end
    status
  end

  def hold_visit(visit, reason)
    ensure_work(visit, "contact_hold", reason, reopen: true)
  end

  def ensure_work(visit, kind, reason, reopen: false)
    item = @work[[ visit.id, kind ]] || WorkItem.build_for(visit, kind, reason: reason)
    item.assign_attributes(resolved_at: nil, reason: reason) if reopen
    item.save! if item.new_record? || item.changed?
  end

  def next_step(days, confirmed, attempts, sms, email)
    primary = sms ? "sms" : "email"
    primary = "email" if email && attempts.any? { |attempt| attempt.channel == "sms" && attempt.status == "failed" }

    return [ "final", primary ] if days <= 1
    return if confirmed
    return [ "follow_up", primary ] if days <= FOLLOW_UP_DAYS
    if days <= BACKUP_DAYS && email && attempts.any? { |attempt| attempt.step == "initial" && attempt.channel == "sms" }
      return [ "backup", "email" ]
    end

    [ "initial", primary ]
  end

  def message_body(visit, profile, channel, confirmed)
    time = visit.starts_at.in_time_zone(visit.clinic.zone).strftime("%Y-%m-%d %I:%M %p %Z")
    if profile.language == "es"
      text = "Cita dental en #{visit.clinic.name}: #{time}."
      text += " Responda SÍ para confirmar o NO si necesita ayuda." unless confirmed
      text += " Envíe STOP para dejar de recibir mensajes de texto." if channel == "sms"
    else
      text = "Dental appointment at #{visit.clinic.name}: #{time}."
      text += " Reply YES to confirm or NO for help." unless confirmed
      text += " Reply STOP to opt out of text messages." if channel == "sms"
    end
    text
  end
end
