class Message < ApplicationRecord
  scope :outbound, -> { where(direction: "outbound") }
  scope :inbound, -> { where(direction: "inbound") }
  scope :sent, -> { outbound.where(status: "sent") }
end
