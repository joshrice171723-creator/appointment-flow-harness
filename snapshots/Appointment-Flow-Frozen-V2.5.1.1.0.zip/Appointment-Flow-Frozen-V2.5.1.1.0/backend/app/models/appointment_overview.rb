class AppointmentOverview
  def initialize(clinic, visits)
    @clinic = clinic
    @visits = visits
    ids = visits.map(&:id)
    @decisions = VisitDecision.where(clinic_id: clinic.id, appointment_id: ids, revision: visits.map(&:revision))
      .index_by { |decision| [ decision.appointment_id, decision.revision ] }
    @reviews = WorkItem.open.where(clinic_id: clinic.id, appointment_id: ids, kind: "reply_review").distinct.pluck(:appointment_id).to_set
  end

  def rows
    @visits.map do |visit|
      visit.clinic = @clinic
      decision = @decisions[[ visit.id, visit.revision ]]&.state
      outcome = visit.status == "complete" ? "completed" : (decision.presence_in(%w[ canceled rescheduled ]) || "unknown")
      {
        id: visit.id, patient_id: visit.patient_id, patient: visit.patient.name, provider: visit.provider_name,
        wall_time: visit.wall_time, local_time: visit.starts_at&.in_time_zone(@clinic.zone)&.strftime("%-I:%M %p %Z"),
        duration: visit.length_minutes, pms_status: visit.status, outcome: outcome, decision: decision || "unconfirmed",
        review: @reviews.include?(visit.id), upcoming: !!visit.upcoming?(DemoClock.now)
      }
    end
  end
end
