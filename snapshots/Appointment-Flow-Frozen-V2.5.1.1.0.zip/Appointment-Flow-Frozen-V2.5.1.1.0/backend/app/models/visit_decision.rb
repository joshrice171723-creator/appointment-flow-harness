class VisitDecision < ApplicationRecord
  def self.for_visit(visit)
    where(clinic_id: visit.clinic_id, appointment_id: visit.id, revision: visit.revision)
  end

  def self.record!(visit, state)
    for_visit(visit).first_or_initialize.update!(state: state)
  end
end
