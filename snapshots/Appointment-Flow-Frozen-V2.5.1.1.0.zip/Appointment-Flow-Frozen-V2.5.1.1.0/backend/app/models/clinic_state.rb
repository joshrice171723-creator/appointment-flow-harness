class ClinicState < ApplicationRecord
  class SourceUnavailable < StandardError; end

  # Touch the locked row on every committed workflow. A concurrent transaction
  # with an older snapshot must retry before trusting opt-outs or other state.
  def self.with_replica(clinic_id)
    attempts = 0
    begin
      transaction(isolation: :repeatable_read) do
        state = lock.find(clinic_id)
        clinic = read_replica(clinic_id)
        result = yield clinic, state
        state.write_generation += 1
        state.save!
        result
      end
    rescue ActiveRecord::SerializationFailure
      attempts += 1
      retry if attempts < 3
      raise
    end
  end

  def self.read_replica(clinic_id)
    clinic = Pms::Clinic.find_by(id: clinic_id)
    unless clinic&.appointments&.joins(:patient)&.exists?
      raise SourceUnavailable, "The PMS replica is empty or unavailable for this clinic."
    end
    clinic
  rescue ActiveRecord::StatementInvalid => error
    raise unless error.cause.is_a?(PG::UndefinedTable) || error.cause.is_a?(PG::QueryCanceled)

    raise SourceUnavailable, "The PMS replica could not be read."
  end
end
