class ContactVerification < ApplicationRecord
end
