class ContactProfile
  FIELDS = %w[ birthdate wireless_phone email preferred_language ].freeze
  MATCH_PHONES = "right(regexp_replace(wireless_phone, '[^0-9]', '', 'g'), 10) IN (?)"
  MATCH_EMAILS = "lower(btrim(email)) IN (?)"

  def self.phone(raw)
    value = raw.to_s.strip
    return unless value.match?(/\A(?:\+?1[ .-]?)?[0-9(). -]+\z/)

    digits = value.gsub(/\D/, "")
    digits = digits[1..] if digits.length == 11 && digits.start_with?("1")
    digits if digits.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
  end

  def self.email(raw)
    value = raw.to_s.gsub(/\A +| +\z/, "").downcase
    value if value.match?(/\A[a-z0-9.!%+'_-]+@[a-z0-9-]+(?:\.[a-z0-9-]+)+\z/)
  end

  def self.owners(channel, recipients)
    return {} if recipients.empty?

    # Indexed source expressions return raw values so malformed source entries
    # do not accidentally count as valid recipients.
    if channel == "sms"
      raw = Pms::Patient.where(MATCH_PHONES, recipients).pluck(:wireless_phone, :id)
      local = :phone
    else
      raw = Pms::Patient.where(MATCH_EMAILS, recipients).pluck(:email, :id)
      local = :email
    end
    normalized = raw.filter_map do |value, id|
      recipient = channel == "sms" ? phone(value) : email(value)
      [ recipient, id ] if recipient
    end
    corrections = ContactVerification.where(local => recipients).pluck(local, :patient_id)
    (normalized + corrections).group_by(&:first).transform_values { |pairs| pairs.map(&:last).uniq }
  end

  def initialize(patient, verification)
    @patient = patient
    @fields = verification&.fields || {}
  end

  def value(field)
    @fields.fetch(field, {}).fetch("value") { source_value(field) }
  end

  def source_value(field)
    @patient.public_send(field).presence&.to_s
  end

  def status(field)
    return "unverified" unless @fields.key?(field)
    return "conflict" unless @fields[field]["source"] == source_value(field)

    "verified"
  end

  def phone
    self.class.phone(value("wireless_phone"))
  end

  def email
    self.class.email(value("email"))
  end

  def language
    case value("preferred_language").to_s.strip.downcase
    when "en", "english" then "en"
    when "es", "spanish", "español" then "es"
    end
  end

  def hold_on(date)
    return "Verified details conflict with the PMS." if FIELDS.any? { |field| status(field) == "conflict" }

    birthdate = CalendarDate.parse(value("birthdate"))
    return "Verify the patient's birthdate." if birthdate.nil? || birthdate > date
    return "Verify guardian authorization before outreach." if birthdate > (date << (18 * 12))
    return "Verify the patient's preferred language." unless language
    return "Verify an SMS number or email address." unless phone || email

    nil
  end

  def as_json(*)
    FIELDS.to_h do |field|
      [ field, { value: value(field), source: source_value(field), status: status(field) } ]
    end
  end
end
