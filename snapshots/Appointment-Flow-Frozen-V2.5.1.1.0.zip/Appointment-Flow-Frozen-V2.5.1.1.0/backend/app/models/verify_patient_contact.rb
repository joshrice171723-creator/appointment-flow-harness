class VerifyPatientContact
  def self.record(clinic_id:, patient_id:, staff:, values:, note:, request_id:)
    note = note.to_s.strip
    raise InvalidWorkflow, "Enter a verification note of 1 to 1,000 characters." unless note.length.between?(1, 1000)
    unless request_id.to_s.match?(/\A[0-9a-zA-Z_-]{1,100}\z/)
      raise InvalidWorkflow, "A valid request identifier is required."
    end
    values = values.stringify_keys.slice(*ContactProfile::FIELDS).transform_values { |value| value.to_s.strip.presence }
    raise InvalidWorkflow, "Select at least one detail to verify." if values.empty?

    ClinicState.with_replica(clinic_id) do |clinic, _state|
      raise InvalidWorkflow, "Select a staff member for this clinic." unless clinic.staff.include?(staff)
      patient = clinic.patients.find(patient_id)
      previous = WorkEvent.find_by(clinic_id: clinic.id, request_id: request_id)
      if previous
        unless previous.patient_id == patient.id && previous.action == "contact_verified" && previous.staff == staff &&
            previous.note == note && previous.details.fetch("values", {}) == values
          raise InvalidWorkflow, "This request identifier was already used."
        end
        next previous
      end

      ContactDirectory.lock_for_change!
      verification = ContactVerification.find_or_initialize_by(clinic_id: clinic.id, patient_id: patient.id)
      profile = ContactProfile.new(patient, verification)
      fields = values.to_h do |field, value|
        validate!(field, value, DemoClock.now.in_time_zone(clinic.zone).to_date)
        [ field, { "value" => value, "source" => profile.source_value(field) } ]
      end
      verification.fields = verification.fields.merge(fields)
      updated = ContactProfile.new(patient, verification)
      verification.phone = updated.phone if verification.fields.key?("wireless_phone")
      verification.email = updated.email if verification.fields.key?("email")
      verification.save!
      WorkEvent.create!(clinic_id: clinic.id, patient_id: patient.id, staff: staff, action: "contact_verified",
        note: note, request_id: request_id, details: {
          values: values, previous_values: values.keys.to_h { |field| [ field, profile.value(field) ] },
          source_values: values.keys.to_h { |field| [ field, profile.source_value(field) ] }
        })
    end
  end

  def self.validate!(field, value, today)
    return if value.nil?

    valid = case field
    when "birthdate"
      date = CalendarDate.parse(value)
      date && date <= today
    when "wireless_phone" then ContactProfile.phone(value)
    when "email" then ContactProfile.email(value)
    when "preferred_language" then %w[ en es english spanish español ].include?(value.downcase)
    end
    raise InvalidWorkflow, "Check the format of #{field.tr('_', ' ')}." unless valid
  end
  private_class_method :validate!
end
