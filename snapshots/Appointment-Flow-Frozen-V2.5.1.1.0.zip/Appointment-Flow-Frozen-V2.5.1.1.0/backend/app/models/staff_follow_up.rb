class StaffFollowUp
  ACTIONS = %w[ attempted confirmed rescheduled canceled clarified ].freeze

  def initialize(clinic_id:, staff:)
    @clinic_id = clinic_id
    @staff = staff
  end

  def assign(item_id)
    ClinicState.with_replica(@clinic_id) do |clinic, _state|
      validate_staff!(clinic)
      item = WorkItem.open.find_by!(id: item_id, clinic_id: clinic.id)
      current_visit!(clinic, item) unless item.kind == "reply_review"
      item.update!(assignee: @staff)
      item
    end
  end

  def record(item_id:, action:, note:, request_id:, candidates: [])
    note = note.to_s.strip
    raise InvalidWorkflow, "Enter a follow-up note of 1 to 1,000 characters." unless note.length.between?(1, 1000)
    raise InvalidWorkflow, "Choose a follow-up outcome." unless ACTIONS.include?(action)
    unless request_id.to_s.match?(/\A[0-9a-zA-Z_-]{1,100}\z/)
      raise InvalidWorkflow, "A valid request identifier is required."
    end
    candidate_ids = Array(candidates).map(&:to_s).uniq.sort
    raise InvalidWorkflow, "Select candidates only when clarifying a reply." if action != "clarified" && candidate_ids.any?

    ClinicState.with_replica(@clinic_id) do |clinic, _state|
      validate_staff!(clinic)
      previous = WorkEvent.find_by(clinic_id: clinic.id, request_id: request_id)
      if previous
        unless previous.work_item_id.to_s == item_id.to_s && previous.action == action && previous.note == note &&
            previous.staff == @staff && previous.details.fetch("candidates", []) == candidate_ids
          raise InvalidWorkflow, "This request identifier was already used. Refresh the follow-up before saving."
        end
        next previous
      end

      item = WorkItem.open.find_by!(id: item_id, clinic_id: clinic.id)
      raise InvalidWorkflow, "Assign this item to yourself before recording follow-up." unless item.assignee == @staff

      if action == "clarified"
        clarify!(clinic, item, candidate_ids)
      elsif action != "attempted"
        raise InvalidWorkflow, "Use Clarified to resolve a reply review." if item.kind == "reply_review"
        decide!(current_visit!(clinic, item), action)
      end
      item.update!(assignee: @staff, resolved_at: action == "attempted" ? nil : DemoClock.now)
      WorkEvent.create!(clinic_id: clinic.id, patient_id: item.patient_id, work_item: item, staff: @staff,
        action: action, note: note, request_id: request_id, details: { candidates: candidate_ids })
    end
  end

  private

  def validate_staff!(clinic)
    raise InvalidWorkflow, "Select a staff member for this clinic." unless clinic.staff.include?(@staff)
  end

  def current_visit!(clinic, item)
    visit = clinic.appointments.find(item.appointment_id)
    visit.clinic = clinic
    unless visit.revision == item.revision
      raise InvalidWorkflow, "The PMS changed this appointment. Refresh before recording an outcome."
    end
    visit
  end

  def clarify!(clinic, item, candidate_ids)
    unless item.kind == "reply_review" && item.message
      raise InvalidWorkflow, "Only a reply review can be clarified."
    end

    references = item.message.candidates.index_by { |candidate| candidate.fetch("id").to_s }
    unless candidate_ids.all? { |id| references.key?(id) }
      raise InvalidWorkflow, "Choose appointments from the reply's candidate list."
    end

    clinic.appointments.find(candidate_ids).each do |visit|
      visit.clinic = clinic
      unless visit.revision == references.fetch(visit.id.to_s).fetch("revision")
        raise InvalidWorkflow, "A candidate appointment changed in the PMS. Refresh the review."
      end
      decide!(visit, "confirmed")
    end
  end

  def decide!(visit, action)
    now = DemoClock.now
    unless visit.upcoming?(now) &&
        !%w[ canceled rescheduled ].include?(VisitDecision.for_visit(visit).pick(:state))
      raise InvalidWorkflow, "This visit is no longer eligible for a local outcome."
    end

    VisitDecision.record!(visit, action)
    WorkItem.for_visit(visit).open.where.not(kind: "reply_review").update_all(resolved_at: now, updated_at: now)
  end
end
