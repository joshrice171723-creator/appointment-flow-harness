require "test_helper"
require Rails.root.join("../quality/rails_workload_probe")

class WorkloadTest < ActionDispatch::IntegrationTest
  include ReplicaFixtures

  test "the appointment page and reminder batch stay scoped as unrelated source and attempt history grows" do
    appointment_page
    batch
    reset_current_work
    baseline_read, baseline_batch, baseline_writes = measure_workload("baseline")
    baseline_repeat = measure_repeat("baseline repeat")

    add_unrelated_history
    reset_current_work
    history_read, history_batch, history_writes = measure_workload("with 600 old visits and 600 old attempts")
    assert_equal baseline_read.except(:elapsed_ms), history_read.except(:elapsed_ms)
    assert_equal baseline_batch.except(:elapsed_ms), history_batch.except(:elapsed_ms)
    assert_equal baseline_writes, history_writes

    reset_current_work
    add_relevant_visits
    _, larger_batch, larger_writes = measure_workload("with 18 more visits within 48 hours")
    assert_equal baseline_writes + 12, larger_writes
    assert_equal 18, WorkItem.where(kind: "no_reply").where(appointment_id: 40_001..40_018).count
    assert_equal 6, WorkItem.where(kind: "contact_hold").where(appointment_id: 40_001..40_018).count
    assert_operator larger_batch.fetch(:instantiated_records), :>, baseline_batch.fetch(:instantiated_records)
    larger_repeat = measure_repeat("larger repeat")
    assert_equal baseline_repeat.fetch(:database_statements), larger_repeat.fetch(:database_statements)
    assert_equal baseline_repeat.fetch(:direct_write_statements), larger_repeat.fetch(:direct_write_statements)
  end

  private

  def appointment_page
    get "/api/clinics/1/appointments", params: { date: "2026-11-23" }, headers: { "X-Demo-Staff" => "Morgan" }
    assert_response :success
    assert_equal [ 101, 102 ], response.parsed_body.fetch("appointments").map { |row| row.fetch("id") }
  end

  def measure_workload(label)
    _, read = RailsWorkloadProbe.measure { appointment_page }
    result, writes = RailsWorkloadProbe.measure { batch }
    if ENV["SHOW_WORKLOAD"]
      puts "\n#{label}\n  appointment HTTP GET #{read}\n  reminder batch #{writes} #{result}"
    end
    [ read, writes, result.values.sum ]
  end

  def reset_current_work
    WorkItem.delete_all
    Message.where("step <> ?", "legacy").delete_all
  end

  def measure_repeat(label)
    result, metrics = RailsWorkloadProbe.measure { batch }
    assert_equal({ sent: 0, failed: 0 }, result)
    puts "\n#{label}\n  reminder batch #{metrics} #{result}" if ENV["SHOW_WORKLOAD"]
    metrics
  end

  def add_unrelated_history
    connection.execute(<<~SQL)
      INSERT INTO pms.appointments (id, clinic_id, patient_id, start_at, status)
      SELECT 30000 + n, 1, 101, timestamp '2023-01-01 12:30' + n * interval '1 day', 'complete'
      FROM generate_series(1, 600) AS n;
      INSERT INTO messages (clinic_id, patient_id, appointment_id, revision, channel, direction, recipient, step, status, body, created_at, updated_at)
      SELECT 1, 101, 101, 'old-' || n, 'sms', 'outbound', '5125550111', 'legacy', 'sent', 'Old demo attempt', now(), now()
      FROM generate_series(1, 600) AS n;
    SQL
  end

  def add_relevant_visits
    connection.execute(<<~SQL)
      INSERT INTO pms.appointments (id, clinic_id, patient_id, start_at, status)
      SELECT 40000 + n, 1, CASE WHEN n <= 12 THEN 101 ELSE 104 END,
        timestamp '2026-11-17 12:30' + n * interval '7 minutes', 'scheduled'
      FROM generate_series(1, 18) AS n;
    SQL
  end
end
