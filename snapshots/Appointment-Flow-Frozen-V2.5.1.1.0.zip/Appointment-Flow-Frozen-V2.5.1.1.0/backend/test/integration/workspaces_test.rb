require "test_helper"

class WorkspacesTest < ActionDispatch::IntegrationTest
  include ReplicaFixtures

  STAFF = { "X-Demo-Staff" => "Morgan" }.freeze
  AUSTIN = "/api/clinics/1"
  PHOENIX = "/api/clinics/2"

  test "staff reads and writes stay scoped to the selected clinic" do
    batch
    item = WorkItem.find_by!(clinic_id: 1, kind: "contact_hold")
    get "#{PHOENIX}/patients/#{item.patient_id}", headers: { "X-Demo-Staff" => "Jordan" }
    assert_response :not_found
    post "#{PHOENIX}/work_items/#{item.id}/assignment", headers: { "X-Demo-Staff" => "Jordan" }
    assert_response :not_found
    get "#{PHOENIX}/dashboard", headers: STAFF
    assert_response :unprocessable_entity
    get "#{PHOENIX}/patients"
    assert_response :success
    assert_not_includes response.body, "Robin"
    assert_nil item.reload.assignee
  end

  test "board search and calendar dates return only matching records" do
    batch
    get "#{AUSTIN}/dashboard", params: { search: "Robin Reed", kind: "contact_hold" }, headers: STAFF
    assert_response :success
    assert_equal [ "Robin Reed" ], response.parsed_body.fetch("items").map { |item| item.fetch("patient") }
    get "#{AUSTIN}/appointments", params: { date: "2026-11-23" }, headers: STAFF
    assert_response :success
    assert_equal [ 101, 102 ], response.parsed_body.fetch("appointments").map { |visit| visit.fetch("id") }
    assert_equal 2, response.parsed_body.fetch("week").fetch("2026-11-23")
  end

  test "a work item selected from the board remains visible beyond the recent history cutoff" do
    batch
    item = WorkItem.find_by!(appointment_id: 104, kind: "contact_hold")
    51.times do |index|
      WorkItem.create!(clinic_id: 1, patient_id: 104, appointment_id: 104, revision: item.revision,
        kind: "contact_hold", event_key: "prior-#{index}", reason: "Fictional history", resolved_at: NOW)
    end
    get "#{AUSTIN}/patients/104", params: { item: item.id }, headers: STAFF
    assert_response :success
    assert_equal item.id, response.parsed_body.fetch("items").first.fetch("id")
    get "#{AUSTIN}/patients/105", params: { item: item.id }, headers: STAFF
    assert_response :success
    assert_not_includes response.parsed_body.fetch("items").pluck("id"), item.id
  end

  test "a patient-name search is filtered from request logging" do
    get "#{AUSTIN}/dashboard", params: { search: "Robin Reed" }, headers: STAFF
    assert_response :success
    assert_equal "[FILTERED]", request.filtered_parameters.fetch("search")
    assert_not_includes request.filtered_path, "Robin"
  end

  test "assigning and recording follow-up through HTTP keeps attempts open and deduplicates confirmation" do
    batch
    item = WorkItem.find_by!(appointment_id: 105, kind: "no_reply")
    path = "#{AUSTIN}/work_items/#{item.id}"
    post "#{path}/assignment", headers: STAFF
    assert_response :success

    post "#{path}/follow_ups", params: { action_name: "attempted", note: "", request_id: "bad" }, headers: STAFF, as: :json
    assert_response :unprocessable_entity
    assert_empty item.work_events

    post "#{path}/follow_ups", params: { action_name: "attempted", note: "Left a message.", request_id: "call" }, headers: STAFF, as: :json
    assert_response :created
    assert_nil item.reload.resolved_at

    confirmation = { action_name: "confirmed", note: "Confirmed by phone.", request_id: "confirmed" }
    2.times do
      post "#{path}/follow_ups", params: confirmation, headers: STAFF, as: :json
      assert_response :created
    end
    assert_equal 2, item.work_events.count
    assert item.reload.resolved_at
    assert_equal "confirmed", VisitDecision.for_visit(Pms::Appointment.find(105)).pick(:state)
  end

  test "patient Email inbox and replies feed the current staff appointments view" do
    batch
    get "#{AUSTIN}/patients/102/inbox", params: { channel: "email" }
    assert_response :success
    message = response.parsed_body.fetch("messages").fetch(0)
    assert_includes message.fetch("body"), "Reply YES"
    post "#{AUSTIN}/patients/102/replies", params: {
      channel: "email", body: "yes", external_id: "demo-email", message_id: message.fetch("id")
    }, as: :json
    assert_response :created
    assert_equal "confirmed", response.parsed_body.fetch("status")
    get "#{AUSTIN}/appointments", params: { date: "2026-11-23" }, headers: STAFF
    visit = response.parsed_body.fetch("appointments").find { |row| row.fetch("id") == 102 }
    assert_equal "confirmed", visit.fetch("decision")
    assert_equal "unknown", visit.fetch("outcome")
  end

  test "clarifying several candidate visits rolls back earlier writes if a later candidate changed" do
    batch
    change_patient(105, wireless_phone: "5125550111")
    incoming = reply("YES")
    item = WorkItem.find_by!(message: incoming)
    path = "#{AUSTIN}/work_items/#{item.id}"
    post "#{path}/assignment", headers: STAFF
    assert_response :success
    change_visit(105, start_at: "2026-11-18 13:00:00")
    post "#{path}/follow_ups", params: { action_name: "clarified", candidates: [ 101, 105 ],
      note: "Checked both visits.", request_id: "review" }, headers: STAFF, as: :json
    assert_response :unprocessable_entity
    assert_empty VisitDecision.all
    assert_empty item.work_events
    assert_nil item.reload.resolved_at

    post "#{path}/follow_ups", params: { action_name: "clarified", candidates: [ 101 ],
      note: "Confirmed this visit after clarification.", request_id: "review-101" }, headers: STAFF, as: :json
    assert_response :created
    assert_equal "confirmed", VisitDecision.for_visit(Pms::Appointment.find(101)).pick(:state)
  end

  test "leadership returns only aggregate outcomes and separates appointment confirmation from completion" do
    batch
    reply("YES")
    item = WorkItem.find_by!(appointment_id: 105, kind: "no_reply")
    follow_up = StaffFollowUp.new(clinic_id: 1, staff: "Morgan")
    follow_up.assign(item.id)
    follow_up.record(item_id: item.id, action: "canceled", note: "Fictional appointment canceled.", request_id: "cancel")
    get "/api/leadership_report", params: { month: "2026-11" }
    assert_response :success
    report = response.parsed_body
    assert_equal %w[ activity clinics history ], report.keys.sort
    austin = report.fetch("clinics").find { |row| row.fetch("clinic") == "Austin" }
    assert_equal 2, austin.fetch("completed")
    assert_equal 1, austin.fetch("canceled")
    assert_equal 10, austin.fetch("recorded")
    %w[ Avery 5125550111 example.test patient_id appointment_id birthdate body recipient note ].each do |term|
      assert_not_includes response.body, term
    end
  end
end
