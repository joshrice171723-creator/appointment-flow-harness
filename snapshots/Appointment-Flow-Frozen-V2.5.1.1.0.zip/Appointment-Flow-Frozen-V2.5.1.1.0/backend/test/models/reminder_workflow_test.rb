require "test_helper"
require "open3"
require "timeout"

class ReminderWorkflowTest < ActiveSupport::TestCase
  include ReplicaFixtures

  test "a safe SMS YES confirms just the current revision and the final reminder is informational" do
    batch
    reply = reply(" YES ", id: "event-1")
    assert_equal "confirmed", reply.status
    assert_equal reply.id, reply(" YES ", id: "event-1").id
    assert_equal 1, Message.inbound.where(patient_id: 101).count
    batch(NOW + 4.days)
    assert_equal [ "initial" ], Message.outbound.where(patient_id: 101).pluck(:step)
    batch(NOW + 6.days)
    final = Message.outbound.find_by!(patient_id: 101, step: "final")
    assert_not_includes final.body, "Reply YES"
    assert_includes final.body, "STOP"
    assert_equal "confirmed", VisitDecision.for_visit(Pms::Appointment.find(101)).pick(:state)
  end

  test "email-only contact can confirm from a specific sent email" do
    batch
    message = Message.sent.find_by!(patient_id: 102, channel: "email")
    assert_equal "confirmed", reply("yes", patient: 102, channel: "email", message_id: message.id).status
    assert_raises(ActiveRecord::RecordNotFound) { reply("yes", channel: "email", message_id: message.id) }
  end

  test "same-row reschedule retires an old confirmation, and an unthreaded stale YES still needs review" do
    batch
    reply("YES")
    previous = Pms::Appointment.find(101).revision
    change_visit(101, start_at: "2026-11-23 16:30:00", updated_at: "2026-11-16 13:00:00")
    batch(NOW + 1.minute)

    current = Pms::Appointment.find(101)
    assert_not_equal previous, current.revision
    assert_nil VisitDecision.for_visit(current).pick(:state)
    assert_equal 2, Message.sent.where(appointment_id: 101).count
    assert_equal "review", reply("YES", now: NOW + 2.minutes).status
    assert_nil VisitDecision.for_visit(current).pick(:state)
  end

  test "breaking and recreating a visit stops the old lifecycle and routes old unthreaded replies to review" do
    batch
    change_visit(101, status: "broken")
    connection.execute(<<~SQL)
      INSERT INTO pms.appointments (id, clinic_id, patient_id, start_at, status)
      VALUES (301, 1, 101, '2026-11-23 16:30:00', 'scheduled')
    SQL
    batch
    assert_equal 1, Message.outbound.where(appointment_id: 101).count
    assert_equal 1, Message.sent.where(appointment_id: 301).count
    assert_equal "review", reply("YES").status
    assert_empty VisitDecision.all
  end

  test "a replacement visit at a new number never receives a YES or STOP sent from the old number" do
    batch
    old = Message.sent.find_by!(patient_id: 101, channel: "sms")
    change_visit(101, status: "broken")
    change_patient(101, wireless_phone: "512-555-0181")
    connection.execute(<<~SQL)
      INSERT INTO pms.appointments (id, clinic_id, patient_id, start_at, status)
      VALUES (301, 1, 101, '2026-11-23 16:30:00', 'scheduled')
    SQL
    batch
    new_message = Message.sent.find_by!(appointment_id: 301, channel: "sms")
    assert_raises(InvalidWorkflow) { reply("YES") }
    assert_equal "review", reply("YES", message_id: old.id).status
    assert_empty VisitDecision.all
    assert_equal "opted_out", reply("STOP", message_id: old.id).status
    assert SmsOptOut.exists?(clinic_id: 1, recipient: old.recipient)
    assert_not SmsOptOut.exists?(clinic_id: 1, recipient: new_message.recipient)
    assert_equal "confirmed", reply("YES", message_id: new_message.id).status
    assert_equal 301, VisitDecision.sole.appointment_id
  end

  test "a failed SMS is retained and only one backup email is attempted" do
    change_visit(103, start_at: "2026-11-23 14:30:00")
    batch
    2.times { batch(NOW + 1.day) }
    attempts = Message.outbound.where(patient_id: 103).order(:id)
    assert_equal [ [ "sms", "failed", "initial" ], [ "email", "sent", "backup" ] ],
      attempts.pluck(:channel, :status, :step)
    assert_equal "delivery_failed", WorkItem.find_by!(message: attempts.first).kind
    assert_includes attempts.second.body, "Responda SÍ"
  end

  test "a caught-up initial text and its backup cannot be sent on the same clinic-local day" do
    change_visit(101, start_at: "2026-11-22 12:30:00")
    batch
    batch(NOW + 10.minutes)
    assert_equal [ "initial" ], Message.outbound.where(patient_id: 101).pluck(:step)
    batch(NOW + 1.day)
    assert_equal [ "backup", "initial" ], Message.outbound.where(patient_id: 101).order(:step).pluck(:step)
  end

  test "a later NO and a late YES are reviewed and do not rewrite confirmation" do
    batch
    reply("YES")
    assert_equal "review", reply("NO", now: NOW + 1.minute).status
    starts = Pms::Appointment.find(102).starts_at
    assert_equal "review", reply("YES", patient: 102, channel: "email", now: starts).status
    assert_equal 1, VisitDecision.count
    assert_equal 2, WorkItem.where(kind: "reply_review").count
  end

  test "only exact STOP suppresses SMS and a future replica refresh preserves it" do
    batch
    assert_equal "review", reply("STOP please").status
    assert_equal "opted_out", reply("sToP").status
    batch(NOW + 4.days)
    assert_equal 1, Message.outbound.where(patient_id: 101, channel: "sms").count
    assert Message.sent.exists?(patient_id: 101, channel: "email", step: "follow_up")
    assert SmsOptOut.exists?(clinic_id: 1, recipient: "5125550111")
  end

  test "a shared phone suppresses SMS and a bare YES has clinic-scoped review candidates" do
    batch
    change_patient(105, wireless_phone: "+1 (512) 555-0111")
    change_patient(201, wireless_phone: "512.555.0111")
    reply = reply("YES")
    assert_equal "review", reply.status
    assert_equal [ 101, 105 ], reply.candidates.map { |entry| entry.fetch("id") }.sort
    assert_empty VisitDecision.all
    batch(NOW + 4.days)
    assert_not Message.outbound.exists?(patient_id: 101, channel: "sms", step: "follow_up")
    assert_equal 1, Message.outbound.where(patient_id: 105, channel: "sms").count
  end

  test "missing age and unsupported language block sends and a local correction can unblock an adult" do
    change_patient(106, preferred_language: "unknown")
    batch
    assert_not Message.outbound.exists?(patient_id: [ 104, 106 ])
    assert_equal [ 104, 106 ], WorkItem.where(kind: "contact_hold", patient_id: [ 104, 106 ]).order(:patient_id).pluck(:patient_id)
    VerifyPatientContact.record(clinic_id: 1, patient_id: 104, staff: "Morgan", values: { birthdate: "1986-10-10" },
      note: "Verified age by phone.", request_id: "birthdate")
    batch
    assert Message.sent.exists?(patient_id: 104)
    assert_nil Pms::Patient.find(104).birthdate
    assert WorkItem.find_by!(kind: "contact_hold", patient_id: 104).resolved_at
  end

  test "unverified minor and later PMS changes to a verified detail hold all outreach" do
    change_patient(101, birthdate: "2016-01-01", guarantor_id: 105)
    VerifyPatientContact.record(clinic_id: 1, patient_id: 102, staff: "Morgan",
      values: { email: "new-jules@example.test" }, note: "Verified address.", request_id: "email")
    change_patient(102, email: "changed@example.test")
    batch
    assert_not Message.outbound.exists?(patient_id: [ 101, 102 ])
    assert_equal "Verified details conflict with the PMS.", WorkItem.find_by!(patient_id: 102, kind: "contact_hold").reason
    assert_equal "jules@example.test", WorkEvent.find_by!(request_id: "email").details.fetch("previous_values").fetch("email")
  end

  test "an empty source preserves previous work and exposes a failed refresh" do
    batch
    previous = ClinicState.find(1).last_synced_at
    item_ids = WorkItem.where(clinic_id: 1).ids
    connection.execute("DELETE FROM pms.appointments WHERE clinic_id = 1")

    assert_no_difference "Message.count" do
      assert_raises(ClinicState::SourceUnavailable) { batch(NOW + 1.day) }
    end
    assert_equal item_ids.sort, WorkItem.where(clinic_id: 1).ids.sort
    assert_equal previous, ClinicState.find(1).last_synced_at
    assert ClinicState.find(1).source_failed_at
  end

  test "the command keeps scanning healthy clinics after a source failure" do
    connection.execute("DELETE FROM pms.appointments WHERE clinic_id = 1")
    output, errors, status = Open3.capture3({ "DEMO_NOW" => NOW.iso8601 }, RbConfig.ruby, "bin/rails", "reminders:run",
      chdir: Rails.root)
    assert_not status.success?
    assert_includes errors, "Reminder scan incomplete for clinics 1"
    assert_includes output, "Clinic 2: 4 sent"
    assert_empty Message.where(clinic_id: 1)
    assert_equal 4, Message.sent.where(clinic_id: 2).count
  end

  test "a healthy source scan retires open work for deleted and transferred visits" do
    batch
    missing = WorkItem.find_by!(appointment_id: 104, kind: "contact_hold")
    transferred = WorkItem.find_by!(appointment_id: 105, kind: "no_reply")
    connection.execute("DELETE FROM pms.appointments WHERE id = 104")
    change_visit(105, clinic_id: 2)
    batch
    assert missing.reload.resolved_at
    assert transferred.reload.resolved_at
  end

  test "an unexpected error after the first delivery rolls back attempts, work and sync together" do
    delivery = Class.new(FakeDelivery) do
      def deliver(**)
        @count = (@count || 0) + 1
        raise IOError, "Simulated adapter crash" if @count == 2
        super
      end
    end.new
    error = assert_raises(IOError) { batch(delivery: delivery) }
    assert_equal "Simulated adapter crash", error.message
    assert_empty Message.all
    assert_empty WorkItem.all
    assert_nil ClinicState.find(1).last_synced_at
    assert_operator batch.fetch(:sent), :>, 0
  end

  test "parallel and repeated batches persist one attempt per logical step" do
    ApplicationRecord.connection_pool.release_connection
    start = Queue.new
    workers = 2.times.map do
      Thread.new do
        start.pop
        ApplicationRecord.connection_pool.with_connection { batch }
      end
    end
    workers.size.times { start.push(true) }
    counts = workers.map(&:value)
    assert_equal Message.outbound.where(clinic_id: 1).count, counts.sum { |count| count.values.sum }
    assert_equal 1, Message.sent.where(patient_id: 101, step: "initial").count
    assert_equal({ sent: 0, failed: 0 }, batch)
  end

  test "a batch with an older snapshot refreshes ownership after another clinic corrects a number" do
    staged = Queue.new
    proceed = Queue.new
    acquiring_guard = Queue.new
    read_guard = Queue.new
    writer = Thread.new do
      ApplicationRecord.connection_pool.with_connection do
        pause = lambda do |event|
          next unless event.payload.fetch(:sql).start_with?('INSERT INTO "contact_verifications"')

          staged.push(true)
          proceed.pop
        end
        ActiveSupport::Notifications.subscribed(pause, "sql.active_record") do
          VerifyPatientContact.record(clinic_id: 2, patient_id: 201, staff: "Jordan",
            values: { wireless_phone: "5125550111" }, note: "Updated fictional contact.", request_id: "phone")
        end
      end
    end
    reader = nil
    begin
      Timeout.timeout(8) { staged.pop }
      reader = Thread.new do
        reader_thread = Thread.current
        observer = Object.new
        observed = false
        observer.define_singleton_method(:start) do |_name, _id, payload|
          next if Thread.current != reader_thread || observed || !payload[:sql].to_s.include?('FROM "contact_directories"')
          next unless payload[:sql].end_with?("FOR SHARE")

          observed = true
          acquiring_guard.push(true)
          read_guard.pop
        end
        observer.define_singleton_method(:finish) { |*| }
        ActiveSupport::Notifications.subscribed(observer, "sql.active_record") do
          ApplicationRecord.connection_pool.with_connection { batch }
        end
      end
      Timeout.timeout(8) { acquiring_guard.pop }
    ensure
      proceed.push(true)
      begin
        writer.value
      ensure
        read_guard.push(true)
        reader&.value
      end
    end
    assert_not Message.outbound.exists?(patient_id: 101, channel: "sms")
    assert Message.sent.exists?(patient_id: 101, channel: "email")
  end

  test "the local sending window and DST conversion are based on the clinic" do
    instant = Time.utc(2026, 7, 9, 15)
    DemoData.load!(now: instant)
    assert_operator batch(instant, clinic: 1).fetch(:sent), :>, 0
    assert_equal 0, batch(instant, clinic: 2).fetch(:sent)
    assert_operator batch(instant + 2.hours, clinic: 2).fetch(:sent), :>, 0

    change_visit(101, start_at: "2026-11-01 01:30:00")
    assert_nil Pms::Appointment.find(101).starts_at
    change_visit(101, start_at: "2026-03-08 02:30:00")
    assert_nil Pms::Appointment.find(101).starts_at
    change_visit(201, start_at: "2026-03-08 02:30:00")
    assert_equal Time.utc(2026, 3, 8, 9, 30), Pms::Appointment.find(201).starts_at
  end

  test "a run on the visit date does not send at the exact appointment start" do
    change_visit(101, start_at: "2026-11-16 12:00:00")
    batch
    assert_not Message.outbound.exists?(appointment_id: 101)
  end

  test "replica records reject Active Record writes" do
    assert_raises(ActiveRecord::ReadOnlyRecord) { Pms::Patient.find(101).update!(birthdate: Date.new(2000, 1, 1)) }
  end
end
