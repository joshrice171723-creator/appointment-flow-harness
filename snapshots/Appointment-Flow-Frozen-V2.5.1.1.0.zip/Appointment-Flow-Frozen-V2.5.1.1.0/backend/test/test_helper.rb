ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"
require Rails.root.join("db/demo_data")

module ReplicaFixtures
  NOW = Time.utc(2026, 11, 16, 18)

  def setup
    super
    if ENV["DEMO_NOW"].present?
      raise "Unset DEMO_NOW before running tests."
    end
    travel_to NOW
    connection.execute(<<~SQL)
      TRUNCATE work_events, work_items, messages, visit_decisions, sms_opt_outs, contact_verifications, contact_directories, clinic_states,
        pms.appointments, pms.patients, pms.clinics RESTART IDENTITY
    SQL
    DemoData.load!(now: NOW)
  end

  def connection
    ApplicationRecord.lease_connection
  end

  def batch(now = NOW, clinic: 1, **options)
    ReminderBatch.new(now: now, **options).run(clinic)
  end

  def reply(body, patient: 101, channel: "sms", id: SecureRandom.uuid, now: NOW, **options)
    PatientReply.new(clinic_id: 1, patient_id: patient, channel: channel, external_id: id,
      body: body, now: now, **options).record
  end

  def change_visit(id, **fields)
    update_replica("appointments", id, fields)
  end

  def change_patient(id, **fields)
    update_replica("patients", id, fields)
  end

  private

  def update_replica(table, id, fields)
    updates = fields.map { |field, value| "#{connection.quote_column_name(field)} = #{connection.quote(value)}" }
    connection.execute("UPDATE pms.#{table} SET #{updates.join(', ')} WHERE id = #{Integer(id)}")
  end
end

class ActiveSupport::TestCase
  self.use_transactional_tests = false
end
