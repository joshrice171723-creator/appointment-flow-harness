require Rails.root.join("db/demo_data")

DemoData.load!(now: DemoClock.now)
