SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pms; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pms;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.appointments (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    provider_name text,
    start_at timestamp without time zone NOT NULL,
    length_minutes integer,
    procedure_note text,
    status text NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: clinics; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.clinics (
    id bigint NOT NULL,
    name text NOT NULL,
    address_line text,
    city text,
    state character(2),
    phone text
);


--
-- Name: patients; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.patients (
    id bigint NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    birthdate date,
    wireless_phone text,
    email text,
    preferred_language text,
    guarantor_id bigint
);


--
-- Name: versioned_appointments; Type: VIEW; Schema: pms; Owner: -
--

CREATE VIEW pms.versioned_appointments AS
 SELECT id,
    patient_id,
    clinic_id,
    provider_name,
    start_at,
    length_minutes,
    procedure_note,
    status,
    updated_at,
    encode(sha256(convert_to(concat_ws('|'::text, id, clinic_id, patient_id, to_char(start_at, 'YYYY-MM-DD"T"HH24:MI:SS.US'::text), status, COALESCE(to_char(updated_at, 'YYYY-MM-DD"T"HH24:MI:SS.US'::text), ''::text)), 'UTF8'::name)), 'hex'::text) AS revision
   FROM pms.appointments;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: clinic_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinic_states (
    id bigint NOT NULL,
    last_synced_at timestamp(6) without time zone,
    write_generation bigint DEFAULT 0 NOT NULL,
    source_failed_at timestamp(6) without time zone
);


--
-- Name: clinic_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clinic_states_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinic_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clinic_states_id_seq OWNED BY public.clinic_states.id;


--
-- Name: contact_directories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_directories (
    id bigint NOT NULL,
    generation bigint DEFAULT 0 NOT NULL
);


--
-- Name: contact_directories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_directories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_directories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_directories_id_seq OWNED BY public.contact_directories.id;


--
-- Name: contact_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_verifications (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    fields jsonb DEFAULT '{}'::jsonb NOT NULL,
    phone character varying,
    email character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: contact_verifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_verifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_verifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_verifications_id_seq OWNED BY public.contact_verifications.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    appointment_id bigint,
    revision character varying,
    channel character varying NOT NULL,
    direction character varying NOT NULL,
    recipient character varying NOT NULL,
    step character varying,
    status character varying NOT NULL,
    external_id character varying,
    body text NOT NULL,
    candidates jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    in_reply_to_id bigint
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: sms_opt_outs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_opt_outs (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    recipient character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_opt_outs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_opt_outs_id_seq OWNED BY public.sms_opt_outs.id;


--
-- Name: visit_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_decisions (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    appointment_id bigint NOT NULL,
    revision character varying NOT NULL,
    state character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: visit_decisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visit_decisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visit_decisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visit_decisions_id_seq OWNED BY public.visit_decisions.id;


--
-- Name: work_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_events (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    work_item_id bigint,
    staff character varying NOT NULL,
    action character varying NOT NULL,
    note text NOT NULL,
    request_id character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: work_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_events_id_seq OWNED BY public.work_events.id;


--
-- Name: work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_items (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    appointment_id bigint NOT NULL,
    revision character varying NOT NULL,
    kind character varying NOT NULL,
    event_key character varying NOT NULL,
    assignee character varying,
    resolved_at timestamp(6) without time zone,
    reason text NOT NULL,
    message_id bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: work_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_items_id_seq OWNED BY public.work_items.id;


--
-- Name: clinic_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinic_states ALTER COLUMN id SET DEFAULT nextval('public.clinic_states_id_seq'::regclass);


--
-- Name: contact_directories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_directories ALTER COLUMN id SET DEFAULT nextval('public.contact_directories_id_seq'::regclass);


--
-- Name: contact_verifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_verifications ALTER COLUMN id SET DEFAULT nextval('public.contact_verifications_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: sms_opt_outs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs ALTER COLUMN id SET DEFAULT nextval('public.sms_opt_outs_id_seq'::regclass);


--
-- Name: visit_decisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_decisions ALTER COLUMN id SET DEFAULT nextval('public.visit_decisions_id_seq'::regclass);


--
-- Name: work_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_events ALTER COLUMN id SET DEFAULT nextval('public.work_events_id_seq'::regclass);


--
-- Name: work_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items ALTER COLUMN id SET DEFAULT nextval('public.work_items_id_seq'::regclass);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: clinic_states clinic_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinic_states
    ADD CONSTRAINT clinic_states_pkey PRIMARY KEY (id);


--
-- Name: contact_directories contact_directories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_directories
    ADD CONSTRAINT contact_directories_pkey PRIMARY KEY (id);


--
-- Name: contact_verifications contact_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_verifications
    ADD CONSTRAINT contact_verifications_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sms_opt_outs sms_opt_outs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs
    ADD CONSTRAINT sms_opt_outs_pkey PRIMARY KEY (id);


--
-- Name: visit_decisions visit_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_decisions
    ADD CONSTRAINT visit_decisions_pkey PRIMARY KEY (id);


--
-- Name: work_events work_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_events
    ADD CONSTRAINT work_events_pkey PRIMARY KEY (id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (id);


--
-- Name: pms_appointments_clinic_patient; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX pms_appointments_clinic_patient ON pms.appointments USING btree (clinic_id, patient_id);


--
-- Name: pms_appointments_clinic_start; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX pms_appointments_clinic_start ON pms.appointments USING btree (clinic_id, start_at);


--
-- Name: pms_patients_email; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX pms_patients_email ON pms.patients USING btree (lower(btrim(email)));


--
-- Name: pms_patients_phone; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX pms_patients_phone ON pms.patients USING btree ("right"(regexp_replace(wireless_phone, '[^0-9]'::text, ''::text, 'g'::text), 10));


--
-- Name: idx_on_clinic_id_appointment_id_revision_2170a15f08; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_on_clinic_id_appointment_id_revision_2170a15f08 ON public.visit_decisions USING btree (clinic_id, appointment_id, revision);


--
-- Name: idx_on_clinic_id_patient_id_channel_created_at_a7dd8b9ab1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_on_clinic_id_patient_id_channel_created_at_a7dd8b9ab1 ON public.messages USING btree (clinic_id, patient_id, channel, created_at);


--
-- Name: index_contact_verifications_on_clinic_id_and_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_contact_verifications_on_clinic_id_and_patient_id ON public.contact_verifications USING btree (clinic_id, patient_id);


--
-- Name: index_contact_verifications_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contact_verifications_on_email ON public.contact_verifications USING btree (email);


--
-- Name: index_contact_verifications_on_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contact_verifications_on_phone ON public.contact_verifications USING btree (phone);


--
-- Name: index_messages_on_clinic_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_clinic_id_and_created_at ON public.messages USING btree (clinic_id, created_at) WHERE ((direction)::text = 'outbound'::text);


--
-- Name: index_sms_opt_outs_on_clinic_id_and_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_sms_opt_outs_on_clinic_id_and_recipient ON public.sms_opt_outs USING btree (clinic_id, recipient);


--
-- Name: index_work_events_on_clinic_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_events_on_clinic_id_and_created_at ON public.work_events USING btree (clinic_id, created_at) WHERE (work_item_id IS NOT NULL);


--
-- Name: index_work_events_on_clinic_id_and_patient_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_events_on_clinic_id_and_patient_id_and_created_at ON public.work_events USING btree (clinic_id, patient_id, created_at);


--
-- Name: index_work_events_on_clinic_id_and_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_work_events_on_clinic_id_and_request_id ON public.work_events USING btree (clinic_id, request_id);


--
-- Name: index_work_events_on_work_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_events_on_work_item_id ON public.work_events USING btree (work_item_id);


--
-- Name: index_work_items_on_clinic_id_and_patient_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_clinic_id_and_patient_id_and_id ON public.work_items USING btree (clinic_id, patient_id, id);


--
-- Name: index_work_items_on_clinic_id_and_resolved_at_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_clinic_id_and_resolved_at_and_id ON public.work_items USING btree (clinic_id, resolved_at, id);


--
-- Name: index_work_items_on_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_message_id ON public.work_items USING btree (message_id);


--
-- Name: sent_messages_by_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sent_messages_by_recipient ON public.messages USING btree (clinic_id, channel, recipient) WHERE (((direction)::text = 'outbound'::text) AND ((status)::text = 'sent'::text));


--
-- Name: unique_inbound_event; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_inbound_event ON public.messages USING btree (clinic_id, channel, external_id) WHERE ((direction)::text = 'inbound'::text);


--
-- Name: unique_reminder_step; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_reminder_step ON public.messages USING btree (clinic_id, appointment_id, revision, step) WHERE ((direction)::text = 'outbound'::text);


--
-- Name: unique_visit_work; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_visit_work ON public.work_items USING btree (clinic_id, appointment_id, revision, event_key);


--
-- Name: appointments appointments_clinic_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES pms.clinics(id);


--
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES pms.patients(id);


--
-- Name: patients patients_guarantor_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_guarantor_id_fkey FOREIGN KEY (guarantor_id) REFERENCES pms.patients(id);


--
-- Name: work_items fk_rails_9064596223; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_9064596223 FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: work_events fk_rails_b611aa0462; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_events
    ADD CONSTRAINT fk_rails_b611aa0462 FOREIGN KEY (work_item_id) REFERENCES public.work_items(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO "$user", public;

INSERT INTO "schema_migrations" (version) VALUES
('20261116000400'),
('20261116000300'),
('20261116000200'),
('20261116000100');
