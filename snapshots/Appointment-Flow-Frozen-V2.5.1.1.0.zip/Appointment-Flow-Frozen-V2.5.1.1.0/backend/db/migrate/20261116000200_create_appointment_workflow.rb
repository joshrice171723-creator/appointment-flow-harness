class CreateAppointmentWorkflow < ActiveRecord::Migration[8.1]
  def change
    create_table :clinic_states, id: false do |t|
      t.bigint :id, primary_key: true
      t.datetime :last_synced_at
    end

    create_table :visit_decisions do |t|
      t.bigint :clinic_id, null: false
      t.bigint :appointment_id, null: false
      t.string :revision, null: false
      t.string :state, null: false
      t.timestamps
      t.index %i[clinic_id appointment_id revision], unique: true
    end

    create_table :messages do |t|
      t.bigint :clinic_id, null: false
      t.bigint :patient_id, null: false
      t.bigint :appointment_id
      t.string :revision
      t.string :channel, null: false
      t.string :direction, null: false
      t.string :recipient, null: false
      t.string :step
      t.string :status, null: false
      t.string :external_id
      t.text :body, null: false
      t.jsonb :candidates, null: false, default: []
      t.timestamps
      t.index %i[clinic_id appointment_id revision step], unique: true,
        where: "direction = 'outbound'", name: "unique_reminder_step"
      t.index %i[clinic_id channel external_id], unique: true,
        where: "direction = 'inbound'", name: "unique_inbound_event"
      t.index %i[clinic_id patient_id channel created_at]
      t.index %i[clinic_id channel recipient], where: "direction = 'outbound' AND status = 'sent'",
        name: "sent_messages_by_recipient"
    end

    create_table :sms_opt_outs do |t|
      t.bigint :clinic_id, null: false
      t.string :recipient, null: false
      t.timestamps
      t.index %i[clinic_id recipient], unique: true
    end

    create_table :contact_verifications do |t|
      t.bigint :clinic_id, null: false
      t.bigint :patient_id, null: false
      t.jsonb :fields, null: false, default: {}
      t.string :phone
      t.string :email
      t.timestamps
      t.index %i[clinic_id patient_id], unique: true
      t.index :phone
      t.index :email
    end

    create_table :work_items do |t|
      t.bigint :clinic_id, null: false
      t.bigint :patient_id, null: false
      t.bigint :appointment_id, null: false
      t.string :revision, null: false
      t.string :kind, null: false
      t.string :event_key, null: false
      t.string :assignee
      t.datetime :resolved_at
      t.text :reason, null: false
      t.references :message, foreign_key: true
      t.timestamps
      t.index %i[clinic_id appointment_id revision event_key], unique: true, name: "unique_visit_work"
      t.index %i[clinic_id resolved_at id]
      t.index %i[clinic_id patient_id id]
    end

    create_table :work_events do |t|
      t.bigint :clinic_id, null: false
      t.bigint :patient_id, null: false
      t.references :work_item, foreign_key: true
      t.string :staff, null: false
      t.string :action, null: false
      t.text :note, null: false
      t.string :request_id, null: false
      t.timestamps
      t.index %i[clinic_id request_id], unique: true
      t.index %i[clinic_id patient_id created_at]
    end
  end
end
