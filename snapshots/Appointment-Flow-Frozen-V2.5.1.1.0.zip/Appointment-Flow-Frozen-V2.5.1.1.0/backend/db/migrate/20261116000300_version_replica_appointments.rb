class VersionReplicaAppointments < ActiveRecord::Migration[8.1]
  def up
    execute <<~SQL
      CREATE VIEW pms.versioned_appointments AS
      SELECT appointments.*, encode(sha256(convert_to(concat_ws('|',
        id, clinic_id, patient_id,
        to_char(start_at, 'YYYY-MM-DD"T"HH24:MI:SS.US'), status,
        coalesce(to_char(updated_at, 'YYYY-MM-DD"T"HH24:MI:SS.US'), '')), 'UTF8')), 'hex') AS revision
      FROM pms.appointments
    SQL

    add_column :clinic_states, :write_generation, :bigint, default: 0, null: false
    add_column :clinic_states, :source_failed_at, :datetime
    add_column :messages, :in_reply_to_id, :bigint
    add_column :work_events, :details, :jsonb, default: {}, null: false
    add_index :messages, %i[ clinic_id created_at ], where: "direction = 'outbound'"
    add_index :work_events, %i[ clinic_id created_at ], where: "work_item_id IS NOT NULL"
  end

  def down
    remove_index :work_events, %i[ clinic_id created_at ]
    remove_index :messages, %i[ clinic_id created_at ]
    remove_column :work_events, :details
    remove_column :messages, :in_reply_to_id
    remove_column :clinic_states, :source_failed_at
    remove_column :clinic_states, :write_generation
    execute "DROP VIEW pms.versioned_appointments"
  end
end
