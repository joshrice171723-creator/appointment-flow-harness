class CreateReplica < ActiveRecord::Migration[8.1]
  def up
    execute <<~SQL
      CREATE SCHEMA pms;
      CREATE TABLE pms.clinics (
        id bigint PRIMARY KEY,
        name text NOT NULL,
        address_line text,
        city text,
        state char(2),
        phone text
      );
      CREATE TABLE pms.patients (
        id bigint PRIMARY KEY,
        first_name text NOT NULL,
        last_name text NOT NULL,
        birthdate date,
        wireless_phone text,
        email text,
        preferred_language text,
        guarantor_id bigint REFERENCES pms.patients(id)
      );
      CREATE TABLE pms.appointments (
        id bigint PRIMARY KEY,
        patient_id bigint NOT NULL REFERENCES pms.patients(id),
        clinic_id bigint NOT NULL REFERENCES pms.clinics(id),
        provider_name text,
        start_at timestamp without time zone NOT NULL,
        length_minutes integer,
        procedure_note text,
        status text NOT NULL,
        updated_at timestamp without time zone
      );
      CREATE INDEX pms_appointments_clinic_start ON pms.appointments (clinic_id, start_at);
      CREATE INDEX pms_appointments_clinic_patient ON pms.appointments (clinic_id, patient_id);
      CREATE INDEX pms_patients_phone ON pms.patients ((right(regexp_replace(wireless_phone, '[^0-9]', '', 'g'), 10)));
      CREATE INDEX pms_patients_email ON pms.patients ((lower(btrim(email))));
    SQL
  end

  def down
    execute "DROP TABLE pms.appointments, pms.patients, pms.clinics"
    execute "DROP SCHEMA pms"
  end
end
