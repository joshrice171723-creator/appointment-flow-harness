class CreateContactDirectories < ActiveRecord::Migration[8.1]
  def up
    create_table :contact_directories do |t|
      t.bigint :generation, null: false, default: 0
    end
    execute "INSERT INTO contact_directories (id) VALUES (1)"
  end

  def down
    drop_table :contact_directories
  end
end
