module DemoData
  CLINICS = [
    [ 1, "Apex Dental · Austin", "Austin", "TX", "210 Orchard Lane", "(512) 555-0100" ],
    [ 2, "Apex Dental · Phoenix", "Phoenix", "AZ", "460 Cypress Avenue", "(602) 555-0100" ]
  ].freeze

  PATIENTS = [
    [ 101, "Avery", "Morgan", "1987-06-15", "(512) 555-0111", "avery@example.test", "en" ],
    [ 102, "Jules", "Bennett", "1993-02-21", nil, "jules@example.test", "en" ],
    [ 103, "Sam", "Rivera", "1991-11-10", "512-555-0199", "sam@example.test", "es" ],
    [ 104, "Robin", "Reed", nil, "512-555-0114", "robin@example.test", "en" ],
    [ 105, "Cameron", "Brooks", "1984-09-02", "512-555-0115", "cameron@example.test", "en" ],
    [ 106, "Riley", "Nguyen", "1979-01-18", "512-555-0116", "riley@example.test", "en" ],
    [ 201, "Jamie", "Davis", "1993-01-05", "602-555-0121", "jamie@example.test", "en" ],
    [ 202, "Taylor", "Ortiz", "1989-05-03", "602-555-0122", "taylor@example.test", "es" ],
    [ 203, "Drew", "Hayes", "1980-05-01", "602-555-0123", "drew@example.test", "en" ],
    [ 204, "Quinn", "Park", "1973-04-13", "602-555-0124", "quinn@example.test", "en" ]
  ].freeze

  def self.load!(now: Time.current)
    ApplicationRecord.transaction do
      upsert("pms.clinics", CLINICS, %i[ id name city state address_line phone ])
      upsert("pms.patients", PATIENTS, %i[ id first_name last_name birthdate wireless_phone email preferred_language ])
      visits = CLINICS.flat_map do |clinic_id, *_|
        zone = ActiveSupport::TimeZone[Pms::Clinic::ZONES.fetch(clinic_id)]
        today = now.in_time_zone(zone).to_date
        patient_ids = PATIENTS.filter_map { |id, *_| id if id / 100 == clinic_id }
        upcoming = patient_ids.each_with_index.map do |id, index|
          day = [ 7, 7, 5, 1, 1, 3 ].fetch(index)
          [ id, id, clinic_id, "Dr. #{index.even? ? 'Chen' : 'Ellis'}", "#{today + day} #{12 + index}:30:00",
            45, "Routine dental visit", "scheduled", "#{today} 08:00:00" ]
        end
        history = [ today.beginning_of_month, today.last_month.beginning_of_month ].flat_map.with_index do |month, offset|
          %w[ complete complete broken unscheduled ].each_with_index.map do |status, index|
            id = clinic_id * 10000 + offset * 100 + index
            [ id, patient_ids.fetch(index), clinic_id, "Dr. Chen", "#{month + index} 09:00:00",
              30, "Routine dental visit", status, "#{month + index} 10:00:00" ]
          end
        end
        upcoming + history
      end
      upsert("pms.appointments", visits, %i[ id patient_id clinic_id provider_name start_at length_minutes procedure_note status updated_at ])
      CLINICS.each { |id, *_| ClinicState.find_or_create_by!(id: id) }
      ContactDirectory.find_or_create_by!(id: 1)
    end
  end

  # Demo fixture writer is loaded only by db:seed and tests.
  def self.upsert(table, rows, columns)
    connection = ApplicationRecord.lease_connection
    values = rows.map { |row| "(#{row.map { |value| connection.quote(value) }.join(', ')})" }.join(", ")
    updates = columns.drop(1).map { |field| "#{field} = EXCLUDED.#{field}" }.join(", ")
    connection.execute("INSERT INTO #{table} (#{columns.join(', ')}) VALUES #{values} ON CONFLICT (id) DO UPDATE SET #{updates}")
  end
  private_class_method :upsert
end
