namespace :reminders do
  desc "Run a simulated reminder batch for each clinic at the current time (override with DEMO_NOW)"
  task run: :environment do
    unavailable = []
    ClinicState.order(:id).pluck(:id).each do |clinic_id|
      begin
        counts = ReminderBatch.new.run(clinic_id)
        puts "Clinic #{clinic_id}: #{counts.fetch(:sent)} sent, #{counts.fetch(:failed)} failed (simulated)"
      rescue ClinicState::SourceUnavailable => error
        warn "Clinic #{clinic_id}: #{error.message}"
        unavailable << clinic_id
      end
    end
    abort "Reminder scan incomplete for clinics #{unavailable.join(', ')}." if unavailable.any?
  end
end
