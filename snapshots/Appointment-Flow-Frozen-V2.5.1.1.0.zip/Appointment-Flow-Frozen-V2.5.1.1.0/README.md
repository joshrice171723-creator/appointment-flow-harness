# Apex Appointment Flow

A local Rails and React demo for appointment reminders, confirmation replies, clinic follow-up, and aggregate outcome reporting. All seeded patients and messages are fictional. SMS and email use an in-process fake transport.

## Run locally

Prerequisites are Ruby 3.4.10 with Bundler 4, Node.js 24 with npm, Python 3.10 or later, and PostgreSQL 17 with the PostgreSQL client tools on your PATH. On Windows, the launcher also checks the standard PostgreSQL 17 install location. Use libpq settings such as `PGHOST`, `PGPORT`, and `PGUSER` for your local instance. The configured role must be able to create the two local demo databases.

From the repository root:

```text
cd backend
bundle install
cd ../frontend
npm ci
cd ..
python scripts/demo.py
```

Open [the local app](http://127.0.0.1:5273). The launcher creates and migrates the databases, seeds fictional visits for Austin and Phoenix, runs a reminder batch, and starts both servers. Press Ctrl+C to stop. The demo uses 18:00 UTC on the current UTC date so both clinics are in their sending windows. Set `DEMO_NOW` to an ISO 8601 timestamp before launch to use another fixed date. A Rails process started directly uses the system clock by default. The default ports are 5273 for React and 3300 for Rails. Override them with `APEX_WEB_PORT` and `APEX_API_PORT`.

### Walk through a reminder

1. Open **Patient**, select **Austin**, then **Avery Morgan**. Submit `YES` in **Text messages**. For email, select **Jules Bennett**, switch to **Email**, select the reminder and submit `yes`.
2. Open **Front desk**, select **Austin** and **Morgan**, and open **Appointments**. Move to the date in the reminder, which is seven days after the demo date for these examples. Both visits appear under **Confirmed**, with their PMS outcome shown separately.
3. In **Patient flow**, search for **Robin Reed** to see a missing-birthdate hold. Assign the item to yourself, enter a note and record **Contact attempted**, or verify the fictional birthdate in **Patient details** and run the batch again.
4. Open **Apex leadership** to see counts by outcome and clinic. The report uses recorded outcomes and simulated activity. Measuring the effect on missed visits would need additional outcome data.

Start a reminder batch from `backend` with this command.

```text
ruby bin/rails reminders:run
```

Set `DEMO_NOW` to the precise value printed by the launcher to use the same clinic-local time. Use `ruby bin/rails db:seed` to reload the source fixtures. Seeding upserts fixture rows and retains app-owned messages, opt-outs, and staff decisions. The inbox displays successful fake sends and simulated replies. Staff can see failed delivery work on the board. Query attempt counts with:

```text
ruby bin/rails runner "pp Message.outbound.group(:clinic_id, :channel, :status).count"
```

### Verify

With dependencies installed, PostgreSQL running, and `DEMO_NOW` unset, run:

```text
python scripts/demo.py --prepare-only
python quality/run_checks.py
```

The gate runs Rails tests and autoload verification, RuboCop, Brakeman, React lint, TypeScript, Vitest, and a client build. The test database is scratch space. On Windows, add PostgreSQL's `bin` directory to PATH for direct Rails database tasks.

For browser verification, start the demo on fresh fictional data, then run `npm run smoke` in `frontend`. It uses an installed Microsoft Edge. Set `BROWSER_PATH` to use a different Chromium executable. The smoke creates simulated patient replies and records a fictional staff follow-up.

## Operating decisions

- Reminders run during 10:00–18:00 clinic-local time, with steps around 7, 6, 3, and 1 days ahead. The six-day email is a backup after an initial text. A late batch picks one applicable step, with at most one attempt per visit per clinic-local day. After confirmation, a final informational reminder can still be sent.
- Valid source contacts for seeded adults are treated as permission to simulate outreach. A missing birthdate, minor, unsupported language, or verified contact conflict triggers a hold. Shared addresses are excluded as recipients. A safe alternate channel can still be used. `STOP` suppresses the recipient's SMS for the clinic. Staff can clear a local contact field to remove that channel from eligibility.
- The appointment revision uses source identity, wall time, status, and the source update timestamp. A plain reply can auto-confirm when its recipient/channel history identifies exactly one expected revision. If the patient’s text number has changed, the demo requires the originating number. An explicit email reply can disambiguate visits through its sent-email reference. Repeated unthreaded visits, stale times, and uncertain replies require staff.
- Austin uses America/Chicago and Phoenix uses America/Phoenix. Unresolvable DST wall times are held. A batch reads a consistent replica snapshot. The reported sync time is the last successful reminder scan. An empty clinic replica blocks sends and preserves existing local work. Replication lag still applies.
- The staff picker is a local identity stub. Production would need authenticated identities and clinic membership, read-only database grants to the replica, independent consent and guardian authorization records, provider delivery receipts and callbacks, and a reliable retry boundary around actual delivery.

See [Architecture](ARCHITECTURE.md) and [candidate decision notes](notes/CANDIDATE_DECISION_NOTES.md). The assessment requires the candidate to write `DECISIONS.md` in their own words.
