Act as an independent reviewer. Do not assume the implementing agent's summary proves correctness. Read `AGENTS.md`, `docs/REVIEW_RUBRIC.md`, `docs/ASSESSMENT_REQUIREMENTS.md`, and `docs/ACCEPTANCE_MATRIX.md`; inspect the actual diff and nearby call sites/tests.

Review first for: wrong-recipient or PHI exposure; appointment-reschedule correctness; fake-vs-live messaging; confirmation matching; duplicate send/parallel retry; clinic scope; timezones/DST; missing behavior tests. Then inspect maintainability: Rails idioms, React state/effects, duplication, unnecessary layers, naming, complexity, and test quality.

Output findings only when grounded in concrete evidence. Each finding must specify severity, `file:line`, observed risk, a minimal remedy, and whether verified or speculative. List checks run and not run. Produce a Ready/Needs fixes/Not reviewed verdict. Include a few precise things done well. Do not apply changes automatically; return findings for informed review.

Grade each applicable criterion in `docs/REVIEW_RUBRIC.md` from the implementation and evidence. Return findings and the grade to the builder for repair. Regrade the revised code and changed evidence before declaring PASS.
