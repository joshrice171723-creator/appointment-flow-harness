# Rubric results

## Implementation under review

`8f52b64f03eb867fc3a6147024f6cf8bd65d0856` on local `main`. **Overall technical grade PASS.** This grade covers the clean-room implementation and local verification. Candidate authorship and live defense are tracked in the [freeze checklist](FREEZE_CHECKLIST.md).

A separate read-only Codex session reviewed a numbered packet of the staged source. Its shell integration failed to launch, so the reviewer traced the attached code and marked execution unverified. The implementation session ran the application, exercised the failure cases, and rechecked the repaired implementation.

## Review rounds

| Round | Grade | Findings and repairs |
| --- | --- | --- |
| Initial independent review | REVISE | Stale SMS replies could inherit a replacement visit after a phone change. Cross-clinic contact corrections could race with sends or replies. An unavailable clinic could stop the reminder command. Deleted or transferred visits left active work. A board link could lose its selected item beyond the history cap. Search logging exposed names. Repeat batches looked up follow-up one visit at a time. |
| First static regrade | REVISE | The regrade traced the seven repairs and found that the contact-lock row depended on seeding. It also required the larger repeat workload to include existing near-visit work and requested live log evidence. |
| Final static regrade | PASS for the seven findings | The independent session confirmed the migration initialization and the more representative repeat workload in source. It accepted the supplied log evidence and left execution to the implementation session. |
| Final repair and verification | PASS | The migration initializes the shared lock row. A fresh migration-only database contained row 1 without seeding, and an upgrade from the earlier clean-room schema created row 1 while retaining existing clinic state. A clean schema restore, seed, and reminder run succeeded separately. The larger repeat fixture includes 18 more near visits and six new contact holds. An actual Rails request logged the fictional search term as `[FILTERED]` in both the URL and request parameters. |

## Required criteria

| Criterion | Grade | Final evidence |
| --- | --- | --- |
| Required behavior | PASS | Fresh setup ran `db:prepare db:seed reminders:run`. The browser submitted SMS and threaded email replies and found both appointments under Confirmed. The [workspace tests](../backend/test/integration/workspaces_test.rb) verify the API results. |
| Safety and data boundaries | PASS | [Reminder workflow tests](../backend/test/models/reminder_workflow_test.rb) exercise contact holds, STOP, ambiguous recipients, changed numbers, same-row and replacement reschedules, DST, exact start boundary, failed sends, repeat runs, concurrent batches, and the cross-clinic ownership race. Rails source models are read-only. The leadership response test asserts aggregate outcomes and absence of patient fields. |
| Performance and Rails queries | PASS | The [workload test](../backend/test/integration/workload_test.rb) measured the appointment endpoint and reminder caller with constant relevant work, more historical noise, and more relevant cases. See the measured results below. |
| Material workflow coverage | PASS | Browser, Rails integration, and persisted-state tests cover receptionist assignment, local correction, manual outcomes, ambiguous reply review, arrival outcomes, tenant scope, manual reminders, and follow-up retries. One clinic with an empty replica fails the reminder command while the healthy clinic still records its sends. |
| Human readability | PASS | The reminder task calls `ReminderBatch#run` at `backend/app/models/reminder_batch.rb:13`. Batch prep limits selection to one clinic and horizon, then applies contact and scheduling rules before writing a fake attempt. `PatientReply#record` at `backend/app/models/patient_reply.rb:15` matches the recipient and revision before persisting a confirmation or review. |
| Ease of change | PASS | `ReminderBatch::WINDOW` at `backend/app/models/reminder_batch.rb:3` owns the send hours. Both send-time checks use that range. The local-window and DST test covers the same instant in Austin and Phoenix. |
| Failure and transaction behavior | PASS | `ClinicState.with_replica` at `backend/app/models/clinic_state.rb:6` owns rollback and serialization retry. Tests check persisted state after a mid-batch adapter crash, a partial staff clarification failure, and a stale directory snapshot. The browser drops the first follow-up response after commit and verifies that retrying with the same request ID leaves one activity entry. |
| Verification and handoff | PASS | `python quality/run_checks.py` passed all eight checks. Rails reported 30 tests and 190 assertions, Vitest passed three tests, and Brakeman reported zero warnings. Startup, browser smoke, request logs, and clean database setup were verified locally. README, architecture, and candidate notes match the implementation. |

## Workload evidence

Measured the full synchronous request or per-clinic batch with the harness probe. Setup was outside the measured operation. All five measured cases had zero cached statements. Times are local observations and vary with runtime load.

| Scenario | Appointment HTTP GET | Reminder batch |
| --- | --- | --- |
| Baseline | 37.0 ms, 7 SQL statements, 6 instantiated records, 0 writes, 2 visits returned | 138.5 ms, 29 SQL statements, 15 records, 11 write statements, 4 sent and 1 failed |
| 600 older visits and 600 old attempts | 20.9 ms, 7 SQL statements, 6 records, 0 writes, same visits | 58.4 ms, 29 SQL statements, 15 records, 11 writes, same 4 sent and 1 failed |
| Additional 18 visits within 48 hours | 23.6 ms, 7 SQL statements, 6 records, 0 writes, same visits | 311.4 ms, 65 SQL statements, 33 records, 47 writes, 16 sent and 1 failed |
| Repeat of baseline with existing work | — | 64.9 ms, 19 SQL statements, 23 records, 2 write statements, 0 new attempts |
| Repeat with 18 more near visits and existing work | — | 66.4 ms, 19 SQL statements, 77 records, 2 write statements, 0 new attempts |

The larger initial batch creates 12 more successful attempts, 18 near-visit follow-ups, and six contact holds. Repeat scans load the current workflow rows in bulk. The two write statements are work reconciliation and the clinic generation update. The lock generation invalidates a concurrent stale snapshot. Independent clinic scans can share the contact directory read lock and verified contact changes use an exclusive lock. Instantiated counts measure rows loaded by Rails. Database query plans and production capacity were outside this local evidence.

A separate repeat of the whole `reminders:run` command, including Rails startup and both clinics, took 9.908 seconds and recorded zero additional attempts at the same demo time.
