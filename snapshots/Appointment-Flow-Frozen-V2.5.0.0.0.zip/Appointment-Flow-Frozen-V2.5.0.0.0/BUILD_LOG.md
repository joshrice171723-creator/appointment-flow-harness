# Apex build log

## Preflight

- `py quality/verify_harness.py` and `python quality/verify_harness.py` each passed with 51 packaged inputs and all 10 PNG signatures. The Email reference shows an empty Email tab for a selected patient. The PDF controls workflow scope.
- Build plan covers B01–B11. Start with the PostgreSQL PMS boundary, appointment revisions and safety-focused reminder/reply checks, then expose clinic-scoped staff actions, aggregate reporting and the patient inbox through React. Verify the full workflow through the quality runner and a separate reviewer.
- Workflow plan. A batch refreshes the source snapshot successfully before picking eligible future visits, then records a local delivery attempt under a clinic lock. An inbound event validates its clinic and contact, deduplicates by event ID, checks its candidate against the current source revision and records either confirmation or a staff task in the same transaction. Staff decisions, local contact edits and replies share that clinic lock. Source or persistence failures must abort writes and remain diagnosable.
- Chosen architecture uses a single Rails application, two PostgreSQL schemas and a React build, with clinic-local business rules and a simulated clock available only to local demo commands. A queue and a live provider add operating cost without improving the local assessment.

## November 16, 2026

### PMS intake, reminders and replies (B02–B05)

- Applied the PostgreSQL migrations in development and test. The replica uses the supplied columns and wall-clock timestamps. The local snapshot gives confirmations and messages revision identity while retaining PMS contact values and authority.
- Implemented send thresholds, channel selection, fake attempts, STOP and reply review. The demo seed produced 13 fake sends and one fake failure. PostgreSQL regressions exercise wrong-recipient holds, clinic clocks, newer revisions, batch rollback, retries and concurrent attempts.
- Considered a background job and per-message external identifiers. The batch runs on demand, and unthreaded replies with multiple plausible visits or an older revision require staff clarification.

### Staff, leadership and inbox (B01, B06–B10)

- Added scoped staff sessions, board and appointment filters, local contact verification, follow-up outcomes, and aggregate reporting. React shares its API loader and keeps drafts in the form that owns them. Server-side scopes keep the staff view independent of the browser picker.
- Added both inbox channels, exercised their reply logic in Rails tests, and added browser checks. Verified the 1440-pixel workspace and board visually in Edge and the seeded leadership API over HTTP. CSS layout follows the supplied reference screens using local fonts.
- The independent reviewer found stale SMS after a long reschedule and a follow-up rejection that rolled back a successful source refresh. Added regression coverage for both and changed the next-appointment summary to check the appointment instant. The reviewer cleared the fixes.

### Local operation and checks (B11)

- Added a pinned dependency set, one startup command and the quality runner configuration. The first full quality run exposed an ESLint error and two browser locator failures. Browser teardown also invoked a broad Rails database task that removed the clean-room test database. Recreated that database and changed browser setup to skip test-database handling and cleanup to target only the disposable database by name.
- Local development started successfully on web port 5180 and API port 4310 after the default web port was found in use. The app keeps all demo messaging in PostgreSQL.
- Completed the startup, architecture and AI-use documentation. The result files are separate from the packaged templates so future preflight verification can still validate the original hashes.
- The final local quality gate passed all eight checks in 1 minute 59 seconds. Rails ran 24 tests with 140 assertions, Vitest ran two tests and Edge ran three browser scenarios. Browser setup and teardown now use an explicitly created disposable database and its own Rails PID file. See [verification results](review/RESULTS.md) for the verified application revision and pending candidate deliverables.
