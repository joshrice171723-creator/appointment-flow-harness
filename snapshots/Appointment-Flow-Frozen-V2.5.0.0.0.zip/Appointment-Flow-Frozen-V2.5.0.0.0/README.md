# Apex Appointment Flow

A local Rails and React demo for clinic follow-up, appointment confirmation, and aggregate reporting. The seed includes fictional Austin and Phoenix clinics. All SMS and email delivery stays in the local PostgreSQL database.

## Run locally

The rebuild was developed with Ruby 3.4.10, Rails 8.1.4.1, React 19.3.1, Vite 7.3.8, Node 24.19.0, npm 11.17.0 and PostgreSQL 17.11. Install the dependencies declared in the lockfiles.

```sh
cd backend
bundle install
cd ../frontend
npm ci
cd ..
python scripts/start_demo.py
```

Use a running PostgreSQL 17 server with its client tools on PATH. The demo uses standard `PGHOST`, `PGPORT`, `PGUSER` and `PGPASSWORD` settings. Rails defaults to `127.0.0.1:5432` and user `postgres`. The local setup role needs permission to create the dedicated demo and test databases. On Windows, add the PostgreSQL `bin` directory to PATH. The local verification used port `55718`.

Open the local demo at `http://127.0.0.1:5173/`. The startup command runs database preparation and seeds an empty demo database, then starts both processes on loopback. Set `APEX_WEB_PORT` and `APEX_API_PORT` if the defaults are occupied. Stop them with Ctrl+C.

## Try the workflows

- **Front desk.** Select Austin and a staff member. On Patient flow, use **Run reminders** to refresh the PMS and run a batch at the demo clock, or **Refresh PMS** to refresh only. Open an item, assign it to yourself, and record a follow-up with a note. Appointments shows confirmation independently from the visit outcome.
- **Patient.** Open the inbox and choose Austin, then **Avery Chen** for SMS or **Marisol Reyes** for email. Send `YES` in Avery’s Text messages tab or `SI` in Marisol’s Email tab. Check **November 23, 2026** in Austin’s Appointments view. Try `NO`, `STOP`, or other text to exercise review and SMS opt-out.
- **Apex leadership.** Choose a reporting month and expand the aggregate sections. Completion comes from the PMS status. Unknown includes visits whose source status does not establish a completed outcome. The sample metrics cannot measure no-shows or causal effects.

The startup script sets the demo clock to `2026-11-16T17:00:00Z` by default. The first batch is part of the seed. The same run is safe to repeat. To advance the clock by a day and exercise the backup-email step, stop the demo and start it with `APEX_DEMO_NOW=2026-11-17T17:00:00Z` in the environment, then run reminders again. A command-line batch for both clinics is available from `backend` with `ruby bin/rails apex:reminders`. Set the same `APEX_DEMO_NOW` when using the command. Rails uses the real clock when the variable is absent.

Successful fake sends appear in the inbox. Austin’s **Robin Hayes** has a seeded failed SMS, visible in Patient flow. A database console can inspect both sent and failed deliveries without reading message contents:

```sh
psql -d apex_cleanroom_development -c "SELECT clinic_id, visit_id, revision, step, channel, status, occurred_at FROM deliveries ORDER BY id"
```

To test a reschedule, confirm Avery’s visit and change the fictional source row using the fixture owner connection, then refresh Austin or reply from the old inbox.

```sql
UPDATE pms.appointments
SET start_at = '2026-11-23 16:00:00', updated_at = LOCALTIMESTAMP
WHERE id = 1001;
```

The new time requires a fresh confirmation. A reply that could refer to an old or new request goes to staff review.

## Verify

Prepare the test database with `ruby bin/rails db:prepare` from `backend` with `RAILS_ENV=test`. Then run from the repository root:

```sh
python quality/verify_harness.py
python quality/run_checks.py
```

The runner executes Rails tests, RuboCop, Brakeman, React lint/types/tests/build, and Playwright against disposable seeded PostgreSQL data. The browser checks use installed Edge on Windows. On other systems run `npx playwright install chromium` from `frontend` before invoking the gate. Ports 4173 and 4300 are used by the browser checks. The test PostgreSQL user needs permission to create and drop the disposable browser database.

Staff sign-in is a demo identity picker with server-side clinic scoping. Production would need real staff authentication and clinic membership checks, verified messaging consent and inbound provider identity, separate least-privilege database roles, and retention controls for audit and contact data.

See [architecture](ARCHITECTURE.md), [implementation notes for the candidate](notes/REBUILD_DECISIONS.md), and [verification results](review/RESULTS.md).
