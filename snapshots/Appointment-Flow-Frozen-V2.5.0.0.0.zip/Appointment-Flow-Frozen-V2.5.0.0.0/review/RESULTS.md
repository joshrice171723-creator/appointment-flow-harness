# Rebuild verification

Application revision `e435b4d4bbad2f0098e858c045177a334c855b09` was verified on Windows with PostgreSQL 17.11 and Edge. The original preflight passed before scaffolding and passed again after the rebuild. It verified 51 packaged inputs and 10 PNG signatures.

## Quality gate

`python quality/run_checks.py` passed all eight checks in 1 minute 59 seconds, including disposable browser database setup and teardown.

| Check | Result |
| --- | --- |
| Rails tests | PASS · 24 tests, 140 assertions, zero failures, errors or skips |
| RuboCop | PASS · 60 files, zero offenses |
| Brakeman | PASS · 79 checks, zero errors or warnings |
| React lint and TypeScript | PASS · ESLint and `tsc --noEmit` |
| React unit tests | PASS · 2 tests |
| React production build | PASS · Vite compiled the application and local fonts |
| Browser smoke | PASS · 3 Edge scenarios, including a 375-pixel viewport |

## Assessment and workflow evidence

| Outcome | Result | Evidence |
| --- | --- | --- |
| Discover visits and read the provided PostgreSQL replica without runtime writes | PASS | [Reminder workflow](../backend/test/integration/reminder_workflow_test.rb) covers source discovery, revisions, failed reads and the read-only role |
| Fake SMS and email cadence, failure history and confirmation | PASS | [Reminder workflow](../backend/test/integration/reminder_workflow_test.rb) and [browser SMS/email](../frontend/e2e/workspaces.spec.ts) |
| Clinic-scoped appointments and follow-up board | PASS | [Clinic scoping](../backend/test/integration/workspaces_test.rb) and [browser filtering, assignment and retry](../frontend/e2e/workspaces.spec.ts) |
| Patient details, verification, and source preservation | PASS | [Contact hold and correction cases](../backend/test/integration/reminder_workflow_test.rb) and the running browser patient view |
| Leadership outcomes and privacy | PASS | [Aggregate-only API](../backend/test/integration/workspaces_test.rb) and [narrow browser reporting](../frontend/e2e/workspaces.spec.ts) |
| Local startup, seed, manual batch and inbox replies | PASS | Started both services with [the startup script](../scripts/start_demo.py). Seed produced 13 fake sends and one intentional failure. A same-clock CLI rerun sent zero duplicates. Both browser reply channels confirmed their appointment. |
| Startup, architecture and AI-use deliverables | PASS | [README](../README.md), [architecture and state diagram](../ARCHITECTURE.md), [AI usage](../AI_USAGE.md) |
| Candidate decisions and in-person defense | NOT RUN | [Implementation notes](../notes/REBUILD_DECISIONS.md) are available for the candidate’s own `DECISIONS.md`. Candidate authorship and live defense are pending. |

S01–S09 and S11–S15 are exercised in the Rails reminder workflow, including a three-thread race, mid-batch rollback, exact STOP, stale replies after 15 days and DST edge conversion. S10 and S16–S17 are exercised through the API. S18–S20 are exercised in Edge with the real backend and a disposable PostgreSQL database. The draft test covers a validation error and a committed save whose response is interrupted.

The 1440-pixel workspace chooser and patient-flow board were visually checked in Edge. The browser suite checked the narrow leadership view. Formal human visual acceptance and volume testing were outside the checks performed.

## Independent review

An independent code reviewer examined the new diff, Rails call sites, test evidence and the privacy boundaries. The targeted re-review returned **Ready** after these findings were addressed.

- Blocking stale reply. [Reply intake](../backend/app/services/reply_intake.rb) now considers successful older requests for the same visit and recipient beyond the ten-day matching window. A persisted-state regression checks that an unthreaded YES at 15 days enters review.
- Major stale follow-up. [Staff follow-up](../backend/app/services/staff_follow_up.rb) preserves a successful PMS refresh while rejecting an action against the old revision. The regression checks the new snapshot and absence of the rejected action.
- Minor next-visit summary. [Visit presentation](../backend/app/controllers/concerns/visit_views.rb) uses the clinic-local appointment instant, so already-started visits drop out of the next-visit summary.

The reviewer ran preflight, TypeScript and RuboCop. The implementing session ran the complete quality gate. The generated schema trailing blank line was removed and `git diff --check` passed.

## Freeze

Keep this report with the local commits and compare the pinned application revision if a later comparison is authorized. The repository has no remote. The [GitHub Actions workflow](../.github/workflows/quality.yml) was parsed and checked for preflight ordering locally. Hosted CI and branch protection remain unverified. See the [decision notes](../notes/REBUILD_DECISIONS.md) for the reminder clock, contact permission assumptions and reporting limits.
