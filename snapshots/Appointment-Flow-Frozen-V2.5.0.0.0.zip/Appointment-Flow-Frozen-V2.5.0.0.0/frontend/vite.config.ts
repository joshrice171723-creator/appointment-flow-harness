import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    proxy: { '/api': process.env.APEX_API_TARGET || 'http://127.0.0.1:3000' },
  },
  preview: {
    proxy: { '/api': process.env.APEX_API_TARGET || 'http://127.0.0.1:3000' },
  },
})
