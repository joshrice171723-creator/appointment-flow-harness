import { expect, test } from '@playwright/test'

test('S01 and S20 simulated SMS and email replies reach the clinic appointment list', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('link', { name: 'Open patient inbox' }).click()
  await page.getByRole('combobox', { name: 'Clinic', exact: true }).selectOption({ label: 'Austin' })
  await page.getByRole('combobox', { name: 'Patient', exact: true }).selectOption({ label: 'Avery Chen' })
  await expect(page.getByText(/Reply YES to confirm/)).toBeVisible()
  await page.getByRole('button', { name: 'Email', exact: true }).click()
  await expect(page.getByText('No simulated emails for this patient yet.')).toBeVisible()
  await page.getByRole('button', { name: 'Text messages' }).click()
  await page.getByLabel('Your reply').fill('YES')
  await page.getByRole('button', { name: 'Send reply' }).click()
  await expect(page.getByRole('status')).toHaveText('Reply recorded. The appointment is confirmed.')

  await page.getByRole('combobox', { name: 'Patient', exact: true }).selectOption({ label: 'Marisol Reyes' })
  await page.getByRole('button', { name: 'Email', exact: true }).click()
  await expect(page.getByText(/Responda SI para confirmar/)).toBeVisible()
  await page.getByLabel('Your reply').fill('SI')
  await page.getByRole('button', { name: 'Send reply' }).click()
  await expect(page.getByRole('status')).toHaveText('Reply recorded. The appointment is confirmed.')

  await page.getByRole('link', { name: 'Workspaces', exact: true }).click()
  await page.getByRole('button', { name: 'Open front desk' }).click()
  await page.getByRole('link', { name: 'Appointments' }).click()
  await page.getByLabel('Jump to date').fill('2026-11-23')
  await page.getByRole('button', { name: /^Confirmed · / }).click()
  await expect(page.getByRole('row').filter({ hasText: 'Avery Chen' })).toContainText('Confirmed')
  await expect(page.getByRole('row').filter({ hasText: 'Marisol Reyes' })).toContainText('Confirmed')
})

test('S18 and S19 board filtering, ownership and a rejected follow-up preserve the draft', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('button', { name: 'Open front desk' }).click()
  await page.getByLabel('Patient search').fill('Sam Patel')
  await page.getByLabel('Follow-up type').selectOption('contact_hold')
  await expect(page.getByRole('link', { name: /Sam Patel/ })).toHaveCount(1)
  await expect(page.getByRole('link', { name: /Drew Cole/ })).toHaveCount(0)
  await page.getByRole('link', { name: /Sam Patel/ }).click()
  const hold = page.locator('article').filter({ hasText: 'Reminders blocked' })
  await hold.getByRole('button', { name: 'Assign to me' }).click()
  const note = hold.getByLabel('Follow-up note')
  await note.fill('Left a voicemail at the verified number.')
  let attempts = 0
  await page.route('**/follow_ups', async (route) => {
    attempts += 1
    if (attempts === 1) {
      await route.fulfill({ status: 422, json: { error: 'Follow-up could not be recorded. Check and retry.' } })
    } else if (attempts === 2) {
      expect((await route.fetch()).ok()).toBe(true)
      await route.abort()
    } else {
      await route.continue()
    }
  })
  await hold.getByRole('button', { name: 'Record follow-up' }).click()
  await expect(hold.getByRole('alert')).toHaveText('Follow-up could not be recorded. Check and retry.')
  await expect(note).toHaveValue('Left a voicemail at the verified number.')
  await hold.getByRole('button', { name: 'Record follow-up' }).click()
  await expect(hold.getByRole('alert')).toContainText('Connection interrupted.')
  await expect(note).toHaveValue('Left a voicemail at the verified number.')
  await hold.getByRole('button', { name: 'Record follow-up' }).click()
  await expect(hold.getByRole('status')).toHaveText('Follow-up recorded.')
  await page.getByRole('button', { name: 'Activity log' }).click()
  await expect(page.getByText('Left a voicemail at the verified number.')).toHaveCount(1)

  await page.getByRole('link', { name: 'Workspaces', exact: true }).click()
  await page.getByRole('combobox', { name: 'Clinic', exact: true }).selectOption({ label: 'Phoenix' })
  await page.getByRole('button', { name: 'Open front desk' }).click()
  await expect(page.getByText('Phoenix', { exact: true })).toBeVisible()
  await expect(page.getByText('Left a voicemail at the verified number.')).toHaveCount(0)
})

test('S17 narrow leadership view expands reporting with aggregate data', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 810 })
  await page.goto('/')
  await page.getByRole('link', { name: 'Open Apex leadership' }).click()
  await page.getByText('Monthly history and reminder activity').click()
  await expect(page.getByRole('cell', { name: 'October 2026' }).first()).toBeVisible()
  await expect(page.getByText('Avery Chen')).toHaveCount(0)
  await expect(page.getByRole('heading', { name: 'Appointment outcomes' })).toBeVisible()
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(375)
})
