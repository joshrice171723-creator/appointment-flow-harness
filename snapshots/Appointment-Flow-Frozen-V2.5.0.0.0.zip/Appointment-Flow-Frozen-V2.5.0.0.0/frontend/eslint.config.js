import js from '@eslint/js'
import hooks from 'eslint-plugin-react-hooks'
import tseslint from 'typescript-eslint'

export default tseslint.config(
  { ignores: ['dist', 'playwright-report', 'test-results'] },
  { files: ['**/*.{ts,tsx,js}'], extends: [js.configs.recommended, ...tseslint.configs.recommended] },
  { files: ['src/**/*.{ts,tsx}'], extends: [hooks.configs.flat.recommended] },
)
