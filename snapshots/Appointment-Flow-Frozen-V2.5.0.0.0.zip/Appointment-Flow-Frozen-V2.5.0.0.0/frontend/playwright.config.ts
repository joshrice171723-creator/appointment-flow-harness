import { defineConfig } from '@playwright/test'

export default defineConfig({
  testDir: 'e2e',
  workers: 1,
  reporter: 'list',
  use: {
    baseURL: 'http://127.0.0.1:4173',
    channel: process.platform === 'win32' ? 'msedge' : undefined,
    trace: 'retain-on-failure',
  },
  webServer: [
    { command: 'ruby bin/rails server -b 127.0.0.1 -p 4300', cwd: '../backend', url: 'http://127.0.0.1:4300/up' },
    { command: 'node node_modules/vite/bin/vite.js --host 127.0.0.1 --port 4173',
      env: { APEX_API_TARGET: 'http://127.0.0.1:4300' }, url: 'http://127.0.0.1:4173' },
  ],
})
