import { expect, test } from 'vitest'
import { addDays, completionRate, wallTime, weekOf } from './dates'

test('calendar weeks and date jumps retain clinic wall dates across DST and year boundaries', () => {
  expect(weekOf('2026-11-01')).toEqual([
    '2026-10-26', '2026-10-27', '2026-10-28', '2026-10-29', '2026-10-30', '2026-10-31', '2026-11-01',
  ])
  expect(addDays('2026-12-31', 1)).toBe('2027-01-01')
  expect(wallTime('2026-11-01T01:30:00.000000')).toBe('1:30 AM')
})

test('completion rate has no percentage when zero visits were recorded', () => {
  expect(completionRate(0, 0)).toBe('—')
  expect(completionRate(0, 8)).toBe('0.0%')
  expect(completionRate(7, 8)).toBe('87.5%')
})
