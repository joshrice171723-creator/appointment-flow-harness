function calendarDate(date: string) {
  return new Date(`${date}T12:00:00Z`)
}

export function addDays(date: string, days: number) {
  const value = calendarDate(date)
  value.setUTCDate(value.getUTCDate() + days)
  return value.toISOString().slice(0, 10)
}

export function weekOf(date: string) {
  const weekday = (calendarDate(date).getUTCDay() + 6) % 7
  return Array.from({ length: 7 }, (_, index) => addDays(date, index - weekday))
}

export function shortDate(date: string) {
  return calendarDate(date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' })
}

export function wallTime(wall: string) {
  const [hour, minute] = wall.slice(11, 16).split(':').map(Number)
  return `${hour % 12 || 12}:${String(minute).padStart(2, '0')} ${hour >= 12 ? 'PM' : 'AM'}`
}

export function wallLabel(wall: string) {
  return `${shortDate(wall.slice(0, 10))}, ${wallTime(wall)}`
}

export function localTimestamp(instant: string, zone: string) {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: zone,
  }).format(new Date(instant))
}

export function monthLabel(month: string) {
  return calendarDate(`${month}-01`).toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })
}

export function completionRate(completed: number, recorded: number) {
  return recorded ? `${(completed / recorded * 100).toFixed(1)}%` : '—'
}
