import { useState } from 'react'
import { useLoad } from './api'
import { completionRate, monthLabel } from './dates'
import { Header, LoadStatus } from './shared'
import type { LeadershipData, MonthlySummary } from './types'

const outcomeFields = [
  { key: 'completed', label: 'Completed visits', color: '#2e725e' },
  { key: 'rescheduled', label: 'Rescheduled', color: '#567d98' },
  { key: 'canceled', label: 'Canceled', color: '#a54f3f' },
  { key: 'unknown', label: 'Unknown result', color: '#a1a99e' },
] as const

export function Leadership() {
  const [month, setMonth] = useState('')
  const result = useLoad<LeadershipData>(`/leadership_report${month ? `?month=${month}` : ''}`)
  const data = result.data
  return <>
    <Header><a href="#leadership" aria-current="page">Apex leadership</a></Header>
    <main className="page">
      <div className="page-title">
        <h1>Appointment outcomes</h1>
        <label>Outcome month<input type="month" value={month || data?.month || ''}
          onChange={(event) => { if (/^\d{4}-\d{2}$/.test(event.target.value)) setMonth(event.target.value) }} /></label>
      </div>
      <LoadStatus loading={result.loading} error={result.error} />
      {data && <>
        <section className="surface outcome-overview">
          <h2>{monthLabel(data.month)}</h2>
          <div className="outcomes-grid">
            {data.clinics.map((clinic) => <OutcomeCard key={clinic.name} name={clinic.name} totals={clinic.history[0]} />)}
          </div>
        </section>
        <section className="surface comparison">
          <h2>Clinic comparison</h2>
          <p className="muted">Completion rate uses PMS-completed visits divided by recorded visits. Staff-recorded cancellations and reschedules appear separately. The PMS does not identify no-shows in this dataset.</p>
          <div className="table-scroll"><table>
            <thead><tr><th>Clinic</th><th>Completion rate</th><th>Recorded visits</th><th>Rescheduled</th><th>Canceled</th><th>Unknown</th></tr></thead>
            <tbody>{data.clinics.map(({ name, history: [totals] }) => <tr key={name}>
              <td><strong>{name}</strong></td><td>{completionRate(totals.completed, totals.recorded)}</td>
              <td>{totals.recorded}</td><td>{totals.rescheduled}</td><td>{totals.canceled}</td><td>{totals.unknown}</td>
            </tr>)}</tbody>
          </table></div>
        </section>
        <details className="surface report-section"><summary>Monthly history and reminder activity</summary>
          <div className="table-scroll"><table>
            <thead><tr><th>Clinic</th><th>Month</th><th>Recorded visits</th><th>Completed</th><th>Fake sends</th><th>Failed attempts</th></tr></thead>
            <tbody>{data.clinics.flatMap((clinic) => clinic.history.map((entry) => <tr key={`${clinic.name}/${entry.month}`}>
              <td>{clinic.name}</td><td>{monthLabel(entry.month)}</td><td>{entry.recorded}</td>
              <td>{entry.completed}</td><td>{entry.sent}</td><td>{entry.failed}</td>
            </tr>))}</tbody>
          </table></div>
        </details>
        <details className="surface report-section"><summary>Contact holds</summary>
          <p className="muted">Counts contact-hold items opened during the selected month.</p>
          <div className="table-scroll"><table>
            <thead><tr><th>Clinic</th><th>Contact holds opened</th></tr></thead>
            <tbody>{data.clinics.map(({ name, history }) => <tr key={name}><td>{name}</td><td>{history[0].holds}</td></tr>)}</tbody>
          </table></div>
        </details>
        <details className="surface report-section"><summary>Contact and follow-up</summary>
          <p className="muted">Assigned items were opened in the selected month. Follow-ups count actions recorded during that month.</p>
          <div className="table-scroll"><table>
            <thead><tr><th>Clinic</th><th>Assigned items</th><th>Follow-up actions</th></tr></thead>
            <tbody>{data.clinics.map(({ name, history }) => <tr key={name}>
              <td>{name}</td><td>{history[0].assigned}</td><td>{history[0].follow_ups}</td>
            </tr>)}</tbody>
          </table></div>
        </details>
      </>}
    </main>
  </>
}

function OutcomeCard({ name, totals }: { name: string; totals: MonthlySummary }) {
  return <article className="outcome-card">
    <div className="outcome-heading"><h3>{name}</h3><small>{totals.recorded} recorded visits</small></div>
    <div className="outcome-bar" aria-hidden="true">
      {outcomeFields.map(({ key, color }) => totals[key] > 0 &&
        <span key={key} style={{ flexGrow: totals[key], backgroundColor: color }} />)}
    </div>
    <div className="outcome-legend">
      {outcomeFields.map(({ key, label, color }) => <div key={key}>
        <small><span style={{ backgroundColor: color }} />{label}</small>
        <strong>{totals[key]}</strong> <small>{completionRate(totals[key], totals.recorded)}</small>
      </div>)}
    </div>
  </article>
}
