import { useEffect, useState } from 'react'

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  let response: Response
  try {
    response = await fetch(`/api${path}`, options)
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw error
    throw new Error('Connection interrupted. Check the connection and retry.', { cause: error })
  }
  const result = await response.json().catch(() => null)
  if (!response.ok || result === null) {
    throw new Error(typeof result?.error === 'string' ? result.error : 'Apex could not complete the request. Try again.')
  }
  return result
}

export function write<T>(path: string, method: 'POST' | 'PATCH', body: object = {}) {
  return api<T>(path, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
}

export function useLoad<T>(path: string | null) {
  const [result, setResult] = useState<{ path: string; data?: T; error?: string }>()
  const [revision, setRevision] = useState(0)

  useEffect(() => {
    if (!path) return
    const controller = new AbortController()
    api<T>(path, { signal: controller.signal }).then(
      (data) => { if (!controller.signal.aborted) setResult({ path, data }) },
      (error: Error) => {
        if (!controller.signal.aborted) {
          setResult((previous) => ({ path, data: previous?.path === path ? previous.data : undefined, error: error.message }))
        }
      },
    )
    return () => controller.abort()
  }, [path, revision])

  const current = result?.path === path ? result : undefined
  return {
    data: current?.data,
    error: current?.error,
    loading: Boolean(path && !current),
    reload: () => setRevision((value) => value + 1),
  }
}

export function useAction() {
  const [pending, setPending] = useState(false)
  const [error, setError] = useState('')
  async function run(action: () => Promise<void>) {
    setError('')
    setPending(true)
    try {
      await action()
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : 'Apex could not complete the request.')
    } finally {
      setPending(false)
    }
  }
  return { pending, error, run }
}
