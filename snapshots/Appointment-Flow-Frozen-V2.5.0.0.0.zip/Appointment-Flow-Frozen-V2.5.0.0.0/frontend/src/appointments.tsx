import { useState } from 'react'
import { useLoad } from './api'
import { addDays, shortDate, wallLabel, weekOf } from './dates'
import { LoadStatus, SyncLine, Tabs } from './shared'
import type { AppointmentData, DeskSession, Visit } from './types'

const filters = [
  { value: 'all', label: 'All appointments' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'unconfirmed', label: 'Unconfirmed' },
  { value: 'review', label: 'Replies to review' },
] as const
type Filter = typeof filters[number]['value']

function matches(visit: Visit, filter: Filter) {
  if (filter === 'all') return true
  if (filter === 'review') return visit.review
  return visit.state.toLowerCase() === filter
}

export function Appointments({ desk }: { desk: DeskSession }) {
  const [date, setDate] = useState(desk.today)
  const [filter, setFilter] = useState<Filter>('all')
  const result = useLoad<AppointmentData>(`/clinics/${desk.clinic.id}/appointments?date=${date}`)
  const visits = result.data?.visits || []
  const days = weekOf(date)
  const today = result.data?.today || desk.today

  return <>
    <div className="page-title">
      <div><p className="clinic-label">{desk.clinic.name}</p><h1>Appointments</h1></div>
      <a className="button" href="#desk">Open patient flow <span aria-hidden="true">→</span></a>
    </div>
    {result.data && <SyncLine clinic={desk.clinic} data={result.data} />}
    <div className="surface calendar">
      <div className="calendar-controls">
        <div className="button-row">
          <button className="button" onClick={() => setDate(addDays(date, -7))}>← Previous week</button>
          <button className="button" onClick={() => setDate(today)}>Today</button>
          <button className="button" onClick={() => setDate(addDays(date, 7))}>Next week →</button>
        </div>
        <label>Jump to date<input type="date" min="1900-01-01" max="9999-12-31" value={date}
          onChange={(event) => { if (/^\d{4}-\d{2}-\d{2}$/.test(event.target.value)) setDate(event.target.value) }} /></label>
      </div>
      <div className="calendar-days">
        {days.map((day) => <button className="button" key={day} aria-pressed={day === date} onClick={() => setDate(day)}>
          <strong>{shortDate(day)}</strong>
          {result.data && <small>{result.data.counts[day] || 0} visits</small>}
        </button>)}
      </div>
    </div>
    <Tabs tabs={filters.map((entry) => ({ ...entry, label: result.data
      ? `${entry.label} · ${visits.filter((visit) => matches(visit, entry.value)).length}` : entry.label }))}
      selected={filter} select={setFilter} />
    <LoadStatus loading={result.loading} error={result.error} />
    {result.data && <VisitTable visits={visits.filter((visit) => matches(visit, filter))} />}
  </>
}

export function VisitTable({ visits, showPatient = true }: { visits: Visit[]; showPatient?: boolean }) {
  if (!visits.length) return <div className="surface empty">No appointments match this view.</div>
  return <div className="surface table-scroll">
    <table>
      <thead><tr>{showPatient && <th>Patient</th>}<th>Appointment · local time</th><th>Confirmation</th><th>Visit outcome</th></tr></thead>
      <tbody>{visits.map((visit) => <tr key={visit.id}>
        {showPatient && <td><a href={`#desk/patients/${visit.patient_id}`}>{visit.patient}</a></td>}
        <td><strong>{wallLabel(visit.wall_start)}</strong><small>{[visit.provider, visit.minutes ? `${visit.minutes} min` : null].filter(Boolean).join(' · ')}</small></td>
        <td><span className={`pill ${visit.review ? 'reply_review' : visit.state.toLowerCase()}`}>{visit.review ? 'Reply needs review' : visit.state}</span>
          {visit.review && <small>{visit.state}</small>}</td>
        <td>{visit.outcome}<small>{visit.source_status.replaceAll('_', ' ')}</small></td>
      </tr>)}</tbody>
    </table>
  </div>
}
