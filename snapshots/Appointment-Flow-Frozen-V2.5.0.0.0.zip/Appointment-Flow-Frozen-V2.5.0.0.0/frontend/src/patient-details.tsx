import { useState } from 'react'
import { useAction, useLoad, write } from './api'
import { VisitTable } from './appointments'
import { localTimestamp, wallLabel } from './dates'
import { Alert, issueLabels, LoadStatus, SyncLine, Tabs } from './shared'
import type { CaseItem, Contact, ContactField, DeskSession, PatientData } from './types'

const contactLabels: Record<ContactField, string> = { birthdate: 'Birthdate', phone: 'Mobile phone', email: 'Email', language: 'Preferred language' }
const contactFields: ContactField[] = ['birthdate', 'phone', 'email', 'language']
const detailTabs = [{ value: 'follow-up', label: 'Follow-up' }, { value: 'visits', label: 'Appointments' }, { value: 'activity', label: 'Activity log' }] as const
const outcomes = [
  { value: 'attempted', label: 'Contact attempted' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'rescheduled', label: 'Rescheduled' },
  { value: 'canceled', label: 'Canceled' },
  { value: 'reviewed', label: 'Reviewed without changing an appointment' },
]

export function PatientDetails({ desk, patientId }: { desk: DeskSession; patientId: string }) {
  const [tab, setTab] = useState<typeof detailTabs[number]['value']>('follow-up')
  const base = `/clinics/${desk.clinic.id}`
  const path = `${base}/patients/${patientId}`
  const patient = useLoad<PatientData>(path)
  const data = patient.data
  const open = data?.items.filter((item) => item.status !== 'Resolved') || []
  const resolved = data?.items.filter((item) => item.status === 'Resolved') || []
  const next = data?.visits.filter((visit) => visit.upcoming).at(-1)

  return <>
    <a className="back-link" href="#desk">← Patient flow</a>
    <LoadStatus loading={patient.loading} error={patient.error} />
    {data && <>
      <div className="page-title">
        <div><p className="clinic-label">{desk.clinic.name}</p><h1>{data.patient.name}</h1></div>
        <span className={`pill ${open.length ? 'no_confirmation' : 'confirmed'}`}>{open.length ? `${open.length} open follow-up ${open.length === 1 ? 'item' : 'items'}` : 'No open follow-up'}</span>
      </div>
      <SyncLine clinic={desk.clinic} data={data} />
      <section className="appointment-strip">
        <strong>Next scheduled appointment</strong>
        <span>{next ? `${wallLabel(next.wall_start)} · ${next.state}` : 'No upcoming appointment recorded.'}</span>
      </section>
      <div className="details-grid">
        <aside className="surface contacts">
          <h2>Patient details</h2>
          {contactFields.map((field) => <ContactEditor key={field} field={field} contact={data.contacts[field]}
            path={`${path}/contact_verifications/${field}`} onSaved={patient.reload} />)}
        </aside>
        <div className="detail-content">
          <Tabs tabs={detailTabs.map((entry) => ({ ...entry, label: entry.value === 'follow-up' ? `Follow-up · ${open.length}` : entry.label }))}
            selected={tab} select={setTab} />
          {tab === 'follow-up' && <section className="surface follow-up">
            <h2>Follow-up items</h2>
            {open.length === 0 && <p className="muted">No open follow-up items.</p>}
            {open.map((item) => <FollowUp key={item.id} item={item} desk={desk} base={base} onSaved={patient.reload} />)}
            <details><summary>Resolved follow-up records ({resolved.length})</summary>
              {resolved.length === 0 && <p className="muted">No resolved items.</p>}
              {resolved.map((item) => <div className="resolved-record" key={item.id}>
                <strong>{issueLabels[item.kind]}</strong><p>{item.reason}</p><small>{item.assignee || 'Automatically closed'}</small>
              </div>)}
            </details>
          </section>}
          {tab === 'visits' && <VisitTable visits={data.visits} showPatient={false} />}
          {tab === 'activity' && <section className="surface follow-up">
            <h2>Activity log</h2>
            {!data.activity.length && <p className="muted">No staff activity recorded.</p>}
            {data.activity.map((entry, index) => <div className="resolved-record" key={`${entry.occurred_at}/${index}`}>
              <strong>{outcomes.find((outcome) => outcome.value === entry.outcome)?.label || 'Contact verified'}</strong>
              <p>{entry.note}</p><small>{entry.staff} · {localTimestamp(entry.occurred_at, desk.clinic.timezone)}</small>
            </div>)}
          </section>}
        </div>
      </div>
    </>}
  </>
}

function ContactEditor({ field, contact, path, onSaved }: { field: ContactField; contact: Contact; path: string; onSaved: () => void }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState('')
  const action = useAction()
  const value = field === 'language' ? ({ en: 'English', es: 'Spanish' }[contact.value || ''] || contact.value) : contact.value
  return <div className="contact-row">
    <div className="contact-title">
      <span>{contactLabels[field]}</span>
      {!editing && <button type="button" className="text-button" onClick={() => { setDraft(contact.value || ''); setEditing(true) }}
        aria-label={`Edit ${contactLabels[field].toLowerCase()}`}>Edit</button>}
    </div>
    <strong>{value || 'No value on file'}</strong>
    <span className={`pill ${contact.conflict ? 'contact_hold' : contact.verified ? 'confirmed' : 'unconfirmed'}`}>
      {contact.conflict ? 'PMS conflict' : contact.verified ? 'Verified locally' : 'Not verified'}
    </span>
    {contact.conflict && <small>PMS value {contact.source || 'missing'}</small>}
    {editing && <form className="inline-form" onSubmit={(event) => {
      event.preventDefault()
      void action.run(async () => {
        await write(path, 'PATCH', { value: draft })
        setEditing(false)
        onSaved()
      })
    }}>
      <label>Verified {contactLabels[field].toLowerCase()}
        {field === 'language' ? <select value={draft} onChange={(event) => setDraft(event.target.value)} required>
          <option value="">Choose a language</option><option value="en">English</option><option value="es">Spanish</option>
        </select> : <input type={field === 'birthdate' ? 'date' : field === 'phone' ? 'tel' : 'email'}
          value={draft} onChange={(event) => setDraft(event.target.value)} required />}
      </label>
      <Alert>{action.error}</Alert>
      <div className="button-row"><button className="button primary" disabled={action.pending}>Save</button>
        <button className="button" type="button" onClick={() => setEditing(false)} disabled={action.pending}>Cancel</button></div>
    </form>}
  </div>
}

function FollowUp({ item, desk, base, onSaved }: { item: CaseItem; desk: DeskSession; base: string; onSaved: () => void }) {
  const [outcome, setOutcome] = useState('attempted')
  const [note, setNote] = useState('')
  const [visitId, setVisitId] = useState('')
  const [eventId, setEventId] = useState(() => crypto.randomUUID())
  const [saved, setSaved] = useState(false)
  const action = useAction()
  const review = item.kind === 'reply_review'
  const candidates = item.candidates.filter((candidate) => candidate.current)
  const needsVisit = review && ['confirmed', 'canceled', 'rescheduled'].includes(outcome)
  const path = `${base}/work_items/${item.id}`
  const availableOutcomes = outcomes.filter(({ value }) => {
    if (value === 'reviewed') return review
    return !review || candidates.length > 0 || value === 'attempted'
  })
  function edit() { setEventId(crypto.randomUUID()); setSaved(false) }

  return <article className="follow-up-item">
    <div className="follow-up-heading">
      <span className={`pill ${item.kind}`}>{issueLabels[item.kind]}</span>
      <small>{item.assignee || 'Unassigned'}</small>
    </div>
    <p>{item.reason}</p>
    {item.wall_start && <small>{wallLabel(item.wall_start)}</small>}
    {item.reply && <blockquote><small>{item.reply.channel === 'sms' ? 'Text message' : 'Email'} · {localTimestamp(item.reply.occurred_at, desk.clinic.timezone)}</small>{item.reply.body}</blockquote>}
    {action.error && <Alert>{action.error}</Alert>}
    {saved && <Alert status>Follow-up recorded.</Alert>}
    {!item.assignee_id && <button className="button primary" disabled={action.pending} onClick={() => {
      void action.run(async () => { await write(path, 'PATCH'); onSaved() })
    }}>Assign to me</button>}
    {item.assignee_id === desk.staff.id && <form className="inline-form" onSubmit={(event) => {
      event.preventDefault()
      void action.run(async () => {
        await write(`${path}/follow_ups`, 'POST', { outcome, note, visit_id: needsVisit ? visitId : null, event_id: eventId })
        setNote('')
        setEventId(crypto.randomUUID())
        setSaved(true)
        onSaved()
      })
    }}>
      <label>Outcome<select value={outcome} onChange={(event) => { setOutcome(event.target.value); edit() }}>
        {availableOutcomes.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      </select></label>
      {needsVisit && <label>Clarified appointment<select required value={visitId} onChange={(event) => { setVisitId(event.target.value); edit() }}>
        <option value="">Choose the appointment discussed</option>
        {candidates.map((candidate) => <option key={candidate.id} value={candidate.id}>{candidate.patient} · {wallLabel(candidate.wall_start)}</option>)}
      </select></label>}
      <label>Follow-up note<textarea required maxLength={1000} rows={3} value={note}
        onChange={(event) => { setNote(event.target.value); edit() }} /></label>
      <button className="button primary" disabled={action.pending || !note.trim()}>{action.pending ? 'Saving…' : 'Record follow-up'}</button>
    </form>}
  </article>
}
