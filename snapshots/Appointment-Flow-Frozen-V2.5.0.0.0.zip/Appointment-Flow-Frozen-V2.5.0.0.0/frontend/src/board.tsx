import { useState } from 'react'
import { useAction, useLoad, write } from './api'
import { wallLabel } from './dates'
import { Alert, issueLabels, LoadStatus, SyncLine, Tabs } from './shared'
import type { BoardData, DeskSession, Lane, LaneName } from './types'

const laneLabels: Record<LaneName, string> = { attention: 'Needs attention', progress: 'In progress', resolved: 'Resolved' }
const activeLanes: LaneName[] = ['attention', 'progress']
const boardTabs = [{ value: 'active', label: 'Active work' }, { value: 'resolved', label: 'Resolved' }] as const

export function Board({ desk }: { desk: DeskSession }) {
  const [view, setView] = useState<'active' | 'resolved'>('active')
  const [search, setSearch] = useState('')
  const [kind, setKind] = useState('')
  const [pages, setPages] = useState<Partial<Record<LaneName, number>>>({})
  const [notice, setNotice] = useState('')
  const action = useAction()
  const base = `/clinics/${desk.clinic.id}`
  const query = new URLSearchParams({ search, kind })
  for (const [lane, page] of Object.entries(pages)) query.set(`${lane}_page`, String(page))
  const board = useLoad<BoardData>(`${base}/work_items?${query}`)
  const data = board.data

  function runBatch() {
    setNotice('')
    void action.run(async () => {
      try {
        const result = await write<{ sent: number; failed: number }>(`${base}/reminder_batch`, 'POST')
        setNotice(`Reminder run finished. ${result.sent} sent, ${result.failed} failed.`)
      } finally {
        board.reload()
      }
    })
  }

  return <>
    <div className="page-title">
      <div><p className="clinic-label">{desk.clinic.name}</p><h1>Patient flow</h1></div>
      <div className="desk-meta"><strong>{desk.staff.name}</strong><small>Front desk</small></div>
    </div>
    {data && <SyncLine clinic={desk.clinic} data={data} />}
    <Alert>{action.error}</Alert>
    <Alert status>{notice}</Alert>
    {data && <div className="summary-grid">
      {(Object.keys(laneLabels) as LaneName[]).map((name) => <button key={name} className="surface summary-card"
        onClick={() => setView(name === 'resolved' ? 'resolved' : 'active')}>
        <span>{laneLabels[name]}</span><strong>{data.counts[name]}</strong>
      </button>)}
    </div>}
    <div className="board-controls">
      <Tabs tabs={[...boardTabs]} selected={view} select={setView} />
      <div className="button-row">
        <button className="button" disabled={action.pending} onClick={() => {
          setNotice('')
          void action.run(async () => {
            try {
              await write(`${base}/pms_refresh`, 'POST')
              setNotice('PMS refresh complete.')
            } finally {
              board.reload()
            }
          })
        }}>Refresh PMS</button>
        <button className="button primary" disabled={action.pending} onClick={runBatch}>Run reminders</button>
      </div>
    </div>
    <div className="board-filters">
      <label>Follow-up type<select value={kind} onChange={(event) => { setKind(event.target.value); setPages({}) }}>
        <option value="">All types</option>
        {Object.entries(issueLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
      </select></label>
      <label>Patient search<input type="search" placeholder="Search patients" value={search}
        onChange={(event) => { setSearch(event.target.value); setPages({}) }} /></label>
    </div>
    <LoadStatus loading={board.loading} error={board.error} />
    {data && <div className={view === 'active' ? 'board-grid' : 'board-grid single'}>
      {(view === 'active' ? activeLanes : ['resolved' as const]).map((name) => <WorkLane key={name} lane={data.lanes[name]}
        name={name} onPage={(page) => setPages({ ...pages, [name]: page })} />)}
    </div>}
  </>
}

function WorkLane({ lane, name, onPage }: { lane: Lane; name: LaneName; onPage: (page: number) => void }) {
  return <section className={`lane lane-${name}`}>
    <div className="lane-heading"><h2><span aria-hidden="true" />{laneLabels[name]}</h2><strong>{lane.total}</strong></div>
    {lane.total === 0 && <p className="muted">No matching follow-up items.</p>}
    {lane.items.map((item) => <a className="work-card" key={item.id} href={`#desk/patients/${item.patient_id}`}>
      <span className={`pill ${item.kind}`}>{issueLabels[item.kind] || item.kind}</span>
      <strong>{item.patient} <span aria-hidden="true">↗</span></strong>
      <p>{item.reason}</p>
      <small>{item.wall_start ? wallLabel(item.wall_start) : 'Appointment to review'} · {item.assignee || 'Unassigned'}</small>
    </a>)}
    {lane.total > lane.size && <div className="pagination">
      <button className="button" disabled={lane.page === 1} onClick={() => onPage(lane.page - 1)}>Previous</button>
      <small>Page {lane.page} of {Math.ceil(lane.total / lane.size)}</small>
      <button className="button" disabled={lane.page * lane.size >= lane.total} onClick={() => onPage(lane.page + 1)}>Next</button>
    </div>}
  </section>
}
