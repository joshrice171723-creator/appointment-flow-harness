import type { ReactNode } from 'react'
import { localTimestamp } from './dates'
import type { Clinic, SyncStatus } from './types'

export const issueLabels: Record<string, string> = {
  no_confirmation: 'Confirmation needed',
  contact_hold: 'Reminders blocked',
  delivery_failed: 'Delivery failed',
  reply_review: 'Reply needs review',
}

export function Header({ children }: { children?: ReactNode }) {
  return <header className="topbar">
    <a className="brand" href="#" aria-label="Apex workspaces">
      <span className="brand-mark" aria-hidden="true">A<span>+</span></span>
      <span><strong>APEX</strong><small>APPOINTMENT FLOW</small></span>
    </a>
    <nav aria-label="Main navigation">{children}<a href="#">Workspaces <span aria-hidden="true">↗</span></a></nav>
  </header>
}

export function Alert({ children, status = false }: { children: ReactNode; status?: boolean }) {
  return children ? <p className={status ? 'notice success' : 'notice error'} role={status ? 'status' : 'alert'}>{children}</p> : null
}

export function LoadStatus({ loading, error }: { loading: boolean; error?: string }) {
  if (error) return <Alert>{error}</Alert>
  return loading ? <p className="muted" role="status">Loading…</p> : null
}

export function SyncLine({ clinic, data }: { clinic: Clinic; data: SyncStatus }) {
  return <>
    <p className="sync-line">Last PMS sync {data.synced_at ? localTimestamp(data.synced_at, clinic.timezone) : 'Unavailable'} · {clinic.timezone}</p>
    <Alert>{data.source_error}</Alert>
  </>
}

export function Tabs<T extends string>({ tabs, selected, select }: {
  tabs: { value: T; label: string }[]; selected: T; select: (value: T) => void
}) {
  return <div className="tabs">
    {tabs.map(({ value, label }) => <button key={value} type="button" className="tab"
      aria-pressed={selected === value} onClick={() => select(value)}>{label}</button>)}
  </div>
}
