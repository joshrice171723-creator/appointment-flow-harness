export type Staff = { id: number; name: string }
export type Clinic = { id: number; name: string; timezone: string }
export type WorkspaceClinic = Clinic & { staff: Staff[] }
export type DeskSession = { clinic: Clinic; staff: Staff; today: string }
export type SyncStatus = { synced_at: string | null; source_error: string | null; today: string }
export type Channel = 'sms' | 'email'
export type Person = { id: number; name: string }

export type WorkItem = {
  id: number
  patient_id: number
  patient: string
  kind: string
  reason: string
  wall_start: string | null
  status: 'Needs attention' | 'In progress' | 'Resolved'
  assignee_id: number | null
  assignee: string | null
  opened_at: string
}

export type LaneName = 'attention' | 'progress' | 'resolved'
export type Lane = { page: number; size: number; total: number; items: WorkItem[] }
export type BoardData = SyncStatus & {
  counts: Record<LaneName, number>
  lanes: Record<LaneName, Lane>
}

export type Visit = {
  id: number
  patient_id: number
  patient: string
  wall_start: string
  provider: string | null
  minutes: number | null
  outcome: string
  source_status: string
  state: 'Confirmed' | 'Unconfirmed'
  review: boolean
  upcoming: boolean
}

export type AppointmentData = SyncStatus & { counts: Record<string, number>; visits: Visit[] }

export type CaseItem = WorkItem & {
  reply: { body: string; channel: Channel; occurred_at: string } | null
  candidates: { id: number; patient: string; wall_start: string; current: boolean }[]
}
export type Contact = { value: string | null; verified: boolean; conflict: boolean; source: string | null }
export type ContactField = 'birthdate' | 'phone' | 'email' | 'language'
export type PatientData = SyncStatus & {
  patient: Person
  contacts: Record<ContactField, Contact>
  visits: Visit[]
  items: CaseItem[]
  activity: { outcome: string; note: string; occurred_at: string; staff: string }[]
}

export type InboxMessage = {
  id: string
  direction: 'outgoing' | 'incoming'
  channel: Channel
  body: string
  occurred_at: string
}

export type MonthlySummary = {
  month: string
  recorded: number
  completed: number
  rescheduled: number
  canceled: number
  unknown: number
  sent: number
  failed: number
  holds: number
  assigned: number
  follow_ups: number
}

export type LeadershipData = { month: string; current_month: string; clinics: { name: string; history: MonthlySummary[] }[] }
