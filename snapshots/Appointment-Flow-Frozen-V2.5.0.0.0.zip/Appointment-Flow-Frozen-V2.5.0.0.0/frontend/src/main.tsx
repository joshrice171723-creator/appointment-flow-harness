import { StrictMode, useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource/dm-sans/400.css'
import '@fontsource/dm-sans/500.css'
import '@fontsource/dm-sans/600.css'
import '@fontsource/dm-sans/700.css'
import '@fontsource/instrument-serif/400.css'
import { useAction, useLoad, write } from './api'
import { Appointments } from './appointments'
import { Board } from './board'
import { Inbox } from './inbox'
import { Leadership } from './leadership'
import { PatientDetails } from './patient-details'
import { Alert, Header, LoadStatus } from './shared'
import type { DeskSession, WorkspaceClinic } from './types'
import './styles.css'

const readRoute = () => window.location.hash.slice(1)

function App() {
  const [route, setRoute] = useState(readRoute)
  const [desk, setDesk] = useState<DeskSession | null>(() => {
    try {
      return JSON.parse(sessionStorage.getItem('apex-desk') || 'null')
    } catch {
      return null
    }
  })
  useEffect(() => {
    const update = () => setRoute(readRoute())
    window.addEventListener('hashchange', update)
    return () => window.removeEventListener('hashchange', update)
  }, [])

  if (route === 'inbox') return <Inbox />
  if (route === 'leadership') return <Leadership />
  if (route.startsWith('desk') && desk) {
    const patientId = route.match(/^desk\/patients\/(\d+)$/)?.[1]
    return <>
      <Header>
        <a href="#desk" aria-current={route === 'desk' ? 'page' : undefined}>Patient flow</a>
        <a href="#desk/appointments" aria-current={route === 'desk/appointments' ? 'page' : undefined}>Appointments</a>
      </Header>
      <main className="page" key={`${desk.clinic.id}/${route}`}>
        {patientId ? <PatientDetails desk={desk} patientId={patientId} />
          : route === 'desk/appointments' ? <Appointments desk={desk} />
          : <Board desk={desk} />}
      </main>
    </>
  }
  return <WorkspaceEntry onEnter={(next) => {
    sessionStorage.setItem('apex-desk', JSON.stringify(next))
    setDesk(next)
    window.location.hash = 'desk'
  }} />
}

function WorkspaceEntry({ onEnter }: { onEnter: (next: DeskSession) => void }) {
  const workspaces = useLoad<{ clinics: WorkspaceClinic[] }>('/workspaces')
  const [clinicId, setClinicId] = useState<number>()
  const [staffId, setStaffId] = useState<number>()
  const action = useAction()
  const clinics = workspaces.data?.clinics || []
  const clinic = clinics.find((entry) => entry.id === clinicId) || clinics[0]
  const staff = clinic?.staff.find((entry) => entry.id === staffId) || clinic?.staff[0]

  return <>
    <Header />
    <main className="page landing">
      <h1>Workspaces</h1>
      <LoadStatus loading={workspaces.loading} error={workspaces.error} />
      <div className="workspace-grid">
        <form className="surface workspace-card" onSubmit={(event) => {
          event.preventDefault()
          if (!clinic || !staff) return
          void action.run(async () => onEnter(await write<DeskSession>('/staff_session', 'POST', {
            clinic_id: clinic.id, staff_id: staff.id,
          })))
        }}>
          <h2>Front desk</h2>
          <p>Review appointments and follow up with patients.</p>
          <label>Clinic
            <select value={clinic?.id ?? ''} onChange={(event) => { setClinicId(Number(event.target.value)); setStaffId(undefined) }}>
              {!clinics.length && <option value="">No clinics available</option>}
              {clinics.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
            </select>
          </label>
          <label>Staff member <small>Demo sign-in</small>
            <select value={staff?.id ?? ''} onChange={(event) => setStaffId(Number(event.target.value))}>
              {!clinic?.staff.length && <option value="">No staff available</option>}
              {clinic?.staff.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
            </select>
          </label>
          <Alert>{action.error}</Alert>
          <button className="button primary" disabled={!staff || action.pending}>{action.pending ? 'Opening…' : 'Open front desk'} <span aria-hidden="true">→</span></button>
        </form>
        <section className="surface workspace-card leadership-card">
          <h2>Apex leadership</h2>
          <p>Compare aggregate appointment outcomes by clinic.</p>
          {workspaces.data && <div className="clinic-count"><strong>{clinics.length}</strong><span>Reporting clinics</span></div>}
          <a className="button primary" href="#leadership">Open Apex leadership <span aria-hidden="true">→</span></a>
        </section>
        <section className="surface workspace-card">
          <h2>Patient</h2>
          <p>Read simulated messages and reply from a fictional patient’s inbox.</p>
          <a className="button primary" href="#inbox">Open patient inbox <span aria-hidden="true">→</span></a>
        </section>
      </div>
    </main>
  </>
}

const root = document.getElementById('root')
if (!root) throw new Error('The Apex application root is missing.')
createRoot(root).render(<StrictMode><App /></StrictMode>)
