import { useState } from 'react'
import { useAction, useLoad, write } from './api'
import { localTimestamp } from './dates'
import { Alert, LoadStatus, Tabs } from './shared'
import type { Channel, InboxMessage, Person, WorkspaceClinic } from './types'

const channels: { value: Channel; label: string }[] = [{ value: 'sms', label: 'Text messages' }, { value: 'email', label: 'Email' }]
const outcomes: Record<string, string> = {
  confirmed: 'Reply recorded. The appointment is confirmed.',
  opted_out: 'Reply recorded. Text messages to this number are stopped for this clinic.',
  review: 'Reply recorded for front-desk review.',
}

export function Inbox() {
  const workspaces = useLoad<{ clinics: WorkspaceClinic[] }>('/workspaces')
  const [clinicId, setClinicId] = useState('')
  const clinic = workspaces.data?.clinics.find((entry) => String(entry.id) === clinicId)

  return <main className="inbox page">
    <a className="back-link" href="#"><span aria-hidden="true">←</span> Workspaces</a>
    <h1>Patient inbox</h1>
    <LoadStatus loading={workspaces.loading} error={workspaces.error} />
    <label>Clinic<select value={clinicId} onChange={(event) => setClinicId(event.target.value)}>
      <option value="">Choose a clinic</option>
      {workspaces.data?.clinics.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
    </select></label>
    {clinic && <ClinicInbox key={clinic.id} clinic={clinic} />}
  </main>
}

function ClinicInbox({ clinic }: { clinic: WorkspaceClinic }) {
  const [patientId, setPatientId] = useState('')
  const path = `/demo_clinics/${clinic.id}/patients`
  const patients = useLoad<{ patients: Person[] }>(path)
  return <>
    <LoadStatus loading={patients.loading} error={patients.error} />
    <label>Patient<select value={patientId} onChange={(event) => setPatientId(event.target.value)}>
      <option value="">Choose a fictional patient</option>
      {patients.data?.patients.map((patient) => <option key={patient.id} value={patient.id}>{patient.name}</option>)}
    </select></label>
    {patientId && <Conversation key={patientId} path={`${path}/${patientId}`} zone={clinic.timezone} />}
  </>
}

function Conversation({ path, zone }: { path: string; zone: string }) {
  const [channel, setChannel] = useState<Channel>('sms')
  const result = useLoad<{ messages: InboxMessage[] }>(path)
  const messages = result.data?.messages.filter((message) => message.channel === channel) || []
  return <>
    <Tabs tabs={channels} selected={channel} select={setChannel} />
    <LoadStatus loading={result.loading} error={result.error} />
    {result.data && <>
      {messages.length > 0
        ? <section className="conversation"><h2>Message history</h2>
          {messages.map((message) => <article className={`message ${message.direction}`} key={message.id}>
            <small>{message.direction === 'outgoing' ? 'Clinic reminder' : 'Your reply'} · {localTimestamp(message.occurred_at, zone)}</small>
            <p>{message.body}</p>
          </article>)}
        </section>
        : <p>No simulated {channel === 'sms' ? 'text messages' : 'emails'} for this patient yet.</p>}
      <ReplyForm key={channel} path={path} channel={channel} onSent={result.reload} />
    </>}
  </>
}

function ReplyForm({ path, channel, onSent }: { path: string; channel: Channel; onSent: () => void }) {
  const action = useAction()
  const [body, setBody] = useState('')
  const [eventId, setEventId] = useState(() => crypto.randomUUID())
  const [notice, setNotice] = useState('')

  return <form className="surface reply-form" onSubmit={(event) => {
    event.preventDefault()
    setNotice('')
    void action.run(async () => {
      const reply = await write<{ outcome: string }>(`${path}/replies`, 'POST', { body, channel, event_id: eventId })
      setNotice(outcomes[reply.outcome])
      setBody('')
      setEventId(crypto.randomUUID())
      onSent()
    })
  }}>
    <label>Your reply<textarea rows={3} required maxLength={500} placeholder="Type a simulated reply" value={body}
      onChange={(event) => { setBody(event.target.value); setEventId(crypto.randomUUID()); setNotice('') }} /></label>
    <Alert>{action.error}</Alert>
    <Alert status>{notice}</Alert>
    <button className="button primary" disabled={action.pending || !body.trim()}>{action.pending ? 'Sending…' : 'Send reply'}</button>
  </form>
}
