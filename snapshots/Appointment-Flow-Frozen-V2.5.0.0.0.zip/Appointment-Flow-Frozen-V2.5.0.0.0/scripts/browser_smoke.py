"""Run browser smoke tests against a new disposable local database."""

import os
from pathlib import Path
import subprocess
import uuid

ROOT = Path(__file__).resolve().parents[1]


def main():
    env = {
        **os.environ,
        "RAILS_ENV": "development",
        "SKIP_TEST_DATABASE": "1",
        "APEX_DEV_DB": f"apex_cleanroom_browser_{uuid.uuid4().hex[:12]}",
        "APEX_DEMO_NOW": "2026-11-16T17:00:00Z",
    }
    env.pop("DATABASE_URL", None)
    env.pop("PRIMARY_DATABASE_URL", None)
    env.pop("PMS_READER_DATABASE_URL", None)
    for name, default in {"PGHOST": "127.0.0.1", "PGPORT": "5432", "PGUSER": "postgres"}.items():
        env.setdefault(name, default)
    env["PIDFILE"] = str(ROOT / "backend" / "tmp" / "pids" / f'{env["APEX_DEV_DB"]}.pid')
    rails = ["ruby", "bin/rails"]
    database = env["APEX_DEV_DB"]

    subprocess.run(["createdb", database], env=env, check=True)
    try:
        subprocess.run([*rails, "db:prepare"], cwd=ROOT / "backend", env=env, check=True)
        subprocess.run(
            ["node", "node_modules/@playwright/test/cli.js", "test"],
            cwd=ROOT / "frontend", env=env, check=True,
        )
    finally:
        subprocess.run(["dropdb", database], env=env, check=True)


if __name__ == "__main__":
    main()
