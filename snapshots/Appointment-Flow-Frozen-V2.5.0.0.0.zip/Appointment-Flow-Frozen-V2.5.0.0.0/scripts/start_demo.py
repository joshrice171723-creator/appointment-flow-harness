"""Prepare the fictional demo and start Rails and Vite on loopback."""

import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    env = {**os.environ, "RAILS_ENV": "development", "SKIP_TEST_DATABASE": "1"}
    env.setdefault("APEX_DEMO_NOW", "2026-11-16T17:00:00Z")
    api_port = env.get("APEX_API_PORT", "3000")
    web_port = env.get("APEX_WEB_PORT", "5173")
    env["APEX_API_TARGET"] = f"http://127.0.0.1:{api_port}"
    rails = ["ruby", "bin/rails"]
    subprocess.run([*rails, "db:prepare"], cwd=ROOT / "backend", env=env, check=True)
    server = subprocess.Popen(
        [*rails, "server", "-b", "127.0.0.1", "-p", api_port],
        cwd=ROOT / "backend", env=env,
    )
    try:
        return subprocess.call(
            ["node", "node_modules/vite/bin/vite.js", "--host", "127.0.0.1", "--port", web_port],
            cwd=ROOT / "frontend", env=env,
        )
    except KeyboardInterrupt:
        return 0
    finally:
        server.terminate()
        server.wait(timeout=10)


if __name__ == "__main__":
    raise SystemExit(main())
