# Architecture

```mermaid
flowchart LR
    Vite["React workspaces"] --> Rails["Rails JSON endpoints"]
    Rails --> Batch["PMS refresh and reminder batch"]
    Rails --> Reply["Reply intake"]
    Rails --> Staff["Staff tasks and contact verification"]
    Rails --> Report["Aggregate SQL reporting"]
    Batch --> Reader["Read-only Rails connection"]
    Reply --> Reader
    Staff --> Reader
    Reader --> PMS["PostgreSQL pms schema"]
    Batch --> Fake["Local fake SMS and email"]
    Fake --> Batch
    Batch --> Store["PostgreSQL public schema"]
    Reply --> Store
    Staff --> Store
    Report --> Store
```

`PmsSync` reads a clinic snapshot in a repeatable-read transaction through a dedicated Rails reading role and a PostgreSQL read-only connection. The demo fixture writer is in `backend/db` and runs during seeding or tests. Raw contact values are retained alongside local verifications. An invalid or overlapping DST wall time creates a hold.

The clinic row lock serializes local refresh, sending, inbox replies and staff writes within one clinic. A batch refreshes before choosing candidates. It aborts sending when the source fails. A vanished visit is held for staff. The fake adapter has no external side effect, so its local delivery record and related case updates commit together. Unique keys enforce one delivery per visit, revision and step, and one business effect per inbound or follow-up event.

```mermaid
stateDiagram-v2
    [*] --> Unconfirmed: Current scheduled visit
    Unconfirmed --> Confirmed: Matched affirmative reply or staff confirmation
    Unconfirmed --> Unconfirmed: Review case opened
    Confirmed --> Confirmed: Later conflicting reply opens review
    Confirmed --> Unconfirmed: PMS changes time, status or patient
    Unconfirmed --> Closed: Staff records cancellation/reschedule or source visit ends
    Confirmed --> Closed: Staff records cancellation/reschedule or source visit ends
    Closed --> Unconfirmed: Visit becomes scheduled on a new revision
```

Delivery and confirmation state live separately. Intake matches the normalized sender and clinic against recent sent confirmation requests. An older request for the same visit also creates ambiguity across revisions. Multiple candidates, uncertain contacts and replies after start go to staff review. An exact SMS STOP records suppression for the clinic and number. Staff can confirm only the current revision when clarifying an ambiguous reply.

Leadership reads explicit counts. Clinic outcomes use local visit dates. Reminder attempts and follow-up activity use clinic-local month boundaries around UTC instants.
