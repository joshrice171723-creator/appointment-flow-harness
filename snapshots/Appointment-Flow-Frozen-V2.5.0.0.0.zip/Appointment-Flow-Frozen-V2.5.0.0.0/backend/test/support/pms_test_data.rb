require Rails.root.join("db/sample_pms")

module PmsTestData
  extend ActiveSupport::Concern

  NOW = Time.iso8601("2026-11-16T17:00:00Z")

  included do
    # The read connection sees committed source fixture changes, just like the runtime reader.
    self.use_transactional_tests = false

    setup do
      ApplicationRecord.with_connection do |db|
        db.execute("TRUNCATE clinics, pms.clinics, pms.patients RESTART IDENTITY CASCADE")
      end
      @austin = create_clinic(1, "Austin", "America/Chicago")
      @phoenix = create_clinic(2, "Phoenix", "America/Phoenix")
    end
  end

  def create_clinic(id, name, timezone)
    SamplePms.insert("pms.clinics", id: id, name: name)
    Clinic.create!(source_id: id, name: name, timezone: timezone)
  end

  def add_visit(id: 11, clinic: @austin, patient_id: 101, start: "2026-11-23 15:00:00",
                phone: "512-555-0101", email: "avery@example.test", birthdate: "1988-02-02", language: "en", status: "scheduled")
    SamplePms.insert("pms.patients", id: patient_id, first_name: "Demo", last_name: "Patient #{patient_id}",
      wireless_phone: phone, email: email, birthdate: birthdate, preferred_language: language)
    SamplePms.insert("pms.appointments", id: id, clinic_id: clinic.source_id, patient_id: patient_id, start_at: start,
      provider_name: "Dr. Example", status: status, length_minutes: 45)
  end

  def visit(id = 11, clinic: @austin)
    clinic.visits.find_by!(source_id: id)
  end

  def send_reply(body = "YES", now: NOW, event_id: SecureRandom.uuid, channel: "sms", patient: visit.patient)
    ReplyIntake.call(patient: patient, body: body, event_id: event_id, channel: channel, now: now)
  end

  def pms_sql(sql)
    ApplicationRecord.with_connection { |db| db.execute(sql) }
  end
end
