require "test_helper"

class ClinicTimeTest < ActiveSupport::TestCase
  test "wall time resolves per clinic and DST gaps and overlaps require review" do
    austin = Clinic.new(timezone: "America/Chicago")
    phoenix = Clinic.new(timezone: "America/Phoenix")

    assert_equal Time.utc(2026, 7, 1, 15), austin.source_time("2026-07-01T10:00:00")
    assert_equal Time.utc(2026, 7, 1, 17), phoenix.source_time("2026-07-01T10:00:00")
    assert_equal Time.utc(2026, 11, 16, 16), austin.source_time("2026-11-16T10:00:00")
    assert_nil austin.source_time("2026-03-08T02:30:00")
    assert_nil austin.source_time("2026-11-01T01:30:00")
  end

  test "an explicitly international number must carry the US country code to be textable" do
    assert_nil Patient.normalize_phone("+4420718387")
    assert_equal "+15125550101", Patient.normalize_phone("+1 (512) 555-0101")
  end
end
