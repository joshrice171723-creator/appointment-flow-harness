require "test_helper"

class WorkspacesTest < ActionDispatch::IntegrationTest
  include PmsTestData

  test "S10 staff session and nested resources enforce clinic scope" do
    add_visit
    add_visit(id: 12, clinic: @phoenix, patient_id: 102, start: "2026-11-17 15:00:00")
    ReminderBatch.call(@austin, now: NOW)
    ReminderBatch.call(@phoenix, now: NOW)
    staff = @austin.staff_members.create!(name: "Taylor")
    phoenix_patient = visit(12, clinic: @phoenix).patient
    foreign_item = @phoenix.work_items.find_by!(kind: "no_confirmation")

    get "/api/clinics/#{@austin.id}/appointments", params: { date: "2026-11-23" }
    assert_response :unauthorized
    post "/api/staff_session", params: { clinic_id: @phoenix.id, staff_id: staff.id }, as: :json
    assert_response :not_found
    post "/api/staff_session", params: { clinic_id: @austin.id, staff_id: staff.id }, as: :json
    assert_response :success

    get "/api/clinics/#{@phoenix.id}/work_items", as: :json
    assert_response :forbidden
    get "/api/clinics/#{@austin.id}/patients/#{phoenix_patient.id}", as: :json
    assert_response :not_found
    patch "/api/clinics/#{@austin.id}/work_items/#{foreign_item.id}", params: {}, as: :json
    assert_response :not_found
    assert_nil foreign_item.reload.assignee_id
    get "/api/demo_clinics/#{@austin.id}/patients/#{phoenix_patient.id}", as: :json
    assert_response :not_found

    get "/api/clinics/#{@austin.id}/appointments", params: { date: "2026-11-23" }
    assert_response :success
    assert_equal [ visit.patient.id ], response.parsed_body.fetch("visits").pluck("patient_id")
    assert_equal "no-store", response.headers["Cache-Control"]
  end

  test "S16 and S17 leadership only returns aggregate numbers and confirmed is distinct from completed" do
    add_visit
    add_visit(id: 12, patient_id: 102, status: "complete", phone: "512-555-0112")
    ReminderBatch.call(@austin, now: NOW)
    send_reply

    get "/api/leadership_report", params: { month: "2026-11" }

    assert_response :success
    clinics = response.parsed_body.fetch("clinics")
    assert_equal %w[Austin Phoenix], clinics.pluck("name")
    summary = clinics.first.fetch("history").first
    assert_equal 2, summary["recorded"]
    assert_equal 1, summary["completed"]
    assert_equal 1, summary["unknown"]
    assert_equal 1, summary["sent"]
    assert_equal %w[assigned canceled completed failed follow_ups holds month recorded rescheduled sent unknown], summary.keys.sort
    assert_not_includes response.body, visit.patient.name
    assert_not_includes response.body, "example.test"
    assert_not_includes response.body, "YES"
  end

  test "S20 email demo endpoint produces staff review and records the inbox event" do
    add_visit(phone: nil)
    ReminderBatch.call(@austin, now: NOW)
    patient = visit.patient
    path = "/api/demo_clinics/#{@austin.id}/patients/#{patient.id}"

    travel_to NOW do
      get path, as: :json
      assert_equal [ "email" ], response.parsed_body.fetch("messages").pluck("channel")

      post "#{path}/replies", params: { channel: "email", body: "Maybe", event_id: SecureRandom.uuid }, as: :json
      assert_response :success
      assert_equal "review", response.parsed_body.fetch("outcome")

      get path, as: :json
      assert_includes response.parsed_body.fetch("messages").pluck("body"), "Maybe"
      assert @austin.work_items.open.exists?(kind: "reply_review", patient_id: patient.id)
    end
  end
end
