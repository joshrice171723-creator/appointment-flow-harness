require "test_helper"

class ReminderWorkflowTest < ActiveSupport::TestCase
  include PmsTestData

  test "S01 confirms by SMS once, skips confirmation nudges and sends an informational final" do
    add_visit
    assert_equal({ sent: 1, failed: 0 }, ReminderBatch.call(@austin, now: NOW))
    assert_equal "sms", visit.deliveries.first.channel
    event = SecureRandom.uuid
    assert_equal "confirmed", send_reply(" yes ", event_id: event).outcome
    assert_no_difference(-> { @austin.replies.count }) { send_reply(" yes ", event_id: event) }
    assert_equal "YES", visit.deliveries.first.body[/YES/]
    assert_equal NOW, visit.confirmed_at

    ReminderBatch.call(@austin, now: NOW + 4.days)
    assert_equal 1, visit.deliveries.count
    ReminderBatch.call(@austin, now: NOW + 6.days)
    final = visit.deliveries.find_by!(step: "final")
    assert_not final.request_confirmation
    assert_not_includes final.body, "Reply YES"
  end

  test "S02 confirms email-only Spanish patient with the same intake" do
    add_visit(phone: nil, language: "es")
    ReminderBatch.call(@austin, now: NOW)
    delivery = visit.deliveries.sole
    assert_equal "email", delivery.channel
    assert_includes delivery.body, "Responda SI"
    assert_equal "confirmed", send_reply("sí", channel: "email").outcome
    assert_equal NOW, visit.confirmed_at
  end

  test "S03 a source time change resets confirmation and old replies require review even before a manual refresh" do
    add_visit
    ReminderBatch.call(@austin, now: NOW)
    send_reply
    pms_sql("UPDATE pms.appointments SET start_at = '2026-11-23 16:00:00' WHERE id = 11")

    assert_equal "review", send_reply(now: NOW + 1.minute).outcome
    assert_nil visit.confirmed_at
    assert_equal 2, visit.revision
    assert_equal "2026-11-23T16:00:00.000000", visit.wall_start
    ReminderBatch.call(@austin, now: NOW + 1.minute)
    assert_equal [ 1, 2 ], visit.deliveries.order(:id).pluck(:revision)
    assert_equal "review", send_reply(now: NOW + 2.minutes).outcome
  end

  test "S04 broken appointment stops outreach while replacement earns a distinct reminder" do
    add_visit
    ReminderBatch.call(@austin, now: NOW)
    pms_sql("UPDATE pms.appointments SET status = 'broken' WHERE id = 11")
    add_visit(id: 12, start: "2026-11-24 13:00:00")

    ReminderBatch.call(@austin, now: NOW + 1.day)

    assert_equal "broken", visit.source_status
    assert_equal 1, visit.deliveries.count
    assert_equal 1, visit(12).deliveries.count
    assert_equal "review", send_reply(now: NOW + 1.day).outcome
    assert_nil visit(12).confirmed_at
  end

  test "S03 a reschedule cannot make an unthreaded YES unambiguous after the reply window" do
    add_visit
    ReminderBatch.call(@austin, now: NOW)
    pms_sql("UPDATE pms.appointments SET start_at = '2026-12-08 16:00:00' WHERE id = 11")
    later = NOW + 15.days
    ReminderBatch.call(@austin, now: later)

    reply = send_reply(now: later)
    assert_equal [ 1, 2 ], visit.deliveries.order(:id).pluck(:revision)
    assert_equal "review", reply.outcome
    assert_nil visit.confirmed_at
    assert_includes @austin.work_items.find_by!(reply: reply).reason, "earlier appointment revision"
  end

  test "S05 failed fake delivery remains visible and backup email is idempotent" do
    add_visit(phone: "512-555-0107")
    assert_equal({ sent: 0, failed: 1 }, ReminderBatch.call(@austin, now: NOW))
    assert_equal "failed", visit.deliveries.sole.status
    assert visit.work_items.open.exists?(kind: "delivery_failed")

    2.times { ReminderBatch.call(@austin, now: NOW + 1.day) }

    assert_equal [ [ "initial", "sms", "failed" ], [ "backup", "email", "sent" ] ],
      visit.deliveries.order(:id).pluck(:step, :channel, :status)
  end

  test "S07 a later NO creates review and preserves confirmation" do
    add_visit
    ReminderBatch.call(@austin, now: NOW)
    send_reply
    assert_equal "review", send_reply("NO", now: NOW + 10.minutes).outcome
    assert_equal NOW, visit.confirmed_at
    assert visit.work_items.open.exists?(kind: "reply_review")
  end

  test "S08 replies and sends at or after start never confirm or deliver" do
    add_visit(start: "2026-11-16 11:05:00")
    ReminderBatch.call(@austin, now: NOW)
    late_time = NOW + 5.minutes

    assert_equal "review", send_reply(now: late_time).outcome
    assert_nil visit.confirmed_at
    assert_no_difference(-> { @austin.deliveries.count }) { ReminderBatch.call(@austin, now: late_time) }
  end

  test "S09 exact STOP persists across refresh and ambiguous variants become review" do
    add_visit
    ReminderBatch.call(@austin, now: NOW)
    assert_equal "review", send_reply("STOP please").outcome
    assert_equal "opted_out", send_reply(" stop ").outcome

    ReminderBatch.call(@austin, now: NOW + 4.days)

    assert_equal [ "sms", "email" ], visit.deliveries.order(:id).pluck(:channel)
    assert_equal 1, @austin.sms_opt_outs.count
  end

  test "S11 staff attempts keep a case open and a confirmed outcome records once" do
    add_visit(start: "2026-11-17 13:00:00")
    ReminderBatch.call(@austin, now: NOW)
    item = visit.work_items.find_by!(kind: "no_confirmation")
    staff = @austin.staff_members.create!(name: "Taylor")
    item.update!(assignee: staff)

    StaffFollowUp.call(item: item, staff: staff, outcome: "attempted", note: "Left a voicemail.", visit_id: nil,
      event_id: SecureRandom.uuid, now: NOW)
    assert_nil item.reload.resolved_at

    event = SecureRandom.uuid
    2.times do
      StaffFollowUp.call(item: item, staff: staff, outcome: "confirmed", note: "Confirmed by phone.", visit_id: nil,
        event_id: event, now: NOW)
    end
    assert_equal NOW, item.reload.resolved_at
    assert_equal NOW, visit.confirmed_at
    assert_equal 2, @austin.staff_actions.count
  end

  test "staff follow-up on a changed visit rejects the stale action and retains the refreshed snapshot" do
    add_visit(start: "2026-11-17 13:00:00")
    ReminderBatch.call(@austin, now: NOW)
    item = visit.work_items.find_by!(kind: "no_confirmation")
    staff = @austin.staff_members.create!(name: "Taylor")
    item.update!(assignee: staff)
    pms_sql("UPDATE pms.appointments SET start_at = '2026-11-18 16:00:00' WHERE id = 11")

    assert_raises(StaffFollowUp::StaleVisit) do
      StaffFollowUp.call(item: item, staff: staff, outcome: "confirmed", note: "Confirmed by phone.", visit_id: nil,
        event_id: SecureRandom.uuid, now: NOW)
    end
    assert_empty @austin.staff_actions
    assert_equal 2, visit.revision
    assert_equal "2026-11-18T16:00:00.000000", visit.wall_start
    assert_nil visit.confirmed_at
    assert item.reload.resolved_at?
  end

  test "S12 shared contact blocks new texts and converts a reply to a linked case" do
    add_visit(email: nil)
    ReminderBatch.call(@austin, now: NOW)
    add_visit(id: 12, patient_id: 102, email: nil)

    ReminderBatch.call(@austin, now: NOW + 4.days)
    reply = send_reply(now: NOW + 4.days)

    assert_equal "review", reply.outcome
    assert_equal({ visit.id.to_s => [ 1 ] }, @austin.work_items.find_by!(reply: reply).candidates)
    assert_equal 1, @austin.deliveries.count
    assert_equal 2, @austin.work_items.open.where(kind: "contact_hold").count
    assert @austin.visits.pluck(:confirmed_at).all?(&:nil?)
  end

  test "staff can link an ambiguous reply to an explicitly clarified current visit" do
    add_visit
    add_visit(id: 12, start: "2026-11-23 16:30:00")
    ReminderBatch.call(@austin, now: NOW)
    reply = send_reply
    item = @austin.work_items.find_by!(reply: reply)
    staff = @austin.staff_members.create!(name: "Taylor")
    item.update!(assignee: staff)

    assert_equal [ visit.id, visit(12).id ].sort, item.candidates.keys.map(&:to_i).sort
    assert_raises(StaffFollowUp::Invalid) do
      StaffFollowUp.call(item: item, staff: staff, outcome: "confirmed", note: "Clarified by phone.", visit_id: nil,
        event_id: SecureRandom.uuid, now: NOW)
    end
    assert_nil item.reload.resolved_at
    StaffFollowUp.call(item: item, staff: staff, outcome: "confirmed", note: "Clarified by phone.", visit_id: visit(12).id,
      event_id: SecureRandom.uuid, now: NOW)
    assert_nil visit.confirmed_at
    assert_equal NOW, visit(12).confirmed_at
    assert_equal NOW, item.reload.resolved_at
  end

  test "a local correction cannot hide another patient's raw claim to a destination" do
    add_visit(email: nil)
    add_visit(id: 12, patient_id: 102, start: "2026-11-30 15:00:00", email: nil)
    ReminderBatch.call(@austin, now: NOW)
    staff = @austin.staff_members.create!(name: "Taylor")
    ContactVerification.call(patient: visit(12).patient, staff: staff, field: "phone",
      value: "512-555-0133", now: NOW)

    assert_empty @austin.deliveries
    assert_equal({ sent: 0, failed: 0 }, ReminderBatch.call(@austin, now: NOW))
  end

  test "S13 local verified correction unblocks outreach without changing raw data and a later conflict blocks it again" do
    add_visit(phone: nil, email: nil, birthdate: nil)
    add_visit(id: 12, patient_id: 102, birthdate: "2012-04-08")
    ReminderBatch.call(@austin, now: NOW)
    assert_empty @austin.deliveries
    assert_equal 2, @austin.work_items.open.where(kind: "contact_hold").count

    staff = @austin.staff_members.create!(name: "Taylor")
    patient = visit.patient
    ContactVerification.call(patient: patient, staff: staff, field: "phone", value: "512-555-0111", now: NOW)
    ContactVerification.call(patient: patient, staff: staff, field: "birthdate", value: "1980-01-01", now: NOW)
    ReminderBatch.call(@austin, now: NOW)
    assert_equal "+15125550111", visit.deliveries.sole.recipient
    source = pms_sql("SELECT wireless_phone, birthdate FROM pms.patients WHERE id = 101").first
    assert source.values.all?(&:nil?)

    pms_sql("UPDATE pms.patients SET wireless_phone = '512-555-0112' WHERE id = 101")
    ReminderBatch.call(@austin, now: NOW + 4.days)
    assert_equal 1, visit.deliveries.count
    assert visit.work_items.open.exists?(kind: "contact_hold")
    assert visit.patient.conflict?("phone")
  end

  test "S14 empty and failed refreshes retain the last successful view and suppress sends" do
    add_visit
    ReminderBatch.call(@austin, now: NOW)
    pms_sql("DELETE FROM pms.appointments WHERE id = 11")

    assert_nil ReminderBatch.call(@austin, now: NOW + 4.days)
    assert_equal NOW, @austin.reload.synced_at
    assert_includes @austin.source_error, "no visits"
    assert_equal "scheduled", visit.source_status

    pms_sql("ALTER TABLE pms.appointments RENAME TO unavailable_appointments")
    begin
      assert_nil ReminderBatch.call(@austin, now: NOW + 4.days)
      assert_includes @austin.reload.source_error, "could not be read"
      assert_equal 1, @austin.deliveries.count
    ensure
      pms_sql("ALTER TABLE pms.unavailable_appointments RENAME TO appointments")
    end
  end

  test "S15 concurrent batches write one delivery and respect clinic-local boundaries" do
    add_visit(start: "2026-11-23 11:15:00")
    add_visit(id: 12, clinic: @phoenix, patient_id: 102, start: "2026-11-23 10:15:00")
    ReminderBatch.call(@austin, now: NOW - 1.hour)
    ReminderBatch.call(@phoenix, now: NOW - 1.hour)
    assert_equal 1, @austin.deliveries.count
    assert_empty @phoenix.deliveries

    ready = Queue.new
    start = Queue.new
    threads = 3.times.map do
      Thread.new do
        Rails.application.executor.wrap do
          clinic = Clinic.find(@phoenix.id)
          ready << true
          start.pop
          ReminderBatch.call(clinic, now: NOW)
        end
      end
    end
    3.times { ready.pop }
    3.times { start << true }

    assert_equal 1, threads.sum { |thread| thread.value.fetch(:sent) }
    assert_equal 1, @phoenix.deliveries.count
    ReminderBatch.call(@phoenix, now: NOW + 6.days + 8.hours)
    assert_equal 1, @phoenix.deliveries.count
  end

  test "an unexpected error during a batch rolls back persisted writes and a retry can finish" do
    add_visit
    add_visit(id: 12, patient_id: 102, phone: "512-555-0112", email: nil)
    mailbox = Object.new
    attempts = 0
    mailbox.define_singleton_method(:deliver) do |**|
      attempts += 1
      raise "Synthetic failure during second delivery" if attempts == 2

      "sent"
    end

    assert_raises(RuntimeError) { ReminderBatch.call(@austin, now: NOW, mailbox: mailbox) }
    assert_equal 0, Delivery.where(clinic: @austin).count
    assert_equal 0, Visit.where(clinic: @austin).count
    assert_nil @austin.reload.synced_at
    assert_equal({ sent: 2, failed: 0 }, ReminderBatch.call(@austin, now: NOW))
  end

  test "PMS reading role refuses writes" do
    PmsRecord.connected_to(role: :reading) do
      assert_raises(ActiveRecord::ReadOnlyError) { Pms::Clinic.where(id: 1).update_all(name: "Modified") }
      assert Pms::Clinic.find(1).readonly?
    end
    assert_equal "Austin", pms_sql("SELECT name FROM pms.clinics WHERE id = 1").first.fetch("name")
  end
end
