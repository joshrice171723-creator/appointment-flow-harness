namespace :apex do
  desc "Refresh the PMS snapshot and run fake reminders for every demo clinic"
  task reminders: :environment do
    failed = false
    Clinic.order(:id).each do |clinic|
      result = ReminderBatch.call(clinic)
      if result
        puts "#{clinic.name}: #{result[:sent]} sent, #{result[:failed]} failed"
      else
        warn "#{clinic.name}: #{clinic.reload.source_error}"
        failed = true
      end
    end
    abort "A clinic refresh failed." if failed
  end
end
