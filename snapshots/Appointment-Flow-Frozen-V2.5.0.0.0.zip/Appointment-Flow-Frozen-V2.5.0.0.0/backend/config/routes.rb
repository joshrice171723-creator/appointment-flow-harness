Rails.application.routes.draw do
  get "up" => "rails/health#show"
  namespace :api do
    resources :workspaces, only: :index
    resource :staff_session, only: :create
    resource :leadership_report, only: :show
    resources :clinics, only: [] do
      resources :appointments, only: :index
      resources :work_items, only: %i[index update] do
        resources :follow_ups, only: :create
      end
      resources :patients, only: :show do
        resources :contact_verifications, only: :update
      end
      resource :pms_refresh, only: :create
      resource :reminder_batch, only: :create
    end
    resources :demo_clinics, only: [] do
      resources :demo_patients, path: "patients", only: %i[index show] do
        resources :demo_replies, path: "replies", only: :create
      end
    end
  end
end
