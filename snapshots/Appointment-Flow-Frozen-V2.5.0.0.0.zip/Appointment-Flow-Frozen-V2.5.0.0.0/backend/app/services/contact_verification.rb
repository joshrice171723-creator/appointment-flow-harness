class ContactVerification
  class Invalid < StandardError; end

  def self.call(patient:, staff:, field:, value:, now: DemoClock.now)
    unless patient.clinic_id == staff.clinic_id && Patient::EDITABLE_FIELDS.include?(field) &&
        value.is_a?(String) && value.length <= 254
      raise Invalid, "Choose a contact field and enter a valid value."
    end

    value = normalize(field, value.strip, today: now.in_time_zone(staff.clinic.zone).to_date)
    raise Invalid, "Enter a valid #{field}." unless value

    staff.clinic.with_lock do
      return false unless PmsSync.call(staff.clinic, now: now)

      patient.reload
      entry = { "value" => value, "source" => patient.source_contact[field] }
      return true if patient.verified_contact[field] == entry

      change = { field => { "before" => patient.contact(field), "after" => value } }
      patient.update!(verified_contact: patient.verified_contact.merge(field => entry))
      staff.clinic.staff_actions.create!(patient: patient, staff_member: staff, event_id: SecureRandom.uuid,
        outcome: "contact_verified", note: "Verified #{field}", changes_recorded: change, occurred_at: now)
      true
    end
  end

  def self.normalize(field, value, today:)
    case field
    when "phone"
      Patient.normalize_phone(value)
    when "email"
      Patient.normalize_email(value)
    when "language"
      value.downcase if Patient::LANGUAGES.include?(value.downcase)
    when "birthdate"
      date = Date.iso8601(value)
      date.iso8601 if date <= today && date.iso8601 == value
    end
  rescue Date::Error
    nil
  end
  private_class_method :normalize
end
