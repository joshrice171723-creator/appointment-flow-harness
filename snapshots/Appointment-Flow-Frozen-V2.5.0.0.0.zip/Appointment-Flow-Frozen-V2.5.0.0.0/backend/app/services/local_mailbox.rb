class LocalMailbox
  UNREACHABLE_NUMBER = "+15125550107"

  def self.deliver(channel:, recipient:, body:)
    return "failed" if channel == "sms" && recipient == UNREACHABLE_NUMBER

    "sent"
  end
end
