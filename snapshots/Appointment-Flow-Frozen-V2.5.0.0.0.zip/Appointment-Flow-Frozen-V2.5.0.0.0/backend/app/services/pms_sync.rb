class PmsSync
  class Unavailable < StandardError; end

  def self.call(clinic, now: DemoClock.now)
    clinic.with_lock { new(clinic, now).refresh }
  end

  def initialize(clinic, now)
    @clinic = clinic
    @now = now
    today = now.in_time_zone(clinic.zone).to_date
    @from = today.beginning_of_month << 2
    @to = today + 61
  end

  def refresh
    source_clinic, source_patients, appointments = read_snapshot
    patients = sync_patients(source_patients)
    sync_visits(appointments, patients)
    @clinic.update!(name: source_clinic.name, synced_at: @now, source_error: nil)
    true
  rescue Unavailable => error
    @clinic.update!(source_error: error.message)
    false
  end

  private

  def read_snapshot
    PmsRecord.connected_to(role: :reading) do
      PmsRecord.transaction(isolation: :repeatable_read) do
        source_clinic = Pms::Clinic.find_by(id: @clinic.source_id)
        raise Unavailable, "Clinic is missing from the PMS." unless source_clinic

        scope = Pms::Appointment.where(clinic_id: source_clinic.id)
        appointments = scope.where(start_at: @from...@to)
          .select(:id, :patient_id, :start_at, :status, :provider_name, :length_minutes).to_a
        if appointments.empty? && @clinic.visits.scheduled.exists?
          raise Unavailable, "PMS returned no visits for this clinic. Verify the source before sending."
        end

        # Check contact ownership across the clinic, including patients without an upcoming visit.
        patient_ids = scope.select(:patient_id).distinct
        patients = Pms::Patient.where(id: patient_ids)
          .select(:id, :first_name, :last_name, :birthdate, :wireless_phone, :email, :preferred_language, :guarantor_id).to_a
        [ source_clinic, patients, appointments ]
      end
    end
  rescue ActiveRecord::ConnectionNotEstablished, ActiveRecord::ConnectionFailed, ActiveRecord::QueryCanceled,
         ActiveRecord::StatementInvalid => error
    Rails.logger.warn("PMS refresh failed for clinic #{@clinic.id} (#{error.class})")
    raise Unavailable, "PMS could not be read. Try refreshing again.", cause: error
  end

  def sync_patients(source_patients)
    patients = @clinic.patients.index_by(&:source_id)
    source_patients.each do |source|
      patient = patients[source.id] ||= @clinic.patients.new(source_id: source.id)
      patient.assign_attributes(
        name: "#{source.first_name} #{source.last_name}",
        source_contact: {
          birthdate: source.birthdate&.iso8601, phone: source.wireless_phone, email: source.email,
          language: source.preferred_language, guarantor: source.guarantor_id
        }
      )
      patient.save! if patient.changed? ||
        patient.source_sms_address != Patient.normalize_phone(source.wireless_phone) ||
        patient.source_email_address != Patient.normalize_email(source.email)
    end
    patients
  end

  def sync_visits(appointments, patients)
    visits = @clinic.visits.where(wall_start: @from.iso8601...@to.iso8601).index_by(&:source_id)
    # Also lookup IDs moved into the window so their existing revision is advanced.
    incoming_ids = appointments.map(&:id)
    @clinic.visits.where(source_id: incoming_ids - visits.keys).each { |visit| visits[visit.source_id] = visit }
    appointments.each do |source|
      visit = visits.delete(source.id) || @clinic.visits.new(source_id: source.id)
      source_wall_start = source.start_at.utc.iso8601(6).delete_suffix("Z")
      patient = patients.fetch(source.patient_id)
      if visit.persisted? && [ visit.wall_start, visit.source_status, visit.patient_id ] !=
          [ source_wall_start, source.status, patient.id ]
        supersede_visit(visit)
      end
      visit.assign_attributes(patient: patient, wall_start: source_wall_start,
        starts_at: @clinic.source_time(source_wall_start), source_status: source.status,
        provider: source.provider_name, minutes: source.length_minutes)
      visit.save! if visit.changed?
    end

    visits.each_value do |visit|
      next unless visit.source_status == "scheduled"

      supersede_visit(visit)
      visit.update!(source_status: "source_missing")
      WorkItem.raise_for_visit!(visit, "contact_hold", "Visit is missing from the current PMS snapshot", now: @now)
    end
  end

  def supersede_visit(visit)
    visit.work_items.open.where.not(kind: "reply_review").update_all(resolved_at: @now)
    visit.assign_attributes(revision: visit.revision + 1, confirmed_at: nil, staff_disposition: nil)
  end
end
