class ReminderBatch
  INITIAL_DAYS = 7
  BACKUP_DAYS = 6
  FOLLOW_UP_DAYS = 3
  FINAL_DAYS = 1
  SEND_HOURS = 10...18

  def self.call(clinic, now: nil, mailbox: LocalMailbox)
    clock = now ? -> { now } : DemoClock.method(:now)
    clinic.with_lock do
      return nil unless PmsSync.call(clinic, now: clock.call)

      new(clinic, clock, mailbox).deliver_reminders
    end
  end

  def initialize(clinic, clock, mailbox)
    @clinic = clinic
    @clock = clock
    @now = clock.call
    @zone = clinic.zone
    @local_now = @now.in_time_zone(@zone)
    @mailbox = mailbox
  end

  def deliver_reminders
    counts = { sent: 0, failed: 0 }
    end_of_window = (@local_now + (INITIAL_DAYS + 1).days).beginning_of_day
    candidates = @clinic.visits.scheduled.where(starts_at: @now...end_of_window)
    invalid_times = @clinic.visits.scheduled.where(starts_at: nil,
      wall_start: @local_now.to_date.iso8601...end_of_window.to_date.iso8601)

    invalid_times.find_each do |visit|
      WorkItem.raise_for_visit!(visit, "contact_hold", "Clinic-local appointment time needs review", now: @now)
    end

    candidates.includes(:patient, :deliveries).find_each do |visit|
      next unless visit.starts_at > @now

      deliver_for(visit, counts)
    end
    counts
  end

  private

  def deliver_for(visit, counts)
    patient = visit.patient
    if visit.confirmed_at.nil? && visit.starts_at <= @now + 48.hours
      WorkItem.raise_for_visit!(visit, "no_confirmation", "Confirmation needed within 48 hours", now: @now)
    end

    channels = usable_channels(patient)
    hold = patient.contact_hold(on: @local_now.to_date)
    hold ||= "No permitted, unshared phone or email is available" if channels.empty?
    if hold
      WorkItem.raise_for_visit!(visit, "contact_hold", hold, now: @now) unless visit.confirmed_at?
      return
    end

    visit.work_items.open.where(revision: visit.revision, kind: "contact_hold").update_all(resolved_at: @now)
    send_at = @clock.call
    local_send_at = send_at.in_time_zone(@zone)
    return unless visit.starts_at > send_at && SEND_HOURS.cover?(local_send_at.hour)

    days = (visit.starts_at.in_time_zone(@zone).to_date - local_send_at.to_date).to_i
    history = visit.deliveries.select { |delivery| delivery.revision == visit.revision }
    step, channel = next_step(visit, days, channels, history)
    return unless channel && history.none? { |delivery| delivery.step == step }
    return if history.any? { |delivery| delivery.occurred_at.in_time_zone(@zone).to_date == local_send_at.to_date }

    request = visit.confirmed_at.nil?
    recipient = patient.destination(channel)
    body = reminder_text(visit, channel, request)
    status = @mailbox.deliver(channel: channel, recipient: recipient, body: body)
    @clinic.deliveries.create!(patient: patient, visit: visit, revision: visit.revision, step: step,
      channel: channel, recipient: recipient, body: body, status: status, occurred_at: send_at,
      request_confirmation: request)
    counts[status.to_sym] += 1
    if status == "failed"
      WorkItem.raise_for_visit!(visit, "delivery_failed", "Simulated #{channel.upcase} delivery failed", now: @now)
    end
  end

  def usable_channels(patient)
    Patient::CHANNEL_COLUMNS.keys.filter_map do |channel|
      address = patient.destination(channel)
      next if address.blank? || patient.shared_destination?(channel, address)
      next if channel == "sms" && @clinic.sms_opt_outs.exists?(recipient: address)

      channel
    end
  end

  def next_step(visit, days, channels, history)
    failed_sms = history.any? { |delivery| delivery.channel == "sms" && delivery.status == "failed" }
    preferred = failed_sms && channels.include?("email") ? "email" : channels.first
    return [ "final", preferred ] if days <= FINAL_DAYS
    return if visit.confirmed_at?

    initial = history.find { |delivery| delivery.step == "initial" }
    return [ "follow_up", preferred ] if days <= FOLLOW_UP_DAYS
    if days <= BACKUP_DAYS && initial&.channel == "sms" && channels.include?("email")
      return [ "backup", "email" ]
    end

    [ "initial", preferred ]
  end

  def reminder_text(visit, channel, request)
    when_local = visit.starts_at.in_time_zone(@zone)
    if visit.patient.contact("language") == "es"
      date = I18n.l(when_local, locale: :es, format: :appointment)
      body = "Cita en #{@clinic.name}: #{date} (hora local)."
      body += " Responda SI para confirmar o NO para pedir ayuda." if request
      body += " Responda STOP para dejar de recibir mensajes de texto." if channel == "sms"
    else
      date = when_local.strftime("%a, %b %-d at %-I:%M %p")
      body = "Appointment at #{@clinic.name}: #{date} (local time)."
      body += " Reply YES to confirm or NO for help." if request
      body += " Reply STOP to stop texts." if channel == "sms"
    end
    body
  end
end
