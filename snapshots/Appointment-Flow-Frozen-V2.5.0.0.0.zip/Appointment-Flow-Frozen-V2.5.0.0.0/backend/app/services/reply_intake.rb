class ReplyIntake
  class Invalid < StandardError; end

  REPLY_WINDOW = 10.days
  EVENT_ID = /\A[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\z/i

  def self.call(patient:, channel:, body:, event_id:, now: DemoClock.now)
    unless Patient::CHANNEL_COLUMNS.key?(channel) && body.is_a?(String) && body.strip.present? &&
        body.length <= 500 && event_id.is_a?(String) && EVENT_ID.match?(event_id)
      raise Invalid, "Enter a reply of 1 to 500 characters."
    end

    patient.clinic.with_lock do
      previous = patient.clinic.replies.find_by(event_id: event_id)
      if previous
        unless [ previous.patient_id, previous.channel, previous.body ] == [ patient.id, channel, body ]
          raise Invalid, "This reply ID already belongs to another event."
        end
        return previous
      end

      new(patient, channel, body, event_id, now).record
    end
  end

  def initialize(patient, channel, body, event_id, now)
    @patient = patient
    @clinic = patient.clinic
    @channel = channel
    @body = body
    @event_id = event_id
    @now = now
  end

  def record
    # The demo gets the inbound sender from the chosen inbox, never a browser-supplied address.
    recipient = @patient.destination(@channel)
    if @channel == "sms" && @body.strip.casecmp?("STOP") && recipient.present?
      @clinic.sms_opt_outs.find_or_create_by!(recipient: recipient) { |opt_out| opt_out.occurred_at = @now }
      return save_reply(recipient, "opted_out")
    end

    source_ready = PmsSync.call(@clinic, now: @now)
    @patient.reload
    deliveries = relevant_deliveries(recipient)
    candidate = deliveries.one? ? deliveries.first : nil
    reason = review_reason(source_ready, recipient, deliveries, candidate)
    if reason
      reply = save_reply(recipient, "review")
      @clinic.work_items.create!(key: "reply/#{reply.id}", patient: @patient, reply: reply, kind: "reply_review",
        visit: candidate&.visit, revision: candidate&.revision, reason: reason, opened_at: @now,
        candidates: deliveries.group_by(&:visit_id).transform_values { |matches| matches.map(&:revision).uniq })
      return reply
    end

    visit = candidate.visit
    visit.update!(confirmed_at: @now) unless visit.confirmed_at?
    visit.work_items.open.where(revision: visit.revision, kind: "no_confirmation").update_all(resolved_at: @now)
    save_reply(recipient, "confirmed")
  end

  private

  def relevant_deliveries(recipient)
    return [] if recipient.blank?

    @clinic.deliveries.where(channel: @channel, recipient: recipient, status: "sent", request_confirmation: true,
      occurred_at: (@now - REPLY_WINDOW)..@now).includes(:visit).order(occurred_at: :desc).to_a
      .uniq { |delivery| [ delivery.visit_id, delivery.revision ] }
  end

  def review_reason(source_ready, recipient, deliveries, candidate)
    return "PMS is unavailable. Verify the visit before acting." unless source_ready
    return "The sender does not match a current contact." if recipient.blank? || @patient.destination(@channel) != recipient
    return "The sender is shared by multiple patients." if @patient.shared_destination?(@channel, recipient)
    return "The reply could refer to multiple visits or revisions." if deliveries.size > 1
    return "No matching confirmation request." unless candidate&.patient_id == @patient.id
    return "The appointment changed or already started." unless candidate.visit.current?(revision: candidate.revision, now: @now)
    return "This number or email received a request for an earlier appointment revision." if prior_revision_request?(candidate)
    return "Contact details need verification." if @patient.contact_hold(on: @now.in_time_zone(@clinic.zone).to_date)
    return "Patient requested help with the appointment." if @body.strip.casecmp?("NO")
    return "Reply needs staff interpretation." unless affirmative?

    nil
  end

  def prior_revision_request?(candidate)
    candidate.visit.deliveries.where(channel: @channel, recipient: candidate.recipient, status: "sent",
      request_confirmation: true, occurred_at: ..@now).where.not(revision: candidate.revision).exists?
  end

  def affirmative?
    reply = @body.strip.upcase
    reply == "YES" || (@patient.contact("language") == "es" && %w[SI SÍ].include?(reply))
  end

  def save_reply(recipient, outcome)
    @clinic.replies.create!(patient: @patient, channel: @channel, recipient: recipient, body: @body,
      event_id: @event_id, outcome: outcome, occurred_at: @now)
  end
end
