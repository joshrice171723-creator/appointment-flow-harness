class StaffFollowUp
  class Invalid < StandardError; end
  class StaleVisit < Invalid; end

  OUTCOMES = %w[attempted confirmed rescheduled canceled reviewed].freeze

  def self.call(item:, staff:, outcome:, note:, visit_id:, event_id:, now: DemoClock.now)
    unless OUTCOMES.include?(outcome) && note.is_a?(String) && note.strip.present? &&
        note.length <= 1000 && event_id.is_a?(String) && ReplyIntake::EVENT_ID.match?(event_id)
      raise Invalid, "Choose an outcome and enter a note of up to 1,000 characters."
    end

    stale_visit = nil
    action = item.clinic.with_lock do
      new(item, staff, now).record(outcome, note.strip, visit_id, event_id)
    rescue StaleVisit => error
      stale_visit = error
    end
    raise stale_visit if stale_visit

    action
  end

  def initialize(item, staff, now)
    @item = item
    @staff = staff
    @clinic = staff.clinic
    @now = now
  end

  def record(outcome, note, visit_id, event_id)
    unless @item.clinic_id == @staff.clinic_id
      raise Invalid, "The work item belongs to another clinic."
    end

    @item.reload
    target = { "visit_id" => visit_id.to_s }
    previous = @clinic.staff_actions.find_by(event_id: event_id)
    if previous
      unless [ previous.staff_member_id, previous.work_item_id, previous.outcome, previous.note, previous.changes_recorded ] ==
          [ @staff.id, @item.id, outcome, note, target ]
        raise Invalid, "This save ID already belongs to another follow-up."
      end
      return previous
    end

    raise Invalid, "This item is already resolved. Refresh the patient record." if @item.resolved_at?
    if @item.assignee_id != @staff.id
      raise Invalid, "Assign this item to yourself before recording follow-up."
    end
    if outcome == "reviewed" && @item.kind != "reply_review"
      raise Invalid, "Use a visit outcome for this item."
    end

    if %w[confirmed canceled rescheduled].include?(outcome)
      return unless PmsSync.call(@clinic, now: @now)

      apply_visit_outcome(outcome, visit_id)
    end
    action = @clinic.staff_actions.create!(patient: @item.patient, work_item: @item, staff_member: @staff,
      outcome: outcome, note: note, event_id: event_id, occurred_at: @now, changes_recorded: target)
    @item.update!(resolved_at: @now) unless outcome == "attempted"
    action
  end

  private

  def apply_visit_outcome(outcome, visit_id)
    if @item.kind == "reply_review"
      revisions = @item.candidates.fetch(visit_id.to_s, [])
      visit = @clinic.visits.find_by(id: visit_id) if revisions.any?
    else
      visit = @item.visit
      revisions = [ @item.revision ]
    end

    unless visit && revisions.include?(visit.revision) && visit.current?(revision: visit.revision, now: @now)
      raise StaleVisit, "Choose a current appointment before recording this outcome. Refresh the patient record if the visit changed."
    end

    if outcome == "confirmed"
      visit.update!(confirmed_at: visit.confirmed_at || @now)
      visit.work_items.open.where(revision: visit.revision, kind: "no_confirmation").update_all(resolved_at: @now)
    else
      visit.update!(staff_disposition: outcome)
      visit.work_items.open.where(revision: visit.revision).where.not(kind: "reply_review").update_all(resolved_at: @now)
    end
  end
end
