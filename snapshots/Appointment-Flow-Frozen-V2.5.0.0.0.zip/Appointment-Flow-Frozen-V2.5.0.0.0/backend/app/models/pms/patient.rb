module Pms
  class Patient < PmsRecord
    self.table_name = "pms.patients"
  end
end
