module Pms
  class Clinic < PmsRecord
    self.table_name = "pms.clinics"
  end
end
