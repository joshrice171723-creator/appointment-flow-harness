module Pms
  class Appointment < PmsRecord
    self.table_name = "pms.appointments"
  end
end
