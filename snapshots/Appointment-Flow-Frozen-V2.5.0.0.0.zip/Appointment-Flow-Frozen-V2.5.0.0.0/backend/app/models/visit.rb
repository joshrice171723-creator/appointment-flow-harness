class Visit < ApplicationRecord
  belongs_to :clinic
  belongs_to :patient
  has_many :deliveries
  has_many :work_items

  scope :scheduled, -> { where(source_status: "scheduled", staff_disposition: nil) }

  def current?(revision:, now:)
    self.revision == revision && source_status == "scheduled" &&
      staff_disposition.nil? && starts_at.present? && starts_at > now
  end

  def outcome
    return "Completed" if source_status == "complete"

    staff_disposition&.capitalize || "Unknown"
  end
end
