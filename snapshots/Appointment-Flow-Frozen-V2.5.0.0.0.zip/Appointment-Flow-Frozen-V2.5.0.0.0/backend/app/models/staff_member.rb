class StaffMember < ApplicationRecord
  belongs_to :clinic
end
