class Patient < ApplicationRecord
  CHANNEL_COLUMNS = { "sms" => :sms_address, "email" => :email_address }.freeze
  SOURCE_COLUMNS = { "sms" => :source_sms_address, "email" => :source_email_address }.freeze
  EDITABLE_FIELDS = %w[birthdate phone email language].freeze
  LANGUAGES = %w[en es].freeze

  belongs_to :clinic
  has_many :visits
  has_many :deliveries
  has_many :replies
  has_many :staff_actions
  has_many :work_items

  before_validation :normalize_destinations

  def contact(field)
    entry = verified_contact[field]
    entry ? entry.fetch("value") : source_contact[field]
  end

  def conflict?(field)
    entry = verified_contact[field]
    entry.present? && ![ entry["source"], entry["value"] ].include?(source_contact[field])
  end

  def contact_hold(on:)
    return "Verified contact details differ from the PMS" if EDITABLE_FIELDS.any? { |field| conflict?(field) }

    birthdate = parse_birthdate
    return "Verify a valid birthdate" if birthdate.nil? || birthdate > on
    return "Verify guardian and contact authorization" if birthdate > on.years_ago(18) || source_contact["guarantor"]
    return "Verify a supported language" unless LANGUAGES.include?(contact("language"))

    nil
  end

  def destination(channel)
    self[CHANNEL_COLUMNS.fetch(channel)]
  end

  def shared_destination?(channel, address)
    others = clinic.patients.where.not(id: id)
    others.where(CHANNEL_COLUMNS.fetch(channel) => address)
      .or(others.where(SOURCE_COLUMNS.fetch(channel) => address)).exists?
  end

  def self.normalize_phone(value)
    text = value.to_s.strip
    return unless text.match?(/\A\+?[\d ()\-.]+\z/)

    digits = text.gsub(/\D/, "")
    return if text.start_with?("+") && !digits.match?(/\A1\d{10}\z/)

    digits = digits.sub(/\A1(?=\d{10}\z)/, "")
    "+1#{digits}" if digits.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
  end

  def self.normalize_email(value)
    email = value.to_s.strip.downcase
    email if email.match?(URI::MailTo::EMAIL_REGEXP) && email.split("@").last.include?(".")
  end

  private

  def parse_birthdate
    Date.iso8601(contact("birthdate").to_s)
  rescue Date::Error
    nil
  end

  def normalize_destinations
    self.sms_address = self.class.normalize_phone(contact("phone"))
    self.email_address = self.class.normalize_email(contact("email"))
    self.source_sms_address = self.class.normalize_phone(source_contact["phone"])
    self.source_email_address = self.class.normalize_email(source_contact["email"])
  end
end
