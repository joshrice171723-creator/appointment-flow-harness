class Delivery < ApplicationRecord
  belongs_to :clinic
  belongs_to :patient
  belongs_to :visit
end
