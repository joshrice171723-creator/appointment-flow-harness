class WorkItem < ApplicationRecord
  belongs_to :clinic
  belongs_to :patient
  belongs_to :visit, optional: true
  belongs_to :reply, optional: true
  belongs_to :assignee, class_name: "StaffMember", optional: true

  scope :open, -> { where(resolved_at: nil) }

  def self.raise_for_visit!(visit, kind, reason, now:)
    find_or_initialize_by(clinic_id: visit.clinic_id, key: "#{visit.id}/#{visit.revision}/#{kind}").tap do |item|
      item.assign_attributes(patient: visit.patient, visit: visit, revision: visit.revision, kind: kind,
        reason: reason, resolved_at: nil, opened_at: item.opened_at || now)
      item.save! if item.changed?
    end
  end

  def status
    return "Resolved" if resolved_at?
    return "In progress" if assignee_id?

    "Needs attention"
  end
end
