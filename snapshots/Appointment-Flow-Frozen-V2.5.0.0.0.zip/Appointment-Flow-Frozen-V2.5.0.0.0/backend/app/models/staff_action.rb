class StaffAction < ApplicationRecord
  belongs_to :clinic
  belongs_to :patient
  belongs_to :work_item, optional: true
  belongs_to :staff_member
end
