class Clinic < ApplicationRecord
  has_many :staff_members
  has_many :patients
  has_many :visits
  has_many :deliveries
  has_many :replies
  has_many :sms_opt_outs
  has_many :work_items
  has_many :staff_actions

  def zone
    Time.find_zone!(timezone)
  end

  def source_time(wall_clock)
    wall = Time.iso8601("#{wall_clock}Z")
    zone.tzinfo.local_to_utc(wall, nil)
  rescue TZInfo::PeriodNotFound, TZInfo::AmbiguousTime
    nil
  end
end
