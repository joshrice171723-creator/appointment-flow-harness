module DemoClock
  def self.now
    value = ENV["APEX_DEMO_NOW"]
    value.present? ? Time.iso8601(value) : Time.current
  end
end
