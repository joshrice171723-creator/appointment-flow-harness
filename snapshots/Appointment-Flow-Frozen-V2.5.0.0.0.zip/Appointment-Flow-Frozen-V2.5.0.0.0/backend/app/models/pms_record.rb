class PmsRecord < ActiveRecord::Base
  self.abstract_class = true

  connects_to database: { writing: :primary, reading: :pms_reader }

  def readonly?
    true
  end
end
