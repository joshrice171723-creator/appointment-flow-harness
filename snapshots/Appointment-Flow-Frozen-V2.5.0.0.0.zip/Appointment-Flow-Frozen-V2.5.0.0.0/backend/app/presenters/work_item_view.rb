module WorkItemView
  def self.summary(item)
    {
      id: item.id, patient_id: item.patient_id, patient: item.patient.name, kind: item.kind,
      reason: item.reason, wall_start: item.visit&.wall_start, status: item.status,
      assignee_id: item.assignee_id, assignee: item.assignee&.name, opened_at: item.opened_at
    }
  end

  def self.detail(item, candidates)
    summary(item).merge(
      reply: item.reply&.as_json(only: %i[body channel occurred_at]),
      candidates: item.candidates.filter_map do |id, revisions|
        visit = candidates[id.to_i]
        next unless visit

        { id: visit.id, patient: visit.patient.name, wall_start: visit.wall_start,
          current: revisions.include?(visit.revision) && visit.current?(revision: visit.revision, now: DemoClock.now) }
      end
    )
  end
end
