module VisitViews
  private

  def visit_view(visit, review_ids)
    {
      id: visit.id, patient_id: visit.patient_id, patient: visit.patient.name, wall_start: visit.wall_start,
      provider: visit.provider, minutes: visit.minutes, outcome: visit.outcome, source_status: visit.source_status,
      state: visit.confirmed_at? ? "Confirmed" : "Unconfirmed", review: review_ids.include?(visit.id),
      upcoming: visit.current?(revision: visit.revision, now: DemoClock.now)
    }
  end

  def review_ids_for(visits)
    ids = visits.map(&:id)
    return [] if ids.empty?

    reviews = clinic.work_items.open.where(kind: "reply_review")
    linked = reviews.where(visit_id: ids).or(reviews.where(
      "EXISTS (SELECT FROM jsonb_object_keys(candidates) AS candidate(id) WHERE candidate.id IN (?))", ids.map(&:to_s)))
    linked
      .pluck(:visit_id, :candidates).flat_map { |visit_id, candidates| [ visit_id, *candidates.keys.map(&:to_i) ] } & ids
  end
end
