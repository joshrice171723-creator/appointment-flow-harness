module Api
  class ContactVerificationsController < StaffController
    def update
      patient = clinic.patients.find(params[:patient_id])
      success = ContactVerification.call(patient: patient, staff: staff, field: params[:id], value: params[:value])
      return render_error(clinic.reload.source_error, :service_unavailable) unless success

      render json: { verified: true }
    rescue ContactVerification::Invalid => error
      render_error(error.message)
    end
  end
end
