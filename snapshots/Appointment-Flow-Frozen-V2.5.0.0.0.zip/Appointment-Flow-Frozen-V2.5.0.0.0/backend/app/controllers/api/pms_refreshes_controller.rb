module Api
  class PmsRefreshesController < StaffController
    def create
      success = PmsSync.call(clinic)
      return render_error(clinic.reload.source_error, :service_unavailable) unless success

      render json: sync_status
    end
  end
end
