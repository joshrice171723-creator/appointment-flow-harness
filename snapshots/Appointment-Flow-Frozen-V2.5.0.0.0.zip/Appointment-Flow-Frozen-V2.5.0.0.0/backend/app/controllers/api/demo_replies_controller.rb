module Api
  class DemoRepliesController < ApplicationController
    def create
      clinic = Clinic.find(params[:demo_clinic_id])
      patient = clinic.patients.find(params[:demo_patient_id])
      reply = ReplyIntake.call(patient: patient, channel: params[:channel], body: params[:body], event_id: params[:event_id])
      render json: { outcome: reply.outcome }
    rescue ReplyIntake::Invalid => error
      render_error(error.message)
    end
  end
end
