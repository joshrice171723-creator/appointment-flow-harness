module Api
  class WorkItemsController < StaffController
    PAGE_SIZE = 6
    GROUPS = {
      attention: { assignee_id: nil, resolved_at: nil },
      progress: { resolved_at: nil },
      resolved: {}
    }.freeze

    def index
      items = clinic.work_items
      counts = {
        attention: items.open.where(assignee_id: nil).count,
        progress: items.open.where.not(assignee_id: nil).count,
        resolved: items.where.not(resolved_at: nil).count
      }
      items = filter(items)
      lanes = GROUPS.to_h do |group, conditions|
        records = items.where(conditions)
        records = records.where.not(assignee_id: nil) if group == :progress
        records = records.where.not(resolved_at: nil) if group == :resolved
        total = records.count
        page = params["#{group}_page"].to_s.to_i.clamp(1, [ (total.to_f / PAGE_SIZE).ceil, 1 ].max)
        records = records.includes(:patient, :assignee, :visit).order(opened_at: :desc, id: :desc)
        [ group, { total: total, page: page, size: PAGE_SIZE, items: records.offset((page - 1) * PAGE_SIZE)
          .limit(PAGE_SIZE).map { |item| WorkItemView.summary(item) } } ]
      end
      render json: sync_status.merge(counts: counts, lanes: lanes)
    end

    def update
      item = clinic.work_items.find(params[:id])
      clinic.with_lock do
        item.reload
        return render_error("This item has already been resolved.", :conflict) if item.resolved_at?
        if item.assignee_id? && item.assignee_id != staff.id
          return render_error("This item is assigned to another staff member.", :conflict)
        end

        item.update!(assignee: staff)
      end
      render json: WorkItemView.summary(item)
    end

    private

    def filter(items)
      items = items.where(kind: params[:kind].to_s) if params[:kind].present?
      search = params[:search].to_s.strip.first(100)
      if search.present?
        items = items.joins(:patient).where("patients.name ILIKE ?", "%#{Patient.sanitize_sql_like(search)}%")
      end
      items
    end
  end
end
