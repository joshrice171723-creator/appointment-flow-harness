module Api
  class WorkspacesController < ApplicationController
    def index
      clinics = Clinic.order(:name).includes(:staff_members)
      render json: {
        clinics: clinics.map do |clinic|
          clinic.as_json(only: %i[id name timezone]).merge(
            staff: clinic.staff_members.sort_by(&:name).map { |staff| staff.as_json(only: %i[id name]) })
        end
      }
    end
  end
end
