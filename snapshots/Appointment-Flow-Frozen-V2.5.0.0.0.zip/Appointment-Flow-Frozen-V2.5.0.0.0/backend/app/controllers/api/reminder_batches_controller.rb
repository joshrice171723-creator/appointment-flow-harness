module Api
  class ReminderBatchesController < StaffController
    def create
      result = ReminderBatch.call(clinic)
      return render_error(clinic.reload.source_error, :service_unavailable) unless result

      render json: result.merge(sync_status)
    end
  end
end
