module Api
  class StaffSessionsController < ApplicationController
    def create
      clinic = Clinic.find(params.require(:clinic_id))
      staff = clinic.staff_members.find(params.require(:staff_id))
      reset_session
      session[:staff_id] = staff.id
      render json: { staff: staff.as_json(only: %i[id name]), clinic: clinic.as_json(only: %i[id name timezone]),
        today: DemoClock.now.in_time_zone(clinic.zone).to_date.iso8601 }
    end
  end
end
