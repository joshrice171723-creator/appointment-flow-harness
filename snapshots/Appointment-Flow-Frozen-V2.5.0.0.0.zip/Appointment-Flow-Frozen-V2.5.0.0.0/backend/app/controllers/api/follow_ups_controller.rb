module Api
  class FollowUpsController < StaffController
    def create
      item = clinic.work_items.find(params[:work_item_id])
      action = StaffFollowUp.call(item: item, staff: staff, outcome: params[:outcome], note: params[:note],
        visit_id: params[:visit_id], event_id: params[:event_id])
      return render_error(clinic.reload.source_error, :service_unavailable) unless action

      render json: { outcome: action.outcome }
    rescue StaffFollowUp::Invalid => error
      render_error(error.message)
    end
  end
end
