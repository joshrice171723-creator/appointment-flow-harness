module Api
  class DemoPatientsController < ApplicationController
    def index
      clinic = Clinic.find(params[:demo_clinic_id])
      render json: { patients: clinic.patients.order(:name, :id).as_json(only: %i[id name]) }
    end

    def show
      clinic = Clinic.find(params[:demo_clinic_id])
      patient = clinic.patients.find(params[:id])
      render json: { messages: inbox_messages(patient) }
    end

    private

    def inbox_messages(patient)
      deliveries = patient.deliveries.where(status: "sent").order(occurred_at: :desc, id: :desc).limit(100)
      replies = patient.replies.order(occurred_at: :desc, id: :desc).limit(100)
      (deliveries.map { |entry| message(entry, "outgoing") } +
        replies.map { |entry| message(entry, "incoming") }).sort_by { |entry| entry[:occurred_at] }
    end

    def message(entry, direction)
      { id: "#{direction}-#{entry.id}", direction: direction, channel: entry.channel, body: entry.body,
        occurred_at: entry.occurred_at }
    end
  end
end
