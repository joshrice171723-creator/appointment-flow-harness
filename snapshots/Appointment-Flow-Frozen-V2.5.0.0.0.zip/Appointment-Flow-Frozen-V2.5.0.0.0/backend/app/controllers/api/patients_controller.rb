module Api
  class PatientsController < StaffController
    include VisitViews

    def show
      patient = clinic.patients.find(params[:id])
      visits = patient.visits.includes(:patient).order(wall_start: :desc).limit(75).to_a
      items = patient.work_items.includes(:patient, :assignee, :visit, :reply).order(opened_at: :desc).to_a
      candidates = clinic.visits.where(id: items.flat_map { |item| item.candidates.keys }).includes(:patient).index_by(&:id)
      review_ids = review_ids_for(visits)
      render json: sync_status.merge(
        patient: patient.as_json(only: %i[id name]),
        contacts: Patient::EDITABLE_FIELDS.index_with do |field|
          { value: patient.contact(field), verified: patient.verified_contact.key?(field), conflict: patient.conflict?(field),
            source: patient.source_contact[field] }
        end,
        visits: visits.map { |visit| visit_view(visit, review_ids) },
        items: items.map { |item| WorkItemView.detail(item, candidates) },
        activity: patient.staff_actions.includes(:staff_member).order(occurred_at: :desc, id: :desc).limit(100)
          .map { |action| action.as_json(only: %i[outcome note occurred_at]).merge(staff: action.staff_member.name) }
      )
    end
  end
end
