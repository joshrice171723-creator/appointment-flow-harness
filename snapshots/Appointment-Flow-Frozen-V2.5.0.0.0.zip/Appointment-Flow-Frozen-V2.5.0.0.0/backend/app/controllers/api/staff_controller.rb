module Api
  class StaffController < ApplicationController
    before_action :require_staff
    attr_reader :clinic, :staff

    private

    def require_staff
      @staff = StaffMember.includes(:clinic).find_by(id: session[:staff_id])
      return render_error("Choose a clinic and staff identity in Workspaces.", :unauthorized) unless @staff

      @clinic = staff.clinic
      if params[:clinic_id].to_s != clinic.id.to_s
        render_error("This staff session belongs to another clinic. Return to Workspaces to switch.", :forbidden)
      end
    end

    def sync_status
      { synced_at: clinic.synced_at, source_error: clinic.source_error,
        today: DemoClock.now.in_time_zone(clinic.zone).to_date.iso8601 }
    end
  end
end
