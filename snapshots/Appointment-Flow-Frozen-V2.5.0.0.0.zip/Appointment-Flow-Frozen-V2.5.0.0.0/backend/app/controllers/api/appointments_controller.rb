module Api
  class AppointmentsController < StaffController
    include VisitViews

    def index
      date = parse_date(params.require(:date))
      return render_error("Choose a valid appointment date.") unless date

      monday = date.beginning_of_week
      week = clinic.visits.where(wall_start: monday.iso8601...(monday + 7).iso8601)
      counts = week.group(Arel.sql("left(wall_start, 10)")).count
      visits = week.where(wall_start: date.iso8601...(date + 1).iso8601).includes(:patient).order(:wall_start).to_a
      review_ids = review_ids_for(visits)
      render json: sync_status.merge(counts: counts, visits: visits.map { |visit| visit_view(visit, review_ids) })
    end

    private

    def parse_date(value)
      return unless value.is_a?(String) && value.match?(/\A\d{4}-\d{2}-\d{2}\z/)

      Date.iso8601(value)
    rescue Date::Error
      nil
    end
  end
end
