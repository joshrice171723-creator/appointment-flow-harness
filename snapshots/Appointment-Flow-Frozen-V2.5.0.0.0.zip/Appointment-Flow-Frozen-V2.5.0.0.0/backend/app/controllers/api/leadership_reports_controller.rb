module Api
  class LeadershipReportsController < ApplicationController
    def show
      month = report_month(params[:month])
      return render_error("Choose a valid reporting month.") unless month

      months = (0..2).map { |offset| month << offset }
      render json: {
        month: month.strftime("%Y-%m"), current_month: DemoClock.now.strftime("%Y-%m"),
        clinics: Clinic.order(:name).map do |clinic|
          { name: clinic.name, history: months.map { |period| summarize_month(clinic, period) } }
        end
      }
    end

    private

    def report_month(value)
      return DemoClock.now.to_date.beginning_of_month if value.blank?
      return unless value.is_a?(String) && value.match?(/\A\d{4}-\d{2}\z/)

      Date.iso8601("#{value}-01")
    rescue Date::Error
      nil
    end

    def summarize_month(clinic, month)
      next_month = month.next_month
      visits = clinic.visits.where(wall_start: month.iso8601...next_month.iso8601).where.not(source_status: "source_missing")
      status_counts = visits.group(:source_status, :staff_disposition).count
      outcomes = { completed: 0, rescheduled: 0, canceled: 0, unknown: 0 }
      status_counts.each do |(status, disposition), total|
        category = if status == "complete"
          :completed
        elsif %w[rescheduled canceled].include?(disposition)
          disposition.to_sym
        else
          :unknown
        end
        outcomes[category] += total
      end
      window = clinic.zone.local(month.year, month.month)...clinic.zone.local(next_month.year, next_month.month)
      outcomes.merge(month: month.strftime("%Y-%m"), recorded: outcomes.values.sum,
        sent: clinic.deliveries.where(occurred_at: window, status: "sent").count,
        failed: clinic.deliveries.where(occurred_at: window, status: "failed").count,
        holds: clinic.work_items.where(opened_at: window, kind: "contact_hold").count,
        assigned: clinic.work_items.where(opened_at: window).where.not(assignee_id: nil).count,
        follow_ups: clinic.staff_actions.where(occurred_at: window).where.not(work_item_id: nil).count)
    end
  end
end
