class ApplicationController < ActionController::API
  before_action :require_json_write
  before_action { response.headers["Cache-Control"] = "no-store" }

  rescue_from ActiveRecord::RecordNotFound do
    render_error("That record could not be found in this clinic.", :not_found)
  end

  rescue_from ActionController::ParameterMissing do
    render_error("A required field is missing.", :bad_request)
  end

  private

  def render_error(message, status = :unprocessable_content)
    render json: { error: message }, status: status
  end

  def require_json_write
    return if request.get? || request.head? || request.media_type == "application/json"

    render_error("Send this request as JSON.", :unsupported_media_type)
  end
end
