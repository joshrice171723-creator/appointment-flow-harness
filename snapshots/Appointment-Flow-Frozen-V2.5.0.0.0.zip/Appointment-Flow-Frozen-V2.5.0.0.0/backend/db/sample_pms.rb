module SamplePms
  CLINICS = [
    { id: 1, name: "Austin", city: "Austin", state: "TX", address_line: "18 Example Road", phone: "512-555-0100" },
    { id: 2, name: "Phoenix", city: "Phoenix", state: "AZ", address_line: "24 Sample Avenue", phone: "602-555-0100" }
  ].freeze
  ZONES = { 1 => "America/Chicago", 2 => "America/Phoenix" }.freeze
  STAFF = { 1 => [ "Taylor Morgan", "Morgan Lee" ], 2 => [ "Jordan Reyes", "Casey Reed" ] }.freeze
  NAMES = [
    [ "Avery", "Chen" ], [ "Marisol", "Reyes" ], [ "Sam", "Patel" ], [ "Riley", "Nguyen" ],
    [ "Drew", "Cole" ], [ "Jules", "Rivera" ], [ "Robin", "Hayes" ], [ "Kai", "Rivera" ],
    [ "Ellis", "Gray" ], [ "Rowan", "Kim" ], [ "Elliot", "Boone" ], [ "Dana", "Brooks" ]
  ].freeze

  def self.seed!
    ApplicationRecord.transaction do
      CLINICS.each do |clinic_data|
        insert("pms.clinics", clinic_data)
        clinic = Clinic.find_or_create_by!(source_id: clinic_data[:id]) do |local|
          local.name = clinic_data[:name]
          local.timezone = ZONES.fetch(local.source_id)
        end
        STAFF.fetch(clinic.source_id).each { |name| clinic.staff_members.find_or_create_by!(name: name) }
        seed_clinic(clinic)
      end
    end
  end

  def self.seed_clinic(clinic)
    today = DemoClock.now.in_time_zone(clinic.zone).to_date
    prefix = clinic.source_id == 1 ? "512" : "602"
    NAMES.each_with_index do |(first, last), index|
      number = index + 1
      patient_id = clinic.source_id * 100 + number
      phone = "#{prefix}-555-#{format('%04d', 100 + number)}"
      phone = "#{prefix}-555-0106" if number == 8
      phone = nil if [ 2, 3 ].include?(number)
      email = "#{first.downcase}.#{last.downcase}.#{clinic.source_id}@example.test" unless [ 3, 6, 8 ].include?(number)
      insert("pms.patients", id: patient_id, first_name: first, last_name: last,
        birthdate: (number == 5 ? today.years_ago(14) : Date.new(1982 + index, 4, 8)),
        wireless_phone: phone, email: email, preferred_language: { 2 => "es", 4 => "fr" }.fetch(number, "en"))
      days = [ 7, 7, 1, 1, 2, 0, 7, 0, 0, 0, 2, 4 ][index]
      hour = index.odd? ? 14 : 15
      create_visit(clinic, patient_id, clinic.source_id * 1000 + number, today + days, hour, "scheduled")
      create_visit(clinic, patient_id, clinic.source_id * 1000 + 100 + number,
        today.beginning_of_month + index, 9, number % 4 == 0 ? "broken" : "complete")
      [ 1, 2 ].each do |offset|
        create_visit(clinic, patient_id, clinic.source_id * 1000 + (offset + 1) * 100 + number,
          (today.beginning_of_month << offset) + index, 10, number % (offset + 3) == 0 ? "unscheduled" : "complete")
      end
    end
  end

  def self.create_visit(clinic, patient_id, id, date, hour, status)
    wall = "#{date.iso8601} #{format('%02d', hour)}:00:00"
    insert("pms.appointments", id: id, patient_id: patient_id, clinic_id: clinic.source_id,
      provider_name: clinic.source_id == 1 ? "Dr. Jordan Park" : "Dr. Jules Moreno",
      start_at: wall, length_minutes: 45, status: status, updated_at: wall)
  end

  def self.insert(table, row)
    ApplicationRecord.with_connection do |connection|
      columns = row.keys.map { |column| connection.quote_column_name(column) }.join(", ")
      values = row.values.map { |value| connection.quote(value) }.join(", ")
      connection.execute("INSERT INTO #{connection.quote_table_name(table)} (#{columns}) VALUES (#{values}) ON CONFLICT (id) DO NOTHING")
    end
  end
end
