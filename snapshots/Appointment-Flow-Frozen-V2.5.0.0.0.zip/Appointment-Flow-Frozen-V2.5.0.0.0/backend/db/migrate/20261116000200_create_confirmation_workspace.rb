class CreateConfirmationWorkspace < ActiveRecord::Migration[8.1]
  def change
    create_table :clinics do |table|
      table.bigint :source_id, null: false, index: { unique: true }
      table.string :name, null: false
      table.string :timezone, null: false
      table.datetime :synced_at
      table.string :source_error
    end

    create_table :staff_members do |table|
      table.references :clinic, null: false, foreign_key: true
      table.string :name, null: false
      table.index [ :clinic_id, :name ], unique: true
    end

    create_table :patients do |table|
      table.references :clinic, null: false, foreign_key: true
      table.bigint :source_id, null: false
      table.string :name, null: false
      table.jsonb :source_contact, null: false, default: {}
      table.jsonb :verified_contact, null: false, default: {}
      table.string :sms_address
      table.string :email_address
      table.index [ :clinic_id, :source_id ], unique: true
      table.index [ :clinic_id, :sms_address ]
      table.index [ :clinic_id, :email_address ]
    end

    create_table :visits do |table|
      table.references :clinic, null: false, foreign_key: true
      table.references :patient, null: false, foreign_key: true
      table.bigint :source_id, null: false
      table.string :wall_start, null: false
      table.datetime :starts_at
      table.string :source_status, null: false
      table.string :provider
      table.integer :minutes
      table.integer :revision, null: false, default: 1
      table.datetime :confirmed_at
      table.string :staff_disposition
      table.index [ :clinic_id, :source_id ], unique: true
      table.index [ :clinic_id, :starts_at ]
      table.index [ :clinic_id, :wall_start ]
    end

    create_table :deliveries do |table|
      table.references :clinic, null: false, foreign_key: true
      table.references :patient, null: false, foreign_key: true
      table.references :visit, null: false, foreign_key: true
      table.integer :revision, null: false
      table.string :step, null: false
      table.string :channel, null: false
      table.string :recipient, null: false
      table.text :body, null: false
      table.datetime :occurred_at, null: false
      table.boolean :request_confirmation, null: false
      table.string :status, null: false
      table.index [ :visit_id, :revision, :step ], unique: true
      table.index [ :clinic_id, :channel, :recipient, :occurred_at ]
    end

    create_table :replies do |table|
      table.references :clinic, null: false, foreign_key: true
      table.references :patient, null: false, foreign_key: true
      table.string :event_id, null: false
      table.string :channel, null: false
      table.string :recipient
      table.text :body, null: false
      table.datetime :occurred_at, null: false
      table.string :outcome, null: false
      table.index [ :clinic_id, :event_id ], unique: true
    end

    create_table :sms_opt_outs do |table|
      table.references :clinic, null: false, foreign_key: true
      table.string :recipient, null: false
      table.datetime :occurred_at, null: false
      table.index [ :clinic_id, :recipient ], unique: true
    end

    create_table :work_items do |table|
      table.references :clinic, null: false, foreign_key: true
      table.references :patient, null: false, foreign_key: true
      table.references :visit, foreign_key: true
      table.references :reply, foreign_key: true, index: { unique: true }
      table.references :assignee, foreign_key: { to_table: :staff_members }
      table.string :kind, null: false
      table.string :reason, null: false
      table.string :key, null: false
      table.integer :revision
      table.jsonb :candidates, null: false, default: {}
      table.datetime :opened_at, null: false
      table.datetime :resolved_at
      table.index [ :clinic_id, :key ], unique: true
      table.index [ :clinic_id, :resolved_at, :assignee_id ]
    end

    create_table :staff_actions do |table|
      table.references :clinic, null: false, foreign_key: true
      table.references :patient, null: false, foreign_key: true
      table.references :work_item, foreign_key: true
      table.references :staff_member, null: false, foreign_key: true
      table.string :event_id, null: false
      table.string :outcome, null: false
      table.text :note, null: false
      table.jsonb :changes_recorded, null: false, default: {}
      table.datetime :occurred_at, null: false
      table.index [ :clinic_id, :event_id ], unique: true
    end
  end
end
