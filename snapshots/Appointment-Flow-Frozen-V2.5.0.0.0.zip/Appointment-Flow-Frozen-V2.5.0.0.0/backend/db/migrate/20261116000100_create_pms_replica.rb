class CreatePmsReplica < ActiveRecord::Migration[8.1]
  def change
    create_schema "pms"

    create_table "pms.clinics" do |table|
      table.text :name, null: false
      table.text :address_line
      table.text :city
      table.column :state, "char(2)"
      table.text :phone
    end

    create_table "pms.patients" do |table|
      table.text :first_name, null: false
      table.text :last_name, null: false
      table.date :birthdate
      table.text :wireless_phone
      table.text :email
      table.text :preferred_language
      table.references :guarantor, foreign_key: { to_table: "pms.patients" }
    end

    create_table "pms.appointments" do |table|
      table.references :patient, null: false, foreign_key: { to_table: "pms.patients" }
      table.references :clinic, null: false, foreign_key: { to_table: "pms.clinics" }
      table.text :provider_name
      table.column :start_at, "timestamp without time zone", null: false
      table.integer :length_minutes
      table.text :procedure_note
      table.text :status, null: false
      table.column :updated_at, "timestamp without time zone"
      table.index [ :clinic_id, :start_at ]
    end
  end
end
