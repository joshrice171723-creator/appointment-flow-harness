class IndexSourceContactAddresses < ActiveRecord::Migration[8.1]
  def change
    add_column :patients, :source_sms_address, :string
    add_column :patients, :source_email_address, :string
    add_index :patients, [ :clinic_id, :source_sms_address ]
    add_index :patients, [ :clinic_id, :source_email_address ]
  end
end
