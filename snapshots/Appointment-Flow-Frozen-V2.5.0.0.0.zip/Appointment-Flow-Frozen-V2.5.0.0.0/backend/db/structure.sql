SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pms; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pms;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.appointments (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    provider_name text,
    start_at timestamp without time zone NOT NULL,
    length_minutes integer,
    procedure_note text,
    status text NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.appointments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.appointments_id_seq OWNED BY pms.appointments.id;


--
-- Name: clinics; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.clinics (
    id bigint NOT NULL,
    name text NOT NULL,
    address_line text,
    city text,
    state character(2),
    phone text
);


--
-- Name: clinics_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.clinics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinics_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.clinics_id_seq OWNED BY pms.clinics.id;


--
-- Name: patients; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.patients (
    id bigint NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    birthdate date,
    wireless_phone text,
    email text,
    preferred_language text,
    guarantor_id bigint
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: pms; Owner: -
--

CREATE SEQUENCE pms.patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: pms; Owner: -
--

ALTER SEQUENCE pms.patients_id_seq OWNED BY pms.patients.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: clinics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinics (
    id bigint NOT NULL,
    source_id bigint NOT NULL,
    name character varying NOT NULL,
    timezone character varying NOT NULL,
    synced_at timestamp(6) without time zone,
    source_error character varying
);


--
-- Name: clinics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clinics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clinics_id_seq OWNED BY public.clinics.id;


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deliveries (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    visit_id bigint NOT NULL,
    revision integer NOT NULL,
    step character varying NOT NULL,
    channel character varying NOT NULL,
    recipient character varying NOT NULL,
    body text NOT NULL,
    occurred_at timestamp(6) without time zone NOT NULL,
    request_confirmation boolean NOT NULL,
    status character varying NOT NULL
);


--
-- Name: deliveries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deliveries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deliveries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deliveries_id_seq OWNED BY public.deliveries.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    source_id bigint NOT NULL,
    name character varying NOT NULL,
    source_contact jsonb DEFAULT '{}'::jsonb NOT NULL,
    verified_contact jsonb DEFAULT '{}'::jsonb NOT NULL,
    sms_address character varying,
    email_address character varying,
    source_sms_address character varying,
    source_email_address character varying
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.replies (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    event_id character varying NOT NULL,
    channel character varying NOT NULL,
    recipient character varying,
    body text NOT NULL,
    occurred_at timestamp(6) without time zone NOT NULL,
    outcome character varying NOT NULL
);


--
-- Name: replies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.replies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: replies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.replies_id_seq OWNED BY public.replies.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: sms_opt_outs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_opt_outs (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    recipient character varying NOT NULL,
    occurred_at timestamp(6) without time zone NOT NULL
);


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_opt_outs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_opt_outs_id_seq OWNED BY public.sms_opt_outs.id;


--
-- Name: staff_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_actions (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    work_item_id bigint,
    staff_member_id bigint NOT NULL,
    event_id character varying NOT NULL,
    outcome character varying NOT NULL,
    note text NOT NULL,
    changes_recorded jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp(6) without time zone NOT NULL
);


--
-- Name: staff_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_actions_id_seq OWNED BY public.staff_actions.id;


--
-- Name: staff_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_members (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    name character varying NOT NULL
);


--
-- Name: staff_members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_members_id_seq OWNED BY public.staff_members.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visits (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    source_id bigint NOT NULL,
    wall_start character varying NOT NULL,
    starts_at timestamp(6) without time zone,
    source_status character varying NOT NULL,
    provider character varying,
    minutes integer,
    revision integer DEFAULT 1 NOT NULL,
    confirmed_at timestamp(6) without time zone,
    staff_disposition character varying
);


--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_items (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    visit_id bigint,
    reply_id bigint,
    assignee_id bigint,
    kind character varying NOT NULL,
    reason character varying NOT NULL,
    key character varying NOT NULL,
    revision integer,
    candidates jsonb DEFAULT '{}'::jsonb NOT NULL,
    opened_at timestamp(6) without time zone NOT NULL,
    resolved_at timestamp(6) without time zone
);


--
-- Name: work_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_items_id_seq OWNED BY public.work_items.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments ALTER COLUMN id SET DEFAULT nextval('pms.appointments_id_seq'::regclass);


--
-- Name: clinics id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics ALTER COLUMN id SET DEFAULT nextval('pms.clinics_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients ALTER COLUMN id SET DEFAULT nextval('pms.patients_id_seq'::regclass);


--
-- Name: clinics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics ALTER COLUMN id SET DEFAULT nextval('public.clinics_id_seq'::regclass);


--
-- Name: deliveries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries ALTER COLUMN id SET DEFAULT nextval('public.deliveries_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: replies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies ALTER COLUMN id SET DEFAULT nextval('public.replies_id_seq'::regclass);


--
-- Name: sms_opt_outs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs ALTER COLUMN id SET DEFAULT nextval('public.sms_opt_outs_id_seq'::regclass);


--
-- Name: staff_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_actions ALTER COLUMN id SET DEFAULT nextval('public.staff_actions_id_seq'::regclass);


--
-- Name: staff_members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_members ALTER COLUMN id SET DEFAULT nextval('public.staff_members_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: work_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items ALTER COLUMN id SET DEFAULT nextval('public.work_items_id_seq'::regclass);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: replies replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sms_opt_outs sms_opt_outs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs
    ADD CONSTRAINT sms_opt_outs_pkey PRIMARY KEY (id);


--
-- Name: staff_actions staff_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_actions
    ADD CONSTRAINT staff_actions_pkey PRIMARY KEY (id);


--
-- Name: staff_members staff_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_members
    ADD CONSTRAINT staff_members_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (id);


--
-- Name: index_appointments_on_clinic_id; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX index_appointments_on_clinic_id ON pms.appointments USING btree (clinic_id);


--
-- Name: index_appointments_on_clinic_id_and_start_at; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX index_appointments_on_clinic_id_and_start_at ON pms.appointments USING btree (clinic_id, start_at);


--
-- Name: index_appointments_on_patient_id; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX index_appointments_on_patient_id ON pms.appointments USING btree (patient_id);


--
-- Name: index_patients_on_guarantor_id; Type: INDEX; Schema: pms; Owner: -
--

CREATE INDEX index_patients_on_guarantor_id ON pms.patients USING btree (guarantor_id);


--
-- Name: idx_on_clinic_id_channel_recipient_occurred_at_4828c1906e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_on_clinic_id_channel_recipient_occurred_at_4828c1906e ON public.deliveries USING btree (clinic_id, channel, recipient, occurred_at);


--
-- Name: index_clinics_on_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_clinics_on_source_id ON public.clinics USING btree (source_id);


--
-- Name: index_deliveries_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deliveries_on_clinic_id ON public.deliveries USING btree (clinic_id);


--
-- Name: index_deliveries_on_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deliveries_on_patient_id ON public.deliveries USING btree (patient_id);


--
-- Name: index_deliveries_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deliveries_on_visit_id ON public.deliveries USING btree (visit_id);


--
-- Name: index_deliveries_on_visit_id_and_revision_and_step; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_deliveries_on_visit_id_and_revision_and_step ON public.deliveries USING btree (visit_id, revision, step);


--
-- Name: index_patients_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_patients_on_clinic_id ON public.patients USING btree (clinic_id);


--
-- Name: index_patients_on_clinic_id_and_email_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_patients_on_clinic_id_and_email_address ON public.patients USING btree (clinic_id, email_address);


--
-- Name: index_patients_on_clinic_id_and_sms_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_patients_on_clinic_id_and_sms_address ON public.patients USING btree (clinic_id, sms_address);


--
-- Name: index_patients_on_clinic_id_and_source_email_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_patients_on_clinic_id_and_source_email_address ON public.patients USING btree (clinic_id, source_email_address);


--
-- Name: index_patients_on_clinic_id_and_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_patients_on_clinic_id_and_source_id ON public.patients USING btree (clinic_id, source_id);


--
-- Name: index_patients_on_clinic_id_and_source_sms_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_patients_on_clinic_id_and_source_sms_address ON public.patients USING btree (clinic_id, source_sms_address);


--
-- Name: index_replies_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_clinic_id ON public.replies USING btree (clinic_id);


--
-- Name: index_replies_on_clinic_id_and_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_replies_on_clinic_id_and_event_id ON public.replies USING btree (clinic_id, event_id);


--
-- Name: index_replies_on_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_replies_on_patient_id ON public.replies USING btree (patient_id);


--
-- Name: index_sms_opt_outs_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sms_opt_outs_on_clinic_id ON public.sms_opt_outs USING btree (clinic_id);


--
-- Name: index_sms_opt_outs_on_clinic_id_and_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_sms_opt_outs_on_clinic_id_and_recipient ON public.sms_opt_outs USING btree (clinic_id, recipient);


--
-- Name: index_staff_actions_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_actions_on_clinic_id ON public.staff_actions USING btree (clinic_id);


--
-- Name: index_staff_actions_on_clinic_id_and_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_staff_actions_on_clinic_id_and_event_id ON public.staff_actions USING btree (clinic_id, event_id);


--
-- Name: index_staff_actions_on_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_actions_on_patient_id ON public.staff_actions USING btree (patient_id);


--
-- Name: index_staff_actions_on_staff_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_actions_on_staff_member_id ON public.staff_actions USING btree (staff_member_id);


--
-- Name: index_staff_actions_on_work_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_actions_on_work_item_id ON public.staff_actions USING btree (work_item_id);


--
-- Name: index_staff_members_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_staff_members_on_clinic_id ON public.staff_members USING btree (clinic_id);


--
-- Name: index_staff_members_on_clinic_id_and_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_staff_members_on_clinic_id_and_name ON public.staff_members USING btree (clinic_id, name);


--
-- Name: index_visits_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_clinic_id ON public.visits USING btree (clinic_id);


--
-- Name: index_visits_on_clinic_id_and_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_visits_on_clinic_id_and_source_id ON public.visits USING btree (clinic_id, source_id);


--
-- Name: index_visits_on_clinic_id_and_starts_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_clinic_id_and_starts_at ON public.visits USING btree (clinic_id, starts_at);


--
-- Name: index_visits_on_clinic_id_and_wall_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_clinic_id_and_wall_start ON public.visits USING btree (clinic_id, wall_start);


--
-- Name: index_visits_on_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_visits_on_patient_id ON public.visits USING btree (patient_id);


--
-- Name: index_work_items_on_assignee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_assignee_id ON public.work_items USING btree (assignee_id);


--
-- Name: index_work_items_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_clinic_id ON public.work_items USING btree (clinic_id);


--
-- Name: index_work_items_on_clinic_id_and_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_work_items_on_clinic_id_and_key ON public.work_items USING btree (clinic_id, key);


--
-- Name: index_work_items_on_clinic_id_and_resolved_at_and_assignee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_clinic_id_and_resolved_at_and_assignee_id ON public.work_items USING btree (clinic_id, resolved_at, assignee_id);


--
-- Name: index_work_items_on_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_patient_id ON public.work_items USING btree (patient_id);


--
-- Name: index_work_items_on_reply_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_work_items_on_reply_id ON public.work_items USING btree (reply_id);


--
-- Name: index_work_items_on_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_items_on_visit_id ON public.work_items USING btree (visit_id);


--
-- Name: appointments fk_rails_12044a3e25; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT fk_rails_12044a3e25 FOREIGN KEY (patient_id) REFERENCES pms.patients(id);


--
-- Name: patients fk_rails_6a0da623bd; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT fk_rails_6a0da623bd FOREIGN KEY (guarantor_id) REFERENCES pms.patients(id);


--
-- Name: appointments fk_rails_adda5689a7; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT fk_rails_adda5689a7 FOREIGN KEY (clinic_id) REFERENCES pms.clinics(id);


--
-- Name: staff_actions fk_rails_14bc6e6c5a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_actions
    ADD CONSTRAINT fk_rails_14bc6e6c5a FOREIGN KEY (staff_member_id) REFERENCES public.staff_members(id);


--
-- Name: deliveries fk_rails_24bbbf0474; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT fk_rails_24bbbf0474 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: staff_actions fk_rails_3a4e1b54f3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_actions
    ADD CONSTRAINT fk_rails_3a4e1b54f3 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: sms_opt_outs fk_rails_583ef9e326; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs
    ADD CONSTRAINT fk_rails_583ef9e326 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: visits fk_rails_67f7d0e40e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_67f7d0e40e FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: work_items fk_rails_786737efa4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_786737efa4 FOREIGN KEY (reply_id) REFERENCES public.replies(id);


--
-- Name: replies fk_rails_86583a924c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT fk_rails_86583a924c FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: staff_actions fk_rails_8d93fd8caa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_actions
    ADD CONSTRAINT fk_rails_8d93fd8caa FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: deliveries fk_rails_93f51727ef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT fk_rails_93f51727ef FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: staff_actions fk_rails_945db64f1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_actions
    ADD CONSTRAINT fk_rails_945db64f1a FOREIGN KEY (work_item_id) REFERENCES public.work_items(id);


--
-- Name: replies fk_rails_9b00828391; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT fk_rails_9b00828391 FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: deliveries fk_rails_a1b2888975; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT fk_rails_a1b2888975 FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: work_items fk_rails_ae0b388133; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_ae0b388133 FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: visits fk_rails_bb2bb87b38; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_rails_bb2bb87b38 FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: work_items fk_rails_d67ee6520f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_d67ee6520f FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: work_items fk_rails_dcefa2a8ff; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_dcefa2a8ff FOREIGN KEY (visit_id) REFERENCES public.visits(id);


--
-- Name: staff_members fk_rails_e8e2a9764f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_members
    ADD CONSTRAINT fk_rails_e8e2a9764f FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: work_items fk_rails_fea1a9c758; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT fk_rails_fea1a9c758 FOREIGN KEY (assignee_id) REFERENCES public.staff_members(id);


--
-- Name: patients fk_rails_ffa68283b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT fk_rails_ffa68283b8 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO "$user", public;

INSERT INTO "schema_migrations" (version) VALUES
('20261116000300'),
('20261116000200'),
('20261116000100');
