require_relative "sample_pms"

SamplePms.seed!

Clinic.order(:id).each do |clinic|
  result = ReminderBatch.call(clinic)
  raise clinic.reload.source_error unless result

  puts "#{clinic.name}: #{result[:sent]} fake sends, #{result[:failed]} fake failures"
end

austin = Clinic.find_by!(source_id: 1)
staff = austin.staff_members.first
work = austin.work_items.open.where(kind: "no_confirmation").joins(:visit)
in_progress = work.find_by(visits: { source_id: 1009 })
in_progress&.update!(assignee: staff) if in_progress&.assignee_id.nil?
if (resolved = work.find_by(visits: { source_id: 1010 })) && resolved.assignee_id.nil?
  resolved.update!(assignee: staff)
  StaffFollowUp.call(item: resolved, staff: staff, outcome: "confirmed", note: "Confirmed by phone.",
    visit_id: nil, event_id: SecureRandom.uuid)
end
