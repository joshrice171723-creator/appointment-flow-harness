# Project context

## Purpose

Josh added this map in response to the clarity requirement on page 5 of the take-home assessment.

> Clarity. Someone on our team could pick up your code and your notes next month and keep going.

He doesn't expect someone to actually take over this project next month. This shows how he would leave it ready for someone who did. The map helps a reviewer find the code, understand the choices, and see what changed, including where Josh pushed back on the AI's work. They can also give it to their AI to help it understand the project.

This is a starting point. Follow the links for the details; it doesn't repeat the whole history or grade the work.

## Active source

The package contains the app, setup instructions, and engineering notes. Run the commands from the extracted project root.

Contributors should read [AGENTS.md](docs/ai-harness/AGENTS.md) before making changes.

## Where to find answers

| Question | Source |
| --- | --- |
| What does the app do, and how do I run it? | [README.md](README.md) |
| How does the current implementation fit together? | [ARCHITECTURE.md](ARCHITECTURE.md) |
| Why were these choices made? | [DECISIONS.md](DECISIONS.md) |
| How was AI involved, and where did Josh challenge its work? | [AI_USAGE.md](AI_USAGE.md) |
| What standard guides readability reviews? | [Human code-quality rubric](docs/ai-harness/apex-human-code-quality-rubric-2026-11-06.md) |
| What did the weighted code-quality review find? | [Code quality history](docs/code-quality-history.md) |
| Which paths reach which controller actions? | [Routes](backend/config/routes.rb) |
| Where are the backend performance measurements? | [Test performance audit](TEST_PERFORMANCE_AUDIT.md) |

## Recent decisions worth understanding

- Database changes use Rails migrations, and sample data is built in Ruby. Old SQL-based demo databases must be rebuilt; their upgrade path was deliberately removed.
- Controllers separate front-desk, patient, leadership, and workspace selection. ApplicationController handles shared request protection and errors. The write operations own their transactions.
- Routes distinguish browser pages from API operations and group API paths by app area. Their organization should help a person find the responsible action.
- Passing tests and AI rubric scores do not establish that Josh accepts the code's readability. His controller and route feedback continued after earlier rubric-driven changes.
- The rubric evaluates whether a developer can find, follow, and change the code. Josh intends to reuse it on future projects with appropriate project-specific examples.

See the architecture, decision record, and AI usage record for the explanations behind these points. Check current source before treating this summary as proof of behavior.

## Reading the record of changes

Use AI_USAGE.md for the account of AI involvement and Josh's corrections, DECISIONS.md for design rationale, and Git for committed changes. Check `git status` and `git diff` for pending work; a commit does not include uncommitted changes.

Treat test results and review reports as evidence for the revision and scope they examined. Older rubric reports are historical records, not current scores. Keep executed checks, AI assessments, and Josh's acceptance distinct.

When behavior or a decision changes, update its owning document. Keep this map brief and update links or summaries when needed instead of duplicating detailed history here.
