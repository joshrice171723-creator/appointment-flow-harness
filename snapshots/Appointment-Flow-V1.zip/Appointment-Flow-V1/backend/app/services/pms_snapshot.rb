class PmsSnapshot
  APPOINTMENT_IMPORT_BATCH_SIZE = 2_000
  COLUMNS = {
    "clinics" => %w[id name address_line city state phone],
    "patients" => %w[id first_name last_name birthdate wireless_phone email preferred_language guarantor_id],
    "appointments" => %w[
      id patient_id clinic_id provider_name start_at length_minutes procedure_note status updated_at
    ]
  }.freeze

  CACHE_MODELS = { "clinics" => Clinic, "patients" => Patient, "appointments" => Appointment }.freeze

  def initialize(read_snapshot: nil)
    @read_snapshot = read_snapshot
  end

  def refresh(observed_at: nil, &configure_clinics)
    ApplicationRecord.transaction do
      Database.lock_snapshot
      import_snapshot(observed_at: observed_at || Time.current, &configure_clinics)
    end
  end

  def refresh_if_stale
    return unless SourceSync.status["stale"]

    ApplicationRecord.transaction do
      Database.lock_snapshot
      import_snapshot(observed_at: Time.current) if SourceSync.status["stale"]
    end
  end

  private

  # The cache rows and freshness timestamp commit or roll back together.
  def import_snapshot(observed_at:)
    if @read_snapshot
      snapshot = @read_snapshot.call
    else
      since = appointment_history_start(observed_at)
      watched_ids = watched_appointment_ids(since)
      snapshot = PmsReplica.read(appointments_since: since, appointment_ids: watched_ids)
    end
    validate_snapshot!(snapshot)
    if watched_ids.present? && snapshot.fetch("appointments").empty?
      raise ReminderFlow::Conflict, "PMS returned no appointments while the app is tracking appointments."
    end
    upsert_source_records(snapshot)
    reconcile_patient_details(snapshot.fetch("patients"), at: observed_at)
    yield snapshot if block_given?
    grant_default_demo_permissions
    mark_missing_scheduled_appointments(snapshot.fetch("appointments"), watched_ids: watched_ids)
    record_sync_time
  rescue KeyError => error
    raise ReminderFlow::Conflict, "PMS snapshot unavailable: #{error.class}."
  end

  def appointment_history_start(observed_at)
    previous_month = observed_at.to_date.prev_month.beginning_of_month
    launch = ENV["ASSESSMENT_REMINDERS_START"].presence
    return previous_month unless launch

    [previous_month, Date.iso8601(launch).prev_month.beginning_of_month].min
  end

  def watched_appointment_ids(since)
    open_visit_ids = FollowUpIssue.open.flat_map { |issue| [issue.visit_id, *issue.affected_visit_ids] }
    tracked = Visit.current.or(Visit.where(id: open_visit_ids)).distinct.pluck(:appointment_id)
    # An appointment that moves before the cutoff must still be read by ID.
    tracked | Appointment.scheduled.where(start_at: since..).pluck(:id)
  end

  def reconcile_patient_details(patients, at:)
    patient_ids = patients.to_set { |row| row.fetch("id") }
    PatientDetailVerification.active.includes(:patient).find_each do |verification|
      verification.reconcile_source!(at: at) if patient_ids.include?(verification.patient_id)
    end
  end

  def validate_snapshot!(snapshot)
    raise ReminderFlow::Conflict, "Invalid PMS snapshot." unless snapshot.is_a?(Hash)

    COLUMNS.each_key do |table|
      records = snapshot.fetch(table)
      unless records.is_a?(Array) && records.all? { |record| record.is_a?(Hash) }
        raise ReminderFlow::Conflict, "Invalid PMS snapshot."
      end
    end
  end

  def upsert_source_records(snapshot)
    COLUMNS.each do |table, columns|
      model = CACHE_MODELS.fetch(table)
      records = snapshot.fetch(table)
      batches = table == "appointments" ? records.each_slice(APPOINTMENT_IMPORT_BATCH_SIZE) : [records]
      batches.each do |batch|
        rows = batch.map { |record| columns.to_h { |column| [column, record[column]] } }
        model.upsert_all(rows, unique_by: :id, returning: false, record_timestamps: false,
                         on_duplicate: update_changed_rows(model, columns.drop(1)))
      end
    end
  end

  def update_changed_rows(model, columns)
    names = columns.map { |column| model.connection.quote_column_name(column) }
    incoming = names.map { |name| "EXCLUDED.#{name}" }

    # Skip unchanged rows so a periodic refresh does not rewrite the entire cache.
    Arel.sql("(#{names.join(', ')}) = ROW(#{incoming.join(', ')}) " \
             "WHERE #{model.quoted_table_name}.* IS DISTINCT FROM EXCLUDED.*")
  end

  def grant_default_demo_permissions
    pairs = Appointment.where(clinic_id: ClinicSetting.select(:clinic_id))
                       .distinct.pluck(:patient_id, :clinic_id)
    permissions = pairs.map do |patient_id, clinic_id|
      { patient_id: patient_id, clinic_id: clinic_id, sms: true, email: true }
    end

    # Existing permissions, including revocations, take precedence.
    ContactPermission.insert_all(permissions, returning: false)
  end

  def mark_missing_scheduled_appointments(appointments, watched_ids:)
    # A missing appointment leaves outreach without counting as a scheduling outcome.
    source_ids = appointments.map { |appointment| appointment.fetch("id") }
    missing = if watched_ids
      Appointment.scheduled.where(id: watched_ids - source_ids)
    else
      Appointment.scheduled.where.not(id: source_ids)
    end
    missing.update_all(status: "missing")
  end

  def record_sync_time
    SourceSync.upsert({ id: 1, last_synced_at: Arel.sql("clock_timestamp()") }, returning: false)
  end
end
