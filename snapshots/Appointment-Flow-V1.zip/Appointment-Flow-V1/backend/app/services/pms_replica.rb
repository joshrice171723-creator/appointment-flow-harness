require "pg"
require "json"

module PmsReplica
  CONNECTION_TIMEOUT_SECONDS = 3
  STATEMENT_TIMEOUT_SECONDS = 15
  def self.read(appointments_since: nil, appointment_ids: [])
    url = ENV.fetch("PMS_READER_URL", "postgresql://pms_reader@127.0.0.1:55439/apex_pms_contact_demo")
    PG.connect(url, connect_timeout: CONNECTION_TIMEOUT_SECONDS) do |db|
      db.transaction do
        db.exec("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY")
        db.exec("SET LOCAL statement_timeout = '#{STATEMENT_TIMEOUT_SECONDS}s'")
        %w[clinics patients appointments].to_h do |table|
          scope = ""
          params = []
          if table == "appointments" && appointments_since
            scope = "WHERE start_at >= $1::date OR id = ANY($2::bigint[])"
            params = [appointments_since.iso8601, "{#{appointment_ids.join(',')}}"]
          end
          json = db.exec_params(<<~SQL, params).first.fetch("rows")
            SELECT coalesce(json_agg(row ORDER BY id), '[]') AS rows
            FROM pms.#{table} row
            #{scope}
          SQL
          [table, JSON.parse(json)]
        end
      end
    end
  rescue PG::Error => error
    raise ReminderFlow::Conflict, "PMS snapshot unavailable: #{error.class}."
  end

end
