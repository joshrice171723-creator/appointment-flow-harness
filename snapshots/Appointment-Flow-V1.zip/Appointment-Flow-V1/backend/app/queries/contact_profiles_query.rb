class ContactProfilesQuery
  def self.scope(clinic_id)
    booked = Appointment.for_clinic(clinic_id).select(:patient_id)
    tracked = Visit.for_clinic(clinic_id).select(:patient_id)
    Patient.where(id: booked).or(Patient.where(id: tracked))
  end

  def self.call(clinic_id, patient_id: nil)
    patients = scope(clinic_id)
    patients = patients.where(id: patient_id) if patient_id
    patients.includes(:active_detail_verifications,
      contact_permissions: { authorized_guarantor: :active_detail_verifications }).to_a
  end
end
