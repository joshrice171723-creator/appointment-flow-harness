class PatientAppointmentsQuery
  def initialize(patient, clinic, now: Time.current)
    @patient = patient
    @clinic = clinic
    @now = now
    @appointments = Appointment.for_clinic(clinic.id).where(patient_id: patient.id)
    @visits = Visit.for_clinic(clinic.id).for_patient(patient.id)
    @policy = ContactPolicy.new(now)
  end

  def next_appointment
    @appointments.scheduled.where("start_at > ?", clinic_wall_time).chronological.first
  end

  def page(filter:, before:, limit:, appointment_id: nil)
    source = @appointments.select("id AS appointment_id, start_at, 1 AS source")
    tracked = @visits.select("appointment_id, start_at, 0 AS source")
    dates = <<~SQL
      SELECT DISTINCT ON (appointment_id) appointment_id, start_at
      FROM (#{source.to_sql} UNION ALL #{tracked.to_sql}) AS appointment_versions
      ORDER BY appointment_id, source DESC, start_at DESC
    SQL
    rows = Appointment.unscoped.from("(#{dates}) AS appointment_dates")
    rows = rows.where("appointment_id = ?", appointment_id) if appointment_id
    rows = rows.where("start_at > ?", clinic_wall_time) if filter == "upcoming"
    rows = rows.where("start_at <= ?", clinic_wall_time) if filter == "past"
    rows = rows.where("(start_at, appointment_id) < (?, ?)", *before) if before
    rows.order(Arel.sql("start_at DESC, appointment_id DESC")).limit(limit)
      .pluck(Arel.sql("appointment_id"), Arel.sql("start_at"))
  end

  def rows(ids)
    appointments = @appointments.where(id: ids).index_by(&:id)
    visits = @visits.where(appointment_id: ids).with_context.includes(:events).order(id: :desc).to_a
    revisions = visits.group_by(&:appointment_id)
    issues = FollowUpIssue.group_by_visit(FollowUpIssue.open.for_visits(visits.map(&:id)).order(:id))
    pending = @visits.where(id: visits.map(&:id)).with_pending_pms_change.pluck(:id).to_set

    ids.filter_map do |id|
      versions = revisions.fetch(id, [])
      appointment = appointments[id]
      visit = if appointment
        versions.find { |version| version.matches_appointment?(appointment) && version.current } ||
          (versions.find { |version| version.matches_appointment?(appointment) } unless appointment.status == "scheduled")
      else
        versions.first
      end
      next unless appointment || visit

      # A replacement booking belongs to its own patient and clinic. Keep the old visit facts separate.
      row = AppointmentSerializer.new(appointment: appointment, visit: visit,
        hold: visit && outreach_for(visit, pending: pending.include?(visit.id)).fetch(:hold),
        issues: visit ? issues.fetch(visit.id, []) : [], patient_reply: visit&.latest_patient_reply).as_json
      [id, row.merge("revisions" => versions.map do |version|
        version.attributes.slice("id", "start_at", "current", "confirmed_at", "confirmed_by")
      end)]
    end.to_h
  end

  def next_outreach(appointment, permission)
    return { hold: nil, allowed_channels: [] } unless appointment

    visit = @visits.current.find_by(appointment_id: appointment.id)
    if visit&.matches_appointment?(appointment)
      return outreach_for(visit, pending: visit.pending_pms_change?)
    end

    visit = Visit.new(patient: @patient, appointment: appointment, clinic_id: @clinic.id,
      clinic_setting: @clinic.setting, start_at: appointment.start_at)
    visit.contact_permission = permission if permission
    outreach_for(visit)
  end

  private

  def outreach_for(visit, pending: false)
    return { hold: "Awaiting PMS update. Reminders paused for this time.", allowed_channels: [] } if pending
    return { hold: nil, allowed_channels: [] } unless visit.starts_at_utc.nil? || visit.starts_at_utc > @now

    @opt_outs ||= OptOut.where(clinic_id: @clinic.id).pluck(:destination).to_set
    decision = @policy.decision(visit, opt_outs: @opt_outs)
    { hold: decision.reason, allowed_channels: decision.destinations.keys }
  end

  def clinic_wall_time
    @now.in_time_zone(@clinic.setting.timezone).strftime("%F %T.%6N")
  end
end
