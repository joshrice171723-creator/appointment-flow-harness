class FollowUpIssue < ApplicationRecord
  self.table_name = "desk.issues"
  belongs_to :follow_up_case, foreign_key: :case_id
  belongs_to :resolution_event, class_name: "ActivityEvent", optional: true
  belongs_to :reply_event, class_name: "ActivityEvent", optional: true
  belongs_to :visit
  scope :open, -> { where(resolved_at: nil) }
  scope :for_clinic, ->(id) { where(case_id: FollowUpCase.for_clinic(id).select(:id)) }
  def self.for_visits(ids)
    return none if ids.empty?
    where("visit_id IN (:ids) OR EXISTS (SELECT 1 FROM jsonb_array_elements_text(candidate_visit_ids) AS candidate(value) WHERE candidate.value::bigint IN (:ids))", ids: ids)
  end

  def affected_visit_ids
    return [visit_id] unless reply_event_id
    resolved_at ? clarified_visit_ids : candidate_visit_ids
  end

  def self.group_by_visit(issues)
    result = Hash.new { |hash, id| hash[id] = [] }
    issues.each { |issue| issue.affected_visit_ids.each { |id| result[id] << issue } }
    result
  end
end
