class SourceSync < ApplicationRecord
  self.table_name = "desk.source_sync"
  MAX_CACHE_AGE = 5.minutes

  def self.status
    uncached do
      synced_at = find_by(id: 1)&.last_synced_at
      # Freshness uses the database clock, independent of a test's simulated visit date.
      database_now = connection.select_value("SELECT clock_timestamp()")
      stale = synced_at.nil? || synced_at < database_now - MAX_CACHE_AGE
      # Response contract: Time or nil, boolean, and a warning string or nil.
      {
        "last_synced_at" => synced_at,
        "stale" => stale,
        "message" => stale ? "Appointment data is stale. Check the PMS before acting." : nil
      }
    end
  end
end
