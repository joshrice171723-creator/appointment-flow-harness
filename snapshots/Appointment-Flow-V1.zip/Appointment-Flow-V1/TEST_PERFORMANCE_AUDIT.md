# Backend test performance audit

The completed backend run took 824.396 seconds (13 minutes 44 seconds): 79 tests, 1,271 assertions, no assertion failures, and one error. The stop request arrived after the run had completed; no backend suite processes remained running. The sections below record the initial investigation; follow-up measurements are recorded at the end.

## Main cause: rebuilding the whole demo before many tests

Five test classes call `ReminderFlow#restore_demo` in their per-test setup:

| File | Tests that inherit the full-demo setup |
| --- | ---: |
| `backend/test/flow_test.rb` | 23 |
| `backend/test/reporting_test.rb` | 9 |
| `backend/test/model_boundaries_test.rb` | 10 |
| `backend/test/cleanup_test.rb` | 5 |
| `backend/test/audit_test.rb` | 5 |
| Total | 52 |

There are additional explicit resets in seed tests and cleanup paths. This includes small checks such as `CleanupTest#test_flow_uses_real_time`, which only needs to inspect the clock but inherits a complete demo rebuild.

The backend log records one reset request taking 12,706 ms, with 2,779 database queries, 4,074 ms of database time, and 992 ms of garbage collection. That is one reset, not the full suite. If the 52 setup resets cost the same as this observed request, they alone would total about 11 minutes. That is an illustrative estimate, not separately measured timing for every setup.

## Why the Ruby seed change amplified the cost

`DemoSeed#load` creates permissions and walkthrough records individually. `seed_messages` looks up a permission for every appointment and then writes visits, messages, message items, and reply events one at a time. Historical replies also call `FollowUpWorkflow` to open and close cases, adding reads, writes, and locks for each example. Active Record makes these steps readable but does not make thousands of database round trips cheap.

The previous controller-split backend run also took 325.733 seconds (about 5 minutes 26 seconds), so full-demo fixture rebuilding was already a problem. The new run was about 2.5 times as long, though changed assertion counts and runtime conditions mean that ratio is not an isolated benchmark of the seed conversion.

## Separate correctness error

`CleanupTest#test_repeating_migrations_and_seeds_does_not_duplicate_or_reset_demo_records` runs migrations while the test clock is frozen to November 5. The migration is dated November 8. Rails rejects that as a future migration timestamp. This error needs fixing, but it does not explain the repeated seed cost. Migration checks should use real time; business-date scenarios can remain frozen.

## Recommended fix order

1. Stop using the full walkthrough as the default fixture for small tests. Create only the records a scenario needs, and use transaction rollback for isolation. Keep dedicated integration checks for a genuine whole-demo reset.
2. For integration tests that share the same baseline, investigate loading the baseline once and rolling back each test, with explicit handling for tests that use multiple connections or exercise real commits. Do not blindly wrap concurrency or transaction-boundary tests in a transaction.
3. Measure one demo rebuild by seed step and query count. Remove repeated permission lookups and use ordinary Active Record bulk inserts for independent fixture rows where that stays easy to read. Do not hide the problem by skipping assertions or returning to large SQL seed files.
4. Fix the migration-clock test, then run focused affected tests before another full suite. Record setup time separately from test-body time so this regression is visible.

## Scope and limitations

This audit used the completed suite log and current source. It did not rerun the full suite, change test behavior, or implement performance fixes. The Rails migration and Ruby-seed change is still pending final verification and commit. Its earlier clean-install, migration rollback/reapply, and 16 desktop browser checks passed; the backend result must not be described as passing.

Evidence logs are retained in the local setup records. The file-by-file migration change list has been calculated there; final counts must be refreshed after any performance fixes.

## Follow-up: first fixes were insufficient

Bulk Ruby seeding reduced the measured reset query count from 2,780 to 521 while retaining the same aggregate example-record counts. A committed in-memory baseline replaced 52 production demo rebuilds. The complete backend command then passed 79 tests and 1,274 assertions with no failures, errors, or skips, but took 490.231 seconds including setup; Minitest reported 422.686 seconds for the tests. This does not meet Josh's one-minute target.

Josh rejected waiting on more runs as the main investigation method and directed a source review of every test. That review found repeated deletion and insertion of all 16 baseline tables, four additional seed-test rebuilds, redundant cleanup imports, a pure text test inheriting database and request setup, and repeated reporting queries. The next changes target those concrete costs without removing assertions or wrapping real commit/concurrency checks in a test transaction. The measured results after these fixes are below.

The host was also sampled around 95% CPU with about 1.55 GB physical memory available and around 90% of memory commit used. This is context for noisy timings, not grounds to waive the target or claim the remaining test design is acceptable.
## Direct test source review

| Test files | What the code showed |
| --- | --- |
| `flow_test.rb`, `model_boundaries_test.rb`, `cleanup_test.rb` | Whole-demo copies were the default, including for small checks. Ordinary cases can roll back. Tests covering a real reset, concurrent workers, or ownership of a transaction must still use committed rows. Four FlowTest cleanup blocks and one boundary test repeated work handled by isolation. |
| `seed_test.rb`, `replica_seed_test.rb` | The four app-seed checks rebuilt the same seed independently. They can inspect the real seed created at suite startup. The replica-seed test exercises three different calendar scenarios; those runs provide distinct coverage. |
| `audit_test.rb`, `reporting_test.rb` | A language-only test inherited database and request setup. Read-only workflow checks repeatedly queried separate digests. Reporting inserted a zone already supplied by the seed and queried cases once per candidate. |
| `replica_test.rb`, `database_test.rb` | The replica preservation test reopened its reader for each checksum check. A separate database test already used rollback to verify timestamp conversion. Inspection of the PG gem found that each application database session separately loaded the entire PostgreSQL type catalog. |
| `cadence_test.rb`, `reply_test.rb`, `contact_policy_test.rb`, `runner_logging_test.rb` | Cadence and reply tests already use small local records in rollback transactions. Contact-policy format checks and logging use no per-test database setup. Repeated cadence runs assert that the same reminder is not sent twice, so those calls stay. |
| Browser specs | Tests wait for specific responses and assertions. The two desktop projects run serially because they share a mutable demo. Browser runtime is measured separately from the backend command. |

A first rollback attempt failed: the Rails request lifecycle released the fixture connection, and a later request used a second connection blocked by the first one's advisory lock. The seed also used the real clock in its final reconciliation despite using a fixed date to build the examples. The test harness now follows Rails' connection pinning pattern, and the seed and its reconciliation use the same clock. Reusable PostgreSQL result decoders avoid repeated catalog reads, and replica reads decode the JSON they actually select.
## Verified timings

| Run | Test time | Whole command | Result |
| --- | ---: | ---: | --- |
| Initial Ruby seed conversion | 824.396 s | Not recorded | 79 tests, 1,271 assertions; one migration-clock error |
| Bulk seeds and per-test copies | 422.686 s | 490.231 s | 79 tests, 1,274 assertions passed |
| Pinned fixtures, seed clock, and decoder reuse | 104.383 s | 134.661 s | 82 tests, 1,286 assertions passed |
| Also removed redundant reset and dead-port waits | 74.965 s | 113.874 s | 82 tests, 1,284 assertions passed |

The one-minute target was not met. The latest run spent about 39 seconds before the tests started. Test time fell from about 13 minutes 44 seconds to 1 minute 15 seconds. The latest whole-command result includes Rails startup, real migrations and seeding on disposable databases, and all test cases. The suite still exercises concurrent workers, app-owned transactions, SELECT-only source access, and a real demo reset. Three new checks verify that PostgreSQL type decoding is reused, works across connections, and reloads on reconnect.

The stale-source reporting test dropped from 9.20 seconds to 1.83 seconds by using an unavailable database on the running PostgreSQL server rather than waiting for a dead TCP port. It still handles an actual connection error. The reset endpoint still has a real integration test; the calendar examples reuse the seed created at suite startup. These comparisons describe the observed runs on this host, not a guarantee of performance on another machine.
## Attempt to reach 30 seconds

Josh asked to try for under 30 seconds for the same complete backend suite. The first instrumented run measured 26.334 seconds in Rails boot, 10.237 seconds in setup and test loading, and 70.412 seconds in the tests. That run already exceeded 30 seconds before tests began. The 8,180 instrumented Active Record queries took about 14 seconds in total; the problem was more than database execution time.

The test environment now disables code reloading, like a normal Rails test configuration. The tests reuse a report or appointment response when no data changed between reads, and setup checks both database names in one catalog query. Provisioning no longer builds a type map that none of its callers use. Direct `ruby test/all.rb` uses the existing `bundler/setup` and avoids the extra Bundler launcher on Windows.

The profiled serial run passed all 82 tests in **53.069 seconds**, with 35.665 seconds in the tests. Two isolated Ruby processes passed the same 82 tests in **53.410 seconds**; duplicated boot and fixture setup absorbed the gain from running tests concurrently. The parallel experiment stays out of the project. No test behavior was removed; three fewer assertions reflect removing repeated checks that an identical request succeeded.

[Rails' test guide](https://guides.rubyonrails.org/v8.1/testing.html) describes transactional fixtures and separate databases for process workers. The boot-cache experiment used [Bootsnap](https://github.com/rails/bootsnap) from a separate, local-only bundle, without adding it to the project.
Bootsnap took 55.379 seconds for Rails boot with an empty cache. With the cache populated, boot took 12.740 seconds and the full command took 117.632 seconds; all 82 tests passed. Run conditions varied, so this is evidence that the cache did not demonstrate a speedup here, not a controlled claim that Bootsnap made the tests slower. The app's dependencies stayed the same.
Final uninstrumented verification used `ruby test/all.rb --verbose --seed 44440`. It passed **82 tests and 1,281 assertions** in **76.502 seconds** end to end, with 52.354 seconds in the tests. The best complete serial run was 53.069 seconds; the repeat shows that sub-minute time is possible here but not consistent. None of the runs reached 30 seconds.