# Appointment Flow

A Rails and React appointment-confirmation app for a take-home assessment. The replica supplies synthetic patients and appointments. SMS and email use a local transport. Use a desktop browser. The app reads a separate PostgreSQL replica with a SELECT-only role and stores its own messages, confirmations, and follow-ups in another database.

## Run with Docker (Linux, macOS, or Windows)

Install Docker with Compose. From the extracted project folder:

```sh
docker compose up --build -d
```

Open [Appointment Flow](http://localhost:8174/). First startup builds React, installs Ruby dependencies, creates both databases, and seeds dates relative to setup time. The one-time `setup` container exits successfully; `app`, `worker`, `redis`, and `db` stay running. Check startup with `docker compose ps -a` and `docker compose logs setup app worker`.

Compose mounts `backend/config/clinic-setup.example.json` for local clinic settings and staff. Set `CLINIC_SETUP_FILE` to a different host file before startup to use your own settings. Setup creates missing records. It preserves existing settings, staff, and workflow history.

Only port 8174 is published, on loopback. PostgreSQL and Redis stay on the internal Docker network. Compose contains disposable local passwords. The running app receives only its app credential and the SELECT-only replica credential; provisioning credentials belong to setup and tests.

Stop with `docker compose down`; data persists in a volume. To intentionally discard all synthetic data and generate fresh dates, run `docker compose down -v`, then start again. Set `PORT` before startup to choose another web port.

## Try the workflow

Start with the reminder, reply, and staff follow-up below. That is the main walkthrough. Patient detail verification is there for contact problems that block outreach. Leadership gets an aggregate comparison across the two example clinics. The interactive demo uses local message delivery. The optional 60-clinic scale fixture runs separately.

Use a fresh stack with the default assessment seed. The reminder for this walkthrough is already in the simulated inbox, including outside the send window.

1. Open **Front desk**, select **Austin** and **Taylor Morgan**, set **Follow-up type** to **No reply**, and open the seeded upcoming item under **Needs attention**. Note the Demo Patient ID and the appointment. The November 10 seed uses Demo Patient 654 and Appointment #678. Fresh setups on other dates can assign different numbers. In **Patient**, select **Austin**, choose that patient, and open their seeded reminder under **Text messages**. The initial reminder contains `Reply YES to confirm or NO for help.`
2. Reply `No, I can't make it`. The inbox records the reply and sends it to **Needs attention** for review.
3. Return to **Front desk** and reopen the same patient under **Needs attention**. **Follow-up items** shows the actual reply and its possible appointments in one review task. **Activity log** shows the original reminder and reply. The PMS booking stays scheduled.
4. Choose **Assign to me**, then **Record follow-up**. Select the reply item and **Applies to selected appointments**, choose the appointment, and add a note explaining the clarification. Save, then record **Contact attempted (keep open)** against the resulting appointment follow-up item. The case stays open and both notes appear in activity. Use **Still unclear (keep open)** when the reply cannot yet be matched. To compare recorded outcomes across clinics, open **Apex leadership** from Workspaces.

Setup seeds a September 2026 baseline and replays reminder activity from the October 1 launch through the local sender, reply handler, and staff actions. It preserves existing patient workflow records. The worker handles current work. Leadership groups message, reply, confirmation, and outcome counts by appointment month. September shows appointment outcomes before reminder activity began. [Reporting measurements](docs/performance.md#leadership-report-performance-evidence)

The assessment assumes messaging permission is granted until revoked. Import creates SMS/email grants for new patient/clinic pairs at messaging-enabled clinics and preserves revocations and opt-outs. The supplied PMS schema has no consent fields. Guardian authorization is separate and import never grants it automatically.

Setup creates five appointments per open day, Monday–Saturday, with the previous month for comparison and upcoming visits through at least the next ten days. The PMS stores synthetic patients with `Demo Patient` as the first name and the patient ID as the last name. Dates are set once. Past statuses are seeded directly. Future visits stay scheduled until the source changes; elapsed time alone does not establish attendance.

## Automatic work

A separate Sidekiq worker runs ReminderJob at startup and every five minutes through sidekiq-cron. Redis persists queued jobs and retry records. Failed ticks raise sanitized errors for up to five retries. The recurring schedule continues after retries are exhausted. Successful clinic batches remain committed, and their daily markers prevent resending on retries. It refreshes the shared replica cache and reconciles follow-ups even with no browser open. GET requests only read data. The visible board, calendar, case details, and leadership report reload every five minutes.

**Triggering reminders:** starting the Compose stack enables the worker; staff do not press a button. Each clinic gets one send batch per local date at 10 AM, with catch-up before 6 PM after an outage or late startup. The batch reads the source before sending. Appointments booked afterward wait until tomorrow; if they occur before then, staff handle confirmation at booking. Source appointments and send history are the backlog.

At day 7, request YES/NO by SMS (email if SMS is unavailable). At day 6, send permitted email only if the initial SMS has no reply. At day 3, send another SMS request only if no reply or confirmation exists (email if SMS is unavailable). At day 1, send a reminder: confirmed visits get the appointment time with no response requested, while unconfirmed visits still receive a confirmation request. A failed initial SMS can immediately fall back to permitted email. English and Spanish templates use the recipient's language; an authorized adult's language applies to a minor. Consent, opt-outs, current appointment revisions, and recipient checks apply to every send.

Failed source reads preserve the old cache. Staff can claim work and record contact attempts during an outage. Confirming or recording a final scheduling outcome requires a successful source read. Schedule changes happen in the existing PMS. The replica's approximate five-minute lag can add to our five-minute refresh interval; an open screen may then wait until its next five-minute reload.

## Windows launcher

Start Docker Desktop, then run from the repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\start.ps1
```

The launcher starts the Docker stack, including Sidekiq and Redis. Set `PORT` to choose a different web port.

For Linux or WSL development outside Docker, install Ruby 3.4, Node.js, PostgreSQL 17, and Redis 7+. From `frontend/`, run `npm ci` and `npm run build` to build browser assets into `backend/public/`. From `backend/`, run `bundle install` and `bundle exec ruby bin/setup.rb` with `APP_ADMIN_URL`, `PMS_ADMIN_URL`, `DENTAL_DATABASE_URL`, and `PMS_READER_URL` configured. Set `CLINIC_SETUP_FILE` to the absolute path of your clinic configuration. Then start Rails and the worker in separate terminals:

```sh
bundle exec puma -t 1:5 -b tcp://127.0.0.1:8174
REDIS_URL=redis://127.0.0.1:6379/0 bundle exec sidekiq -c 1
```

Runtime uses only `DENTAL_DATABASE_URL` and `PMS_READER_URL`, plus `REDIS_URL` for the worker. Provisioner credentials belong to setup and tests. The worker runs one job at a time, with its recurring schedule in `config/schedule.yml`. Inspect failures with `docker compose logs worker`.

## Tests

```sh
docker compose --profile test run --rm test
```

The suite creates isolated databases ending in `_test` and freezes time only in tests. It checks the source schema and grants, seed dates, cadence, duplicate prevention, reply matching, guardian/consent rules, outages, source changes, follow-up history, and reporting. It does not modify the running demo's databases. After code changes, run `docker compose build` before testing.

Native equivalent from `backend/`: set `DENTAL_DATABASE_URL` to a disposable database ending in `_test`, set `APP_ADMIN_URL` and `PMS_READER_URL` for the same cluster, and run `ruby test/all.rb`. The app loads its locked gems through Bundler, and test setup provisions both isolated databases. Add `--verbose` to see each test's time.

### Browser checks

With the app running, from `frontend/`:

```sh
npm ci
npx playwright install chromium
npm run test:ui
```

Browser tests run at 1366×768 and 1920×1080 and check patient selection, Spanish history, free-text entry, calendar navigation, leadership reporting, resolved activity history, empty-response errors, clearing a draft when changing patients, and excluding later declines from the Confirmed filter. Controlled browser tests also check late reads, rejected writes, uncertain write outcomes, failed refresh after acceptance, and draft identity. These tests supply message and activity history through test responses. Backend tests cover actual workflow transitions using isolated databases.

### Isolated scale check

```sh
docker compose --profile scale run --rm scale
```

This creates/replaces only `apex_scale_test` and `apex_scale_source_test`. It seeds 60 clinics and 14 open days with 4,000 appointments per day (56,000 total), times a complete replica import and a 4,000-message daily batch, then checks that repeating that batch sends zero duplicates and times leadership reporting. Output is JSON. Normal demo data and dropdowns stay small. Delivery is fake; timing does not include provider latency or prove production capacity. Full-table reads are still used, so growing historical data remains a limit to measure before production.

## Read the code

| File from the repository root | Responsibility |
| --- | --- |
| `backend/app/services/pms_replica.rb` | Only runtime connection to the SELECT-only source. |
| `backend/app/services/pms_snapshot.rb` | Transactional cache import. |
| `backend/app/jobs/reminder_job.rb`, `backend/config/schedule.yml` | Sidekiq job, retries, and five-minute schedule. |
| `backend/app/services/reminder_runner.rb` | Automatic refresh, follow-up maintenance, daily batches. |
| `backend/app/services/reminder_flow.rb` | Reconciles visit revisions and owns the daily batch transaction. |
| `backend/app/services/reminder_sender.rb` | Applies recipient/schedule decisions and records fake deliveries and contact work. |
| `backend/app/services/reminder_schedule.rb` | Day 7, 6, 3, and 1 decisions. |
| `backend/app/services/receive_reply.rb` | Matches a sent receipt and recipient before confirming or requesting review. |
| `backend/app/services/contact_policy.rb` | Normalizes contact fields and selects an authorized adult. |
| `backend/app/models/visit.rb` | Converts clinic wall time and confirms only the current appointment revision. |
| `backend/app/services/follow_up_workflow.rb` | Opens, reopens, and closes follow-up issues. |
| `backend/app/models/`, `backend/app/queries/`, `backend/app/serializers/` | Records and relationships, screen reads, and explicit response fields. |
| `backend/app/controllers/desk_controller.rb` | Front-desk appointments, board, case details, and staff actions. |
| `backend/app/services/record_follow_up.rb` | Explicit staff-action inputs, ownership/version checks, and outcome recording. |
| `frontend/src/features/` | Route screens and their feature-specific components. |
| `frontend/src/shared/format.js` | Shared date formatting and confirmation/reply labels. |
| `backend/test/reply_test.rb` | Bounded reply fixtures: recipient matching, ambiguity, and review transitions. |
| `backend/test/contact_policy_test.rb` | Phone/email normalization and adult-recipient selection without a demo reset. |
| `backend/db/migrate/`, `backend/db/schema.rb` | Versioned app database changes and the generated Rails schema. |
| `backend/db/seeds.rb`, `backend/config/clinic-setup.example.json` | Import the source and provision configured clinic settings and staff. |
| `backend/db/replica/migrate/`, `backend/db/replica/seeds.rb` | Reproduce the supplied source tables and create fake source records during setup only. |

The app uses Active Record models, plain Ruby services and serializers, esbuild, and one shared `usePage` hook. Internal workflows use model records; serializers define screen responses. Start with `ReminderSchedule` for timing, `ContactPolicy` for recipients, and `ReceiveReply` for reply handling. Rails migrations define the tables, and the replica seed creates synthetic PMS records. SQL remains for PostgreSQL database/account permissions, the bulk replica import, locks, the database clock, and the isolated scale fixture. Ordinary screens and workflow record operations use models. Full snapshot imports retain reporting history and guarantor-only patients. Measure the live dataset before designing bounded reads with explicit checks for missing tracked IDs.

For case and calendar reply status, follow `Visit#latest_patient_reply` → `AppointmentSerializer` → `confirmationLabel` in `frontend/src/shared/format.js`. A recorded confirmation remains historical fact; an open reply review takes precedence in the displayed label. `declined_reply` identifies definite declines such as `NO` and `No, I can't make it`, separately from no response.

`PmsSnapshot#refresh` owns the transaction for its lock, cached rows, and freshness timestamp. `RecordFollowUp` owns the staff action transaction and reconciles visits associated with that case before recording an outcome. Unexpected runner failures log the exception class, cause class, and source location; exception messages are omitted because they can contain patient text.

## Submission contents

The package contains application source, setup scripts, dependency lockfiles, tests, and these documents:

- [DECISIONS.md](DECISIONS.md): choices and tradeoffs.
- [ARCHITECTURE.md](ARCHITECTURE.md): components, data flow, and states.
- [AI_USAGE.md](AI_USAGE.md): tools, uses, and corrections.
- [Human code-quality rubric](docs/ai-harness/apex-human-code-quality-rubric-2026-11-06.md): code-review criteria.
- [Project context](PROJECT_CONTEXT.md) helps reviewers find code and decisions.
- [Test performance audit](TEST_PERFORMANCE_AUDIT.md) records the test timings and run conditions.

Controller responsibilities: `ApplicationController` shares CSRF protection and conflict handling; `DeskController` handles front-desk work; `PatientsController` handles inboxes and replies; `OperationsController` handles leadership reports; `WorkspacesController` serves the React shell and workspace selection.

## Database changes and demo data

First installation still starts with `docker compose up --build -d`, or the Windows launcher above. `bin/setup.rb` provisions the database accounts, runs the replica migrations and Ruby seed, then runs the app migrations and `db/seeds.rb`. PostgreSQL account creation and SELECT-only grants remain a small setup-only SQL step.

For later app-table changes, from `backend/` with the app database URL configured:

```sh
bundle exec ruby bin/rails generate migration DescribeYourChange
bundle exec ruby bin/rails db:migrate
bundle exec ruby bin/rails db:migrate:status
bundle exec ruby bin/rails db:seed
```

`db:seed` refreshes the PMS snapshot and creates missing clinic settings and staff from configuration. Existing workflow history stays in place. Compose sets `ASSESSMENT_REMINDERS_START` for its setup container. Set it to an empty value to skip the assessment history. The source fixture's writable Rails models are loaded only by setup and tests. Runtime reads the replica through the SELECT-only login.

This version starts a new migration history. It does not upgrade the earlier SQL-based demo layout. To replace an older Docker demo, use `docker compose down -v`, then start again. This discards the disposable demo data. Normal restarts after this one-time rebuild retain data and run only pending migrations.

## Request and recovery boundaries

Staff writes in `DeskController#work` check case access and call `RecordFollowUp`. The service checks the request and refreshes the source for final outcomes before opening the action transaction. Access is checked again inside that transaction. `RecordFollowUp` locks and reloads the case before validating its version, owner, issue, and outcome. A returned conflict preserves reconciliation; an exception rolls back the action. The earlier successful source refresh remains committed. Patient replies check the workspace and receipt before an optional refresh, then load their target under the clinic lock.

Read actions use Active Record queries without constructing a reminder workflow or database session. `Database::Session` remains for raw SQL fixtures and the scale command: it shares Rails' connection, materializes transactions before raw SQL, and preserves PostgreSQL result types without replacing Rails' timestamp decoder.

In React, `requests.js` decodes HTTP results; `usePage` owns reads and submission status; each form owns its draft. Rejected writes retain the draft. An accepted write clears its submitted draft even when the following read fails. An uncertain write retains the draft and asks the user to reload and inspect the record before another submission. Recovery reloads do not repeat writes. Selection controls stay disabled while a write is pending.
