# Frontend code quality rubric

Rebuilt 2026-11-10 as a source-linked review checklist. The earlier numerical weights, pass threshold, cap, and mandatory scoring exercises are retired. Review questions are editorial applications of the cited sources, not a grading system supplied by their authors.

## Focused review of a change

Complete the review independently using source traces and checks you can run. Assess readability by tracing concrete inputs, decisions, and outcomes to their owners. Use automated checks for claims about executed behavior and mark unavailable checks Unverified.

Use the applicable rows to review one workflow at a time. Begin at the entry point and follow the inputs, state owner, event, request, server result, and visible result. If this is a refactor, trace that path before and after and describe what became easier to understand. Read the relevant source passage in the [frontend guide](Frontend-Coding-Guide.md#start) when a finding depends on its guidance.

For JavaScript structure and behavior tests, use the [nine-chapter reference for 99 Bottles of OOP](Frontend-Coding-Guide.md#bottles-js-chapters). Cite the relevant entry and page reference when a book principle supports a recommendation. Use the guide's React and browser references to assess framework behavior.

Use [Current React practice](Frontend-Coding-Guide.md#react-practice) for component structure, render purity, record identity, effect cleanup and request outcomes. Its source notes distinguish the book passages from the React.dev APIs used in the examples.

Rate each row **Meets**, **Revise**, **Unverified**, or **Outside scope**. Use Meets when the cited evidence supports the criterion, Revise for a concrete deficiency, Unverified when necessary evidence is missing, and Outside scope when the criterion does not apply. Write the evidence and consequence of each finding. Keep ratings per criterion.

| Check | What a reviewer should be able to establish | Evidence to look for |
| --- | --- | --- |
| Names, dependencies, and boundaries | The call site names the operation and makes its inputs visible. A module or hook groups one responsibility and exposes only what callers need. | Trace the call and imports. Explain which details stay local after extraction and who owns collaborator selection. [F01](Frontend-Coding-Guide.md#f01) · [F02](Frontend-Coding-Guide.md#f02) · [99 Bottles ch. 5](Frontend-Coding-Guide.md#bottles-js-05) · [99 Bottles ch. 8](Frontend-Coding-Guide.md#bottles-js-08) |
| Proportion and variants | An extraction joins cases that share a decision. The caller can see what a default means and which component selects a variant. | Show the real cases and the reading burden removed. Confirm a proposed wrapper or factory earns its place. [99 Bottles ch. 1](Frontend-Coding-Guide.md#bottles-js-01) · [ch. 3](Frontend-Coding-Guide.md#bottles-js-03) · [ch. 4](Frontend-Coding-Guide.md#bottles-js-04) · [ch. 7](Frontend-Coding-Guide.md#bottles-js-07) |
| State and rendering | Each editable value has an owner. Rendering derives the display without changing inputs. Stable keys preserve the right record's state. | Trace the draft and persisted data. Reorder rows or switch records where relevant. Check intentional resets and the affected loading, empty and failed states. [F04](Frontend-Coding-Guide.md#f04) · [F18](Frontend-Coding-Guide.md#f18) · [F19](Frontend-Coding-Guide.md#f19) · [F23](Frontend-Coding-Guide.md#f23) |
| User action and request identity | A write starts from its actual interaction. Effects have a synchronization purpose and matching dependencies and cleanup. The current record and the record that started a pending request stay distinguishable. | Trace the event or effect. If the path can race, force response reordering. Check the current rows, feedback and draft. [F07](Frontend-Coding-Guide.md#f07) · [F21](Frontend-Coding-Guide.md#f21) · [F22](Frontend-Coding-Guide.md#f22) |
| API result and recovery | Transport failure, rejected action, ambiguous outcome, and accepted write followed by failed refresh lead to appropriate feedback. Repeating a consequential action follows its server contract. | Compare client handling with the Rails action and write boundary. Check rejected drafts and persisted records when applicable. [F09](Frontend-Coding-Guide.md#f09) · [F10](Frontend-Coding-Guide.md#f10) · [F11](Frontend-Coding-Guide.md#f11) |
| Accessible interaction and plain language | Users can identify the control, complete the action by keyboard, find the feedback, and tell what to do next. Data tables retain header relationships. | Check affected actions, labels, focus, feedback, and changed strings. Record which browser and assistive technology checks actually ran. [F12](Frontend-Coding-Guide.md#f12) · [F13](Frontend-Coding-Guide.md#f13) |
| Desktop layout | The affected view stays usable at the supported desktop sizes and preserves zoom and reduced-motion behavior. | Check 1366×768 and 1920×1080 for view changes. Exercise long values, zoom, keyboard, and motion where relevant. [F14](Frontend-Coding-Guide.md#f14) |
| Regression evidence | The check would fail for a specific user-visible or persistence regression. Its expected result is independent of the implementation under test. | Name the scenario and report the observed result. Distinguish source review, tests with stubbed responses, and real browser plus API evidence. [F25](Frontend-Coding-Guide.md#f25) · [99 Bottles ch. 2](Frontend-Coding-Guide.md#bottles-js-02) · [99 Bottles ch. 9](Frontend-Coding-Guide.md#bottles-js-09) |
| Performance changes | A concrete delay warrants the change, and the comparison measures the user task under the same conditions. | Record before and after timing and the component of the delay that changed. [F16](Frontend-Coding-Guide.md#f16) |

## Recording findings

For each problem, provide a file and line, what the reader or user experiences, the consequence, and a correction that fits the path. For example, a source trace may show that an older load updates the current list. A controlled browser exercise can establish that switching clinics actually displays the wrong rows. Mark the second claim **Unverified** until the exercise runs.

Prioritize broken actions, incorrect data, wrong-record effects, unrecoverable drafts, inaccessible controls, and other consequential findings according to the changed scope. Record material unverified paths. For whole-app work, review the Rails contract with the [backend rubric](apex-human-code-quality-rubric-2026-11-06.md) and trace any shared finding through both sides once.

For a historical comparison, record the code revision, rubric revision, reviewed workflows, criterion ratings, and evidence used. Compare ratings across runs with matching criteria and scope.
