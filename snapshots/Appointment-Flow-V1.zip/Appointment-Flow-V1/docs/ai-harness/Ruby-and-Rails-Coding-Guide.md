# Writing Ruby and Rails for humans

Revised 2026-11-10 using the supplied editions. This guide uses the books for design and readability and the Rails 8.1 documentation for framework behavior. Each entry identifies its source and separates it from the project application. Examples are original.

<a id="start"></a>
## Start here

Use [Find guidance by task](#router) for a focused change. The [chapter reference](#chapter-reference) covers all 40 numbered chapters with page references and two original examples each. Jump to [Eloquent Ruby](#eloquent-ruby-chapters) or [Practical Object-Oriented Design in Ruby](#practical-oo-chapters).

1. Pick a real entry point and a case the change must preserve. Trace the request or job to the rule owner, writes and visible result.
2. Find the decision in the [task index](#router). Read its cited passage when you need the author's rationale.
3. Compare the proposed call site with the original. Say what a reader no longer has to infer or look up. If the only gain is fewer lines, keep looking.
4. Verify the behavior at its boundary. Record source evidence and executed checks separately. Review using the [Ruby/Rails rubric](apex-human-code-quality-rubric-2026-11-06.md).

<a id="sources"></a>
## Books and reading coverage

This guide uses readable chapters and excerpts selected for their relevance to the way people understand and change Ruby code. Goodreads figures are indexed snapshots from the linked listings and can change. They help select books. The cited passages support the rules.

| Book | Reader ratings | Text used |
| --- | --- | --- |
| *99 Bottles of OOP*, second edition, Sandi Metz, Katrina Owen and TJ Stankus | [4.55/5 from 676 ratings on the second-edition listing](https://www.goodreads.com/book/show/54500642-99-bottles-of-oop). Goodreads aggregates this work across editions. | [Author's Ruby sample v2.2.0](https://sandimetz.com/99bottles-sample-ruby). Chapter 1 in full, §§2.1–2.3 and selected material from chapters 8 and 9. Supplied JavaScript v2.0.0 PDF (297 PDF pages, 2020), §§2.9–2.10, 3.6, 3.7.3, 4.4, 5.1.4, 6.2 and 6.6. |
| *Practical Object-Oriented Design*, Sandi Metz | [4.50/5 from 68 paperback ratings and 4.58/5 from 88 Kindle ratings for the second edition](https://www.goodreads.com/work/editions/19059453-practical-object-oriented-design-in-ruby). | [Second-edition publisher sample, chapter 3 in full](https://www.informit.com/content/images/9780134456478/samplepages/9780134456478_Sample.pdf#page=24), printed pp. 37–59. The [chapter reference](#practical-oo-chapters) cites selected passages from all nine chapters of the supplied first edition (272 PDF pages, second printing, April 2013). |
| *Eloquent Ruby*, first edition, Russ Olsen | [4.35/5 from 1,305 ratings on the first-edition listing](https://www.goodreads.com/en/book/show/9364729-eloquent-ruby). Goodreads aggregates the work across editions. | [Publisher sample, chapters 6 and 8 in full](https://www.informit.com/content/images/9780321584106/samplepages/0321584104.pdf), printed pp. 65–71 and 85–96. The [chapter reference](#eloquent-ruby-chapters) cites selected passages from all 31 chapters of the supplied first edition (442 PDF pages, first printing, February 2011). |

The supplied books predate this project's Rails 8.1 release. Their examples explain why a design choice helps a reader. Use current Ruby and Rails syntax for the implementation. When an example depends on request parameters, a database relation, a callback or a lock, check the corresponding Rails documentation and the version in `backend/Gemfile.lock`. Treat the JavaScript edition of *99 Bottles* as a source for the design reasoning and use the Ruby sample or original Ruby examples for syntax.

**Reading labels.** *Book* paraphrases the cited passage. *Framework* describes documented Rails behavior. *Apply here* is the project interpretation. Code blocks are original examples, with Rails fragments identified where they assume app classes or fixtures. References to supplied PDFs identify both printed and viewer page numbers. The coverage table lists the portions consulted for the guide.

<a id="router"></a>
## Find guidance by task

| If the reader needs to… | Start here |
| --- | --- |
| Understand why a branch exists | [B1 Show the cases](#b1), [B2 Delay speculative abstraction](#b2) |
| Choose a name, input or value shape | [B6 Name the inputs](#b6), [B8 Distinguish labels and text](#b8), [B9 Name the shared concept](#b9) |
| Choose a guard, a default or a collection operation | [B13 Make conditions easy to scan](#b13), [B14 Use the operation that states the result](#b14), [B15 Give omitted arguments a meaning](#b15) |
| Decide where a collaborator or integration belongs | [B4 Make the dependency small](#b4), [B5 Isolate a changing interface](#b5), [B7 Depend on a useful behavior](#b7), [B12 Ask for the outcome](#b12) |
| Decide where a rule belongs or whether to add a class | [B16 Give domain facts an owner](#b16), [B17 Limit what a caller knows](#b17), [B18 Choose a relationship](#b18) |
| Read a Rails action from route to result | [R1 Keep the request legible](#r1), [R2 Validate request shape and record scope](#r2), [B10 Keep each method at one level](#b10) |
| Evaluate a block wrapper or around callback | [B11 Name the guarantee](#b11), [R3 Show what commits](#state-changes) |
| Tell what survives a failure, retry or competing write | [R3 Show what commits](#state-changes), [R4 Keep external effects separate](#r4), [R6 Recheck under the relevant lock](#r6) |
| Check a refactor or assess a test | [B3 Change structure under a check](#b3), [B19 Verify the role played by a test double](#b19), [R5 Test at the boundary](#behavior-tests) |
| Apply these ideas to an end-to-end change | [Worked review of a staff action](#worked-review) |
| Review the resulting change | [Ruby/Rails rubric](apex-human-code-quality-rubric-2026-11-06.md#focused-review) |

<a id="b1"></a>
## B1. Show the business cases

**Book.** In the compact verse example, a reader must reconstruct the domain by reading conditions embedded in strings. The straightforward implementation exposes the cases even though it repeats some text. [*99 Bottles of OOP*, §§1.1.1 and 1.1.4](https://sandimetz.com/99bottles-sample-ruby)

**Apply here.** A handler that can accept, reject or require review should make those outcomes apparent. A short expression that combines three business decisions with formatting asks the next reader to reverse engineer the rule.

Original Ruby example.

```ruby
def outcome_label(outcome)
  case outcome
  when :accepted then "Accepted"
  when :rejected then "Rejected"
  when :needs_review then "Needs review"
  else
    raise ArgumentError, "Unknown outcome: #{outcome.inspect}"
  end
end
```

**Check.** Name the valid cases from the code. For a real response, also trace the treatment of an unknown value. Preserve the existing contract before changing that branch.

<a id="b2"></a>
<a id="extract-object"></a>
## B2. Extract when the common rule is understood

**Book.** The alternative verse implementations show the cost of guessing at future variation and of factoring pieces at the wrong level. Shared code adds a jump. It pays for that jump when the change it centralizes is worth the reading cost. [*99 Bottles of OOP*, §§1.1.2–1.1.3 and 1.3](https://sandimetz.com/99bottles-sample-ruby)

**Apply here.** Similar staff and patient forms can require different permissions or failure handling. Ask which future edit should affect both. Share that rule if it already exists. A new dispatcher with two modes only helps if the two actions really share a contract.

**Check.** Compare one proposed use before and after. State what knowledge moved out of the caller and where it lives now. If a change to one action would still require inspecting both modes, keep the actions explicit.

<a id="b3"></a>
## B3. Use behavior to hold a refactor steady

**Book.** The sample builds behavior through a failing check, a passing implementation and a structural improvement. The chapter 9 opening adds that tests can tell future readers how the domain works. In §2.10, comparing the output of two cooperating methods can let the same defect pass on both sides of the assertion. Metz distinguishes internal queries from commands with effects another part of the application needs. [*99 Bottles of OOP*, §§2.1–2.2 and chapter 9 opening](https://sandimetz.com/99bottles-sample-ruby) · Supplied JavaScript v2.0.0, §§2.9–2.10, printed pp. 44–46 (PDF pp. 58–60) · *Practical Object-Oriented Design in Ruby*, first edition, chapter 9, “Testing Outgoing Messages,” printed pp. 215–216 (PDF pp. 240–241).

**Apply here.** When moving reminder eligibility, name a specific allowed and excluded appointment. Set the expected outcomes independently of the rule under test. A call count for an internal eligibility query usually says little about which appointments qualify. A recorded delivery, required job enqueue or absence of a duplicate can be a meaningful effect when it is part of the caller's contract.

**Check.** Identify what would make the check fail. Compare the same contract before and after a structural change. Follow the repository's test policy and record any check you could not run.

<a id="b4"></a>
<a id="rule-owner"></a>
## B4. Give the collaborator the job and only the knowledge it needs

**Book.** The gear example counts knowing another class, the message, its arguments and their order as separate dependencies. Supplying the collaborator lets the calculation depend on its needed behavior without knowing how the collaborator is assembled. [*Practical Object-Oriented Design*, §§3.1.1 and 3.2.1](https://www.informit.com/content/images/9780134456478/samplepages/9780134456478_Sample.pdf#page=26)

**Apply here.** If an operation needs a recipient and a clock, ask why it receives a coordinator, clinic, appointment and session. Give it the information necessary for its own rule. Put object construction where the concrete choice is understood. Direct calls to stable Rails models can stay direct.

Original Ruby fragment. The caller supplies the already selected recipient and configured delivery collaborator. The example only checks the deadline.

```ruby
def deliver_due_reminder(reminder:, recipient:, delivery:, now:)
  return :not_due if reminder.due_at > now

  delivery.deliver(recipient: recipient, message: reminder.message)
end
```

**Check.** Follow the real call. Could a reader identify the operation's necessary collaborators from its inputs? Does the recipient decision have one authoritative owner?

<a id="b5"></a>
## B5. Contain a changing external contract

**Book.** Metz shows how to isolate vulnerable external calls and how a wrapper can confine an interface whose argument order the application cannot control. She distinguishes such calls from simple external sends that are already easy to read. [*Practical Object-Oriented Design*, §3.2.2, vulnerable messages](https://www.informit.com/content/images/9780134456478/samplepages/9780134456478_Sample.pdf#page=33) · [§3.2.3, wrapping an external interface](https://www.informit.com/content/images/9780134456478/samplepages/9780134456478_Sample.pdf#page=39)

**Apply here.** Keep PMS field names, type conversion and read-only connection details at the actual PMS boundary. Preserve raw values where the assessment needs them. If a caller can use an Active Record association directly, a wrapper that only rebrands that association introduces another place to look.

**Check.** Imagine one concrete provider field or API change. Which code changes and why? A useful adapter keeps that change at the boundary and gives callers a clearer contract.

<a id="b6"></a>
## B6. Put intent and units in the inputs

**Book.** Metz shows how keyword arguments free callers from remembering positions. Olsen makes a parameter clearer by naming the unit it counts. [*Practical Object-Oriented Design*, §3.2.3](https://www.informit.com/content/images/9780134456478/samplepages/9780134456478_Sample.pdf#page=35), [*Eloquent Ruby*, chapter 8, “Required Ceremony Versus Programmer-Driven Clarity,” p. 92](https://www.informit.com/content/images/9780321584106/samplepages/0321584104.pdf#page=46)

**Apply here.** A pair of times or booleans invites swapped arguments. Use keywords when their roles are ambiguous. A single obvious argument can remain positional. If a value depends on timezone or unit, show that in the name or the value type.

Original Ruby example.

```ruby
def due_for_review?(due_at:, now:)
  due_at <= now
end
```

**Check.** Read the call without opening its definition. Can you tell which time is the deadline, which is the observation time and whether equality is due?

<a id="b7"></a>
## B7. Require the behavior the caller uses

**Book.** Olsen's file and string examples illustrate that objects with different implementations can serve a caller through the same useful method. Metz asks which end of a dependency is more likely to change. [*Eloquent Ruby*, chapter 8, “In the Wild,” pp. 94–96](https://www.informit.com/content/images/9780321584106/samplepages/0321584104.pdf), [*Practical Object-Oriented Design*, §3.3.2](https://www.informit.com/content/images/9780134456478/samplepages/9780134456478_Sample.pdf#page=42)

**Apply here.** For a genuine alternate source, define what a read returns and how it reports a failure. Leave interface selection at the place that knows which implementation to use. A nominal class check by itself doesn't validate a row, and an abstraction for a single stable collaborator may add work.

**Check.** Verify the same contract against a substitute and the relevant real adapter. Keep any stub result distinct from real integration evidence.

<a id="b8"></a>
## B8. Distinguish labels and text at boundaries

**Book.** Olsen separates symbols used as identifiers from strings used as text, and shows why a plain hash indexed with the wrong kind of key silently returns the wrong result. [*Eloquent Ruby*, chapter 6, “Staying Out of Trouble,” p. 70](https://www.informit.com/articles/article.aspx?p=1681756&seqNum=5)

**Apply here.** Define the key and value types at the JSON and PMS boundaries. Normalize only where the consumer has a reason to expect a different form. Keep a record as a record when callers need its behavior. Keep display text distinct from an internal outcome.

Original Ruby fragment for a response whose contract uses a string key.

```ruby
def notice_from_response(payload)
  payload.fetch("notice")
end
```

**Check.** Trace one valid value, one missing field and one blank value. Decide which can use a default and which signals an unexpected response.

<a id="b9"></a>
## B9. Find the shared concept in a concrete difference

**Book.** The authors compare nearby cases and work through their smallest differences. When a remaining difference reveals a useful idea, they name it in the vocabulary of the problem. *99 Bottles of OOP*, second edition, supplied JavaScript v2.0.0, §§3.6 and 3.7.3, printed pp. 59–60 and 64–65 (PDF pp. 73–74 and 78–79).

**Apply here.** Compare real reminder rules before creating a general policy. Initial and backup messages may share the requirement for a usable destination while having distinct due times. If a requirement changes which destinations qualify, give the shared decision a domain name. Keep independent schedule rules visible. Each structural step should preserve the affected behavior before you make a policy change.

**Check.** Show two concrete cases and the one difference the extraction resolves. Name a case that would expose a false equivalence, such as an eligible destination whose reminder is still too early.

<a id="b10"></a>
## B10. Keep each method at one level of explanation

**Book.** Olsen splits a working compression routine into methods with a single job, a consistent level of detail and names that explain their purpose. *Eloquent Ruby*, first edition, chapter 10, “Composing Methods for Humans,” printed pp. 121–122 (PDF pp. 149–150).

**Apply here.** A request action should let the reader follow request scope, the operation and the response without reconstructing the storage format for a cached appointment. Put storage details with the code that reads or writes that representation. Keep decisions about authorization and commit order discoverable at the boundary where they matter.

**Check.** Read the entry point without jumping into each method. You should be able to describe the order and what each step guarantees. If an extraction only renames a trivial call and gives the reader another file to visit, it has little value.

<a id="b11"></a>
## B11. Name the guarantee around a block

**Book.** Olsen shows how an around method can centralize preparation and cleanup, return the block's result and handle failure consistently. The name should explain the operation in the caller's terms. *Eloquent Ruby*, first edition, chapter 18, printed pp. 224, 226 and 228 (PDF pp. 252, 254 and 256).

**Apply here.** Keep a wrapper when it provides a genuine guarantee such as holding a lock through an operation. Read its name as a caller. A database helper that also decides whether to import source data or render a response makes those decisions harder to see. Where refresh and staff action have separate durability requirements, keep both boundaries apparent in the workflow. The book explains the block pattern. Rails and the assessment contract determine commit behavior.

Original Ruby fragment. `File.open` owns the file's lifetime. The caller describes the work and receives its result.

```ruby
bytes_written = File.open(report_path, "w") do |file|
  file.write(report_text)
end
```

The file closes if the block raises. For Appointment Flow's database locks, verify the relevant connection and transaction guarantees separately.

**Check.** Name the setup, result, cleanup and error behavior. Trace what commits separately from what the block returns.

<a id="b12"></a>
## B12. Ask the rule owner for the outcome

**Book.** Metz contrasts telling a collaborator each preparation step with asking it for the prepared result. The caller stops knowing which steps the collaborator uses and has fewer methods to depend on. *Practical Object-Oriented Design in Ruby*, first edition, chapter 4, “Asking for ‘What’ Instead of Telling ‘How’,” printed pp. 69–72 (PDF pp. 94–97).

**Apply here.** A reminder sender should be able to ask for the eligible recipient without knowing how contact preferences and guardian rules are checked. The recipient rule needs the facts it consumes. Passing a whole coordinator to the rule makes the reader trace a wider set of possible callbacks. Keep transaction and request ordering with the caller that genuinely owns them.

Original Ruby fragment. The selector owns the recipient decision, and the caller still handles the outcome.

```ruby
recipient = recipient_policy.eligible_recipient_for(appointment)
return :no_eligible_recipient unless recipient

delivery.deliver(recipient: recipient, message: message)
```

**Check.** Change a recipient rule in your head. Which code would need to change, and would a caller still understand why it receives no recipient?

<a id="b13"></a>
## B13. Make conditions easy to scan

**Book.** Olsen uses Ruby's modifier form for a single action under a simple condition. He also points out that zero is true in a Ruby condition. *Eloquent Ruby*, first edition, chapter 2, printed pp. 19–20 and 23 (PDF pp. 47–48 and 51).

**Apply here.** Use a short guard when a reader can understand the exit in one pass. Keep a block when a branch has several meaningful steps. Name a compound predicate only when its name explains a domain concept. Check a value with the operation that matches its meaning. An appointment count of zero is different from a missing value.

Original Ruby fragments for two independent cases.

```ruby
return :not_due if appointment.starts_at > reminder_cutoff
```

```ruby
if pending_count.zero?
  "No follow-ups due"
else
  "#{pending_count} follow-ups due"
end
```

**Check.** Read the normal path and each early exit. For a time condition, include the exact threshold in the check. For an input, account for missing values and valid zeroes separately.

<a id="b14"></a>
## B14. Use a collection operation that states the result

**Book.** Olsen replaces a manual search and index counter with `find_index` and uses `map` for a transformation. His sorting example distinguishes returning a new collection from changing a shared one. *Eloquent Ruby*, first edition, chapter 3, printed pp. 34–37 (PDF pp. 62–65).

**Apply here.** On a loaded Ruby collection, use the operation that tells the reader whether you search, transform, group or change it. On an Active Record relation, keep database filtering and ordering in the query when that expresses the same contract. Ruby enumeration may load rows the caller never needed. Use `each` when the purpose is performing work for every element. Check mutation and failure behavior against the actual method contract. A bang has different meanings on different APIs. [Rails 8.1 Query Interface, Filtering Records and Ordering Records](https://guides.rubyonrails.org/v8.1/active_record_querying.html#filtering-records)

Original fragments. The first operates on an already loaded array. The second expresses a database query on an illustrative association.

```ruby
ordered_appointments = appointments.sort_by(&:starts_at)
appointment_ids = ordered_appointments.map(&:id)
```

```ruby
scheduled_appointments = clinic.appointments.where(status: "scheduled").order(:starts_at)
```

**Check.** Explain where filtering and sorting run, which records are loaded, and whether callers rely on the original collection order. Preserve a required tie-breaker when changing a report's sort.

<a id="b15"></a>
## B15. Give an omitted argument a meaning

**Book.** The authors use an explicit default to keep an existing call working during a refactor. Once both callers pass the number, they remove that temporary default. *99 Bottles of OOP*, second edition, supplied JavaScript v2.0.0, §4.4, printed pp. 83–86 (PDF pp. 97–100).

**Apply here.** An optional argument should communicate a valid, stable choice. Require clinic scope for a scoped operation. Pass the observation time when the caller needs multiple decisions to share the same instant. Treat a default added during a migration as temporary when the final call sites can all supply the input.

Original Ruby fragments. The first requires scope. The second is an illustrative display preference with an intentional default.

```ruby
def scheduled_for(clinic:)
  clinic.appointments.where(status: "scheduled")
end
```

```ruby
def clinic_label(clinic, include_code: false)
  return clinic.name unless include_code

  "#{clinic.name} (#{clinic.code})"
end
```

**Check.** Compare omission, an explicit value and `nil` when it can reach the boundary. Ruby keyword defaults apply to omitted arguments. Inspect how the caller would read the choice after a migration.

<a id="b16"></a>
## B16. Give domain facts an owner before formatting them

**Book.** A string shortcut produces the expected display for a new case while leaving its underlying quantity and container behavior wrong. The authors implement those domain concepts directly so other callers receive correct answers. *99 Bottles of OOP*, second edition, supplied JavaScript v2.0.0, §6.6, printed pp. 175–176 (PDF pp. 189–190).

**Apply here.** An overdue follow-up label should describe an overdue decision already made by the rule owner. A serializer formats the decision for its audience. If a report and an action depend on the same fact, a change in its definition should have an identifiable place to go. Use an explicit domain name when the rule and a convenient formatted label differ.

Original Ruby fragments for a list of open follow-ups. The presentation step consumes an already evaluated fact.

```ruby
overdue = follow_up.overdue_at?(now)
```

```ruby
payload = { id: follow_up.id, overdue: overdue, label: overdue ? "Overdue" : "Open" }
```

**Check.** Locate the decision and its consumers. Verify a boundary case against the rule and verify that the response expresses the same outcome.

<a id="b17"></a>
## B17. Limit the representation a caller needs to know

**Book.** Metz shows how a method can give a changing value one place to be defined. She also warns that delegation can hide the visible chain of calls while leaving its coupling intact. *Practical Object-Oriented Design in Ruby*, first edition, chapter 2, printed pp. 24–25 (PDF pp. 49–50), and chapter 4, printed p. 82 (PDF p. 107). The *99 Bottles* authors show a related dependency when several callers interpret the same raw number. *99 Bottles of OOP*, second edition, supplied JavaScript v2.0.0, §5.1.4, printed p. 116 (PDF p. 130).

**Apply here.** A formatter can read an ordinary model attribute directly. A decision about whom to contact should consume a meaningful result from the rule owner. Look for callers that extract fields from several nested objects and independently rebuild the same rule. Move the decision when that removes knowledge from those callers. A new method that forwards a chain unchanged may only relocate the problem.

**Check.** Imagine changing how contact permission is stored. Identify which objects need to know the new shape and why. Follow dependencies rather than counting dots. A chain of query scopes can still be clear when each operation works on the same relation.

<a id="b18"></a>
## B18. Choose a relationship that fits the change

**Book.** Metz weighs specialization, shared roles and assembled parts against their different costs. Composition can make individual parts easy to change while making their combined behavior harder to follow. *Practical Object-Oriented Design in Ruby*, first edition, chapter 8, “Choosing Relationships,” printed pp. 188–190 (PDF pp. 213–215).

**Book.** The *99 Bottles* example removes temporary forwarding methods after the extracted object takes over. Repeated conditionals still exist at that point and are treated as a separate decision. *99 Bottles of OOP*, second edition, supplied JavaScript v2.0.0, §6.2, printed pp. 146–148 (PDF pp. 160–162).

**Apply here.** Keep a small branch with its rule when the cases are local and easy to explain. Consider a collaborator when an independently changing decision has a clear result. Consider a role when multiple implementations already need to satisfy the same contract. Keep construction where the reader can see which concrete collaborators run. A new outcome should require changes to the business cases it actually affects.

| What you see | What to compare at the call site |
| --- | --- |
| One clear branch with a few known outcomes | Keep the direct case unless the change reveals a repeated decision. |
| The same variant check repeated across several decisions | Compare a single selection point with keeping the decision explicit in each caller. Look for a contract all variants can honor. |
| A workflow made from independently changing parts | Name the result each collaborator supplies and keep their execution order visible. |
| A helper that forwards to the original coordinator | Trace the actual owner. If the helper adds no contract or behavior, remove the extra hop. |

**Check.** Trace one ordinary case and the variation that motivated the change. Name which calls disappear and where a developer would make the next similar change.

<a id="b19"></a>
## B19. Check that a test double plays the same role

**Book.** Metz shows a passing test whose double and caller still use a method the real collaborator has replaced. She applies a shared role check to the real object and the double. *Practical Object-Oriented Design in Ruby*, first edition, chapter 9, “Using Role Tests to Validate Doubles,” printed pp. 224–226 (PDF pp. 249–251).

**Apply here.** A fake PMS reader can prove how an importer responds to a supplied row. The actual reader determines key names, date and time representations and how a missing row is reported. When a refactor touches that boundary, exercise the relevant expectation against both. A method-name assertion alone is too weak when correctness depends on the returned shape or failure behavior.

**Check.** Pick a plausible contract change, such as a missing source record returning `nil` where a fake returns an empty hash. Identify the test that would catch the mismatch. Use the smallest check that establishes the claim, and label evidence from fake and real collaborators separately.

<a id="r1"></a>
## R1. Make the Rails entry point legible

**Framework.** Rails routes an incoming request to a controller action. The action processes the request and produces its response. Controller callbacks can run before, after or around an action. [Rails 8.1 Action Controller Overview, §§1–2 and 7](https://guides.rubyonrails.org/v8.1/action_controller_overview.html#introduction)

**Apply here.** Start at the route and action. Make it possible to see which clinic or record is selected, which rule decides the result and how that result reaches the caller. Name a shared callback for the exact check it performs. Keep an action readable through ordinary Rails operations where they express the same behavior.

**Check.** In an action using `Database.open`, identify what the wrapper actually does and which of its guarantees the path uses. Consider the existing Rails connection and transaction APIs. Remove the wrapper from that path only after verifying its database roles, transaction order and callers still behave correctly.

<a id="r2"></a>
## R2. Keep request shape and access separate

**Framework.** Strong parameters control which request fields may be used for mass assignment. They do not decide which records the requester is allowed to change. [Rails 8.1 Action Controller Overview, §4](https://guides.rubyonrails.org/v8.1/action_controller_overview.html#strong-parameters)

**Apply here.** Keep the permitted fields visible and scope the target record using the existing clinic or token rules. Do that before work that changes app state. Recheck mutable facts at the write boundary if they can change after lookup. Preserve the assessment's existing access design.

Original Rails fragment for an illustrative association and validated attribute.

```ruby
def update
  note = current_clinic.notes.find(params[:id])
  note.update!(params.expect(note: [:body]))
  render json: { id: note.id, body: note.body }
end
```

**Check.** Send a valid field to an out-of-scope record and verify that it remains unchanged. Also check what the caller sees on rejected input. The example assumes the application already handles relevant exceptions.

<a id="r3"></a>
<a id="state-changes"></a>
## R3. Show what commits together

**Framework.** An Active Record transaction applies to a database connection. An exception escaping the transaction block normally causes rollback and propagates. Rescuing it inside the block can allow a commit. `ActiveRecord::Rollback` is handled differently. Nested transactions normally join the parent, while a savepoint still depends on the outer transaction's commit. [Rails 8.1 Active Record Transactions, “Exception handling and rolling back” and “Nested transactions”](https://api.rubyonrails.org/v8.1/classes/ActiveRecord/Transactions/ClassMethods.html)

**Apply here.** Keep the transaction boundary visible where it owns the related writes. A rejected action returned as an ordinary result can allow prior writes in the block to commit. Replacing that return with an exception can change what persists. Preserve the deliberate difference in Appointment Flow between a source import that survives later rejection and work that must roll back together.

Original Rails fragment. Both writes use the application connection.

```ruby
ApplicationRecord.transaction do
  task.update!(completed_at: now)
  task.events.create!(kind: "completed", occurred_at: now)
end
```

**Check.** For each changed branch, predict stored records after success, normal rejection and an exception. Verify the app database state and the returned response. Preserve necessary locks and their order.

<a id="r4"></a>
## R4. Separate the commit from external effects

**Framework.** A transaction covers one database connection. Rails provides commit callbacks that run after the database commits. An outside effect performed from a commit callback cannot be rolled back by the already committed transaction. [Rails 8.1 Active Record Transactions, “Transactions are not distributed across database connections” and “Callbacks”](https://api.rubyonrails.org/v8.1/classes/ActiveRecord/Transactions/ClassMethods.html)

**Apply here.** The PMS reader uses SELECT. App writes stay on the app database. Trace outbound reminder work to its existing recorded state and repeat protection. If a job is re-run after an interrupted attempt, distinguish another attempt from another delivery. Do not infer a need for a new worker or storage layer until you can describe the missing guarantee.

**Check.** Write down what happens when the local write fails, when external work fails after commit and when the same work runs twice. Check only the cases the change touches. Use the runtime boundary for guarantees that depend on real persistence or delivery.

<a id="r5"></a>
<a id="behavior-tests"></a>
## R5. Test the boundary that owns the promise

**Framework.** Rails integration tests exercise interactions among app parts. System tests run through a browser and cost more to maintain. [Rails 8.1 Testing Guide, §§6 and 7.1](https://guides.rubyonrails.org/v8.1/testing.html#integration-testing)

**Apply here.** Use a focused rule check for a pure decision and a request or database check for authorization, persistence or rollback. A browser check is useful for a user-visible result. A fixture with a meaningful name helps the reader predict the outcome before reading the assertions.

**Check.** Match each claim to evidence. A request result can prove the response for that test. A state assertion can prove its corresponding writes. A visual walkthrough can prove what was observed in that run. A developer's ability to trace the code is a separate assessment.

<a id="r6"></a>
## R6. Recheck mutable facts under the relevant lock

**Framework.** Active Record's `with_lock` runs the block in a transaction and reloads the record under a row lock before yielding. The lock protects the rows it covers. The enclosing transaction still governs when the write commits. [Rails 8.1 Pessimistic Locking, `lock!` and `with_lock`](https://api.rubyonrails.org/v8.1/classes/ActiveRecord/Locking/Pessimistic.html)

**Apply here.** Check request scope before side effects. Recheck state that can change between that lookup and the write under the existing concurrency protocol. A row lock on a follow-up does not protect a separately scoped import, job, or delivery. Identify the operation that owns each lock and the order in which it acquires them. Keep source refresh outside the action transaction where the existing contract requires it to survive action failure.

Original Rails fragment for one record on the application connection. The illustrative event belongs to the same completion operation.

```ruby
task.with_lock do
  if task.completed_at
    :already_completed
  else
    task.update!(completed_at: now)
    task.events.create!(kind: "completed", occurred_at: now)
    :completed
  end
end
```

**Check.** Arrange two attempts against the same initially eligible record. Verify the second evaluates the updated state and that the operation records only the intended effect. Verify rollback of both writes if the event fails. For locks covering several records or processes, use a check that exercises that actual scope.

<a id="worked-review"></a>
## Worked review of a staff action

Use a staff action that requires current source data as the trace. The table describes the project contract to verify against the branch under review. It is an application of the guide, rather than a claim about the books or an implementation to copy.

| Step | What the reader should be able to explain | Where to look |
| --- | --- | --- |
| Scope | Which clinic and case can this request act on? What happens before an out-of-scope request exits? | [R2](#r2) |
| Refresh | Which action requires fresh source data? What is the response if the required refresh fails? | [B1](#b1), [B11](#b11) |
| Commit | Which successful refresh survives a later rejected action? Which action writes must succeed together? | [R3](#r3), [R6](#r6) |
| Decide | Which owner knows the rule for a stale or closed case? Can the caller request its decision without reconstructing it? | [B12](#b12), [B16](#b16) |
| Respond | Which result tells staff that the action succeeded or requires a fresh view? Does the response reflect the actual persisted state? | [B10](#b10), [R5](#r5) |

For an out-of-scope request, check that it produces no refresh or action writes. For a successful refresh followed by a rejected action, check that the refresh persists. Distinguish a conflict returned as a value, which may allow reconciliation to commit, from a failure raised out of the transaction. Verify the record states and the response together. If the UI is part of the change, check how it handles each outcome with the [frontend guide](Frontend-Coding-Guide.md#start).

Use the trace to decide whether an extraction helps. If an action currently sends a flag to a helper and the reader has to inspect that helper to learn when the refresh commits, expose the boundary in the workflow. If a block only acquires and releases a resource, name the resource guarantee and keep the block. Compare what the reader must know in each design and preserve the same observable behavior.

<a id="handoff"></a>
## Handoff

Give one before-and-after trace from the real entry point. Show the rule owner, the contract the caller relies on and the visible result. If writes matter, state what survives failure and retry. Record the checks run and what remains unverified. For a screen and API change, use the [frontend guide](Frontend-Coding-Guide.md#start) alongside this guide.

<a id="chapter-reference"></a>
## Chapter reference for both books

The reference covers every numbered chapter in the supplied first editions. Each summary draws on the cited passages, including chapter openings, conclusions and selected sections relevant to the examples. Printed pages are the numbers on the book pages. PDF pages count from the first page in the viewer. Examples are original Ruby illustrations. A Rails or test fragment assumes the named application objects or fixtures.

Use the [task index](#router) first for a code change. Open the matching chapter when a recommendation needs its rationale, a concrete example or a review question. These chapters include language features such as metaprogramming and packaging. Adopt a feature when it solves the task's actual problem.

<a id="eloquent-ruby-chapters"></a>
## Eloquent Ruby

Russ Olsen, first edition, first printing, February 2011. Supplied 442-page PDF. Printed page 1 is PDF page 29.

- [1. Write Code That Looks Like Ruby](#er-01)
- [2. Choose the Right Control Structure](#er-02)
- [3. Take Advantage of Ruby’s Smart Collections](#er-03)
- [4. Take Advantage of Ruby’s Smart Strings](#er-04)
- [5. Find the Right String with Regular Expressions](#er-05)
- [6. Use Symbols to Stand for Something](#er-06)
- [7. Treat Everything Like an Object—Because Everything Is](#er-07)
- [8. Embrace Dynamic Typing](#er-08)
- [9. Write Specs!](#er-09)
- [10. Construct Your Classes from Short, Focused Methods](#er-10)
- [11. Define Operators Respectfully](#er-11)
- [12. Create Classes That Understand Equality](#er-12)
- [13. Get the Behavior You Need with Singleton and Class Methods](#er-13)
- [14. Use Class Instance Variables](#er-14)
- [15. Use Modules as Name Spaces](#er-15)
- [16. Use Modules as Mixins](#er-16)
- [17. Use Blocks to Iterate](#er-17)
- [18. Execute Around with a Block](#er-18)
- [19. Save Blocks to Execute Later](#er-19)
- [20. Use Hooks to Keep Your Program Informed](#er-20)
- [21. Use method_missing for Flexible Error Handling](#er-21)
- [22. Use method_missing for Delegation](#er-22)
- [23. Use method_missing to Build Flexible APIs](#er-23)
- [24. Update Existing Classes with Monkey Patching](#er-24)
- [25. Create Self-Modifying Classes](#er-25)
- [26. Create Classes That Modify Their Subclasses](#er-26)
- [27. Invent Internal DSLs](#er-27)
- [28. Build External DSLs for Flexible Syntax](#er-28)
- [29. Package Your Programs as Gems](#er-29)
- [30. Know Your Ruby Implementation](#er-30)
- [31. Keep an Open Mind to Go with Those Open Classes](#er-31)

<a id="er-01"></a>
### 1. Write Code That Looks Like Ruby

**Passages consulted.** Printed pp. 3, 15 (PDF pp. 31, 43).

**Chapter summary.** Olsen treats idiom as a way to reduce the translation a reader has to do. Predictable indentation, familiar names and restrained comments help readers see the operation. Apply conventions with judgment when a layout or comment makes a real constraint easier to understand.

**Example 1.** Use a predictable class name and a verb for the action.

```ruby
class ScheduleExport
  def file_name(clinic_code)
    "schedule-#{clinic_code}.csv"
  end
end
```

**Example 2.** Explain the reason for an ordering constraint beside the operations it affects. This fragment assumes an existing importer and action.

```ruby
# A successful refresh must survive rejection of the action.
importer.refresh!
record_staff_action.call
```

**Review question.** Can the reader recognize the operation before reading its implementation?

<a id="er-02"></a>
### 2. Choose the Right Control Structure

**Passages consulted.** Printed pp. 17, 19–20, 23, 27 (PDF pp. 45, 47–48, 51, 55).

**Chapter summary.** Choose the Ruby form that makes the direction of a condition easy to read. A short conditional action can fit a modifier. Separate several meaningful outcomes with branches a reader can scan. In Ruby, an integer zero still counts as true.

**Example 1.** Put a straightforward rejection at the top of a method.

```ruby
def export_status(rows, allowed:)
  return :denied unless allowed

  rows.empty? ? :empty : :ready
end
```

**Example 2.** Use explicit cases when each branch has a distinct display meaning.

```ruby
def delivery_label(status)
  case status
  when :queued then "Queued"
  when :failed then "Delivery failed"
  else "Unknown delivery status"
  end
end
```

**Review question.** Can you describe what happens at zero, nil and the exact boundary where they matter?

<a id="er-03"></a>
### 3. Take Advantage of Ruby’s Smart Collections

**Passages consulted.** Printed pp. 29, 34–37, 42 (PDF pp. 57, 62–65, 70).

**Chapter summary.** Ruby collections give names to common operations. An index search, a transformation and a reduction have different results. Selecting the appropriate operation exposes the result type and avoids manual counters. Check which methods change the collection shared by other callers.

**Example 1.** Find a row without building a second collection.

```ruby
def find_appointment(rows, appointment_id)
  rows.find { |row| row.fetch(:id) == appointment_id }
end
```

**Example 2.** Group rows for a report and derive a separate count for each clinic.

```ruby
by_clinic = appointments.group_by(&:clinic_id)
counts_by_clinic = by_clinic.transform_values(&:size)
```

**Review question.** Does this operate on loaded Ruby data or should the database perform the filtering?

<a id="er-04"></a>
### 4. Take Advantage of Ruby’s Smart Strings

**Passages consulted.** Printed pp. 43, 49, 52 (PDF pp. 71, 77, 80).

**Chapter summary.** Ruby strings have several literal forms and a substantial API. Select the form that makes escaping, interpolation and the intended operation obvious. Be deliberate about whether the operation concerns lines, text or bytes.

**Example 1.** A heredoc shows the shape of a short report without embedded newline escapes.

```ruby
report = <<~TEXT
  Clinic: #{clinic_name}
  Pending follow-ups: #{pending_count}
TEXT
```

**Example 2.** Use the string operation that corresponds to the rule. This removes surrounding whitespace from a display value.

```ruby
def display_clinic_name(raw_name)
  raw_name.strip
end
```

**Review question.** Does a size constraint concern bytes sent to an external system or characters shown to a person?

<a id="er-05"></a>
### 5. Find the Right String with Regular Expressions

**Passages consulted.** Printed pp. 53, 64 (PDF pp. 81, 92).

**Chapter summary.** A regular expression describes a textual pattern directly. It can replace a manual sequence of character tests when the format is constrained. Give a pattern a name that explains the accepted shape and handle a failed match at the boundary.

**Example 1.** Validate the complete form of an illustrative source identifier.

```ruby
SOURCE_ID = /\A[A-Z]{2}-\d{6}\z/

def source_id?(value)
  SOURCE_ID.match?(value)
end
```

**Example 2.** Capture named fields and represent a failed match explicitly.

```ruby
def parse_slot(value)
  match = /\A(?<hour>[01]\d|2[0-3]):(?<minute>[0-5]\d)\z/.match(value)
  return unless match

  [match[:hour].to_i, match[:minute].to_i]
end
```

**Review question.** Would a trailing newline or invalid time be rejected as intended?

<a id="er-06"></a>
### 6. Use Symbols to Stand for Something

**Passages consulted.** Printed pp. 65, 70–71 (PDF pp. 93, 98–99).

**Chapter summary.** Symbols make useful internal names for fixed concepts. Strings carry text and often arrive at boundaries such as a JSON response. A plain Ruby hash distinguishes string and symbol keys, so a caller needs a clear key contract.

**Example 1.** Use a symbol for an internal decision and a string for the corresponding text.

```ruby
STATUS_LABELS = { ready: "Ready", held: "Needs review" }.freeze

def status_label(status)
  STATUS_LABELS.fetch(status)
end
```

**Example 2.** Read the external key in the form the boundary supplies.

```ruby
def source_appointment_id(json_payload)
  json_payload.fetch("appointment_id")
end
```

**Review question.** Can a reader see where an external string becomes an internal label?

<a id="er-07"></a>
### 7. Treat Everything Like an Object—Because Everything Is

**Passages consulted.** Printed pp. 73, 84 (PDF pp. 101, 112).

**Chapter summary.** Values such as numbers, booleans and nil participate in Ruby's object model. Readers can follow behavior through messages without inventing a separate representation for each primitive. Identity, equality and absent values have different meanings.

**Example 1.** Ask the integer a question that says what zero means in this decision.

```ruby
def pending_work?(pending_count)
  pending_count.positive?
end
```

**Example 2.** Use a named value to express an absence explicitly at the boundary.

```ruby
def observed_time(override, clock:)
  override.nil? ? clock.call : override
end
```

**Review question.** Does the code distinguish an absent value from a legitimate false value or zero?

<a id="er-08"></a>
### 8. Embrace Dynamic Typing

**Passages consulted.** Printed pp. 85, 94–96 (PDF pp. 113, 122–124).

**Chapter summary.** Olsen uses compatible behavior to let unrelated objects satisfy the same caller. A small, stable contract keeps the caller flexible. Documentation and tests still need to explain the arguments, result and failure behavior. Validate untrusted data where it enters.

**Example 1.** Both a file and an in-memory stream can supply lines.

```ruby
def clinic_codes(source)
  source.each_line.map { |line| line.strip }.reject(&:empty?)
end
```

**Example 2.** Accept a clock that answers the one question this rule needs.

```ruby
def reminder_due?(due_at:, clock:)
  due_at <= clock.call
end

fixed_clock = -> { Time.utc(2026, 11, 10, 12) }
```

**Review question.** What message does the caller require, and which test proves the relevant behavior on a real collaborator?

<a id="er-09"></a>
### 9. Write Specs!

**Passages consulted.** Printed pp. 97, 113 (PDF pp. 125, 141).

**Chapter summary.** Automated tests make behavior repeatable as the implementation changes. Olsen values tests a reader can understand and uses test frameworks of the period to illustrate that goal. In this project, follow the existing test framework and verify the behavior at the layer that owns it.

**Example 1.** A Minitest fragment documents the inclusive deadline. It assumes the rule is already in scope.

```ruby
def test_reminder_is_due_at_the_deadline
  deadline = Time.utc(2026, 11, 10, 12)

  assert reminder_due?(due_at: deadline, clock: -> { deadline })
end
```

**Example 2.** A Rails request test fragment checks the effect that an access rejection must avoid. The route and credentials are test fixtures.

```ruby
assert_no_difference("FollowUp.count") do
  post restricted_follow_ups_path, params: follow_up_params
end
assert_response :forbidden
```

**Review question.** What regression would fail each assertion, and would a private rename leave the test intact?

<a id="er-10"></a>
### 10. Construct Your Classes from Short, Focused Methods

**Passages consulted.** Printed pp. 117, 121–122, 128 (PDF pp. 145, 149–150, 156).

**Chapter summary.** The composed method puts a single job at one level of explanation. A method with a meaningful name can let its caller explain the sequence without learning every detail. Judge an extraction by what it removes from the reader's working knowledge.

**Example 1.** Keep the decision and the response at the level of the action. This Rails fragment assumes scope and handling of lookup failures.

```ruby
def show
  follow_up = current_clinic.follow_ups.find(params[:id])
  render json: FollowUpSerializer.new(follow_up).as_json
end
```

**Example 2.** Give a meaningful calculation its own name when it hides the representation of a window.

```ruby
def active_at?(time)
  starts_at <= time && time < ends_at
end
```

**Review question.** Does each name tell the reader more than the implementation's syntax does?

<a id="er-11"></a>
### 11. Define Operators Respectfully

**Passages consulted.** Printed pp. 129, 139 (PDF pp. 157, 167).

**Chapter summary.** An operator is a Ruby method with familiar expectations attached. A new implementation should preserve the meaning its call site suggests. A named method is easier to understand for an operation whose effect or output would surprise someone reading an operator.

**Example 1.** Addition can reasonably return a new count of the same kind.

```ruby
PendingCount = Data.define(:value) do
  def +(other)
    self.class.new(value + other.value)
  end
end

total = PendingCount.new(2) + PendingCount.new(3)
```

**Example 2.** Name an action that changes records explicitly. This Rails fragment assumes an authorized, scoped record.

```ruby
follow_up.update!(completed_at: now)
```

**Review question.** Could a reader predict the result type and whether the operation changes either operand?

<a id="er-12"></a>
### 12. Create Classes That Understand Equality

**Passages consulted.** Printed pp. 141, 156 (PDF pp. 169, 184).

**Chapter summary.** Ruby distinguishes object identity, ordinary equality, case matching and the equality used by hash keys. Choose the comparison that matches the contract. A value used as a key needs stable, consistent equality and hashing.

**Example 1.** Use a value type whose components define the key. These identifiers are integers.

```ruby
AppointmentKey = Data.define(:clinic_id, :appointment_id)

counts = { AppointmentKey.new(2, 17) => 3 }
count = counts.fetch(AppointmentKey.new(2, 17))
```

**Example 2.** Inspect identity and value equality separately when ownership of a mutable object matters.

```ruby
original = ["scheduled"]
copy = original.dup
same_value = original == copy
same_object = original.equal?(copy)
```

**Review question.** Does this comparison mean the same database row, the same value or the same in-memory object?

<a id="er-13"></a>
### 13. Get the Behavior You Need with Singleton and Class Methods

**Passages consulted.** Printed pp. 157, 167 (PDF pp. 185, 195).

**Chapter summary.** A singleton method belongs to one receiver. A Ruby class is itself an object, so a class method is a method on that class object. Use class methods for operations that belong to the type and instance methods for behavior tied to a particular record.

**Example 1.** Keep a named constructor with the type it creates.

```ruby
ClinicCode = Data.define(:value) do
  def self.parse(input)
    new(input.strip.upcase)
  end
end
```

**Example 2.** Use a singleton method on one test object when the scope of the substitute is clear.

```ruby
clock = Object.new
def clock.call
  Time.utc(2026, 11, 10, 12)
end

observed_at = clock.call
```

**Review question.** Does the method actually need the class, a particular instance or a collaborator supplied by the caller?

<a id="er-14"></a>
### 14. Use Class Instance Variables

**Passages consulted.** Printed pp. 169, 179 (PDF pp. 197, 207).

**Chapter summary.** Olsen contrasts class variables shared through a hierarchy with instance variables stored on the class object. Their inheritance behavior differs. A reader needs to know whether settings are per class, inherited or per object. Request-specific facts belong in the request or operation.

**Example 1.** A class-instance value can be set independently on each exporter.

```ruby
class ExportFormat
  class << self
    attr_accessor :extension
  end
end

class CsvExport < ExportFormat
  self.extension = "csv"
end
```

**Example 2.** Keep per-operation values on the instance instead of writing process-wide state.

```ruby
class ReportWindow
  def initialize(observed_at:)
    @observed_at = observed_at
  end

  attr_reader :observed_at
end
```

**Review question.** If two requests or two subclasses use this setting, can one unexpectedly change the other's behavior?

<a id="er-15"></a>
### 15. Use Modules as Name Spaces

**Passages consulted.** Printed pp. 181, 191 (PDF pp. 209, 219).

**Chapter summary.** A module can organize related constants and classes, giving their names a scope and a place to look. A namespace helps when the prefix names a real boundary. In Rails, preserve the project’s relationship between constant names and file paths.

**Example 1.** Group an import error with the boundary that owns it.

```ruby
module Pms
  class InvalidSourceRow < StandardError
  end
end
```

**Example 2.** Refer to a qualified name at the caller so the failure boundary is visible.

```ruby
def validate_source_row(row)
  return if row.key?("appointment_id")

  raise Pms::InvalidSourceRow, "Missing appointment ID"
end
```

**Review question.** Does the namespace tell a reader where to find the code and why the pieces belong together?

<a id="er-16"></a>
### 16. Use Modules as Mixins

**Passages consulted.** Printed pp. 193, 205 (PDF pp. 221, 233).

**Chapter summary.** A mixin shares behavior through Ruby's method lookup without requiring the hosts to share a superclass. Its interface includes both what the module provides and what the host must supply. Make those expectations small and visible.

**Example 1.** The module provides a time predicate and expects its host to answer due_at.

```ruby
module DueAt
  def due_at_or_before?(time)
    due_at <= time
  end
end
```

**Example 2.** A value type supplies the required input. This fragment uses the module above.

```ruby
ReminderDeadline = Data.define(:due_at) do
  include DueAt
end

deadline = ReminderDeadline.new(Time.utc(2026, 11, 10, 12))
```

**Review question.** Can a developer list the host methods the module requires without inspecting unrelated classes?

<a id="er-17"></a>
### 17. Use Blocks to Iterate

**Passages consulted.** Printed pp. 207, 218 (PDF pp. 235, 246).

**Chapter summary.** An iterator lets an object choose what it yields and lets the caller choose what to do with each item. Enumerable can supply common operations when a type has a meaningful each contract. An iterator should disclose what it yields and whether traversal performs work.

**Example 1.** Return an enumerator when an iterator is called without a block.

```ruby
def each_scheduled(rows)
  return enum_for(__method__, rows) unless block_given?

  rows.each do |row|
    yield row if row.fetch(:status) == :scheduled
  end
end
```

**Example 2.** Use a caller block for the work it actually wants to perform. This fragment uses the iterator above.

```ruby
each_scheduled(appointments) do |appointment|
  export_row(appointment)
end
```

**Review question.** Would iteration load records or perform writes, and can a caller tell?

<a id="er-18"></a>
### 18. Execute Around with a Block

**Passages consulted.** Printed pp. 219, 224, 226, 228, 231 (PDF pp. 247, 252, 254, 256, 259).

**Chapter summary.** A method can own setup and cleanup while a block supplies the variable work. Its name should tell the caller what surrounds the operation. Preserve the intended block result, exception and cleanup behavior. Rails transaction durability has its own rules.

**Example 1.** Let the standard file API own the resource lifetime.

```ruby
bytes_written = File.open(report_path, "w") do |file|
  file.write(report_body)
end
```

**Example 2.** Use a transaction when the two illustrative application records must commit together.

```ruby
ApplicationRecord.transaction do
  follow_up.update!(completed_at: now)
  follow_up.events.create!(kind: "completed", occurred_at: now)
end
```

**Review question.** Can the reader predict the result and which cleanup or rollback happens if the block raises?

<a id="er-19"></a>
### 19. Save Blocks to Execute Later

**Passages consulted.** Printed pp. 233, 244–245 (PDF pp. 261, 272–273).

**Chapter summary.** A block can be kept and called later as a callback or lazy computation. It retains access to the surrounding variables, which can retain data longer than intended or expose a changed value when invoked. Name the trigger and keep captured state small.

**Example 1.** A lambda defers a pure calculation until the result is needed.

```ruby
def count_when_needed(rows)
  -> { rows.count { |row| row.fetch(:status) == :scheduled } }
end
```

**Example 2.** Capture an identifier by value for a process-local callback. This illustrates a closure, not a job payload.

```ruby
def after_save_notice(appointment_id, notifier:)
  -> { notifier.saved(appointment_id) }
end
```

**Review question.** When will the block run, which values will it see then, and is its lifetime confined to one process?

<a id="er-20"></a>
### 20. Use Hooks to Keep Your Program Informed

**Passages consulted.** Printed pp. 249, 261 (PDF pp. 277, 289).

**Chapter summary.** Ruby calls hooks at defined lifecycle events, such as subclass creation or module inclusion. A hook can keep registration or setup with the event that triggers it. Its costs include work happening implicitly and dependence on initialization order. Keep business writes at a point a reader can trace.

**Example 1.** A class-definition hook gives each subclass its own configuration array. This example is process-local.

```ruby
class ExportDefinition
  class << self
    attr_reader :columns

    def inherited(child)
      super
      child.instance_variable_set(:@columns, [])
    end
  end
end
```

**Example 2.** An inclusion hook installs a small class-level interface.

```ruby
module ExportNaming
  def self.included(base)
    base.extend(ClassMethods)
  end

  module ClassMethods
    def export_extension
      "csv"
    end
  end
end
```

**Review question.** Which event runs this code, and could a reload or repeated inclusion run it again?

<a id="er-21"></a>
### 21. Use method_missing for Flexible Error Handling

**Passages consulted.** Printed pp. 263, 271 (PDF pp. 291, 299).

**Chapter summary.** Ruby provides a fallback for missing methods and a separate fallback for unresolved constants. A fallback can give a more specific diagnostic for a narrowly understood case. Preserve the standard error path for unrelated misses. Rails code should use the application's existing constant loading conventions.

**Example 1.** Add a targeted diagnostic for a retired call and preserve normal lookup failures.

```ruby
class ReportResult
  private

  def method_missing(name, ...)
    if name == :raw_result
      raise NoMethodError, "Read the report through its documented fields"
    end

    super
  end
end
```

**Example 2.** When callers pass a data key, a regular method can report the error without changing Ruby method lookup.

```ruby
def required_column(columns, name)
  columns.fetch(name) do
    raise KeyError, "Unknown report column #{name.inspect}"
  end
end
```

**Review question.** Does an unexpected typo still fail at the correct boundary?

<a id="er-22"></a>
### 22. Use method_missing for Delegation

**Passages consulted.** Printed pp. 273, 283 (PDF pp. 301, 311).

**Chapter summary.** Delegation passes a request to a collaborator that can do the work. A missing-method proxy can forward many calls, which also makes its supported interface harder to see. For a fixed interface, declare the forwarded names. A dynamic proxy needs consistent reflection and failure behavior.

**Example 1.** Declare a single forwarded message.

```ruby
require "forwardable"

class ClinicReport
  extend Forwardable
  def_delegator :@clinic, :name, :clinic_name

  def initialize(clinic)
    @clinic = clinic
  end
end
```

**Example 2.** A constrained proxy forwards public calls and reports the same supported methods to introspection.

```ruby
class ReportReader
  def initialize(report)
    @report = report
  end

  private

  def method_missing(name, ...)
    return super unless supported?(name)

    @report.public_send(name, ...)
  end

  def respond_to_missing?(name, include_private = false)
    supported?(name) || super
  end

  def supported?(name)
    %i[title rows].include?(name) && @report.respond_to?(name)
  end
end
```

**Review question.** What messages cross the boundary and does the proxy preserve arguments, blocks and failures?

<a id="er-23"></a>
### 23. Use method_missing to Build Flexible APIs

**Passages consulted.** Printed pp. 285, 292 (PDF pp. 313, 320).

**Chapter summary.** A virtual method can decode its name and use part of it as data. This suits a family of operations with a consistent naming rule. It also makes definitions harder to find. A single method with an explicit input is easier to navigate when callers already hold the data.

**Example 1.** An illustrative status object maps a small set of virtual predicates to a value.

```ruby
class DeliveryState
  PREDICATES = { queued?: :queued, sent?: :sent }.freeze

  def initialize(state)
    @state = state
  end

  private

  def method_missing(name, *arguments)
    return super unless PREDICATES.key?(name) && arguments.empty? && !block_given?

    @state == PREDICATES.fetch(name)
  end

  def respond_to_missing?(name, include_private = false)
    PREDICATES.key?(name) || super
  end
end
```

**Example 2.** Pass the value explicitly when the name would otherwise carry the argument.

```ruby
def delivery_in_state?(delivery, state)
  delivery.status == state
end
```

**Review question.** Can a reader search for the supported operation and distinguish it from an invalid one?

<a id="er-24"></a>
### 24. Update Existing Classes with Monkey Patching

**Passages consulted.** Printed pp. 293, 303–304 (PDF pp. 321, 331–332).

**Chapter summary.** Reopening a class changes behavior for callers of that class. It can repair or extend existing code but affects more than the immediate use site. Before adopting a patch, identify the affected callers and how upgrades or load order could change the result.

**Example 1.** Reopen an illustrative class the application owns to demonstrate the language feature.

```ruby
class ReportRow
  attr_reader :values

  def initialize(values)
    @values = values
  end
end

class ReportRow
  def empty?
    values.empty?
  end
end
```

**Example 2.** Keep a specific display operation local when it belongs only to one report.

```ruby
def clinic_date_label(date)
  date.strftime("%Y-%m-%d")
end
```

**Review question.** Which callers acquire the change just because this file loads?

<a id="er-25"></a>
### 25. Create Self-Modifying Classes

**Passages consulted.** Printed pp. 305, 315–316 (PDF pp. 333, 343–344).

**Chapter summary.** Ruby executes a class body, so a declaration can generate or modify methods while the class is built. That can remove repeated definitions when the generated contract is regular. The benefit has to pay for the extra step a reader takes to find each method.

**Example 1.** Generate a small, fixed family of read methods from a declared set of fields.

```ruby
class ImportCounts
  FIELDS = %i[loaded rejected].freeze

  def initialize(counts)
    @counts = counts
  end

  FIELDS.each do |field|
    define_method(field) { @counts.fetch(field) }
  end
end
```

**Example 2.** A Minitest example exercises a generated method through its public contract.

```ruby
def test_rejected_count_uses_its_own_field
  counts = ImportCounts.new(loaded: 12, rejected: 2)

  assert_equal 2, counts.rejected
end
```

**Review question.** Are the method names, argument contracts and unknown cases visible somewhere a reader can search?

<a id="er-26"></a>
### 26. Create Classes That Modify Their Subclasses

**Passages consulted.** Printed pp. 317, 332 (PDF pp. 345, 360).

**Chapter summary.** A superclass or module can centralize a class-building operation so subclasses can declare the part that varies. The declaration is useful when its effect is predictable and its scope is per class. The abstraction costs more when developers have to inspect several layers to understand class construction.

**Example 1.** A macro defines one fixed instance method on the class that declares it.

```ruby
class ExportDefinition
  def self.media_type(value)
    define_method(:media_type) { value }
  end
end

class CsvExport < ExportDefinition
  media_type "text/csv"
end
```

**Example 2.** A class that has a distinct calculation can express it directly with a method.

```ruby
class WindowExport < ExportDefinition
  def media_type
    "application/json"
  end
end
```

**Review question.** Can a subclass add a supported variation without depending on class-definition side effects it cannot see?

<a id="er-27"></a>
### 27. Invent Internal DSLs

**Passages consulted.** Printed pp. 335, 349 (PDF pp. 363, 377).

**Chapter summary.** An internal domain-specific language uses Ruby's syntax to express a recurring problem in its own vocabulary. It can grow from a regular API when repetitive calls reveal a stable grammar. Its declarations should have a clear effect and leave errors intelligible.

**Example 1.** An existing Rails declaration explains a field requirement. This fragment assumes an illustrative Active Record model.

```ruby
class ImportedAppointment < ApplicationRecord
  validates :source_id, presence: true
end
```

**Example 2.** Start with a small visible interface for repeated report declarations. This fragment assumes report implements the column method.

```ruby
report.column :clinic_name, heading: "Clinic"
report.column :pending_count, heading: "Pending follow-ups"
```

**Review question.** Does the declaration shorten a real recurring task or make the execution path harder to find?

<a id="er-28"></a>
### 28. Build External DSLs for Flexible Syntax

**Passages consulted.** Printed pp. 351, 364–365 (PDF pp. 379, 392–393).

**Chapter summary.** An external language has its own grammar and parser. That gives authors control over what users can write and adds validation and error-reporting work. Choose it only when a meaningful input format requires it. Keep parsing separate from side effects.

**Example 1.** Parse a narrow report-filter grammar with a complete match.

```ruby
def parse_report_filter(input)
  match = /\Aclinic (?<code>[A-Z]{2})\z/.match(input)
  raise ArgumentError, "Expected clinic followed by a two-letter code" unless match

  { clinic_code: match[:code] }
end
```

**Example 2.** Translate the parsed value into a scoped query. This Rails fragment assumes accessible_clinics is already authorized.

```ruby
filters = parse_report_filter(input)
clinic = accessible_clinics.find_by!(code: filters.fetch(:clinic_code))
rows = clinic.appointments.where(status: "scheduled")
```

**Review question.** Which inputs are legal, how is an invalid one explained, and which code owns the effect?

<a id="er-29"></a>
### 29. Package Your Programs as Gems

**Passages consulted.** Printed pp. 367, 380 (PDF pp. 395, 408).

**Chapter summary.** A package captures the files, dependencies and interface required for someone else to load and use a library. Installation is part of the contract. A separate gem is valuable when there is a genuine independent consumer. Use the current RubyGems and Bundler workflow for package tooling.

**Example 1.** An illustrative gemspec declares the distributed entry point and required Ruby version.

```ruby
Gem::Specification.new do |spec|
  spec.name = "appointment_export"
  spec.version = "0.1.0"
  spec.summary = "Render appointment reports"
  spec.authors = ["Appointment Flow maintainers"]
  spec.files = Dir["lib/**/*.rb"]
  spec.require_paths = ["lib"]
  spec.required_ruby_version = ">= 3.2"
end
```

**Example 2.** A minimal entry file establishes the public require path.

```ruby
# lib/appointment_export.rb
require_relative "appointment_export/report"
```

**Review question.** Would the packaged files load in a fresh environment with the declared dependencies?

<a id="er-30"></a>
### 30. Know Your Ruby Implementation

**Passages consulted.** Printed pp. 381, 390 (PDF pp. 409, 418).

**Chapter summary.** The chapter explains how implementation details shape performance and language behavior. Its runtime descriptions reflect the publication period. For a current application, identify the actual engine and version and measure on the supported setup before drawing conclusions about optimization.

**Example 1.** Record the runtime with a measurement or reproduction.

```ruby
runtime = {
  engine: RUBY_ENGINE,
  version: RUBY_VERSION,
  platform: RUBY_PLATFORM
}
```

**Example 2.** Time the whole comparable operation with standard tooling. This fragment assumes an existing report builder and a representative fixture.

```ruby
require "benchmark"

elapsed_seconds = Benchmark.realtime do
  report_builder.call(fixture_rows)
end
```

**Review question.** Was the comparison made with the same runtime, workload and setup costs?

<a id="er-31"></a>
### 31. Keep an Open Mind to Go with Those Open Classes

**Passages consulted.** Printed pp. 391–392 (PDF pp. 419–420).

**Chapter summary.** Olsen closes by treating conventions as accumulated experience and asking readers to use judgment when a convention conflicts with clarity. A departure should solve a real problem that the reader can see. The project should still be able to explain and verify the behavior.

**Example 1.** An explicit case keeps a small set of business outcomes easy to scan.

```ruby
def staff_notice(outcome)
  case outcome
  when :saved then "Follow-up saved"
  when :stale then "Review the current follow-up"
  else "Follow-up could not be saved"
  end
end
```

**Example 2.** Use an explicit query when it keeps a reporting filter visible. This fragment assumes a scoped relation.

```ruby
appointments_in_window = scoped_appointments.where(starts_at: window)
```

**Review question.** What concrete reading or behavior problem justifies departing from the usual convention?

<a id="practical-oo-chapters"></a>
## Practical Object-Oriented Design in Ruby

Sandi Metz, first edition, second printing, April 2013. Supplied 272-page PDF. Printed page 1 is PDF page 26. The [reading coverage table](#sources) identifies the separate second-edition sample cited in some of the decision sections.

- [1. Object-Oriented Design](#po-01)
- [2. Designing Classes with a Single Responsibility](#po-02)
- [3. Managing Dependencies](#po-03)
- [4. Creating Flexible Interfaces](#po-04)
- [5. Reducing Costs with Duck Typing](#po-05)
- [6. Acquiring Behavior Through Inheritance](#po-06)
- [7. Sharing Role Behavior with Modules](#po-07)
- [8. Combining Objects with Composition](#po-08)
- [9. Designing Cost-Effective Tests](#po-09)

<a id="po-01"></a>
### 1. Object-Oriented Design

**Passages consulted.** Printed pp. 1, 14 (PDF pp. 26, 39).

**Chapter summary.** Metz defines design in terms of the cost of change. Patterns and metrics can expose friction, but a useful design has to fit a concrete change and its constraints. Begin with a real requirement and compare what a future reader will have to change.

**Example 1.** Keep a simple report calculation near the caller while it has one purpose.

```ruby
pending_count = appointments.count { |row| row.fetch(:status) == :pending }
```

**Example 2.** If multiple report formats are a real requirement, keep the count separate from the formatting operation.

```ruby
data = { clinic_name: clinic_name, pending_count: pending_count }
report_formatter.render(data)
```

**Review question.** Name the requirement that makes an extra boundary earn its maintenance cost.

<a id="po-02"></a>
### 2. Designing Classes with a Single Responsibility

**Passages consulted.** Printed pp. 15, 24–25, 34 (PDF pp. 40, 49–50, 59).

**Chapter summary.** A focused class groups behavior that changes for the same reason. Metz shows how a method can put the meaning of a value in one place. Look at the decisions a class owns rather than its line count. Keep a model's public behavior meaningful when the underlying representation changes.

**Example 1.** An illustrative record owns the deadline rule that depends on its own state.

```ruby
class FollowUp < ApplicationRecord
  def overdue_at?(time)
    completed_at.nil? && due_at <= time
  end
end
```

**Example 2.** A presenter consumes the answer to make display text for open follow-ups.

```ruby
def open_follow_up_label(follow_up, now:)
  follow_up.overdue_at?(now) ? "Overdue" : "Open"
end
```

**Review question.** Can you describe the class's job in domain terms and point to the one place a rule would change?

<a id="po-03"></a>
### 3. Managing Dependencies

**Passages consulted.** Printed pp. 35, 57 (PDF pp. 60, 82).

**Chapter summary.** Classes inevitably depend on messages, argument shapes and construction choices. Supply a collaborator where the concrete choice belongs. Keep fragile dependencies at an identifiable boundary and prefer depending on the more stable contract. Avoid passing broad context when the rule needs a small fact.

**Example 1.** Supply the observation time the decision needs, with its meaning visible at the call.

```ruby
def can_send_reminder?(appointment, observed_at:)
  appointment.starts_at > observed_at
end
```

**Example 2.** Keep a vendor's string keys and required conversion of a decimal string in the import boundary.

```ruby
def imported_appointment_id(source_row)
  Integer(source_row.fetch("appointment_id"), 10)
end
```

**Review question.** Which dependency would change if the source representation changes, and do callers need to know it?

<a id="po-04"></a>
### 4. Creating Flexible Interfaces

**Passages consulted.** Printed pp. 59, 69–72, 82–83 (PDF pp. 84, 94–97, 107–108).

**Chapter summary.** The messages between objects explain how the application works. Give a caller a stable question to ask and leave the mechanics with the owner of the answer. Delegation earns its place when it limits the knowledge the caller needs. Moving a chain behind another name can leave the same dependencies in place.

**Example 1.** Ask the recipient policy for the result using the smallest useful input.

```ruby
recipient = recipient_policy.eligible_recipient_for(appointment)
delivery.deliver_to(recipient) if recipient
```

**Example 2.** Keep an ordinary database relation readable when the action genuinely owns the scope.

```ruby
def scheduled_appointments_for(clinic)
  clinic.appointments.where(status: "scheduled")
end
```

**Review question.** After a policy change, does the caller still ask the same meaningful question?

<a id="po-05"></a>
### 5. Reducing Costs with Duck Typing

**Passages consulted.** Printed pp. 85, 104 (PDF pp. 110, 129).

**Chapter summary.** A role is a public contract that objects can satisfy without sharing a class hierarchy. A role makes sense when the caller actually needs the same behavior from different implementations. Define the result and error behavior so callers can trust the substitution.

**Example 1.** An importer depends on each_row and leaves the source choice to its caller.

```ruby
def import_rows(source, importer:)
  source.each_row do |row|
    importer.import_row(row)
  end
end
```

**Example 2.** An in-memory fixture source provides the same message and yields the same row shape.

```ruby
class FixtureRows
  def initialize(rows)
    @rows = rows
  end

  def each_row(&block)
    @rows.each(&block)
  end
end
```

**Review question.** Can both implementations fulfill the same caller expectations, including empty input and relevant failures?

<a id="po-06"></a>
### 6. Acquiring Behavior Through Inheritance

**Passages consulted.** Printed pp. 105, 139 (PDF pp. 130, 164).

**Chapter summary.** Inheritance can share a stable algorithm across closely related specializations. Metz introduces a template method that calls a hook for the part that varies. This lets a subclass supply that part without repeating the shared sequence. Start from real variants so the common behavior is understood.

**Example 1.** An illustrative shared exporter owns the sequence and delegates row formatting to a hook.

```ruby
class RowExport
  def render(records)
    records.map { |record| row_for(record) }
  end

  private

  def row_for(record)
    raise NotImplementedError, "An exporter must define row_for"
  end
end
```

**Example 2.** The specialization supplies row shape and leaves iteration with the superclass.

```ruby
class ClinicExport < RowExport
  private

  def row_for(clinic)
    [clinic.code, clinic.name]
  end
end
```

**Review question.** Can a developer add a real subtype by implementing a small hook without understanding hidden ordering rules?

<a id="po-07"></a>
### 7. Sharing Role Behavior with Modules

**Passages consulted.** Printed pp. 141, 162 (PDF pp. 166, 187).

**Chapter summary.** A module lets unrelated hosts share behavior for the same role. Including it changes method lookup, so the host and module need a clear contract. Shared behavior is useful when all hosts can honor the expectations the caller relies on.

**Example 1.** A role module defines a time-window check with visible host inputs.

```ruby
module TimeWindow
  def covers?(time)
    starts_at <= time && time < ends_at
  end
end
```

**Example 2.** A plain value supplies the two required methods. This fragment uses the role above.

```ruby
Availability = Data.define(:starts_at, :ends_at) do
  include TimeWindow
end
```

**Review question.** What does the role promise at the start and end of a window, and do all hosts honor it?

<a id="po-08"></a>
### 8. Combining Objects with Composition

**Passages consulted.** Printed pp. 163, 188–190 (PDF pp. 188, 213–215).

**Chapter summary.** Composition lets an object carry out its work using independently useful parts with clear contracts. Individual parts can be easier to understand and replace. The assembled flow still needs to show how those parts interact. Choose composition, inheritance or a shared role based on the actual relationship.

**Example 1.** An illustrative report assembles a scoped query and renderer with distinct jobs.

```ruby
class ScheduleReport
  def initialize(query:, renderer:)
    @query = query
    @renderer = renderer
  end

  def call(clinic:)
    rows = @query.call(clinic: clinic)
    @renderer.render(rows)
  end
end
```

**Example 2.** Build the operation where the choice of output format is understood.

```ruby
report = ScheduleReport.new(query: schedule_query, renderer: csv_renderer)
csv = report.call(clinic: clinic)
```

**Review question.** Can a reader tell which component runs first, which record shape it supplies and what a renderer can assume?

<a id="po-09"></a>
### 9. Designing Cost-Effective Tests

**Passages consulted.** Printed pp. 191, 215–216, 224–226, 240 (PDF pp. 216, 240–241, 249–251, 265).

**Chapter summary.** A useful test protects a behavior at the place it is promised and remains stable when internal implementation changes. Metz distinguishes an internal query from an outgoing command whose effect matters. Shared role checks can reveal when a test double and caller drift away from the real collaborator.

**Example 1.** A Minitest example observes a query's answer using fixtures with known scope.

```ruby
def test_report_only_counts_the_selected_clinic
  report = schedule_query.call(clinic: east_clinic)

  assert_equal 2, report.pending_count
end
```

**Example 2.** A Rails test fragment observes a durable effect of an authorized action.

```ruby
assert_difference -> { follow_up.events.count }, 1 do
  record_contact_attempt.call(follow_up: follow_up, observed_at: now)
end
```

**Review question.** Could this test pass if the actual adapter breaks, or fail merely because a private helper was renamed?
