# Performance evidence

## Leadership report performance evidence

Measured November 10, 2026, against the synthetic assessment database: **815 appointments and 125 issues**. The baseline was the original `OperationsQuery` from local revision `29f9faf`; the candidate was the live Active Record aggregation change. Both ran in the same Rails process against one read-only, repeatable-read database snapshot, with the same clock and the Active Record query cache disabled. Complete outputs matched for all-month, current-month, October, and September requests before timing.

Four warmed samples per implementation per month alternated execution order. These are report-calculation timings, excluding HTTP, browser rendering, and cold boot. Medians describe this local run, not a production guarantee.

| Detail requested | Before median | After median | Less elapsed time | Before range | After range |
| --- | ---: | ---: | ---: | ---: | ---: |
| Current month (November) | 330.80 ms | 105.89 ms | 68.0% | 196.77–511.10 ms | 66.33–112.74 ms |
| October | 493.08 ms | 145.38 ms | 70.5% | 208.21–1,611.12 ms | 78.72–228.27 ms |
| September | 397.43 ms | 83.81 ms | 78.9% | 191.54–3,940.12 ms | 60.08–624.05 ms |

For the current-month request, instantiated Active Record objects fell from **2,485 to 132**, and application SQL statements from **13 to 11**. The improvement comes mainly from reducing the rows and objects processed in Ruby, not merely removing two queries. The report still reads retained message history, so these measurements do not establish its cost at production scale. The spread also shows why a single fast query timing cannot explain the whole page's latency.

A separate authenticated localhost HTTP sweep measured five requests for each month before and after replacing the running app image. This included request handling and transfer, but not browser rendering. Medians were **1,144.55 → 729.59 ms** for November, **637.23 → 540.54 ms** for October, and **882.65 → 660.96 ms** for September. These were sequential rollout observations, not the controlled same-process comparison above: the prior live image was older than the checkout, the app restarted, and the backend suite was also running. First November requests were outliers at **20.29 seconds before and 3.25 seconds after**. This supports reporting a faster calculation and improved sampled endpoint medians, not claiming that all page latency or startup spikes have been eliminated.

Nine browser month changes on the rebuilt app ranged from **264 ms to 4,356 ms** from selection to updated detail. The slow request also took 4,212 ms in the Rails log, so that outlier was not merely delayed table rendering. Other requests in the same sweep completed in hundreds of milliseconds. These checks ran while the backend suite was active; the remaining variance needs separate measurement before attributing it to a specific resource bottleneck.

After the backend suite stopped, the same nine-change browser sweep had a **228 ms median**, ranging from **154 ms to 1,449 ms**. Per-month medians were 228 ms for November, 284 ms for October, and 194 ms for September. This is a small local sample, with occasional slower responses still present.

Resuming the deferred checks also found stale reply/Phoenix expectations, a real gap where a reply-review task remained open after all candidate appointments finished, and a test-order fixture collision after a committed transaction test. Codex corrected these without changing the SELECT-only PMS boundary or removing transaction, retry, and concurrency checks. The final backend run passed **113 tests and 1,775 assertions** in **248.76 seconds for the whole Docker test command** (224.09 seconds inside the test runner). The browser suite passed **31 checks** at the two supported desktop sizes; frontend compilation and inspection of both clinic summaries also passed. These checks apply to the leadership reporting revision and its deferred workflow fixes.

## Reminder batch and setup

The prepared 60-clinic fixture took **162.392 seconds** to record 4,000 simulated deliveries. A repeat sent zero duplicates. The 30-second target remained unmet. The run excluded source import. The earlier 240.394-second run used a different revision and environment. A separate fresh assessment setup took **103.957 seconds**, including **91.233 seconds** for app seeding.

## PMS snapshot refresh

Two sequential fresh-cache imports used the same disposable PostgreSQL source: 60 clinics, 56,000 benchmark appointments, and 40,000 completed appointments dated two years earlier. Both runs used 2,000-row appointment upserts and a 640 MiB Ruby container limit. The bounded run used a November 5, 2026 clock and the October 1 assessment launch, retaining appointments from September 1 onward plus IDs the app still watches.

| Measure | Full snapshot | Bounded snapshot |
| --- | ---: | ---: |
| Appointments read and cached | 96,000 | 56,000 |
| PMS read and JSON decode | 5.654 s | 2.661 s |
| Full refresh through app commit | 171.949 s | 117.963 s |
| Peak Ruby process RSS | 292.0 MiB | 263.8 MiB |

The full refresh took 53.986 seconds less (31.4%) in this comparison. The app-side caches started empty. These single runs measure fresh refreshes before the empty-result guard was added. They do not measure a recurring refresh, reminder batch, or production throughput.

Separate replica tests verified that an older tracked appointment still refreshes, an appointment moved before the cutoff is read by ID, an actual removal is marked missing, and an unexpected zero-row result preserves the cache and freshness timestamp.
