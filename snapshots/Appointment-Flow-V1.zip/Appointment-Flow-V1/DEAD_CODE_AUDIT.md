# Dead code audit

Audited checkout: `C:/Users/joshr/appointment-flow`, branch `main`, commit `db037d7932b13fc4d735106e0fa199815fb2d22c`; `origin/main` matched after fetch. The pre-existing changes in `frontend/src/shared/ui.jsx` and `frontend/src/styles/flow.css` were present during the search. Source inspection only; no app code was changed and no test suite was run.

**Version mismatch:** this checkout has `backend/` and `frontend/`, not `appointment_app/`. Its `ReminderFlow` no longer defines either named SQL method. They were removed by `e11f71f`; the worked example is documented under `reminder_flow.rb` below and excluded from current counts. This report covers the corresponding current code, not a claim about another checkout.

## Summary

| Bucket | Count |
| --- | ---: |
| PRODUCTION | 167 |
| TEST/SCRIPT ONLY | 8 |
| NEVER CALLED | 2 |
| DEMO ONLY | 3 |
| UNCERTAIN | 0 |
| **Total** | **180** |

The unit is a named, source-declared method or generated reader, or one named Rails scope/association **family**, not every framework-generated writer/helper. The total comprises 107 public `def`/`attr_reader` definitions, 4 explicitly delegated methods, 10 `Data.define` readers, 20 named scopes, and 39 association families. Ruby `initialize` is private; private/protected definitions, inherited Rails APIs, schema-generated attribute readers, and every individual helper generated for an association are outside the count. The report nevertheless lists the declared association families because the brief explicitly protects framework-defined associations and scopes.

For the requested safeguard, the 59 named scope/association families are included under PRODUCTION as Rails-registered framework surfaces; this is **not** a finding that every generated accessor has an independently demonstrated live invocation. Rails uses association reflection, preloading, joins and validation; scope declarations define relation methods. The `PmsRecord#readonly?` override is also PRODUCTION: Active Record consults `readonly?` on persistence. No custom model callback or validation-method declarations were found. A declared method used by a live chain is counted once even if tests and seeds also call it.

## Search and classification method

The inventory covered every `.rb` directly in `backend/app/models/`, `backend/app/services/`, and `backend/app/controllers/`: 37 files. I searched all source-declared names in one pass across the repository, including the entire backend app, config, db, bin, tests, frontend source/tests and local generated frontend output. Distinct method names were collected from `def`, `attr_reader`, `delegate`, `scope`, association macros and `Data.define`; matches were then checked against the owning class and receiver. Common names alone do not establish a call. For each flagged method below, **Search** names the literal terms run using this exact command, with `<term>` replaced by each listed term:

```powershell
rg -n --hidden --no-ignore --max-columns 500 --max-columns-preview -g '!.git/**' -g '!graft/**' -g '!.idea/**' -g '!**/node_modules/**' -g '!**/vendor/**' -g '!**/tmp/**' -g '!**/log/**' -g '!DEAD_CODE_AUDIT.md' -F -- '<term>' .
```

The exclusions are Git internals, the derived graft index, IDE metadata, installed dependencies, temporary/log output, and this generated report. Compiled frontend output was included as a search target but not treated as proof of which deployed bundle is running. The full inventory pass used the same options with `-F -f "$env:TEMP\audit_all_terms.txt"` in place of `-F -- '<term>'`; the file contained 212 distinct names including private names. The recorded lines below are repository source evidence, not execution evidence. Search output can contain similarly named methods, comments, docs, JSON/JS fields, and longer identifiers; these were checked rather than treated automatically as calls.

The dynamic-dispatch search used the same command for `send`, `public_send`, `__send__`, `method`, `constantize`, `const_get`, `class_eval`, `instance_eval`, `eval`, `define_method`, `define_singleton_method`, `method_missing`, and `&:`. The app has symbol-to-proc calls, which were checked as calls; test monkey-patches and documentation examples are not live entry points. No relevant app dynamic dispatch was found for the flagged methods. This is a static, in-repository conclusion; it cannot rule out an uninspected external console script or an installed dependency invoking an app method.

Routes at `backend/config/routes.rb:3-29` account for every public controller action below. The scheduler configuration names `ReminderJob` at `backend/config/schedule.yml:1-4`; separately, Sidekiq startup explicitly enqueues it at `backend/config/initializers/sidekiq.rb:1-3` → `backend/app/jobs/reminder_job.rb:7-8` → `ReminderRunner.tick`. This audit did not establish whether cron loads the schedule in a running environment. The assessment-only seed replay is `backend/db/seeds.rb:28-34`. `Database::Session`'s sole non-test construction site is `Database.open` at `backend/app/services/database.rb:14-17`; that method has no live app caller. These chains are used when classifying internal calls.

## Per-file inventory

A method's location is the declaration line. Each item has exactly one bucket; a line annotated `Rails scope` or `Rails belongs_to/has_one/has_many` is the protected framework family described above. Entries with no flags still appear, so the total is auditable.

### `backend/app/controllers/application_controller.rb`

No source-declared public methods, readers, scopes, or association families in this file.

### `backend/app/controllers/desk_controller.rb`

- `DeskController#appointments` (line 2): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:16`.
- `DeskController#board` (line 12): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:17`.
- `DeskController#case_detail` (line 18): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:18`.
- `DeskController#patient_details` (line 23): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:20`.
- `DeskController#patient_history` (line 30): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:22`.
- `DeskController#verify_patient_detail` (line 37): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:21`.
- `DeskController#work` (line 58): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:19`.

### `backend/app/controllers/operations_controller.rb`

- `OperationsController#operations` (line 2): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:29`.

### `backend/app/controllers/patients_controller.rb`

- `PatientsController#patient_inbox` (line 4): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:25`.
- `PatientsController#reply` (line 25): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:26`.

### `backend/app/controllers/workspaces_controller.rb`

- `WorkspacesController#index` (line 2): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:3, 4, 5, 6, 7, 8, 9`.
- `WorkspacesController#workspaces` (line 12): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:12`.
- `WorkspacesController#enter` (line 19): **PRODUCTION**.
  - Mechanism: routed in `backend/config/routes.rb:13`.

### `backend/app/models/activity_event.rb`

- `ActivityEvent#visit` (line 3): **PRODUCTION** — Rails belongs_to.
- `ActivityEvent#message` (line 4): **PRODUCTION** — Rails belongs_to.
- `ActivityEvent.pms_change` (line 6): **PRODUCTION** — Rails scope.
- `ActivityEvent.record` (line 8): **PRODUCTION**.

### `backend/app/models/application_record.rb`

No source-declared public methods, readers, scopes, or association families in this file.

### `backend/app/models/appointment.rb`

- `Appointment#patient` (line 9): **PRODUCTION** — Rails belongs_to.
- `Appointment#clinic` (line 10): **PRODUCTION** — Rails belongs_to.
- `Appointment#visits` (line 11): **PRODUCTION** — Rails has_many.
- `Appointment#current_visit` (line 12): **PRODUCTION** — Rails has_one.
- `Appointment.for_clinic` (line 14): **PRODUCTION** — Rails scope.
- `Appointment.scheduled` (line 15): **PRODUCTION** — Rails scope.
- `Appointment.within_window` (line 16): **PRODUCTION** — Rails scope.
- `Appointment.chronological` (line 17): **PRODUCTION** — Rails scope.
- `Appointment.needing_reconciliation` (line 19): **PRODUCTION**.
- `Appointment#confirmation_revision` (line 33): **PRODUCTION**.
- `Appointment#outcome` (line 44): **PRODUCTION**.

### `backend/app/models/clinic.rb`

- `Clinic#setting` (line 3): **PRODUCTION** — Rails has_one.
- `Clinic#reporting_zone` (line 4): **PRODUCTION** — Rails has_one.
- `Clinic#appointments` (line 5): **PRODUCTION** — Rails has_many.
- `Clinic.messaging_enabled` (line 7): **PRODUCTION** — Rails scope.

### `backend/app/models/clinic_setting.rb`

No source-declared public methods, readers, scopes, or association families in this file.

### `backend/app/models/contact_permission.rb`

- `ContactPermission#patient` (line 4): **PRODUCTION** — Rails belongs_to.
- `ContactPermission#authorized_guarantor` (line 5): **PRODUCTION** — Rails belongs_to.

### `backend/app/models/follow_up_case.rb`

- `FollowUpCase#patient` (line 3): **PRODUCTION** — Rails belongs_to.
- `FollowUpCase#owner` (line 4): **PRODUCTION** — Rails belongs_to.
- `FollowUpCase#issues` (line 5): **PRODUCTION** — Rails has_many.
- `FollowUpCase#events` (line 6): **PRODUCTION** — Rails has_many.
- `FollowUpCase.for_clinic` (line 7): **PRODUCTION** — Rails scope.
- `FollowUpCase#changed_for_staff?` (line 9): **PRODUCTION**.
- `FollowUpCase#mark_in_progress!` (line 13): **PRODUCTION**.

### `backend/app/models/follow_up_issue.rb`

- `FollowUpIssue#follow_up_case` (line 3): **PRODUCTION** — Rails belongs_to.
- `FollowUpIssue#resolution_event` (line 4): **PRODUCTION** — Rails belongs_to.
- `FollowUpIssue#reply_event` (line 5): **PRODUCTION** — Rails belongs_to.
- `FollowUpIssue#visit` (line 6): **PRODUCTION** — Rails belongs_to.
- `FollowUpIssue.open` (line 7): **PRODUCTION** — Rails scope.
- `FollowUpIssue.for_clinic` (line 8): **PRODUCTION** — Rails scope.
- `FollowUpIssue.for_visits` (line 9): **PRODUCTION**.
- `FollowUpIssue#affected_visit_ids` (line 14): **PRODUCTION**.
- `FollowUpIssue.group_by_visit` (line 19): **PRODUCTION**.

### `backend/app/models/message.rb`

- `Message#items` (line 3): **PRODUCTION** — Rails has_many.
- `Message#visits` (line 4): **PRODUCTION** — Rails has_many.
- `Message#events` (line 5): **PRODUCTION** — Rails has_many.
- `Message.sent` (line 6): **PRODUCTION** — Rails scope.
- `Message.conversation` (line 7): **PRODUCTION** — Rails scope.

### `backend/app/models/message_item.rb`

- `MessageItem#message` (line 4): **PRODUCTION** — Rails belongs_to.
- `MessageItem#visit` (line 5): **PRODUCTION** — Rails belongs_to.

### `backend/app/models/opt_out.rb`

No source-declared public methods, readers, scopes, or association families in this file.

### `backend/app/models/patient.rb`

- `Patient#guarantor` (line 3): **PRODUCTION** — Rails belongs_to.
- `Patient#appointments` (line 4): **PRODUCTION** — Rails has_many.
- `Patient#contact_permissions` (line 5): **PRODUCTION** — Rails has_many.
- `Patient#active_detail_verifications` (line 6): **PRODUCTION** — Rails has_many.
- `Patient#effective_detail` (line 8): **PRODUCTION**.
- `Patient#contact_details_conflicted?` (line 15): **PRODUCTION**.
- `Patient#contact_permission_for` (line 19): **PRODUCTION**.
- `Patient#display_name` (line 23): **PRODUCTION**.

### `backend/app/models/patient_detail_verification.rb`

- `PatientDetailVerification#patient` (line 11): **PRODUCTION** — Rails belongs_to.
- `PatientDetailVerification#staff` (line 12): **PRODUCTION** — Rails belongs_to.
- `PatientDetailVerification.active` (line 13): **PRODUCTION** — Rails scope.
- `PatientDetailVerification.source_value` (line 15): **PRODUCTION**.
- `PatientDetailVerification.review_token` (line 20): **PRODUCTION**.
- `PatientDetailVerification.record!` (line 28): **PRODUCTION**.
- `PatientDetailVerification#reconcile_source!` (line 46): **PRODUCTION**.
- `PatientDetailVerification#supplies_local_value?` (line 56): **PRODUCTION**.

### `backend/app/models/pms_record.rb`

- `PmsRecord#readonly?` (line 5): **PRODUCTION**.
  - Mechanism: Active Record persistence checks `readonly?`; `Appointment`, `Patient`, and `Clinic` inherit from `PmsRecord`.

### `backend/app/models/reporting_clinic_zone.rb`

No source-declared public methods, readers, scopes, or association families in this file.

### `backend/app/models/source_sync.rb`

- `SourceSync.status` (line 5): **PRODUCTION**.

### `backend/app/models/staff_member.rb`

No source-declared public methods, readers, scopes, or association families in this file.

### `backend/app/models/visit.rb`

- `Visit#appointment` (line 3): **PRODUCTION** — Rails belongs_to.
- `Visit#clinic` (line 4): **PRODUCTION** — Rails belongs_to.
- `Visit#clinic_setting` (line 5): **PRODUCTION** — Rails belongs_to.
- `Visit#patient` (line 6): **PRODUCTION** — Rails belongs_to.
- `Visit#contact_permission` (line 7): **PRODUCTION** — Rails belongs_to.
- `Visit#message_items` (line 9): **PRODUCTION** — Rails has_many.
- `Visit#messages` (line 10): **PRODUCTION** — Rails has_many.
- `Visit#events` (line 11): **PRODUCTION** — Rails has_many.
- `Visit#issues` (line 12): **PRODUCTION** — Rails has_many.
- `Visit.with_context` (line 14): **PRODUCTION** — Rails scope.
- `Visit#sender` (line 19): **PRODUCTION** — delegate.
  - Live call: `backend/app/services/reminder_sender.rb:48`; delegates to `clinic_setting`.
- `Visit#timezone` (line 19): **PRODUCTION** — delegate.
  - Live call: `backend/app/services/contact_policy.rb:88`; delegates to `clinic_setting`.
- `Visit.current` (line 21): **PRODUCTION** — Rails scope.
- `Visit.for_clinic` (line 22): **PRODUCTION** — Rails scope.
- `Visit.for_patient` (line 24): **PRODUCTION** — Rails scope.
- `Visit.within_window` (line 25): **PRODUCTION** — Rails scope.
- `Visit.chronological` (line 26): **PRODUCTION** — Rails scope.
- `Visit.with_messaging_context` (line 27): **PRODUCTION** — Rails scope.
- `Visit.with_pending_pms_change` (line 28): **PRODUCTION** — Rails scope.
- `Visit#matches_appointment?` (line 30): **PRODUCTION**.
- `Visit#patient_name` (line 34): **PRODUCTION**.
- `Visit#provider_name` (line 38): **PRODUCTION**.
- `Visit#latest_patient_reply` (line 42): **PRODUCTION**.
- `Visit#sms_permitted?` (line 46): **PRODUCTION**.
- `Visit#email_permitted?` (line 50): **PRODUCTION**.
- `Visit.clinic_wall_time_to_utc` (line 54): **PRODUCTION**.
- `Visit#starts_at_utc` (line 62): **PRODUCTION**.
- `Visit#reminder_at` (line 66): **PRODUCTION**.
- `Visit#pending_pms_change?` (line 71): **PRODUCTION**.
- `Visit#current_reply_target?` (line 75): **PRODUCTION**.
- `Visit#current_scheduled_revision?` (line 82): **PRODUCTION**.
- `Visit#upcoming_on_open_day?` (line 87): **PRODUCTION**.
- `Visit#confirmable_at?` (line 91): **PRODUCTION**.
- `Visit#confirm!` (line 96): **PRODUCTION**.

### `backend/app/services/contact_policy.rb`

- `ContactPolicy#now` (line 12): **PRODUCTION**.
  - Used by its own live workflow as a bare reader, e.g. `backend/app/services/contact_policy.rb:47`.
- `ContactPolicy#phone` (line 14): **PRODUCTION**.
- `ContactPolicy#address` (line 29): **PRODUCTION**.
- `ContactPolicy::Recipient#email` (line 41): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/contact_policy.rb:97`.
- `ContactPolicy::Recipient#id` (line 41): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/receive_reply.rb:155`.
- `ContactPolicy::Recipient#language` (line 41): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/contact_policy.rb:99`.
- `ContactPolicy::Recipient#name` (line 41): **TEST/SCRIPT ONLY** — Data reader.
  - Does: Reads the authorized recipient name from the generated Data object.
  - Search: `name`, `contact.name`, `contact&.to_h`, using the exact command in Search and classification method.
  - Result: The only Ruby call on a Recipient reader found is `backend/test/model_boundaries_test.rb:235`. The live app serializes the name *value* with `contact&.to_h` in `backend/app/queries/case_detail_query.rb:70`; the JavaScript `contact.name` at `frontend/src/features/patient-workspace/PatientDetails.jsx:130` reads that JSON property, not the Ruby reader. A local Ruby 3.4.10 check overriding the reader to raise still returned `{name: "value"}` from `to_h`; do not infer that the name field itself is unused.
- `ContactPolicy::Recipient#phone` (line 41): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/contact_policy.rb:97`.
- `ContactPolicy::Recipient#phone_on_file` (line 41): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/contact_policy.rb:143`.
- `ContactPolicy#recipient` (line 43): **PRODUCTION**.
- `ContactPolicy#for_visit` (line 87): **PRODUCTION**.
- `ContactPolicy#hold_code` (line 91): **PRODUCTION**.
- `ContactPolicy#hold` (line 102): **PRODUCTION**.
- `ContactPolicy#destinations` (line 106): **PRODUCTION**.
- `ContactPolicy::Decision#destinations` (line 115): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/reminder_sender.rb:73`.
- `ContactPolicy::Decision#reason` (line 115): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/reminder_sender.rb:94`.
- `ContactPolicy::Decision#reason_code` (line 115): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/reminder_sender.rb:92`.
- `ContactPolicy::Decision#recipient` (line 115): **PRODUCTION** — Data reader.
  - Live reader call: `backend/app/services/reminder_sender.rb:73`.
- `ContactPolicy#decision` (line 117): **PRODUCTION**.
- `ContactPolicy#verification_conflict?` (line 126): **PRODUCTION**.

### `backend/app/services/database.rb`

- `Database.open` (line 14): **TEST/SCRIPT ONLY**.
  - Does: Opens a Rails-backed SQL session for fixtures and the benchmark.
  - Search: `open`, `Database.open`, `Session.new`, `Database::Session`, using the exact command in Search and classification method.
  - Result: The only actual `Database.open` calls are `backend/bin/benchmark.rb:64` and the `backend/test/` calls indexed below. `Session.new` in `database.rb:16` is reached through this method; the only other constructors are `backend/test/database_test.rb:52, 63, 68`. Documentation mentions are not callers.
- `Database.provision` (line 21): **TEST/SCRIPT ONLY**.
  - Does: Opens the setup/admin PostgreSQL connection.
  - Search: `provision`, using the exact command in Search and classification method.
  - Result: Callers: `backend/bin/setup.rb:9`, `backend/bin/setup_replica.rb:7, 41`, and `backend/test/model_boundaries_test.rb:74`. The yielded object is a raw PG connection, not `Database::Session`.
- `Database.lock_clinic` (line 27): **PRODUCTION**.
- `Database.lock_snapshot` (line 34): **PRODUCTION**.
- `Database.lock_appointment` (line 38): **DEMO ONLY**.
  - Does: Takes the transaction advisory lock for one appointment.
  - Search: `lock_appointment`, `reconcile_appointment`, using the exact command in Search and classification method.
  - Result: Only call: `backend/app/services/reconcile_appointments.rb:28`, inside `ReconcileAppointments#reconcile_appointment`, which is itself DEMO ONLY. The similarly named plural method at `database.rb:44` is a different method used by the live bulk reconciliation path.
- `Database.lock_appointments` (line 44): **PRODUCTION**.
- `Database.lock_request` (line 54): **PRODUCTION**.
- `Database::Session#escape_literal` (line 75): **NEVER CALLED** — delegate.
  - Does: Delegates SQL literal escaping to the raw PG connection.
  - Search: `escape_literal`, `Database.open`, `Database::Session`, `Session.new`, using the exact command in Search and classification method.
  - Result: The only hits beyond the declaration are `backend/bin/setup.rb:11` and `backend/bin/setup_replica.rb:43`; both use the raw connection returned by `Database.provision`, not a Session. No Session receiver or dynamic invocation found.
- `Database::Session#quote_ident` (line 75): **NEVER CALLED** — delegate.
  - Does: Delegates SQL identifier quoting to the raw PG connection.
  - Search: `quote_ident`, `Database.open`, `Database::Session`, `Session.new`, using the exact command in Search and classification method.
  - Result: The only in-scope source hits beyond the declaration are `backend/bin/setup.rb:12, 15` and `backend/bin/setup_replica.rb:9, 44, 46, 47`; their `db` is yielded by `Database.provision` and is a raw PG connection (`database.rb:21-23`), not a Session. No Session receiver or dynamic invocation found.
- `Database::Session#exec` (line 78): **TEST/SCRIPT ONLY**.
  - Does: Executes SQL and maps PostgreSQL result types.
  - Search: `exec`, `Database.open`, `Database::Session`, `Session.new`, using the exact command in Search and classification method.
  - Result: Session callers include `backend/bin/benchmark.rb:65, 76` and `backend/test/database_test.rb:22, 38, 53, 69`; further fixture calls are in `backend/test/audit_test.rb`, `flow_test.rb`, and `reporting_test.rb`. The `db.exec` at `backend/app/services/pms_replica.rb:11-12` is on the raw `PG.connect` object from line 9, not this session. Session construction has only the test/benchmark roots described above.
- `Database::Session#exec_params` (line 82): **TEST/SCRIPT ONLY**.
  - Does: Runs parameterized SQL and maps result types.
  - Search: `exec_params`, `rows`, `Database.open`, `Database::Session`, `Session.new`, using the exact command in Search and classification method.
  - Result: Direct session calls include `backend/test/audit_test.rb:23`, `backend/test/database_test.rb:10`, `backend/test/flow_test.rb:69, 393, 620`, and `backend/test/model_boundaries_test.rb:88, 93, 102`; indirect call is `database.rb:87` from `Session#rows`. `backend/app/services/pms_replica.rb:20` and setup scripts call raw PG connections, not this wrapper. The indirect rows chain ends in tests or the benchmark.
- `Database::Session#rows` (line 86): **TEST/SCRIPT ONLY**.
  - Does: Returns all rows from parameterized SQL.
  - Search: `rows`, `.rows`, `first_row`, `Database.open`, `Database::Session`, `Session.new`, using the exact command in Search and classification method.
  - Result: Called by `Session#first_row` at `database.rb:91`, and directly in `backend/test/cleanup_test.rb:57-58, 69`, `backend/test/flow_test.rb:225, 239, 276, 278, 328-329, 336`, `backend/test/reporting_test.rb:255, 277, 279`, and `backend/test/seed_test.rb:116, 134, 175, 182`. `backend/app/queries/case_detail_query.rb:75, 85` and `patient_workspace_history.rb:66` invoke `PatientAppointmentsQuery#rows`, a different receiver. `first_row` ends in tests/benchmark.
- `Database::Session#first_row` (line 90): **TEST/SCRIPT ONLY**.
  - Does: Returns the first SQL result row.
  - Search: `first_row`, `Database.open`, `Database::Session`, `Session.new`, using the exact command in Search and classification method.
  - Result: Callers are `backend/bin/benchmark.rb:100` and tests in `backend/test/audit_test.rb:62, 64`, `cleanup_test.rb:27, 29`, `flow_test.rb:58, 289, 292, 294, 297, 445, 453, 576, 577, 579, 580`, `reporting_test.rb:210, 213, 273, 278`, and `seed_test.rb:123, 131-133, 140-142, 156, 199`. No non-test live session caller found.
- `Database::Session#transaction` (line 94): **TEST/SCRIPT ONLY**.
  - Does: Materializes and wraps a Rails transaction for raw SQL.
  - Search: `transaction`, `Database.open`, `Database::Session`, `Session.new`, using the exact command in Search and classification method.
  - Result: `backend/bin/benchmark.rb:60` receives the session passed to `measure_changed_import(db)` at line 75 from `Database.open` at line 64. Tests include `backend/test/database_test.rb:8`, `backend/test/flow_test.rb:382, 503`, and `backend/test/reporting_test.rb:128`. The transaction at `backend/app/services/pms_replica.rb:10` is on raw PG; `ApplicationRecord.transaction` is a different method.

### `backend/app/services/follow_up_workflow.rb`

- `FollowUpWorkflow#now` (line 7): **PRODUCTION**.
  - Used by its own live workflow as a bare reader, e.g. `backend/app/services/follow_up_workflow.rb:15`.
- `FollowUpWorkflow#finish_cases` (line 9): **PRODUCTION**.
- `FollowUpWorkflow#resolve_finished_follow_ups` (line 19): **PRODUCTION**.
- `FollowUpWorkflow#close_visit_follow_ups` (line 55): **PRODUCTION**.
- `FollowUpWorkflow#close_after_confirmation` (line 81): **PRODUCTION**.
- `FollowUpWorkflow#preserve_contact_hold_on_confirmation?` (line 87): **PRODUCTION**.
- `FollowUpWorkflow#issue` (line 91): **PRODUCTION**.

### `backend/app/services/message_templates.rb`

- `MessageTemplates#english?` (line 4): **PRODUCTION**.
- `MessageTemplates#message_language` (line 9): **PRODUCTION**.
- `MessageTemplates#message_body` (line 15): **PRODUCTION**.

### `backend/app/services/pms_replica.rb`

- `PmsReplica.read` (line 7): **PRODUCTION**.

### `backend/app/services/pms_snapshot.rb`

- `PmsSnapshot#refresh` (line 17): **PRODUCTION**.
- `PmsSnapshot#refresh_if_stale` (line 24): **PRODUCTION**.

### `backend/app/services/receive_reply.rb`

- `ReceiveReply#reply_to_receipt` (line 19): **PRODUCTION**.
- `ReceiveReply#reply` (line 38): **DEMO ONLY**.
  - Does: Processes a reply for an already matched visit and receipt.
  - Search: `reply`, `.reply`, `reply_to_receipt`, using the exact command in Search and classification method.
  - Result: Assessment callers: `backend/db/assessment_history.rb:97` and `backend/db/assessment_task_examples.rb:273`. Test callers include `backend/test/workflow_fixture.rb:256`, `reply_test.rb:54, 97, 114, 129, 140, 157, 188`, `flow_test.rb:202, 293`, and `cadence_test.rb:66, 72, 132, 230, 234`. The live route uses the distinct `reply_to_receipt` method at `backend/app/controllers/patients_controller.rb:31`; the common private processing code is also live.

### `backend/app/services/reconcile_appointments.rb`

- `ReconcileAppointments#for_clinic` (line 8): **PRODUCTION**.
- `ReconcileAppointments#for_case` (line 15): **PRODUCTION**.
- `ReconcileAppointments#reconcile_appointment` (line 27): **DEMO ONLY**.
  - Does: Locks and reconciles one appointment at an assessment-supplied time.
  - Search: `reconcile_appointment`, `lock_appointment`, using the exact command in Search and classification method.
  - Result: Callers: `backend/db/assessment_history.rb:54, 67`, `backend/db/assessment_patient_details.rb:98`, `backend/db/assessment_task_examples.rb:253`. `backend/db/seeds.rb:28-34` loads these replay paths only for the assessment seed. The live workflow calls plural private `reconcile_appointments` through `for_clinic`/`for_case`, not this singular method.

### `backend/app/services/record_follow_up.rb`

- `RecordFollowUp#call` (line 14): **PRODUCTION**.
- `RecordFollowUp#record_action_on_reconciled_case` (line 36): **PRODUCTION**.

### `backend/app/services/reminder_flow.rb`

- `ReminderFlow::FakeSender#deliver` (line 8): **PRODUCTION**.
  - Live call: default transport is constructed in `reminder_flow.rb:13` and called by `backend/app/services/reminder_sender.rb:45`.
- `ReminderFlow#now` (line 18): **PRODUCTION**.
- `ReminderFlow#load_visits` (line 22): **PRODUCTION**.
- `ReminderFlow#contact_policy` (line 32): **PRODUCTION**.
- `ReminderFlow#message_templates` (line 36): **PRODUCTION**.
- `ReminderFlow#follow_ups` (line 40): **PRODUCTION**.
- `ReminderFlow#reminder_sender` (line 44): **PRODUCTION**.
- `ReminderFlow#due_batches` (line 51): **PRODUCTION**.
- `ReminderFlow#run_daily_batch` (line 64): **PRODUCTION**.
- `ReminderFlow#run` (line 78): **PRODUCTION**.

**Historical worked example, not part of the current counts:** `ReminderFlow#execute_sql_rows` was defined at `appointment_app/app/services/reminder_flow.rb:19` in `e11f71f^`; it returned parameterized query rows. `ReminderFlow#execute_sql_first_row` was at line 23 and returned the first row by calling the first method at line 24. At that historical revision, the first-row caller included `appointment_app/bin/benchmark.rb:73`, with further callers under `appointment_app/test/`; the rows method also had test callers and the first-row chain. Exact historical search run:

```powershell
git grep -n -E 'execute_sql_rows|execute_sql_first_row' 'e11f71f^' -- appointment_app/app appointment_app/config appointment_app/db appointment_app/bin appointment_app/test
```

That search found the definitions, the internal call, benchmark, and test callers; it found no other app/config/db caller. `git show e11f71f -- appointment_app/app/services/reminder_flow.rb` shows both definitions removed. On the audited checkout, the exact repository search above for each of `execute_sql_rows` and `execute_sql_first_row` returned zero hits before this report existed. Neither method is present to classify as a current live-service method.


### `backend/app/services/reminder_runner.rb`

- `ReminderRunner.tick` (line 4): **PRODUCTION**.
- `ReminderRunner.log_failure` (line 34): **PRODUCTION**.

### `backend/app/services/reminder_schedule.rb`

- `ReminderSchedule#purposes` (line 21): **PRODUCTION**.

### `backend/app/services/reminder_sender.rb`

- `ReminderSender#call` (line 17): **PRODUCTION**.
- `ReminderSender#deliver` (line 41): **PRODUCTION**.

### `backend/app/services/reply_classification.rb`

- `ReplyClassification.call` (line 6): **PRODUCTION**.
- `ReplyClassification.affirmative_lead?` (line 14): **PRODUCTION**.

## Caller index for the SQL fixture/session methods

These are source call sites with receivers traced to the wrapper. For `exec_params`, `rows` and `first_row`, also follow the internal chain `database.rb:91` → `database.rb:87` → `database.rb:82`. The script runner reaches `Session#transaction` through `measure_changed_import` (`benchmark.rb:60, 75`). Calls on `PG.connect`/`Database.provision` and unrelated query objects are excluded from this receiver-specific index; the literal searches above still include them.

- **Database.open:** `backend/bin/benchmark.rb:64`; `backend/test/audit_test.rb:22, 42, 47, 61, 69, 99`; `backend/test/cleanup_test.rb:19, 56`; `backend/test/database_test.rb:7, 36`; `backend/test/flow_test.rb:29, 57, 68, 84, 139, 160, 173, 177, 220, 237, 258, 324, 379, 382, 392, 444, 485, 503, 534, 572, 619`; `backend/test/model_boundaries_test.rb:40, 49, 73, 80, 110, 283, 308`; `backend/test/reply_test.rb:11`; `backend/test/reporting_test.rb:19, 27, 51, 73, 95, 108, 120, 128, 152, 177, 197, 246, 270, 293`; `backend/test/seed_test.rb:22, 57, 78, 110, 154, 173`; `backend/test/test_helper.rb:57`.

- **Database.provision:** `backend/bin/setup.rb:9`; `backend/bin/setup_replica.rb:7, 41`; `backend/test/model_boundaries_test.rb:74`.

- **Session#first_row:** `backend/bin/benchmark.rb:100`; `backend/test/audit_test.rb:62, 64`; `backend/test/cleanup_test.rb:27, 29`; `backend/test/flow_test.rb:58, 289, 292, 294, 297, 445, 453, 576, 577, 579, 580`; `backend/test/reporting_test.rb:210, 213, 273, 278`; `backend/test/seed_test.rb:123, 131, 132, 133, 140, 141, 142, 156, 199`.

- **Session#rows direct:** `backend/test/cleanup_test.rb:57, 58, 69`; `backend/test/flow_test.rb:225, 239, 276, 278, 328, 329, 336`; `backend/test/reporting_test.rb:255, 277, 279`; `backend/test/seed_test.rb:116, 134, 175, 182`.

- **Session#exec direct:** `backend/bin/benchmark.rb:65, 76`; `backend/test/audit_test.rb:43, 44, 47, 103`; `backend/test/database_test.rb:22, 38, 53, 69`; `backend/test/flow_test.rb:85, 161, 162, 173, 260, 380, 488, 496, 535`; `backend/test/reporting_test.rb:20, 27, 52, 53, 74, 96, 109, 121, 152, 177, 294`.

- **Session#exec_params direct:** `backend/test/audit_test.rb:23`; `backend/test/database_test.rb:10`; `backend/test/flow_test.rb:69, 393, 620`; `backend/test/model_boundaries_test.rb:88, 93, 102`.

- **Session#transaction direct:** `backend/bin/benchmark.rb:60`; `backend/test/audit_test.rb:70`; `backend/test/cleanup_test.rb:20`; `backend/test/database_test.rb:8`; `backend/test/flow_test.rb:30, 242, 382, 486, 503, 573`; `backend/test/model_boundaries_test.rb:41, 82`; `backend/test/reply_test.rb:12`; `backend/test/reporting_test.rb:128, 198, 247, 272`; `backend/test/seed_test.rb:23, 58, 79, 111, 155, 174`; `backend/test/test_helper.rb:58`.

## Recommendations for a later task

- Review the two unused `Database::Session` delegates separately from the session itself. The wrapper and its other methods still support the benchmark and tests; `Database.provision` still supports setup.
- Keep the demo-only methods if assessment replay is still wanted; their absence from a live route is not proof that seed generation is disposable.
- Do not remove the `Recipient` name field based on the reader finding: the live response uses the value through `to_h`.

## UNCERTAIN items

None identified in the inspected repository. A console script, private integration, runtime instrumentation, or dependency outside this checkout could introduce a caller not visible to this search; establishing that would require inspecting that specific integration or observing its dispatch. Bundler could not resolve the installed Sidekiq dependencies, so no Rails boot or runtime call tracing was performed. This limitation does not turn unobserved external callers into confirmed in-repo calls.
