# Apex Appointment Flow V3.1.1

This build was originally named V4 and previously appeared in the review bundle as V3.1.

Local Rails + React demonstration using fictional Austin and Phoenix patients and a fake SMS/email transport. The source assessment and ten visual references are in `reference/`; the original V4 ZIP is retained at the project root.

## Start on Windows

Prerequisites: Ruby 3.4, Bundler, PostgreSQL 17 (including `psql` and `pg_dump`), Node 24 and npm. Tested versions and check results are recorded in `review/FREEZE_CHECKLIST.md`.

PostgreSQL must be running. This machine's server is at `127.0.0.1:5443`, user `postgres`. Override `PGHOST`, `PGPORT`, `PGUSER`, and `PGPASSWORD` for another installation. The app uses only `apex_clean_v4_development` and `apex_clean_v4_test`; never point these commands at an existing application's database.

From this folder in PowerShell:

```powershell
.\Start.ps1 -Setup
```

Setup installs locked dependencies, prepares the database and seeds a new database. The launcher starts both servers. Open **http://127.0.0.1:5174**. Subsequent runs use `.\Start.ps1`. Ctrl+C stops the launcher's child servers. Server logs are in `tmp/`. Ports 3040 and 5174 must be free.

Alternatively, in separate terminals:

```powershell
cd backend
bundle install
ruby bin/rails db:prepare
ruby bin/rails server -b 127.0.0.1 -p 3040
```

```powershell
cd frontend
$env:npm_config_allow_scripts = ''
npm.cmd ci --ignore-scripts
npm.cmd run dev
```

The npm environment setting avoids an inherited npm 11 `allow-scripts` option that otherwise rejects project installs on this machine. No dependency lifecycle scripts are required by this application. PostgreSQL command tools must be on PATH for schema creation/loading. `Start.ps1` detects the installed Windows PostgreSQL 17 paths.

If creating the database manually with `db:create db:migrate`, run `ruby bin/rails db:seed` once afterward. Seeds refuse to overwrite existing work. They create 24 patients and visits, relative to the seed date, including both languages, an email-only recipient, failed SMS, a minor, an unsupported language, confirmed visits and historical outcomes. Seeds record fake attempts at clinic-local noon, regardless of the actual startup hour.

## Exercise the workflows

1. Choose Austin and a demo staff identity. Open **Front desk**. Open Jordan's follow-up, assign it, enter a note, and record attempted or confirmed contact. Source reschedules/cancellations are recorded locally as staff outcomes; this app does not change the PMS schedule.
2. **Appointments** has week/day navigation, a date picker and state filters. Seeded upcoming visits span the next seven days.
3. **Patient details** shows inspectable PMS values and locally verified values. Correct a contact and explicitly select channel permissions. Minors remain held for human authorization; this version does not implement a guardian verification flow.
4. Choose **Patient demo**, a clinic, then Avery. In Text messages, enter `YES`, `NO`, `STOP` or uncertain text. Inspect the recorded result and return to Front desk to refresh. Email uses exactly the same reply-processing path. Casey has email messages; Avery initially has an empty Email tab.
5. **Leadership** returns only aggregate counts. Completion means source status `complete` divided by visits whose start time has passed, in the clinic's appointment month. It does not measure no-show reduction or causation.

**Run fake reminders** on the staff screen, or from `backend`:

```powershell
ruby bin/rails reminders:run
```

Runs refresh the source first and send only between 10:00 and 18:00 clinic time, before visit start. They coalesce missed windows into one initial (up to 7 days), follow-up (up to 3 days), or final (up to 1 day) step. An unanswered/failed initial SMS can receive one email backup from day 6. Confirmed visits receive only an informational final reminder. Repeated batches cannot create another record for the same appointment revision and step. No message ever leaves this computer.

Fake attempts and replies are visible in the patient inbox and patient activity log. `accepted` means the fake interface recorded the attempt; it does not mean delivery to a person. Phone numbers ending `0199` and email addresses starting `fail@` deterministically fail.

## Source boundary and safe reply matching

The assessment's tables are preserved in PostgreSQL's `pms` schema. Runtime PMS models reject writes. Only migration, seed and test setup code writes source records. Local tables own snapshots, contact corrections/consent, SMS opt-outs, messages, replies, follow-up and confirmation state. The demo database connection is an owner account; production must enforce SELECT-only source privileges with a separate role.

Every reminder and non-STOP reply reads a consistent source snapshot inside a clinic transaction. Empty/incomplete/invalid snapshots roll back and pause outreach. Changed appointment time, patient or status starts another revision and clears earlier confirmation. Removed source visits stop outreach. A matching YES requires a current revision, accepted attempt, safe contact, one unambiguous upcoming visit, and permission. Shared contacts, stale/late replies, NO and uncertain commands become staff review. STOP is honored even while source refresh is unavailable and is persisted for the recipient and clinic.

The five-minute replication lag remains a limitation: this demonstration cannot know about source changes that have not replicated yet. Appointment times are interpreted explicitly as America/Chicago for Austin and America/Phoenix for Phoenix. Ambiguous/nonexistent DST wall times pause the source snapshot for review.

Staff identity and clinic headers are intentionally a **demo authentication stub**. Queries scope every patient/appointment mutation to the selected clinic, but this is not production authorization. Production needs authenticated staff memberships, role-separated leadership access, verified provider callbacks, protected audit storage, data retention, and a least-privilege source connection. A real external provider would require an outbox/reconciliation design; the fake has no external side effect to reconcile.

## Checks

```powershell
python quality/run_checks.py
```

This runs Rails behavior/request tests, RuboCop, Brakeman, ESLint, TypeScript, React tests and the frontend build. Prepare the test database first if needed: from `backend`, set `RAILS_ENV=test` and run `ruby bin/rails db:prepare`, then remove that environment variable before starting development servers. Tests use their own database and truncate only their test records. They include a real multi-connection concurrent reminder test; the suite itself runs serially.

With both development servers running and Google Chrome installed:

```powershell
cd frontend
npm.cmd run smoke
```

Playwright exercises the real Rails backend, follow-up persistence, clinic switching, simulated confirmation, the Email empty state, leadership, appointment date/state filters and a 390px viewport. React interaction tests use a stubbed HTTP backend; they separately check stale clinic responses and retained drafts after rejection. Screenshots are saved under `notes/evidence/`.

`verify_harness.py` verifies the original ZIP baseline before development. The original manifest intentionally includes writable logs/templates and `.gitignore`; its initial pass is not an app check, and editing these files during development changes those baseline hashes. The original ZIP remains the immutable provenance reference.

Architecture: `ARCHITECTURE.md`. AI record: `AI_USAGE.md`. Agent-generated tradeoff notes: `notes/CANDIDATE_DECISION_NOTES.md`. The candidate must personally author the final `DECISIONS.md`; it is intentionally not impersonated by the agent. Final review and exact evidence gaps are in `review/`.
