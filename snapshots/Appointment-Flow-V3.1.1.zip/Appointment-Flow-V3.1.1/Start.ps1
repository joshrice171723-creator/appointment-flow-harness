param([switch]$Setup)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$env:npm_config_allow_scripts = ''
foreach ($postgresBin in @('C:\PostgreSQL\17\bin', 'C:\Program Files\PostgreSQL\17\bin')) {
    if (Test-Path -LiteralPath "$postgresBin\psql.exe") { $env:PATH = "$postgresBin;$env:PATH"; break }
}
if ($Setup) {
    Push-Location "$projectRoot\backend"
    try {
        bundle install
        if ($LASTEXITCODE -ne 0) { throw 'Bundle installation failed' }
        ruby bin/rails db:prepare
        if ($LASTEXITCODE -ne 0) { throw 'Database preparation failed; check PostgreSQL environment variables' }
    } finally { Pop-Location }
    Push-Location "$projectRoot\frontend"
    try {
        npm.cmd ci --ignore-scripts
        if ($LASTEXITCODE -ne 0) { throw 'Frontend dependency installation failed' }
    } finally { Pop-Location }
}
New-Item -ItemType Directory -Path "$projectRoot\tmp" -Force | Out-Null
$rubyExecutable = (Get-Command ruby).Source
$nodeExecutable = (Get-Command node).Source
$backendProcess = Start-Process -FilePath $rubyExecutable -ArgumentList @('bin/rails', 'server', '-b', '127.0.0.1', '-p', '3040') -WorkingDirectory "$projectRoot\backend" -WindowStyle Hidden -PassThru -RedirectStandardOutput "$projectRoot\tmp\rails.stdout.log" -RedirectStandardError "$projectRoot\tmp\rails.stderr.log"
$frontendProcess = Start-Process -FilePath $nodeExecutable -ArgumentList @('node_modules/vite/bin/vite.js') -WorkingDirectory "$projectRoot\frontend" -WindowStyle Hidden -PassThru -RedirectStandardOutput "$projectRoot\tmp\vite.stdout.log" -RedirectStandardError "$projectRoot\tmp\vite.stderr.log"
Write-Output 'Apex demo: http://127.0.0.1:5174 . Press Ctrl+C to stop. Logs: tmp/ .'
try {
    while (-not $backendProcess.HasExited -and -not $frontendProcess.HasExited) { Start-Sleep -Seconds 1 }
    throw 'A server stopped; inspect tmp/ logs.'
} finally {
    foreach ($demoProcess in @($backendProcess, $frontendProcess)) {
        if (-not $demoProcess.HasExited) { Stop-Process -Id $demoProcess.Id }
    }
}
