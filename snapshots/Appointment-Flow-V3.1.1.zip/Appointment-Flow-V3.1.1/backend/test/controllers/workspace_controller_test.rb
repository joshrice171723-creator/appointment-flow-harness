require "test_helper"

class WorkspaceControllerTest < ActionDispatch::IntegrationTest
  def headers(clinic = 1)
    { "X-Clinic-Id" => clinic.to_s, "X-Staff-Name" => "Taylor Morgan" }
  end

  test "S10 clinic boundary rejects reads and mutations for other records" do
    other = Clinic.create!(id: 2, name: "Phoenix", timezone: "America/Phoenix")
    source_patient(2, phone: "+16025550102", email: "quinn@example.test")
    source_appointment(2, patient_id: 2, clinic_id: 2)
    other.sync!
    get "/api/workspace", headers: headers(2)
    assert_response :success
    assert_not_includes response.body, "Fictional1"
    post "/api/appointments/#{@appointment.id}/assign", headers: headers(2)
    assert_response :not_found
    assert_nil @appointment.reload.owner
    post "/api/patients/#{@patient.id}/verify", params: { values: {} }, headers: headers(2), as: :json
    assert_response :not_found
    message = send_initial
    post "/api/notifications/#{message.id}/replies", params: { body: "YES", event_id: SecureRandom.uuid }, headers: headers(2), as: :json
    assert_response :not_found
  end

  test "S16 S17 leadership contains only aggregate outcomes" do
    @appointment.update!(confirmed_at: @now)
    source_appointment(2, wall: "2026-11-14 15:00:00", status: "complete")
    @clinic.sync!
    get "/api/leadership", params: { month: "2026-11" }
    assert_response :success
    report = response.parsed_body.first
    assert_equal 1, report["completed"]
    assert_equal 1, report["recorded"]
    assert_equal 100.0, report["completion_rate"]
    %w[Fictional avery @example birthdate recipient patient body].each { |identifier| assert_not_includes response.body, identifier }
  end

  test "S19 rejected note saves nothing and repeated accepted request is safe" do
    data = { revision: 1, outcome: "attempted", note: "", request_id: SecureRandom.uuid }
    post "/api/appointments/#{@appointment.id}/follow_up", params: data, headers: headers, as: :json
    assert_response :unprocessable_entity
    assert_equal 0, FollowUp.count
    data[:note] = "Left voicemail"
    2.times do
      post "/api/appointments/#{@appointment.id}/follow_up", params: data, headers: headers, as: :json
      assert_response :success
    end
    assert_equal 1, FollowUp.count
  end

  test "staff actions require the demo identity and stale revisions reject" do
    post "/api/reminders", headers: { "X-Clinic-Id" => "1" }, as: :json
    assert_response :forbidden
    post "/api/appointments/#{@appointment.id}/follow_up", params: { revision: 9, outcome: "confirmed", note: "Phone", request_id: SecureRandom.uuid }, headers: headers, as: :json
    assert_response :unprocessable_entity
    assert_nil @appointment.reload.confirmed_at
  end
end
