require "test_helper"

class ConfirmationFlowTest < ActiveSupport::TestCase
  test "S01 clear YES confirms this revision and repeated batches do not resend" do
    message = send_initial
    assert_equal "accepted", message.status
    assert_includes message.body, "Nov 22, 2026 3:00 PM CST"
    assert_equal "Confirmed", receive(message, "yes").result
    ReminderRun.call(@clinic, now: @now)
    assert_equal 1, Notification.count
    assert @appointment.reload.confirmed_at
    assert_equal "scheduled", PmsAppointment.first.status
  end

  test "S02 email can confirm without SMS" do
    @patient.update!(verified: @patient.verified.merge("wireless_phone" => ""))
    message = send_initial
    assert_equal "email", message.channel
    assert_equal "Confirmed", receive(message, "YES").result
  end

  test "S03 moved appointment rejects old YES before explicit screen sync" do
    message = send_initial
    receive(message, "YES")
    source_change("UPDATE pms.appointments SET start_at='2026-11-23 16:00:00'")
    assert_equal "Needs staff review", receive(message, "YES").result
    assert_nil @appointment.reload.confirmed_at
    assert_equal 2, @appointment.revision
  end

  test "S04 broken old visit and new visit have independent lifecycles" do
    send_initial
    source_change("UPDATE pms.appointments SET status='broken'")
    source_appointment(2, wall: "2026-11-20 15:00:00")
    ReminderRun.call(@clinic, now: @now)
    assert_equal "broken", @appointment.reload.source_status
    assert_equal 1, @appointment.notifications.count
    assert_equal 1, @clinic.appointments.find_by!(pms_id: 2).notifications.count
  end

  test "S05 failed SMS is retained with one day-six backup email" do
    @patient.update!(verified: @patient.verified.merge("wireless_phone" => "+15125550199"))
    assert_equal "failed", send_initial.status
    2.times { ReminderRun.call(@clinic, now: @now + 1.day) }
    assert_equal [ "sms", "email" ], Notification.order(:id).pluck(:channel)
    assert_includes @appointment.reload.concern, "Delivery failed"
  end

  test "S06 repeated inbound event has one effect and conflicting reuse is rejected" do
    message = send_initial
    event = SecureRandom.uuid
    2.times { receive(message, "YES", event_id: event) }
    assert_equal 1, InboundReply.count
    assert_raises(ArgumentError) { receive(message, "NO", event_id: event) }
  end

  test "S07 later NO preserves confirmation and opens review" do
    message = send_initial
    receive(message, "YES")
    receive(message, "NO")
    assert @appointment.reload.confirmed_at
    assert @appointment.reply_review
    assert_equal "Needs attention", @appointment.work_status
  end

  test "S08 late YES does not confirm" do
    message = send_initial
    assert_equal "Needs staff review", receive(message, "YES", now: @appointment.starts_at).result
    assert_nil @appointment.reload.confirmed_at
  end

  test "S09 exact STOP survives sync and blocks SMS" do
    message = send_initial
    assert_equal "SMS stopped", receive(message, "stop").result
    @clinic.sync!
    assert @patient.reload.sms_opted_out
    ReminderRun.call(@clinic, now: @now + 4.days)
    assert_equal "email", Notification.last.channel
  end

  test "uncertain STOP text needs review" do
    receive(send_initial, "STOP please")
    assert_not @patient.reload.sms_opted_out
    assert @appointment.reload.reply_review
  end

  test "S11 attempted follow-up stays open and phone confirmation closes" do
    @appointment.update!(concern: "No reply")
    @clinic.with_lock { @appointment.record_follow_up!(staff: "Taylor Morgan", outcome: "attempted", note: "Left voicemail", request_id: SecureRandom.uuid) }
    assert_equal "In progress", @appointment.reload.work_status
    @clinic.with_lock { @appointment.record_follow_up!(staff: "Taylor Morgan", outcome: "confirmed", note: "Confirmed date by phone", request_id: SecureRandom.uuid) }
    assert_equal "Resolved", @appointment.reload.work_status
  end

  test "S12 shared number added after sending cannot confirm either patient" do
    message = send_initial
    source_patient(2)
    source_appointment(2, patient_id: 2)
    assert_equal "Needs staff review", receive(message, "YES").result
    assert_equal 0, Appointment.where.not(confirmed_at: nil).count
  end

  test "S12 shared phone is excluded from new sends" do
    source_patient(2)
    source_appointment(2, patient_id: 2)
    ReminderRun.call(@clinic, now: @now)
    assert_not Notification.where(channel: "sms").exists?
  end

  test "S13 minors and missing age cannot be sent reminders" do
    [ "2014-05-06", "" ].each do |birthday|
      @patient.update!(verified: @patient.verified.merge("birthdate" => birthday))
      ReminderRun.call(@clinic, now: @now)
      assert_equal 0, Notification.count
      assert_includes @appointment.reload.concern, "authorized adult"
    end
  end

  test "verification correction changes eligibility but never PMS" do
    @patient.update!(verified: {})
    ReminderRun.call(@clinic, now: @now)
    assert_equal 0, Notification.count
    @patient.verify!(@patient.source.slice(*Patient::FIELDS).merge("wireless_phone" => "+15125550188", "sms_consent" => true), staff: "Alex Chen")
    assert_equal "+15125550188", send_initial.recipient
    assert_equal "+15125550101", PmsPatient.first.wireless_phone
    assert_equal 2, ContactReview.count
  end

  test "new PMS contact conflict pauses outreach" do
    source_change("UPDATE pms.patients SET wireless_phone='+15125550188'")
    ReminderRun.call(@clinic, now: @now)
    assert_equal 0, Notification.count
    assert_includes @appointment.reload.concern, "conflict"
  end

  test "S14 empty source preserves local work and pauses sends" do
    source_change("DELETE FROM pms.appointments")
    assert_raises(Clinic::SourceUnavailable) { ReminderRun.call(@clinic, now: @now) }
    assert_equal 1, Appointment.count
    assert_equal 0, Notification.count
    assert @clinic.reload.sync_error
  end

  test "S15 missed cadence is coalesced and local hours respected" do
    assert_equal 0, ReminderRun.call(@clinic, now: @now.change(hour: 14))[:recorded]
    ReminderRun.call(@clinic, now: @now + 6.days)
    assert_equal [ "final" ], Notification.pluck(:step)
    ReminderRun.call(@clinic, now: @appointment.starts_at)
    assert_equal 1, Notification.count
  end

  test "S15 concurrent batches record exactly one logical send" do
    errors = Queue.new
    threads = 2.times.map do
      Thread.new do
        ActiveRecord::Base.connection_pool.with_connection do
          ReminderRun.call(Clinic.find(1), now: @now)
        rescue Clinic::SourceUnavailable => error
          errors << error
        end
      end
    end
    threads.each(&:join)
    assert_equal 1, Notification.count
    failures = errors.size.times.map { errors.pop }
    assert_empty failures, failures.map { |error| error.cause&.full_message || error.full_message }.join("\n")
  end

  test "clinic wall times convert explicitly and reject DST ambiguity" do
    assert_equal Time.utc(2026, 11, 22, 21), @appointment.starts_at
    phoenix = Clinic.new(timezone: "America/Phoenix")
    assert_equal Time.utc(2026, 11, 22, 22), phoenix.parse_wall_time("2026-11-22 15:00:00")
    assert_raises(ArgumentError) { @clinic.parse_wall_time("2026-11-01 01:30:00") }
    assert_raises(ArgumentError) { @clinic.parse_wall_time("2026-03-08 02:30:00") }
  end

  test "PMS models refuse writes" do
    assert_raises(ActiveRecord::ReadOnlyRecord) { PmsPatient.first.update!(first_name: "Wrong") }
  end

  test "STOP survives source failure and recipient reassignment" do
    message = send_initial
    source_change("DELETE FROM pms.appointments")
    assert_equal "SMS stopped", receive(message, "STOP").result
    assert SmsOptOut.exists?(clinic: @clinic, recipient: message.recipient)
    source_patient(2)
    source_appointment(2, patient_id: 2)
    @clinic.sync!
    other = @clinic.patients.find_by!(pms_id: 2)
    other.verify!(other.source.slice(*Patient::FIELDS).merge("sms_consent" => true), staff: "Alex Chen")
    assert_not other.permitted?("sms")
  end

  test "concurrent duplicate inbound event confirms exactly once" do
    message = send_initial
    event_id = SecureRandom.uuid
    errors = Queue.new
    threads = 2.times.map do
      Thread.new do
        ActiveRecord::Base.connection_pool.with_connection do
          receive(Notification.find(message.id), "YES", event_id: event_id)
        rescue StandardError => error
          errors << error
        end
      end
    end
    threads.each(&:join)
    assert_equal 0, errors.size
    assert_equal 1, InboundReply.count
    assert @appointment.reload.confirmed_at
  end
end
