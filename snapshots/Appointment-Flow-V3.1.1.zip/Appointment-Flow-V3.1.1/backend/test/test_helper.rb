ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"

class ActiveSupport::TestCase
  self.use_transactional_tests = false

  setup do
    ActiveRecord::Base.connection.execute("TRUNCATE sms_opt_outs,contact_reviews,follow_ups,inbound_replies,notifications,appointments,patients,clinics,pms.appointments,pms.patients,pms.clinics RESTART IDENTITY CASCADE")
    @now = Time.utc(2026, 11, 15, 18)
    travel_to @now
    @clinic = Clinic.create!(id: 1, name: "Austin", timezone: "America/Chicago")
    source_patient(1)
    source_appointment(1)
    @clinic.sync!
    @patient = @clinic.patients.first
    @patient.verify!(@patient.source.slice(*Patient::FIELDS).merge("sms_consent" => true, "email_consent" => true), staff: "Taylor Morgan")
    @appointment = @clinic.appointments.first
  end
  teardown { travel_back }

  def source_patient(id, phone: "+15125550101", email: "avery@example.test", birthdate: "1988-01-01", language: "en")
    connection = ActiveRecord::Base.connection
    values = [ id, "Fictional#{id}", "Demo", birthdate, phone, email, language ].map { |value| connection.quote(value) }
    connection.execute("INSERT INTO pms.patients (id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (#{values.join(',')})")
  end

  def source_appointment(id, patient_id: 1, clinic_id: 1, wall: "2026-11-22 15:00:00", status: "scheduled")
    connection = ActiveRecord::Base.connection
    connection.execute("INSERT INTO pms.clinics (id,name) VALUES (#{Integer(clinic_id)},'Fictional clinic') ON CONFLICT (id) DO NOTHING")
    connection.execute("INSERT INTO pms.appointments (id,patient_id,clinic_id,start_at,status,provider_name) VALUES (#{Integer(id)},#{Integer(patient_id)},#{Integer(clinic_id)},#{connection.quote(wall)},#{connection.quote(status)},'Dr. Demo')")
  end

  def source_change(sql)
    ActiveRecord::Base.connection.execute(sql)
  end

  def send_initial
    ReminderRun.call(@clinic, now: @now)
    Notification.first
  end

  def receive(message, body, event_id: SecureRandom.uuid, now: @now)
    InboundReply.receive!(notification: message, body: body, event_id: event_id, now: now)
  end
end
