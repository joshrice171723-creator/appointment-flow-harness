namespace :reminders do
  desc "Record fake reminder attempts for all clinics (no live delivery)"
  task run: :environment do
    Clinic.order(:id).each { |clinic| puts "#{clinic.name}: #{ReminderRun.call(clinic)}" }
  end
end
