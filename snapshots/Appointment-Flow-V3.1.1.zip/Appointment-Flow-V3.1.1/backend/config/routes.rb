Rails.application.routes.draw do
  get "up" => "rails/health#show"
  scope :api do
    get "clinics", to: "workspace#clinics"
    get "workspace", to: "workspace#show"
    get "leadership", to: "workspace#leadership"
    post "reminders", to: "workspace#reminders"
    post "patients/:id/verify", to: "workspace#verify_contact"
    post "appointments/:id/assign", to: "workspace#assign"
    post "appointments/:id/follow_up", to: "workspace#follow_up"
    post "notifications/:id/replies", to: "workspace#reply"
  end
end
