# The replicated schema and public schema must both load into a newly created database.
ActiveRecord::Tasks::DatabaseTasks.structure_dump_flags = [ "--clean", "--if-exists" ]
