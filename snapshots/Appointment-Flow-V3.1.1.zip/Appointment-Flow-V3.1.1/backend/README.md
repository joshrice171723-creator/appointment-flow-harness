# Rails backend

See the repository-root README.md for setup, source boundaries, reminder/reply simulation and verification commands. The API binds to 127.0.0.1:3040 during the local demo.
