class CreateClinicFlow < ActiveRecord::Migration[8.1]
  def change
    reversible do |dir|
      dir.up do
        execute <<~SQL
          CREATE SCHEMA pms;
          CREATE TABLE pms.clinics (id BIGINT PRIMARY KEY, name TEXT NOT NULL, address_line TEXT, city TEXT, state CHAR(2), phone TEXT);
          CREATE TABLE pms.patients (id BIGINT PRIMARY KEY, first_name TEXT NOT NULL, last_name TEXT NOT NULL, birthdate DATE, wireless_phone TEXT, email TEXT, preferred_language TEXT, guarantor_id BIGINT REFERENCES pms.patients(id));
          CREATE TABLE pms.appointments (id BIGINT PRIMARY KEY, patient_id BIGINT NOT NULL REFERENCES pms.patients(id), clinic_id BIGINT NOT NULL REFERENCES pms.clinics(id), provider_name TEXT, start_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, length_minutes INT, procedure_note TEXT, status TEXT NOT NULL, updated_at TIMESTAMP WITHOUT TIME ZONE);
        SQL
      end
      dir.down { execute "DROP SCHEMA pms CASCADE" }
    end
    create_table :clinics do |t|
      t.string :name, :timezone, null: false
      t.datetime :synced_at
      t.string :sync_error
    end
    create_table :patients do |t|
      t.references :clinic, foreign_key: true, null: false
      t.bigint :pms_id, null: false
      t.jsonb :source, :verified, :verified_source, null: false, default: {}
      t.boolean :sms_consent, :email_consent, :sms_opted_out, null: false, default: false
      t.timestamps
    end
    add_index :patients, [ :clinic_id, :pms_id ], unique: true
    create_table :appointments do |t|
      t.references :clinic, :patient, foreign_key: true, null: false
      t.bigint :pms_id, null: false
      t.string :wall_time, :source_status, :provider, null: false
      t.datetime :starts_at, null: false
      t.integer :revision, null: false, default: 1
      t.datetime :confirmed_at
      t.string :staff_outcome, :owner, :concern
      t.boolean :reply_review, null: false, default: false
      t.timestamps
    end
    add_index :appointments, [ :clinic_id, :pms_id ], unique: true
    add_index :appointments, [ :clinic_id, :starts_at ]
    create_table :notifications do |t|
      t.references :appointment, foreign_key: true, null: false
      t.integer :revision, null: false
      t.string :step, :channel, :recipient, :status, null: false
      t.text :body, null: false
      t.timestamps
    end
    add_index :notifications, [ :appointment_id, :revision, :step ], unique: true
    create_table :inbound_replies do |t|
      t.references :notification, foreign_key: true, null: false
      t.string :event_id, :result, null: false
      t.text :body, null: false
      t.timestamps
    end
    add_index :inbound_replies, :event_id, unique: true
    create_table :follow_ups do |t|
      t.references :appointment, foreign_key: true, null: false
      t.string :request_id, :staff, :outcome, null: false
      t.text :note, null: false
      t.timestamps
    end
    add_index :follow_ups, :request_id, unique: true
    create_table :contact_reviews do |t|
      t.references :patient, foreign_key: true, null: false
      t.string :staff, null: false
      t.jsonb :before, :after, null: false
      t.timestamps
    end
  end
end
