class CreateSmsOptOuts < ActiveRecord::Migration[8.1]
  def change
    create_table :sms_opt_outs do |t|
      t.references :clinic, null: false, foreign_key: true
      t.string :recipient, null: false
      t.timestamps
    end
    add_index :sms_opt_outs, [ :clinic_id, :recipient ], unique: true
  end
end
