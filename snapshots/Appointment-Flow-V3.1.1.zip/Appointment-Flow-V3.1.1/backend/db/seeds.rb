abort "Development seeds only" unless Rails.env.development? || Rails.env.test?
connection = ActiveRecord::Base.connection
abort "Seed database is not empty; seeds never erase work" if Clinic.exists?
today = Date.current
ActiveRecord::Base.transaction do
  [ [ 1, "Austin", "TX", "America/Chicago" ], [ 2, "Phoenix", "AZ", "America/Phoenix" ] ].each do |id, name, state, zone|
    connection.execute("INSERT INTO pms.clinics (id,name,city,state) VALUES (#{id},#{connection.quote(name)},#{connection.quote(name)},#{connection.quote(state)})")
    Clinic.create!(id: id, name: name, timezone: zone)
    12.times do |index|
      patient_id = id * 100 + index
      first = %w[Avery Jordan Casey Riley Morgan Quinn Sage Rowan Skyler Parker Cameron Drew][index]
      birthdate = index == 6 ? "2014-05-06" : "1988-04-12"
      phone = index == 2 ? nil : "+1#{id == 1 ? '512' : '602'}555#{format('%04d', index == 3 ? 199 : 100 + index)}"
      language = index == 7 ? "fr" : index == 5 ? "es" : "en"
      values = [ patient_id, first, "Demo", birthdate, phone, "#{first.downcase}.#{id}@example.test", language ].map { |value| connection.quote(value) }
      connection.execute("INSERT INTO pms.patients (id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES (#{values.join(',')})")
      day = index < 8 ? today + [ 7, 3, 6, 7, 1, 2, 3, 5 ][index] : today - (index - 7)
      status = index < 8 ? "scheduled" : %w[complete complete broken unscheduled][index - 8]
      wall = "#{day} 15:00:00"
      connection.execute("INSERT INTO pms.appointments (id,patient_id,clinic_id,provider_name,start_at,length_minutes,status,updated_at) VALUES (#{patient_id},#{patient_id},#{id},'Dr. Ellis',#{connection.quote(wall)},45,#{connection.quote(status)},#{connection.quote(wall)})")
    end
  end
end
Clinic.find_each do |clinic|
  raise "Seed sync failed" unless clinic.sync!
  clinic.patients.each do |patient|
    next if patient.pms_id % 100 == 7
    patient.verify!(patient.source.slice(*Patient::FIELDS).merge("sms_consent" => true, "email_consent" => true), staff: "Taylor Morgan")
  end
  clinic.appointments.find_by!(pms_id: clinic.id * 100 + 4).update!(confirmed_at: Time.current)
  clinic.appointments.find_by!(pms_id: clinic.id * 100 + 1).update!(concern: "No reply before appointment; call patient")
  ReminderRun.call(clinic, now: Time.current.in_time_zone(clinic.timezone).change(hour: 12))
end
puts "Seeded 2 clinics, 24 fictional patients and visits; fake transport only."
