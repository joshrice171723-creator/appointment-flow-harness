SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.patients DROP CONSTRAINT IF EXISTS fk_rails_ffa68283b8;
ALTER TABLE IF EXISTS ONLY public.follow_ups DROP CONSTRAINT IF EXISTS fk_rails_f323c6ac33;
ALTER TABLE IF EXISTS ONLY public.appointments DROP CONSTRAINT IF EXISTS fk_rails_e048c6d191;
ALTER TABLE IF EXISTS ONLY public.inbound_replies DROP CONSTRAINT IF EXISTS fk_rails_ccde0c4534;
ALTER TABLE IF EXISTS ONLY public.appointments DROP CONSTRAINT IF EXISTS fk_rails_c63da04ab4;
ALTER TABLE IF EXISTS ONLY public.contact_reviews DROP CONSTRAINT IF EXISTS fk_rails_a72900b223;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS fk_rails_9d113f9d4b;
ALTER TABLE IF EXISTS ONLY public.sms_opt_outs DROP CONSTRAINT IF EXISTS fk_rails_583ef9e326;
ALTER TABLE IF EXISTS ONLY pms.patients DROP CONSTRAINT IF EXISTS patients_guarantor_id_fkey;
ALTER TABLE IF EXISTS ONLY pms.appointments DROP CONSTRAINT IF EXISTS appointments_patient_id_fkey;
ALTER TABLE IF EXISTS ONLY pms.appointments DROP CONSTRAINT IF EXISTS appointments_clinic_id_fkey;
DROP INDEX IF EXISTS public.index_sms_opt_outs_on_clinic_id_and_recipient;
DROP INDEX IF EXISTS public.index_sms_opt_outs_on_clinic_id;
DROP INDEX IF EXISTS public.index_patients_on_clinic_id_and_pms_id;
DROP INDEX IF EXISTS public.index_patients_on_clinic_id;
DROP INDEX IF EXISTS public.index_notifications_on_appointment_id_and_revision_and_step;
DROP INDEX IF EXISTS public.index_notifications_on_appointment_id;
DROP INDEX IF EXISTS public.index_inbound_replies_on_notification_id;
DROP INDEX IF EXISTS public.index_inbound_replies_on_event_id;
DROP INDEX IF EXISTS public.index_follow_ups_on_request_id;
DROP INDEX IF EXISTS public.index_follow_ups_on_appointment_id;
DROP INDEX IF EXISTS public.index_contact_reviews_on_patient_id;
DROP INDEX IF EXISTS public.index_appointments_on_patient_id;
DROP INDEX IF EXISTS public.index_appointments_on_clinic_id_and_starts_at;
DROP INDEX IF EXISTS public.index_appointments_on_clinic_id_and_pms_id;
DROP INDEX IF EXISTS public.index_appointments_on_clinic_id;
ALTER TABLE IF EXISTS ONLY public.sms_opt_outs DROP CONSTRAINT IF EXISTS sms_opt_outs_pkey;
ALTER TABLE IF EXISTS ONLY public.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.patients DROP CONSTRAINT IF EXISTS patients_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.inbound_replies DROP CONSTRAINT IF EXISTS inbound_replies_pkey;
ALTER TABLE IF EXISTS ONLY public.follow_ups DROP CONSTRAINT IF EXISTS follow_ups_pkey;
ALTER TABLE IF EXISTS ONLY public.contact_reviews DROP CONSTRAINT IF EXISTS contact_reviews_pkey;
ALTER TABLE IF EXISTS ONLY public.clinics DROP CONSTRAINT IF EXISTS clinics_pkey;
ALTER TABLE IF EXISTS ONLY public.ar_internal_metadata DROP CONSTRAINT IF EXISTS ar_internal_metadata_pkey;
ALTER TABLE IF EXISTS ONLY public.appointments DROP CONSTRAINT IF EXISTS appointments_pkey;
ALTER TABLE IF EXISTS ONLY pms.patients DROP CONSTRAINT IF EXISTS patients_pkey;
ALTER TABLE IF EXISTS ONLY pms.clinics DROP CONSTRAINT IF EXISTS clinics_pkey;
ALTER TABLE IF EXISTS ONLY pms.appointments DROP CONSTRAINT IF EXISTS appointments_pkey;
ALTER TABLE IF EXISTS public.sms_opt_outs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.patients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.inbound_replies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.follow_ups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contact_reviews ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.clinics ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.appointments ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.sms_opt_outs_id_seq;
DROP TABLE IF EXISTS public.sms_opt_outs;
DROP TABLE IF EXISTS public.schema_migrations;
DROP SEQUENCE IF EXISTS public.patients_id_seq;
DROP TABLE IF EXISTS public.patients;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.inbound_replies_id_seq;
DROP TABLE IF EXISTS public.inbound_replies;
DROP SEQUENCE IF EXISTS public.follow_ups_id_seq;
DROP TABLE IF EXISTS public.follow_ups;
DROP SEQUENCE IF EXISTS public.contact_reviews_id_seq;
DROP TABLE IF EXISTS public.contact_reviews;
DROP SEQUENCE IF EXISTS public.clinics_id_seq;
DROP TABLE IF EXISTS public.clinics;
DROP TABLE IF EXISTS public.ar_internal_metadata;
DROP SEQUENCE IF EXISTS public.appointments_id_seq;
DROP TABLE IF EXISTS public.appointments;
DROP TABLE IF EXISTS pms.patients;
DROP TABLE IF EXISTS pms.clinics;
DROP TABLE IF EXISTS pms.appointments;
DROP SCHEMA IF EXISTS public;
DROP SCHEMA IF EXISTS pms;
--
-- Name: pms; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pms;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.appointments (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    provider_name text,
    start_at timestamp without time zone NOT NULL,
    length_minutes integer,
    procedure_note text,
    status text NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: clinics; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.clinics (
    id bigint NOT NULL,
    name text NOT NULL,
    address_line text,
    city text,
    state character(2),
    phone text
);


--
-- Name: patients; Type: TABLE; Schema: pms; Owner: -
--

CREATE TABLE pms.patients (
    id bigint NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    birthdate date,
    wireless_phone text,
    email text,
    preferred_language text,
    guarantor_id bigint
);


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    patient_id bigint NOT NULL,
    pms_id bigint NOT NULL,
    wall_time character varying NOT NULL,
    source_status character varying NOT NULL,
    provider character varying NOT NULL,
    starts_at timestamp(6) without time zone NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    confirmed_at timestamp(6) without time zone,
    staff_outcome character varying,
    owner character varying,
    concern character varying,
    reply_review boolean DEFAULT false NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.appointments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: clinics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinics (
    id bigint NOT NULL,
    name character varying NOT NULL,
    timezone character varying NOT NULL,
    synced_at timestamp(6) without time zone,
    sync_error character varying
);


--
-- Name: clinics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clinics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clinics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clinics_id_seq OWNED BY public.clinics.id;


--
-- Name: contact_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_reviews (
    id bigint NOT NULL,
    patient_id bigint NOT NULL,
    staff character varying NOT NULL,
    before jsonb NOT NULL,
    after jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: contact_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_reviews_id_seq OWNED BY public.contact_reviews.id;


--
-- Name: follow_ups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.follow_ups (
    id bigint NOT NULL,
    appointment_id bigint NOT NULL,
    request_id character varying NOT NULL,
    staff character varying NOT NULL,
    outcome character varying NOT NULL,
    note text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: follow_ups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.follow_ups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: follow_ups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.follow_ups_id_seq OWNED BY public.follow_ups.id;


--
-- Name: inbound_replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inbound_replies (
    id bigint NOT NULL,
    notification_id bigint NOT NULL,
    event_id character varying NOT NULL,
    result character varying NOT NULL,
    body text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: inbound_replies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inbound_replies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inbound_replies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inbound_replies_id_seq OWNED BY public.inbound_replies.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    appointment_id bigint NOT NULL,
    revision integer NOT NULL,
    step character varying NOT NULL,
    channel character varying NOT NULL,
    recipient character varying NOT NULL,
    status character varying NOT NULL,
    body text NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    pms_id bigint NOT NULL,
    source jsonb DEFAULT '{}'::jsonb NOT NULL,
    verified jsonb DEFAULT '{}'::jsonb NOT NULL,
    verified_source jsonb DEFAULT '{}'::jsonb NOT NULL,
    sms_consent boolean DEFAULT false NOT NULL,
    email_consent boolean DEFAULT false NOT NULL,
    sms_opted_out boolean DEFAULT false NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: sms_opt_outs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_opt_outs (
    id bigint NOT NULL,
    clinic_id bigint NOT NULL,
    recipient character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_opt_outs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_opt_outs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_opt_outs_id_seq OWNED BY public.sms_opt_outs.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: clinics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics ALTER COLUMN id SET DEFAULT nextval('public.clinics_id_seq'::regclass);


--
-- Name: contact_reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_reviews ALTER COLUMN id SET DEFAULT nextval('public.contact_reviews_id_seq'::regclass);


--
-- Name: follow_ups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follow_ups ALTER COLUMN id SET DEFAULT nextval('public.follow_ups_id_seq'::regclass);


--
-- Name: inbound_replies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbound_replies ALTER COLUMN id SET DEFAULT nextval('public.inbound_replies_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: sms_opt_outs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs ALTER COLUMN id SET DEFAULT nextval('public.sms_opt_outs_id_seq'::regclass);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: contact_reviews contact_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_reviews
    ADD CONSTRAINT contact_reviews_pkey PRIMARY KEY (id);


--
-- Name: follow_ups follow_ups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT follow_ups_pkey PRIMARY KEY (id);


--
-- Name: inbound_replies inbound_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbound_replies
    ADD CONSTRAINT inbound_replies_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sms_opt_outs sms_opt_outs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs
    ADD CONSTRAINT sms_opt_outs_pkey PRIMARY KEY (id);


--
-- Name: index_appointments_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_appointments_on_clinic_id ON public.appointments USING btree (clinic_id);


--
-- Name: index_appointments_on_clinic_id_and_pms_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_appointments_on_clinic_id_and_pms_id ON public.appointments USING btree (clinic_id, pms_id);


--
-- Name: index_appointments_on_clinic_id_and_starts_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_appointments_on_clinic_id_and_starts_at ON public.appointments USING btree (clinic_id, starts_at);


--
-- Name: index_appointments_on_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_appointments_on_patient_id ON public.appointments USING btree (patient_id);


--
-- Name: index_contact_reviews_on_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contact_reviews_on_patient_id ON public.contact_reviews USING btree (patient_id);


--
-- Name: index_follow_ups_on_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_follow_ups_on_appointment_id ON public.follow_ups USING btree (appointment_id);


--
-- Name: index_follow_ups_on_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_follow_ups_on_request_id ON public.follow_ups USING btree (request_id);


--
-- Name: index_inbound_replies_on_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_inbound_replies_on_event_id ON public.inbound_replies USING btree (event_id);


--
-- Name: index_inbound_replies_on_notification_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_inbound_replies_on_notification_id ON public.inbound_replies USING btree (notification_id);


--
-- Name: index_notifications_on_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_appointment_id ON public.notifications USING btree (appointment_id);


--
-- Name: index_notifications_on_appointment_id_and_revision_and_step; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notifications_on_appointment_id_and_revision_and_step ON public.notifications USING btree (appointment_id, revision, step);


--
-- Name: index_patients_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_patients_on_clinic_id ON public.patients USING btree (clinic_id);


--
-- Name: index_patients_on_clinic_id_and_pms_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_patients_on_clinic_id_and_pms_id ON public.patients USING btree (clinic_id, pms_id);


--
-- Name: index_sms_opt_outs_on_clinic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sms_opt_outs_on_clinic_id ON public.sms_opt_outs USING btree (clinic_id);


--
-- Name: index_sms_opt_outs_on_clinic_id_and_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_sms_opt_outs_on_clinic_id_and_recipient ON public.sms_opt_outs USING btree (clinic_id, recipient);


--
-- Name: appointments appointments_clinic_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES pms.clinics(id);


--
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES pms.patients(id);


--
-- Name: patients patients_guarantor_id_fkey; Type: FK CONSTRAINT; Schema: pms; Owner: -
--

ALTER TABLE ONLY pms.patients
    ADD CONSTRAINT patients_guarantor_id_fkey FOREIGN KEY (guarantor_id) REFERENCES pms.patients(id);


--
-- Name: sms_opt_outs fk_rails_583ef9e326; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_opt_outs
    ADD CONSTRAINT fk_rails_583ef9e326 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: notifications fk_rails_9d113f9d4b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_9d113f9d4b FOREIGN KEY (appointment_id) REFERENCES public.appointments(id);


--
-- Name: contact_reviews fk_rails_a72900b223; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_reviews
    ADD CONSTRAINT fk_rails_a72900b223 FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: appointments fk_rails_c63da04ab4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT fk_rails_c63da04ab4 FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: inbound_replies fk_rails_ccde0c4534; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbound_replies
    ADD CONSTRAINT fk_rails_ccde0c4534 FOREIGN KEY (notification_id) REFERENCES public.notifications(id);


--
-- Name: appointments fk_rails_e048c6d191; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT fk_rails_e048c6d191 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- Name: follow_ups fk_rails_f323c6ac33; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follow_ups
    ADD CONSTRAINT fk_rails_f323c6ac33 FOREIGN KEY (appointment_id) REFERENCES public.appointments(id);


--
-- Name: patients fk_rails_ffa68283b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT fk_rails_ffa68283b8 FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO "$user", public;

INSERT INTO "schema_migrations" (version) VALUES
('20261115020000'),
('20261115010000');
