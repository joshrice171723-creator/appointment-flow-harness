class WorkspaceController < ApplicationController
  before_action :load_clinic, except: [ :clinics, :leadership ]
  before_action :require_staff, only: [ :reminders, :verify_contact, :assign, :follow_up ]
  rescue_from ActiveRecord::RecordNotFound, with: -> { render json: { error: "Record not found in this clinic" }, status: :not_found }
  rescue_from ArgumentError, ActiveRecord::RecordInvalid, with: ->(error) { render json: { error: error.message }, status: :unprocessable_entity }
  rescue_from Clinic::SourceUnavailable, with: -> { render json: { error: "Source refresh failed; outreach paused" }, status: :service_unavailable }
  STAFF = [ "Taylor Morgan", "Alex Chen" ].freeze

  def clinics
    render json: Clinic.order(:id).map(&:payload)
  end

  def show
    @clinic.sync!
    appointments = @clinic.appointments.includes(:patient, :follow_ups, notifications: :inbound_replies).order(:starts_at)
    render json: { clinic: @clinic.reload.payload, patients: @clinic.patients.order(:id).map(&:payload),
      appointments: appointments.map(&:payload), notifications: appointments.flat_map { |appointment| appointment.notifications.map(&:payload) },
      follow_ups: appointments.flat_map { |appointment| appointment.follow_ups.map { |follow| follow.slice(:id, :appointment_id, :staff, :outcome, :note, :created_at) } },
      contact_reviews: ContactReview.joins(:patient).where(patients: { clinic_id: @clinic.id }).order(:id).map { |review| review.slice(:id, :patient_id, :staff, :created_at, :before, :after) } }
  end

  def reminders
    render json: ReminderRun.call(@clinic)
  end

  def verify_contact
    @clinic.with_snapshot do
      @clinic.patients.find(params[:id]).verify!(params.require(:values).permit(*Patient::FIELDS, :sms_consent, :email_consent).to_h, staff: staff)
    end
    render json: { status: "Contact verified locally; PMS unchanged" }
  end

  def assign
    @clinic.with_lock { @clinic.appointments.find(params[:id]).update!(owner: staff) }
    render json: { status: "Assigned to #{staff}" }
  end

  def follow_up
    @clinic.with_snapshot do
      appointment = @clinic.appointments.find(params[:id])
      raise ArgumentError, "Appointment changed; refresh before saving" unless appointment.revision == params[:revision].to_i
      appointment.record_follow_up!(staff: staff, outcome: params[:outcome], note: params[:note], request_id: params[:request_id])
    end
    render json: { status: "Follow-up recorded" }
  end

  def reply
    notification = Notification.joins(:appointment).where(appointments: { clinic_id: @clinic.id }).find(params[:id])
    result = InboundReply.receive!(notification: notification, body: params[:body], event_id: params[:event_id])
    render json: { status: result.result }
  end

  def leadership
    raise ArgumentError, "Select a reporting month" unless params[:month].to_s.match?(/\A\d{4}-\d{2}\z/)
    render json: LeadershipReport.call(Date.strptime(params[:month], "%Y-%m"))
  end

  private

  def load_clinic
    @clinic = Clinic.find(request.headers["X-Clinic-Id"])
  end

  def staff
    request.headers["X-Staff-Name"]
  end

  def require_staff
    render json: { error: "Select a demo staff identity" }, status: :forbidden unless STAFF.include?(staff)
  end
end
