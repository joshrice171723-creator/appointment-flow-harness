class Patient < ApplicationRecord
  belongs_to :clinic
  has_many :appointments
  has_many :contact_reviews
  FIELDS = %w[birthdate wireless_phone email preferred_language].freeze

  def name
    [ source["first_name"], source["last_name"] ].join(" ")
  end

  def facts
    source.merge(verified)
  end

  def recipient(channel)
    raw = facts[channel == "sms" ? "wireless_phone" : "email"].to_s.strip
    if channel == "sms"
      digits = raw.gsub(/\D/, "")
      digits = "1#{digits}" if digits.size == 10
      "+#{digits}" if digits.match?(/\A1\d{10}\z/)
    elsif raw.match?(/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/)
      raw.downcase
    end
  end

  def shared?(channel, recipient_value = recipient(channel))
    recipient_value && clinic.patients.where.not(id: id).any? { |other| other.recipient(channel) == recipient_value }
  end

  def hold(now = Time.current)
    return "Verified details conflict with PMS; review contact" if verified_source.any? { |key, value| source[key] != value }
    birthday = Date.iso8601(facts["birthdate"].to_s) rescue nil
    return "Verify birthdate and authorized adult contact" unless birthday && birthday <= now.in_time_zone(clinic.timezone).to_date.advance(years: -18)
    return "Arrange contact in the preferred language" unless %w[en es].include?(facts["preferred_language"])
    return "Verify contact details and channel permissions" if verified.empty?
    nil
  end

  def permitted?(channel)
    channel == "sms" ? sms_consent && !sms_opted_out && !SmsOptOut.exists?(clinic_id: clinic_id, recipient: recipient("sms")) : email_consent
  end

  def safe_channels(now = Time.current)
    return [] if hold(now)
    %w[sms email].select { |channel| permitted?(channel) && recipient(channel) && !shared?(channel) }
  end

  def verify!(values, staff:)
    contact = values.slice(*FIELDS).transform_values { |value| value.to_s.strip }
    raise ArgumentError, "All contact fields are required" unless contact.keys.sort == FIELDS.sort
    birthday = Date.iso8601(contact.fetch("birthdate"))
    raise ArgumentError, "Birthdate cannot be in the future" if birthday > Date.current
    transaction do
      before = { facts: facts, sms_consent: sms_consent, email_consent: email_consent }
      update!(verified: contact, verified_source: source.slice(*FIELDS),
        sms_consent: values["sms_consent"] == true, email_consent: values["email_consent"] == true)
      contact_reviews.create!(staff: staff, before: before, after: { facts: facts, sms_consent: sms_consent, email_consent: email_consent })
    end
  end

  def payload
    { id: id, name: name, source: source.slice(*FIELDS), facts: facts.slice(*FIELDS), verified: verified.present?,
      sms_consent: sms_consent, email_consent: email_consent, sms_opted_out: sms_opted_out, hold: hold }
  end
end
