class PmsAppointment < PmsRecord
  self.table_name = "pms.appointments"
end
