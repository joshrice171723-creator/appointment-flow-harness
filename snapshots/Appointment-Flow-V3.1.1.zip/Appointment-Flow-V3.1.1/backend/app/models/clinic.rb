class Clinic < ApplicationRecord
  has_many :patients
  has_many :appointments

  class SourceUnavailable < StandardError; end

  def sync!
    # The same snapshot contains both source reads and the local revision updates.
    with_snapshot { true }
    true
  rescue SourceUnavailable, ActiveRecord::ActiveRecordError, ArgumentError => error
    update!(sync_error: "Source refresh failed (#{error.class.name}); outreach paused")
    false
  end

  def with_snapshot(refresh: true)
    attempts = 0
    begin
      with_lock(isolation: :repeatable_read) do
        import_snapshot! if refresh
        yield
      end
    rescue ActiveRecord::SerializationFailure, ActiveRecord::RecordNotUnique
      attempts += 1
      if attempts < 3
        reload
        retry
      end
      raise SourceUnavailable, "Concurrent clinic updates; retry after refreshing"
    end
  end

  def import_snapshot!
    rows = PmsAppointment.where(clinic_id: id).to_a
    raise SourceUnavailable, "Empty source" if rows.empty?
    people = PmsPatient.where(id: rows.map(&:patient_id)).index_by(&:id)
    raise SourceUnavailable, "Partial source" unless people.size == rows.map(&:patient_id).uniq.size
    rows.each do |row|
      person = people.fetch(row.patient_id)
      patient = patients.find_or_initialize_by(pms_id: person.id)
      patient.update!(source: person.attributes.except("id"))
      appointment = appointments.find_or_initialize_by(pms_id: row.id)
      wall = row.start_at.strftime("%Y-%m-%d %H:%M:%S")
      changed = appointment.persisted? && [ appointment.wall_time, appointment.source_status, appointment.patient_id ] != [ wall, row.status, patient.id ]
      appointment.assign_attributes(patient: patient, wall_time: wall, starts_at: parse_wall_time(wall),
        source_status: row.status, provider: row.provider_name.to_s)
      if changed
        appointment.assign_attributes(revision: appointment.revision + 1, confirmed_at: nil, staff_outcome: nil,
          concern: "Appointment changed; verify the current time", reply_review: false)
      end
      appointment.save!
    end
    appointments.where.not(pms_id: rows.map(&:id)).update_all(source_status: "missing", confirmed_at: nil, concern: "Missing from source")
    update!(synced_at: Time.current, sync_error: nil)
  end

  def parse_wall_time(wall)
    local = DateTime.strptime(wall, "%Y-%m-%d %H:%M:%S")
    periods = TZInfo::Timezone.get(timezone).periods_for_local(local)
    raise ArgumentError, "Ambiguous or missing local time" unless periods.one?
    Time.utc(local.year, local.month, local.day, local.hour, local.min, local.sec) - periods.first.utc_total_offset
  end

  def payload
    { id: id, name: name, timezone: timezone, synced_at: synced_at, sync_error: sync_error }
  end
end
