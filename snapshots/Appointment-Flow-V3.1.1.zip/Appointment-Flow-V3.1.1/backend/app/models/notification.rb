class Notification < ApplicationRecord
  belongs_to :appointment
  has_many :inbound_replies

  def payload
    { id: id, appointment_id: appointment_id, revision: revision, channel: channel, body: body, status: status,
      created_at: created_at, replies: inbound_replies.order(:id).map { |reply| reply.slice(:id, :body, :result, :created_at) } }
  end
end
