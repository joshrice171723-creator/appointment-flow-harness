class PmsPatient < PmsRecord
  self.table_name = "pms.patients"
end
