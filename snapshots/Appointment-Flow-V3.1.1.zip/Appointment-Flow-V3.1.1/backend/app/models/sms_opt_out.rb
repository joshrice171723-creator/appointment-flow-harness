class SmsOptOut < ApplicationRecord
  belongs_to :clinic
end
