class Appointment < ApplicationRecord
  belongs_to :clinic
  belongs_to :patient
  has_many :notifications
  has_many :follow_ups

  def upcoming?(now = Time.current)
    source_status == "scheduled" && staff_outcome.nil? && starts_at > now
  end

  def work_status
    return "Needs attention" if reply_review
    return "Resolved" if confirmed_at || staff_outcome || source_status != "scheduled" || starts_at <= Time.current
    owner.present? ? "In progress" : "Needs attention"
  end

  def record_follow_up!(staff:, outcome:, note:, request_id:, now: Time.current)
    previous = FollowUp.find_by(request_id: request_id)
    if previous
      raise ArgumentError, "Request ID already used" unless previous.appointment_id == id && previous.outcome == outcome && previous.note == note && previous.staff == staff
      return previous
    end
    raise ArgumentError, "Enter a follow-up note" if note.to_s.strip.empty? || note.size > 2000
    raise ArgumentError, "Unknown follow-up outcome" unless %w[attempted confirmed rescheduled canceled reviewed].include?(outcome)
    raise ArgumentError, "Appointment is no longer scheduled in the future" unless upcoming?(now) || outcome == "reviewed"
    raise ArgumentError, "Appointment changed; refresh before saving" unless request_id.to_s.match?(/\A[\w-]{10,100}\z/)
    record = follow_ups.create!(staff: staff, outcome: outcome, note: note, request_id: request_id)
    changes = { owner: staff }
    changes.merge!(concern: nil, reply_review: false) unless outcome == "attempted"
    changes[:confirmed_at] = now if outcome == "confirmed"
    changes[:staff_outcome] = outcome if %w[rescheduled canceled].include?(outcome)
    update!(changes)
    record
  end

  def payload
    { id: id, patient_id: patient_id, name: patient.name, pms_id: pms_id, revision: revision,
      starts_at: starts_at, wall_time: wall_time, source_status: source_status, provider: provider,
      confirmed_at: confirmed_at, staff_outcome: staff_outcome, owner: owner, concern: concern,
      reply_review: reply_review, work_status: work_status }
  end
end
