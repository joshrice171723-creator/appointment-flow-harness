class InboundReply < ApplicationRecord
  belongs_to :notification
  validates :body, length: { in: 1..2000 }
  validates :event_id, format: { with: /\A[\w-]{10,100}\z/ }

  def self.receive!(notification:, body:, event_id:, now: Time.current)
    clinic = notification.appointment.clinic
    command = body.to_s.strip.upcase
    stopping_sms = command == "STOP" && notification.channel == "sms"
    clinic.with_snapshot(refresh: !stopping_sms) do
      existing = find_by(event_id: event_id)
      if existing
        raise ArgumentError, "Reply identifier already used" unless existing.notification_id == notification.id && existing.body == body
        return existing
      end
      appointment = notification.appointment.reload
      patient = appointment.patient.reload
      result = "Needs staff review"
      if stopping_sms
        SmsOptOut.find_or_create_by!(clinic: clinic, recipient: notification.recipient)
        clinic.patients.each do |other|
          other.update!(sms_opted_out: true) if other.recipient("sms") == notification.recipient
        end
        result = "SMS stopped"
      elsif command == "YES" && appointment.upcoming?(now) && notification.status == "accepted" &&
          notification.revision == appointment.revision && notification.recipient == patient.recipient(notification.channel) &&
          patient.safe_channels(now).include?(notification.channel) &&
          clinic.appointments.where(patient: patient, source_status: "scheduled", staff_outcome: nil).where("starts_at > ?", now).count == 1
        appointment.update!(confirmed_at: now, concern: nil, reply_review: false)
        result = "Confirmed"
      end
      appointment.update!(concern: "Reply needs review; clarify intent and appointment", reply_review: true) if result == "Needs staff review"
      create!(notification: notification, body: body, event_id: event_id, result: result)
    end
  end
end
