class ContactReview < ApplicationRecord
  belongs_to :patient
end
