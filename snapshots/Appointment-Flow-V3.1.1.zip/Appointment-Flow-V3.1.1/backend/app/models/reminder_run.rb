class ReminderRun
  SEND_HOURS = 10...18

  def self.call(clinic, now: Time.current)
    count = 0
    clinic.with_snapshot do
      count = 0
      local = now.in_time_zone(clinic.timezone)
      return { recorded: 0, status: "Outside clinic sending hours (10:00-18:00)" } unless SEND_HOURS.cover?(local.hour)
      clinic.appointments.includes(:patient).find_each do |appointment|
        next unless appointment.upcoming?(now)
        days = (appointment.starts_at.in_time_zone(clinic.timezone).to_date - local.to_date).to_i
        next if days > 7
        patient = appointment.patient
        channels = patient.safe_channels(now)
        if channels.empty?
          appointment.update!(concern: patient.hold(now) || "No safe permitted channel; check shared contacts and permissions")
          next
        end
        if !appointment.confirmed_at && days <= 2 && appointment.concern.nil?
          appointment.update!(concern: "No reply before appointment; call patient")
        end
        step = days <= 1 ? "final" : days <= 3 ? "follow_up" : "initial"
        next if appointment.confirmed_at && step != "final"
        prior = appointment.notifications.where(revision: appointment.revision)
        channel = channels.include?("sms") ? "sms" : "email"
        if step == "initial" && days <= 6 && channels.include?("email") && prior.exists?(step: "initial", channel: "sms")
          step, channel = "backup", "email"
        end
        next if prior.exists?(step: step)
        body = message_text(appointment)
        recipient = patient.recipient(channel)
        status = FakeTransport.deliver(channel: channel, recipient: recipient, body: body)
        prior.create!(step: step, channel: channel, recipient: recipient, body: body, status: status)
        appointment.update!(concern: "Delivery failed; review contact details") if status == "failed"
        count += 1
      end
    end
    { recorded: count, status: "Fake attempts recorded; no live messages sent" }
  rescue Clinic::SourceUnavailable, ActiveRecord::ActiveRecordError, ArgumentError => error
    clinic.update!(sync_error: "Source refresh failed (#{error.class.name}); outreach paused")
    raise Clinic::SourceUnavailable, "Source refresh failed; outreach paused"
  end

  def self.message_text(appointment)
    date = appointment.starts_at.in_time_zone(appointment.clinic.timezone).strftime("%b %-d, %Y %-I:%M %p %Z")
    if appointment.patient.facts["preferred_language"] == "es"
      action = appointment.confirmed_at ? "Cita confirmada." : "Responda YES para confirmar o NO para ayuda."
      "#{appointment.clinic.name}: cita #{date}. #{action} STOP para dejar SMS."
    else
      action = appointment.confirmed_at ? "Your appointment is confirmed." : "Reply YES to confirm or NO for help."
      "#{appointment.clinic.name}: appointment #{date}. #{action} Reply STOP to stop SMS."
    end
  end
end
