class LeadershipReport
  def self.call(month)
    Clinic.order(:id).map do |clinic|
      period = clinic.appointments.where("wall_time >= ? AND wall_time < ?", month.strftime("%Y-%m-%d"), month.next_month.strftime("%Y-%m-%d"))
      recorded = period.where("starts_at < ?", Time.current)
      counts = recorded.group(:source_status).count
      total = recorded.count
      messages = Notification.where(appointment_id: period.select(:id))
      { clinic: clinic.name, recorded: total, completed: counts.fetch("complete", 0),
        canceled: counts.fetch("broken", 0), rescheduled: counts.fetch("unscheduled", 0),
        unknown: total - counts.values_at("complete", "broken", "unscheduled").compact.sum,
        completion_rate: total.positive? ? (100.0 * counts.fetch("complete", 0) / total).round(1) : nil,
        attempts: messages.count, failed: messages.where(status: "failed").count,
        replies: InboundReply.where(notification_id: messages.select(:id)).count,
        confirmations: period.where.not(confirmed_at: nil).count,
        open_holds: period.where.not(concern: nil).count,
        follow_ups: FollowUp.where(appointment_id: period.select(:id)).count }
    end
  end
end
