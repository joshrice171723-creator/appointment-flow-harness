class FollowUp < ApplicationRecord
  belongs_to :appointment
end
