class FakeTransport
  # Deterministic local acceptance only; this interface performs no network IO.
  def self.deliver(channel:, recipient:, body:)
    raise ArgumentError, "Unknown channel" unless %w[sms email].include?(channel)
    raise ArgumentError, "Empty message" if body.empty?
    recipient.end_with?("0199") || recipient.start_with?("fail@") ? "failed" : "accepted"
  end
end
