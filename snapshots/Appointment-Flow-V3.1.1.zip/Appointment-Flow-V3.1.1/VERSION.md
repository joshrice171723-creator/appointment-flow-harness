# V4 clean-room coding quality harness

Original V2 product specification, assessment and screenshots preserved.

V4 = V3 workflow + two evidence-based reviewer rubrics; no numerical scoring.

See `standards/INTEGRATION_NOTES.md` and `review/EXPERIMENT_PROTOCOL.md`.
