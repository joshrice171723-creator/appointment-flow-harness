# Components and confirmation lifecycle

```mermaid
flowchart LR
  PMS[(PMS replica: pms schema)] -->|consistent read only| C[Clinic snapshot transaction]
  C --> L[(Local records and appointment revisions)]
  UI[React workspaces] --> API[Rails workspace controller]
  API --> C
  API --> R[ReminderRun]
  R --> C
  R --> F[FakeTransport: no network IO]
  F --> N[(Notification attempts)]
  API --> I[InboundReply]
  I --> C
  I --> L
  I --> O[(Clinic and recipient SMS opt-outs)]
  API --> A[Appointment staff follow-up]
  A --> L
  API --> P[Patient local contact verification]
  P --> L
  L --> G[LeadershipReport aggregate-only response]
  G --> UI
```

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: Import current PMS visit
  Unconfirmed --> ContactHeld: Unsafe or unpermitted contact
  ContactHeld --> Unconfirmed: Staff verifies local contact
  Unconfirmed --> AwaitingReply: Fake notification accepted
  AwaitingReply --> Confirmed: Unambiguous current YES or staff phone confirmation
  AwaitingReply --> StaffReview: NO, unclear, shared, stale or late reply
  Confirmed --> StaffReview: Later conflicting intent; keep confirmation
  StaffReview --> Confirmed: Staff clarifies current visit and records confirmation
  Confirmed --> Unconfirmed: PMS appointment revision changes
  Unconfirmed --> Closed: PMS outcome or staff records canceled/rescheduled
  Confirmed --> Closed: PMS outcome or visit start passes
```

`Clinic#with_snapshot` owns the transaction and clinic row lock. A repeatable-read snapshot keeps the two PMS reads consistent. Database uniqueness rejects duplicate sends and inbound events. A bounded retry restarts the whole local-only operation when a concurrent transaction invalidates its snapshot. There is no external provider call inside the transaction: the fake transport only returns a deterministic result, and the notification record commits with the other local state.

`Appointment` owns staff outcomes and confirmation state for a source revision. `Patient` owns contact facts, local verification provenance and channel eligibility. `InboundReply` owns exact command matching and conservative review. `ReminderRun` owns cadence, clinic time and send eligibility. `LeadershipReport` explicitly constructs aggregate keys and never serializes patient records.

React keeps workspace, clinic, selected patient and form state close to their screens. Changing clinic remounts its workspace, preventing old patient/form state from crossing clinics. Read effects cancel obsolete requests. Writes are user-triggered, display rejection or uncertainty and retain drafts. Reply and follow-up requests have stable IDs until their draft changes or a save is accepted. A saved-write notice is separate from a failed subsequent read.

The source boundary is an application guarantee in the local owner-account demo. A deployed system must add a database SELECT-only role and authenticated clinic memberships. Real messaging, production auth/deployment, booking and self-service rescheduling are outside this exercise.
