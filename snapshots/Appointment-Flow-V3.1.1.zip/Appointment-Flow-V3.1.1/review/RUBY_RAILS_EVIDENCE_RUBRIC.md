# V4 — Ruby / Rails evidence-based review rubric

Use only in **V4's independent review stage**. This adapts the user-provided Ruby/Rails rubric without embedding prior application code, source paths, or examples. It is not a numerical grading system.

Review one concrete workflow at a time; trace the entry point, business rule, persistence and observable result. For each applicable criterion record **Meets**, **Revise**, **Unverified**, or **Outside scope**. A finding requires path/line evidence, its real consequence, and a minimal correction. Explain whether the concern is directly demonstrated, inferred from code, or still unverified.

| Criterion | Reviewer must establish | Typical evidence |
|---|---|---|
| Business cases | Normal, rejected and ambiguous outcomes are evident and consistent | Traced entry and named case tests |
| Proportion | New abstractions unify an actual rule rather than hypothetical future variation | Before/after call sites; shared change boundary |
| Dependencies and responsibilities | A decision has an owner; callers request useful outcomes | Call sites, collaborators and API contract |
| Call-site clarity | Argument meanings, units and nullable values are understandable | Declaration + invocation + observed edge case |
| Request flow and scope | Request validation, clinic-scoped lookup and domain behavior are traceable | Controller, authorization/selector boundary, tests |
| Persistence and side effects | Transaction ownership, source data boundary and retry semantics are correct | DB constraints, write paths, concurrency tests |
| Behavioral evidence | Tests would catch a plausible regression and assert outcomes independently | Focused request/model/job tests, executed logs |

### Safety-sensitive findings

Treat demonstrated wrong-recipient messaging, cross-clinic disclosure, mishandled reschedules, duplicate consequential sends, data corruption, live sends, or writes to read-only PMS source tables as blocking defects. Do not accept a green unit suite as proof if the relevant integration path has not been tested.

### Output

- Scope and commit/revision inspected.
- Table of applicable criteria with one of the four statuses and evidence.
- Findings: `file:line`, observed behavior or uncertainty, consequence, minimal remedy.
- Tests and checks actually executed; what is unverified.
- Candidate questions only for unresolved consequential choices.

Source adaptation: user-provided `apex-human-code-quality-rubric-2026-11-06.md`, with V1-specific examples, source-guide path dependencies, and historical scoring language removed.
