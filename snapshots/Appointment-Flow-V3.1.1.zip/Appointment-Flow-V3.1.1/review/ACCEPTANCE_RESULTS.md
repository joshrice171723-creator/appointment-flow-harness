# Acceptance evidence, 2026-11-15

Statuses refer to this local fictional-data demo. Source inspection, automated tests, running behavior and human acceptance remain separate.

| Scope | Result | Evidence |
|---|---|---|
| Initial harness integrity / all ten screenshots | PASS before code | Stage 0 `verify_harness.py`; original ZIP SHA-256 retained in freeze record |
| Official PMS discovery, fake SMS/email, confirmations and clinic staff UI | PASS | Rails model/request tests; real Chrome workflow; fictional seed/source records |
| Fictional seed and local startup | PASS on this machine | Database create/migrate/seed, SQL schema-load, Rails/Vite boot and Start.ps1 launcher HTTP 200 |
| S01–S09 confirmation, recurrence/reschedule, provider failure, deduplication, conflicting/late intent and STOP | PASS automated | `backend/test/models/confirmation_flow_test.rb` |
| S10–S13 clinic isolation, follow-up, shared contacts and held minors | PASS automated | Model tests and `backend/test/controllers/workspace_controller_test.rb`; browser clinic switch |
| S14 empty source and STOP during unavailable source | PASS automated | Snapshot rollback and unavailable-source opt-out tests; stale prior state retained |
| S15 send/reply concurrency and clinic-local windows/DST | PASS automated | Real multi-connection model tests, repeated logical step and wall-time boundary assertions |
| S16–S17 confirmation versus completion and leadership privacy | PASS automated | Aggregate request tests; real browser leadership page |
| S18 appointment date/filter and clinic navigation | PASS browser | `frontend/e2e/demo.spec.ts` against actual Rails/database |
| S19 rejection/draft retention and pending form safety | PASS automated | Deferred-response React test checks pending controls and retained note after 422; server validates notes/revisions/request IDs |
| S20 SMS/email inbox paths | PASS automated and browser | Email confirmation model test; React Email empty/reply tests; real browser SMS confirmation/Email empty |
| Board search/type/pagination and assignment | Implemented; partially verified | Source plus browser follow-up/assignment ownership; no exhaustive many-page browser dataset test |
| Contact correction/provenance without PMS writes | PASS automated | Model correction/source-preservation assertions; source/current values and audit UI inspected |
| Three workspaces, broad visual identity and narrow entry layout | PASS browser/visual inspection | Five PNGs under `notes/evidence`; 390px no-horizontal-overflow assertion; no pixel-perfect or full accessibility certification |
| Seven configured quality categories | PASS | `notes/quality-results.txt`, 138.85s whole command |
| Real-backend browser smoke | PASS, 3 tests | `notes/browser-results.txt`, 33.6s runner / 43.77s whole command |
| Independent V4 review | Completed | `review/INDEPENDENT_REVIEW.md`; no unresolved Revise findings |
| README, architecture, AI record, candidate decision notes | Present/reviewed | Root documents and `notes/CANDIDATE_DECISION_NOTES.md` |
| Candidate's final personal DECISIONS.md and live defense | NOT RUN / human-owned | Agent did not fabricate candidate rationale |
| Production load, fresh-machine install, screen reader/zoom/long-value coverage | NOT RUN | Not inferred from current local checks |
| Live messaging, production auth/deployment/booking | Outside scope | Fake transport and local identity stub only |

The original baseline manifest covers mutable log/template files. Its Stage 0 pass establishes the extracted input's integrity; it is not a final application test and is not rebaselined to disguise documented development edits.
