﻿# V4 independent review

Review date: 2026-11-15. Scope: this clean-room V4 directory only. The repository is on `main`, has no remote and no HEAD commit; the initial application and harness are staged additions. Reviewed the staged application plus subsequent working-tree changes: pending-form correction, two additional Rails safety tests, info-level logging, Vitest single-thread worker configuration and CSS whitespace formatting. This report is not evidence of a commit, publication, production readiness or human acceptance.

Read the execution contract, AGENTS.md, assessment requirements, acceptance matrix, relevant behavior specification, both engineering guides, independent-review prompt and both evidence rubrics. Inspected all application models/controller, migrations, model/request tests, complete React screen/request implementation, interaction tests, real-backend smoke script, README, architecture and decision notes. No earlier implementation, sibling checkout, remote or memory was accessed.

## Findings

No unresolved **Revise** finding in the reviewed local-demo scope. One concrete issue was reported during review and corrected by the implementing agent:

- **Meets after correction — pending drafts.** `frontend/src/App.tsx:352` and `frontend/src/App.tsx:401` clear a submitted draft after accepted writes. Originally the outcome/note/reply controls remained editable during the request, allowing a newer unsaved draft to be erased by the earlier response. The smallest correction now disables the follow-up outcome (`:357`), follow-up note (`:361`) and reply body (`:404`) while pending. The correction was independently inspected. The extended interaction test and its execution are recorded below; a reviewer-only delayed HTTP browser probe was stopped before reaching an assertion and is not counted as proof.

## Rails evidence rubric

| Criterion | Status | Evidence and scope |
|---|---|---|
| Business cases | Meets | `ReminderRun.call`, `InboundReply.receive!` and `Appointment#record_follow_up!` visibly distinguish eligible sends, rejected/stale/ambiguous YES, STOP, human outcomes and provider failure. Model tests exercise current YES, moved/broken visits, late replies, shared contacts, minors, failure, cadence, repeated events and DST. |
| Proportion | Meets | Ordinary models own actual domain rules; one snapshot owner, a local deterministic transport and one aggregate report. No speculative worker, outbox, store or service framework. A real transport would require a different side-effect boundary, explicitly documented. |
| Dependencies and responsibilities | Meets | Controller handles scoped HTTP lookup and staff stub; Clinic owns source reconciliation/transaction; Patient owns contact eligibility; Appointment owns staff outcomes; InboundReply owns conservative command matching. These owners are directly called by the request/runner. |
| Call-site clarity | Meets | Named `now`, `staff`, `outcome`, `request_id`, notification and body arguments make tested call meanings clear. Provider returns accepted/failed, never delivered. |
| Request flow and scope | Meets | `backend/app/controllers/workspace_controller.rb` scopes patient, appointment and notification lookups through the selected clinic; request test rejects another clinic's records. Header selection is deliberately a demo stub, not authenticated membership. Leadership constructs aggregate-only fields; its request test excludes identifying values. |
| Persistence and side effects | Meets | `Clinic#with_snapshot` owns a repeatable-read transaction and clinic lock, with bounded concurrency retries. Source changes clear confirmation and advance revisions. Unique appointment/revision/step, inbound event and follow-up request keys enforce local idempotency. Runtime source records are read-only through PmsRecord; fake transport has no network effect. DB-level source grants remain outside this demo guarantee. |
| Behavioral evidence | Meets | Read the actual outcome assertions and consolidated log: 27 Rails tests, 103 assertions, zero failures/errors/skips; real multi-connection batch test included. Request tests cover scope, aggregate privacy, rejected/repeated follow-up and stale revisions. Reviewer did not rerun Rails while the shared test DB quality runner was active. |

## React / TypeScript evidence rubric

| Criterion | Status | Evidence and scope |
|---|---|---|
| Names and module boundaries | Meets | `frontend/src/App.tsx` follows entry, clinic workspace, desk/calendar, patient/contact/follow-up, inbox/reply and leadership responsibilities in one navigable file. `api.ts` contains shared request/types/date display. No extraction is needed solely to shorten the file. |
| Proportion and variants | Meets | Semantic table is reused for clinic and patient views; request transport and mutation feedback share actual behavior. No custom hook, global store or context is required for the present coordination. |
| State/rendering/record identity | Meets | Clinic/view changes remount ClinicWorkspace; patient details and message forms use stable record keys. Filtered counts/pages are derived. Pending draft controls now prevent the reported response-versus-edit race. |
| Async request identity | Meets | Clinic remount isolates old request state; read effects abort obsolete fetches. The stubbed-HTTP clinic-switch test intentionally resolves the old clinic last. Leadership clears the prior month while loading. Writes carry selected record/revision and stable draft identifiers. |
| API result and recovery | Meets | `api.ts` distinguishes rejection, network uncertainty and invalid JSON. Rejection retains draft; accepted-write notice is separate from refresh error. No automatic consequential write retry. Successful read bodies rely on this application's typed server contract; arbitrary malformed-success-payload tolerance was not established. |
| Accessible interactions | Meets | Native labeled controls, semantic tables, pressed filter buttons, status/alert feedback, keyboard-reachable controls and visible focus CSS. This is source/smoke evidence, not a full screen-reader certification. |
| Desktop layout | Meets | Independently viewed generated 1440px follow-up, inbox and leadership PNGs plus 390px workspace PNG. Main actions and labels are legible; table wrappers scroll. Unusual long values and browser zoom were not independently exercised. |
| Regression evidence | Meets | All three interaction tests pass in the final consolidated log (7.04 seconds). The held-response test asserts follow-up note/outcome disabled while pending, retained text after rejection and re-enabled input. These tests use stubbed HTTP, distinct from real-backend Playwright smoke; reply input disabling was independently inspected in source. |
| Performance changes | Outside scope | No measured frontend performance claim or optimization introduced. No 4,000/day benchmark was performed; batching/indexes are source observations, not throughput evidence. |

## Commands and runtime evidence

The reviewer executed local Git status/diff and complete source/test/document reads, independently inspected the four PNG artifacts, and read `notes/quality-results.txt`. No application files were edited by the reviewer. No Rails suite was launched concurrently with the implementing agent's test runner.

The final UTF-8 `notes/quality-results.txt`, independently read by this reviewer, records QUALITY GATE PASS: all seven configured checks succeeded in 138.85 seconds. Rails: 27 tests / 103 assertions, zero failures/errors/skips (23.978056 seconds); RuboCop: 41 files clean; Brakeman: zero warnings/errors; ESLint and TypeScript: pass; Vitest: three tests pass (7.04 seconds); production Vite build: pass (918 milliseconds). Added Rails assertions cover STOP during unavailable source plus later recipient reassignment, and concurrent duplicate inbound events. The reviewer read both added tests and final output but did not independently rerun the gate. An earlier Vitest fork-worker startup timeout was resolved by a single threads worker; it is not silently represented as an earlier behavior-test pass.

The implementing agent reported two real-Chrome Playwright tests passed in 37.5 seconds against the running Rails backend (follow-up persistence, clinic switch, simulated YES, Email empty state, leadership and 390px entry layout). The reviewer inspected both the test's real-backend call path and resulting screenshots, but did not independently rerun that smoke command. The pending-form correction occurred after those screenshots; its focused interaction regression is included in the final passing gate. The final UTF-8 `notes/browser-results.txt`, independently read by the reviewer along with the extended test source, records all three real-backend Chrome tests passed in 33.6 seconds (whole command 43.77 seconds). It includes follow-up persistence, clinic switch, simulated YES, Email empty state, aggregate leadership, the 390px entry layout and calendar day/state filters. This supersedes the earlier two-test smoke result; the reviewer read this execution evidence rather than rerunning the browser suite. Launcher HTTP 200 health was reported by the implementing agent; the reviewer did not independently rerun launcher setup.

## Remaining boundaries and candidate work

- **Meets:** final affected frontend checks after the pending-form fix, as recorded in the independently read consolidated log. Info-level logging configuration suppresses ordinary SQL debug-bind output; source inspection is not a comprehensive operational log audit.
- **Unverified:** candidate-owned `DECISIONS.md` and human acceptance. Its absence is deliberate: assignment requires the candidate's own writing. Existing notes honestly describe assumptions without impersonating that writing.
- **Unverified:** complete fresh-machine installation, long-value/zoom behavior and measured production-volume performance. Do not convert source inspection or today's local demo into these claims.
- **Outside scope:** live delivery, staff authentication, deployed source SELECT-only roles, real provider callback authentication, guardian authorization workflow, booking/rescheduling, infrastructure and causal no-show reduction. The README states these boundaries. No live-delivery assertion is supported.

Functional copy was reviewed in source and generated screens. Titles, labels, notices and instructions help navigation, explain state or identify next actions. Fake acceptance is distinguished from delivery and completion metrics explicitly avoid a no-show or causality claim. No promotional hero copy was added.
