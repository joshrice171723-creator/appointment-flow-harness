# V4 — React / TypeScript evidence-based review rubric

Use only in **V4's independent review stage**. Adapted from the user-provided frontend rubric without carrying over earlier application's API shapes or implementation hints. It does not assign numerical scores.

For each affected user workflow, trace: screen entry -> selected record -> state owner -> event -> HTTP outcome -> visible result. Mark applicable criteria **Meets**, **Revise**, **Unverified**, or **Outside scope**. Support deficiencies with file/line evidence and, when possible, a reproduced failing scenario.

| Criterion | Reviewer must establish | Typical evidence |
|---|---|---|
| Names and module boundaries | Operations, dependencies and responsibilities are legible | Imports, call sites, props/hook interface |
| Proportion and variants | Splits and shared code eliminate real repetition without hiding the behavior | Concrete callers, before/after trace |
| State/rendering/record identity | Editable state has one owner; derived state stays derived; keys preserve identity | Reordering, record switching and UI tests |
| Async request identity | Old read results cannot replace new selected data; writes affect correct record | Delayed/reordered requests, pending state trace |
| API result and recovery | Failure types and accepted-write/failed-refresh distinction are represented truthfully | Controlled HTTP failure and retry exercises |
| Accessible interactions | Labels, keyboard operations, feedback, and table semantics work | Keyboard/role tests, DOM inspection |
| Desktop layout | Main actions and information remain usable at relevant widths and zoom | Real browser/visual check with long values |
| Regression evidence | Tests assert independent visible behavior and distinguish mocked from real persistence | Playwright/component tests, server integration |
| Performance changes | Added complexity responds to a measured bottleneck | Comparable before/after measurements |

### Output

- Workflow, commit/revision and files inspected.
- One status per applicable row, with evidence.
- Findings: exact location, user impact, demonstrated vs unverified, minimal change.
- Actual browser/test environments and commands; missing checks noted.
- Do not demand unnecessary hooks, context, stores or abstractions as an aesthetic preference.

Source adaptation: user-provided `Frontend-Code-Quality-Rubric.md`, with links to unavailable old guide anchors, application-specific examples, and legacy grading removed.
