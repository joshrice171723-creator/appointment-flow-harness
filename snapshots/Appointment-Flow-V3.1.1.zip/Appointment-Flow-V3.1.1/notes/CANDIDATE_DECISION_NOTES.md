# Tradeoff notes for candidate's own DECISIONS.md

The assessment requires that the candidate write `DECISIONS.md` **personally in their own words**. Capture factual choices and alternatives here so the candidate can make their own narrative later. Agent must not claim authorship on their behalf.

- Assumption / ambiguity:
- What was chosen and why:
- Alternative considered and drawback:
- Risk / what would change with another week:
- Evidence (test/demo/measurement):
# Agent-generated notes for the candidate

These notes describe implementation choices. They are not Joshua's personal rationale or final DECISIONS.md.

- The official brief favors a smaller working system. Rails + PostgreSQL + a React app are sufficient; no Redis, background worker, global client store or live provider was added. A manually invoked runner makes cadence and results inspectable. A production scheduler would invoke the same operation.
- Replicated tables preserve the assessment's columns under `pms`. Runtime source models reject writes; local verification, confirmation and follow-up never change source. Database-level read-only privileges remain a production requirement.
- Clinic timezones are explicitly mapped, not inferred from a state abbreviation. Source wall times are converted using TZInfo; invalid/ambiguous DST times pause a snapshot. Internal instants are UTC.
- 7/3/1-day cadence plus day-6 email backup is chosen for the demo. Missed windows coalesce. Confirmed visits receive only final informational contact. The 10:00–18:00 window applies in clinic time.
- A YES confirms only an accepted attempt for the current source revision with an unambiguous eligible recipient and one upcoming visit. Other intent goes to staff. Source rescheduling invalidates confirmation. Staff can resolve an ambiguous reply after human clarification using the appointment-specific follow-up form.
- Unsupported languages, unverified age, minors without a guardian process, conflicting source/local contact and unsafe contacts are held. Minors remain held rather than inventing guardian authorization not supplied by the schema. Another week could add explicit authorization provenance and a narrow guardian workflow.
- Exact case-insensitive STOP persists by recipient and clinic even across future source/contact changes. Broad telecom compliance is not claimed. A real callback must verify provider signatures and identity; the patient picker is a simulator only.
- Clinic transactions and unique keys protect local effects. Concurrent repeatable-read snapshots can lose a race; a bounded retry restarts the transaction. A real external provider needs an outbox and uncertain-outcome reconciliation rather than assuming a DB rollback undoes a send.
- Confirmation and PMS outcomes are different facts. Leadership counts source outcomes after visit start, with completed / recorded visits as denominator. Seed data cannot show causal no-show reduction.
- Demo headers scope records but are not authentication. A production week should prioritize authenticated clinic memberships, role-specific data endpoints, source SELECT-only grants, callback verification and privacy-aware operational logging.
- Decide personally which remaining limitations matter most, what vendor you would evaluate and why, and what you would change with another week. Do not submit these AI-authored notes as your own judgment.
