# Build log — generated only from actual work

The agent should append factual, dated entries: requirements addressed, test commands + actual output, meaningful choices, and blockers. Never insert fictional results or commit hashes.
# Fresh build, 2026-11-15

Stage 0: read complete instructions, official assessment, product specifications, engineering guides, and screenshot references. Integrity check passed with ten PNGs including the empty Email tab. No previous repositories or project memory consulted. The interrupted build was removed before this run; no application files existed on entry. Existing Git main has no commits or remote, so no upstream synchronization is possible.

Plan: Rails API, React/TypeScript, PostgreSQL. Separate replicated PMS tables from locally owned patient verification, appointment revisions, confirmation, outreach and follow-up records. Clinic locks and database constraints protect concurrency. Read source consistently before any outreach; reject incomplete/empty snapshots. Clinic timezone mapping is explicit. Manual reminder batches at 7/3/1 days with day-6 email backup; no catch-up burst. Conservative contact holds and ambiguous-reply review. Three workspaces with functional copy and broad screenshot styling.

Slices: persistence and source synchronization; reminder/reply rules and safety tests; functional UI and UI tests; quality runner and runtime checks; separate V4 rubric reviewer; documented fixes and freeze. Final DECISIONS.md remains human-owned.

Available prerequisites: Ruby 3.4.10, Rails 8.1.3.1, Node 24.22.1, npm 11.19.1, PostgreSQL 17.11 at localhost:5443. Database names will be unique to this project. No live provider or external deployment.

## Implementation and verification

- B02–B05, S01–S17: implemented source snapshot/revision ownership, recipient verification/holds, local-time cadence, fake attempts, conservative inbound matching and durable clinic/recipient STOP. Source writes are confined to setup/tests. Concurrency test exposed a repeatable-read uniqueness race; bounded retries now handle serialization and uniqueness conflicts. Added concurrent inbound-event coverage and STOP during source failure/recipient reassignment.
- B01/B06–B10, S18–S20: implemented three clinic-scoped workspaces, follow-up/assignment, local corrections with raw source values, calendar/filter/table, simulated SMS/email history/replies, aggregate-only month reporting. React tests distinguish stubbed HTTP from real-backend browser evidence.
- First completed Rails pass: 25 tests/97 assertions, 0 failures/errors/skips, 21.18 seconds test runtime. Focused concurrent-send regression: 1 test/3 assertions pass. Subsequent final run includes 27 tests/103 assertions and has passed that category (23.98 seconds); complete gate result is recorded separately.
- Dependency setup: generated TypeScript 7 conflicted with typescript-eslint's supported range; installed compatible TypeScript 6.0.3. PostgreSQL SQL dump needed clean/if-exists flags for public+pms schemas. Test fixture source clinic rows were corrected after their foreign-key failures. Original baseline integrity manifest is retained; editing build logs/templates intentionally changes mutable baseline hashes.
- Initial consolidated gate passed Rails, RuboCop (41 files), Brakeman (0 warnings), ESLint, TypeScript and build; Vitest failed before executing tests with a worker-startup timeout. A minimal worker probe passed, jsdom imported successfully, and the actual three frontend tests then passed in 7.24 seconds using one thread worker. Diagnostic-only probe was removed. The full gate is rerunning without concurrent browser work.
- Separate V4 reviewer inspected both rubrics/current implementation, found pending-save draft-loss risk, and confirmed the minimal fix: disable note/outcome/reply editing while pending. The existing rejection test now intentionally holds the response and checks disabled controls, retained draft and re-enabled controls after rejection. No unresolved Revise finding reported.
- Browser proof before final rerun: two real-Chrome tests passed in 37.5 seconds, including persistent follow-up, clinic switch, Phoenix YES, Email empty, leadership, and 390px layout. Generated PNGs were visually inspected. Added a real calendar date/filter check for final smoke.
- Start.ps1 syntax passed; both processes were restarted through that launcher and responded HTTP 200 on Rails /up and the frontend. PostgreSQL seed/migrate/schema-load commands executed on this machine. A complete fresh-machine setup is not claimed.
- Runtime npm audit (omit dev): 0 vulnerabilities. Full audit found seven moderate development-tool findings from typescript-eslint's minimatch dependency; no forced dependency override was applied. No production-volume benchmark or human acceptance performed.

## Final checks

Final `python quality/run_checks.py`: PASS all seven configured categories, whole command 138.85 seconds. Rails 27 tests/103 assertions, 0 failures/errors/skips in 23.978056 seconds. RuboCop 41 files clean; Brakeman 0 warnings/errors; ESLint/strict TypeScript pass; React 3 tests pass in 7.04 seconds, including reviewer-fix regression; build pass in 918ms. Actual log: `notes/quality-results.txt`.

Final real-backend Chrome smoke: PASS 3 tests in 33.6 seconds, whole command 43.77 seconds. Added appointment date/state filtering passed alongside existing workflows and 390px test. Actual log: `notes/browser-results.txt`. Screenshots inspected for functional copy/layout, including the appointment table. Start.ps1-launched Rails /up and Vite root both returned HTTP 200. No app changes after these checks; final documentation/freeze records only.
