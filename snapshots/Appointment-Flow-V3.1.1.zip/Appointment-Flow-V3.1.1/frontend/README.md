# React frontend

See the repository-root README.md for setup and tests. Vite binds to 127.0.0.1:5174 and proxies /api to Rails on port 3040. Browser smoke checks require both servers and local Chrome.
