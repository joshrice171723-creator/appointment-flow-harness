export type Clinic = { id: number; name: string; timezone: string; synced_at: string | null; sync_error: string | null }
export type Facts = { birthdate: string; wireless_phone: string; email: string; preferred_language: string }
export type Patient = {
  id: number;
  name: string;
  source: Facts;
  facts: Facts;
  verified: boolean;
  sms_consent: boolean;
  email_consent: boolean;
  sms_opted_out: boolean;
  hold: string | null
}
export type Appointment = {
  id: number;
  patient_id: number;
  name: string;
  pms_id: number;
  revision: number;
  starts_at: string;
  wall_time: string;
  source_status: string;
  provider: string;
  confirmed_at: string | null;
  staff_outcome: string | null;
  owner: string | null;
  concern: string | null;
  reply_review: boolean;
  work_status: string
}
export type Notification = {
  id: number;
  appointment_id: number;
  revision: number;
  channel: string;
  body: string;
  status: string;
  created_at: string;
  replies: { id: number; body: string; result: string; created_at: string }[]
}
export type FollowUp = {
  id: number;
  appointment_id: number;
  staff: string;
  outcome: string;
  note: string;
  created_at: string
}
export type Workspace = {
  clinic: Clinic;
  patients: Patient[];
  appointments: Appointment[];
  notifications: Notification[];
  follow_ups: FollowUp[];
  contact_reviews: { id: number; patient_id: number; staff: string; created_at: string }[]
}
export type Report = {
  clinic: string;
  recorded: number;
  completed: number;
  rescheduled: number;
  canceled: number;
  unknown: number;
  completion_rate: number | null;
  attempts: number;
  failed: number;
  replies: number;
  confirmations: number;
  open_holds: number;
  follow_ups: number
}

export async function request<T>(path: string, options: {
  clinic?: number;
  staff?: string;
  body?: object;
  signal?: AbortSignal
} = {}): Promise<T> {
  let response: Response
  try {
    response = await fetch(`/api/${path}`, {
      method: options.body ? 'POST' : 'GET', signal: options.signal,
      headers: {'Content-Type': 'application/json', ...(options.clinic ? {'X-Clinic-Id': String(options.clinic)} : {}), ...(options.staff ? {'X-Staff-Name': options.staff} : {})},
      body: options.body ? JSON.stringify(options.body) : undefined,
    })
  } catch (error) {
    if (options.signal?.aborted) throw error
    throw new Error(options.body ? 'Request outcome uncertain. Refresh to check before submitting again. Your draft is retained.' : 'Could not reach the server. Try refreshing.')
  }
  const result: unknown = await response.json().catch(() => {
    throw new Error('Invalid server response. Refresh to check the current state.')
  })
  if (!response.ok) throw new Error(typeof result === 'object' && result && 'error' in result ? String(result.error) : `Request rejected (${response.status})`)
  return result as T
}

export function localTime(value: string, zone: string) {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: zone,
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(new Date(value))
}
