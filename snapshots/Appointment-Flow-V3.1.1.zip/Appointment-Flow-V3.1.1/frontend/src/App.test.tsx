import {afterEach, describe, expect, it, vi} from 'vitest'
import {fireEvent, render, screen, waitFor} from '@testing-library/react'
import App from './App'
import type {Workspace} from './api'

const clinics = [{id: 1, name: 'Austin', timezone: 'America/Chicago', synced_at: null, sync_error: null}, {
  id: 2,
  name: 'Phoenix',
  timezone: 'America/Phoenix',
  synced_at: null,
  sync_error: null
}]

function data(id = 1): Workspace {
  const patient = {
    id,
    name: id === 1 ? 'Avery Demo' : 'Quinn Demo',
    facts: {
      birthdate: '1988-01-01',
      wireless_phone: '+15125550101',
      email: 'avery@example.test',
      preferred_language: 'en'
    },
    source: {
      birthdate: '1988-01-01',
      wireless_phone: '+15125550101',
      email: 'avery@example.test',
      preferred_language: 'en'
    },
    verified: true,
    sms_consent: true,
    email_consent: true,
    sms_opted_out: false,
    hold: null
  }
  return {
    clinic: clinics[id - 1],
    patients: [patient],
    appointments: [{
      id,
      patient_id: id,
      name: patient.name,
      pms_id: id,
      revision: 1,
      starts_at: '2026-11-22T21:00:00Z',
      wall_time: '2026-11-22 15:00:00',
      source_status: 'scheduled',
      provider: 'Dr. Demo',
      confirmed_at: null,
      staff_outcome: null,
      owner: null,
      concern: 'No reply',
      reply_review: false,
      work_status: 'Needs attention'
    }],
    notifications: [{
      id,
      appointment_id: id,
      revision: 1,
      channel: 'sms',
      body: 'Reply YES to confirm',
      status: 'accepted',
      created_at: '2026-11-15T18:00:00Z',
      replies: []
    }],
    follow_ups: [],
    contact_reviews: []
  }
}

function json(value: unknown, status = 200) {
  return new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}})
}

afterEach(() => vi.unstubAllGlobals())

describe('workspace behavior with a stubbed HTTP backend', () => {
  it('clinic switch keeps an obsolete response from exposing the previous clinic', async () => {
    let finishAustin: ((response: Response) => void) | undefined
    vi.stubGlobal('fetch', vi.fn((url: string, options?: RequestInit) => {
      if (url.endsWith('clinics')) return Promise.resolve(json(clinics))
      const headers = options?.headers as Record<string, string>
      if (headers['X-Clinic-Id'] === '1') return new Promise<Response>(resolve => {
        finishAustin = resolve
      })
      return Promise.resolve(json(data(2)))
    }))
    render(<App/>)
    await waitFor(() => expect(screen.getByRole('button', {name: /Open front desk/})).toBeEnabled())
    fireEvent.click(screen.getByRole('button', {name: /Open front desk/}))
    fireEvent.change(screen.getByLabelText('Clinic'), {target: {value: '2'}})
    expect(await screen.findByRole('button', {name: /Quinn Demo/})).toBeVisible()
    finishAustin?.(json(data(1)))
    await waitFor(() => expect(screen.queryByText(/Avery Demo/)).not.toBeInTheDocument())
  })

  it('rejected follow-up retains the note and displays the rejection', async () => {
    let rejectSave: ((response: Response) => void) | undefined
    vi.stubGlobal('fetch', vi.fn((url: string) => {
      if (url.endsWith('follow_up')) return new Promise<Response>(resolve => { rejectSave = resolve })
      return Promise.resolve(url.endsWith('clinics') ? json(clinics) : json(data()))
    }))
    render(<App/>)
    await waitFor(() => expect(screen.getByRole('button', {name: /Open front desk/})).toBeEnabled())
    fireEvent.click(screen.getByRole('button', {name: /Open front desk/}))
    fireEvent.click(await screen.findByRole('button', {name: /Avery Demo/}))
    fireEvent.change(screen.getByLabelText('Follow-up note'), {target: {value: 'Patient asked for a callback'}})
    fireEvent.click(screen.getByRole('button', {name: 'Record follow-up'}))
    expect(screen.getByLabelText('Follow-up note')).toBeDisabled()
    expect(screen.getByLabelText('Outcome')).toBeDisabled()
    rejectSave?.(json({error: 'Appointment changed; refresh before saving'}, 422))
    expect(await screen.findByRole('alert')).toHaveTextContent('Appointment changed')
    expect(screen.getByLabelText('Follow-up note')).toHaveValue('Patient asked for a callback')
    expect(screen.getByLabelText('Follow-up note')).toBeEnabled()
  })

  it('email empty state and SMS reply use the same simulated-reply endpoint', async () => {
    const fetch = vi.fn((url: string) => Promise.resolve(url.endsWith('clinics') ? json(clinics) : url.endsWith('replies') ? json({status: 'Confirmed'}) : json(data())))
    vi.stubGlobal('fetch', fetch)
    render(<App/>)
    await waitFor(() => expect(screen.getByRole('button', {name: /Open patient workspace/})).toBeEnabled())
    fireEvent.click(screen.getByRole('button', {name: /Open patient workspace/}))
    fireEvent.change(await screen.findByLabelText('Patient'), {target: {value: '1'}})
    fireEvent.click(screen.getByRole('button', {name: 'Email'}))
    expect(screen.getByText(/No simulated emails/)).toBeVisible()
    fireEvent.click(screen.getByRole('button', {name: 'Text messages'}))
    fireEvent.change(screen.getByLabelText('Your reply'), {target: {value: 'YES'}})
    fireEvent.click(screen.getByRole('button', {name: 'Send simulated reply'}))
    expect(await screen.findByRole('status')).toHaveTextContent('Confirmed')
    expect(fetch.mock.calls.some(call => call[0] === '/api/notifications/1/replies')).toBe(true)
  })
})
