import {useEffect, useRef, useState} from 'react'
import type {FormEvent} from 'react'
import {localTime, request} from './api'
import type {Appointment, Clinic, Facts, Patient, Report, Workspace} from './api'
import './App.css'

type View = 'workspaces' | 'desk' | 'patient' | 'leadership'
const staffNames = ['Taylor Morgan', 'Alex Chen']
const outcomes: Record<string, string> = {
  complete: 'Completed',
  broken: 'Canceled',
  unscheduled: 'Rescheduled',
  scheduled: 'Unknown',
  missing: 'Missing from source'
}

export default function App() {
  const [clinics, setClinics] = useState<Clinic[]>([])
  const [error, setError] = useState('')
  const [view, setView] = useState<View>('workspaces')
  const [clinic, setClinic] = useState(1)
  const [staff, setStaff] = useState(staffNames[0])
  useEffect(() => {
    const controller = new AbortController()
    request<Clinic[]>('clinics', {signal: controller.signal}).then(setClinics).catch(error => {
      if (!controller.signal.aborted) setError(String(error.message))
    })
    return () => controller.abort()
  }, [])
  return <>
    <header><a className="brand" href="#" onClick={() => setView('workspaces')}><span>A↗</span>
      <div>APEX<small>APPOINTMENT FLOW</small></div>
    </a>
      <nav>
        <button onClick={() => setView('workspaces')}>Workspaces ↗</button>
      </nav>
    </header>
    <main>{error && <p role="alert">{error}</p>}
      {view === 'workspaces' && <><h1>Workspaces</h1>
        <div className="entry-grid">
          <section className="card entry"><h2>Front desk</h2><p>Review appointments and record patient follow-up.</p>
            <label>Clinic<select value={clinic}
                                 onChange={event => setClinic(Number(event.target.value))}>{clinics.map(item => <option
              value={item.id} key={item.id}>{item.name}</option>)}</select></label>
            <label>Staff member · demo sign-in<select value={staff}
                                                      onChange={event => setStaff(event.target.value)}>{staffNames.map(name =>
              <option key={name}>{name}</option>)}</select></label>
            <button className="primary" disabled={!clinics.length} onClick={() => setView('desk')}>Open front desk →
            </button>
          </section>
          <section className="card entry tinted"><h2>Apex leadership</h2><p>Clinic outcomes and aggregate activity.</p>
            <strong className="large">{clinics.length}</strong><p>Reporting clinics</p>
            <button className="primary" onClick={() => setView('leadership')}>Open Apex leadership →</button>
          </section>
          <section className="card entry"><h2>Patient demo</h2><p>Inspect fake messages and simulate replies. No live
            delivery.</p>
            <button className="primary" disabled={!clinics.length} onClick={() => setView('patient')}>Open patient
              workspace →
            </button>
          </section>
        </div>
      </>}
      {(view === 'desk' || view === 'patient') && <>
        <div className="toolbar"><label>Clinic<select value={clinic}
                                                      onChange={event => setClinic(Number(event.target.value))}>{clinics.map(item =>
          <option key={item.id}
                  value={item.id}>{item.name}</option>)}</select></label><span>{view === 'desk' ? `${staff} · demo staff identity` : 'Fictional patient inbox'}</span>
        </div>
        <ClinicWorkspace key={`${view}-${clinic}`} clinicId={clinic} staff={staff} mode={view}/></>}
      {view === 'leadership' && <Leadership/>}
    </main>
  </>
}

function ClinicWorkspace({clinicId, staff, mode}: { clinicId: number; staff: string; mode: 'desk' | 'patient' }) {
  const [data, setData] = useState<Workspace | null>(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [pending, setPending] = useState(false)
  const [reload, setReload] = useState(0)
  useEffect(() => {
    const controller = new AbortController()
    request<Workspace>('workspace', {clinic: clinicId, signal: controller.signal}).then(result => {
      setData(result);
      setError('')
    }).catch(error => {
      if (!controller.signal.aborted) setError(error.message)
    })
    return () => controller.abort()
  }, [clinicId, reload])

  async function mutate(path: string, body: object) {
    setPending(true);
    setError('');
    setNotice('')
    try {
      const result = await request<{ status: string }>(path, {clinic: clinicId, staff, body})
      setNotice(result.status);
      setReload(value => value + 1)
      return true
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Request failed');
      return false
    } finally {
      setPending(false)
    }
  }

  return <>{notice && <p className="notice" role="status">{notice}</p>}{error && <p role="alert">{error}</p>}
    <div className="toolbar">
      <button onClick={() => setReload(value => value + 1)}>Refresh data</button>
      {mode === 'desk' &&
        <button disabled={pending || !data} onClick={() => void mutate('reminders', {})}>Run fake reminders</button>}
    </div>
    {!data ? <p role="status">Loading clinic records…</p> : <><p className="muted">Last successful PMS
      sync: {data.clinic.synced_at ? localTime(data.clinic.synced_at, data.clinic.timezone) : 'Not yet synced'} · {data.clinic.timezone}</p>{data.clinic.sync_error &&
      <p role="alert">{data.clinic.sync_error}</p>}
      {mode === 'desk' ? <FrontDesk data={data} mutate={mutate} pending={pending}/> :
        <Inbox data={data} mutate={mutate} pending={pending}/>}</>}
  </>
}

type Mutation = (path: string, body: object) => Promise<boolean>

function FrontDesk({data, mutate, pending}: { data: Workspace; mutate: Mutation; pending: boolean }) {
  const [tab, setTab] = useState('Patient flow')
  const [selected, setSelected] = useState<number | null>(null)
  const patient = data.patients.find(patient => patient.id === selected)
  return <>
    <div className="tabs">{['Patient flow', 'Appointments'].map(name => <button aria-pressed={tab === name} key={name}
                                                                                onClick={() => {
                                                                                  setTab(name);
                                                                                  setSelected(null)
                                                                                }}>{name}</button>)}</div>
    {patient ? <PatientDetails key={patient.id} patient={patient} data={data} mutate={mutate} pending={pending}
                               back={() => setSelected(null)}/> : <><h1>{tab}</h1>{tab === 'Patient flow' ?
      <Board data={data} open={setSelected}/> : <Calendar data={data} open={setSelected}/>}</>}
  </>
}

function Board({data, open}: { data: Workspace; open: (id: number) => void }) {
  const [search, setSearch] = useState('')
  const [type, setType] = useState('All')
  const [resolved, setResolved] = useState(false)
  const [page, setPage] = useState(0)
  const work = data.appointments.filter(item => item.concern || item.reply_review || item.owner || item.confirmed_at || item.staff_outcome)
  const filtered = work.filter(item => (resolved ? item.work_status === 'Resolved' : item.work_status !== 'Resolved') && item.name.toLowerCase().includes(search.toLowerCase()) && (type === 'All' || (type === 'Replies' ? item.reply_review : item.concern?.includes(type))))
  const pages = Math.max(1, Math.ceil(filtered.length / 10))
  const current = Math.min(page, pages - 1)
  const rows = filtered.slice(current * 10, current * 10 + 10)
  return <>
    <div className="summary">{['Needs attention', 'In progress', 'Resolved'].map(status => <section className="card"
                                                                                                    key={status}>
      <p>{status}</p><strong className="large">{work.filter(item => item.work_status === status).length}</strong>
    </section>)}</div>
    <div className="toolbar">
      <button aria-pressed={!resolved} onClick={() => {
        setResolved(false);
        setPage(0)
      }}>Active work
      </button>
      <button aria-pressed={resolved} onClick={() => {
        setResolved(true);
        setPage(0)
      }}>Resolved
      </button>
      <label>Find a patient<input value={search} onChange={event => {
        setSearch(event.target.value);
        setPage(0)
      }}/></label><label>Follow-up type<select value={type} onChange={event => {
      setType(event.target.value);
      setPage(0)
    }}>{['All', 'Replies', 'contact', 'Delivery failed', 'No reply'].map(value => <option
      key={value}>{value}</option>)}</select></label></div>
    {!rows.length && <p>No matching follow-up items.</p>}
    <div className="board">{(resolved ? ['Resolved'] : ['Needs attention', 'In progress']).map(status => <section
      className="queue" key={status}><h2>{status}</h2>{rows.filter(item => item.work_status === status).map(item =>
      <article className="card work" key={item.id}><span
        className="pill">{item.reply_review ? 'Reply needs review' : item.concern || 'Confirmed'}</span>
        <h3>
          <button className="text-button" onClick={() => open(item.patient_id)}>{item.name} ↗</button>
        </h3>
        <p>{localTime(item.starts_at, data.clinic.timezone)}</p><p>{item.owner || 'Unassigned'}</p></article>)}
    </section>)}</div>
    <div className="toolbar"><p>{filtered.length} matching work items · Page {current + 1} of {pages}</p>
      <button disabled={current === 0} onClick={() => setPage(current - 1)}>Previous</button>
      <button disabled={current + 1 >= pages} onClick={() => setPage(current + 1)}>Next</button>
    </div>
  </>
}

function Calendar({data, open}: { data: Workspace; open: (id: number) => void }) {
  const [date, setDate] = useState(new Intl.DateTimeFormat('en-CA', {timeZone: data.clinic.timezone}).format(new Date()))
  const [filter, setFilter] = useState('All')

  function shift(days: number) {
    const next = new Date(`${date}T12:00:00Z`);
    next.setUTCDate(next.getUTCDate() + days);
    setDate(next.toISOString().slice(0, 10))
  }

  const weekStart = new Date(`${date}T12:00:00Z`)
  weekStart.setUTCDate(weekStart.getUTCDate() - (weekStart.getUTCDay() + 6) % 7)
  const week = Array.from({length: 7}, (_, index) => {
    const day = new Date(weekStart);
    day.setUTCDate(day.getUTCDate() + index);
    return day.toISOString().slice(0, 10)
  })
  const rows = data.appointments.filter(item => item.wall_time.startsWith(date) && (filter === 'All' || (filter === 'Confirmed' ? item.confirmed_at : filter === 'Unconfirmed' ? !item.confirmed_at : item.reply_review)))
  return <>
    <section className="card">
      <div className="toolbar">
        <button onClick={() => shift(-7)}>← Previous week</button>
        <button
          onClick={() => setDate(new Intl.DateTimeFormat('en-CA', {timeZone: data.clinic.timezone}).format(new Date()))}>Today
        </button>
        <button onClick={() => shift(7)}>Next week →</button>
        <label>Jump to date<input type="date" value={date} onChange={event => {
          if (event.target.value) setDate(event.target.value)
        }}/></label></div>
      <div className="week">{week.map(day => <button key={day} aria-pressed={day === date}
                                                     onClick={() => setDate(day)}>{day.slice(5)}<small>{data.appointments.filter(item => item.wall_time.startsWith(day)).length} visits</small>
      </button>)}</div>
    </section>
    <div className="tabs">{['All', 'Confirmed', 'Unconfirmed', 'Replies to review'].map(value => <button
      aria-pressed={filter === value} key={value} onClick={() => setFilter(value)}>{value}</button>)}</div>
    <AppointmentTable rows={rows} zone={data.clinic.timezone} open={open}/></>
}

function AppointmentTable({rows, zone, open}: { rows: Appointment[]; zone: string; open: (id: number) => void }) {
  return <div className="card table-scroll">
    <table>
      <thead>
      <tr>
        <th>Patient</th>
        <th>Appointment · {zone}</th>
        <th>Confirmation or reply</th>
        <th>PMS outcome</th>
        <th>Follow-up</th>
      </tr>
      </thead>
      <tbody>{rows.map(item => <tr key={item.id}>
        <td>
          <button className="text-button" onClick={() => open(item.patient_id)}>{item.name}</button>
        </td>
        <td>{localTime(item.starts_at, zone)}<small>{item.provider} · #{item.pms_id} · revision {item.revision}</small>
        </td>
        <td>{item.confirmed_at ? 'Confirmed' : 'Unconfirmed'}{item.reply_review &&
          <small>Reply needs review</small>}</td>
        <td>{outcomes[item.source_status] || 'Unknown'}{item.staff_outcome &&
          <small>Staff recorded: {item.staff_outcome}</small>}</td>
        <td>{item.concern || 'No open concern'}</td>
      </tr>)}</tbody>
    </table>
    {!rows.length && <p>No appointments match this date and filter.</p>}</div>
}

function PatientDetails({patient, data, mutate, pending, back}: {
  patient: Patient;
  data: Workspace;
  mutate: Mutation;
  pending: boolean;
  back: () => void
}) {
  const [tab, setTab] = useState('Follow-up')
  const appointments = data.appointments.filter(item => item.patient_id === patient.id)
  return <>
    <button onClick={back}>← Patient flow</button>
    <h1>{patient.name}</h1>
    <p>{patient.hold || 'Contact details reviewed'}{patient.sms_opted_out && ' · SMS opted out'}</p>
    <div className="patient-layout">
      <aside className="card"><h2>Patient details</h2><ContactForm patient={patient} mutate={mutate} pending={pending}/>
      </aside>
      <section>
        <div className="tabs">{['Follow-up', 'Appointments', 'Activity log'].map(value => <button key={value}
                                                                                                  aria-pressed={tab === value}
                                                                                                  onClick={() => setTab(value)}>{value}</button>)}</div>
        {tab === 'Follow-up' && appointments.map(item => <section className="card" key={item.id}><h2>Appointment
          #{item.pms_id}</h2><p>{localTime(item.starts_at, data.clinic.timezone)} · {item.work_status}</p>
          <p>{item.concern || (item.confirmed_at ? 'Confirmed' : 'No open concern')}</p>
          <p>Owner: {item.owner || 'Unassigned'}</p>
          <button disabled={pending} onClick={() => void mutate(`appointments/${item.id}/assign`, {})}>Assign to me
          </button>
          <FollowUpForm appointment={item} mutate={mutate} pending={pending}/>
          <details>
            <summary>Follow-up history</summary>
            {data.follow_ups.filter(follow => follow.appointment_id === item.id).map(follow => <p
              key={follow.id}>{follow.staff} · {follow.outcome} · {follow.note}</p>)}</details>
        </section>)}
        {tab === 'Appointments' &&
          <AppointmentTable rows={appointments} zone={data.clinic.timezone} open={() => setTab('Follow-up')}/>}
        {tab === 'Activity log' && <section className="card"><h2>Activity
          log</h2>{data.contact_reviews.filter(review => review.patient_id === patient.id).map(review => <p
          key={`contact-${review.id}`}>{localTime(review.created_at, data.clinic.timezone)} · Contact verified
          by {review.staff}</p>)}{data.notifications.filter(message => appointments.some(item => item.id === message.appointment_id)).map(message =>
          <article key={message.id}>
            <p>Fake {message.channel} · {message.status} · {localTime(message.created_at, data.clinic.timezone)}</p>{message.replies.map(reply =>
            <p key={reply.id}>Reply: {reply.body} · {reply.result}</p>)}</article>)}</section>}
      </section>
    </div>
  </>
}

function ContactForm({patient, mutate, pending}: { patient: Patient; mutate: Mutation; pending: boolean }) {
  const [values, setValues] = useState({
    ...patient.facts,
    sms_consent: patient.sms_consent,
    email_consent: patient.email_consent
  })
  const labels: Record<keyof Facts, string> = {
    birthdate: 'Birthdate',
    wireless_phone: 'Mobile phone',
    email: 'Email',
    preferred_language: 'Preferred language (en or es)'
  }
  return <form onSubmit={event => {
    event.preventDefault();
    void mutate(`patients/${patient.id}/verify`, {values})
  }}>
    <p>{patient.verified ? 'Locally verified' : 'Not verified'}</p>{(Object.keys(labels) as (keyof Facts)[]).map(field =>
    <label key={field}>{labels[field]}<input type={field === 'birthdate' ? 'date' : 'text'} value={values[field] || ''}
                                             onChange={event => setValues({
                                               ...values,
                                               [field]: event.target.value
                                             })}/><small>PMS: {patient.source[field] || 'No value on file'}</small></label>)}{(['sms_consent', 'email_consent'] as const).map(field =>
    <label className="check" key={field}><input type="checkbox" checked={values[field]} onChange={event => setValues({
      ...values,
      [field]: event.target.checked
    })}/>Permission for {field === 'sms_consent' ? 'SMS' : 'email'}</label>)}<p className="muted">Corrections stay
    local. SMS STOP remains in effect.</p>
    <button className="primary" disabled={pending}>Verify contact details</button>
  </form>
}

function FollowUpForm({appointment, mutate, pending}: {
  appointment: Appointment;
  mutate: Mutation;
  pending: boolean
}) {
  const [note, setNote] = useState('')
  const [outcome, setOutcome] = useState('attempted')
  const requestId = useRef(crypto.randomUUID())

  async function save(event: FormEvent) {
    event.preventDefault()
    if (await mutate(`appointments/${appointment.id}/follow_up`, {
      note,
      outcome,
      revision: appointment.revision,
      request_id: requestId.current
    })) {
      setNote('');
      requestId.current = crypto.randomUUID()
    }
  }

  return <form onSubmit={event => void save(event)}><label>Outcome<select disabled={pending} value={outcome} onChange={event => {
    setOutcome(event.target.value);
    requestId.current = crypto.randomUUID()
  }}>{[['attempted', 'Contact attempted'], ['confirmed', 'Confirmed by staff'], ['rescheduled', 'Rescheduled in PMS'], ['canceled', 'Canceled in PMS'], ['reviewed', 'Reply reviewed with patient']].map(([value, label]) =>
    <option value={value} key={value}>{label}</option>)}</select></label><label>Follow-up note<textarea disabled={pending} required
                                                                                                        maxLength={2000}
                                                                                                        value={note}
                                                                                                        onChange={event => {
                                                                                                          setNote(event.target.value);
                                                                                                          requestId.current = crypto.randomUUID()
                                                                                                        }}/></label>
    <button disabled={pending}>Record follow-up</button>
  </form>
}

function Inbox({data, mutate, pending}: { data: Workspace; mutate: Mutation; pending: boolean }) {
  const [patientId, setPatientId] = useState('')
  const [channel, setChannel] = useState('sms')
  const appointments = data.appointments.filter(item => item.patient_id === Number(patientId))
  const messages = data.notifications.filter(message => message.channel === channel && appointments.some(item => item.id === message.appointment_id))
  return <div className="inbox"><h1>Patient inbox</h1><label>Patient<select value={patientId}
                                                                            onChange={event => setPatientId(event.target.value)}>
    <option value="">Choose a patient</option>
    {data.patients.map(patient => <option key={patient.id} value={patient.id}>{patient.name}</option>)}
  </select></label>{patientId && <>
    <div className="tabs">{[['sms', 'Text messages'], ['email', 'Email']].map(([value, label]) => <button key={value}
                                                                                                          aria-pressed={channel === value}
                                                                                                          onClick={() => setChannel(value)}>{label}</button>)}</div>
    <h2>Message history</h2>{!messages.length &&
    <p>No simulated {channel === 'sms' ? 'text messages' : 'emails'} for this patient yet.</p>}{messages.map(message =>
    <article className="bubble" key={message.id}>
      <small>Fake {message.channel} · {message.status} · {localTime(message.created_at, data.clinic.timezone)}</small>
      <p>{message.body}</p>{message.replies.map(reply => <blockquote key={reply.id}><p>{reply.body}</p>
      <small>{reply.result}</small></blockquote>)}<ReplyForm key={`${patientId}-${message.id}`}
                                                             notificationId={message.id} mutate={mutate}
                                                             pending={pending}/></article>)}</>}</div>
}

function ReplyForm({notificationId, mutate, pending}: { notificationId: number; mutate: Mutation; pending: boolean }) {
  const [body, setBody] = useState('')
  const eventId = useRef(crypto.randomUUID())
  return <form onSubmit={async event => {
    event.preventDefault();
    if (await mutate(`notifications/${notificationId}/replies`, {body, event_id: eventId.current})) {
      setBody('');
      eventId.current = crypto.randomUUID()
    }
  }}><label>Your reply<textarea disabled={pending} required maxLength={2000} value={body} onChange={event => {
    setBody(event.target.value);
    eventId.current = crypto.randomUUID()
  }}/></label>
    <button disabled={pending}>Send simulated reply</button>
  </form>
}

function Leadership() {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7))
  const [report, setReport] = useState<Report[] | null>(null)
  const [error, setError] = useState('')
  useEffect(() => {
    const controller = new AbortController()
    request<Report[]>(`leadership?month=${month}`, {signal: controller.signal}).then(result => {
      setReport(result);
      setError('')
    }).catch(error => {
      if (!controller.signal.aborted) setError(error.message)
    })
    return () => controller.abort()
  }, [month])
  return <><h1>Appointment outcomes</h1><label>Outcome month<input type="month" value={month} onChange={event => {
    if (event.target.value) {
      setReport(null);
      setMonth(event.target.value)
    }
  }}/></label><p>Completed / recorded visits whose appointment time has passed. These outcomes do not establish no-shows
    or reminder effectiveness.</p>{error && <p role="alert">{error}</p>}{!report ? <p>Loading report…</p> : <>
    <div className="summary">{report.map(row => <section className="card" key={row.clinic}><h2>{row.clinic}</h2><strong
      className="large">{row.completion_rate === null ? '—' : `${row.completion_rate}%`}</strong>
      <p>{row.completed} completed / {row.recorded} recorded visits</p>
      <progress max={row.recorded || 1} value={row.completed} aria-label={`${row.clinic} completed visits`}/>
    </section>)}</div>
    <section className="card table-scroll"><h2>Clinic comparison</h2>
      <table>
        <thead>
        <tr>{['Clinic', 'Recorded', 'Completed', 'Rescheduled', 'Canceled', 'Unknown'].map(label => <th
          key={label}>{label}</th>)}</tr>
        </thead>
        <tbody>{report.map(row => <tr
          key={row.clinic}>{[row.clinic, row.recorded, row.completed, row.rescheduled, row.canceled, row.unknown].map((value, index) =>
          <td key={index}>{value}</td>)}</tr>)}</tbody>
      </table>
    </section>
    {[['Reminder activity', ['attempts', 'failed', 'replies', 'confirmations']], ['Contact and follow-up', ['open_holds', 'follow_ups']]].map(([title, keys]) =>
      <details className="card" key={String(title)}>
        <summary>{String(title)}</summary>
        <p>Counts are grouped by appointment month. Attempts are fake acceptance records; holds are current
          concerns.</p>{report.map(row => <section key={row.clinic}><h3>{row.clinic}</h3>{(keys as string[]).map(key =>
        <p key={key}>{key.replaceAll('_', ' ')}: {row[key as keyof Report]}</p>)}</section>)}</details>)}</>}</>
}
