# V4 — Independent review using the two evidence-based rubrics

Run this **after implementation and its ordinary automated checks**, preferably in a separate agent session. The V3 development guidance, product spec and acceptance requirements remain unchanged. The V4-only difference is how the final independent review is structured.

Read `AGENTS.md`, `docs/ASSESSMENT_REQUIREMENTS.md`, `docs/ACCEPTANCE_MATRIX.md`, `standards/RUBY_RAILS_GUIDE.md`, `standards/FRONTEND_GUIDE.md`, `review/RUBY_RAILS_EVIDENCE_RUBRIC.md`, and `review/FRONTEND_EVIDENCE_RUBRIC.md`. Inspect the real diff, call sites, tests and meaningful runtime behavior rather than relying on the implementer's summary.

For each relevant area, use **Meets**, **Revise**, **Unverified**, or **Outside scope**. Each `Revise` finding must cite `file:line`, explain the consequence and smallest defensible remedy. Preserve unresolved evidence gaps. Run checks you can run; report blockers without inventing pass results.

Do not turn review into a rewrite campaign. Fix demonstrated high-impact defects first, then meaningful readability problems. Reject aesthetic-only requests for layers, abstractions, hooks or service objects. Do not provide numeric grades.
