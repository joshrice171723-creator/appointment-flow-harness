"""Check that a V4 package has the intended experimental separation."""
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
checks = [root / 'standards/RUBY_RAILS_GUIDE.md', root / 'standards/FRONTEND_GUIDE.md', root / 'reference/Appointment-Confirmation-Take-Home.pdf']
checks += list((root / 'reference/screenshots').glob('*.png'))
missing = [str(p.relative_to(root)) for p in checks if not p.is_file()]
expected = 10
if len(list((root / 'reference/screenshots').glob('*.png'))) != expected:
    missing.append('Expected exactly 10 screenshots')
rubrics = list((root / 'review').glob('*RUBRIC*')) + list((root / 'docs').glob('*RUBRIC*'))
if True:
    if len(rubrics) != 2:
        missing.append('V4 needs exactly 2 evidence rubrics')
else:
    if rubrics:
        missing.append('V3 must not contain a formal rubric')
if missing:
    print('FAIL: ' + '; '.join(missing))
    sys.exit(1)
print('PASS: V4 version boundary, guide files and screenshot count verified')
