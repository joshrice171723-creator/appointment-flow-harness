# V4 launch prompt

Verbatim saved user messages, in chronological order. Headings are packaging annotations; message bodies are unchanged.

## User message 1 ? 2026-11-15T16:59:11.561Z

Step 1 — Set up RubyMine
Extract the ZIP into:
@C:/Users/joshr/Downloads/Apex_Clean_Room_V4_RubyMine_Harness_UPDATED.zip 
C:\Users\joshr\RubyMineProjects\appointment-flow_v4

Open the extracted project folder in RubyMine and start a new, independent Codex or Claude Code session.
Step 2 — Give RubyMine this prompt
:::writing{variant="standard" id="63418"}
# Apex Appointment Flow V4 — Autonomous Clean-Room Rebuild

You are the lead software engineer responsible for independently building the Apex Appointment Confirmation System from scratch.

Your objective is to produce a complete, working Ruby on Rails + React application using the V4 engineering-quality harness provided in this project.

**This is an autonomous development assignment, not a planning-only task.**

## Phase 1 — Initialize the Harness

Before writing application code:

1. Read the complete `AGENTS.md` file.
2. Read `START_HERE.md`.
3. Read and follow `RUN_THIS_IN_RUBYMINE.md`.
4. Examine the original assessment PDF, product specifications, acceptance criteria, workflows, scenarios, and all 10 screenshots.
5. Read the enhanced Ruby/Rails and React engineering guides.
6. Read the V4 review rubrics and understand when to apply them.
7. Run the harness verification script.
8. Verify development prerequisites and prepare a concise implementation plan.

Treat the supplied harness instructions as authoritative, with the original assessment controlling product scope.

Do not begin application development until the harness is initialized and verified.

## Phase 2 — Build the Application

Independently design and implement the complete application.

Follow these engineering priorities:

1. Correctness
2. Readability
3. Simplicity
4. Maintainability
5. Performance, where relevant

Use conventional, readable Rails and React code.

Avoid unnecessary abstractions, service objects, hooks, dependencies, and architectural complexity.

Implement the documented features and workflows in small, testable increments.

Make reasonable technical decisions autonomously. Document important assumptions and tradeoffs.

## Phase 3 — Test, Review, and Improve

Run the automated verification tools included with the harness.

For every substantial feature:

- Verify its functionality.
- Run appropriate tests and static checks.
- Review the implementation for unnecessary complexity.
- Simplify where justified.
- Rerun affected tests.

After implementation, perform the independent reviews required by V4's Ruby/Rails and frontend quality rubrics.

Correct confirmed issues. Do not make changes solely to satisfy arbitrary stylistic preferences.

## Phase 4 — Final Deliverables

Produce:

- A working Rails + React application.
- Fictional seed data.
- Automated tests.
- Startup and testing instructions.
- Architecture documentation.
- An accurate AI usage record.
- Decision notes for the human developer to write the final `DECISIONS.md`.
- Verification results and known limitations.

Follow the harness's freeze procedure after completing the build.

## Critical Clean-Room Restrictions

This application must be independently developed.

- Never inspect, clone, or reference the original Appointment Flow GitHub repository.
- Never access the source code of V1, V2, or V3.
- Never reuse prior implementations or their architectures.
- Use only the current project's assessment, screenshots, specifications, and engineering instructions.
- Do not modify files outside this project.
- Do not push or submit anything without authorization.

## Autonomy

Proceed through every phase without requesting permission for ordinary, reversible engineering decisions.

Only interrupt for missing essential prerequisites, required permissions, or genuinely consequential decisions.

If a tool or dependency is unavailable, investigate reasonable alternatives and document any remaining blocker.

Do not stop after generating a plan. Continue implementing, testing, reviewing, and documenting until the application is complete or a genuine blocker prevents progress.

**Begin Phase 1 immediately. Follow the V4 harness exactly.**


context: renderer=paths title=Files source=manualPaths project=C:\Users\joshr\RubymineProjects\appointment-flow_v4
path: C:\Users\joshr\Downloads\Apex_Clean_Room_V4_RubyMine_Harness_UPDATED.zip

## User message 3 ? 2026-11-15T21:22:32.280Z

add the zip file to the project its for reference/ this run was interrupped so I would like for you to start over from scratch delete everything you done so far  empty the appointment-flow_v4 folder and start again in there

## User message 5 ? 2026-11-15T21:27:11.281Z

ok now move zip 4 into the folder then 


Set up RubyMine Extract the ZIP into: Apex_Clean_Room_V4_RubyMine_Harness_UPDATED.zip C:/Users/joshr/RubyMineProjects/appointment-flow_v4
Open the extracted project folder in RubyMine and start a new, independent Codex or Claude Code session. Step 2 — Give RubyMine this prompt :::writing{variant="standard" id="63418"}
Apex Appointment Flow V4 — Autonomous Clean-Room Rebuild
You are the lead software engineer responsible for independently building the Apex Appointment Confirmation System from scratch.
Your objective is to produce a complete, working Ruby on Rails + React application using the V4 engineering-quality harness provided in this project.
This is an autonomous development assignment, not a planning-only task.
Phase 1 — Initialize the Harness
Before writing application code:
Read the complete AGENTS.md file.
Read START_HERE.md.
Read and follow RUN_THIS_IN_RUBYMINE.md.
Examine the original assessment PDF, product specifications, acceptance criteria, workflows, scenarios, and all 10 screenshots.
Read the enhanced Ruby/Rails and React engineering guides.
Read the V4 review rubrics and understand when to apply them.
Run the harness verification script.
Verify development prerequisites and prepare a concise implementation plan.
Treat the supplied harness instructions as authoritative, with the original assessment controlling product scope.
Do not begin application development until the harness is initialized and verified.
Phase 2 — Build the Application
Independently design and implement the complete application.
Follow these engineering priorities:
Correctness
Readability
Simplicity
Maintainability
Performance, where relevant
Use conventional, readable Rails and React code.
Avoid unnecessary abstractions, service objects, hooks, dependencies, and architectural complexity.
Implement the documented features and workflows in small, testable increments.
Make reasonable technical decisions autonomously. Document important assumptions and tradeoffs.
Phase 3 — Test, Review, and Improve
Run the automated verification tools included with the harness.
For every substantial feature:
Verify its functionality.
Run appropriate tests and static checks.
Review the implementation for unnecessary complexity.
Simplify where justified.
Rerun affected tests.
After implementation, perform the independent reviews required by V4's Ruby/Rails and frontend quality rubrics.
Correct confirmed issues. Do not make changes solely to satisfy arbitrary stylistic preferences.
Phase 4 — Final Deliverables
Produce:
A working Rails + React application.
Fictional seed data.
Automated tests.
Startup and testing instructions.
Architecture documentation.
An accurate AI usage record.
Decision notes for the human developer to write the final DECISIONS.md.
Verification results and known limitations.
Follow the harness's freeze procedure after completing the build.
Critical Clean-Room Restrictions
This application must be independently developed.
Never inspect, clone, or reference the original Appointment Flow GitHub repository.
Never access the source code of V1, V2, or V3.
Never reuse prior implementations or their architectures.
Use only the current project's assessment, screenshots, specifications, and engineering instructions.
Do not modify files outside this project.
Do not push or submit anything without authorization.
Autonomy
Proceed through every phase without requesting permission for ordinary, reversible engineering decisions.
Only interrupt for missing essential prerequisites, required permissions, or genuinely consequential decisions.
If a tool or dependency is unavailable, investigate reasonable alternatives and document any remaining blocker.
Do not stop after generating a plan. Continue implementing, testing, reviewing, and documenting until the application is complete or a genuine blocker prevents progress.
Begin Phase 1 immediately. Follow the V4 harness exactly.
context: renderer=paths title=Files source=manualPaths project=C:/Users/joshr/RubymineProjects/appointment-flow_v4 path: Apex_Clean_Room_V4_RubyMine_Harness_UPDATED.zip

## User message 6 ? 2026-11-15T21:29:52.160Z

```
# Paste this file into a RubyMine coding-agent session

You are the implementation agent for a clean-room quality-harness evaluation. Build a **new** Rails + React version of the Apex appointment-confirmation product using ONLY this ZIP's assessment document, included UI screenshots, sanitized product specification, and engineering rules. A separate old implementation exists but is forbidden to access until this rebuild is completely finished and frozen. The purpose is to test whether the harness creates a high-quality implementation, not whether it can reproduce old code.

## Mandatory sequence — start immediately

**Stage 0: Harness setup, before application code.** Read the **entire root `AGENTS.md`**, including its before-code and before-finish engineering checks, then `START_HERE.md`, `reference/Appointment-Confirmation-Take-Home.pdf`, every file in `product-spec/`, then `docs/CODING_STANDARDS.md`, `docs/ARCHITECTURE_GUARDRAILS.md`, `docs/DELIVERABLES_AND_DECISIONS.md`, and both guides under `standards/`. Run `python quality/verify_harness.py` (Windows: `py quality/verify_harness.py`). Confirm the screen count from the actual filesystem. Confirm the Email-tab screenshot is included, read it, and do not infer hidden behavior from it. State a concise implementation plan and identify decision points. Do not read old code, and do not write app code until this Stage 0 plan has been established.

**Stage 1: Independent design.** Choose the smallest understandable Rails + React solution that can meet the *official* scope and present the UI/workflows shown. Use appropriate current stable runtime and tool versions available on the user's machine; document the exact versions. No mandated classes, API routes, component structure, background job product, global store, or folder split. The picture and written behavior are inputs, not an architecture blueprint. Explicitly address reminder scheduling, safe reply matching, reschedules, clinic isolation, read-only PMS boundary, timezones, fake transport, and testability.

**Stage 2: Scaffold and implement.** After the Stage 0 plan is captured, proceed with implementation in small working vertical slices without asking about ordinary, reversible choices. Prioritize a runnable app and the official core requirements; then add the visual workflows and safety-sensitive extended behavior within scope. No pixel-perfect mandate: retain the warm neutral / dark-green visual identity and the main navigation patterns. Seed **fictional** records representing Austin and Phoenix and enough cases to exercise each state. No live external messaging. For each slice, test behavior and simplify the real diff before adding new abstractions. Keep a compact progress record in `notes/BUILD_LOG.md`.

**Stage 3: Working local demo.** Document one reproducible startup path from a clean checkout, how to seed, how to trigger a reminder batch manually, how to simulate SMS/email replies, how to inspect sent fake messages, and how to run all checks. If prerequisites are not available, describe the exact blocker and give tested partial steps; do not fabricate success.

**Stage 4: Verify independently.** Configure `quality/checks.json` using the actual structure after scaffolding; execute `python quality/run_checks.py`. Run tests for high-risk scenarios in `product-spec/SCENARIOS.md`, plus UI smoke checks and a separate code-review session per `agent-prompts/03_INDEPENDENT_REVIEW.md`. Resolve confirmed issues; track nonissues and untested items honestly.

**Stage 5: Candidate-owned deliverables and freeze.** Produce a usable `README.md`, an honest `AI_USAGE.md`, and an architecture diagram. Create only **decision notes** for the candidate to turn into their own `DECISIONS.md`; do not write the final decision narrative as their words. Produce `review/FREEZE_CHECKLIST.md` with actual results, commit hash if one exists, known limitations, and instructions to preserve this version for a later blind comparison. Do not access the old repo during this stage. Do not push or submit anything without explicit authorization.

**Variant:** V4. Read `review/EXPERIMENT_PROTOCOL.md` for isolation and comparison controls. V4 adds a structured evidence-based review after development; the implementation guidance is identical to V3.

## Agent interaction rules
- Do not ask broad stylistic preference questions. Make reasonable, documented choices.
- Stop and ask only for a blocking prerequisite, a truly consequential irreversible choice, or required permission.
- Explicitly distinguish **observed in screenshot**, **provided in spec**, **chosen for rebuild**, and **verified by test**.
- This ZIP is a repository instruction package, **not an installed RubyMine plugin**, and the optional Compound Engineering plugin must be installed separately in a supported agent host if desired. If unavailable, follow these self-contained steps without it.
- Keep the new implementation fully independent until the user explicitly authorizes final comparison.

Begin Stage 0 now, in this directory.
```

