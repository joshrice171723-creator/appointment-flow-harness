# V4 supplied user instructions

Verbatim saved user messages, in chronological order. Headings are packaging annotations; message bodies are unchanged.

## User message 0 ? 2026-11-15T16:57:31.857Z

# AGENTS.md instructions

<INSTRUCTIONS>
## 1. Execution Philosophy
- Treat my workspace as a engineering environment there are NO USER NO REAL DATA.
- Prioritize action over explanation. If a task requires editing a file or running a command, output the code or tool call immediately with minimal conversational text.
- Do not stop to ask for permission to read directories, inspect files, or check local configurations.

## 2. Granular File & Directory Access
- Use an existing index or recursive file listing to map the relevant architecture before structural edits. Read the context the change needs; do not repeat a whole-repository survey for a narrow edit.
- Read complete files when structural context is needed; avoid partial snippets that lead to broken imports or mismatched syntax.
- When modifying code, ensure all edits are fully realized with no truncated sections or placeholder comments.

## 3. Terminal & Workflow Execution
- Run checks appropriate to the change. Use focused regression checks for changed behavior; reserve full suites for cross-cutting changes or requested acceptance checks. Instruction-only or documentation-only changes need content and reference validation, not an unrelated app suite.
- If a command throws a runtime or compilation error, analyze the trace, modify the files accordingly, and re-run the verification automatically.



Before repository work, verify the active checkout, remote, branch, and dirty files, then synchronize with the actual upstream/default branch (main or master, whichever exists). Preserve unrelated changes; do not reset, stash, or commit them automatically. After changing repository files, synchronize again, resolve relevant conflicts, commit only the task's changes, and push as authorized. If there is no remote, report that limit rather than repeatedly attempting a nonexistent origin. Local harness files outside Git do not require creating a repository just to commit them.



ignore the shortcut rules 

## Product copy

Write functional copy for apps and internal tools. Use plain titles, labels, status messages, and instructions that help users do their work.

Add promotional hero copy, taglines, slogans, product pitches, or decorative filler only when the user explicitly requests that kind of copy for that surface. Requests to design, redesign, or polish a screen call for functional copy by default.

Before handing off UI work, review every new or changed user-visible string. Keep it if it helps someone understand where they are, what happened, or what they can do next. Remove unsolicited promotional or decorative text and flag it in review.

## Engineering judgment learned from Apex

- Honor the brief, accepted scope, and Joshua's latest corrections. Allocate effort by user frequency and consequence. Do not turn deliberate cuts into defects or reintroduce rejected features through an audit. Keep project-specific exclusions local.
- Check another agent's finding against current source before acting. Agreement and high scores are not proof; distinguish defects, risks, preferences, and unchecked paths.
- Assess comprehension separately from tests: trace an entry point through its rule owner, writes, and visible result. Prefer familiar conventions, explicit contracts, and obvious transaction ownership. Extract only to reduce reader effort; remove superseded paths.
- Choose the smallest complete design. Workers, migrations, and dependencies can earn their place through a demonstrated need; explain their operating cost rather than reflexively adding or rejecting them.
- Make demo states and totals traceable to records, events, or explicit assumptions. Preserve inspectable raw source values and the actual source-write boundary.
- Measure whole-command performance, including setup and repeated work. Inspect cumulative cost before adding concurrency or caches. Preserve meaningful transaction/retry/concurrency coverage; distinguish best and repeat timings.
- Tie evidence to its revision and scope. Separate source inspection, tests, running behavior, packaged artifacts, and human acceptance. Check extracted deliverables when packaging; never promote historical checks to a current pass.
- Distinguish Joshua's decisions and objections from AI implementation and wording. Preserve personal notes unless rewriting is requested. Do not infer authorship from style or invent rankings among unseen candidates.
- Finish the agreed checks, then stop expanding. Report actual results and evidence gaps without inventing human acceptance or claiming future agent behavior is proven.
</INSTRUCTIONS>
<environment_context>
  <cwd>C:\Users\joshr\RubymineProjects\appointment-flow_v4</cwd>
  <shell>powershell</shell>
  <current_date>2026-11-15</current_date>
  <timezone>America/Chicago</timezone>
  <filesystem><workspace_roots><root>C:\Users\joshr\RubymineProjects\appointment-flow_v4</root><root>C:\Users\joshr\AppData\Local\JetBrains\RubyMine2026.3\ai-agent-extensions\agents\air-views\999c99748dcfacb5ca0f0485c754bf2d\codex\7f9a8cc292aec9f1</root></workspace_roots><permission_profile type="disabled"><file_system type="unrestricted" /></permission_profile></filesystem>
</environment_context>

## User message 2 ? 2026-11-15T21:22:15.192Z

# AGENTS.md instructions for C:\Users\joshr\RubymineProjects\appointment-flow_v4

<INSTRUCTIONS>
These AGENTS.md instructions replace all previously provided AGENTS.md instructions.

## 1. Execution Philosophy
- Treat my workspace as a engineering environment there are NO USER NO REAL DATA.
- Prioritize action over explanation. If a task requires editing a file or running a command, output the code or tool call immediately with minimal conversational text.
- Do not stop to ask for permission to read directories, inspect files, or check local configurations.

## 2. Granular File & Directory Access
- Use an existing index or recursive file listing to map the relevant architecture before structural edits. Read the context the change needs; do not repeat a whole-repository survey for a narrow edit.
- Read complete files when structural context is needed; avoid partial snippets that lead to broken imports or mismatched syntax.
- When modifying code, ensure all edits are fully realized with no truncated sections or placeholder comments.

## 3. Terminal & Workflow Execution
- Run checks appropriate to the change. Use focused regression checks for changed behavior; reserve full suites for cross-cutting changes or requested acceptance checks. Instruction-only or documentation-only changes need content and reference validation, not an unrelated app suite.
- If a command throws a runtime or compilation error, analyze the trace, modify the files accordingly, and re-run the verification automatically.



Before repository work, verify the active checkout, remote, branch, and dirty files, then synchronize with the actual upstream/default branch (main or master, whichever exists). Preserve unrelated changes; do not reset, stash, or commit them automatically. After changing repository files, synchronize again, resolve relevant conflicts, commit only the task's changes, and push as authorized. If there is no remote, report that limit rather than repeatedly attempting a nonexistent origin. Local harness files outside Git do not require creating a repository just to commit them.



ignore the shortcut rules 

## Product copy

Write functional copy for apps and internal tools. Use plain titles, labels, status messages, and instructions that help users do their work.

Add promotional hero copy, taglines, slogans, product pitches, or decorative filler only when the user explicitly requests that kind of copy for that surface. Requests to design, redesign, or polish a screen call for functional copy by default.

Before handing off UI work, review every new or changed user-visible string. Keep it if it helps someone understand where they are, what happened, or what they can do next. Remove unsolicited promotional or decorative text and flag it in review.

## Engineering judgment learned from Apex

- Honor the brief, accepted scope, and Joshua's latest corrections. Allocate effort by user frequency and consequence. Do not turn deliberate cuts into defects or reintroduce rejected features through an audit. Keep project-specific exclusions local.
- Check another agent's finding against current source before acting. Agreement and high scores are not proof; distinguish defects, risks, preferences, and unchecked paths.
- Assess comprehension separately from tests: trace an entry point through its rule owner, writes, and visible result. Prefer familiar conventions, explicit contracts, and obvious transaction ownership. Extract only to reduce reader effort; remove superseded paths.
- Choose the smallest complete design. Workers, migrations, and dependencies can earn their place through a demonstrated need; explain their operating cost rather than reflexively adding or rejecting them.
- Make demo states and totals traceable to records, events, or explicit assumptions. Preserve inspectable raw source values and the actual source-write boundary.
- Measure whole-command performance, including setup and repeated work. Inspect cumulative cost before adding concurrency or caches. Preserve meaningful transaction/retry/concurrency coverage; distinguish best and repeat timings.
- Tie evidence to its revision and scope. Separate source inspection, tests, running behavior, packaged artifacts, and human acceptance. Check extracted deliverables when packaging; never promote historical checks to a current pass.
- Distinguish Joshua's decisions and objections from AI implementation and wording. Preserve personal notes unless rewriting is requested. Do not infer authorship from style or invent rankings among unseen candidates.
- Finish the agreed checks, then stop expanding. Report actual results and evidence gaps without inventing human acceptance or claiming future agent behavior is proven.

--- project-doc ---

# AGENTS.md — Apex clean-room rebuild contract

## Read order and precedence
1. `RUN_THIS_IN_RUBYMINE.md` (execution contract)
2. `reference/Appointment-Confirmation-Take-Home.pdf` (official assignment, highest product authority)
3. `product-spec/PRODUCT_BRIEF.md`, `BEHAVIORAL_REQUIREMENTS.md`, `USER_JOURNEYS.md`, `SCENARIOS.md`, and `ACCEPTANCE_TESTS.md` (observed product intent)
4. `product-spec/SCREENSHOT_INDEX.md` and the actual PNGs (visual reference, **not** proof of unseen behavior)
5. `docs/CODING_STANDARDS.md`, `docs/ARCHITECTURE_GUARDRAILS.md`, and the task-relevant `standards/` guides (engineering discipline)
6. Other templates, prompts, and reference documents

If sources disagree, keep the official assessment above the baseline behavior and visuals. Note material ambiguity in a decision log; make a narrow, defensible choice rather than inventing facts.

## Absolute clean-room boundary
- Build in this newly extracted directory, as a **brand-new application and Git repository**.
- NEVER open, clone, search, fetch, inspect, or copy code, tests, config, commit history, issues, agent notes, API routes, model names, database migrations, or architecture from the earlier appointment-flow repository. This includes GitHub connector access and local files from that repository. The old project is strictly a post-completion comparison baseline.
- Only the assessment PDF, the ten included UI screenshots, and **sanitized behavior-only documents** are authorized information about the prior product. Do not look for screenshots or more details in the old codebase.
- Do not add the old repository as a Git remote. Do not publish to it. Create a new independent repository if publishing is authorized.
- The screenshot names are descriptive labels, not code or API requirements.
- Do not recreate the former code architecture even if a product example tempts you to do so. Choose your own solution from the problem and justify it.

## Software engineering standards — mandatory for every agent

**Write code that another experienced software engineer can quickly understand, debug, modify, and maintain.** The purpose of this rebuild is to assess code quality independently, not to generate the most code or reproduce an earlier design.

Prioritize, in this order:

1. **Correctness and safety** — observable behavior, patient privacy, clinic isolation, and reliable state transitions.
2. **Readability** — meaningful names, straightforward control flow, and code that is easy to trace.
3. **Simplicity** — the least complicated implementation that meets the actual requirement.
4. **Maintainability** — cohesive responsibilities, understandable change boundaries, and focused tests.
5. **Performance, where relevant** — optimize demonstrated bottlenecks or actual requirements, not hypothetical scale.

Follow conventional, idiomatic Ruby on Rails and React/TypeScript practices:

- Keep methods and components focused, but **do not split code into extra files merely to make it shorter**. Keep related logic together if splitting it would obscure the flow.
- Choose descriptive method, component, variable, and hook names. Prefer understandable conditions and early returns when helpful over clever expressions or needless nesting.
- Search for existing functionality **inside this new version only** before creating duplicate behavior. Prefer a small, appropriate reuse over a generic framework.
- Don't introduce design patterns, service objects, concerns, wrappers, helpers, custom hooks, React context, memoization, or extra dependencies without a concrete benefit. No infrastructure for one hypothetical future use case.
- Keep Rails controllers responsible for HTTP concerns. Put substantive domain behavior where ownership is clearest; do not extract it reflexively just to satisfy an arbitrary line count.
- Use ActiveRecord and ordinary Rails conventions when suitable. Avoid needless metaprogramming and unexplained indirection.
- Prefer cohesive React function components, minimal state, derived values instead of duplicated state, and effects only for real external synchronization. Account for stale or canceled asynchronous work when it affects correctness.
- Comments should explain **why** a non-obvious decision exists, not narrate what the code plainly does. Add only documentation that helps a future maintainer.
- Never trade correctness, accessibility, security, or important domain boundaries for fewer lines of code.

**Before writing code**

1. In the initial empty workspace, read the official assessment, product specification, ten screenshots, and relevant harness guides. There is no existing app code to read yet.
2. For subsequent changes, inspect the relevant **new-project** implementation, its call sites, and its tests. Never inspect a previous project's implementation, repository, commits, or architectural notes.
3. Understand the behavior to preserve, local conventions to follow, and functionality available for reuse.
4. Choose the simplest appropriate approach; document nontrivial product or architecture choices without prescribing their implementation in advance.

**Before completing each feature or change**

1. Inspect the actual diff as an experienced maintainer would. Ask: Is it more complex than necessary? Are names and control flow clear? Are there unjustified layers, files, dependencies, comments, hooks, or duplicated decisions?
2. Simplify **confirmed** problems without changing the required behavior. Do not obey an AI review suggestion merely because it sounds sophisticated.
3. Run applicable behavior tests, type checks, linters, and security checks; rerun affected checks after simplification. Record actual pass/fail/blocked results without claiming unrun checks passed.
4. Explain the feature's observable behavior, the important tradeoffs, and where to make the next change in ordinary engineering terms. If the code requires an elaborate explanation to be legible, reconsider the code.

**Critical principle:** Code is written for humans to maintain, not for AI to generate as quickly as possible. The best implementation is the simplest **correct** one that fits this *new* application's verified requirements and evolving structure.

## Domain and process guardrails

- Work in small, reviewable vertical slices; make real behaviors work, not just screenshots. Every material UI action must produce or reveal an observable state transition.
- Add focused automated tests for high-risk behavior: wrong-recipient outreach, clinic data isolation, duplicate sends, ambiguous replies, opt-outs, rescheduled appointments, timezone/clinic-local dates, and no PHI in leadership data.
- A fake provider's successful API call is **not** evidence that an SMS or email reached anyone. Use only fake/sandbox transport and fictional patient records.
- Treat replicated PMS source data as read-only in the application. Keep locally owned state separately and document any domain assumptions.
- Do not implement out-of-scope booking, patient self-service rescheduling, production infrastructure, full staff authentication, or live vendor accounts.
- Run a **separate reviewer session** on the final diff; require exact file/line evidence and the smallest justified fix. V3 uses defect-focused review without a formal rubric; V4 alone adds structured evidence rubrics **at the independent review stage**.
- No automatic push, PR, merge, live communication, external-resource creation, or destructive operation outside the isolated workspace without explicit authorization.
- `DECISIONS.md` is the candidate's own writing. The agent may provide tradeoff notes and critique, but must not fabricate or impersonate the candidate's personal judgment.

## At each slice
Summarize requirement IDs, implementation approach, alternatives, tests run and *actual* results, remaining gaps, and a plain-English explanation of why this code is structured this way. Do not pad with generic engineering essays.

## V4 additional engineering guidance

Before implementing a Rails/backend slice, read `standards/RUBY_RAILS_GUIDE.md`; before implementing a React/frontend slice, read `standards/FRONTEND_GUIDE.md`. Apply only relevant rules; these documents do **not** prescribe classes, files, routes, hooks, or libraries. Do not consult the earlier implementation or original source-guide examples.

The independent reviewer (not the implementing agent during Stage 0/1) reads `review/RUBY_RAILS_EVIDENCE_RUBRIC.md` and `review/FRONTEND_EVIDENCE_RUBRIC.md` during Stage 4. These checklists use four evidence statuses, not a score.

</INSTRUCTIONS>

