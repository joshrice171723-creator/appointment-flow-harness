# Candidate-owned decisions

The candidate's personal decision narrative has not been written. Joshua must author it in his own words before using this as an assessment submission.

Agent-authored implementation facts and suggested discussion points are in [notes/REBUILD_DECISION_NOTES.md](notes/REBUILD_DECISION_NOTES.md). They are not represented as Joshua's reasoning or acceptance.
