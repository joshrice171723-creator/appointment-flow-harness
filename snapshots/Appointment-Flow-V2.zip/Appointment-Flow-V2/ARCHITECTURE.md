# Components and ownership

```mermaid
flowchart LR
    PMS[(PMS replica database\nexact brief schema)] -->|separate SELECT-only connection| Refresh[SourceRefresh]
    Refresh --> App[(Application database\napp-owned tables)]
    React[React workspaces] --> API[Rails controllers\nclinic-scoped lookups]
    API --> Batch[ReminderBatch]
    API --> Reply[ReceiveReply]
    API --> Staff[RecordFollowup]
    Batch --> Refresh
    Reply --> Refresh
    Staff --> Refresh
    Batch --> Fake[FakeTransport\nno network IO]
    Fake --> App
    Reply --> App
    Staff --> App
    API --> Aggregate[Leadership aggregate queries]
    Aggregate --> React
```

`SourceRefresh` owns interpreting source wall time and identifying appointment revisions. `ReminderBatch` owns timing and logical send steps; `Person` owns contact safety, local verification conflicts and opt-outs. `ReceiveReply` owns one inbound event and its business effect. `RecordFollowup` owns an idempotent staff action and confirmation/disposition. Models expose ordinary persistence relationships and serialization; controllers enforce clinic lookups and HTTP error responses.

```mermaid
stateDiagram-v2
    [*] --> Unconfirmed: source scheduled visit / new revision
    Unconfirmed --> ContactHold: unsafe contact or time
    ContactHold --> Unconfirmed: verified safe contact + next batch
    Unconfirmed --> Requested: eligible local window / fake send
    Requested --> Confirmed: safe current YES or staff phone confirmation
    Requested --> Review: ambiguous / stale / late / NO reply
    Review --> Confirmed: staff clarifies this current appointment
    Confirmed --> Review: conflicting NO (confirmation retained)
    Confirmed --> Unconfirmed: source schedule changes / fresh revision
    Requested --> Unconfirmed: source schedule changes / fresh revision
    Review --> Stopped: staff records canceled or rescheduled
    Requested --> Stopped: PMS no longer scheduled
    Confirmed --> Stopped: PMS no longer scheduled
```

Confirmation, work-item status, local disposition and source outcome are distinct facts. STOP is a persisted contact-channel suppression, not a visit outcome. Delivery failures retain attempts and create follow-up. Leadership completion derives only from source status, never from a YES.

All workflow writes share a PostgreSQL transaction advisory lock. A reminder transaction refreshes source, validates eligibility and records a deterministic fake outcome; unique message step/version/channel keys provide a second integrity boundary. Inbound event and follow-up request IDs are uniquely constrained and payload-checked on replay. No transaction performs external provider IO. A real provider would require a separate idempotent dispatch/outbox design, delivery reconciliation and signed callbacks.
