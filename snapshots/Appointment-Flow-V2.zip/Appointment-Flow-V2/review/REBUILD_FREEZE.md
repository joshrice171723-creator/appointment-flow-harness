# Verified local rebuild — 2026-11-15

Status: working local assessment demo, verified by source review, automated checks and browser smoke checks. Human acceptance and candidate-authored decisions are not claimed.

Workspace: `C:\Users\joshr\RubymineProjects\appointment-flow_v2`. The full harness passed on initial rebuild commit `2c24e8c`. A subsequent readability-only change expanded the React/CSS sources with Prettier and added formatting enforcement to frontend lint. Frontend lint, tests, TypeScript/build, dependency audit and browser checks were rerun for that change; backend files remain byte-identical in Git to the 33-test revision. This record is updated in the formatting follow-up commit; use `git log -1 --format=%H -- review/REBUILD_FREEZE.md` to identify it. No remote is configured, so no upstream synchronization or push was possible. No external publication, submission, old-code access or comparison occurred.

## Evidence

| Check | Actual result |
|---|---|
| Preflight before application code | PASS: required files, original PDF, ten PNG signatures and original SHA256 manifest |
| Original harness integrity after rebuild | PASS: original harness files remain unchanged |
| PostgreSQL safety/API tests | PASS: 33 tests, 164 assertions, zero failures/errors/skips; final test execution 123.878 seconds |
| Exact PMS schema and ownership | PASS within backend suite: separate source/application databases; exact three source tables, original columns/types/nullability/CHAR(2), three foreign keys; reader cannot write and app role cannot connect |
| Concurrent reminder runs | PASS within backend suite: four concurrent attempts produce one logical message; database uniqueness also rejects duplicate insert |
| Ruby/Rails formatting | PASS: 42 files, no offenses |
| React lint/hooks and Prettier | PASS after the formatting follow-up |
| React save-failure tests | PASS: 2 tests; rejected/network-interrupted saves retain drafts; retry reuses save ID |
| TypeScript and production build | PASS through the configured harness runner |
| Harness runner | PASS: all 6 configured checks on `2c24e8c`; affected frontend checks rerun after formatting |
| Browser smoke, Microsoft Edge | PASS: 2 tests, 1.1 minutes reported for the final formatted build, zero failures |
| Visual inspection | Captured landing, board, contact editor, expanded leadership, narrow inbox and narrow landing inspected; no clipping or horizontal page overflow observed in these captures |
| Dependency audit | PASS: `npm audit` reported zero vulnerabilities after the scoped minimatch override; installed dependency tree uses 11.0.8 |
| Documented setup/start | Setup rerun completed without deleting existing records; supplied start script serves built React and Rails API at 127.0.0.1:3185 |
| Independent source reviewer | Ready after verified fixes; reviewer did not run overlapping suites or claim runtime acceptance |

Raw current-session evidence is in `tmp/quality-gate.log`, `tmp/browser-smoke.log`, `tmp/browser-smoke-formatted.log`, and `tmp/screenshots/`. These are local generated artifacts, excluded from source control; the commands in README reproduce them. Earlier failing runs are documented in the build journal and are not presented as passing evidence. The final backend suite follows the separate-database correction and the late-review persistence regression; backend tests were not needlessly repeated for frontend formatting.

## Coverage and limits

Official application behavior is implemented: replica-backed upcoming visits, fake SMS/email, current-version confirmation, clinic-scoped staff views, realistic fictional fixtures, local startup and tests. Reminder timing, reschedules/reopened visits, late/shared/stale/conflicting replies, opt-outs, unsafe contacts, failed/empty source refresh, idempotency/concurrency, clinic isolation and aggregate reporting have focused backend checks. Browser coverage exercises navigation, reminder runs, search/date selection, patient contact editor, clinic switching, leadership, SMS/email reply submission and narrow layouts. It is smoke coverage, not an exhaustive accessibility or interaction audit.

Extended workflow limits: leadership offers selected-month outcomes and activity, without a multi-month history chart; shared replies are resolved through individual appointment work items rather than a grouped family screen. Replies from a completely unknown contact are retained as inbound records but do not have a dedicated unmatched-sender staff queue. Backend pagination/search UI exists, but every possible filter/pagination combination is not browser-tested.

`DECISIONS.md` contains an explicit candidate-authorship status, not an AI-written personal narrative. Joshua still needs to write his decisions, perform the live defense and accept the product. Source inspection and test passes do not prove employer-volume throughput, real vendor delivery, production authentication/authorization, actual guardianship/consent, upstream freshness or no-show reduction.

## Preserve and reproduce

1. Keep this independent Git commit; do not overwrite it with an old implementation.
2. From a checkout, run `powershell -File scripts/setup.ps1`, then `powershell -File scripts/start.ps1`.
3. Use the November 15, 2026 demo clock and a matching fresh seed date to reproduce the current browser fixture assumptions. Production messaging is absent.
4. Run `python quality/run_checks.py`; with the app running, execute `npm.cmd run smoke` in frontend.
5. Do not compare with old code until Joshua explicitly authorizes a comparison. No comparison was performed in this run.
