# Independent source review — clean-room rebuild

Verdict: **Ready from source review**, subject to the execution results recorded in REBUILD_FREEZE.md. Review performed by a separate Codex reviewer session against the actual new application, tests, assessment, acceptance matrix and rubric. The reviewer made no file changes and ran no overlapping suites. This is source evidence, not human acceptance or a performance certification.

## Findings verified and resolved

1. Major: appointment A→B→A reused the original content-hash version, potentially accepting an old message. SourceRefresh now issues a fresh UUID for each schedule revision/reopened appointment. Regression requires old reply rejection and a fresh send after restoring a previous wall time.
2. Major: an unthreaded reply before successful delivery was stored for review without a visible work item. Current clinic/contact candidates now create review work regardless of send history; automatic YES still requires current successful outbound context.
3. Minor: omitted birthdate raised KeyError rather than a validation response. Missing birthdate now reaches explicit validation; endpoint regression checks 422 and no saved verification.
4. Major: a contact shared by multiple patients was eligible for outbound messaging. Channel-level eligibility now rejects shared addresses, uses a safe alternative channel or raises a hold. Regressions cover shared-phone email fallback, shared-both holds and ambiguous inbound replies.
5. Setup: the database bootstrap originally checked only one role. It now independently ensures both roles and all four databases with guarded SQL, preserving existing data. The reviewer rechecked this fix.

## Final boundary and runtime-driven changes reviewed

- PMS is a separate database containing only the brief's three tables. Dedicated reader grants enforce SELECT-only access even if the connection's read-only default is disabled. The application role cannot connect to PMS.
- Local snapshot maps live for one refresh under the transaction lock, retain source-identity checks and introduce no shared cache.
- Work closes on an actual source transition from scheduled to ended, so later reply-review tasks survive routine refreshes.
- The reviewer found no remaining material correctness issue in these final changes.

## Specific strengths and limits

One-statement source snapshots, database uniqueness alongside transaction ordering, explicit appointment revisions, aggregate-only leadership responses and separate source completion/confirmation semantics make the important boundaries visible in source.

The reviewer did not run tests or browsers. Leadership has selected-month comparisons and activity, without multi-month history charts. Shared replies use individual appointment work items rather than a grouped family-resolution view. Staff identity and guardian/consent assumptions remain assessment stubs. Employer-volume throughput has not been measured. Candidate-written DECISIONS.md, live defense and human acceptance remain outside automated proof.
