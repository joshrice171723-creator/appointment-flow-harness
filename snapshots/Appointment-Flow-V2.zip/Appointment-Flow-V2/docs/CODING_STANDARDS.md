# Rails + React coding standards — v1

These are project **decisions for the harness**, informed by official framework documentation and thoughtbot guides (see `docs/SOURCES.md`). They are not claims that every listed rule is an official framework mandate.

## Global standards

- **Readable at a glance:** explicit names, small coherent units, flat branching when it improves comprehension, ordinary control flow, comments explaining *why* rather than narrating *what*.
- **No speculative abstraction:** solve this version first. Extract only to remove meaningful duplication, separate a distinct responsibility, or permit focused testing.
- **Keep changes narrow:** no opportunistic directory reshuffles, pointless wrappers, or adding dependencies for a few lines of code.
- **No "defensive" code that hides bugs:** don't swallow errors, invent fallback values, cast away types, or skip failing tests.
- **Human-maintainable tests:** name scenarios and observable behavior; avoid mocks for every internal method and fragile implementation-specific assertions.
- **No magic constants:** put domain-significant reminder intervals/status values in one clear location; avoid unnecessary configuration layers.
- **Be explicit with dates:** `start_at` is **clinic-local wall-clock time**; do not silently treat it as UTC. Establish a timezone decision and test DST boundaries.

## Ruby and Rails

- Use ActiveRecord models and associations for persistence and ordinary queries. Use scopes for genuinely reusable query conditions; avoid chains of confusing one-letter scopes.
- Keep controllers thin enough to read, but don't introduce a service object simply because controller code exceeds an arbitrary line count. Extract actual domain behavior when it crosses concerns or needs independent tests.
- Prefer straightforward Ruby methods with descriptive parameters and early returns where they clarify branches.
- Use database constraints/indexes where needed for integrity and idempotency; application validation is not sufficient for concurrent uniqueness.
- Do not assume replicated source tables can be mutated safely. Decide and document ownership boundaries for locally managed reminder/confirmation data.
- Use Active Job if async work materially improves the implementation; don't introduce Sidekiq, Redis, schedulers, or distributed systems by default.
- Handle provider failure and retry without duplicate sends; represent delivery attempts and confirmation state distinctly if required by behavior.
- Use UTC for internally controlled instants when applicable and a well-defined clinic timezone for displaying/interpreting appointment wall time. Document conversions; don't guess timezone from a state's abbreviation when the clinic timezone is ambiguous.
- Prefer Rails default Minitest initially; use RSpec only if intentionally chosen with a reason. Test database behavior, domain transitions, and endpoints.
- Follow consistent formatting and RuboCop/RuboCop Rails checks (configured to installed versions); don't disable cops wholesale.

## React and TypeScript

- Prefer **functional components**, explicit props, and clear types. TypeScript is a proposed default, not a requirement from the employer brief.
- Keep state as local as possible; avoid mirroring props, storing derivable values, contradictory status booleans, or unnecessary global contexts.
- Avoid effects for calculations or event-driven work. Use `useEffect` only to synchronize with an external system or similar lifecycle need; handle cleanup/cancellation for async effects.
- Write clear loading, error, empty, and success states for staff actions. Avoid data flashes that display another clinic's appointments.
- Keep API request/response types close to usage; create a shared layer only if duplication appears. Avoid introducing Redux, complex data-fetching libraries, form frameworks, or generic component systems before a demonstrated need.
- Prefer semantic HTML, explicit labels, understandable status text, and testable user-facing behavior.
- Avoid `any`, non-null assertions, and disabled lint rules unless documented with a specific reason. `unknown` plus validation is preferable for untrusted input.
- Use the starter's ESLint and TypeScript setup; add React Hooks rules. Follow React's official guidance on state and effects.

## Security and sensitive data

- Seed **synthetic** patients only. Keep procedure notes/medical details out of SMS/email bodies, logs, screenshots, and unnecessary UI views.
- Never log message bodies or patient contact details in routine error output. Store only the minimum data needed for the demo.
- Validate clinic boundaries **server-side**; a frontend clinic selector is not authorization.
- Stub staff auth because the brief says so, but explicitly document how identity, authorization, consent/opt-out, audit, and data protection would work in production.
- No live sends. The default test adapter must be deterministic and inspectable locally.

## The readability test

Before finishing, ask: "Can a Rails/React engineer explain the execution path and major state changes in five minutes without reading an AI-authored architectural essay?" If not, simplify and verify again.
