# Rebuild journal

2026-11-15, new workspace `C:\Users\joshr\RubymineProjects\appointment-flow_v2`. Initially only RubyMine `.idea` settings; no repository or remote. Original ZIP extracted directly here, and original preflight passed before application code. Original harness files remain byte-identical to the manifest.

## Implementation

- Rails API, app-owned PostgreSQL models, separate exact-schema PMS replica and read-only connection; per-appointment revisions, local verification provenance, persisted opt-outs, fake SMS/email attempts and idempotent inbound/staff actions.
- Reminder batch refreshes source first, coalesces missed steps and respects clinic-local windows, starts, consent assumptions, recipient ambiguity and confirmed state.
- React front desk board/date filters/contact detail/follow-up, aggregate leadership and patient SMS/email simulation. New strings reviewed for functional meaning; no promotional hero copy or decorative filler.
- Windows setup/start scripts, original harness quality configuration, candidate decision notes and architecture flow. Fonts use local fallbacks; the browser makes no font-service request.

## Corrections and evidence boundaries

- Joshua clarified the replica boundary. Initial same-database schemas were replaced with separate PMS and application databases, each with an isolated test counterpart. Task-created initial fixture schemas were removed, and the corrected demo was reseeded. Source schema remains exactly the supplied columns and constraints; no application metadata is stored there.
- First backend run exposed host-local normalization of DST gaps. DateTime now preserves wall fields before clinic timezone validation. An email/SMS test-context mismatch was corrected without weakening validation.
- Independent source review found version reuse, invisible review replies, incomplete validation, shared outgoing contacts and bootstrap compatibility; each was checked against source and resolved. See review/INDEPENDENT_REVIEW.md.
- Current-source backend run before the final late-review regression: 32 tests, 161 assertions, zero failures/errors/skips. A later regression now also covers review persistence after completed-visit refresh. Final revision results are in the freeze record.
- First browser runs exposed test locator errors and a five-second expectation below this host's observed request time. Source refresh also performed repeated per-row lookups; these became per-call record maps, retaining the lock and transaction boundary. No employer-volume speed or throughput claim is made.
- The development parser dependency's minimatch advisory was addressed through a scoped override; the installed dependency tree and final audit are checked separately from application tests.
- Full documented setup command completed successfully against the existing demo, preserving records. Startup was exercised through the supplied script and served Rails and compiled React on 3185.

No earlier application source/config/tests/history were read. No remote was configured, and no external publication or old-code comparison was performed. Agent source review, automated checks, browser observations and human acceptance are separate evidence categories.

## Readability follow-up

After the initial full six-check pass and commit `2c24e8c`, the agent identified overly dense React/CSS source formatting. Prettier expanded those sources, and frontend lint now enforces the format. Frontend tests, TypeScript/production build, lint/format, zero-vulnerability audit and both browser smoke scenarios were rechecked. Backend Git content stayed unchanged from the passing 33-test revision; no backend suite rerun was needed for this formatting-only change. The freeze record separates those evidence scopes.
