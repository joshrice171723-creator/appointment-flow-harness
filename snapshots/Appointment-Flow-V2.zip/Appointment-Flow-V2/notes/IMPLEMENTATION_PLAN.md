# Stage 0 — 2026-11-15

Preflight passed before application code: `python quality/verify_harness.py` verified the original manifest, PDF and ten PNG screenshots. Read the assessment PDF, every product-spec document, coding standards, architecture guardrails, review rubric and deliverable rules. Inspected the supplied landing, board, appointments, SMS and empty email images. The current workspace initially contained only `.idea`; no existing application, Git repository or remote. No previous implementation was inspected.

## Chosen for this rebuild

- Rails API, PostgreSQL and React/TypeScript with Vite; one repository and same-origin production assets served by Rails. Native Windows development; isolated PostgreSQL container.
- Separate PostgreSQL PMS replica database reproduces exactly the supplied source tables in its public schema. A dedicated runtime connection can SELECT but cannot mutate them. A different application database holds snapshots, appointment versions, confirmations, fake messages, inbound replies, opt-outs, tasks and local verification history. This replaces the initial same-database schema split after Joshua clarified the replica boundary.
- Explicit refresh before every batch; full source read and local update under one transaction and advisory lock. Empty, missing or failed reads block sends and preserve the previous snapshot. Five-minute replication lag remains an upstream limitation.
- Clinic timezone mapping is explicit (Austin America/Chicago, Phoenix America/Phoenix). Invalid or ambiguous wall-clock times become holds. No inference from state abbreviations.
- Manual batch entrypoint; initial 7-day request, 6-day backup email if SMS unanswered, 3-day follow-up, 1-day final. Coalesce missed steps. Clinic-local send window 10:00–18:00. Fake delivery records and database uniqueness plus transaction locks prevent duplicate logical sends.
- Exact YES confirms only one current, future, scheduled appointment with an unambiguous authorized recipient and matching outbound context. Exact STOP persists by clinic/channel/recipient. Other and stale replies require staff review. Confirmation and source outcome are separate facts.
- Conservative consent assumption: adult patient's own valid contact is permitted in this synthetic demo unless opted out; minors need explicitly verified guardian authorization. Unsupported language and verified/source conflicts block outreach.
- Front desk clinic/staff stub, board, appointments, patient follow-up/verification; aggregate-only leadership endpoint; simulated SMS/email inbox. Broad screenshot styling, no pixel-copy requirement.

## Delivery sequence

1. Database ownership and snapshot, reminder, inbound and follow-up rules with focused tests.
2. Connected React workspaces, meaningful empty/error/loading states, retained save drafts.
3. Configure and run harness quality gate, database concurrency/safety tests, UI smoke checks and independent reviewer session. Fix supported findings, record evidence and freeze.

No old-code comparison, external publication, live communications, production authentication, booking or self-service rescheduling. Candidate authors final DECISIONS.md.
