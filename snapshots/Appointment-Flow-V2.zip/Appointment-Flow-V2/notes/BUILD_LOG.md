# Build log — generated only from actual work

The agent should append factual, dated entries: requirements addressed, test commands + actual output, meaningful choices, and blockers. Never insert fictional results or commit hashes.
