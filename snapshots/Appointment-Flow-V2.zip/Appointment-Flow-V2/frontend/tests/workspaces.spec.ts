import { expect, test } from '@playwright/test'

test('workspaces, clinic board, date filters, contact detail and aggregate leadership', async ({
  page,
}) => {
  const errors: string[] = []
  page.on('pageerror', (error) => errors.push(error.message))
  await page.goto('/')
  await expect(page.getByRole('heading', { name: 'Workspaces' })).toBeVisible()
  await page.screenshot({ path: '../tmp/screenshots/workspaces.png', fullPage: true })
  await page.getByRole('button', { name: 'Open front desk' }).click()
  await expect(page.getByRole('heading', { name: 'Patient flow', exact: true })).toBeVisible()
  await expect(page.getByText('matching work items')).toBeVisible()
  await page.getByRole('button', { name: 'Run fake reminders' }).click()
  await expect(page.getByRole('status')).toContainText('fake delivery attempts recorded')
  await page.getByLabel('Find a patient').fill('Not a patient')
  await expect(page.getByText('No follow-up items match these filters.')).toBeVisible()
  await page.getByLabel('Find a patient').fill('')
  await page.screenshot({ path: '../tmp/screenshots/front-desk.png', fullPage: true })
  await page.getByRole('button', { name: 'Appointments', exact: true }).click()
  await page.getByLabel('Jump to date').fill('2026-11-22')
  await expect(page.getByRole('cell', { name: /Avery Demo/ })).toBeVisible()
  await page
    .getByRole('row', { name: /Avery Demo/ })
    .getByRole('button', { name: 'Patient details' })
    .click()
  await expect(page.getByRole('heading', { name: 'Avery Demo' })).toBeVisible()
  await page.getByRole('button', { name: 'Verify or correct contact' }).click()
  await expect(page.getByRole('button', { name: 'Save verified contact' })).toBeVisible()
  await page.screenshot({ path: '../tmp/screenshots/patient-details.png', fullPage: true })
  await page.getByRole('button', { name: 'Workspaces' }).click()
  await page.getByRole('combobox', { name: 'Clinic', exact: true }).selectOption('2')
  await page.getByRole('button', { name: 'Open front desk' }).click()
  await expect(page.getByText('Phoenix', { exact: true })).toBeVisible()
  await page.getByRole('button', { name: 'Workspaces' }).click()
  await page.getByRole('button', { name: 'Open Apex leadership' }).click()
  await expect(page.getByRole('heading', { name: 'Clinic comparison' })).toBeVisible()
  await expect(page.getByText('Avery Demo')).toHaveCount(0)
  await page.getByText('Reminder activity and contact holds', { exact: true }).click()
  await page.screenshot({ path: '../tmp/screenshots/leadership.png', fullPage: true })
  expect(errors).toEqual([])
})

test('patient SMS and email reply flow and narrow layout', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('button', { name: 'Open patient workspace' }).click()
  await page.getByRole('combobox', { name: 'Clinic', exact: true }).selectOption('1')
  await page
    .getByRole('combobox', { name: 'Patient', exact: true })
    .selectOption({ label: 'Avery Demo' })
  await expect(page.getByRole('heading', { name: 'Message history' })).toBeVisible()
  await expect(page.getByText(/Reply YES to confirm/).first()).toBeVisible()
  await page.getByLabel('Your reply', { exact: true }).fill('YES')
  await page.getByRole('button', { name: 'Send simulated reply' }).click()
  await expect(page.getByRole('status')).toHaveText('Reply recorded: confirmed.')
  await page.getByRole('button', { name: 'Email', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Message history' })).toBeVisible()
  await page.getByLabel('Your reply', { exact: true }).fill('Can someone call me?')
  await page.getByRole('button', { name: 'Send simulated reply' }).click()
  await expect(page.getByRole('status')).toHaveText('Reply recorded: needs review.')
  await expect(page.getByText('Can someone call me?', { exact: true }).first()).toBeVisible()
  await page.setViewportSize({ width: 390, height: 844 })
  await page.screenshot({ path: '../tmp/screenshots/inbox-narrow.png', fullPage: true })
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
  await page.getByRole('button', { name: 'Workspaces' }).click()
  await page.screenshot({ path: '../tmp/screenshots/workspaces-narrow.png', fullPage: true })
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
})
