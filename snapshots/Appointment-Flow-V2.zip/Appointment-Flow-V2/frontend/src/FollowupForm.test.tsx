import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { FollowupForm } from './PatientDetails'
import type { Visit, WorkItem } from './api'

const visit: Visit = {
  id: 1,
  patient_id: 1,
  patient: 'Avery Demo',
  wall_time: '2026-11-22 14:00:00',
  starts_at: '2026-11-22T20:00:00Z',
  provider: 'Dr. Demo',
  source_status: 'scheduled',
  confirmed: false,
  disposition: null,
  time_error: null,
  version: 'current-revision',
  review: false,
}
const item: WorkItem = {
  id: 1,
  visit_id: 1,
  patient_id: 1,
  patient: 'Avery Demo',
  wall_time: visit.wall_time,
  reason: 'no_reply',
  description: 'Call this patient.',
  status: 'needs_attention',
  staff: null,
  followups: [],
}

afterEach(() => {
  cleanup()
  vi.unstubAllGlobals()
})

describe('staff follow-up saves', () => {
  it('S19 retains a rejected draft and reuses the same save ID on retry', async () => {
    const fetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 422,
      json: async () => ({ error: 'The appointment changed. Refresh before saving.' }),
    })
    vi.stubGlobal('fetch', fetch)
    const onSaved = vi.fn()
    render(
      <FollowupForm
        item={item}
        visit={visit}
        path="/api/clinics/1"
        staff="Taylor Morgan"
        onSaved={onSaved}
      />,
    )
    fireEvent.change(screen.getByLabelText('Follow-up note'), {
      target: { value: 'Spoke to the patient.' },
    })
    fireEvent.click(screen.getByRole('button', { name: 'Record follow-up' }))
    await screen.findByRole('alert')
    expect(screen.getByLabelText('Follow-up note')).toHaveValue('Spoke to the patient.')
    const first = JSON.parse(String(fetch.mock.calls[0][1].body)) as { request_id: string }
    fireEvent.click(screen.getByRole('button', { name: 'Record follow-up' }))
    await waitFor(() => expect(fetch).toHaveBeenCalledTimes(2))
    const second = JSON.parse(String(fetch.mock.calls[1][1].body)) as { request_id: string }
    expect(second.request_id).toBe(first.request_id)
    expect(onSaved).not.toHaveBeenCalled()
  })

  it('keeps the note and gives recovery instructions after a network interruption', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Network disconnected')))
    render(
      <FollowupForm
        item={item}
        visit={visit}
        path="/api/clinics/1"
        staff="Taylor Morgan"
        onSaved={vi.fn()}
      />,
    )
    fireEvent.change(screen.getByLabelText('Follow-up note'), {
      target: { value: 'Draft before connection loss.' },
    })
    fireEvent.click(screen.getByRole('button', { name: 'Record follow-up' }))
    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Refresh and inspect history before retrying',
    )
    expect(screen.getByLabelText('Follow-up note')).toHaveValue('Draft before connection loss.')
  })
})
