import { useState } from 'react'
import { clinicPath, request, useResource } from './api'
import type { Clinic, PatientData, Workspace } from './api'

export function Inbox({ clinics, staff }: { clinics: Clinic[]; staff: string }) {
  const [clinicId, setClinicId] = useState('')
  return (
    <main className="inbox">
      <h1>Patient inbox</h1>
      <p className="muted">Simulated messages for fictional patients.</p>
      <label>
        Clinic
        <select value={clinicId} onChange={(event) => setClinicId(event.target.value)}>
          <option value="">Select a clinic</option>
          {clinics.map((clinic) => (
            <option key={clinic.id} value={clinic.id}>
              {clinic.name}
            </option>
          ))}
        </select>
      </label>
      {clinicId && (
        <PatientPicker key={clinicId} path={clinicPath(Number(clinicId))} staff={staff} />
      )}
    </main>
  )
}

function PatientPicker({ path, staff }: { path: string; staff: string }) {
  const { data, error, reload } = useResource<Workspace>(`${path}/workspace`, staff)
  const [patientId, setPatientId] = useState('')
  return (
    <>
      {error && (
        <p role="alert">
          {error} <button onClick={reload}>Reload</button>
        </p>
      )}
      <label>
        Patient
        <select value={patientId} onChange={(event) => setPatientId(event.target.value)}>
          <option value="">Select a fictional patient</option>
          {data?.patients.map((patient) => (
            <option key={patient.id} value={patient.id}>
              {patient.name}
            </option>
          ))}
        </select>
      </label>
      {patientId && <Conversation key={patientId} path={path} patientId={Number(patientId)} />}
    </>
  )
}

function Conversation({ path, patientId }: { path: string; patientId: number }) {
  const { data, error, reload } = useResource<PatientData>(`${path}/patients/${patientId}`)
  const [channel, setChannel] = useState('sms')
  const [body, setBody] = useState('')
  const [eventId, setEventId] = useState(() => crypto.randomUUID())
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  async function send(event: React.SubmitEvent) {
    event.preventDefault()
    if (!data) return
    setBusy(true)
    setNotice('')
    const latest = data.messages
      .filter((message) => message.channel === channel && message.status === 'sent')
      .at(-1)
    const recipient =
      channel === 'sms' ? data.patient.details.wireless_phone : data.patient.details.email
    try {
      const result = await request<{ result: string }>(`${path}/replies`, {
        method: 'POST',
        body: JSON.stringify({
          channel,
          recipient,
          body,
          external_id: eventId,
          message_id: latest?.id,
        }),
      })
      setNotice(`Reply recorded: ${result.result.replaceAll('_', ' ')}.`)
      setBody('')
      setEventId(crypto.randomUUID())
      reload()
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'Reply failed.')
    } finally {
      setBusy(false)
    }
  }
  if (error) return <p role="alert">{error}</p>
  if (!data) return <p aria-busy="true">Loading conversation…</p>
  const timeline = [
    ...data.messages
      .filter((message) => message.channel === channel)
      .map((message) => ({
        id: `m${message.id}`,
        at: message.sent_at,
        body: message.body,
        label: `Clinic ${channel === 'sms' ? 'text' : 'email'} · ${message.status}`,
      })),
    ...data.replies
      .filter((reply) => reply.channel === channel)
      .map((reply) => ({
        id: `r${reply.id}`,
        at: reply.received_at,
        body: reply.body,
        label: `Your reply · ${reply.result.replaceAll('_', ' ')}`,
      })),
  ].sort((a, b) => a.at.localeCompare(b.at))
  return (
    <>
      <div className="tabs">
        <button
          aria-pressed={channel === 'sms'}
          onClick={() => {
            setChannel('sms')
            setEventId(crypto.randomUUID())
            setNotice('')
          }}
        >
          Text messages
        </button>
        <button
          aria-pressed={channel === 'email'}
          onClick={() => {
            setChannel('email')
            setEventId(crypto.randomUUID())
            setNotice('')
          }}
        >
          Email
        </button>
      </div>
      <h2>Message history</h2>
      {timeline.length ? (
        <ol className="messages">
          {timeline.map((message) => (
            <li className={message.label.startsWith('Your') ? 'incoming' : ''} key={message.id}>
              <small>
                {message.label} · {new Date(message.at).toLocaleString()}
              </small>
              <p>{message.body}</p>
            </li>
          ))}
        </ol>
      ) : (
        <p className="empty">
          No simulated {channel === 'sms' ? 'texts' : 'emails'} for this patient yet.
        </p>
      )}
      <form className="card" onSubmit={send}>
        <label>
          Your reply
          <textarea
            required
            maxLength={2000}
            value={body}
            onChange={(event) => {
              setBody(event.target.value)
              setEventId(crypto.randomUUID())
            }}
            placeholder="YES, NO, STOP, or a question"
          />
        </label>
        <p className="muted">
          Replies use the latest sent message as context. Shared contacts and unclear replies go to
          staff.
        </p>
        <button disabled={busy}>{busy ? 'Recording…' : 'Send simulated reply'}</button>
        {notice && <p role="status">{notice}</p>}
      </form>
    </>
  )
}
