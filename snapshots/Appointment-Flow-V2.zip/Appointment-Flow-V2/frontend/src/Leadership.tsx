import { useState } from 'react'
import { useResource } from './api'
import type { Report } from './api'

export function Leadership({ now }: { now: string }) {
  const [month, setMonth] = useState(now.slice(0, 7))
  const { data, error, reload } = useResource<Report>(`/api/leadership?month=${month}`)
  return (
    <main>
      <span className="eyebrow">Aggregate reporting</span>
      <div className="page-title">
        <h1>Apex leadership</h1>
        <label>
          Reporting month
          <input
            type="month"
            value={month}
            onChange={(event) => {
              if (event.target.value) setMonth(event.target.value)
            }}
          />
        </label>
      </div>
      {error && (
        <p className="alert" role="alert">
          {error} <button onClick={reload}>Reload</button>
        </p>
      )}
      {!data && !error && <p aria-busy="true">Loading clinic outcomes…</p>}
      {data && (
        <>
          <p className="muted">{data.definition}</p>
          <div className="report-cards">
            {data.clinics.map((clinic) => (
              <section className="card clinic-report" key={clinic.id}>
                <span className="eyebrow">{clinic.name}</span>
                <h2>{clinic.completion_rate === null ? '—' : `${clinic.completion_rate}%`}</h2>
                <p>Recorded visit completion</p>
                <div
                  className="bar"
                  aria-label={`${clinic.completed} completed out of ${clinic.recorded} recorded visits`}
                >
                  <span style={{ width: `${clinic.completion_rate ?? 0}%` }} />
                </div>
                <dl>
                  <dt>Recorded visits</dt>
                  <dd>{clinic.recorded}</dd>
                  <dt>Completed</dt>
                  <dd>{clinic.completed}</dd>
                  <dt>Rescheduled</dt>
                  <dd>{clinic.rescheduled}</dd>
                  <dt>Canceled</dt>
                  <dd>{clinic.canceled}</dd>
                  <dt>Unknown outcome</dt>
                  <dd>{clinic.unknown}</dd>
                </dl>
              </section>
            ))}
          </div>
          <section className="card table-wrap">
            <h2>Clinic comparison</h2>
            <table>
              <thead>
                <tr>
                  <th>Clinic</th>
                  <th>Recorded visits</th>
                  <th>Completed</th>
                  <th>Confirmed</th>
                  <th>Completion</th>
                </tr>
              </thead>
              <tbody>
                {data.clinics.map((clinic) => (
                  <tr key={clinic.id}>
                    <td>{clinic.name}</td>
                    <td>{clinic.recorded}</td>
                    <td>{clinic.completed}</td>
                    <td>{clinic.confirmed}</td>
                    <td>
                      {clinic.completion_rate === null
                        ? 'No records'
                        : `${clinic.completion_rate}%`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="muted">
              Confirmation is a communication state, separate from the PMS visit outcome.
            </p>
          </section>
          <details className="card">
            <summary>Reminder activity and contact holds</summary>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Clinic</th>
                    <th>Attempts</th>
                    <th>Fake sent</th>
                    <th>Failed</th>
                    <th>Open contact holds</th>
                    <th>Staff follow-ups</th>
                  </tr>
                </thead>
                <tbody>
                  {data.clinics.map((clinic) => (
                    <tr key={clinic.id}>
                      <td>{clinic.name}</td>
                      <td>{clinic.delivery_attempts}</td>
                      <td>{clinic.sent}</td>
                      <td>{clinic.failed}</td>
                      <td>{clinic.contact_holds}</td>
                      <td>{clinic.followups}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="muted">
              Activity belongs to the appointments in the selected clinic-local month; attempts
              include failed fake deliveries. Holds count open tasks, and follow-ups count recorded
              staff actions.
            </p>
          </details>
        </>
      )}
    </main>
  )
}
