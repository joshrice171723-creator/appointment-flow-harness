import { useEffect, useState } from 'react'

export type Clinic = {
  id: number
  name: string
  timezone: string
  synced_at: string | null
  sync_error: string | null
}
export type Visit = {
  id: number
  patient_id: number
  patient: string
  wall_time: string
  starts_at: string | null
  provider: string
  source_status: string
  confirmed: boolean
  disposition: string | null
  time_error: string | null
  version: string
  review: boolean
}
export type Followup = { staff: string; outcome: string; note: string; created_at: string }
export type WorkItem = {
  id: number
  visit_id: number
  patient_id: number
  patient: string
  wall_time: string
  reason: string
  description: string
  status: string
  staff: string | null
  followups: Followup[]
}
export type Contact = {
  first_name: string
  last_name: string
  birthdate: string
  wireless_phone: string | null
  email: string | null
  preferred_language: string
  guardian_authorized?: boolean
}
export type Person = {
  id: number
  name: string
  source: Contact
  details: Contact
  verified: boolean
  conflict: boolean
}
export type Message = {
  id: number
  channel: string
  body: string
  status: string
  sent_at: string
  step: string
  version: string
}
export type Reply = {
  id: number
  channel: string
  body: string
  result: string
  received_at: string
}
export type PatientData = {
  patient: Person
  visits: Visit[]
  messages: Message[]
  replies: Reply[]
  work_items: WorkItem[]
  changes: { staff: string; details: Contact; created_at: string }[]
}
export type Workspace = {
  clinic: Clinic
  visits: Visit[]
  work_items: WorkItem[]
  patients: { id: number; name: string }[]
}
export type Bootstrap = {
  clinics: Clinic[]
  staff: string[]
  now: string
  simulated_clock: boolean
}
export type ClinicReport = {
  id: number
  name: string
  recorded: number
  completed: number
  rescheduled: number
  canceled: number
  unknown: number
  completion_rate: number | null
  confirmed: number
  delivery_attempts: number
  sent: number
  failed: number
  contact_holds: number
  followups: number
}
export type Report = { month: string; clinics: ClinicReport[]; definition: string }

export async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  let response: Response
  try {
    response = await fetch(url, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...options.headers },
    })
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw error
    throw new Error(
      'Connection interrupted. Refresh and inspect history before retrying. Your draft is kept.',
      { cause: error },
    )
  }
  const data: unknown = await response.json()
  if (!response.ok) {
    throw new Error(
      typeof data === 'object' && data !== null && 'error' in data
        ? String(data.error)
        : `Request failed (${response.status}).`,
    )
  }
  // The same-repository Rails API owns these response contracts; TypeScript types live here.
  return data as T
}

// Actual shared lifecycle: cancel reads on navigation and never render the previous URL's data.
export function useResource<T>(url: string, staff?: string) {
  const [revision, setRevision] = useState(0)
  const [state, setState] = useState<{ url: string; data?: T; error?: string }>({ url: '' })
  useEffect(() => {
    const controller = new AbortController()
    request<T>(url, { signal: controller.signal, headers: staff ? { 'X-Demo-Staff': staff } : {} })
      .then((data) => setState({ url, data }))
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setState({
            url,
            error: error instanceof Error ? error.message : 'Unable to load records.',
          })
      })
    return () => controller.abort()
  }, [url, staff, revision])
  return {
    data: state.url === url ? state.data : undefined,
    error: state.url === url ? state.error : undefined,
    reload: () => setRevision((value) => value + 1),
  }
}

export const clinicPath = (id: number) => `/api/clinics/${id}`
export const dateLabel = (value: string) =>
  new Date(`${value.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  })
export const wallLabel = (value: string) => `${dateLabel(value)}, ${value.slice(11, 16)}`
export const outcomeLabel = (status: string) =>
  ({ complete: 'Completed', broken: 'Canceled', unscheduled: 'Rescheduled', scheduled: 'Unknown' })[
    status
  ] ?? 'Unknown'
export const issueLabel = (reason: string) =>
  ({
    no_reply: 'No confirmation',
    contact_hold: 'Reminders blocked',
    delivery_failed: 'Delivery failed',
    reply_review: 'Reply needs review',
  })[reason] ?? reason
