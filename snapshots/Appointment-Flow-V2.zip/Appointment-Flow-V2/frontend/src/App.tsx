import { useState } from 'react'
import { clinicPath, useResource } from './api'
import type { Bootstrap } from './api'
import { FrontDesk } from './FrontDesk'
import { Inbox } from './Inbox'
import { Leadership } from './Leadership'

export default function App() {
  const { data, error, reload } = useResource<Bootstrap>('/api/clinics')
  const [screen, setScreen] = useState('workspaces')
  const [clinicId, setClinicId] = useState(1)
  const [staff, setStaff] = useState('Taylor Morgan')
  if (error)
    return (
      <main>
        <h1>Unable to load workspaces</h1>
        <p role="alert">{error}</p>
        <button onClick={reload}>Try again</button>
      </main>
    )
  if (!data)
    return (
      <main aria-busy="true">
        <p>Loading workspaces…</p>
      </main>
    )
  const clinic = data.clinics.find((clinic) => clinic.id === clinicId)
  return (
    <>
      <header className="topbar">
        <a
          className="brand"
          href="#"
          onClick={() => setScreen('workspaces')}
          aria-label="Apex workspaces"
        >
          <span className="mark">A↗</span>
          <span>
            <b>APEX</b>
            <small>APPOINTMENT FLOW</small>
          </span>
        </a>
        <nav aria-label="Main navigation">
          <button className="text-button" onClick={() => setScreen('workspaces')}>
            Workspaces ↗
          </button>
        </nav>
      </header>
      <div className="clock">
        {data.simulated_clock ? 'Demo clock' : 'Current time'} ·{' '}
        {new Date(data.now).toLocaleString('en-US', {
          timeZone: clinic?.timezone ?? 'America/Chicago',
          dateStyle: 'medium',
          timeStyle: 'short',
        })}{' '}
        · {clinic?.timezone ?? 'America/Chicago'} · Fake messaging only
      </div>
      {screen === 'workspaces' && (
        <main className="workspace-entry">
          <h1>Workspaces</h1>
          <div className="workspace-cards">
            <section className="card entry">
              <h2>Front desk</h2>
              <p>Review appointments and follow up with patients.</p>
              <label>
                Clinic
                <select
                  value={clinicId}
                  onChange={(event) => setClinicId(Number(event.target.value))}
                >
                  {data.clinics.map((clinic) => (
                    <option key={clinic.id} value={clinic.id}>
                      {clinic.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Staff member <span className="muted">· demo sign-in</span>
                <select value={staff} onChange={(event) => setStaff(event.target.value)}>
                  {data.staff.map((name) => (
                    <option key={name}>{name}</option>
                  ))}
                </select>
              </label>
              <button onClick={() => setScreen('frontdesk')}>
                Open front desk <span>→</span>
              </button>
            </section>
            <section className="card entry leadership-entry">
              <h2>Apex leadership</h2>
              <p>Aggregated clinic outcomes and reminder activity.</p>
              <div className="clinic-total">
                {data.clinics.length}
                <small>clinics</small>
              </div>
              <p className="muted">No patient details.</p>
              <button onClick={() => setScreen('leadership')}>
                Open Apex leadership <span>→</span>
              </button>
            </section>
            <section className="card entry">
              <h2>Patient demo</h2>
              <p>Inspect fake SMS and email messages and simulate a reply.</p>
              <p className="muted">Use the fictional patients supplied with this demo.</p>
              <button onClick={() => setScreen('inbox')}>
                Open patient workspace <span>→</span>
              </button>
            </section>
          </div>
        </main>
      )}
      {screen === 'frontdesk' && clinic && (
        <FrontDesk
          key={`${clinicId}:${staff}`}
          clinic={clinic}
          staff={staff}
          path={clinicPath(clinicId)}
          now={data.now}
        />
      )}
      {screen === 'leadership' && <Leadership now={data.now} />}
      {screen === 'inbox' && <Inbox clinics={data.clinics} staff={staff} />}
    </>
  )
}
