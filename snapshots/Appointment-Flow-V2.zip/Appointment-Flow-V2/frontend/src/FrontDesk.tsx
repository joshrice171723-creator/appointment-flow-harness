import { useState } from 'react'
import {
  clinicPath,
  dateLabel,
  issueLabel,
  outcomeLabel,
  request,
  useResource,
  wallLabel,
} from './api'
import type { Clinic, Visit, Workspace, WorkItem } from './api'
import { PatientDetails } from './PatientDetails'

export function FrontDesk({
  clinic,
  staff,
  path,
  now,
}: {
  clinic: Clinic
  staff: string
  path: string
  now: string
}) {
  const { data, error, reload } = useResource<Workspace>(`${path}/workspace`, staff)
  const [tab, setTab] = useState('board')
  const [patientId, setPatientId] = useState<number | null>(null)
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  async function run(action: string) {
    setBusy(true)
    setNotice('')
    try {
      const result = await request<{ message: string }>(`${path}/${action}`, {
        method: 'POST',
        headers: { 'X-Demo-Staff': staff },
      })
      setNotice(result.message)
      reload()
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'Action failed.')
    } finally {
      setBusy(false)
    }
  }
  const openPatient = (id: number) => setPatientId(id)
  return (
    <main>
      <div className="section-nav">
        <div>
          <span className="eyebrow">{clinic.name}</span>
          <p className="muted">
            {staff} · {clinic.timezone}
          </p>
        </div>
        <div className="tabs">
          <button
            aria-pressed={tab === 'board' && !patientId}
            onClick={() => {
              setTab('board')
              setPatientId(null)
            }}
          >
            Patient flow
          </button>
          <button
            aria-pressed={tab === 'appointments' && !patientId}
            onClick={() => {
              setTab('appointments')
              setPatientId(null)
            }}
          >
            Appointments
          </button>
        </div>
      </div>
      <div className="page-title">
        <h1>{patientId ? 'Patient details' : tab === 'board' ? 'Patient flow' : 'Appointments'}</h1>
        <div className="actions">
          <button className="secondary" disabled={busy} onClick={() => run('refresh')}>
            Refresh PMS
          </button>
          <button disabled={busy} onClick={() => run('batches')}>
            {busy ? 'Working…' : 'Run fake reminders'}
          </button>
        </div>
      </div>
      <p className="muted sync">
        Last PMS sync:{' '}
        {data?.clinic.synced_at
          ? new Date(data.clinic.synced_at).toLocaleString('en-US', { timeZone: clinic.timezone })
          : 'Not synced'}{' '}
        · {clinic.timezone}
      </p>
      {data?.clinic.sync_error && (
        <p className="alert" role="alert">
          {data.clinic.sync_error}
        </p>
      )}
      {notice && (
        <p className="notice" role="status">
          {notice}
        </p>
      )}
      {error && (
        <p className="alert" role="alert">
          {error} <button onClick={reload}>Reload</button>
        </p>
      )}
      {!data && !error && <p aria-busy="true">Loading clinic records…</p>}
      {patientId ? (
        <PatientDetails
          key={patientId}
          path={path}
          patientId={patientId}
          staff={staff}
          onBack={() => {
            setPatientId(null)
            reload()
          }}
        />
      ) : (
        data &&
        (tab === 'board' ? (
          <Board items={data.work_items} onOpen={openPatient} />
        ) : (
          <Appointments visits={data.visits} now={now} clinic={clinic} onOpen={openPatient} />
        ))
      )}
    </main>
  )
}

function Board({ items, onOpen }: { items: WorkItem[]; onOpen: (id: number) => void }) {
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [resolved, setResolved] = useState(false)
  const [page, setPage] = useState(1)
  const matches = items.filter(
    (item) =>
      (resolved ? item.status === 'resolved' : item.status !== 'resolved') &&
      item.patient.toLowerCase().includes(search.toLowerCase()) &&
      (filter === 'all' || item.reason === filter),
  )
  const pages = Math.max(1, Math.ceil(matches.length / 8))
  const visible = matches.slice((Math.min(page, pages) - 1) * 8, Math.min(page, pages) * 8)
  const columns = resolved ? ['resolved'] : ['needs_attention', 'in_progress']
  return (
    <>
      <div className="summary">
        {[
          ['Needs attention', 'needs_attention', 'Open concerns and follow-up'],
          ['In progress', 'in_progress', 'Assigned to a staff member'],
          ['Resolved', 'resolved', 'Follow-up history'],
        ].map(([title, status, help]) => (
          <section className="card stat" key={status}>
            <p>{title}</p>
            <strong>{items.filter((item) => item.status === status).length}</strong>
            <small>{help}</small>
          </section>
        ))}
      </div>
      <div className="toolbar">
        <div className="tabs">
          <button
            aria-pressed={!resolved}
            onClick={() => {
              setResolved(false)
              setPage(1)
            }}
          >
            Active work
          </button>
          <button
            aria-pressed={resolved}
            onClick={() => {
              setResolved(true)
              setPage(1)
            }}
          >
            Resolved
          </button>
        </div>
        <label className="search">
          Find a patient
          <input
            type="search"
            value={search}
            onChange={(event) => {
              setSearch(event.target.value)
              setPage(1)
            }}
            placeholder="Patient name"
          />
        </label>
        <label>
          Follow-up type
          <select
            value={filter}
            onChange={(event) => {
              setFilter(event.target.value)
              setPage(1)
            }}
          >
            <option value="all">All follow-up types</option>
            {['no_reply', 'contact_hold', 'delivery_failed', 'reply_review'].map((reason) => (
              <option key={reason} value={reason}>
                {issueLabel(reason)}
              </option>
            ))}
          </select>
        </label>
      </div>
      {matches.length === 0 ? (
        <div className="card empty">No follow-up items match these filters.</div>
      ) : (
        <div className={`board ${resolved ? 'single' : ''}`}>
          {columns.map((status) => (
            <section className={`queue ${status}`} key={status}>
              <h2>
                {status === 'needs_attention'
                  ? 'Needs attention'
                  : status === 'in_progress'
                    ? 'In progress'
                    : 'Resolved'}{' '}
                <small>{matches.filter((item) => item.status === status).length}</small>
              </h2>
              {visible
                .filter((item) => item.status === status)
                .map((item) => (
                  <button
                    className="work-card"
                    key={item.id}
                    onClick={() => onOpen(item.patient_id)}
                  >
                    <span className={`pill ${item.reason}`}>{issueLabel(item.reason)}</span>
                    <strong>
                      {item.patient}
                      <span className="arrow">↗</span>
                    </strong>
                    <p>{item.description}</p>
                    <small>{wallLabel(item.wall_time)}</small>
                    <div className="owner">{item.staff ?? 'Unassigned'}</div>
                  </button>
                ))}
            </section>
          ))}
        </div>
      )}
      <div className="pagination">
        <span>{matches.length} matching work items</span>
        <button
          className="secondary"
          disabled={page <= 1}
          onClick={() => setPage((value) => value - 1)}
        >
          Previous
        </button>
        <span>
          Page {Math.min(page, pages)} of {pages}
        </span>
        <button
          className="secondary"
          disabled={page >= pages}
          onClick={() => setPage((value) => value + 1)}
        >
          Next
        </button>
      </div>
    </>
  )
}

function shiftDate(date: string, days: number) {
  const value = new Date(`${date}T12:00:00Z`)
  value.setUTCDate(value.getUTCDate() + days)
  return value.toISOString().slice(0, 10)
}

function Appointments({
  visits,
  now,
  clinic,
  onOpen,
}: {
  visits: Visit[]
  now: string
  clinic: Clinic
  onOpen: (id: number) => void
}) {
  const today = new Intl.DateTimeFormat('en-CA', {
    timeZone: clinic.timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(now))
  const [date, setDate] = useState(today)
  const [filter, setFilter] = useState('all')
  const day = new Date(`${date}T12:00:00Z`).getUTCDay()
  const monday = shiftDate(date, -(day + 6) % 7)
  const selected = visits.filter((visit) => visit.wall_time.startsWith(date))
  const accepts = (visit: Visit, value: string) =>
    value === 'all' ||
    (value === 'confirmed' && visit.confirmed) ||
    (value === 'unconfirmed' && !visit.confirmed) ||
    (value === 'review' && visit.review)
  const visible = selected.filter((visit) => accepts(visit, filter))
  return (
    <>
      <section className="card calendar">
        <div className="actions">
          <button className="secondary" onClick={() => setDate(shiftDate(date, -7))}>
            ← Previous week
          </button>
          <button className="secondary" onClick={() => setDate(today)}>
            Today
          </button>
          <button className="secondary" onClick={() => setDate(shiftDate(date, 7))}>
            Next week →
          </button>
          <label>
            Jump to date
            <input
              type="date"
              value={date}
              onChange={(event) => {
                if (event.target.value) setDate(event.target.value)
              }}
            />
          </label>
        </div>
        <div className="week">
          {Array.from({ length: 7 }, (_, index) => shiftDate(monday, index)).map((day) => (
            <button
              className="secondary"
              aria-pressed={date === day}
              key={day}
              onClick={() => setDate(day)}
            >
              {dateLabel(day)}
              <small>
                {visits.filter((visit) => visit.wall_time.startsWith(day)).length} visits
              </small>
            </button>
          ))}
        </div>
      </section>
      <div className="tabs filter-tabs">
        {[
          ['all', 'All appointments'],
          ['confirmed', 'Confirmed'],
          ['unconfirmed', 'Unconfirmed'],
          ['review', 'Replies to review'],
        ].map(([value, label]) => (
          <button key={value} aria-pressed={filter === value} onClick={() => setFilter(value)}>
            {label} <span>{selected.filter((visit) => accepts(visit, value)).length}</span>
          </button>
        ))}
      </div>
      <div className="card table-wrap">
        <table>
          <caption className="sr-only">Appointments on {dateLabel(date)}</caption>
          <thead>
            <tr>
              <th>Patient</th>
              <th>Appointment · {clinic.timezone}</th>
              <th>Confirmation or reply</th>
              <th>PMS outcome</th>
              <th>Next step</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((visit) => (
              <tr key={visit.id}>
                <td>
                  <b>{visit.patient}</b>
                  <small>Visit #{visit.id}</small>
                </td>
                <td>
                  {wallLabel(visit.wall_time)}
                  <small>{visit.provider}</small>
                </td>
                <td>
                  <span
                    className={`pill ${visit.confirmed ? 'confirmed' : visit.review ? 'reply_review' : ''}`}
                  >
                    {visit.confirmed
                      ? 'Confirmed'
                      : visit.review
                        ? 'Reply needs review'
                        : 'Unconfirmed'}
                  </span>
                  {visit.disposition && <small>Staff recorded: {visit.disposition}</small>}
                  {visit.time_error && <small>{visit.time_error}</small>}
                </td>
                <td>{outcomeLabel(visit.source_status)}</td>
                <td>
                  <button className="text-button" onClick={() => onOpen(visit.patient_id)}>
                    Patient details →
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {visible.length === 0 && (
          <p className="empty">No appointments match this date and filter.</p>
        )}
      </div>
    </>
  )
}

export { clinicPath }
