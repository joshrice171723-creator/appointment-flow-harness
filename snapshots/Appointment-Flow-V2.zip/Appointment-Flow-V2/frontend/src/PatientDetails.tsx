import { useState } from 'react'
import { issueLabel, outcomeLabel, request, useResource, wallLabel } from './api'
import type { Contact, PatientData, Person, Visit, WorkItem } from './api'

export function PatientDetails({
  path,
  patientId,
  staff,
  onBack,
}: {
  path: string
  patientId: number
  staff: string
  onBack: () => void
}) {
  const { data, error, reload } = useResource<PatientData>(`${path}/patients/${patientId}`, staff)
  const [tab, setTab] = useState('followup')
  if (error)
    return (
      <p role="alert">
        {error} <button onClick={reload}>Reload</button>
      </p>
    )
  if (!data) return <p aria-busy="true">Loading patient…</p>
  return (
    <>
      <button className="text-button" onClick={onBack}>
        ← Back to clinic
      </button>
      <div className="patient-heading">
        <h2>{data.patient.name}</h2>
        <span className="pill">
          {data.work_items.some((item) => item.status !== 'resolved')
            ? 'Follow-up open'
            : 'No open follow-up'}
        </span>
      </div>
      <div className="patient-layout">
        <aside className="card">
          <ContactEditor patient={data.patient} path={path} staff={staff} onSaved={reload} />
          <details>
            <summary>Original PMS contact values</summary>
            <dl>
              <dt>Mobile</dt>
              <dd>{data.patient.source.wireless_phone ?? 'Missing'}</dd>
              <dt>Email</dt>
              <dd>{data.patient.source.email ?? 'Missing'}</dd>
              <dt>Birthdate</dt>
              <dd>{data.patient.source.birthdate ?? 'Missing'}</dd>
              <dt>Language</dt>
              <dd>{data.patient.source.preferred_language ?? 'Missing'}</dd>
            </dl>
          </details>
        </aside>
        <section>
          <div className="tabs">
            <button aria-pressed={tab === 'followup'} onClick={() => setTab('followup')}>
              Follow-up
            </button>
            <button aria-pressed={tab === 'visits'} onClick={() => setTab('visits')}>
              Appointments
            </button>
            <button aria-pressed={tab === 'activity'} onClick={() => setTab('activity')}>
              Activity
            </button>
          </div>
          {tab === 'followup' &&
            (data.work_items.length ? (
              data.work_items.map((item) => {
                const visit = data.visits.find((visit) => visit.id === item.visit_id)
                return (
                  visit && (
                    <FollowupForm
                      key={item.id}
                      item={item}
                      visit={visit}
                      staff={staff}
                      path={path}
                      onSaved={reload}
                    />
                  )
                )
              })
            ) : (
              <div className="card empty">No follow-up items for this patient.</div>
            ))}
          {tab === 'visits' &&
            data.visits.map((visit) => (
              <article className="card visit" key={visit.id}>
                <h3>{wallLabel(visit.wall_time)}</h3>
                <p>{visit.provider}</p>
                <p>
                  {visit.confirmed ? 'Confirmed' : 'Unconfirmed'} · PMS outcome:{' '}
                  {outcomeLabel(visit.source_status)}
                </p>
                {visit.disposition && (
                  <p>Staff recorded: {visit.disposition}. Update the appointment in the PMS.</p>
                )}
              </article>
            ))}
          {tab === 'activity' && (
            <div className="card activity">
              <h3>Communication and verification history</h3>
              {data.messages.map((message) => (
                <p key={`m${message.id}`}>
                  <b>
                    {message.channel.toUpperCase()} · {message.status}
                  </b>
                  <small>{new Date(message.sent_at).toLocaleString()}</small>
                  {message.body}
                </p>
              ))}
              {data.replies.map((reply) => (
                <p key={`r${reply.id}`}>
                  <b>Patient reply · {reply.result.replaceAll('_', ' ')}</b>
                  <small>{new Date(reply.received_at).toLocaleString()}</small>
                  {reply.body}
                </p>
              ))}
              {data.changes.map((change, index) => (
                <p key={`c${index}`}>
                  <b>Local details verified by {change.staff}</b>
                  <small>{new Date(change.created_at).toLocaleString()}</small>Mobile:{' '}
                  {change.details.wireless_phone || 'Missing'} · Email:{' '}
                  {change.details.email || 'Missing'}
                </p>
              ))}
              {data.messages.length + data.replies.length + data.changes.length === 0 && (
                <p>No activity recorded.</p>
              )}
            </div>
          )}
        </section>
      </div>
    </>
  )
}

function ContactEditor({
  patient,
  path,
  staff,
  onSaved,
}: {
  patient: Person
  path: string
  staff: string
  onSaved: () => void
}) {
  const [editing, setEditing] = useState(false)
  const [values, setValues] = useState<Contact>(patient.details)
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  function field(key: keyof Contact, value: string | boolean) {
    setValues((current) => ({ ...current, [key]: value }))
  }
  async function save(event: React.SubmitEvent) {
    event.preventDefault()
    setBusy(true)
    setStatus('')
    try {
      const result = await request<{ message: string }>(`${path}/patients/${patient.id}`, {
        method: 'PATCH',
        headers: { 'X-Demo-Staff': staff },
        body: JSON.stringify({ details: values }),
      })
      setStatus(result.message)
      setEditing(false)
      onSaved()
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Unable to save.')
    } finally {
      setBusy(false)
    }
  }
  return (
    <>
      <h3>Patient contact</h3>
      <span
        className={`pill ${patient.conflict ? 'contact_hold' : patient.verified ? 'confirmed' : ''}`}
      >
        {patient.conflict
          ? 'Source conflict'
          : patient.verified
            ? 'Locally verified'
            : 'Unverified PMS details'}
      </span>
      {patient.conflict && (
        <p role="alert">PMS values changed after verification. Review before sending reminders.</p>
      )}
      <dl>
        <dt>Mobile</dt>
        <dd>{patient.details.wireless_phone ?? 'Missing'}</dd>
        <dt>Email</dt>
        <dd>{patient.details.email ?? 'Missing'}</dd>
        <dt>Birthdate</dt>
        <dd>{patient.details.birthdate ?? 'Missing'}</dd>
        <dt>Preferred language</dt>
        <dd>{patient.details.preferred_language ?? 'Missing'}</dd>
      </dl>
      <button
        className="secondary"
        onClick={() => {
          setEditing((value) => !value)
          setValues(patient.details)
        }}
      >
        {editing ? 'Close editor' : 'Verify or correct contact'}
      </button>
      {editing && (
        <form onSubmit={save}>
          <label>
            Birthdate
            <input
              type="date"
              required
              value={values.birthdate ?? ''}
              onChange={(event) => field('birthdate', event.target.value)}
            />
          </label>
          <label>
            Mobile
            <input
              type="tel"
              value={values.wireless_phone ?? ''}
              onChange={(event) => field('wireless_phone', event.target.value)}
            />
          </label>
          <label>
            Email
            <input
              type="email"
              value={values.email ?? ''}
              onChange={(event) => field('email', event.target.value)}
            />
          </label>
          <label>
            Preferred language
            <select
              value={values.preferred_language}
              onChange={(event) => field('preferred_language', event.target.value)}
            >
              <option value="">Choose a supported language</option>
              <option value="en">English</option>
              <option value="es">Spanish</option>
            </select>
          </label>
          <label className="check">
            <input
              type="checkbox"
              checked={values.guardian_authorized ?? false}
              onChange={(event) => field('guardian_authorized', event.target.checked)}
            />
            Guardian contact authorization verified, if a minor
          </label>
          <p className="muted">
            For a minor, enter the authorized guardian's contact. This records a local correction;
            it does not change the PMS.
          </p>
          <button disabled={busy}>{busy ? 'Saving…' : 'Save verified contact'}</button>
        </form>
      )}
      {status && <p role="status">{status}</p>}
    </>
  )
}

export function FollowupForm({
  item,
  visit,
  path,
  staff,
  onSaved,
}: {
  item: WorkItem
  visit: Visit
  path: string
  staff: string
  onSaved: () => void
}) {
  const [note, setNote] = useState('')
  const [outcome, setOutcome] = useState('attempted')
  const [requestId, setRequestId] = useState(() => crypto.randomUUID())
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  async function claim() {
    setBusy(true)
    setError('')
    try {
      await request(`${path}/work_items/${item.id}/claim`, {
        method: 'POST',
        headers: { 'X-Demo-Staff': staff },
      })
      onSaved()
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Unable to assign.')
    } finally {
      setBusy(false)
    }
  }
  async function save(event: React.SubmitEvent) {
    event.preventDefault()
    setBusy(true)
    setError('')
    setNotice('')
    try {
      await request(`${path}/work_items/${item.id}/followups`, {
        method: 'POST',
        headers: { 'X-Demo-Staff': staff },
        body: JSON.stringify({ note, outcome, request_id: requestId, version: visit.version }),
      })
      setNote('')
      setRequestId(crypto.randomUUID())
      setNotice('Follow-up recorded.')
      onSaved()
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Unable to save.')
    } finally {
      setBusy(false)
    }
  }
  return (
    <article className="card followup">
      <div className="section-nav">
        <span className={`pill ${item.reason}`}>{issueLabel(item.reason)}</span>
        <span>{item.status.replaceAll('_', ' ')}</span>
      </div>
      <h3>{wallLabel(visit.wall_time)}</h3>
      <p>{item.description}</p>
      <p className="muted">
        {item.staff ? `Assigned to ${item.staff}` : 'Unassigned'} · {visit.provider}
      </p>
      {item.status !== 'resolved' && (
        <>
          <button className="secondary" disabled={busy} onClick={claim}>
            Assign to me
          </button>
          <form onSubmit={save}>
            <label>
              Outcome
              <select
                value={outcome}
                onChange={(event) => {
                  setOutcome(event.target.value)
                  setRequestId(crypto.randomUUID())
                }}
              >
                <option value="attempted">Contact attempted — keep open</option>
                <option value="confirmed">Confirmed current appointment</option>
                {item.reason === 'reply_review' && (
                  <option value="clarified">Reply clarified — confirm this appointment</option>
                )}
                <option value="rescheduled">Rescheduled — stop reminders</option>
                <option value="canceled">Canceled — stop reminders</option>
              </select>
            </label>
            <label>
              Follow-up note
              <textarea
                required
                maxLength={2000}
                value={note}
                onChange={(event) => {
                  setNote(event.target.value)
                  setRequestId(crypto.randomUUID())
                }}
                placeholder="Record what you learned or attempted."
              />
            </label>
            <button disabled={busy}>{busy ? 'Saving…' : 'Record follow-up'}</button>
          </form>
        </>
      )}
      {error && (
        <p className="alert" role="alert">
          {error}
        </p>
      )}
      {notice && <p role="status">{notice}</p>}
      {item.followups.length > 0 && (
        <details open={item.status === 'resolved'}>
          <summary>Follow-up history ({item.followups.length})</summary>
          {item.followups.map((followup, index) => (
            <div className="history-entry" key={index}>
              <b>
                {followup.outcome} · {followup.staff}
              </b>
              <small>{new Date(followup.created_at).toLocaleString()}</small>
              <p>{followup.note}</p>
            </div>
          ))}
        </details>
      )}
    </article>
  )
}
