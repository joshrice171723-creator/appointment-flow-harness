SELECT 'CREATE ROLE apex_app LOGIN PASSWORD ''local_demo_only'''
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname='apex_app')
\gexec
SELECT 'CREATE ROLE apex_pms_reader LOGIN PASSWORD ''local_reader_only'''
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname='apex_pms_reader')
\gexec
SELECT 'CREATE DATABASE apex_rebuild_development OWNER apex_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='apex_rebuild_development')
\gexec
SELECT 'CREATE DATABASE apex_rebuild_test OWNER apex_app'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='apex_rebuild_test')
\gexec
SELECT 'CREATE DATABASE apex_pms_development'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='apex_pms_development')
\gexec
SELECT 'CREATE DATABASE apex_pms_test'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='apex_pms_test')
\gexec
REVOKE CONNECT ON DATABASE apex_pms_development FROM PUBLIC;
REVOKE CONNECT ON DATABASE apex_pms_test FROM PUBLIC;
GRANT CONNECT ON DATABASE apex_pms_development, apex_pms_test TO apex_pms_reader;
