CREATE TABLE IF NOT EXISTS clinics (
  id BIGINT PRIMARY KEY, name TEXT NOT NULL, address_line TEXT, city TEXT, state CHAR(2), phone TEXT
);
CREATE TABLE IF NOT EXISTS patients (
  id BIGINT PRIMARY KEY, first_name TEXT NOT NULL, last_name TEXT NOT NULL, birthdate DATE,
  wireless_phone TEXT, email TEXT, preferred_language TEXT, guarantor_id BIGINT REFERENCES patients(id)
);
CREATE TABLE IF NOT EXISTS appointments (
  id BIGINT PRIMARY KEY, patient_id BIGINT NOT NULL REFERENCES patients(id),
  clinic_id BIGINT NOT NULL REFERENCES clinics(id), provider_name TEXT,
  start_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, length_minutes INT, procedure_note TEXT,
  status TEXT NOT NULL, updated_at TIMESTAMP WITHOUT TIME ZONE
);
GRANT USAGE ON SCHEMA public TO apex_pms_reader;
GRANT SELECT ON clinics, patients, appointments TO apex_pms_reader;
