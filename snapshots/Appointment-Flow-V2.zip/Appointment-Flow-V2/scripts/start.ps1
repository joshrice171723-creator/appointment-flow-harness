$ErrorActionPreference = 'Stop'
$workspace = Split-Path $PSScriptRoot -Parent
if (-not $env:APEX_DEMO_NOW) { $env:APEX_DEMO_NOW = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd') + 'T18:00:00Z' }
docker start apex-rebuild-db | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Run scripts/setup.ps1 first.' }
Set-Location (Join-Path $workspace 'backend')
Write-Output "Demo clock: $env:APEX_DEMO_NOW. Open http://127.0.0.1:3185"
bundle exec ruby bin/rails server -b 127.0.0.1 -p 3185
exit $LASTEXITCODE
