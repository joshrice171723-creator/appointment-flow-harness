$ErrorActionPreference = 'Stop'
$workspace = Split-Path $PSScriptRoot -Parent
Set-Location $workspace
python quality/verify_harness.py
if ($LASTEXITCODE -ne 0) { throw 'Harness preflight failed. No setup performed.' }
$existing = docker ps -a --filter 'name=^apex-rebuild-db$' --format '{{.Names}}'
if (-not $existing) {
  docker run --name apex-rebuild-db -e POSTGRES_PASSWORD=local_admin_only -p 127.0.0.1:15435:5432 -d postgres:17-alpine
  if ($LASTEXITCODE -ne 0) { throw 'Could not create demo PostgreSQL container.' }
} else {
  docker start apex-rebuild-db | Out-Null
}
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  docker exec apex-rebuild-db pg_isready -U postgres *> $null
  if ($LASTEXITCODE -eq 0) { break }
  Start-Sleep -Milliseconds 500
}
Get-Content -Raw scripts/database.sql | docker exec -i apex-rebuild-db psql -U postgres -v ON_ERROR_STOP=1
if ($LASTEXITCODE -ne 0) { throw 'Database creation failed.' }
foreach ($database in @('apex_pms_development', 'apex_pms_test')) {
  Get-Content -Raw scripts/source_schema.sql | docker exec -i apex-rebuild-db psql -U postgres -d $database -v ON_ERROR_STOP=1
  if ($LASTEXITCODE -ne 0) { throw "Source setup failed for $database" }
}
if (-not $env:APEX_DEMO_NOW) { $env:APEX_DEMO_NOW = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd') + 'T18:00:00Z' }
Push-Location backend
try {
  bundle install --local
  if ($LASTEXITCODE -ne 0) { throw 'Ruby dependency installation failed.' }
  bundle exec ruby bin/rails db:migrate
  if ($LASTEXITCODE -ne 0) { throw 'Migration failed.' }
  $sourceCount = docker exec apex-rebuild-db psql -U postgres -d apex_pms_development -tAc 'SELECT count(*) FROM appointments'
  if ($sourceCount.Trim() -eq '0') {
    bundle exec ruby bin/rails db:seed
    if ($LASTEXITCODE -ne 0) { throw 'Seed failed.' }
  }
  $env:RAILS_ENV = 'test'
  bundle exec ruby bin/rails db:migrate
  if ($LASTEXITCODE -ne 0) { throw 'Test migration failed.' }
} finally { Remove-Item Env:RAILS_ENV -ErrorAction SilentlyContinue; Pop-Location }
Push-Location frontend
try {
  # RubyMine ACP exports this npm option for its own global installation.
  Remove-Item Env:npm_config_allow_scripts -ErrorAction SilentlyContinue
  npm.cmd ci
  if ($LASTEXITCODE -ne 0) { throw 'Frontend dependency installation failed.' }
  npm.cmd run build
  if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
} finally { Pop-Location }
Write-Output 'Setup complete. Run powershell -File scripts/start.ps1'
