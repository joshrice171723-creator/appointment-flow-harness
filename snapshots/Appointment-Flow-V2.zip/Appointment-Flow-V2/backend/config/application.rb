require_relative "boot"
require "rails"
require "active_record/railtie"
require "action_controller/railtie"
require "rails/test_unit/railtie"
Bundler.require(*Rails.groups)

module ApexRebuild
  class Application < Rails::Application
    config.load_defaults 8.1
    config.api_only = true
    config.time_zone = "UTC"
    config.active_record.schema_format = :ruby
    config.filter_parameters += [ :body, :recipient, :phone, :email, :birthdate, :contact, :details ]
    config.hosts = [ "localhost", "127.0.0.1", "www.example.com" ]
    config.public_file_server.enabled = true
    config.secret_key_base = ENV.fetch("SECRET_KEY_BASE", "local-assessment-only-" * 4)
    config.eager_load = false
    config.active_support.deprecation = :stderr
  end
end
