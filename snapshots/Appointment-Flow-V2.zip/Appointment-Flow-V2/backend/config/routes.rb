Rails.application.routes.draw do
  get "/up", to: proc { [ 200, { "content-type" => "application/json" }, [ '{"status":"ok"}' ] ] }
  get "/api/clinics", to: "clinics#index"
  get "/api/leadership", to: "leadership#index"
  scope "/api/clinics/:clinic_id" do
    get "workspace", to: "workspace#show"
    post "refresh", to: "batches#refresh"
    post "batches", to: "batches#create"
    get "patients/:id", to: "patients#show"
    patch "patients/:id", to: "patients#update"
    post "replies", to: "replies#create"
    post "work_items/:id/claim", to: "work_items#claim"
    post "work_items/:id/followups", to: "work_items#followup"
  end
  get "/", to: "home#show"
end
