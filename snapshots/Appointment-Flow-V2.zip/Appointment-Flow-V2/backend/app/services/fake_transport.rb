class FakeTransport
  # Deterministic failure fixture; this adapter never performs network IO.
  def self.deliver(channel:, recipient:, body:)
    raise ArgumentError, "Unsupported transport" unless %w[sms email].include?(channel)
    recipient.end_with?("0199") || recipient.start_with?("fail@") ? "failed" : "sent"
  end
end
