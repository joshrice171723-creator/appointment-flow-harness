class ReminderBatch
  STEPS = { initial: 7, backup: 6, followup: 3, final: 1 }.freeze
  SEND_HOURS = (10...18)

  def self.call(clinic:, now: Time.current)
    count = 0
    ApplicationRecord.transaction do
      Clinic.lock_workflow!
      SourceRefresh.call(now: now)
      local = now.in_time_zone(clinic.timezone)
      clinic.visits.includes(:person, :messages, :work_items).each do |visit|
        if visit.time_error.present?
          visit.raise_work!("contact_hold", visit.time_error)
          next
        end
        next unless visit.eligible?(now)
        days = (visit.starts_at.in_time_zone(clinic.timezone).to_date - local.to_date).to_i
        next if days > STEPS.fetch(:initial)
        if !visit.confirmed? && visit.starts_at <= now + 48.hours
          visit.raise_work!("no_reply", "No confirmation within 48 hours of the visit. Contact the patient.")
        end
        hold = visit.person.hold_reason(on: local.to_date)
        hold ||= "No permitted SMS or email contact. Verify details and opt-outs." unless %w[sms email].any? { |channel| visit.person.allowed?(channel) }
        if hold
          visit.raise_work!("contact_hold", hold)
          next
        end
        visit.work_items.where(reason: "contact_hold").where.not(status: "resolved").update_all(status: "resolved", updated_at: now)
        next unless SEND_HOURS.cover?(local.hour)
        step = days <= STEPS.fetch(:final) ? "final" : days <= STEPS.fetch(:followup) ? "followup" : "initial"
        next if visit.confirmed? && step != "final"
        sms = visit.person.allowed?("sms")
        channel = sms ? "sms" : "email"
        previous_sms = visit.messages.where(version: visit.version, channel: "sms", status: "sent").exists?
        if days <= STEPS.fetch(:backup) && step == "initial" && previous_sms && !visit.confirmed? && visit.person.allowed?("email")
          step, channel = "backup", "email"
        end
        count += deliver(visit, step, channel, now)
        failed_sms = visit.messages.where(version: visit.version, step: step, channel: "sms", status: "failed").exists?
        count += deliver(visit, step, "email", now) if failed_sms && visit.person.allowed?("email")
      end
    end
    count
  rescue SourceRefresh::Unavailable
    Clinic.update_all(sync_error: "PMS refresh unavailable. Previous records retained; sending is blocked.")
    raise
  end

  def self.deliver(visit, step, channel, now)
    return 0 if visit.messages.exists?(version: visit.version, step: step, channel: channel)
    recipient = visit.person.recipient(channel)
    local = visit.starts_at.in_time_zone(visit.clinic.timezone).strftime("%b %-d, %Y at %-I:%M %p")
    spanish = visit.person.details["preferred_language"] == "es"
    body = spanish ? "Cita: #{local}, #{visit.clinic.name} (#{visit.clinic.timezone})." : "Appointment: #{local}, #{visit.clinic.name} (#{visit.clinic.timezone})."
    body += if visit.confirmed?
      spanish ? " Su cita esta confirmada." : " Your appointment is confirmed."
    else
      spanish ? " Responda YES para confirmar o NO para ayuda." : " Reply YES to confirm or NO for help."
    end
    body += spanish ? " Responda STOP para dejar de recibir textos." : " Reply STOP to stop texts." if channel == "sms"
    status = FakeTransport.deliver(channel: channel, recipient: recipient, body: body)
    visit.messages.create!(version: visit.version, step: step, channel: channel, recipient: recipient, body: body, status: status, sent_at: now)
    visit.raise_work!("delivery_failed", "#{channel.upcase} delivery failed. Review contact details.") if status == "failed"
    1
  end
end
