class ReceiveReply
  class Invalid < StandardError; end

  def self.call(clinic:, channel:, recipient:, body:, external_id:, message_id: nil, now: DemoClock.now)
    raise Invalid, "Choose SMS or email." unless %w[sms email].include?(channel)
    recipient = channel == "sms" ? Person.normalize_phone(recipient) : Person.normalize_email(recipient)
    raise Invalid, "A valid recipient and reply are required." if recipient.blank? || body.to_s.strip.empty? || body.to_s.length > 2000
    raise Invalid, "A reply event ID is required (maximum 100 characters)." if external_id.blank? || external_id.length > 100
    ApplicationRecord.transaction do
      Clinic.lock_workflow!
      existing = clinic_reply(clinic, channel, external_id)
      if existing
        raise Invalid, "This event ID was already used with different content." unless existing.recipient == recipient && existing.body == body && existing.message_id.to_s == message_id.to_s
        return existing
      end
      SourceRefresh.call(now: now) unless body.strip.casecmp?("STOP")
      context = message_id.present? ? Message.joins(:visit).where(visits: { clinic_id: clinic.id }).find(message_id) : nil
      raise Invalid, "Reply context does not match this recipient." if context && (context.channel != channel || context.recipient != recipient || context.status != "sent")
      contacts = clinic.people.select { |person| person.recipient(channel) == recipient }
      visits = clinic.visits.includes(:person, :messages).select do |visit|
        contacts.any? { |person| person.id == visit.person_id }
      end
      visits |= [ context.visit ] if context
      command = body.strip.upcase
      result = "needs_review"
      if command == "STOP"
        Suppression.find_or_create_by!(clinic: clinic, channel: channel, recipient: recipient)
        result = "opted_out"
      else
        current = visits.select { |visit| visit.eligible?(now) }
        candidate = context ? context.visit : current.one? ? current.first : nil
        valid_context = candidate && (context ? context.version == candidate.version : candidate.messages.where(version: candidate.version, channel: channel, recipient: recipient, status: "sent").exists?)
        safe = candidate && candidate.eligible?(now) && valid_context && contacts.one? && contacts.first.id == candidate.person_id && candidate.person.hold_reason(on: now.in_time_zone(clinic.timezone).to_date).nil? && candidate.person.allowed?(channel)
        if command == "YES" && safe
          candidate.confirm!(now: now)
          result = "confirmed"
        else
          visits.each { |visit| visit.raise_work!("reply_review", "Reply needs clarification: #{body.strip.truncate(160)}") }
        end
      end
      InboundReply.create!(clinic: clinic, channel: channel, recipient: recipient, body: body,
        external_id: external_id, message: context, result: result, received_at: now)
    end
  end

  def self.clinic_reply(clinic, channel, external_id)
    InboundReply.find_by(clinic: clinic, channel: channel, external_id: external_id)
  end
end
