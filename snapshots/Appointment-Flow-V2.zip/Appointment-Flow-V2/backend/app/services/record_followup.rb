class RecordFollowup
  class Invalid < StandardError; end

  def self.call(item:, staff:, outcome:, note:, request_id:, version:, now: DemoClock.now)
    raise Invalid, "A save ID is required." if request_id.blank? || request_id.length > 100
    ApplicationRecord.transaction do
      Clinic.lock_workflow!
      SourceRefresh.call(now: now)
      item.reload
      existing = Followup.find_by(request_id: request_id)
      if existing
        raise Invalid, "This save ID belongs to another action." unless existing.work_item_id == item.id && existing.staff == staff && existing.outcome == outcome && existing.note == note
        return existing
      end
      raise Invalid, "The appointment changed. Refresh before saving; your note has been kept." unless version == item.visit.version
      raise Invalid, "This work item is already resolved. Refresh before saving." if item.status == "resolved"
      if %w[confirmed clarified].include?(outcome) && !item.visit.eligible?(now)
        raise Invalid, "Only a current future appointment can be confirmed."
      end
      followup = item.followups.create!(staff: staff, outcome: outcome, note: note, request_id: request_id, created_at: now)
      if %w[confirmed clarified].include?(outcome)
        item.visit.confirm!(now: now)
      elsif %w[rescheduled canceled].include?(outcome)
        item.visit.update!(disposition: outcome)
        item.visit.work_items.update_all(status: "resolved", staff: staff, updated_at: now)
      else
        item.update!(status: "in_progress", staff: staff)
      end
      followup
    end
  end
end
