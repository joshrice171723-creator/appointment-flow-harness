require "pg"

class SourceDatabase
  def self.database_name
    Rails.env.test? ? "apex_pms_test" : ENV.fetch("PMS_DATABASE", "apex_pms_development")
  end

  def self.connect
    PG.connect(host: ENV.fetch("PMS_HOST", "127.0.0.1"), port: ENV.fetch("PMS_PORT", "15435"),
      dbname: database_name, user: "apex_pms_reader", password: "local_reader_only", connect_timeout: 5,
      options: "-c statement_timeout=10000 -c default_transaction_read_only=on")
  end

  def self.snapshot
    connection = connect
    # Source is a different database. Only this read crosses that boundary;
    # the caller's application transaction owns all local writes.
    result = connection.exec(<<~SQL).first.fetch("snapshot")
      SELECT json_build_object(
        'clinics', (SELECT coalesce(json_agg(c ORDER BY id), '[]') FROM clinics c),
        'patients', (SELECT coalesce(json_agg(p), '[]') FROM patients p),
        'appointments', (SELECT coalesce(json_agg(a ORDER BY id), '[]') FROM appointments a)
      )::text AS snapshot
    SQL
    JSON.parse(result)
  ensure
    connection&.close
  end
end
