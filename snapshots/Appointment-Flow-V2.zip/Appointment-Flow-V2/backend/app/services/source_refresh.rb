class SourceRefresh
  class Unavailable < StandardError; end

  def self.call(now: Time.current)
    ApplicationRecord.transaction(requires_new: true) do
      Clinic.lock_workflow!
      # One SQL statement sees one committed snapshot in the separate PMS database.
      snapshot = SourceDatabase.snapshot
      source_clinics = snapshot.fetch("clinics")
      patients = snapshot.fetch("patients").index_by { |p| p.fetch("id") }
      appointments = snapshot.fetch("appointments")
      raise Unavailable, "PMS refresh was empty; previous records retained. No reminders sent." if source_clinics.empty? || patients.empty? || appointments.empty?
      visits = Visit.all.index_by(&:source_id)
      people = Person.all.index_by { |person| [ person.clinic_id, person.source_id ] }
      clinics = Clinic.all.index_by(&:id)
      incoming_ids = appointments.map { |row| row.fetch("id") }
      raise Unavailable, "PMS records disappeared; review source completeness before sending." if (visits.keys - incoming_ids).any?

      source_clinics.each do |row|
        timezone = Clinic::TIMEZONES[row.fetch("id")]
        raise Unavailable, "Clinic timezone is not configured." unless timezone
        clinic = clinics[row.fetch("id")] ||= Clinic.new(id: row.fetch("id"))
        clinic.update!(name: row.fetch("name"), timezone: timezone, synced_at: now, sync_error: nil)
      end
      appointments.each do |row|
        clinic = clinics.fetch(row.fetch("clinic_id"))
        source = patients.fetch(row.fetch("patient_id")).except("id", "guarantor_id")
        person_key = [ clinic.id, row.fetch("patient_id") ]
        person = people[person_key] ||= Person.new(clinic: clinic, source_id: row.fetch("patient_id"))
        person.update!(source: source)
        wall = row.fetch("start_at").tr("T", " ")
        instant, error = interpret_time(wall, clinic.timezone)
        visit = visits[row.fetch("id")] ||= Visit.new(source_id: row.fetch("id"))
        if visit.persisted? && (visit.clinic_id != clinic.id || visit.person_id != person.id)
          raise Unavailable, "PMS appointment identity changed; review before sending."
        end
        revised = visit.new_record? || visit.wall_time != wall || (visit.source_status != "scheduled" && row.fetch("status") == "scheduled")
        version = revised ? SecureRandom.uuid : visit.version
        if visit.persisted? && revised
          visit.assign_attributes(confirmed_version: nil, confirmed_at: nil, disposition: nil)
          visit.work_items.where.not(status: "resolved").update_all(status: "resolved", updated_at: now)
        end
        ended = visit.persisted? && visit.source_status == "scheduled" && row.fetch("status") != "scheduled"
        visit.update!(clinic: clinic, person: person, wall_time: wall, starts_at: instant, time_error: error,
          provider: row["provider_name"], source_status: row.fetch("status"), length_minutes: row["length_minutes"], version: version)
        visit.work_items.where.not(status: "resolved").update_all(status: "resolved", updated_at: now) if ended
      end
    end
  rescue Unavailable, PG::Error, ActiveRecord::StatementInvalid, KeyError => error
    Clinic.update_all(sync_error: "PMS refresh unavailable. Previous records retained; sending is blocked.")
    raise Unavailable, error.is_a?(Unavailable) ? error.message : "PMS read failed. No reminders sent."
  end

  def self.interpret_time(wall, timezone)
    # DateTime preserves the wall fields; Time.strptime can normalize a DST gap
    # in the host's timezone before the clinic timezone gets to validate it.
    naive = DateTime.strptime(wall, "%Y-%m-%d %H:%M:%S")
    zone = TZInfo::Timezone.get(timezone)
    [ zone.local_to_utc(Time.utc(naive.year, naive.month, naive.day, naive.hour, naive.min, naive.sec)), nil ]
  rescue TZInfo::AmbiguousTime, TZInfo::PeriodNotFound
    [ nil, "Appointment time needs review because of a daylight-saving transition." ]
  end
end
