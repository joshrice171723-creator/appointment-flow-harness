class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "Record not found in this clinic." }, status: :not_found
  end
  rescue_from ActiveRecord::RecordInvalid do |error|
    render json: { error: error.record.errors.full_messages.join(". ") }, status: :unprocessable_entity
  end
  rescue_from ReceiveReply::Invalid, RecordFollowup::Invalid, ArgumentError, ActionController::ParameterMissing do |error|
    render json: { error: error.message }, status: :unprocessable_entity
  end
  rescue_from SourceRefresh::Unavailable do |error|
    render json: { error: error.message }, status: :service_unavailable
  end

  private

  def clinic
    @clinic ||= Clinic.find(params[:clinic_id])
  end

  def staff!
    staff = request.headers["X-Demo-Staff"]
    raise ArgumentError, "Select a demo staff member." unless Clinic::STAFF.include?(staff)
    staff
  end
end
