class WorkItemsController < ApplicationController
  def claim
    staff = staff!
    ApplicationRecord.transaction do
      Clinic.lock_workflow!
      item = WorkItem.joins(:visit).where(visits: { clinic_id: clinic.id }).find(params[:id])
      raise ArgumentError, "Resolved work cannot be assigned." if item.status == "resolved"
      item.update!(staff: staff, status: "in_progress")
    end
    render json: { message: "Assigned to #{staff}." }
  end

  def followup
    staff = staff!
    item = WorkItem.joins(:visit).where(visits: { clinic_id: clinic.id }).find(params[:id])
    followup = RecordFollowup.call(item: item, staff: staff, outcome: params.require(:outcome), note: params.require(:note),
      request_id: params.require(:request_id), version: params.require(:version))
    render json: { id: followup.id, message: "Follow-up recorded." }
  end
end
