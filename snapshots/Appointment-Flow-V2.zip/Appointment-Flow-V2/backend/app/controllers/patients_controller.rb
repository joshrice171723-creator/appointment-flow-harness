class PatientsController < ApplicationController
  def show
    person = clinic.people.find(params[:id])
    visits = person.visits.includes(:work_items).order(:starts_at)
    messages = Message.where(visit_id: visits.select(:id)).order(:sent_at, :id)
    replies = InboundReply.where(clinic: clinic).where("message_id IN (?) OR (channel = 'sms' AND recipient = ?) OR (channel = 'email' AND recipient = ?)", messages.select(:id), person.recipient("sms"), person.recipient("email")).order(:received_at)
    render json: { patient: person.serialize, visits: visits.map(&:serialize), messages: messages.map(&:serialize),
      replies: replies.as_json(only: [ :id, :channel, :body, :result, :received_at ]),
      work_items: WorkItem.where(visit_id: visits.select(:id)).includes(:followups, visit: :person).map(&:serialize),
      changes: person.contact_changes.order(:created_at).as_json(only: [ :staff, :details, :created_at ]) }
  end

  def update
    staff = staff!
    person = clinic.people.find(params[:id])
    values = params.require(:details).permit(:birthdate, :wireless_phone, :email, :preferred_language, :guardian_authorized).to_h
    values["guardian_authorized"] = ActiveModel::Type::Boolean.new.cast(values["guardian_authorized"]) if values.key?("guardian_authorized")
    raise ArgumentError, "Enter a valid birthdate." unless Date.iso8601(values.fetch("birthdate", "")).between?(Date.new(1900), DemoClock.now.to_date)
    raise ArgumentError, "Use en or es for the supported language." unless %w[en es].include?(values["preferred_language"])
    raise ArgumentError, "Enter a valid mobile number or leave it blank." if values["wireless_phone"].present? && Person.normalize_phone(values["wireless_phone"]).nil?
    raise ArgumentError, "Enter a valid email or leave it blank." if values["email"].present? && Person.normalize_email(values["email"]).nil?
    ApplicationRecord.transaction do
      Clinic.lock_workflow!
      person.reload
      person.update!(verified: values, verified_against: person.source_digest)
      person.contact_changes.create!(staff: staff, details: values, created_at: DemoClock.now)
    end
    render json: { message: "Local contact details verified. PMS source was not changed." }
  end
end
