class RepliesController < ApplicationController
  def create
    # This is the only inbound rule path, shared by the local inbox and simulated provider.
    reply = ReceiveReply.call(clinic: clinic, channel: params.require(:channel), recipient: params.require(:recipient),
      body: params.require(:body), external_id: params.require(:external_id), message_id: params[:message_id])
    render json: { result: reply.result, id: reply.id }
  end
end
