class LeadershipController < ApplicationController
  def index
    month = Date.iso8601("#{params.fetch(:month, DemoClock.now.strftime('%Y-%m'))}-01")
    clinics = Clinic.order(:id).map do |clinic|
      visits = clinic.visits.where("wall_time >= ? AND wall_time < ?", month.to_s, month.next_month.to_s)
      counts = visits.group(:source_status).count
      total = counts.values.sum
      messages = Message.where(visit_id: visits.select(:id))
      work = WorkItem.where(visit_id: visits.select(:id))
      { id: clinic.id, name: clinic.name, recorded: total, completed: counts.fetch("complete", 0),
        rescheduled: counts.fetch("unscheduled", 0), canceled: counts.fetch("broken", 0), unknown: counts.fetch("scheduled", 0),
        completion_rate: total.zero? ? nil : (100.0 * counts.fetch("complete", 0) / total).round(1),
        confirmed: visits.where("confirmed_version = version").count,
        delivery_attempts: messages.count, sent: messages.where(status: "sent").count, failed: messages.where(status: "failed").count,
        contact_holds: work.where(reason: "contact_hold").where.not(status: "resolved").count,
        followups: Followup.where(work_item_id: work.select(:id)).count }
    end
    render json: { month: month.strftime("%Y-%m"), clinics: clinics,
      definition: "Completion rate = PMS completed visits / all recorded visits in the clinic-local month. Scheduled visits have an unknown outcome. These records do not establish no-shows or reminder impact." }
  end
end
