class ClinicsController < ApplicationController
  def index
    render json: { clinics: Clinic.order(:id).map(&:serialize), staff: Clinic::STAFF, now: DemoClock.now, simulated_clock: ENV["APEX_DEMO_NOW"].present? }
  end
end
