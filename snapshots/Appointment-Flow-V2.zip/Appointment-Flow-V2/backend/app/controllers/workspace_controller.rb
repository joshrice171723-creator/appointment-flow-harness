class WorkspaceController < ApplicationController
  def show
    staff!
    visits = clinic.visits.includes(:person, :work_items).order(:starts_at)
    items = WorkItem.joins(:visit).where(visits: { clinic_id: clinic.id }).includes(:followups, visit: :person).order(:created_at)
    render json: { clinic: clinic.serialize, visits: visits.map(&:serialize), work_items: items.map(&:serialize), patients: clinic.people.order(:id).map { |person| { id: person.id, name: person.name } } }
  end
end
