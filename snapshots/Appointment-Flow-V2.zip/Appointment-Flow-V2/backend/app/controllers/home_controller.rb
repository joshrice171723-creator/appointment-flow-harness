class HomeController < ActionController::API
  def show
    file = Rails.public_path.join("index.html")
    if file.file?
      send_file file, type: "text/html", disposition: "inline"
    else
      render json: { message: "Build the frontend with npm run build, or open the Vite development server." }
    end
  end
end
