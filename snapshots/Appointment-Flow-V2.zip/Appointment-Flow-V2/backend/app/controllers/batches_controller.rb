class BatchesController < ApplicationController
  def refresh
    staff!
    clinic
    SourceRefresh.call(now: DemoClock.now)
    render json: { message: "PMS snapshot refreshed." }
  end

  def create
    staff!
    count = ReminderBatch.call(clinic: clinic, now: DemoClock.now)
    render json: { message: "#{count} fake delivery attempts recorded. Sending window: 10:00–18:00 clinic time." }
  end
end
