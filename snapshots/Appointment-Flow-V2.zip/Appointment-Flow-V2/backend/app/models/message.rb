class Message < ApplicationRecord
  belongs_to :visit

  def serialize
    as_json(only: [ :id, :channel, :body, :status, :sent_at, :step, :version ])
  end
end
