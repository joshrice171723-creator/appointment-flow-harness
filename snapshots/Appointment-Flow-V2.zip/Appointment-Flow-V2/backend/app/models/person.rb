class Person < ApplicationRecord
  belongs_to :clinic
  has_many :visits
  has_many :contact_changes

  def name
    "#{source.fetch('first_name')} #{source.fetch('last_name')}"
  end

  def source_digest
    Digest::SHA256.hexdigest(source.sort.to_json)
  end

  def details
    source.merge(verified)
  end

  def recipient(channel)
    channel == "sms" ? self.class.normalize_phone(details["wireless_phone"]) : self.class.normalize_email(details["email"])
  end

  def self.normalize_phone(value)
    digits = value.to_s.gsub(/\D/, "")
    digits = "1#{digits}" if digits.length == 10
    "+#{digits}" if digits.match?(/\A1[2-9]\d{2}[2-9]\d{6}\z/)
  end

  def self.normalize_email(value)
    value.to_s.strip.downcase.presence if value.to_s.strip.match?(/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/)
  end

  def hold_reason(on:)
    return "PMS details changed after verification. Review the local correction." if verified_against.present? && verified_against != source_digest
    return "Arrange contact in the patient's preferred language." unless %w[en es].include?(details["preferred_language"])
    birthday = Date.iso8601(details["birthdate"].to_s) rescue nil
    return "Verify the patient's birthdate and authorized contact." unless birthday && birthday <= on
    adult = birthday <= on.years_ago(18)
    return "Verify guardian authorization before contacting this minor." unless adult || details["guardian_authorized"] == true
    nil
  end

  def allowed?(channel)
    address = recipient(channel)
    return false if address.blank? || Suppression.exists?(clinic_id: clinic_id, channel: channel, recipient: address)
    # A contact attached to another patient is not established as this patient's own.
    clinic.people.where.not(id: id).none? { |other| other.recipient(channel) == address }
  end

  def serialize
    { id: id, name: name, source: source, details: details, verified: verified.present?, conflict: verified_against.present? && verified_against != source_digest }
  end
end
