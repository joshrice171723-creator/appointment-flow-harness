class Suppression < ApplicationRecord
  belongs_to :clinic
end
