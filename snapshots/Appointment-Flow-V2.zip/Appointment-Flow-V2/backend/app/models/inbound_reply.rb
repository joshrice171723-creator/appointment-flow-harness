class InboundReply < ApplicationRecord
  belongs_to :clinic
  belongs_to :message, optional: true
end
