class Clinic < ApplicationRecord
  TIMEZONES = { 1 => "America/Chicago", 2 => "America/Phoenix" }.freeze
  STAFF = [ "Taylor Morgan", "Jordan Lee" ].freeze

  has_many :people
  has_many :visits

  def serialize
    { id: id, name: name, timezone: timezone, synced_at: synced_at, sync_error: sync_error }
  end

  # The same transaction-scoped lock orders sync, sends, replies and staff changes.
  def self.lock_workflow!
    connection.execute("SELECT pg_advisory_xact_lock(751115)")
  end
end
