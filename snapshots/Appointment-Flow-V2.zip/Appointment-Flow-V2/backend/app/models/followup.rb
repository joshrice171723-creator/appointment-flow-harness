class Followup < ApplicationRecord
  belongs_to :work_item
  validates :note, presence: true, length: { maximum: 2000 }
  validates :staff, inclusion: { in: Clinic::STAFF }
  validates :outcome, inclusion: { in: %w[attempted confirmed rescheduled canceled clarified] }
end
