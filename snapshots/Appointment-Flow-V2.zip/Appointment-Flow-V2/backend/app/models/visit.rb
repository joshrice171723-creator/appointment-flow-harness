class Visit < ApplicationRecord
  belongs_to :clinic
  belongs_to :person
  has_many :messages
  has_many :work_items

  def confirmed?
    confirmed_version == version
  end

  def eligible?(now)
    source_status == "scheduled" && starts_at.present? && starts_at > now && disposition.nil?
  end

  def confirm!(now:)
    update!(confirmed_version: version, confirmed_at: now)
    work_items.where.not(status: "resolved").update_all(status: "resolved", updated_at: now)
  end

  def raise_work!(reason, description)
    item = work_items.find_or_initialize_by(reason: reason)
    item.assign_attributes(description: description, status: "needs_attention", staff: nil) if item.new_record? || item.status == "resolved"
    item.save!
    item
  end

  def serialize
    { id: id, patient_id: person_id, patient: person.name, wall_time: wall_time, starts_at: starts_at,
      provider: provider, source_status: source_status, confirmed: confirmed?, disposition: disposition,
      time_error: time_error, version: version, review: work_items.any? { |item| item.reason == "reply_review" && item.status != "resolved" } }
  end
end
