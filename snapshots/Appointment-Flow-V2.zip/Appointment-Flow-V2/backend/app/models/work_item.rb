class WorkItem < ApplicationRecord
  belongs_to :visit
  has_many :followups

  def serialize
    { id: id, visit_id: visit_id, patient_id: visit.person_id, patient: visit.person.name,
      wall_time: visit.wall_time, reason: reason, description: description, status: status,
      staff: staff, followups: followups.order(:created_at).as_json(only: [ :staff, :outcome, :note, :created_at ]) }
  end
end
