class ContactChange < ApplicationRecord
  belongs_to :person
end
