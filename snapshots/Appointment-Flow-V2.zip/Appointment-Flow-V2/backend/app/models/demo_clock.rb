class DemoClock
  def self.now
    ENV["APEX_DEMO_NOW"].present? ? Time.iso8601(ENV.fetch("APEX_DEMO_NOW")) : Time.current
  end
end
