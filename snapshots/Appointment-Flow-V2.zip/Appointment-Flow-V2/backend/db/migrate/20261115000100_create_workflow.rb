class CreateWorkflow < ActiveRecord::Migration[8.1]
  def change
    create_table :clinics do |t|
      t.string :name, null: false
      t.string :timezone, null: false
      t.datetime :synced_at
      t.string :sync_error
    end
    create_table :people do |t|
      t.references :clinic, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.jsonb :source, null: false, default: {}
      t.jsonb :verified, null: false, default: {}
      t.string :verified_against
      t.timestamps
    end
    add_index :people, [ :clinic_id, :source_id ], unique: true
    create_table :visits do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.string :wall_time, null: false
      t.datetime :starts_at
      t.string :time_error
      t.string :provider
      t.string :source_status, null: false
      t.integer :length_minutes
      t.string :version, null: false
      t.string :confirmed_version
      t.datetime :confirmed_at
      t.string :disposition
      t.timestamps
    end
    add_index :visits, :source_id, unique: true
    add_index :visits, [ :clinic_id, :starts_at ]
    create_table :work_items do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :reason, null: false
      t.string :description, null: false
      t.string :status, null: false, default: "needs_attention"
      t.string :staff
      t.timestamps
    end
    add_index :work_items, [ :visit_id, :reason ], unique: true
    create_table :messages do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :version, null: false
      t.string :step, null: false
      t.string :channel, null: false
      t.string :recipient, null: false
      t.text :body, null: false
      t.string :status, null: false
      t.datetime :sent_at, null: false
    end
    add_index :messages, [ :visit_id, :version, :step, :channel ], unique: true
    create_table :inbound_replies do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :message, foreign_key: true
      t.string :channel, null: false
      t.string :recipient, null: false
      t.string :external_id, null: false
      t.text :body, null: false
      t.string :result, null: false
      t.datetime :received_at, null: false
    end
    add_index :inbound_replies, [ :clinic_id, :channel, :external_id ], unique: true
    create_table :suppressions do |t|
      t.references :clinic, null: false, foreign_key: true
      t.string :channel, null: false
      t.string :recipient, null: false
    end
    add_index :suppressions, [ :clinic_id, :channel, :recipient ], unique: true
    create_table :followups do |t|
      t.references :work_item, null: false, foreign_key: true
      t.string :request_id, null: false
      t.string :staff, null: false
      t.string :outcome, null: false
      t.text :note, null: false
      t.datetime :created_at, null: false
    end
    add_index :followups, :request_id, unique: true
    create_table :contact_changes do |t|
      t.references :person, null: false, foreign_key: true
      t.string :staff, null: false
      t.jsonb :details, null: false
      t.datetime :created_at, null: false
    end
  end
end
