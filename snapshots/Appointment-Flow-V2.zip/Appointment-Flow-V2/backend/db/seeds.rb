require "pg"

# Fixture-only administrative connection. Application runtime has no source-write privilege.
admin = PG.connect(host: ENV.fetch("PMS_HOST", "127.0.0.1"), port: ENV.fetch("PMS_PORT", "15435"),
  dbname: SourceDatabase.database_name, user: "postgres", password: "local_admin_only")
raise "Seeds require an empty source database; use a new demo database." unless admin.exec("SELECT count(*) FROM appointments").first.fetch("count") == "0"
today = DemoClock.now.in_time_zone("America/Chicago").to_date
admin.transaction do |db|
  [ [ 1, "Austin", "TX" ], [ 2, "Phoenix", "AZ" ] ].each do |id, name, state|
    db.exec_params("INSERT INTO clinics(id,name,city,state,phone) VALUES($1,$2,$2,$3,$4)", [ id, name, state, "(512) 555-0100" ])
    16.times do |index|
      patient_id = id * 100 + index
      first = %w[Avery Maya Noah Elena Sam Riley Morgan Luis Harper Jamie Casey Quinn Robin Sage Alex Drew][index]
      phone = index == 4 ? nil : index == 5 ? "5125550199" : index == 7 || index == 8 ? "5125550166" : "512555#{(100 + id * 20 + index).to_s.rjust(4, '0')}"
      email = "#{first.downcase}#{id}@example.test"
      phone, email = "invalid", nil if index == 6
      birthday = index == 9 ? (today - 12.years).to_s : "1988-04-12"
      language = index == 10 ? "fr" : index == 3 ? "es" : "en"
      db.exec_params("INSERT INTO patients(id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES($1,$2,$3,$4,$5,$6,$7)",
        [ patient_id, first, "Demo", birthday, phone, email, language ])
      day_offset = [ 7, 3, 1, 6, 7, 3, 1, 3, 3, 1, 1, -1, -2, -3, -4, 2 ][index]
      status = index == 11 ? "complete" : index == 12 ? "broken" : index == 13 ? "unscheduled" : "scheduled"
      db.exec_params("INSERT INTO appointments(id,patient_id,clinic_id,provider_name,start_at,length_minutes,procedure_note,status,updated_at) VALUES($1,$2,$3,$4,$5,45,'Fictional fixture only',$6,$7)",
        [ patient_id, patient_id, id, index.even? ? "Dr. Chen" : "Dr. Patel", "#{today + day_offset} #{index.even? ? '14:00:00' : '15:30:00'}", status, "#{today} 09:00:00" ])
    end
  end
end
admin.close
SourceRefresh.call(now: DemoClock.now)
Clinic.find_each { |clinic| ReminderBatch.call(clinic: clinic, now: DemoClock.now) }
first = Visit.find_by!(source_id: 101)
first.confirm!(now: DemoClock.now)
item = Visit.find_by!(source_id: 115).work_items.first
item&.update!(staff: Clinic::STAFF.first, status: "in_progress")
puts "Seeded #{Clinic.count} clinics, #{Person.count} fictional patients, #{Visit.count} source-backed visits and #{Message.count} fake deliveries."
