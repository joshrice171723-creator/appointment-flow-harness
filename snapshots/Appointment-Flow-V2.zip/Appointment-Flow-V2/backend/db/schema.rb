# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_11_15_000100) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "clinics", force: :cascade do |t|
    t.string "name", null: false
    t.string "sync_error"
    t.datetime "synced_at"
    t.string "timezone", null: false
  end

  create_table "contact_changes", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.jsonb "details", null: false
    t.bigint "person_id", null: false
    t.string "staff", null: false
    t.index ["person_id"], name: "index_contact_changes_on_person_id"
  end

  create_table "followups", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.text "note", null: false
    t.string "outcome", null: false
    t.string "request_id", null: false
    t.string "staff", null: false
    t.bigint "work_item_id", null: false
    t.index ["request_id"], name: "index_followups_on_request_id", unique: true
    t.index ["work_item_id"], name: "index_followups_on_work_item_id"
  end

  create_table "inbound_replies", force: :cascade do |t|
    t.text "body", null: false
    t.string "channel", null: false
    t.bigint "clinic_id", null: false
    t.string "external_id", null: false
    t.bigint "message_id"
    t.datetime "received_at", null: false
    t.string "recipient", null: false
    t.string "result", null: false
    t.index ["clinic_id", "channel", "external_id"], name: "index_inbound_replies_on_clinic_id_and_channel_and_external_id", unique: true
    t.index ["clinic_id"], name: "index_inbound_replies_on_clinic_id"
    t.index ["message_id"], name: "index_inbound_replies_on_message_id"
  end

  create_table "messages", force: :cascade do |t|
    t.text "body", null: false
    t.string "channel", null: false
    t.string "recipient", null: false
    t.datetime "sent_at", null: false
    t.string "status", null: false
    t.string "step", null: false
    t.string "version", null: false
    t.bigint "visit_id", null: false
    t.index ["visit_id", "version", "step", "channel"], name: "index_messages_on_visit_id_and_version_and_step_and_channel", unique: true
    t.index ["visit_id"], name: "index_messages_on_visit_id"
  end

  create_table "people", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.datetime "created_at", null: false
    t.jsonb "source", default: {}, null: false
    t.bigint "source_id", null: false
    t.datetime "updated_at", null: false
    t.jsonb "verified", default: {}, null: false
    t.string "verified_against"
    t.index ["clinic_id", "source_id"], name: "index_people_on_clinic_id_and_source_id", unique: true
    t.index ["clinic_id"], name: "index_people_on_clinic_id"
  end

  create_table "suppressions", force: :cascade do |t|
    t.string "channel", null: false
    t.bigint "clinic_id", null: false
    t.string "recipient", null: false
    t.index ["clinic_id", "channel", "recipient"], name: "index_suppressions_on_clinic_id_and_channel_and_recipient", unique: true
    t.index ["clinic_id"], name: "index_suppressions_on_clinic_id"
  end

  create_table "visits", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.datetime "confirmed_at"
    t.string "confirmed_version"
    t.datetime "created_at", null: false
    t.string "disposition"
    t.integer "length_minutes"
    t.bigint "person_id", null: false
    t.string "provider"
    t.bigint "source_id", null: false
    t.string "source_status", null: false
    t.datetime "starts_at"
    t.string "time_error"
    t.datetime "updated_at", null: false
    t.string "version", null: false
    t.string "wall_time", null: false
    t.index ["clinic_id", "starts_at"], name: "index_visits_on_clinic_id_and_starts_at"
    t.index ["clinic_id"], name: "index_visits_on_clinic_id"
    t.index ["person_id"], name: "index_visits_on_person_id"
    t.index ["source_id"], name: "index_visits_on_source_id", unique: true
  end

  create_table "work_items", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "description", null: false
    t.string "reason", null: false
    t.string "staff"
    t.string "status", default: "needs_attention", null: false
    t.datetime "updated_at", null: false
    t.bigint "visit_id", null: false
    t.index ["visit_id", "reason"], name: "index_work_items_on_visit_id_and_reason", unique: true
    t.index ["visit_id"], name: "index_work_items_on_visit_id"
  end

  add_foreign_key "contact_changes", "people"
  add_foreign_key "followups", "work_items"
  add_foreign_key "inbound_replies", "clinics"
  add_foreign_key "inbound_replies", "messages"
  add_foreign_key "messages", "visits"
  add_foreign_key "people", "clinics"
  add_foreign_key "suppressions", "clinics"
  add_foreign_key "visits", "clinics"
  add_foreign_key "visits", "people"
  add_foreign_key "work_items", "visits"
end
