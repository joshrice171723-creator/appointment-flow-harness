ENV["RAILS_ENV"] = "test"
require_relative "../config/environment"
require "rails/test_help"
require "pg"

class ActiveSupport::TestCase
  self.use_transactional_tests = false

  def setup
    @now = Time.iso8601("2026-11-15T18:00:00Z")
    @admin = PG.connect(host: ENV.fetch("PMS_HOST", "127.0.0.1"), port: ENV.fetch("PMS_PORT", "15435"), dbname: "apex_pms_test", user: "postgres", password: "local_admin_only")
    ApplicationRecord.connection.execute("TRUNCATE contact_changes, followups, inbound_replies, suppressions, messages, work_items, visits, people, clinics RESTART IDENTITY CASCADE")
    @admin.exec("TRUNCATE appointments, patients, clinics CASCADE")
    @admin.exec("INSERT INTO clinics(id,name,state) VALUES(1,'Austin','TX'),(2,'Phoenix','AZ')")
    source_patient(101)
    source_patient(201, phone: "6025550121", email: "phoenix@example.test")
    source_visit(101, patient: 101, clinic: 1)
    source_visit(201, patient: 201, clinic: 2)
    SourceRefresh.call(now: @now)
    @clinic = Clinic.find(1)
    @visit = Visit.find_by!(source_id: 101)
  end

  def teardown
    @admin&.close
  end

  def source_patient(id, phone: "5125550121", email: "avery@example.test", birthday: "1988-04-12", language: "en")
    @admin.exec_params("INSERT INTO patients(id,first_name,last_name,birthdate,wireless_phone,email,preferred_language) VALUES($1,'Avery','Fictional',$2,$3,$4,$5)", [ id, birthday, phone, email, language ])
  end

  def source_visit(id, patient: 101, clinic: 1, wall: "2026-11-22 14:00:00", status: "scheduled")
    @admin.exec_params("INSERT INTO appointments(id,patient_id,clinic_id,provider_name,start_at,length_minutes,status) VALUES($1,$2,$3,'Dr. Demo',$4,45,$5)", [ id, patient, clinic, wall, status ])
  end

  def batch(now: @now)
    ReminderBatch.call(clinic: @clinic, now: now)
  end

  def reply(body: "YES", external_id: SecureRandom.uuid, message: @visit.messages.order(:id).last, channel: "sms", recipient: @visit.person.recipient(channel), now: @now)
    ReceiveReply.call(clinic: @clinic, channel: channel, recipient: recipient, body: body, external_id: external_id, message_id: message&.id, now: now)
  end
end
