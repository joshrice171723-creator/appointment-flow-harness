require "test_helper"

class SourceDatabaseTest < ActiveSupport::TestCase
  test "PMS is a separate database with exactly the brief tables and columns" do
    reader = SourceDatabase.connect
    begin
      assert_equal "apex_pms_test", reader.exec("SELECT current_database()").first.fetch("current_database")
      assert_equal "apex_rebuild_test", ApplicationRecord.connection.select_value("SELECT current_database()")
      tables = reader.exec("SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name").map { |row| row.fetch("table_name") }
      assert_equal %w[appointments clinics patients], tables
      expected = {
        "clinics" => [ [ "id", "bigint", "NO" ], [ "name", "text", "NO" ], [ "address_line", "text", "YES" ], [ "city", "text", "YES" ], [ "state", "character", "YES" ], [ "phone", "text", "YES" ] ],
        "patients" => [ [ "id", "bigint", "NO" ], [ "first_name", "text", "NO" ], [ "last_name", "text", "NO" ], [ "birthdate", "date", "YES" ], [ "wireless_phone", "text", "YES" ], [ "email", "text", "YES" ], [ "preferred_language", "text", "YES" ], [ "guarantor_id", "bigint", "YES" ] ],
        "appointments" => [ [ "id", "bigint", "NO" ], [ "patient_id", "bigint", "NO" ], [ "clinic_id", "bigint", "NO" ], [ "provider_name", "text", "YES" ], [ "start_at", "timestamp without time zone", "NO" ], [ "length_minutes", "integer", "YES" ], [ "procedure_note", "text", "YES" ], [ "status", "text", "NO" ], [ "updated_at", "timestamp without time zone", "YES" ] ]
      }
      expected.each do |table, columns|
        actual = reader.exec_params("SELECT column_name,data_type,is_nullable FROM information_schema.columns WHERE table_schema='public' AND table_name=$1 ORDER BY ordinal_position", [ table ]).map { |row| row.values_at("column_name", "data_type", "is_nullable") }
        assert_equal columns, actual, table
      end
      assert_equal "2", reader.exec("SELECT character_maximum_length FROM information_schema.columns WHERE table_name='clinics' AND column_name='state'").first.fetch("character_maximum_length")
      assert_equal "on", reader.exec("SHOW default_transaction_read_only").first.fetch("default_transaction_read_only")
      assert_equal 3, reader.exec("SELECT conname FROM pg_constraint WHERE connamespace='public'::regnamespace AND contype='f'").ntuples
    ensure
      reader.close
    end
    assert_not_includes ApplicationRecord.connection.tables, "appointments"
    assert_not_includes ApplicationRecord.connection.tables, "patients"
  end

  test "application role cannot connect to the PMS database" do
    error = assert_raises(PG::ConnectionBad) do
      PG.connect(host: "127.0.0.1", port: ENV.fetch("PMS_PORT", "15435"), dbname: "apex_pms_test", user: "apex_app", password: "local_demo_only")
    end
    assert_match(/permission denied/, error.message)
  end
end
