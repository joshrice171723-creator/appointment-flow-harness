require "test_helper"

class ApiTest < ActionDispatch::IntegrationTest
  test "S10 clinic scoping rejects cross-clinic patient task claim and followup" do
    get "/api/clinics/2/patients/#{@visit.person_id}"
    assert_response :not_found
    item = @visit.raise_work!("no_reply", "Call this fictional patient.")
    post "/api/clinics/2/work_items/#{item.id}/claim", headers: { "X-Demo-Staff" => Clinic::STAFF.first }
    assert_response :not_found
    post "/api/clinics/2/work_items/#{item.id}/followups", headers: { "X-Demo-Staff" => Clinic::STAFF.first }, params: { note: "Wrong clinic", outcome: "confirmed", version: @visit.version, request_id: "no" }, as: :json
    assert_response :not_found
    get "/api/clinics/2/workspace", headers: { "X-Demo-Staff" => Clinic::STAFF.first }
    assert_response :success
    assert_equal [ 201 ], response.parsed_body.fetch("visits").map { |visit| Visit.find(visit.fetch("id")).source_id }
    assert_empty response.parsed_body.fetch("work_items")
  end

  test "S16 S17 leadership uses source outcomes and only aggregate allowlisted fields" do
    batch
    reply
    get "/api/leadership?month=2026-11"
    assert_response :success
    payload = response.parsed_body
    report = payload.fetch("clinics").find { |row| row.fetch("id") == 1 }
    assert_equal 1, report.fetch("confirmed")
    assert_equal 0, report.fetch("completed")
    assert_equal 0.0, report.fetch("completion_rate")
    assert_equal 1, report.fetch("unknown")
    assert_equal %w[canceled completed completion_rate confirmed contact_holds delivery_attempts failed followups id name recorded rescheduled sent unknown], report.keys.sort
    %w[Avery Fictional 5125550121 avery@example.test YES birthdate recipient].each { |value| assert_not_includes response.body, value }
    get "/api/leadership?month=2025-01"
    assert_nil response.parsed_body.fetch("clinics").first.fetch("completion_rate")
  end

  test "staff identity required and invalid month is a clear validation error" do
    get "/api/clinics/1/workspace"
    assert_response :unprocessable_entity
    get "/api/leadership?month=oops"
    assert_response :unprocessable_entity
  end

  test "contact correction preserves raw source and records who verified" do
    patch "/api/clinics/1/patients/#{@visit.person_id}", headers: { "X-Demo-Staff" => Clinic::STAFF.first }, params: { details: { birthdate: "1988-04-12", wireless_phone: "5125550122", email: "corrected@example.test", preferred_language: "en" } }, as: :json
    assert_response :success
    assert_equal "+15125550122", @visit.person.reload.recipient("sms")
    assert_equal Clinic::STAFF.first, ContactChange.last.staff
    assert_equal "5125550121", @visit.person.source.fetch("wireless_phone")
  end

  test "S20 simulated email reply uses the same confirmation processing" do
    @admin.exec("UPDATE patients SET wireless_phone=NULL WHERE id=101")
    batch
    message = @visit.messages.last
    post "/api/clinics/1/replies", params: { channel: "email", recipient: message.recipient, body: "yes", external_id: "email-event", message_id: message.id }, as: :json
    assert_response :success
    assert_equal "confirmed", response.parsed_body.fetch("result")
    assert @visit.reload.confirmed?
  end

  test "incomplete contact verification is rejected with a validation error" do
    patch "/api/clinics/1/patients/#{@visit.person_id}", headers: { "X-Demo-Staff" => Clinic::STAFF.first }, params: { details: { email: "only@example.test" } }, as: :json
    assert_response :unprocessable_entity
    assert_equal 0, ContactChange.count
  end
end
