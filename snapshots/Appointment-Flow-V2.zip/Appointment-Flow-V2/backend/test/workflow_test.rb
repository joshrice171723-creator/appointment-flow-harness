require "test_helper"

class WorkflowTest < ActiveSupport::TestCase
  test "S01 YES confirms only the current visit and stops confirmation requests" do
    batch
    event = reply
    assert_equal "confirmed", event.result
    assert @visit.reload.confirmed?
    assert_equal "scheduled", @visit.source_status
    assert_equal 0, batch(now: @now + 4.days)
    assert_equal 1, batch(now: @now + 6.days)
    assert_includes @visit.messages.order(:id).last.body, "Your appointment is confirmed"
    assert_not_includes @visit.messages.order(:id).last.body, "YES"
  end

  test "S02 email-only recipient confirms through the same inbound rule" do
    @admin.exec("UPDATE patients SET wireless_phone = NULL WHERE id = 101")
    batch
    message = @visit.messages.last
    assert_equal "email", message.channel
    assert_equal "confirmed", reply(channel: "email", message: message).result
  end

  test "S03 moved appointment rejects old YES even without an explicit refresh" do
    batch
    message = @visit.messages.last
    reply(message: message)
    @admin.exec("UPDATE appointments SET start_at = start_at + interval '1 hour' WHERE id = 101")
    assert_equal "needs_review", reply(message: message).result
    assert_not @visit.reload.confirmed?
    assert_equal 1, @visit.work_items.where(reason: "reply_review").count
    assert_equal 1, batch
    assert_equal 2, @visit.messages.count
  end

  test "S04 broken appointment and new row have independent lifecycles" do
    batch
    @admin.exec("UPDATE appointments SET status = 'broken' WHERE id = 101")
    source_visit(102, wall: "2026-11-21 14:00:00")
    batch
    assert_equal 1, @visit.messages.count
    assert_equal 1, Visit.find_by!(source_id: 102).messages.count
    assert_equal "broken", @visit.reload.source_status
  end

  test "returning to an earlier wall time creates a fresh revision and rejects its old reply" do
    batch
    original = @visit.messages.last
    @admin.exec("UPDATE appointments SET start_at = start_at + interval '1 hour' WHERE id=101")
    SourceRefresh.call(now: @now)
    @admin.exec("UPDATE appointments SET start_at = start_at - interval '1 hour' WHERE id=101")
    assert_equal "needs_review", reply(message: original).result
    assert_not_equal original.version, @visit.reload.version
    assert_equal 1, batch
    assert_equal 2, @visit.messages.count
  end

  test "unthreaded reply with no sent messages remains visible to staff" do
    assert_equal "needs_review", reply(message: nil).result
    assert_not @visit.reload.confirmed?
    assert @visit.work_items.exists?(reason: "reply_review", status: "needs_attention")
  end

  test "S05 failed SMS is visible and falls back to one email" do
    @admin.exec("UPDATE patients SET wireless_phone = '5125550199' WHERE id = 101")
    assert_equal 2, batch
    assert_equal %w[failed sent], @visit.messages.order(:id).pluck(:status)
    assert_equal %w[sms email], @visit.messages.order(:id).pluck(:channel)
    assert_equal 0, batch
    assert @visit.work_items.exists?(reason: "delivery_failed")
  end

  test "S06 duplicate event is idempotent and conflicting reuse is rejected" do
    batch
    first = reply(external_id: "event-1")
    assert_equal first.id, reply(external_id: "event-1").id
    assert_equal 1, InboundReply.count
    assert_raises(ReceiveReply::Invalid) { reply(external_id: "event-1", body: "NO") }
    assert @visit.reload.confirmed?
  end

  test "S07 NO after YES preserves confirmation and asks staff to clarify" do
    batch
    reply
    assert_equal "needs_review", reply(body: "NO").result
    assert @visit.reload.confirmed?
    assert @visit.work_items.exists?(reason: "reply_review", status: "needs_attention")
  end

  test "S08 late reply retained without retroactive confirmation or sends" do
    batch
    assert_equal "needs_review", reply(now: @now + 8.days).result
    assert_not @visit.reload.confirmed?
    assert_equal 0, batch(now: @now + 8.days)
    assert_equal 1, InboundReply.count
  end

  test "late reply review for a completed appointment survives subsequent source refresh" do
    batch
    @admin.exec("UPDATE appointments SET status='complete' WHERE id=101")
    assert_equal "needs_review", reply(now: @now + 8.days).result
    SourceRefresh.call(now: @now + 8.days)
    assert @visit.work_items.exists?(reason: "reply_review", status: "needs_attention")
    assert_not @visit.reload.confirmed?
  end

  test "S09 STOP persists through source refresh and affects SMS only" do
    batch
    assert_equal "opted_out", reply(body: "sToP").result
    SourceRefresh.call(now: @now)
    batch(now: @now + 4.days)
    assert_equal 1, @visit.messages.where(channel: "sms").count
    assert_equal 1, @visit.messages.where(channel: "email").count
    assert_equal "needs_review", reply(body: "STOP please", message: @visit.messages.find_by!(channel: "sms")).result
  end

  test "S11 no confirmation within 48 hours creates work and attempted contact stays open" do
    @admin.exec("UPDATE appointments SET start_at = '2026-11-16 14:00' WHERE id = 101")
    batch
    item = @visit.work_items.find_by!(reason: "no_reply")
    save = RecordFollowup.call(item: item, staff: Clinic::STAFF.first, outcome: "attempted", note: "Left a callback request.", request_id: "save-1", version: @visit.reload.version, now: @now)
    assert_equal "in_progress", item.reload.status
    assert_equal save.id, RecordFollowup.call(item: item, staff: Clinic::STAFF.first, outcome: "attempted", note: "Left a callback request.", request_id: "save-1", version: @visit.version, now: @now).id
    RecordFollowup.call(item: item, staff: Clinic::STAFF.first, outcome: "confirmed", note: "Patient confirmed by phone.", request_id: "save-2", version: @visit.version, now: @now)
    assert @visit.reload.confirmed?
    assert_equal "resolved", item.reload.status
    assert_equal 2, Followup.count
  end

  test "S12 shared family number cannot automatically confirm either patient" do
    source_patient(102, email: "family@example.test")
    source_visit(102, patient: 102)
    batch
    assert_equal "needs_review", reply(message: nil).result
    assert_equal 0, Visit.where("confirmed_version = version").count
    assert_equal 2, WorkItem.where(reason: "reply_review").count
  end

  test "shared outgoing phone uses a unique email and shared contacts on both channels hold" do
    source_patient(102, email: "family@example.test")
    source_visit(102, patient: 102)
    batch
    assert_equal [ "email" ], @visit.messages.pluck(:channel)
    assert_equal "avery@example.test", @visit.messages.first.recipient
    @admin.exec("UPDATE patients SET email='avery@example.test' WHERE id=102")
    batch(now: @now + 4.days)
    assert_equal 1, @visit.messages.count
    assert @visit.work_items.exists?(reason: "contact_hold", status: "needs_attention")
  end

  test "S13 missing birthdate minor unsupported language and invalid contact are held" do
    [ [ nil, "en", "5125550121" ], [ "2015-01-01", "en", "5125550121" ], [ "1988-01-01", "fr", "5125550121" ], [ "1988-01-01", "en", "invalid" ] ].each do |birthdate, language, phone|
      @admin.exec_params("UPDATE patients SET birthdate = $1, preferred_language = $2, wireless_phone = $3, email = NULL WHERE id = 101", [ birthdate, language, phone ])
      batch
      assert_equal 0, @visit.messages.count
      assert @visit.work_items.exists?(reason: "contact_hold", status: "needs_attention")
    end
  end

  test "verified correction can unblock and PMS contact changes create a conflict hold" do
    @admin.exec("UPDATE patients SET wireless_phone = 'invalid', email = NULL WHERE id = 101")
    batch
    person = @visit.person.reload
    person.update!(verified: { wireless_phone: "5125550122" }, verified_against: person.source_digest)
    assert_equal 1, batch
    assert_equal "+15125550122", @visit.messages.last.recipient
    @admin.exec("UPDATE patients SET email = 'changed@example.test' WHERE id = 101")
    assert_equal 0, batch(now: @now + 4.days)
    assert_match(/changed after verification/, @visit.person.reload.hold_reason(on: @now.to_date))
    assert_equal "invalid", @admin.exec("SELECT wireless_phone FROM patients WHERE id=101").first.fetch("wireless_phone")
  end

  test "S14 empty and partial source snapshots preserve local state and block sends" do
    @admin.exec("DELETE FROM appointments WHERE id = 101")
    assert_raises(SourceRefresh::Unavailable) { batch }
    assert_equal 2, Visit.count
    assert_equal 0, Message.count
    assert Clinic.find(1).sync_error.present?
    @admin.exec("DELETE FROM appointments")
    assert_raises(SourceRefresh::Unavailable) { batch }
    assert_equal 2, Visit.count
  end

  test "failed source SQL blocks sends while retaining the snapshot" do
    @admin.exec("ALTER TABLE appointments RENAME TO appointments_unavailable")
    begin
      assert_raises(SourceRefresh::Unavailable) { batch }
      assert_equal 2, Visit.count
      assert_equal 0, Message.count
    ensure
      @admin.exec("ALTER TABLE appointments_unavailable RENAME TO appointments")
    end
  end

  test "S15 concurrent batches create exactly one logical message" do
    gate = Queue.new
    threads = 4.times.map do
      Thread.new do
        gate.pop
        ApplicationRecord.connection_pool.with_connection { ReminderBatch.call(clinic: Clinic.find(1), now: @now) }
      end
    end
    4.times { gate << true }
    assert_equal 1, threads.sum(&:value)
    assert_equal 1, @visit.messages.count
    assert_raises(ActiveRecord::RecordNotUnique) { @visit.messages.create!(@visit.messages.first.attributes.except("id")) }
  end

  test "sending window clinic-local date and at-start cutoff" do
    assert_equal 0, batch(now: Time.iso8601("2026-11-15T15:59:00Z"))
    assert_equal 1, batch(now: Time.iso8601("2026-11-15T16:00:00Z"))
    assert_equal 0, batch(now: Time.iso8601("2026-11-19T00:00:00Z"))
    assert_equal 0, batch(now: Time.iso8601("2026-11-22T20:00:00Z"))
    assert_equal Time.iso8601("2026-11-22T20:00:00Z"), @visit.reload.starts_at
    phoenix = Visit.find_by!(source_id: 201)
    assert_equal Time.iso8601("2026-11-22T21:00:00Z"), phoenix.starts_at
  end

  test "DST nonexistent and ambiguous wall times are held instead of guessed" do
    assert_nil SourceRefresh.interpret_time("2026-03-08 02:30:00", "America/Chicago").first
    assert_nil SourceRefresh.interpret_time("2026-11-01 01:30:00", "America/Chicago").first
    assert_equal Time.iso8601("2026-03-08T09:30:00Z"), SourceRefresh.interpret_time("2026-03-08 02:30:00", "America/Phoenix").first
    @admin.exec("UPDATE appointments SET start_at = '2026-11-01 01:30:00' WHERE id = 101")
    batch
    assert_equal 0, @visit.messages.count
    assert @visit.work_items.exists?(reason: "contact_hold")
  end

  test "runtime database role cannot write PMS source tables" do
    reader = SourceDatabase.connect
    begin
      # Even disabling the connection's read-only default cannot grant table writes.
      reader.exec("SET default_transaction_read_only=off")
      assert_raises(PG::InsufficientPrivilege) { reader.exec("UPDATE patients SET first_name = 'Wrong'") }
    ensure
      reader.close
    end
    assert_equal "Avery", @admin.exec("SELECT first_name FROM patients WHERE id=101").first.fetch("first_name")
  end

  test "missed steps coalesce and backup email is sent once when SMS unanswered" do
    batch
    assert_equal 1, batch(now: @now + 1.day)
    assert_equal "backup", @visit.messages.order(:id).last.step
    assert_equal 0, batch(now: @now + 1.day)
    assert_equal 1, batch(now: @now + 6.days)
    assert_equal [ "initial", "backup", "final" ], @visit.messages.order(:id).pluck(:step)
  end

  test "stale followup rejects confirmation and cancellation stops outreach" do
    batch(now: @now + 6.days)
    item = @visit.work_items.find_by!(reason: "no_reply")
    old_version = @visit.reload.version
    @admin.exec("UPDATE appointments SET start_at = start_at + interval '1 hour' WHERE id=101")
    assert_raises(RecordFollowup::Invalid) { RecordFollowup.call(item: item, staff: Clinic::STAFF.first, outcome: "confirmed", note: "Old time", request_id: "stale", version: old_version, now: @now) }
    batch(now: @now + 6.days)
    item.reload
    RecordFollowup.call(item: item, staff: Clinic::STAFF.first, outcome: "canceled", note: "Patient asked to cancel; PMS update needed.", request_id: "cancel", version: @visit.reload.version, now: @now)
    assert_equal 0, batch(now: @now + 6.days)
    assert_equal "scheduled", @visit.reload.source_status
    assert_equal "canceled", @visit.disposition
  end
end
