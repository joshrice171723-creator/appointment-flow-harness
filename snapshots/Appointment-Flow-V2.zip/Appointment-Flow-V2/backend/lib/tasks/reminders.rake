namespace :reminders do
  desc "Refresh PMS and record eligible fake reminders for each clinic"
  task run: :environment do
    Clinic.find_each do |clinic|
      puts "#{clinic.name}: #{ReminderBatch.call(clinic: clinic, now: DemoClock.now)} fake attempts"
    end
  end
end
