# Apex Appointment Flow — independent rebuild

Rails + React assessment application using only the supplied harness, assessment and screenshots. Two fictional clinics, fake SMS/email, a clinic-scoped front desk, aggregate leadership reporting and a patient reply simulator. Nothing is sent to a live provider.

## Run on Windows

Prerequisites: Ruby 3.4 with Bundler, Node 24/npm, Python 3.11+, Docker Desktop with Linux containers. This implementation was built with Rails 8.1.3.1. Package versions are pinned in the lockfiles.

From this directory in PowerShell:

```powershell
powershell -File scripts/setup.ps1
powershell -File scripts/start.ps1
```

Open **http://127.0.0.1:3185**. Setup verifies the original harness before installing application dependencies, creates an isolated `apex-rebuild-db` PostgreSQL container on loopback port 15435, creates separate application and PMS replica databases (plus an isolated pair for tests), migrates only the application databases, seeds the demo only when the replica source tables are empty, and builds the React assets. Startup serves the built React application and API through one Rails process. Ctrl+C stops Rails; `docker stop apex-rebuild-db` stops this demo's PostgreSQL server. Container deletion destroys demo data; setup never deletes existing data.

The startup script uses a clearly displayed **demo clock**, frozen at 18:00 UTC on the current day (noon Austin and 11 AM Phoenix in November), so reminders can be demonstrated inside clinic sending windows. To choose a fixed exercise date:

```powershell
$env:APEX_DEMO_NOW = '2026-11-15T18:00:00Z'
powershell -File scripts/start.ps1
```

Seed dates are relative to the clock used during setup. Restarting on another day does not move existing appointments. Direct Rails commands without `APEX_DEMO_NOW` use real time. Set it to the seed exercise date for reproducible demonstrations.

For frontend development, run Rails on 3185 and `npm.cmd run dev` in `frontend`; open 5185. Vite proxies `/api` to Rails. Rebuild before viewing frontend changes through Rails.

## Exercise the workflows

1. Open **Front desk**, choose Austin and Taylor Morgan. Inspect needs-attention and in-progress work, search/filter it, and open a patient. Record an attempted contact or confirm the current appointment with a note. Contact corrections are app-owned, audited and leave original PMS values visible.
2. **Run fake reminders** refreshes PMS first and records eligible delivery attempts. **Refresh PMS** updates the local snapshot without sending. Appointment date navigation and confirmation filters show source outcomes separately from confirmation.
3. Return to Workspaces, open **Patient demo**, select Austin → Avery Demo. Inspect Text messages, submit `YES`, and inspect the resulting confirmation at the front desk. `NO` and uncertain replies require review; exact `STOP` suppresses that contact channel for that clinic. The Email tab uses the same inbound rules. Riley Demo has deterministic fake SMS failure; Sam Demo is email-only. Other fixtures include minors, unsupported language, shared contacts and invalid contacts.
4. Choose Phoenix at the workspace entry to inspect independent clinic work.
5. Open **Apex leadership**, select the reporting month, and expand activity details. All leadership responses contain only clinic aggregates. Completion is PMS `complete` / all recorded visits, and does not establish no-shows or reminder causation.

Run reminders from the terminal:

```powershell
Set-Location backend
$env:APEX_DEMO_NOW = '2026-11-15T18:00:00Z'
bundle exec ruby bin/rails reminders:run
```

The inbox POSTs to `/api/clinics/:clinic_id/replies` with `channel` (`sms` or `email`), `recipient`, `body`, unique `external_id`, and optional `message_id` from a sent message. Reusing an event ID with the same payload returns the existing result; conflicting reuse is rejected. Automatic YES requires safe current contact, unambiguous appointment context, a current successful outbound message and a future scheduled visit. API examples and tests exercise the same code path as the UI.

## Checks

```powershell
python quality/verify_harness.py
python quality/run_checks.py
# With the app running at 3185, for a demo seeded on November 15:
Set-Location frontend
npm.cmd run smoke
```

The quality runner checks original harness integrity, Rails domain/API tests, exact source-schema and database ownership tests, RuboCop Rails style, React hooks/lint and Prettier formatting, UI save-failure tests, TypeScript and production build. Browser smoke tests use installed Microsoft Edge and write screenshots to `tmp/screenshots`. They use the seeded development demo, so they record fictional replies. Backend tests use only `apex_rebuild_test` and `apex_pms_test` and replace their fixtures; they never touch the development databases. Browser tests target the documented fixed November 15 demo clock.

The scoped npm override moves the TypeScript lint parser's `minimatch` dependency to the fixed 11.x line. It uses the same named matching API, and lint/build/tests check this combination. Remove the override when the parser adopts the fixed dependency itself. `npm.cmd audit` inspects the full locked dependency tree.

## Source boundary and operating assumptions

The **`apex_pms_development` replica database** contains exactly the supplied `clinics`, `patients` and `appointments` tables in its public schema, including the original column types, nullability, primary keys and foreign keys. It has no application tables, Rails metadata or added columns. A fixture-only administrative connection creates and seeds it. Runtime reads use a dedicated `apex_pms_reader` connection with SELECT-only grants and a read-only connection default. The `apex_app` role cannot connect to PMS. The separate **`apex_rebuild_development` application database** retains source snapshots, revisions, local verified contacts, opt-outs, messages, replies and follow-ups. Tests have a separate matching database pair. `PMS_HOST`, `PMS_PORT` and `PMS_DATABASE` configure the source connection independently from the application connection.

Source refresh reads all three source tables in one SQL statement and commits the local snapshot atomically. An empty source, disappearing known appointment or read failure blocks sending and retains previous data. This deliberately conservative policy requires investigation if an upstream replica legitimately deletes historical rows. The upstream five-minute replication lag cannot be eliminated here.

Appointments use clinic wall-clock timestamps, explicit IANA timezone mappings and fresh revisions after schedule changes. A reschedule back to an earlier time still has a new revision. Unknown/DST-ambiguous times are held. Initial requests are eligible within seven local days, backup email within six after unanswered SMS, follow-up within three and final within one; missed steps coalesce. Sending is restricted to 10:00–18:00 local time and always before appointment start. Confirmed visits get only a final informational reminder. A failed fake send is recorded once per logical step; a safe email fallback is attempted without retry loops.

For this fictional exercise, a valid adult's own contact is assumed permitted unless opted out. Shared contacts are unsafe for automatic outreach on that channel; a unique alternative channel may be used. Minors require staff verification of guardian authorization and guardian contact. Unsupported languages, missing ages, unsafe contacts and source/local verification conflicts create contact holds. These assumptions require actual consent records and recipient verification before production use.

The demo staff header is an identity stub, not authentication. Every staff record lookup is constrained by the selected clinic on the server, but a caller can select another clinic. A production system needs authenticated identities, clinic memberships, signed inbound webhooks, real consent and guardian evidence, audited access, retention policy, secrets management, request throttling and provider-specific delivery/retry handling. The fake adapter never makes network requests, so a committed fake send is inspectable atomically; this is not an exactly-once guarantee for a real vendor.

The shared transaction lock intentionally serializes workflow mutations. It makes concurrent behavior straightforward for this local assessment; this build does not claim measured throughput at the employer's daily volume. No booking, self-service rescheduling, real auth, real vendors or deployment infrastructure was added. Staff cancellation/reschedule follow-up suppresses local messaging; actual schedule changes remain in the PMS.

## Deliverables and evidence

- [Architecture and state flow](ARCHITECTURE.md)
- [Agent/tool attribution](AI_USAGE.md)
- [Candidate decision notes](notes/REBUILD_DECISION_NOTES.md); [candidate-owned narrative status](DECISIONS.md)
- [Implementation plan](notes/IMPLEMENTATION_PLAN.md), [build evidence](notes/REBUILD_LOG.md), [independent review](review/INDEPENDENT_REVIEW.md), [freeze evidence](review/REBUILD_FREEZE.md)

The original harness files and manifest remain unchanged. Application evidence is stored in new files so preflight can continue to verify the supplied archive. The reference screenshots establish visual states; the implementation and tests establish behavior. Final candidate-written DECISIONS.md and live defense remain human work. No old repository was accessed, and no publication or old-code comparison is part of this rebuild.
