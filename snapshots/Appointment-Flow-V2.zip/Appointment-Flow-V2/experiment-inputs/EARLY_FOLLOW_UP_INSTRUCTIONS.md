# V2 early follow-up instructions

Verbatim saved user messages, in chronological order. Headings are packaging annotations; message bodies are unchanged.

## User message 3 ? 2026-11-15T14:53:28.643Z

there was a hard rule we have two seperate db the PMS DB needs to be 100% exactly like the one in the brief this intentionally creates complications.

## User message 4 ? 2026-11-15T14:57:54.036Z

sorry as long as the schema is seperated and  we have a replica db

