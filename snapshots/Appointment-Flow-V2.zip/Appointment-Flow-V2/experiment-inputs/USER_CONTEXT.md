# V2 supplied user instructions

Verbatim saved user messages, in chronological order. Headings are packaging annotations; message bodies are unchanged.

## User message 0 ? 2026-11-15T14:19:36.005Z

# AGENTS.md instructions

<INSTRUCTIONS>
## 1. Execution Philosophy
- Treat my workspace as a engineering environment there are NO USER NO REAL DATA.
- Prioritize action over explanation. If a task requires editing a file or running a command, output the code or tool call immediately with minimal conversational text.
- Do not stop to ask for permission to read directories, inspect files, or check local configurations.

## 2. Granular File & Directory Access
- Use an existing index or recursive file listing to map the relevant architecture before structural edits. Read the context the change needs; do not repeat a whole-repository survey for a narrow edit.
- Read complete files when structural context is needed; avoid partial snippets that lead to broken imports or mismatched syntax.
- When modifying code, ensure all edits are fully realized with no truncated sections or placeholder comments.

## 3. Terminal & Workflow Execution
- Run checks appropriate to the change. Use focused regression checks for changed behavior; reserve full suites for cross-cutting changes or requested acceptance checks. Instruction-only or documentation-only changes need content and reference validation, not an unrelated app suite.
- If a command throws a runtime or compilation error, analyze the trace, modify the files accordingly, and re-run the verification automatically.



Before repository work, verify the active checkout, remote, branch, and dirty files, then synchronize with the actual upstream/default branch (main or master, whichever exists). Preserve unrelated changes; do not reset, stash, or commit them automatically. After changing repository files, synchronize again, resolve relevant conflicts, commit only the task's changes, and push as authorized. If there is no remote, report that limit rather than repeatedly attempting a nonexistent origin. Local harness files outside Git do not require creating a repository just to commit them.



ignore the shortcut rules 

## Product copy

Write functional copy for apps and internal tools. Use plain titles, labels, status messages, and instructions that help users do their work.

Add promotional hero copy, taglines, slogans, product pitches, or decorative filler only when the user explicitly requests that kind of copy for that surface. Requests to design, redesign, or polish a screen call for functional copy by default.

Before handing off UI work, review every new or changed user-visible string. Keep it if it helps someone understand where they are, what happened, or what they can do next. Remove unsolicited promotional or decorative text and flag it in review.

## Engineering judgment learned from Apex

- Honor the brief, accepted scope, and Joshua's latest corrections. Allocate effort by user frequency and consequence. Do not turn deliberate cuts into defects or reintroduce rejected features through an audit. Keep project-specific exclusions local.
- Check another agent's finding against current source before acting. Agreement and high scores are not proof; distinguish defects, risks, preferences, and unchecked paths.
- Assess comprehension separately from tests: trace an entry point through its rule owner, writes, and visible result. Prefer familiar conventions, explicit contracts, and obvious transaction ownership. Extract only to reduce reader effort; remove superseded paths.
- Choose the smallest complete design. Workers, migrations, and dependencies can earn their place through a demonstrated need; explain their operating cost rather than reflexively adding or rejecting them.
- Make demo states and totals traceable to records, events, or explicit assumptions. Preserve inspectable raw source values and the actual source-write boundary.
- Measure whole-command performance, including setup and repeated work. Inspect cumulative cost before adding concurrency or caches. Preserve meaningful transaction/retry/concurrency coverage; distinguish best and repeat timings.
- Tie evidence to its revision and scope. Separate source inspection, tests, running behavior, packaged artifacts, and human acceptance. Check extracted deliverables when packaging; never promote historical checks to a current pass.
- Distinguish Joshua's decisions and objections from AI implementation and wording. Preserve personal notes unless rewriting is requested. Do not infer authorship from style or invent rankings among unseen candidates.
- Finish the agreed checks, then stop expanding. Report actual results and evidence gaps without inventing human acceptance or claiming future agent behavior is proven.
</INSTRUCTIONS>
<environment_context>
  <cwd>C:\Users\joshr\RubymineProjects\appointment-flow_v2</cwd>
  <shell>powershell</shell>
  <current_date>2026-11-15</current_date>
  <timezone>America/Chicago</timezone>
  <filesystem><workspace_roots><root>C:\Users\joshr\RubymineProjects\appointment-flow_v2</root><root>C:\Users\joshr\AppData\Local\JetBrains\RubyMine2026.3\ai-agent-extensions\agents\air-views\4bea65ff44448ab8aa2e8f2c15063eea\codex\7f9a8cc292aec9f1</root></workspace_roots><permission_profile type="disabled"><file_system type="unrestricted" /></permission_profile></filesystem>
</environment_context>

