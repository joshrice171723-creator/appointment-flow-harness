Execute the rebuild, but require the harness to pass its preflight verification first.

The goal is to build the Rails + React assessment application from scratch, using the harness to enforce code quality—not spend more time reviewing instructions.
