# Patient detail and appointment history trial

## Scope and contract

Frozen checkout `0f4e6cf`, local `main`, clean at intake, with no configured remote. The checkout already included the Active Record page lookup and the two history indexes. The external PMS migrations and supplied fields are fixed. All commands used the launcher's PostgreSQL instance. Review mode is self-review. Independent evaluation remains outside this checkout.

| Request | Access and result | Persisted effect |
| --- | --- | --- |
| `GET /api/patient-details/:id` | Staff workspace and messaging clinic. Patient has a source booking or tracked visit in that clinic, or is explicitly authorized by a patient with that activity and the matching current PMS guarantor link. Return the existing case and patient details, outreach, upcoming appointment, bounded recent visits and activity. | None |
| `GET /api/patient-details/:id/history?section=appointments` | Same access. Page size 25 with one extra key for the cursor, optional appointment filter, clinic-local date boundary, descending time and appointment ID. The source date leads for source rows. When the source row is missing or reassigned, use the latest date among the clinic and patient's tracked revisions and preserve stored visit facts. | None |

The access owner is `ContactProfilesQuery` via `DeskController`. The page and revision owner is `PatientAppointmentsQuery` via `PatientWorkspaceHistory`. `CaseDetailQuery` composes the detail response, `ActivityHistoryQuery` owns its recent activity, and `ContactPolicy` owns recipient and channel eligibility. The browser uses these existing routes and keys. Dedicated activity and follow-up history tabs, full-clinic peer matching, reporting, source refresh, and delivery throughput are outside the performance slice.

## Frozen baseline

- From `backend`, `ruby -Itest -e "require './test/patient_workspace_test'; require './test/patient_details_test'"` ran 8 tests and 97 assertions with zero failures, errors, or skips. The additional guarantor test passed against the frozen app with 20 assertions. It exercised both GETs, a ward with only another clinic's booking, a local noncurrent tracked visit, a stale PMS link, and an authorization updated to match the new PMS link.
- The Rack probe measures each request five times after a warm-up. It collects Rails SQL events and record counts on the request thread. It runs `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` separately for the captured SELECTs. Fixtures, ANALYZE, and plan execution are outside request timings.
- The grown fixture adds 16,000 same-clinic bookings, people with permissions, tracked visits, cases, open issues, receipts and items, opt-outs, and pairs of delivery and PMS-change events. The guardian request has matching additional wards. Another 1,000 linked delivery events reach the displayed visit's event preload and are excluded from the result's activity stream. The probe compares byte-for-byte response hashes and records writes. This is a synthetic request workload.

| Request | Fixed bytes | SQL small → grown | Rows returned small → grown | Models small → grown | Median ms small → grown |
| --- | ---: | ---: | ---: | ---: | ---: |
| Detail | 4,623 | 43 → 43 | 40 → 17,040 | 44 → 2,044 | 203.26 → 1,152.28 |
| Past page 1 | 7,868 | 19 → 19 | 64 → 64 | 36 → 36 | 109.31 → 323.11 |
| Past page 2 | 3,708 | 19 → 19 | 33 → 33 | 21 → 21 | 107.71 → 714.15 |
| Appointment-filtered history | 495 | 18 → 18 | 12 → 12 | 10 → 10 | 85.89 → 246.42 |
| Guardian detail | 1,654 | 14 → 14 | 9 → 9 | 4 → 4 | 75.93 → 388.77 |

The baseline performed zero writes on all requests. Direct access scanned 296 → 16,296 appointment rows returned by its clinic subplan, with a further 260 rejected in both fixtures. Guardian access went from 45 to 1,189 root shared blocks in the frozen replay. The tracked second page went from 16 to 230 blocks, including an exclusion subplan that rejected 221 → 16,221 visits. The appointment-filtered request still discarded 33,167 events and 16,049 issues on the grown fixture. Detail activity took 13 → 991 blocks and the opt-out lookup transferred 1 → 16,001 values. The first run before implementation exposed the same growth. The table uses the preserved replay capture from the frozen revision.

## First implementation and grade

Checkpoint `acb8a00`. **REVISE.** The first implementation eliminates the clinic-wide direct access lookups and adds a patient-leading visit index to support both sides of tracked paging's date and cursor rule. It scopes appointment rows to the displayed keys, limits reply summaries to the latest reply IDs, reads pending events by visit ID, and selects opt-outs by the policy's normalized recipient and clinic. Recent activity uses separately bounded case and visit event queries and a receipt index keyed by clinic and patient. Both links of an authorized guarantor are still required.

The focused command used `ruby -Itest -e "require './test/patient_workspace_test'; require './test/patient_details_test'; require './test/reply_test'; require './test/replica_test'"` and passed 22 tests and 215 assertions. This covers exact order across equal-time cursor pages, microsecond and clinic wall time boundaries, missing and reassigned history, reply review anchored to one visit but displayed on its other candidate, latest reply by ID, pending changes, STOP scope, and real source grants. The measured five request bodies remained byte-identical to the baseline. The appointment-filtered history held at 13 transferred rows and 10 models. Its track lookup took 8 blocks in both sizes, and the second full page's tracked key lookup took 10 blocks in both sizes.

| Criterion | First grade | Evidence or remaining work |
| --- | --- | --- |
| Required behavior | PASS | The focused request and reply tests checked the existing response, scope and fake receipt workflow, including ambiguous and confirmed results. |
| Safety and data boundaries | PASS | The guardian challenge changed the PMS link and local authorization across repeated real reads. Reassigned rows kept the former visit facts. Replica tests checked the supplied columns and denied writes with the reader role. |
| Performance and Rails queries | REVISE | The grown guardian query still scanned appointments first. Its positive check used 794 shared blocks and looped over 261 patient key lookups. The detail's visit activity plan discarded 250 linked delivery events per loop over four visits and rose from 10 to 32 blocks. |
| Material workflow coverage | PASS | The probe reached both GET routes and the shared access, rendering and policy owners. The covered API cases are listed above. |
| Human readability | PASS | Eligibility begins at `DeskController#scoped_patient`, page membership stays in `PatientAppointmentsQuery`, and the selected recipient feeds one indexed opt-out lookup in `ContactPolicy#decision`. |
| Ease of change | UNVERIFIED | The disposable page-size exercise had yet to run. |
| Failure and transaction behavior | PASS | Invalid or cross-clinic scope returns 409. Missing and reassigned source rows retain visit facts. Neither GET wrote rows in repeated probes. The paired source and tracked key reads still use the existing repeatable-read transaction. |
| Verification and handoff | REVISE | The focused tests passed. The all-tests gate was pending. The unmodified repository-wide Active Record checker still reported inherited findings. |

## Repairs

Checkpoint `1e54140`. The guardian lookup now starts with a bounded, ordered permission lookup using the clinic and requested guardian as keys. It checks the current PMS link and activity for each batch and stops on a qualifying ward. The added regression puts 26 stale permissions before the valid one. A negative lookup may require further batches of wards who actually name that guardian in permissions. A standard partial B-tree on app-owned visit events supports the exact activity predicate. The new activity regression spans both event sources, checks the 60-event bound and ID tiebreaker, deduplicates an event with both scopes and preserves a legacy delivery event without a receipt.

Checkpoint `500c78e`. A second review of the access rule found that separate reads of a ward's PMS link and clinic activity could straddle a source refresh and combine conditions from two different snapshots. In `ContactProfilesQuery#authorized_ward_activity?`, every positive booking or visit test now checks the ward's permission, PMS link, and activity in one SQL statement. The earlier ID batch bounds the possible input to each statement. The compatibility test exercises a changed mirror link across requests. The statement structure verifies the single-snapshot predicate. Concurrent refresh was not forced at that exact point in the HTTP test.

The focused guardian regrade repeated the actual detail request with the same 16,000 added patient, permission, booking, and visit rows. Both responses kept the baseline's 1,654 bytes and SHA-256. The final recheck used 8 → 10 blocks across fixture sizes and examined one indexed appointment and one indexed patient in the grown plan. The permission batch used 2 → 5 blocks and returned 1 → 25 IDs. The whole request held at 19 statements and four model instantiations, transferring 11 → 35 rows with zero writes. This bounded the extra work visible in the first implementation's 794-block grown plan.

### Change exercise

In a disposable archive of `1e54140` under the local evidence directory, one production line changed `PatientWorkspaceHistory::PAGE_SIZE` from 25 to 10. The copied test expected 10 first-page items. From the copied `backend`, `ruby test/patient_workspace_test.rb --name '/test_history_pages|test_appointment_history_uses_scoped_source_dates/'` passed 2 tests and 30 assertions. Across the changed capacity, pages retained their order, completed without duplicate IDs and rejected a cursor used for another section. The neighboring date and reassignment test passed with its original assertions. The later access repair uses the same paging contract.

## Data-source and source-check findings

The catalog check on PostgreSQL 17.11 found ordinary tables for all queried `desk` and `pms` sources and confirmed the seven new indexes are all B-trees on app-owned tables. The visit activity index uses a receipt-delivery predicate. Index entries add maintenance to writes on those existing tables. Each request remains read-only and the migrations create no derived columns or separate synchronization work. The source replica migrations and import/read code match the frozen snapshot. The replica request suite separately checks all supplied columns, key constraints, raw read values and SELECT-only grants. The cache keeps the original timestamp and character column declarations.

The supplied repository-wide Active Record checker ran against the migrated database and exited 1 on all examined revisions. The repair removed the two scoped findings at the original `DeskController#scoped_patient` and `CaseDetailQuery#issues`. The 16 remaining locations were present in the frozen snapshot. They cover the database clock in `SourceSync.status`, JSON candidate lookup in `FollowUpIssue.for_visits` used by delivery and the follow-up tab, reporting expressions, database setup and advisory locking, and PMS refresh SQL. The manual source trace also found `arel_table` in the unchanged non-appointment history paginator. The detail response still reads the database clock for its freshness flag. It is constant work and retains its database-clock semantics. See `.refactor-harness/review/final-source-check.log` and `final-data-sources.log` for exact locations and catalog output.

The fixed-response probe grows activity and data unrelated to the selected patient, plus excluded delivery rows associated with one displayed visit. Growth from more case issues or revisions in the actual response remains unmeasured. Open reply-review candidates are still evaluated for the selected patient's case. Receipt and event history limits, the entire-case issue response, and revision-field payloads follow the existing API contract.

## Regrade measurements

The complete workload recheck ran on `1e54140`. The focused guardian replay verified the only subsequent query change in `500c78e`. The direct access path and other queries retain the complete-workload measurements. A comparison of the preserved frozen, first, complete-repair and focused-guardian captures matched every recorded response status, byte count and SHA-256. Every request sample recorded zero write statements, affected rows, and returned write rows. Fixture setup, database analysis and plan capture account for substantial wall time outside the request timings. Request timing varied with machine load, so the grade uses returned rows and executed plans.

| Request | Fixed bytes | SQL small → grown | Rows returned small → grown | Models small → grown | Median ms small → grown |
| --- | ---: | ---: | ---: | ---: | ---: |
| Detail | 4,623 | 46 → 46 | 41 → 41 | 32 → 32 | 213.70 → 185.80 |
| Past page 1 | 7,868 | 20 → 20 | 65 → 65 | 36 → 36 | 455.69 → 101.41 |
| Past page 2 | 3,708 | 20 → 20 | 34 → 34 | 21 → 21 | 270.43 → 221.74 |
| Appointment-filtered history | 495 | 19 → 19 | 13 → 13 | 10 → 10 | 76.11 → 79.70 |
| Guardian detail, `500c78e` focused | 1,654 | 19 → 19 | 11 → 35 | 4 → 4 | 99.83 → 91.22 |

- Grown detail direct access used four blocks and one appointment index entry. The opt-out probe used two blocks and the existing clinic-and-destination primary key. The grown visit activity node used the new partial B-tree, four loops and zero rows removed by filter. It took 12 blocks compared with 32 on the first implementation. Rails sent this activity query with bind values and without a named prepared statement. The first implementation's case activity and receipt paths remained selective.
- The grown second page served both date projections through `visit_patient_history` with 10 blocks, versus the frozen plan's 230. Its exclusion projection returned three scoped visit keys and filtered one. The query still uses the current source mirror to exclude appointments owned by the same patient and clinic and consults later tracked revisions before accepting a historical date.
- The appointment-filtered request uses indexed event and case lookups. The grown baseline had scanned 33,167 events and discarded 16,049 issues to find the same one row in the response.

## Final grade for `500c78e`

**REVISE.** Scoped request behavior and the measured growth checks passed. The repository-wide Active Record source gate remains red. A full native backend run passed, while a second seeded run hit a query-budget assertion in reconciliation.

| Criterion | Grade | Failure challenged and observed result |
| --- | --- | --- |
| Required behavior | PASS | In `FlowTest#test_reply_review_and_confirmation`, the patient API records the ambiguous reply for review and the staff API resolves the seeded clinic case and records confirmation. The test compares the fake receipt, raw phone, reply, provider and resulting confirmation. The scoped detail and history tests check the request contracts in this report. |
| Safety and data boundaries | PASS | The guardian test covers another clinic's booking, a valid historical local visit, 26 stale permissions and a changed mirror link. The detail and history GETs enforce the same scope. The appointment history tests exercise both kinds of reassignment and keep earlier confirmation facts on the historical revision. Replica tests validate the supplied schema and SELECT-only role. |
| Performance and Rails queries | PASS for the measured scope | All tested request bodies were fixed under growth with zero writes. The grown tracked-page, opt-out, guardian and activity plans above show selective work. The changed application predicates use Active Record. Growth and inherited-source limits are recorded above. |
| Material workflow coverage | PASS | Both normal Rack entry points, first and second history pages, the appointment filter and guardian access were exercised. The suite also verified the detail-to-case workflow and the shared contact and response rules. |
| Human readability | PASS | Guardian qualification is visible in `ContactProfilesQuery#authorized_ward_activity?`. To change which activity qualifies, edit the two scoped projections there. To change the bounded recent activity rule, edit `ActivityHistoryQuery#recent_events`. The event merge regression checks the order, cutoff, and duplicate handling. |
| Ease of change | PASS | The local archive exercise changed one production constant and verified the new page size, exact order and cursor behavior alongside unchanged date and reassignment behavior. |
| Failure and transaction behavior | PASS | Bad visibility or cursor combinations return 409. Historical visits render when source rows are missing or moved. Requests perform no writes, and the source and tracked key projections keep their shared read transaction. The contact verification and failed-refresh tests still exercise the owning write workflows. |
| Verification and handoff | REVISE | `ruby test/all.rb` from `backend` bootstrapped absent app and source databases via migrations and seeds. Seed 39306 passed 122 tests and 1,852 assertions on `500c78e`. Seed 21997 ran 122 tests and 1,851 assertions with one failure at `test/model_boundaries_test.rb:203`: the existing reconciliation assertion saw 13 SQL statements against a limit of 12. The source gate findings and actual schema checks are listed above. |

The passing full run used the native README command and an empty database pair. The actual reminder, reply, staff and patient pages were exercised through their local API entry points. Browser rendering was outside this backend slice.

The reconciliation failure did not reproduce when running `ruby test/model_boundaries_test.rb --seed 21997` from separate empty database pairs on the frozen `0f4e6cf` archive and `500c78e`. Each focused run passed 13 tests and 72 assertions. The reconciliation code, its follow-up owner, and the assertion match the frozen snapshot. The cause of the full-suite count difference remains unresolved. Exact logs are `final-gate.log`, `regrade-gate.log`, `reconciliation-baseline.log` and `reconciliation-current.log` in the evidence directory.

## Reproduction

Run the native setup and test commands from `backend` using the launcher's URLs. The probe can boot a fresh disposable test database via the existing test helper, or reuse an already migrated and seeded test database with `PATIENT_PROBE_REUSE_DATABASE=1`. It pins and rolls back the fixture transaction. It sets stable IDs and a fixed request date, and uses the actual Rack routes and SQL sent by Rails. The plans are captured with bind values, then executed outside the sampled requests. The final run limits ANALYZE to the relations used by the probe.

```powershell
$env:PATIENT_PROBE_REUSE_DATABASE = '1'
$env:PATIENT_PROBE_OUTPUT = '../.refactor-harness/review/reproduced.json'
ruby ../.refactor-harness/review/patient_request_probe.rb
python ../.refactor-harness/review/summarize_patient_probe.py ../.refactor-harness/review/reproduced.json
$env:RAILS_ENV = 'test'
ruby bin/rails runner ../.refactor-harness/quality/check_active_record_queries.rb
```

Probe logs, request metrics and full plans are under `.refactor-harness/review/` as `baseline-fast.json`, `first.json`, `final.json` and `guardian-regrade.json`. The frozen replay ran the archived `0f4e6cf` application on a cloned disposable database rolled back to migration `20261116000001`. It used `PATIENT_PROBE_FAST_GROWTH=1` for equivalent bulk fixture population outside the measured requests. The focused guardian command sets `PATIENT_PROBE_GUARDIAN_ONLY=1` to grow just the relevant relations. The Active Record API patterns were checked against the installed 8.1 series. [Active Record Query Interface](https://guides.rubyonrails.org/v8.1/active_record_querying.html)
