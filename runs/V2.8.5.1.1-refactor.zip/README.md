# V2.8.5.1.1-refactor

Patient appointment read refactor on the original app. Response bodies and cursors matched. One upcoming-history query still scans the mirror.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
