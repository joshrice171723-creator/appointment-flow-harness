# Components and state

```mermaid
flowchart LR
  UI[React workspaces] -->|local HTTP| API[Rails resource controllers]
  API --> Refresh[Pms::Refresh]
  API --> Batch[Reminders::Run]
  API --> Reply[Replies::Record]
  API --> Staff[Staff follow-up / contact verification]
  Batch --> Refresh
  Reply --> Refresh
  Staff --> Refresh
  Refresh -->|repeatable read| PMS[(pms schema: read-only runtime connection)]
  Refresh -->|bulk changed rows| Local[(public schema: local state)]
  Batch --> Fake[Deterministic fake transport]
  Batch --> Local
  Reply --> Local
  Staff --> Local
  API -->|bounded queries / aggregates| Local
```

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: source snapshot
  Unconfirmed --> Confirmed: safe current YES or staff confirmation
  Unconfirmed --> Review: NO / uncertain / stale / late / mismatched reply
  Confirmed --> Review: later conflicting intent
  Review --> Confirmed: staff clarification for current visit
  Confirmed --> Unconfirmed: source appointment revision changes
  Unconfirmed --> Closed: source outcome or staff canceled/rescheduled
  Confirmed --> Closed: source outcome or staff canceled/rescheduled
```

Confirmation belongs to a revision derived from source appointment ID, patient ID, wall time, and status. The source outcome remains separate. Reminder uniqueness uses visit, revision, step, and channel. Reply uniqueness uses clinic and external event key. Staff writes use person and request key, with payload checks. STOP creates a separate recipient/channel/clinic suppression, independent of source refresh.

Each consequential owner takes a clinic row lock, refreshes a coherent source snapshot, validates current authoritative inputs, and commits local writes together. The fake transport returns a deterministic result; message attempts are local database records. Provider rejection persists as a failed attempt. Unexpected errors propagate and roll back local effects. Refresh failures are translated only at the source-read boundary and retain their cause. A failed batch records its source error after rollback.

Raw contact values remain in `people.raw`. Local overrides and the raw values against which they were verified remain separate. `Pms::Refresh` owns canonical phone/email derivation and invalidation. `Staff::VerifyContact` uses that same derivation when changing overrides. Indexed canonical values support shared-recipient existence checks across the complete clinic directory. Clinic timezones are explicit configuration; ambiguous or nonexistent DST wall times do not become guessed instants.

Controllers own screen scopes, filters, bounds, and response fields. Models own their own persistence and contact rules. Workflow objects own cross-record decisions and transactions. No queue, repository layer, global React store, or generic service hierarchy is needed. `useResource` owns the repeated fetch lifecycle and binds results to their clinic/request key. Mutations stay in event handlers and are never retried automatically.

Increment `Person::CONTACT_POLICY_VERSION` when changing canonical contact derivation. The snapshot digest includes this version, so the normal refresh rederives existing data after a policy change. Source upserts return the source/local patient keys used to assemble visit links. Visit upserts return no unused IDs.

The fake inbound contract includes an outbound message ID. The patient demo chooses that message explicitly. Matching still checks the sender, channel, current source revision, contact safety, shared contacts, time, and suppression. A real SMS integration must establish a safe correlation and identity contract; the demo does not prove one exists.
