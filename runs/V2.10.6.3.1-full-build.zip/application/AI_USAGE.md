# AI usage record

Codex implemented this clean-room application from the supplied assessment, sanitized specifications, screenshots, and harness. The host identifies the agent as GPT-6 based; an exact deployed variant is not exposed. It read the current project, used PowerShell, Ruby/Rails, Node/npm, Python, PostgreSQL, and normal test tools. No optional skills, external review plugins, other people, or prior application code were used.

The agent inspected all ten supplied screenshots and extracted the official five-page PDF with pypdf. It consulted the official Rails query guide and React effect guide for generic framework conventions. It generated the implementation, tests, factual notes, architecture, and AI review. The candidate did not author this code during the recorded session.

It also checked the published picomatch advisory after npm audit reported affected development dependencies. No patched release was available. The audit failure is retained as a handoff limit; no forced toolchain downgrade or audit suppression was used to claim a fix.

Corrections during implementation included a schema dump that omitted the PMS schema, an Active Record association cache read after bulk insertion, TypeScript/ESLint peer-version compatibility, and retaining conflicting replies in the staff work list. Actual verification and later repair results are recorded in the build log and rubric report.

While diagnosing dependency setup, a tool read unrelated npm command metadata from the shared npm log directory. It exposed command paths, not application source. No implementation or decisions were taken from that metadata. Subsequent npm logs are confined to this project's `frontend/npm-logs` directory.

Review uses a dedicated AI self-review under `docs/AI_LOOP.md`; it is not an independent human acceptance or comparison with the prior product. The candidate must write `DECISIONS.md` personally and complete the live defense. No external publication, push, PR, or submission occurred.
