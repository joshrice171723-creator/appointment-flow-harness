import { expect, test } from "@playwright/test";

test("front desk, leadership and patient inbox work at desktop and narrow widths", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Workspaces" })).toBeVisible();
  await page.getByRole("link", { name: "Open front desk" }).click();
  await expect(
    page.getByRole("heading", { name: "Patient flow" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Refresh PMS", exact: true }).click();
  await expect(
    page.getByText("PMS snapshot refreshed.", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Run fake reminders" }).click();
  await expect(page.getByText(/fake messages sent\./)).toBeVisible();
  await page.getByRole("link", { name: "Appointments", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Appointments", exact: true }),
  ).toBeVisible();
  await page
    .getByLabel("Jump to date")
    .fill(new Date(Date.now() + 7 * 86400000).toLocaleDateString("en-CA"));
  await expect(page.locator("tbody tr").first()).toBeVisible();
  await page
    .getByRole("link", { name: "Patient details", exact: true })
    .first()
    .click();
  await expect(
    page.getByRole("heading", { name: "Patient details", exact: true }),
  ).toBeVisible();
  await page.getByText("Verify or correct contact", { exact: true }).click();
  await expect(page.getByLabel("Verification note")).toBeVisible();
  await page.getByRole("link", { name: "Workspaces" }).click();
  await page.getByRole("link", { name: "Open Apex leadership" }).click();
  await expect(
    page.getByRole("heading", { name: "Appointment outcomes" }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Clinic comparison" }),
  ).toBeVisible();
  await page.getByText("Contact and follow-up holds", { exact: true }).click();
  await expect(
    page.getByText(
      "Counts group the current issue on each visit in this month.",
    ),
  ).toBeVisible();
  await page.getByRole("link", { name: "Workspaces" }).click();
  await page.getByRole("link", { name: "Open patient workspace" }).click();
  await page
    .getByRole("combobox", { name: "Clinic", exact: true })
    .selectOption({ label: "Austin" });
  await page
    .getByRole("combobox", { name: "Patient", exact: true })
    .selectOption({ label: "Demo Patient 1" });
  await expect(page.locator(".message").first()).toBeVisible();
  await page
    .getByRole("combobox", { name: "Reply to", exact: true })
    .selectOption({ index: 1 });
  await page.getByLabel("Your reply", { exact: true }).fill("YES");
  await page.getByRole("button", { name: "Send simulated reply" }).click();
  await expect(
    page
      .getByRole("status")
      .filter({ hasText: /Appointment confirmed|Reply recorded/ }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Email", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Message history" }),
  ).toBeVisible();
  await expect(
    page.getByText("No simulated emails for this patient yet."),
  ).toBeVisible();
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(
    page.getByRole("heading", { name: "Patient inbox" }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({ path: "../review/inbox-mobile.png", fullPage: true });
  await page
    .getByRole("combobox", { name: "Patient", exact: true })
    .selectOption({ label: "Demo Patient 2" });
  await expect(page.locator(".message").first()).toBeVisible();
  await page
    .getByRole("combobox", { name: "Reply to", exact: true })
    .selectOption({ index: 1 });
  await page.getByLabel("Your reply", { exact: true }).fill("YES");
  await page.getByRole("button", { name: "Send simulated reply" }).click();
  await expect(
    page
      .getByRole("status")
      .filter({ hasText: /Appointment confirmed|Reply recorded/ }),
  ).toBeVisible();
  await page.getByRole("link", { name: "Workspaces" }).click();
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({
    path: "../review/workspaces-desktop.png",
    fullPage: true,
  });
  expect(errors).toEqual([]);
});

test("staff and leadership pages fit a narrow viewport", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  for (const route of ["#/desk/1", "#/appointments/1", "#/leadership"]) {
    await page.goto("/" + route);
    await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
    await expect(page.getByText("Loading…", { exact: true })).toHaveCount(0);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
  }
});
