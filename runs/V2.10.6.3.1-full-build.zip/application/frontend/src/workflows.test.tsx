import {
  act,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { afterEach, expect, test, vi } from "vitest";
import { FollowUpForm } from "./PatientDetails";
import { useResource } from "./api";
import type { Visit } from "./api";

afterEach(() => vi.unstubAllGlobals());
const visit: Visit = {
  id: 1,
  person_id: 1,
  name: "Demo Patient 1",
  source_id: 1,
  revision: "revision",
  wall_time: "2026-11-24 14:00:00",
  local_date: "2026-11-24",
  starts_at: "2026-11-24T20:00:00Z",
  provider: "Dr. Rivera",
  confirmation: "unconfirmed",
  issue: "Reply needs review",
  assigned_to: "Taylor",
  staff_outcome: null,
  outcome: "Unknown",
};

test("follow-up retains the note on server rejection and never retries automatically", async () => {
  const fetch = vi
    .fn()
    .mockResolvedValue({
      ok: false,
      json: async () => ({
        error: "Appointment changed. Reload and review before saving",
      }),
    });
  vi.stubGlobal("fetch", fetch);
  const saved = vi.fn();
  render(
    <FollowUpForm clinicId={1} visit={visit} staff="Taylor" saved={saved} />,
  );
  fireEvent.change(screen.getByLabelText("Follow-up note"), {
    target: { value: "Called the fictional patient." },
  });
  fireEvent.click(screen.getByText("Save follow-up"));
  expect(await screen.findByRole("alert")).toHaveTextContent(
    "Appointment changed",
  );
  expect(screen.getByLabelText("Follow-up note")).toHaveValue(
    "Called the fictional patient.",
  );
  expect(fetch).toHaveBeenCalledTimes(1);
  expect(saved).not.toHaveBeenCalled();
});

test("uncertain network save preserves input and explains recovery", async () => {
  const fetch = vi.fn().mockRejectedValue(new TypeError("Failed to fetch"));
  vi.stubGlobal("fetch", fetch);
  render(
    <FollowUpForm clinicId={1} visit={visit} staff="Taylor" saved={() => {}} />,
  );
  fireEvent.change(screen.getByLabelText("Follow-up note"), {
    target: { value: "Contact attempted" },
  });
  fireEvent.click(screen.getByText("Save follow-up"));
  expect(await screen.findByRole("alert")).toHaveTextContent(
    "Reload to check whether the action saved",
  );
  expect(screen.getByLabelText("Follow-up note")).toHaveValue(
    "Contact attempted",
  );
  expect(fetch).toHaveBeenCalledTimes(1);
});

function ClinicResult({ clinic }: { clinic: number }) {
  const { data } = useResource<{ name: string }>(`/clinics/${clinic}/visits`);
  return <p>{data?.name || "Loading clinic"}</p>;
}
test("clinic switch hides the old response while the next request is pending", async () => {
  let finish: ((response: object) => void) | undefined;
  vi.stubGlobal(
    "fetch",
    vi
      .fn()
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({ name: "Austin result" }),
      })
      .mockImplementationOnce(
        () =>
          new Promise((resolve) => {
            finish = resolve;
          }),
      ),
  );
  const { rerender } = render(<ClinicResult clinic={1} />);
  expect(await screen.findByText("Austin result")).toBeVisible();
  rerender(<ClinicResult clinic={2} />);
  expect(screen.queryByText("Austin result")).not.toBeInTheDocument();
  expect(screen.getByText("Loading clinic")).toBeVisible();
  await act(async () => {
    finish?.({ ok: true, json: async () => ({ name: "Phoenix result" }) });
  });
  await waitFor(() => expect(screen.getByText("Phoenix result")).toBeVisible());
});
