import { useState } from "react";
import type { Clinic, MessageList } from "./api";
import { errorText, request, useResource } from "./api";
import { Pagination, Panel, Status } from "./components";

function Conversation({
  clinicId,
  personId,
  channel,
}: {
  clinicId: number;
  personId: number;
  channel: string;
}) {
  const [page, setPage] = useState(1);
  const [revision, setRevision] = useState(0);
  const [body, setBody] = useState("");
  const [selected, setSelected] = useState("");
  const [key, setKey] = useState(() => crypto.randomUUID());
  const [state, setState] = useState({ pending: false, error: "", result: "" });
  const { data, error } = useResource<MessageList>(
    `/clinics/${clinicId}/people/${personId}/messages?channel=${channel}&page=${page}`,
    "Taylor",
    revision,
  );
  const message = data?.items.find(
    (message) => String(message.id) === selected,
  );
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!message) return;
    setState({ pending: true, error: "", result: "" });
    try {
      const response = await request<{ result: string }>(
        `/clinics/${clinicId}/replies`,
        "Taylor",
        {
          external_id: key,
          message_id: message.id,
          channel,
          sender: message.recipient,
          body,
        },
      );
      setState({
        pending: false,
        error: "",
        result:
          response.result === "confirmed"
            ? "Appointment confirmed."
            : response.result === "sms_stopped"
              ? "Future text messages stopped."
              : "Reply recorded for staff review.",
      });
      setBody("");
      setKey(crypto.randomUUID());
      setRevision((n) => n + 1);
    } catch (error) {
      setState({ pending: false, error: errorText(error), result: "" });
    }
  }
  return (
    <>
      <h2>Message history</h2>
      <Status error={error || state.error} loading={!data && !error} />
      {data && (
        <>
          <Pagination page={page} total={data.total} setPage={setPage} />
          {!data.items.length && (
            <p>
              No simulated {channel === "sms" ? "text messages" : "emails"} for
              this patient yet.
            </p>
          )}
          {data.items.map((message) => (
            <article className="message" key={message.id}>
              <small>
                Clinic {channel === "sms" ? "text" : "email"} ·{" "}
                {new Date(message.created_at).toLocaleString()} ·{" "}
                {message.status}
              </small>
              <p>{message.body}</p>
              {message.failure && <p>{message.failure}</p>}
              {data.replies
                .filter((reply) => reply.message_id === message.id)
                .map((reply) => (
                  <div className="reply" key={reply.id}>
                    <small>Your reply · {reply.result}</small>
                    <p>{reply.body}</p>
                  </div>
                ))}
            </article>
          ))}
          {data.items.length > 0 && (
            <Panel>
              <form onSubmit={submit}>
                <label>
                  Reply to
                  <select
                    required
                    value={selected}
                    onChange={(event) => setSelected(event.target.value)}
                  >
                    <option value="">Choose a message</option>
                    {data.items.map((message) => (
                      <option key={message.id} value={message.id}>
                        Message #{message.id} · {message.body.slice(0, 90)}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  Your reply
                  <textarea
                    required
                    maxLength={2000}
                    value={body}
                    onChange={(event) => setBody(event.target.value)}
                  />
                </label>
                <button
                  className="primary"
                  disabled={state.pending || !message}
                >
                  {state.pending ? "Saving…" : "Send simulated reply"}
                </button>
              </form>
            </Panel>
          )}
          <p role="status">{state.result}</p>
        </>
      )}
    </>
  );
}

function PatientPicker({ clinicId }: { clinicId: number }) {
  const [personId, setPersonId] = useState("");
  const [channel, setChannel] = useState("sms");
  const [page, setPage] = useState(1);
  const { data, error } = useResource<{
    items: { id: number; name: string }[];
    total: number;
  }>(`/clinics/${clinicId}/people?page=${page}&page_size=50`);
  return (
    <>
      <Status error={error} loading={!data && !error} />
      <label>
        Patient
        <select value={personId} onChange={(e) => setPersonId(e.target.value)}>
          <option value="">Choose a fictional patient</option>
          {data?.items.map((person) => (
            <option key={person.id} value={person.id}>
              {person.name}
            </option>
          ))}
        </select>
      </label>
      {data && data.total > 50 && (
        <Pagination
          page={page}
          total={data.total}
          size={50}
          setPage={(value) => {
            setPage(value);
            setPersonId("");
          }}
        />
      )}
      <div className="toolbar tabs">
        {[
          ["sms", "Text messages"],
          ["email", "Email"],
        ].map(([key, title]) => (
          <button
            className={channel === key ? "active" : ""}
            onClick={() => setChannel(key)}
            key={key}
          >
            {title}
          </button>
        ))}
      </div>
      {personId && (
        <Conversation
          key={`${personId}-${channel}`}
          clinicId={clinicId}
          personId={Number(personId)}
          channel={channel}
        />
      )}
    </>
  );
}

export default function Inbox({ clinics }: { clinics: Clinic[] }) {
  const [clinicId, setClinicId] = useState("");
  return (
    <div className="inbox">
      <h1>Patient inbox</h1>
      <p>Fictional patients · local simulation only</p>
      <label>
        Clinic
        <select value={clinicId} onChange={(e) => setClinicId(e.target.value)}>
          <option value="">Choose a clinic</option>
          {clinics.map((clinic) => (
            <option key={clinic.id} value={clinic.id}>
              {clinic.name}
            </option>
          ))}
        </select>
      </label>
      {clinicId && <PatientPicker key={clinicId} clinicId={Number(clinicId)} />}
    </div>
  );
}
