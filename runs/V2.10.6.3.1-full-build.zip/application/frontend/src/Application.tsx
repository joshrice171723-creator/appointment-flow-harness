import { useEffect, useState } from "react";
import type { Clinic } from "./api";
import { useResource } from "./api";
import Desk from "./Desk";
import Inbox from "./Inbox";
import Leadership from "./Leadership";
import PatientDetails from "./PatientDetails";
import { Panel, Status } from "./components";
import "./styles.css";

export default function Application() {
  const [hash, setHash] = useState(location.hash || "#/");
  const [staff, setStaff] = useState("Taylor");
  const [selectedClinic, setSelectedClinic] = useState("1");
  const { data: clinics, error } = useResource<Clinic[]>("/clinics");
  useEffect(() => {
    const changed = () => setHash(location.hash || "#/");
    window.addEventListener("hashchange", changed);
    return () => window.removeEventListener("hashchange", changed);
  }, []);
  const [, screen, clinicValue, personValue] = hash.split("/");
  const clinic = clinics?.find((clinic) => clinic.id === Number(clinicValue));
  return (
    <>
      <header>
        <a className="brand" href="#/">
          <span className="brand-mark">A↗</span>
          <span>
            APEX<small>APPOINTMENT FLOW</small>
          </span>
        </a>
        <nav>
          {clinic && (
            <>
              <a href={`#/desk/${clinic.id}`}>Patient flow</a>
              <a href={`#/appointments/${clinic.id}`}>Appointments</a>
            </>
          )}
          <a href="#/">Workspaces ↗</a>
        </nav>
      </header>
      <main>
        <Status error={error} loading={!clinics && !error} />
        {clinics && (
          <>
            {screen === "leadership" ? (
              <Leadership />
            ) : screen === "inbox" ? (
              <Inbox clinics={clinics} />
            ) : clinic && screen === "person" ? (
              <PatientDetails
                key={hash}
                clinicId={clinic.id}
                personId={Number(personValue)}
                staff={staff}
              />
            ) : clinic && (screen === "desk" || screen === "appointments") ? (
              <Desk
                key={hash}
                clinic={clinic}
                staff={staff}
                appointments={screen === "appointments"}
              />
            ) : (
              <>
                <h1>Workspaces</h1>
                <div className="workspace-grid">
                  <Panel>
                    <h2>Front desk</h2>
                    <p>Review appointments and follow up with patients.</p>
                    <label>
                      Clinic
                      <select
                        value={selectedClinic}
                        onChange={(e) => setSelectedClinic(e.target.value)}
                      >
                        {clinics.map((clinic) => (
                          <option key={clinic.id} value={clinic.id}>
                            {clinic.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Staff member · demo sign-in
                      <select
                        value={staff}
                        onChange={(e) => setStaff(e.target.value)}
                      >
                        <option>Taylor</option>
                        <option>Jordan</option>
                      </select>
                    </label>
                    <a
                      className="button primary"
                      href={`#/desk/${selectedClinic}`}
                    >
                      Open front desk <span>→</span>
                    </a>
                  </Panel>
                  <Panel className="leadership-card">
                    <h2>Apex leadership</h2>
                    <p>Aggregate outcomes only.</p>
                    <strong className="metric">{clinics.length}</strong>
                    <p>clinics</p>
                    <a className="button primary" href="#/leadership">
                      Open Apex leadership <span>→</span>
                    </a>
                  </Panel>
                  <Panel>
                    <h2>Patient</h2>
                    <p>
                      For internal demo use. Simulate replies from fictional
                      patients.
                    </p>
                    <a className="button primary" href="#/inbox">
                      Open patient workspace <span>→</span>
                    </a>
                  </Panel>
                </div>
              </>
            )}
          </>
        )}
      </main>
    </>
  );
}
