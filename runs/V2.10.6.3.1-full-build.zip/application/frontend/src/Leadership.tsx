import { useState } from "react";
import { today, useResource } from "./api";
import type { Outcome } from "./api";
import { Panel, Status } from "./components";

export default function Leadership() {
  const [month, setMonth] = useState(today().slice(0, 7));
  const { data, error } = useResource<{ month: string; clinics: Outcome[] }>(
    `/outcomes?month=${month}`,
  );
  return (
    <>
      <div className="page-heading">
        <h1>Appointment outcomes</h1>
        <label>
          Outcome month
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
          />
        </label>
      </div>
      <p>
        Aggregate source outcomes. These records do not establish no-shows or
        reminder impact.
      </p>
      <Status error={error} loading={!data && !error} />
      {data && (
        <>
          <Panel>
            <h2>{month} · recorded visits</h2>
            <div className="outcome-grid">
              {data.clinics.map((clinic) => (
                <section key={clinic.id}>
                  <div className="toolbar">
                    <h3>{clinic.name}</h3>
                    <span>{clinic.recorded} recorded visits</span>
                  </div>
                  <div
                    className="outcome-bar"
                    aria-label={`${clinic.completion_rate ?? 0}% completed`}
                  >
                    <span
                      style={{ width: `${clinic.completion_rate ?? 0}%` }}
                    />
                  </div>
                  <dl className="outcome-counts">
                    {[
                      ["Completed visits", clinic.completed],
                      ["Rescheduled", clinic.rescheduled],
                      ["Canceled", clinic.canceled],
                      ["Unknown result", clinic.unknown],
                    ].map(([title, count]) => (
                      <div key={title}>
                        <dt>{title}</dt>
                        <dd>{count}</dd>
                      </div>
                    ))}
                  </dl>
                </section>
              ))}
            </div>
          </Panel>
          <Panel>
            <h2>Clinic comparison</h2>
            <details>
              <summary>How rates are calculated</summary>
              <p>
                Completion rate = completed source visits / all recorded source
                visits in the selected clinic-local month. Confirmation does not
                mean completion.
              </p>
            </details>
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Clinic</th>
                    <th>Completion rate</th>
                    <th>Recorded visits</th>
                    <th>Rescheduled</th>
                    <th>Canceled</th>
                    <th>Unknown</th>
                  </tr>
                </thead>
                <tbody>
                  {data.clinics.map((clinic) => (
                    <tr key={clinic.id}>
                      <td>{clinic.name}</td>
                      <td>
                        {clinic.completion_rate === null
                          ? "No visits"
                          : `${clinic.completion_rate}%`}
                      </td>
                      <td>{clinic.recorded}</td>
                      <td>{clinic.rescheduled}</td>
                      <td>{clinic.canceled}</td>
                      <td>{clinic.unknown}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
          <Panel>
            <details>
              <summary>Reminder activity</summary>
              <p>
                Successful fake messages for visits in the selected appointment
                month.
              </p>
              {data.clinics.map((clinic) => (
                <p key={clinic.id}>
                  {clinic.name}: {clinic.messages_sent} messages
                </p>
              ))}
            </details>
          </Panel>
          <Panel>
            <details>
              <summary>Contact and follow-up holds</summary>
              <p>Counts group the current issue on each visit in this month.</p>
              {data.clinics.map((clinic) => (
                <section key={clinic.id}>
                  <h3>{clinic.name}</h3>
                  {clinic.holds.length ? (
                    <ul>
                      {clinic.holds.map((hold) => (
                        <li key={hold.reason}>
                          {hold.reason}: {hold.count}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p>No recorded holds.</p>
                  )}
                </section>
              ))}
            </details>
          </Panel>
        </>
      )}
    </>
  );
}
