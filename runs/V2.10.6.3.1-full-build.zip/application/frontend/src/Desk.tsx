import { useState } from "react";
import { errorText, request, today, useResource } from "./api";
import type { Clinic, VisitList } from "./api";
import { Pagination, Panel, Status, VisitTable } from "./components";

export default function Desk({
  clinic,
  staff,
  appointments = false,
}: {
  clinic: Clinic;
  staff: string;
  appointments?: boolean;
}) {
  const [date, setDate] = useState(today());
  const [state, setState] = useState(appointments ? "all" : "attention");
  const [search, setSearch] = useState("");
  const [type, setType] = useState("");
  const [page, setPage] = useState(1);
  const [revision, setRevision] = useState(0);
  const [action, setAction] = useState({
    pending: false,
    message: "",
    error: "",
  });
  const query = new URLSearchParams({
    state,
    page: String(page),
    search,
    ...(appointments ? { date } : { type }),
  });
  const { data, error } = useResource<VisitList>(
    `/clinics/${clinic.id}/${appointments ? "visits" : "work_items"}?${query}`,
    staff,
    revision,
  );
  async function run(endpoint: string) {
    setAction({ pending: true, message: "", error: "" });
    try {
      const result = await request<{ sent?: number }>(
        `/clinics/${clinic.id}/${endpoint}`,
        staff,
        {},
      );
      setAction({
        pending: false,
        message:
          endpoint === "refreshes"
            ? "PMS snapshot refreshed."
            : `${result.sent ?? 0} fake messages sent.`,
        error: "",
      });
      setRevision((n) => n + 1);
    } catch (error) {
      setAction({ pending: false, message: "", error: errorText(error) });
    }
  }
  function changeDate(value: string) {
    setDate(value);
    setPage(1);
  }
  function shiftDate(days: number) {
    const next = new Date(`${date}T12:00:00`);
    next.setDate(next.getDate() + days);
    changeDate(
      `${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, "0")}-${String(next.getDate()).padStart(2, "0")}`,
    );
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">{clinic.name}</p>
          <h1>{appointments ? "Appointments" : "Patient flow"}</h1>
        </div>
        <p>
          {staff} · {clinic.timezone}
        </p>
      </div>
      <div className="toolbar">
        <p>
          Last PMS sync:{" "}
          {data?.synced_at
            ? new Date(data.synced_at).toLocaleString()
            : "Not refreshed"}
        </p>
        <button disabled={action.pending} onClick={() => run("refreshes")}>
          Refresh PMS
        </button>
        <button
          className="primary"
          disabled={action.pending}
          onClick={() => run("reminder_runs")}
        >
          Run fake reminders
        </button>
      </div>
      <Status
        error={error || action.error || data?.sync_error || undefined}
        loading={!data && !error}
      />
      <p role="status">{action.message}</p>
      {!appointments && (
        <div className="summary-grid">
          {[
            ["attention", "Needs attention"],
            ["in_progress", "In progress"],
            ["resolved", "Resolved"],
          ].map(([key, title]) => (
            <Panel key={key}>
              <span>{title}</span>
              <strong className="metric">{data?.counts[key] ?? "—"}</strong>
            </Panel>
          ))}
        </div>
      )}
      {appointments && (
        <Panel>
          <div className="toolbar">
            <button onClick={() => shiftDate(-7)}>← Previous week</button>
            <button onClick={() => changeDate(today())}>Today</button>
            <button onClick={() => shiftDate(7)}>Next week →</button>
            <label>
              Jump to date
              <input
                type="date"
                value={date}
                onChange={(e) => changeDate(e.target.value)}
              />
            </label>
          </div>
          <div className="week">
            {Array.from({ length: 7 }, (_, index) => {
              const day = new Date(`${date}T12:00:00`);
              day.setDate(day.getDate() - day.getDay() + index);
              const value = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(day.getDate()).padStart(2, "0")}`;
              return (
                <button
                  className={value === date ? "active" : ""}
                  key={value}
                  onClick={() => changeDate(value)}
                >
                  {day.toLocaleDateString(undefined, {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                  })}
                </button>
              );
            })}
          </div>
        </Panel>
      )}
      <div className="toolbar tabs">
        {(appointments
          ? [
              ["all", "All appointments"],
              ["confirmed", "Confirmed"],
              ["unconfirmed", "Unconfirmed"],
              ["review", "Replies to review"],
            ]
          : [
              ["attention", "Needs attention"],
              ["in_progress", "In progress"],
              ["resolved", "Resolved"],
            ]
        ).map(([value, label]) => (
          <button
            key={value}
            className={state === value ? "active" : ""}
            onClick={() => {
              setState(value);
              setPage(1);
            }}
          >
            {label} {data?.counts[value] ?? ""}
          </button>
        ))}
        <a href={`#/${appointments ? "desk" : "appointments"}/${clinic.id}`}>
          {appointments ? "Open patient flow" : "All appointments"} →
        </a>
      </div>
      <div className="toolbar">
        <label>
          Full patient name
          <input
            type="search"
            value={search}
            placeholder="Demo Patient 1"
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </label>
        {!appointments && (
          <label>
            Follow-up type
            <select
              value={type}
              onChange={(e) => {
                setType(e.target.value);
                setPage(1);
              }}
            >
              <option value="">All types</option>
              {[
                "Reply needs review",
                "No confirmation; contact patient",
                "Delivery failed",
                "No safe permitted contact channel",
                "Verify birthdate",
                "Verify authorized adult contact",
                "Review preferred language",
                "Source and verified contact differ",
              ].map((value) => (
                <option key={value}>{value}</option>
              ))}
            </select>
          </label>
        )}
      </div>
      {data && (
        <>
          <Pagination page={page} total={data.total} setPage={setPage} />
          {appointments ? (
            <Panel>
              <VisitTable visits={data.items} clinicId={clinic.id} />
            </Panel>
          ) : (
            <div className="board">
              {!data.items.length && (
                <Panel>No follow-up items match these filters.</Panel>
              )}
              {data.items.map((visit) => (
                <a
                  className="work-card"
                  key={visit.id}
                  href={`#/person/${clinic.id}/${visit.person_id}`}
                >
                  <span className="pill">
                    {visit.issue || visit.confirmation}
                  </span>
                  <h2>{visit.name}</h2>
                  <p>
                    {visit.issue || visit.staff_outcome || "Follow-up resolved"}
                  </p>
                  <small>
                    {visit.wall_time.slice(0, 16)} · {clinic.name}
                  </small>
                  <hr />
                  <small>
                    {visit.assigned_to || "Unassigned"}{" "}
                    <span aria-hidden="true">↗</span>
                  </small>
                </a>
              ))}
            </div>
          )}
        </>
      )}
    </>
  );
}
