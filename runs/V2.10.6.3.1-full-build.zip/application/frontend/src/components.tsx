import type { ReactNode } from "react";
import type { Visit } from "./api";
import { wallTime } from "./api";

export function Status({
  error,
  loading,
}: {
  error?: string;
  loading?: boolean;
}) {
  return error ? (
    <p role="alert" className="alert">
      {error}
    </p>
  ) : loading ? (
    <p role="status">Loading…</p>
  ) : null;
}
export function Panel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <section className={`panel ${className}`}>{children}</section>;
}
export function Pagination({
  page,
  total,
  setPage,
  size = 10,
}: {
  page: number;
  total: number;
  setPage: (page: number) => void;
  size?: number;
}) {
  return (
    <div className="pagination">
      <span>
        {total ? (page - 1) * size + 1 : 0}–{Math.min(page * size, total)} of{" "}
        {total}
      </span>
      <button disabled={page <= 1} onClick={() => setPage(page - 1)}>
        Previous
      </button>
      <button disabled={page * size >= total} onClick={() => setPage(page + 1)}>
        Next
      </button>
    </div>
  );
}
export function VisitTable({
  visits,
  clinicId,
}: {
  visits: Visit[];
  clinicId: number;
}) {
  if (!visits.length) return <p>No appointments match these filters.</p>;
  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            <th>Patient</th>
            <th>Appointment · clinic time</th>
            <th>Confirmation or reply</th>
            <th>Source outcome</th>
            <th>Next step</th>
          </tr>
        </thead>
        <tbody>
          {visits.map((visit) => (
            <tr key={visit.id}>
              <td>
                <strong>{visit.name}</strong>
                <small>Appointment #{visit.source_id}</small>
                <a href={`#/person/${clinicId}/${visit.person_id}`}>
                  Patient details
                </a>
              </td>
              <td>
                {wallTime(visit.wall_time)}
                <small>{visit.provider}</small>
              </td>
              <td>
                <span className={`pill ${visit.confirmation}`}>
                  {visit.confirmation}
                </span>
                <small>{visit.issue}</small>
              </td>
              <td>
                {visit.outcome}
                <small>
                  {visit.staff_outcome &&
                    `Staff recorded: ${visit.staff_outcome}`}
                </small>
              </td>
              <td>
                <a href={`#/person/${clinicId}/${visit.person_id}`}>
                  Review follow-up →
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
