import { useEffect, useState } from "react";

export type Clinic = {
  id: number;
  name: string;
  timezone: string;
  synced_at: string | null;
  sync_error: string | null;
};
export type Visit = {
  id: number;
  person_id: number;
  name: string;
  source_id: number;
  revision: string;
  wall_time: string;
  local_date: string;
  starts_at: string | null;
  provider: string;
  confirmation: string;
  issue: string | null;
  assigned_to: string | null;
  staff_outcome: string | null;
  outcome: string;
};
export type VisitList = {
  items: Visit[];
  total: number;
  counts: Record<string, number>;
  synced_at: string | null;
  sync_error: string | null;
  timezone?: string;
};
export type Person = {
  id: number;
  source_id: number;
  name: string;
  phone: string | null;
  email: string | null;
  birthdate: string | null;
  language: string | null;
  raw: Record<string, string | null>;
  overrides: Record<string, string | null>;
  verified_against: Record<string, string | null>;
  conflict: boolean;
  adult_authorized: boolean;
  sms_allowed: boolean;
  email_allowed: boolean;
};
export type Activity = {
  id: number;
  outcome: string;
  note: string;
  staff: string;
  created_at: string;
  changes_recorded: Record<string, string>;
};
export type PersonDetail = {
  person: Person;
  visits: Visit[];
  activities: Activity[];
};
export type Message = {
  id: number;
  channel: string;
  recipient: string;
  body: string;
  status: string;
  failure: string | null;
  created_at: string;
};
export type Reply = {
  id: number;
  message_id: number;
  body: string;
  result: string;
  created_at: string;
};
export type MessageList = { items: Message[]; total: number; replies: Reply[] };
export type Outcome = {
  id: number;
  name: string;
  recorded: number;
  completed: number;
  canceled: number;
  rescheduled: number;
  unknown: number;
  completion_rate: number | null;
  messages_sent: number;
  holds: { reason: string; count: number }[];
};

export async function request<T>(
  path: string,
  staff = "Taylor",
  body?: object,
  method = "POST",
  signal?: AbortSignal,
): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`/api${path}`, {
      method: body ? method : "GET",
      headers: { "Content-Type": "application/json", "X-Demo-Staff": staff },
      body: body ? JSON.stringify(body) : undefined,
      signal,
    });
  } catch (error) {
    if (signal?.aborted) throw error;
    throw new Error(
      "Connection lost. Reload to check whether the action saved before retrying.",
    );
  }
  if (!response.ok) {
    const result: { error?: string } = await response.json();
    throw new Error(
      result.error ||
        `Request failed (${response.status}). Reload and review the record.`,
    );
  }
  return response.json() as Promise<T>;
}

// Keep responses bound to their request so a clinic change cannot display old data.
export function useResource<T>(path: string, staff = "Taylor", revision = 0) {
  const key = `${path}|${staff}|${revision}`;
  const [result, setResult] = useState<{
    key: string;
    data?: T;
    error?: string;
  }>({ key: "" });
  useEffect(() => {
    const controller = new AbortController();
    request<T>(path, staff, undefined, "GET", controller.signal)
      .then((data) => {
        if (!controller.signal.aborted) setResult({ key, data });
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setResult({ key, error: errorText(error) });
      });
    return () => controller.abort();
  }, [path, staff, key]);
  return result.key === key ? result : { key };
}

export function errorText(error: unknown) {
  return error instanceof Error
    ? error.message
    : "The action failed. Reload and review the record.";
}
export function wallTime(value: string) {
  return value.replace("T", " ").slice(0, 16);
}
export function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
