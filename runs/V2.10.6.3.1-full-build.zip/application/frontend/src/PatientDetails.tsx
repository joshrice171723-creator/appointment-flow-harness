import { useState } from "react";
import type { Person, PersonDetail, Visit } from "./api";
import { errorText, request, useResource } from "./api";
import { Panel, Status, VisitTable } from "./components";

export function FollowUpForm({
  clinicId,
  visit,
  staff,
  saved,
}: {
  clinicId: number;
  visit: Visit;
  staff: string;
  saved: () => void;
}) {
  const [note, setNote] = useState("");
  const [outcome, setOutcome] = useState("attempted");
  const [key] = useState(() => crypto.randomUUID());
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    try {
      await request(
        `/clinics/${clinicId}/visits/${visit.id}/follow_ups`,
        staff,
        { note, outcome, revision: visit.revision, external_id: key },
      );
      saved();
    } catch (error) {
      setError(errorText(error));
    } finally {
      setPending(false);
    }
  }
  return (
    <form onSubmit={submit}>
      <h3>Record follow-up · #{visit.source_id}</h3>
      <label>
        Outcome
        <select value={outcome} onChange={(e) => setOutcome(e.target.value)}>
          <option value="attempted">Contact attempted</option>
          <option value="confirmed">Confirmed by staff</option>
          <option value="canceled">Canceled by staff</option>
          <option value="rescheduled">Rescheduled in PMS by staff</option>
        </select>
      </label>
      <label>
        Follow-up note
        <textarea
          required
          maxLength={2000}
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </label>
      <Status error={error} />
      <button className="primary" disabled={pending}>
        {pending ? "Saving…" : "Save follow-up"}
      </button>
    </form>
  );
}

function ContactForm({
  clinicId,
  person,
  staff,
  saved,
}: {
  clinicId: number;
  person: Person;
  staff: string;
  saved: () => void;
}) {
  const [contact, setContact] = useState({
    birthdate: person.birthdate || "",
    wireless_phone: person.phone || "",
    email: person.email || "",
    preferred_language: person.language || "",
  });
  const [adult, setAdult] = useState(person.adult_authorized);
  const [sms, setSms] = useState(person.sms_allowed);
  const [email, setEmail] = useState(person.email_allowed);
  const [note, setNote] = useState("");
  const [key] = useState(() => crypto.randomUUID());
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    try {
      await request(
        `/clinics/${clinicId}/people/${person.id}/contact_verifications`,
        staff,
        {
          external_id: key,
          contact: { ...contact, birthdate: contact.birthdate || null },
          adult_authorized: adult,
          sms_allowed: sms,
          email_allowed: email,
          note,
        },
      );
      saved();
    } catch (error) {
      setError(errorText(error));
    } finally {
      setPending(false);
    }
  }
  return (
    <form onSubmit={submit}>
      <h3>Verify local contact</h3>
      {(
        [
          ["birthdate", "Birthdate", "date"],
          ["wireless_phone", "Mobile phone", "tel"],
          ["email", "Email", "email"],
          ["preferred_language", "Language (en or es)", "text"],
        ] as const
      ).map(([key, label, type]) => (
        <label key={key}>
          {label}
          <input
            type={type}
            value={contact[key]}
            onChange={(e) => setContact({ ...contact, [key]: e.target.value })}
          />
        </label>
      ))}
      <label className="check">
        <input
          type="checkbox"
          checked={adult}
          onChange={(e) => setAdult(e.target.checked)}
        />
        Authorized adult contact verified
      </label>
      <label className="check">
        <input
          type="checkbox"
          checked={sms}
          onChange={(e) => setSms(e.target.checked)}
        />
        SMS permission verified
      </label>
      <label className="check">
        <input
          type="checkbox"
          checked={email}
          onChange={(e) => setEmail(e.target.checked)}
        />
        Email permission verified
      </label>
      <label>
        Verification note
        <textarea
          required
          value={note}
          maxLength={2000}
          onChange={(e) => setNote(e.target.value)}
        />
      </label>
      <p>
        Local corrections retain the PMS values. An SMS STOP remains in effect.
      </p>
      <Status error={error} />
      <button className="primary" disabled={pending}>
        Save verification
      </button>
    </form>
  );
}

export default function PatientDetails({
  clinicId,
  personId,
  staff,
}: {
  clinicId: number;
  personId: number;
  staff: string;
}) {
  const [revision, setRevision] = useState(0);
  const [tab, setTab] = useState("follow-up");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const { data, error: readError } = useResource<PersonDetail>(
    `/clinics/${clinicId}/people/${personId}`,
    staff,
    revision,
  );
  function saved() {
    setRevision((n) => n + 1);
  }
  async function assign(visit: Visit) {
    setPending(true);
    try {
      await request(
        `/clinics/${clinicId}/work_items/${visit.id}`,
        staff,
        {},
        "PATCH",
      );
      saved();
    } catch (error) {
      setError(errorText(error));
    } finally {
      setPending(false);
    }
  }
  if (!data) return <Status error={readError} loading={!readError} />;
  const { person, visits, activities } = data;
  return (
    <>
      <a href={`#/desk/${clinicId}`}>← Patient flow</a>
      <div className="page-heading">
        <div>
          <h1>{person.name}</h1>
          <p>Patient follow-up</p>
        </div>
        <a href={`#/appointments/${clinicId}`}>Appointments →</a>
      </div>
      <Status error={error} />
      <div className="patient-layout">
        <Panel>
          <h2>Patient details</h2>
          {person.conflict && (
            <p className="alert">
              PMS and verified values differ. Verify before outreach.
            </p>
          )}
          <dl>
            {[
              ["Birthdate", "birthdate", person.birthdate],
              ["Mobile phone", "wireless_phone", person.phone],
              ["Email", "email", person.email],
              ["Preferred language", "preferred_language", person.language],
            ].map(([title, field, value]) => (
              <div key={field}>
                <dt>{title}</dt>
                <dd>{value || "No value on file"}</dd>
                <small>
                  {field && field in person.verified_against
                    ? "Locally verified"
                    : "Not verified"}
                </small>
              </div>
            ))}
          </dl>
          <details>
            <summary>Verify or correct contact</summary>
            <ContactForm
              key={revision}
              clinicId={clinicId}
              person={person}
              staff={staff}
              saved={saved}
            />
          </details>
          <details>
            <summary>Original PMS values</summary>
            <dl>
              {Object.entries(person.raw).map(([key, value]) => (
                <div key={key}>
                  <dt>{key}</dt>
                  <dd>{value || "No value"}</dd>
                </div>
              ))}
            </dl>
          </details>
        </Panel>
        <div>
          <div className="tabs toolbar">
            {["follow-up", "appointments", "activity"].map((value) => (
              <button
                className={tab === value ? "active" : ""}
                key={value}
                onClick={() => setTab(value)}
              >
                {value === "follow-up"
                  ? "Follow-up"
                  : value === "activity"
                    ? "Activity log"
                    : "Appointments"}
              </button>
            ))}
          </div>
          <Panel>
            {tab === "appointments" ? (
              <VisitTable visits={visits} clinicId={clinicId} />
            ) : tab === "activity" ? (
              <>
                <h2>Activity log</h2>
                {!activities.length && <p>No recorded activity.</p>}
                {activities.map((activity) => (
                  <article key={activity.id}>
                    <h3>{activity.outcome.replaceAll("_", " ")}</h3>
                    <p>{activity.note}</p>
                    <small>
                      {activity.staff} ·{" "}
                      {new Date(activity.created_at).toLocaleString()}
                    </small>
                    <hr />
                  </article>
                ))}
              </>
            ) : (
              <>
                <h2>Follow-up items</h2>
                {!visits.some((visit) => visit.issue) && (
                  <p>No open follow-up items.</p>
                )}
                {visits.map((visit) => (
                  <article key={visit.id}>
                    <h3>Appointment #{visit.source_id}</h3>
                    <p>
                      {visit.wall_time.slice(0, 16)} · {visit.confirmation} ·{" "}
                      {visit.outcome}
                    </p>
                    {visit.issue && <p className="pill">{visit.issue}</p>}
                    <p>Assigned to: {visit.assigned_to || "Unassigned"}</p>
                    {!visit.staff_outcome &&
                      visit.starts_at &&
                      new Date(visit.starts_at) > new Date() && (
                        <>
                          {visit.assigned_to !== staff ? (
                            <button
                              disabled={pending}
                              onClick={() => assign(visit)}
                            >
                              Assign to me
                            </button>
                          ) : (
                            <FollowUpForm
                              key={`${visit.id}-${revision}`}
                              clinicId={clinicId}
                              visit={visit}
                              staff={staff}
                              saved={saved}
                            />
                          )}
                        </>
                      )}
                    <hr />
                  </article>
                ))}
              </>
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
