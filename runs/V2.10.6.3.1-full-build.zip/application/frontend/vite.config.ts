import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: "127.0.0.1",
    port: Number(process.env.HARNESS_UI_PORT),
    strictPort: true,
    proxy: { "/api": `http://127.0.0.1:${process.env.HARNESS_API_PORT}` },
  },
});
