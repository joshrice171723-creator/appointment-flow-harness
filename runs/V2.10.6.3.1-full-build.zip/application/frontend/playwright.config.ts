import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  workers: 1,
  timeout: 120000,
  expect: { timeout: 15000 },
  use: {
    baseURL: `http://127.0.0.1:${process.env.HARNESS_UI_PORT}`,
    browserName: "chromium",
    channel: "msedge",
    headless: true,
  },
  webServer: [
    {
      command: `ruby bin/rails server -b 127.0.0.1 -p ${process.env.HARNESS_API_PORT}`,
      cwd: "../backend",
      url: `http://127.0.0.1:${process.env.HARNESS_API_PORT}/up`,
      reuseExistingServer: true,
      timeout: 180000,
    },
    {
      command: "npm run dev",
      url: `http://127.0.0.1:${process.env.HARNESS_UI_PORT}`,
      reuseExistingServer: true,
      timeout: 180000,
    },
  ],
});
