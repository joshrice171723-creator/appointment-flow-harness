# Candidate decisions

This file is reserved for Joshua's own explanation, as required by the assessment. The AI has not written or attributed a personal rationale to him.

Technical facts and prompts for that explanation are in [notes/CANDIDATE_DECISION_NOTES.md](notes/CANDIDATE_DECISION_NOTES.md). Personal authorship and the live defense remain outside the AI technical grade.
