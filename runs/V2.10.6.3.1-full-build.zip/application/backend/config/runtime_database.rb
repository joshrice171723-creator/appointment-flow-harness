require "uri"

module RuntimeDatabase
  def self.configuration(environment)
    host, port, user, database = %w[PGHOST PGPORT PGUSER PGDATABASE].map { |key| ENV.fetch(key) }
    url = URI(ENV.fetch("DATABASE_URL"))
    unless url.host == host && url.port == Integer(port) && URI.decode_www_form_component(url.user.to_s) == user && url.path.delete_prefix("/") == database
      raise "DATABASE_URL and PG environment disagree"
    end
    raise "A private non-default PostgreSQL port is required" if Integer(port) == 5432
    selected = environment == "test" ? "#{database.delete_suffix('_test')}_rails_test" : database
    raise "Test database must end in _test" if environment == "test" && !selected.end_with?("_test")

    url.path = "/#{selected}"
    { "url" => url.to_s, "adapter" => "postgresql", "host" => host, "port" => Integer(port), "username" => user,
      "password" => url.password && URI.decode_www_form_component(url.password), "database" => selected,
      "pool" => 8, "variables" => { "statement_timeout" => "15000" } }
  end
end
