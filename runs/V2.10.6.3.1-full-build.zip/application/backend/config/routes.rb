Rails.application.routes.draw do
  scope :api do
    resources :clinics, only: :index do
      resources :refreshes, only: :create
      resources :reminder_runs, only: :create
      resources :visits, only: :index do
        resources :follow_ups, only: :create
      end
      resources :work_items, only: [ :index, :update ]
      resources :people, only: [ :index, :show ] do
        resources :contact_verifications, only: :create
        resources :messages, only: :index
      end
      resources :replies, only: :create
    end
    resources :outcomes, only: :index
  end
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
end
