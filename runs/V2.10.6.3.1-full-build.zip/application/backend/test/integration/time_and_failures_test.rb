require "test_helper"

class TimeAndFailuresTest < ActionDispatch::IntegrationTest
  NOW = Time.utc(2026, 11, 17, 17)

  test "DST gap and repeated hour require review while Phoenix keeps its fixed offset" do
    clinic = SourceFixture.create
    SourceFixture::Appointment.find(1).update!(start_at: Time.utc(2026, 3, 8, 2, 30))
    clinic.with_lock { Pms::Refresh.new(clinic).call }
    assert_nil Visit.sole.starts_at
    assert_equal "Appointment time needs review", Visit.sole.issue
    SourceFixture::Appointment.find(1).update!(start_at: Time.utc(2026, 11, 1, 1, 30))
    clinic.with_lock { Pms::Refresh.new(clinic).call }
    assert_nil Visit.sole.reload.starts_at
    phoenix = SourceFixture.create(clinic_id: 2, id: 2, phone: "6025550102")
    SourceFixture::Appointment.find(2).update!(start_at: Time.utc(2026, 3, 8, 2, 30))
    phoenix.with_lock { Pms::Refresh.new(phoenix).call }
    assert_equal Time.utc(2026, 3, 8, 9, 30), Visit.find_by!(source_id: 2).starts_at
  end

  test "new source contact blocks the next send and correction history remains local" do
    clinic = SourceFixture.create
    Reminders::Run.new(clinic, now: NOW - 2.hours).call
    SourceFixture.create(id: 2, days: 60, phone: "512-555-0102", email: nil)
    SourceFixture::Patient.find(2).update!(wireless_phone: "1 512 555 0101")
    SourceFixture::Patient.find(1).update!(email: nil)
    assert_equal 0, Reminders::Run.new(clinic, now: NOW).call[:sent]
    assert_empty Message.all
    SourceFixture::Patient.find(2).update!(wireless_phone: "512-555-0102")
    assert_equal 1, Reminders::Run.new(clinic, now: NOW).call[:sent]
  end

  test "provider failure survives with one backup email and no retry duplicates" do
    clinic = SourceFixture.create(phone: "5125550199")
    Reminders::Run.new(clinic, now: NOW).call
    assert_equal "failed", Message.sole.status
    assert_equal "Delivery failed", Visit.sole.issue
    Reminders::Run.new(clinic, now: NOW + 1.day).call
    assert_equal 1, Message.where(status: "failed", channel: "sms").count
    assert_equal 1, Message.where(status: "sent", channel: "email", step: "backup").count
    Reminders::Run.new(clinic, now: NOW + 1.day).call
    assert_equal 2, Message.count
  end

  test "source failure returns unavailable without writes from the partial snapshot" do
    clinic = SourceFixture.create
    Reminders::Run.new(clinic, now: NOW - 2.hours).call
    SourceFixture::Appointment.delete_all
    SourceFixture::Clinic.find(1).destroy!
    travel_to NOW do
      post "/api/clinics/1/reminder_runs", headers: { "X-Demo-Staff" => "Taylor" }, params: {}, as: :json
    end
    assert_response :service_unavailable
    assert_equal 1, Visit.count
    assert_empty Message.all
    assert_includes clinic.reload.sync_error, "unavailable"
  end

  test "unexpected transport error rolls back earlier fake attempts and keeps its cause" do
    clinic = SourceFixture.create
    SourceFixture.create(id: 2, phone: "5125550102", email: "demo2@example.test")
    calls = 0
    transport = Object.new
    transport.define_singleton_method(:deliver) do |**_arguments|
      calls += 1
      raise IOError, "Local simulated transport programming failure" if calls == 2
      "sent"
    end
    error = assert_raises(IOError) { Reminders::Run.new(clinic, now: NOW, transport: transport).call }
    assert_includes error.message, "programming failure"
    assert_empty Message.all
    assert_empty Visit.all
    assert_nil clinic.reload.synced_at
    assert_equal 2, Reminders::Run.new(clinic, now: NOW).call[:sent]
    assert_equal 2, Message.count
  end

  test "broken source and replacement are separate lifecycles" do
    clinic = SourceFixture.create
    Reminders::Run.new(clinic, now: NOW).call
    old_message = Message.sole
    SourceFixture::Appointment.find(1).update!(status: "broken")
    SourceFixture::Appointment.create!(id: 2, patient_id: 1, clinic_id: 1, start_at: Time.utc(2026, 11, 25, 14), status: "scheduled")
    attributes = { external_id: "old", message_id: old_message.id, sender: old_message.recipient, channel: "sms", body: "YES" }
    result = Replies::Record.new(clinic, attributes, now: NOW).call
    assert_equal "review", result.result
    assert_equal "Canceled", Visit.find_by!(source_id: 1).outcome
    assert_equal "unconfirmed", Visit.find_by!(source_id: 2).confirmation
  end
end
