require "test_helper"

class VisitListsTest < ActionDispatch::IntegrationTest
  test "clinic date state ordering and pagination preserve full-scope counts" do
    clinic = SourceFixture.create
    SourceFixture.create(id: 2, phone: "5125550102", email: "demo2@example.test")
    SourceFixture.create(clinic_id: 2, id: 3, phone: "6025550103", email: "demo3@example.test")
    clinic.with_lock { Pms::Refresh.new(clinic).call }
    visits = clinic.visits.order(:id).to_a
    visits.first.update!(confirmation: "confirmed")
    headers = { "X-Demo-Staff" => "Taylor" }
    get "/api/clinics/1/visits", headers: headers, params: { date: "2026-11-24", state: "unconfirmed", page_size: 1 }
    assert_response :success
    assert_equal [ visits.last.id ], response.parsed_body.fetch("items").map { |row| row.fetch("id") }
    assert_equal({ "all" => 2, "confirmed" => 1, "unconfirmed" => 1, "review" => 0 }, response.parsed_body.fetch("counts"))
    get "/api/clinics/1/visits", headers: headers, params: { date: "2026-11-24", page_size: 1, page: 2 }
    assert_equal [ visits.last.id ], response.parsed_body.fetch("items").map { |row| row.fetch("id") }
    get "/api/clinics/1/visits", headers: headers, params: { date: "2026-11-25" }
    assert_empty response.parsed_body.fetch("items")
    get "/api/clinics/1/visits", headers: headers, params: { search: "Demo Patient 2" }
    assert_equal [ visits.last.id ], response.parsed_body.fetch("items").map { |row| row.fetch("id") }
  end
end
