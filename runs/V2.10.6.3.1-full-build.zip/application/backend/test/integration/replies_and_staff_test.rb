require "test_helper"

class RepliesAndStaffTest < ActionDispatch::IntegrationTest
  NOW = Time.utc(2026, 11, 17, 17)
  HEADERS = { "X-Demo-Staff" => "Taylor" }.freeze

  def ready(**options)
    clinic = SourceFixture.create(**options)
    Reminders::Run.new(clinic, now: NOW).call
    [ clinic, Visit.sole, Message.sole ]
  end

  def reply(message, body, key: SecureRandom.uuid, sender: message.recipient)
    travel_to NOW do
      post "/api/clinics/1/replies", params: { external_id: key, message_id: message.id, sender: sender, channel: message.channel, body: body }, as: :json
    end
  end

  test "SMS YES confirms only its current version; replay is idempotent; NO requires review" do
    _, visit, message = ready
    reply(message, "YES", key: "one")
    assert_response :created
    assert_equal "confirmed", response.parsed_body["result"]
    assert_equal "confirmed", visit.reload.confirmation
    reply(message, "YES", key: "one")
    assert_equal 1, Reply.count
    reply(message, "NO")
    assert_equal "review", response.parsed_body["result"]
    assert_equal "confirmed", visit.reload.confirmation
    assert_equal "Reply needs review", visit.issue
    get "/api/clinics/1/work_items", headers: HEADERS
    assert_equal [ visit.id ], response.parsed_body.fetch("items").map { |row| row.fetch("id") }
  end

  test "email YES uses the same confirmation rule" do
    _, visit, message = ready(phone: nil)
    reply(message, "yes")
    assert_response :created
    assert_equal "confirmed", visit.reload.confirmation
  end

  test "moving source appointment rejects old YES and invalidates prior confirmation" do
    _, visit, message = ready
    reply(message, "YES")
    original_revision = visit.revision
    SourceFixture::Appointment.find(1).update!(start_at: Time.utc(2026, 11, 26, 14))
    reply(message, "YES")
    assert_equal "review", response.parsed_body["result"]
    assert_equal "unconfirmed", visit.reload.confirmation
    assert_not_equal original_revision, visit.revision
  end

  test "source contact change outside selected appointment is refreshed before a reply decision" do
    clinic, visit, message = ready
    SourceFixture.create(id: 2, days: 100, phone: "(512) 555-0102", email: nil)
    # The other appointment cannot appear in today's reminder selection.
    SourceFixture::Patient.find(2).update!(wireless_phone: "512.555.0101")
    reply(message, "YES")
    assert_equal "review", response.parsed_body["result"]
    assert_equal "unconfirmed", visit.reload.confirmation
    assert_equal 2, clinic.people.where(phone: message.recipient).count
  end

  test "late and mismatched replies never confirm" do
    _, visit, message = ready
    reply(message, "YES", sender: "+15125550109")
    assert_equal "review", response.parsed_body["result"]
    travel_to visit.starts_at do
      post "/api/clinics/1/replies", params: { external_id: "late", message_id: message.id, sender: message.recipient, channel: "sms", body: "YES" }, as: :json
    end
    assert_equal "review", response.parsed_body["result"]
    assert_equal "unconfirmed", visit.reload.confirmation
  end

  test "STOP survives source refresh and suppresses SMS; uncertain STOP is review" do
    clinic, _, message = ready
    reply(message, "STOP please")
    assert_equal "review", response.parsed_body["result"]
    assert_empty Suppression.all
    reply(message, "sToP")
    assert_equal "sms_stopped", response.parsed_body["result"]
    Reminders::Run.new(clinic, now: NOW + 4.days).call
    assert_equal 1, Suppression.count
    assert_equal 1, Message.where(channel: "sms").count
  end

  test "clinic mismatch cannot read patient or submit reply or assign work" do
    _, visit, message = ready
    other = SourceFixture.create(clinic_id: 2, id: 2, phone: "(602) 555-0102", email: "demo2@example.test")
    other.with_lock { Pms::Refresh.new(other).call }
    get "/api/clinics/2/people/#{visit.person_id}", headers: HEADERS
    assert_response :not_found
    post "/api/clinics/2/replies", params: { external_id: "wrong-clinic", message_id: message.id, sender: message.recipient, channel: "sms", body: "YES" }, as: :json
    assert_response :not_found
    patch "/api/clinics/2/work_items/#{visit.id}", headers: HEADERS, params: {}, as: :json
    assert_response :not_found
    assert_nil visit.reload.assigned_to
    assert_empty Reply.all
  end

  test "follow-up requires note and current version; confirmation plus activity roll back on failure" do
    _, visit, = ready
    patch "/api/clinics/1/work_items/#{visit.id}", headers: HEADERS, params: {}, as: :json
    travel_to NOW do
      post "/api/clinics/1/visits/#{visit.id}/follow_ups", headers: HEADERS, params: { revision: visit.revision, external_id: "empty", outcome: "confirmed", note: "" }, as: :json
      assert_response :conflict
      # Validation fails after the workflow writes confirmation, exercising its rollback.
      post "/api/clinics/1/visits/#{visit.id}/follow_ups", headers: HEADERS, params: { revision: visit.revision, external_id: "long", outcome: "confirmed", note: "a" * 2001 }, as: :json
      assert_response :unprocessable_entity
      assert_equal "unconfirmed", visit.reload.confirmation
      assert_empty Activity.all
      post "/api/clinics/1/visits/#{visit.id}/follow_ups", headers: HEADERS, params: { revision: visit.revision, external_id: "saved", outcome: "confirmed", note: "Confirmed by phone" }, as: :json
      assert_response :created
      assert_equal "confirmed", visit.reload.confirmation
      assert_equal "Confirmed by phone", Activity.sole.note
      post "/api/clinics/1/visits/#{visit.id}/follow_ups", headers: HEADERS, params: { revision: visit.revision, external_id: "saved", outcome: "confirmed", note: "Confirmed by phone" }, as: :json
      assert_response :created
      assert_equal 1, Activity.count
    end
  end

  test "local correction unblocks contact without source writes; source conflict later holds" do
    clinic = SourceFixture.create(birthdate: nil)
    Reminders::Run.new(clinic, now: NOW).call
    person = Person.sole
    assert_empty Message.all
    travel_to NOW do
      post "/api/clinics/1/people/#{person.id}/contact_verifications", headers: HEADERS, params: { external_id: "verify", note: "Checked fictional date", contact: { birthdate: "1990-01-01" }, adult_authorized: false, sms_allowed: true, email_allowed: true }, as: :json
    end
    assert_response :created
    assert_nil SourceFixture::Patient.find(1).birthdate
    assert_equal 1, Reminders::Run.new(clinic, now: NOW).call[:sent]
    SourceFixture::Patient.find(1).update!(birthdate: "1985-01-01")
    Reminders::Run.new(clinic, now: NOW + 4.days).call
    assert person.reload.conflict
    assert_equal 1, Message.count
  end

  test "leadership aggregates source outcomes and returns no identifying fields or values" do
    _, visit, message = ready
    visit.update!(confirmation: "confirmed")
    get "/api/outcomes", params: { month: "2026-11" }
    assert_response :success
    record = response.parsed_body.fetch("clinics").first
    assert_equal 1, record.fetch("recorded")
    assert_equal 0, record.fetch("completed")
    assert_equal 1, record.fetch("unknown")
    [ visit.person.name, message.recipient, message.body, "birthdate", "person_id", "sender" ].each { |private_value| assert_not_includes response.body, private_value }
  end
end
