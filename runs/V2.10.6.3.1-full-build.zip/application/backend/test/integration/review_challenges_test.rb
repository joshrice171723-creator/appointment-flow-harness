require "test_helper"

class ReviewChallengesTest < ActionDispatch::IntegrationTest
  NOW = Time.utc(2026, 11, 17, 17)
  HEADERS = { "X-Demo-Staff" => "Taylor" }.freeze

  test "contact verification rolls back contact and audit when audit validation fails" do
    clinic = SourceFixture.create(birthdate: nil)
    Reminders::Run.new(clinic, now: NOW).call
    person = Person.sole
    travel_to NOW do
      post "/api/clinics/1/people/#{person.id}/contact_verifications", headers: HEADERS, params: { external_id: "rollback", note: "a" * 2001,
        contact: { birthdate: "1990-01-01" }, adult_authorized: false, sms_allowed: true, email_allowed: true }, as: :json
    end
    assert_response :unprocessable_entity
    assert_nil person.reload.birthdate
    assert_equal({}, person.overrides)
    assert_empty Activity.all
    assert_nil SourceFixture::Patient.find(1).birthdate
  end

  test "changed source guarantor invalidates previously verified minor authorization" do
    clinic = SourceFixture.create(birthdate: "2014-01-01")
    SourceFixture.create(id: 2, days: 100, phone: "5125550102", email: "demo2@example.test")
    Reminders::Run.new(clinic, now: NOW).call
    person = Person.find_by!(source_id: 1)
    assert_empty Message.all
    travel_to NOW do
      post "/api/clinics/1/people/#{person.id}/contact_verifications", headers: HEADERS, params: { external_id: "authorized", note: "Verified the fictional authorized adult and their unique contact",
        contact: { wireless_phone: "5125550111", email: "adult@example.test" }, adult_authorized: true, sms_allowed: true, email_allowed: true }, as: :json
    end
    assert_response :created
    assert_equal 1, Reminders::Run.new(clinic, now: NOW).call[:sent]
    SourceFixture::Patient.find(1).update!(guarantor_id: 2)
    assert_equal 0, Reminders::Run.new(clinic, now: NOW + 4.days).call[:sent]
    assert person.reload.conflict
    assert_equal 1, Message.count
  end

  test "a batch that crosses the local window does not send its second message" do
    clinic = SourceFixture.create
    SourceFixture.create(id: 2, phone: "5125550102", email: "demo2@example.test")
    transport = Object.new
    calls = 0
    advance_clock = -> { travel_to Time.utc(2026, 11, 18, 0) }
    transport.define_singleton_method(:deliver) do |**_attributes|
      calls += 1
      advance_clock.call
      "sent"
    end
    # The transport advances the actual server clock used by the next decision.
    travel_to Time.utc(2026, 11, 17, 23, 59) do
      Reminders::Run.new(clinic, transport: transport).call
    end
    assert_equal 1, calls
    assert_equal 1, Message.count
  end
end
