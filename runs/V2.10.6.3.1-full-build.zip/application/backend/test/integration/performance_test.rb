require "test_helper"
require_relative "../../../quality/rails_workload_probe"

class PerformanceTest < ActionDispatch::IntegrationTest
  NOW = Time.utc(2026, 11, 17, 17)
  HEADERS = { "X-Demo-Staff" => "Taylor" }.freeze

  def add_source_rows(count, start_id:, days:)
    people = count.times.map do |index|
      id = start_id + index
      { id: id, first_name: "Growth", last_name: "Patient #{id}", birthdate: Date.new(1990, 1, 1), wireless_phone: "512555#{format('%04d', id % 10000)}", email: "growth#{id}@example.test", preferred_language: "en" }
    end
    appointments = people.map { |person| { id: person[:id], patient_id: person[:id], clinic_id: 1, start_at: (NOW.to_date + days).to_time(:utc) + 14.hours, status: "scheduled" } }
    SourceFixture::Patient.insert_all!(people)
    SourceFixture::Appointment.insert_all!(appointments)
  end

  def capture(label)
    source = { rows: 0, bytes: 0 }
    subscriber = ->(event) { source[:rows] += event.payload[:rows]; source[:bytes] += event.payload[:bytes] }
    _, metrics = ActiveSupport::Notifications.subscribed(subscriber, "snapshot.pms") do
      RailsWorkloadProbe.measure { yield }
    end
    assert_response :success
    result = metrics.merge(source_rows: source[:rows], source_bytes: source[:bytes], response_bytes: response.body.bytesize)
    @measurements[label] = result
    puts "PERFORMANCE #{label}: #{result.to_json}"
  end

  test "complete refresh batch and indexed list preserve effects under first repeat and growth" do
    @measurements = {}
    SourceFixture.create
    travel_to NOW do
      capture("first_population") { post "/api/clinics/1/reminder_runs", headers: HEADERS, params: {}, as: :json }
      original_ids = Message.pluck(:id)
      visit_id = Visit.sole.id
      assert_equal 1, original_ids.size
      capture("unchanged_retry") { post "/api/clinics/1/reminder_runs", headers: HEADERS, params: {}, as: :json }
      assert_equal original_ids, Message.pluck(:id)
      capture("small_read") { get "/api/clinics/1/visits", headers: HEADERS, params: { date: "2026-11-24", page_size: 10 } }
      small_response = response.parsed_body
      assert_equal [ visit_id ], small_response.fetch("items").map { |row| row.fetch("id") }
      add_source_rows(100, start_id: 2000, days: 100)
      capture("unrelated_first_sync") { post "/api/clinics/1/reminder_runs", headers: HEADERS, params: {}, as: :json }
      assert_equal original_ids, Message.pluck(:id)
      assert_equal 101, Person.count
      capture("unrelated_retry") { post "/api/clinics/1/reminder_runs", headers: HEADERS, params: {}, as: :json }
      assert_equal original_ids, Message.pluck(:id)
      capture("grown_read") { get "/api/clinics/1/visits", headers: HEADERS, params: { date: "2026-11-24", page_size: 10 } }
      assert_equal small_response.fetch("items"), response.parsed_body.fetch("items")
      assert_equal small_response.fetch("counts"), response.parsed_body.fetch("counts")
      assert_equal @measurements["small_read"][:response_bytes], @measurements["grown_read"][:response_bytes]
      add_source_rows(20, start_id: 3000, days: 7)
      capture("eligible_growth") { post "/api/clinics/1/reminder_runs", headers: HEADERS, params: {}, as: :json }
      assert_equal 21, Message.count
      assert_equal 20, Message.where(visit_id: Visit.where(source_id: 3000...3020).select(:id)).count
      capture("eligible_retry") { post "/api/clinics/1/reminder_runs", headers: HEADERS, params: {}, as: :json }
      assert_equal 21, Message.count
      capture("page_10") { get "/api/clinics/1/visits", headers: HEADERS, params: { date: "2026-11-24", page_size: 10 } }
      assert_equal 10, response.parsed_body.fetch("items").size
      capture("page_50") { get "/api/clinics/1/visits", headers: HEADERS, params: { date: "2026-11-24", page_size: 50 } }
      assert_equal 21, response.parsed_body.fetch("items").size
      puts "QUERY PLAN: #{Visit.where(clinic_id: 1, local_date: Date.new(2026, 11, 24)).order(:local_date, :wall_time, :id).limit(10).explain.inspect}"
      path = Rails.root.join("../review/performance.json")
      path.write(JSON.pretty_generate(@measurements) + "\n")
    end
  end
end
