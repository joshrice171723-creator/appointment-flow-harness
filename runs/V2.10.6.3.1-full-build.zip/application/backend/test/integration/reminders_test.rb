require "test_helper"

class RemindersTest < ActiveSupport::TestCase
  NOW = Time.utc(2026, 11, 17, 17)

  test "first refresh sends one logical SMS and repeat does not duplicate" do
    clinic = SourceFixture.create
    assert_equal 1, Reminders::Run.new(clinic, now: NOW).call[:sent]
    message = Message.sole
    assert_equal "+15125550101", message.recipient
    assert_includes message.body, "America/Chicago"
    assert_not_includes message.body, "procedure"
    assert_equal 0, Reminders::Run.new(clinic, now: NOW).call[:sent]
    assert_equal [ message.id ], Message.pluck(:id)
    assert_equal Time.utc(2026, 11, 24, 20), Visit.sole.starts_at
  end

  test "shared contacts outside reminder horizon prevent SMS" do
    clinic = SourceFixture.create(email: nil)
    SourceFixture.create(id: 2, days: 100, email: nil)
    assert_equal 0, Reminders::Run.new(clinic, now: NOW).call[:sent]
    assert_equal "No safe permitted contact channel", Visit.find_by!(source_id: 1).issue
    assert_empty Message.all
  end

  test "email fallback and simulated failure are recorded" do
    clinic = SourceFixture.create(phone: nil)
    assert_equal 1, Reminders::Run.new(clinic, now: NOW).call[:sent]
    assert_equal "email", Message.sole.channel
    SourceFixture::Patient.find(1).update!(email: "fail@example.test")
    SourceFixture::Appointment.find(1).update!(start_at: Time.utc(2026, 11, 25, 14))
    Reminders::Run.new(clinic, now: NOW + 1.day).call
    assert_equal "failed", Message.order(:id).last.status
    assert_equal "Delivery failed", Visit.sole.issue
  end

  test "outside sending window and at visit start no messages are sent" do
    clinic = SourceFixture.create
    Reminders::Run.new(clinic, now: Time.utc(2026, 11, 17, 15)).call
    assert_empty Message.all
    SourceFixture::Appointment.find(1).update!(start_at: Time.utc(2026, 11, 17, 11))
    Reminders::Run.new(clinic, now: NOW).call
    assert_empty Message.all
  end

  test "source connection rejects bulk writes" do
    SourceFixture.create
    assert_raises(ActiveRecord::StatementInvalid) { Pms::Patient.where(id: 1).update_all(email: "wrong@example.test") }
    assert_equal "demo1@example.test", SourceFixture::Patient.find(1).email
  end

  test "empty source preserves previous work and prevents sends" do
    clinic = SourceFixture.create
    Reminders::Run.new(clinic, now: NOW - 2.hours).call
    id = Visit.sole.id
    SourceFixture::Appointment.delete_all
    assert_raises(Pms::Refresh::Unavailable) { Reminders::Run.new(clinic, now: NOW).call }
    assert_equal id, Visit.sole.id
    assert_empty Message.all
    assert_includes clinic.reload.sync_error, "no appointments"
  end

  test "parallel reminder runs serialize the same clinic" do
    clinic = SourceFixture.create
    threads = 2.times.map do
      Thread.new do
        ActiveRecord::Base.connection_pool.with_connection do
          Reminders::Run.new(Clinic.find(clinic.id), now: NOW).call
        end
      end
    end
    threads.each(&:value)
    assert_equal 1, Message.count
  end

  test "minor unknown age and unsupported language require staff before contact" do
    [ { birthdate: "2014-01-01" }, { birthdate: nil }, { preferred_language: "fr" } ].each do |attributes|
      SourceFixture.clear
      clinic = SourceFixture.create(**attributes)
      Reminders::Run.new(clinic, now: NOW).call
      assert_empty Message.all
      assert Visit.sole.issue.present?
    end
  end
end
