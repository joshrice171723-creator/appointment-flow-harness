# Source writes exist only in seed/test administration, never runtime models.
module SourceFixture
  class Clinic < ApplicationRecord
    self.table_name = "pms.clinics"
  end
  class Patient < ApplicationRecord
    self.table_name = "pms.patients"
  end
  class Appointment < ApplicationRecord
    self.table_name = "pms.appointments"
  end

  def self.create(clinic_id: 1, id: 1, days: 7, now: Time.utc(2026, 11, 17, 17), phone: "(512) 555-0101", email: "demo1@example.test", **patient)
    Clinic.upsert({ id: clinic_id, name: clinic_id == 1 ? "Austin" : "Phoenix", city: clinic_id == 1 ? "Austin" : "Phoenix", state: clinic_id == 1 ? "TX" : "AZ" })
    ::Clinic.find_or_create_by!(id: clinic_id) { |clinic| clinic.name = clinic_id == 1 ? "Austin" : "Phoenix"; clinic.timezone = clinic_id == 1 ? "America/Chicago" : "America/Phoenix" }
    Patient.create!({ id: id, first_name: "Demo", last_name: "Patient #{id}", birthdate: "1990-01-01", wireless_phone: phone, email: email, preferred_language: "en" }.merge(patient))
    Appointment.create!(id: id, patient_id: id, clinic_id: clinic_id, start_at: (now.to_date + days).to_time(:utc) + 14.hours, length_minutes: 45, provider_name: "Dr. Rivera", procedure_note: "Fictional procedure; never send", status: "scheduled", updated_at: now)
    ::Clinic.find(clinic_id)
  end

  def self.clear
    [ Reply, Message, Activity, Suppression, Visit, Person, ::Clinic, Appointment, Patient, Clinic ].each(&:delete_all)
  end
end
