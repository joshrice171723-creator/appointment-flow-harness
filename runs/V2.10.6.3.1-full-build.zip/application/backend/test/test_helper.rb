ENV["RAILS_ENV"] ||= "test"
require_relative "../config/environment"
require "rails/test_help"
require_relative "support/source_fixture"

module ActiveSupport
  class TestCase
    # Run tests in parallel with specified workers
    self.use_transactional_tests = false

    # Setup all fixtures in test/fixtures/*.yml for all tests in alphabetical order.
    setup { SourceFixture.clear }
    teardown { SourceFixture.clear }

    # Add more helper methods to be used by all tests here...
  end
end
