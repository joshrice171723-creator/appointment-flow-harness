namespace :demo do
  desc "Run fake reminders for every configured clinic"
  task reminders: :environment do
    Clinic.find_each { |clinic| puts "#{clinic.name}: #{Reminders::Run.new(clinic).call.inspect}" }
  end
end
