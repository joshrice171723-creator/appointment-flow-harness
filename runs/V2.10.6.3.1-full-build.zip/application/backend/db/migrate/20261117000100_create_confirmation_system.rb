class CreateConfirmationSystem < ActiveRecord::Migration[8.1]
  def change
    create_schema :pms
    create_table "pms.clinics" do |t|
      t.text :name, null: false
      t.text :address_line
      t.text :city
      t.string :state, limit: 2
      t.text :phone
    end
    create_table "pms.patients" do |t|
      t.text :first_name, null: false
      t.text :last_name, null: false
      t.date :birthdate
      t.text :wireless_phone
      t.text :email
      t.text :preferred_language
      t.bigint :guarantor_id
    end
    add_foreign_key "pms.patients", "pms.patients", column: :guarantor_id
    create_table "pms.appointments" do |t|
      t.bigint :patient_id, null: false
      t.bigint :clinic_id, null: false
      t.text :provider_name
      t.datetime :start_at, null: false
      t.integer :length_minutes
      t.text :procedure_note
      t.text :status, null: false
      t.datetime :updated_at
    end
    add_foreign_key "pms.appointments", "pms.patients", column: :patient_id
    add_foreign_key "pms.appointments", "pms.clinics", column: :clinic_id
    add_index "pms.appointments", [ :clinic_id, :id ]
    create_table :clinics do |t|
      t.string :name, null: false
      t.string :timezone, null: false
      t.datetime :synced_at
      t.string :sync_error
      t.string :snapshot_digest
    end
    create_table :people do |t|
      t.references :clinic, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.string :name, null: false
      t.jsonb :raw, null: false, default: {}
      t.jsonb :overrides, null: false, default: {}
      t.jsonb :verified_against, null: false, default: {}
      t.string :phone
      t.string :email
      t.date :birthdate
      t.string :language
      t.boolean :conflict, null: false, default: false
      t.boolean :adult_authorized, null: false, default: false
      t.boolean :sms_allowed, null: false, default: true
      t.boolean :email_allowed, null: false, default: true
    end
    add_index :people, [ :clinic_id, :source_id ], unique: true
    add_index :people, [ :clinic_id, :phone ]
    add_index :people, [ :clinic_id, :email ]
    create_table :visits do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.bigint :source_id, null: false
      t.string :revision, null: false
      t.datetime :starts_at
      t.date :local_date, null: false
      t.string :wall_time, null: false
      t.string :source_status, null: false
      t.string :provider
      t.string :confirmation, null: false, default: "unconfirmed"
      t.string :issue
      t.string :assigned_to
      t.string :staff_outcome
    end
    add_index :visits, :source_id, unique: true
    add_index :visits, [ :clinic_id, :local_date, :id ]
    add_index :visits, [ :clinic_id, :source_status, :starts_at ]
    create_table :messages do |t|
      t.references :visit, null: false, foreign_key: true
      t.string :revision, null: false
      t.string :step, null: false
      t.string :channel, null: false
      t.string :recipient, null: false
      t.text :body, null: false
      t.string :status, null: false
      t.string :failure
      t.datetime :created_at, null: false
    end
    add_index :messages, [ :visit_id, :revision, :step, :channel ], unique: true
    create_table :replies do |t|
      t.references :clinic, null: false, foreign_key: true
      t.references :message, null: false, foreign_key: true
      t.string :external_id, null: false
      t.string :sender, null: false
      t.string :channel, null: false
      t.text :body, null: false
      t.string :result, null: false
      t.datetime :created_at, null: false
    end
    add_index :replies, [ :clinic_id, :external_id ], unique: true
    create_table :suppressions do |t|
      t.references :clinic, null: false, foreign_key: true
      t.string :recipient, null: false
      t.string :channel, null: false
    end
    add_index :suppressions, [ :clinic_id, :recipient, :channel ], unique: true
    create_table :activities do |t|
      t.references :visit, foreign_key: true
      t.references :person, null: false, foreign_key: true
      t.string :external_id, null: false
      t.string :staff, null: false
      t.string :outcome, null: false
      t.text :note, null: false
      t.jsonb :changes_recorded, null: false, default: {}
      t.datetime :created_at, null: false
    end
    add_index :activities, [ :person_id, :external_id ], unique: true
  end
end
