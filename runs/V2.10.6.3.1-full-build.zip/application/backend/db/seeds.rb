# Fictional source writes occur only during this setup task.
require_relative "../test/support/source_fixture"
abort "Seed requires an empty database; existing records were preserved" if Clinic.exists? || SourceFixture::Appointment.exists?
now = Time.current
2.times do |clinic_index|
  clinic_id = clinic_index + 1
  18.times do |index|
    id = clinic_index * 100 + index + 1
    options = { clinic_id: clinic_id, id: id, days: [ 7, 6, 3, 1, 2, 4, 10, 0, -2 ][index % 9], now: now,
      phone: "(#{clinic_id == 1 ? '512' : '602'}) 555-#{format('%04d', 100 + index)}", email: "demo#{id}@example.test" }
    options.merge!(phone: nil) if index == 1
    options.merge!(phone: "(512) 555-0199") if index == 2
    options.merge!(birthdate: nil, phone: nil, email: nil) if index == 3
    options.merge!(birthdate: "2014-01-01") if index == 4
    options.merge!(preferred_language: "es") if index == 5
    options.merge!(preferred_language: "fr") if index == 6
    options.merge!(phone: "(512) 555-0177", email: nil) if [ 9, 10 ].include?(index)
    SourceFixture.create(**options)
    if index >= 12
      SourceFixture::Appointment.find(id).update!(start_at: (now.to_date - (index - 10)).to_time(:utc) + 14.hours, status: %w[complete complete broken unscheduled][index % 4])
    end
  end
  clinic = Clinic.find(clinic_id)
  # Fixed local noon creates inspectable fake history even when setup runs at night.
  demo_time = clinic.zone.local(now.year, now.month, now.day, 12)
  Reminders::Run.new(clinic, now: demo_time).call
end
puts "Seeded 2 clinics, 36 fictional patients, source visits, holds, and local fake messages."
