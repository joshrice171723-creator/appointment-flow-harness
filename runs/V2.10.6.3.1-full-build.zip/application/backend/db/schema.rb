# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_11_17_000100) do
  create_schema "pms"

  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "public.activities", force: :cascade do |t|
    t.bigint "visit_id"
    t.bigint "person_id", null: false
    t.string "external_id", null: false
    t.string "staff", null: false
    t.string "outcome", null: false
    t.text "note", null: false
    t.jsonb "changes_recorded", default: {}, null: false
    t.datetime "created_at", null: false
    t.index ["person_id", "external_id"], name: "index_activities_on_person_id_and_external_id", unique: true
    t.index ["person_id"], name: "index_activities_on_person_id"
    t.index ["visit_id"], name: "index_activities_on_visit_id"
  end

  create_table "public.clinics", force: :cascade do |t|
    t.string "name", null: false
    t.string "timezone", null: false
    t.datetime "synced_at"
    t.string "sync_error"
    t.string "snapshot_digest"
  end

  create_table "public.messages", force: :cascade do |t|
    t.bigint "visit_id", null: false
    t.string "revision", null: false
    t.string "step", null: false
    t.string "channel", null: false
    t.string "recipient", null: false
    t.text "body", null: false
    t.string "status", null: false
    t.string "failure"
    t.datetime "created_at", null: false
    t.index ["visit_id", "revision", "step", "channel"], name: "index_messages_on_visit_id_and_revision_and_step_and_channel", unique: true
    t.index ["visit_id"], name: "index_messages_on_visit_id"
  end

  create_table "public.people", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.bigint "source_id", null: false
    t.string "name", null: false
    t.jsonb "raw", default: {}, null: false
    t.jsonb "overrides", default: {}, null: false
    t.jsonb "verified_against", default: {}, null: false
    t.string "phone"
    t.string "email"
    t.date "birthdate"
    t.string "language"
    t.boolean "conflict", default: false, null: false
    t.boolean "adult_authorized", default: false, null: false
    t.boolean "sms_allowed", default: true, null: false
    t.boolean "email_allowed", default: true, null: false
    t.index ["clinic_id", "email"], name: "index_people_on_clinic_id_and_email"
    t.index ["clinic_id", "phone"], name: "index_people_on_clinic_id_and_phone"
    t.index ["clinic_id", "source_id"], name: "index_people_on_clinic_id_and_source_id", unique: true
    t.index ["clinic_id"], name: "index_people_on_clinic_id"
  end

  create_table "public.replies", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.bigint "message_id", null: false
    t.string "external_id", null: false
    t.string "sender", null: false
    t.string "channel", null: false
    t.text "body", null: false
    t.string "result", null: false
    t.datetime "created_at", null: false
    t.index ["clinic_id", "external_id"], name: "index_replies_on_clinic_id_and_external_id", unique: true
    t.index ["clinic_id"], name: "index_replies_on_clinic_id"
    t.index ["message_id"], name: "index_replies_on_message_id"
  end

  create_table "public.suppressions", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.string "recipient", null: false
    t.string "channel", null: false
    t.index ["clinic_id", "recipient", "channel"], name: "index_suppressions_on_clinic_id_and_recipient_and_channel", unique: true
    t.index ["clinic_id"], name: "index_suppressions_on_clinic_id"
  end

  create_table "public.visits", force: :cascade do |t|
    t.bigint "clinic_id", null: false
    t.bigint "person_id", null: false
    t.bigint "source_id", null: false
    t.string "revision", null: false
    t.datetime "starts_at"
    t.date "local_date", null: false
    t.string "wall_time", null: false
    t.string "source_status", null: false
    t.string "provider"
    t.string "confirmation", default: "unconfirmed", null: false
    t.string "issue"
    t.string "assigned_to"
    t.string "staff_outcome"
    t.index ["clinic_id", "local_date", "id"], name: "index_visits_on_clinic_id_and_local_date_and_id"
    t.index ["clinic_id", "source_status", "starts_at"], name: "index_visits_on_clinic_id_and_source_status_and_starts_at"
    t.index ["clinic_id"], name: "index_visits_on_clinic_id"
    t.index ["person_id"], name: "index_visits_on_person_id"
    t.index ["source_id"], name: "index_visits_on_source_id", unique: true
  end

  add_foreign_key "public.activities", "public.people"
  add_foreign_key "public.activities", "public.visits"
  add_foreign_key "public.messages", "public.visits"
  add_foreign_key "public.people", "public.clinics"
  add_foreign_key "public.replies", "public.clinics"
  add_foreign_key "public.replies", "public.messages"
  add_foreign_key "public.suppressions", "public.clinics"
  add_foreign_key "public.visits", "public.clinics"
  add_foreign_key "public.visits", "public.people"

  create_table "pms.appointments", force: :cascade do |t|
    t.bigint "patient_id", null: false
    t.bigint "clinic_id", null: false
    t.text "provider_name"
    t.datetime "start_at", null: false
    t.integer "length_minutes"
    t.text "procedure_note"
    t.text "status", null: false
    t.datetime "updated_at"
    t.index ["clinic_id", "id"], name: "index_appointments_on_clinic_id_and_id"
  end

  create_table "pms.clinics", force: :cascade do |t|
    t.text "name", null: false
    t.text "address_line"
    t.text "city"
    t.string "state", limit: 2
    t.text "phone"
  end

  create_table "pms.patients", force: :cascade do |t|
    t.text "first_name", null: false
    t.text "last_name", null: false
    t.date "birthdate"
    t.text "wireless_phone"
    t.text "email"
    t.text "preferred_language"
    t.bigint "guarantor_id"
  end

  add_foreign_key "pms.appointments", "pms.clinics"
  add_foreign_key "pms.appointments", "pms.patients"
  add_foreign_key "pms.patients", "pms.patients", column: "guarantor_id"
end
