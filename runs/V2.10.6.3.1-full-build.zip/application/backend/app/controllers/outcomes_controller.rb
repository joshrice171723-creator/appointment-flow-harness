class OutcomesController < ApplicationController
  def index
    month = Date.iso8601("#{params.fetch(:month, Date.current.strftime('%Y-%m'))}-01")
    scope = Visit.where(local_date: month...month.next_month)
    statuses = scope.group(:clinic_id, :source_status).count
    sent = Message.where(visit_id: scope.select(:id), status: "sent").joins(:visit).group(:clinic_id).count
    holds = scope.where.not(issue: nil).group(:clinic_id, :issue).count
    render json: { month: month.strftime("%Y-%m"), clinics: Clinic.order(:id).map { |clinic| aggregate(clinic, statuses, sent, holds) } }
  rescue Date::Error
    render json: { error: "Use a reporting month in YYYY-MM format" }, status: :bad_request
  end

  private

  def aggregate(clinic, statuses, sent, holds)
    counts = statuses.filter_map { |(clinic_id, status), count| [ status, count ] if clinic_id == clinic.id }.to_h
    total = counts.values.sum
    completed = counts.fetch("complete", 0)
    { id: clinic.id, name: clinic.name, recorded: total, completed: completed, canceled: counts.fetch("broken", 0),
      rescheduled: counts.fetch("unscheduled", 0), unknown: total - completed - counts.fetch("broken", 0) - counts.fetch("unscheduled", 0),
      completion_rate: total.positive? ? (completed.fdiv(total) * 100).round(1) : nil,
      messages_sent: sent.fetch(clinic.id, 0), holds: holds.filter_map { |(clinic_id, reason), count| { reason: reason, count: count } if clinic_id == clinic.id } }
  end
end
