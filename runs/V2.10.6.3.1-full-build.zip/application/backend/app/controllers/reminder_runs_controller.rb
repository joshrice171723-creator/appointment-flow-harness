class ReminderRunsController < ApplicationController
  def create
    current_staff
    render json: Reminders::Run.new(current_clinic).call, status: :created
  end
end
