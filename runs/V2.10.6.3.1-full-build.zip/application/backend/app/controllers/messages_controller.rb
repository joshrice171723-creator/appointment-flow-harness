class MessagesController < ApplicationController
  def index
    person = current_clinic.people.find(params[:person_id])
    scope = Message.where(visit_id: person.visits.select(:id), channel: params.fetch(:channel, "sms"))
    messages = scope.order(id: :desc).offset((page - 1) * page_size).limit(page_size)
    render json: { items: messages.as_json(only: [ :id, :channel, :recipient, :body, :status, :failure, :created_at ]), total: scope.count,
      replies: current_clinic.replies.where(message_id: messages.select(:id)).order(:id).as_json(only: [ :id, :message_id, :body, :result, :created_at ]) }
  end
end
