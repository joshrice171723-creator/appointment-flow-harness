class WorkItemsController < ApplicationController
  def index
    current_staff
    scope = current_clinic.visits.where.not(issue: nil).where(staff_outcome: nil)
    scope = scope.where(issue: params[:type]) if params[:type].present?
    scope = scope.where(person_id: current_clinic.people.where(name: params[:search])) if params[:search].present?
    selected = params[:state] == "in_progress" ? scope.where.not(assigned_to: nil) : scope.where(assigned_to: nil)
    resolved = current_clinic.visits.where(confirmation: "confirmed", issue: nil).or(current_clinic.visits.where.not(staff_outcome: nil))
    selected = resolved if params[:state] == "resolved"
    render json: { items: selected.order(:local_date, :id).offset((page - 1) * page_size).limit(page_size).includes(:person).map { |visit| visit_json(visit) },
      total: selected.count, counts: { attention: scope.where(assigned_to: nil).count, in_progress: scope.where.not(assigned_to: nil).count,
        resolved: resolved.count },
      synced_at: current_clinic.synced_at, sync_error: current_clinic.sync_error }
  end

  def update
    staff = current_staff
    visit = current_clinic.visits.find(params[:id])
    current_clinic.with_lock { visit.update!(assigned_to: staff) }
    render json: { assigned_to: staff }
  end
end
