class RefreshesController < ApplicationController
  def create
    current_staff
    current_clinic.with_lock { Pms::Refresh.new(current_clinic).call }
    render json: { synced_at: current_clinic.synced_at }
  rescue Pms::Refresh::Unavailable => error
    current_clinic.update!(sync_error: error.message)
    raise
  end
end
