class FollowUpsController < ApplicationController
  def create
    attributes = params.permit(:external_id, :revision, :outcome, :note).to_h
    activity = Staff::RecordFollowUp.new(current_clinic, params[:visit_id], attributes, staff: current_staff).call
    render json: { id: activity.id, outcome: activity.outcome }, status: :created
  end
end
