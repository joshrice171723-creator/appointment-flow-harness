class ContactVerificationsController < ApplicationController
  def create
    params.require(:contact)
    attributes = params.permit(:external_id, :note, :adult_authorized, :sms_allowed, :email_allowed, contact: Person::CONTACT_FIELDS).to_h
    activity = Staff::VerifyContact.new(current_clinic, params[:person_id], attributes, staff: current_staff).call
    render json: { id: activity.id, outcome: activity.outcome }, status: :created
  end
end
