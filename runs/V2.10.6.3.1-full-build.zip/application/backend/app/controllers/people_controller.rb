class PeopleController < ApplicationController
  def index
    render json: { items: current_clinic.people.order(:name, :id).offset((page - 1) * page_size).limit(page_size).as_json(only: [ :id, :name ]), total: current_clinic.people.count }
  end

  def show
    current_staff
    person = current_clinic.people.find(params[:id])
    render json: { person: person.as_json(except: [ :clinic_id ]),
      visits: person.visits.order(local_date: :desc, id: :desc).limit(30).includes(:person).map { |visit| visit_json(visit) },
      activities: person.activities.order(id: :desc).limit(30).as_json(only: [ :id, :outcome, :note, :staff, :created_at, :changes_recorded ]) }
  end
end
