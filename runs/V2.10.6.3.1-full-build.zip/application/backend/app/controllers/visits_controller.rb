class VisitsController < ApplicationController
  def index
    current_staff
    full_scope = current_clinic.visits
    full_scope = full_scope.where(local_date: params[:date]) if params[:date].present?
    full_scope = full_scope.where(person_id: params[:person_id]) if params[:person_id].present?
    full_scope = full_scope.where(person_id: matching_people) if params[:search].present?
    filtered = filter_state(full_scope)
    render json: { items: filtered.order(:local_date, :wall_time, :id).offset((page - 1) * page_size).limit(page_size).includes(:person).map { |visit| visit_json(visit) },
      total: filtered.count, counts: { all: full_scope.count, confirmed: full_scope.where(confirmation: "confirmed").count,
        unconfirmed: full_scope.where(confirmation: "unconfirmed").count, review: full_scope.where(issue: "Reply needs review").count },
      synced_at: current_clinic.synced_at, sync_error: current_clinic.sync_error, timezone: current_clinic.timezone }
  end

  private

  def matching_people
    current_clinic.people.where(name: params[:search].to_s.strip).select(:id)
  end

  def filter_state(scope)
    case params[:state]
    when "confirmed", "unconfirmed" then scope.where(confirmation: params[:state])
    when "review" then scope.where(issue: "Reply needs review")
    else scope
    end
  end
end
