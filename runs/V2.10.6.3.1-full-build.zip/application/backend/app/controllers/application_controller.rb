class ApplicationController < ActionController::API
  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: "Record not found in this clinic" }, status: :not_found
  end
  rescue_from ActiveRecord::RecordInvalid do |error|
    render json: { error: error.record.errors.full_messages.join(". ") }, status: :unprocessable_entity
  end
  rescue_from Pms::Refresh::Unavailable do |error|
    render json: { error: error.message }, status: :service_unavailable
  end
  rescue_from Staff::RecordFollowUp::Rejected, Staff::VerifyContact::Rejected, Replies::Record::Conflict do |error|
    render json: { error: error.message }, status: :conflict
  end
  rescue_from ActionController::ParameterMissing do |error|
    render json: { error: error.message }, status: :bad_request
  end

  private

  def current_clinic
    @current_clinic ||= Clinic.find(params.require(:clinic_id))
  end

  def current_staff
    staff = request.headers["X-Demo-Staff"]
    raise ActionController::ParameterMissing, "Select a demo staff identity" unless %w[Taylor Jordan].include?(staff)

    staff
  end

  def page
    [ params.fetch(:page, 1).to_i, 1 ].max
  end

  def page_size
    params.fetch(:page_size, 10).to_i.clamp(1, 50)
  end

  def visit_json(visit)
    { id: visit.id, person_id: visit.person_id, name: visit.person.name, source_id: visit.source_id,
      revision: visit.revision, wall_time: visit.wall_time, local_date: visit.local_date, starts_at: visit.starts_at,
      provider: visit.provider, confirmation: visit.confirmation, issue: visit.issue,
      assigned_to: visit.assigned_to, staff_outcome: visit.staff_outcome, outcome: visit.outcome }
  end
end
