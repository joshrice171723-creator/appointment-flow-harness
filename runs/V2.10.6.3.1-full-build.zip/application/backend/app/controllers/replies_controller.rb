class RepliesController < ApplicationController
  def create
    %i[external_id message_id sender channel body].each { |key| params.require(key) }
    attributes = params.permit(:external_id, :message_id, :sender, :channel, :body).to_h
    reply = Replies::Record.new(current_clinic, attributes).call
    render json: { id: reply.id, result: reply.result }, status: :created
  end
end
