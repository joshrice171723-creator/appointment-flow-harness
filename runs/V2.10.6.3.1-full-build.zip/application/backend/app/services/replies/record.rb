module Replies
  class Record
    class Conflict < StandardError; end

    def initialize(clinic, attributes, now: Time.current)
      @clinic, @attributes, @now = clinic, attributes.symbolize_keys, now
    end

    def call
      @clinic.with_lock do
        existing = @clinic.replies.find_by(external_id: @attributes.fetch(:external_id))
        return verify_replay(existing) if existing

        Pms::Refresh.new(@clinic, now: @now).call
        message = Message.joins(:visit).where(visits: { clinic_id: @clinic.id }).find(@attributes.fetch(:message_id))
        reply = @clinic.replies.new(@attributes.slice(:external_id, :sender, :body, :channel).merge(message: message, created_at: @now))
        reply.result = "pending"
        reply.validate!
        reply.result = interpret(reply, message)
        reply.save!
        reply
      end
    end

    private

    def verify_replay(existing)
      matches = %i[message_id sender body channel].all? { |key| existing.public_send(key).to_s == @attributes.fetch(key).to_s }
      raise Conflict, "Reply key was already used for different content" unless matches

      existing
    end

    def interpret(reply, message)
      visit = message.visit
      person = visit.person
      expected_sender = reply.sender == message.recipient && reply.channel == message.channel
      if expected_sender && reply.channel == "sms" && reply.body.strip.casecmp?("STOP")
        @clinic.suppressions.find_or_create_by!(recipient: reply.sender, channel: "sms")
        return "sms_stopped"
      end

      current_recipient = reply.channel == "sms" ? person.phone : person.email
      safe = expected_sender && current_recipient == reply.sender && message.status == "sent" &&
        message.revision == visit.revision && visit.actionable?(@now) && message.created_at <= @now &&
        person.hold_reason(@now.in_time_zone(@clinic.timezone).to_date).nil? &&
        !person.shared_contact?(reply.channel, reply.sender) &&
        !@clinic.suppressions.exists?(recipient: reply.sender, channel: reply.channel)
      if safe && reply.body.strip.casecmp?("YES")
        visit.update!(confirmation: "confirmed", issue: nil)
        "confirmed"
      else
        visit.update!(issue: "Reply needs review")
        "review"
      end
    end
  end
end
