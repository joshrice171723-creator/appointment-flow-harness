module Staff
  class VerifyContact
    class Rejected < StandardError; end

    def initialize(clinic, person_id, attributes, staff:, now: Time.current)
      @clinic, @person_id, @attributes, @staff, @now = clinic, person_id, attributes.symbolize_keys, staff, now
    end

    def call
      raise Rejected, "Enter a note and a request key" if @attributes[:note].blank? || @attributes[:external_id].blank?
      corrections = @attributes.fetch(:contact).stringify_keys.slice(*Person::CONTACT_FIELDS)
      change = { "contact" => corrections, "adult_authorized" => @attributes[:adult_authorized] == true,
        "sms_allowed" => @attributes[:sms_allowed] == true, "email_allowed" => @attributes[:email_allowed] == true }
      @clinic.with_lock do
        person = @clinic.people.find(@person_id)
        previous = person.activities.find_by(external_id: @attributes[:external_id])
        return previous if previous && previous.changes_recorded == change && previous.note == @attributes[:note] && previous.staff == @staff
        raise Rejected, "Request key has different saved content" if previous

        Pms::Refresh.new(@clinic, now: @now).call
        person.reload
        overrides = person.overrides.merge(corrections)
        baseline = person.verified_against.merge(person.raw.slice(*corrections.keys))
        baseline["guarantor_id"] = person.raw["guarantor_id"] if change["adult_authorized"]
        values = Person.contact_attributes(person.raw, overrides, baseline)
        raise Rejected, "Use a valid birthdate" if values[:birthdate] && values[:birthdate] > @now.to_date
        raise Rejected, "Use a valid mobile number or leave it empty" if overrides["wireless_phone"].present? && values[:phone].nil?
        raise Rejected, "Use a valid email or leave it empty" if overrides["email"].present? && values[:email].nil?
        person.update!(values.merge(overrides: overrides, verified_against: baseline,
          adult_authorized: @attributes[:adult_authorized] == true, sms_allowed: @attributes[:sms_allowed] == true, email_allowed: @attributes[:email_allowed] == true))
        person.activities.create!(staff: @staff, outcome: "contact_verified", note: @attributes.fetch(:note),
          external_id: @attributes.fetch(:external_id), changes_recorded: change, created_at: @now)
      end
    rescue Date::Error => error
      raise Rejected, "Use a valid birthdate", cause: error
    end
  end
end
