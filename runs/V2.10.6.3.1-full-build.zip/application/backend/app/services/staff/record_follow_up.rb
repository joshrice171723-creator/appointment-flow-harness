module Staff
  class RecordFollowUp
    class Rejected < StandardError; end
    OUTCOMES = %w[attempted confirmed canceled rescheduled].freeze

    def initialize(clinic, visit_id, attributes, staff:, now: Time.current)
      @clinic, @visit_id, @attributes, @staff, @now = clinic, visit_id, attributes.symbolize_keys, staff, now
    end

    def call
      raise Rejected, "Choose a follow-up outcome" unless OUTCOMES.include?(@attributes[:outcome])
      raise Rejected, "Enter a note and a request key" if @attributes[:note].blank? || @attributes[:external_id].blank?

      @clinic.with_lock do
        visit = @clinic.visits.find(@visit_id)
        previous = visit.activities.find_by(external_id: @attributes[:external_id])
        return previous if previous && previous.note == @attributes[:note] && previous.outcome == @attributes[:outcome] && previous.staff == @staff
        raise Rejected, "Request key has different saved content" if previous

        Pms::Refresh.new(@clinic, now: @now).call
        visit.reload
        raise Rejected, "Appointment changed. Reload and review before saving" unless visit.revision == @attributes[:revision] && visit.actionable?(@now)
        raise Rejected, "Assign this work to yourself before saving" unless visit.assigned_to == @staff

        outcome = @attributes.fetch(:outcome)
        if outcome == "confirmed"
          visit.update!(confirmation: "confirmed", issue: nil)
        elsif outcome != "attempted"
          visit.update!(staff_outcome: outcome, issue: nil)
        end
        visit.activities.create!(person: visit.person, staff: @staff, outcome: outcome,
          note: @attributes.fetch(:note), external_id: @attributes.fetch(:external_id), created_at: @now)
      end
    end
  end
end
