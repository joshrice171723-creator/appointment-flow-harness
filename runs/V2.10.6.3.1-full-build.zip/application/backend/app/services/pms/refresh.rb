require "digest"

module Pms
  class Refresh
    class Unavailable < StandardError; end

    def initialize(clinic, now: Time.current)
      @clinic = clinic
      @now = now
    end

    # The caller holds the clinic lock through refresh and any dependent decision.
    def call
      snapshot = read_snapshot
      ActiveSupport::Notifications.instrument("snapshot.pms", rows: snapshot[:patients].size + snapshot[:visits].size + 1, bytes: snapshot.to_json.bytesize)
      digest = Digest::SHA256.hexdigest([ ::Person::CONTACT_POLICY_VERSION, snapshot ].to_json)
      reconcile(snapshot) unless @clinic.snapshot_digest == digest
      @clinic.update!(snapshot_digest: digest, synced_at: @now, sync_error: nil)
    end

    private

    def read_snapshot
      Record.transaction(isolation: :repeatable_read) do
        source_clinic = Clinic.find(@clinic.id)
        visits = Appointment.where(clinic_id: @clinic.id).select(:id, :patient_id, :clinic_id, :start_at, :status, :provider_name).order(:id).map(&:attributes)
        raise Unavailable, "PMS returned no appointments; previous work was preserved" if visits.empty?

        ids = visits.map { |visit| visit.fetch("patient_id") }.uniq
        patients = Patient.where(id: ids).order(:id).map(&:attributes)
        raise Unavailable, "PMS snapshot has missing patients" unless patients.size == ids.size

        { clinic: source_clinic.attributes, patients: patients, visits: visits }
      end
    rescue ActiveRecord::RecordNotFound => error
      raise Unavailable, "PMS clinic is unavailable", cause: error
    rescue ActiveRecord::ConnectionNotEstablished, ActiveRecord::StatementInvalid => error
      raise Unavailable, "PMS read failed; no dependent action was taken", cause: error
    end

    def reconcile(snapshot)
      @clinic.update!(name: snapshot[:clinic].fetch("name"))
      people = reconcile_people(snapshot[:patients])
      existing = @clinic.visits.index_by(&:source_id)
      changes = snapshot[:visits].filter_map do |raw|
        attributes = visit_attributes(raw, people.fetch(raw.fetch("patient_id")))
        visit = existing[raw.fetch("id")]
        next if visit && attributes.all? { |key, value| visit.public_send(key) == value }

        if !visit || visit.revision != attributes[:revision]
          attributes.merge!(confirmation: "unconfirmed", issue: attributes[:starts_at] ? nil : "Appointment time needs review", staff_outcome: nil, assigned_to: nil)
        else
          attributes.merge!(confirmation: visit.confirmation, issue: visit.issue, staff_outcome: visit.staff_outcome, assigned_to: visit.assigned_to)
        end
        attributes
      end
      ::Visit.upsert_all(changes, unique_by: :source_id, returning: false) if changes.any?
      removed = @clinic.visits.where.not(source_id: snapshot[:visits].map { |row| row.fetch("id") })
      removed.where.not(source_status: "missing").update_all(source_status: "missing", confirmation: "unconfirmed", issue: "Source appointment missing; review", staff_outcome: nil)
    end

    def reconcile_people(patients)
      existing = @clinic.people.index_by(&:source_id)
      changes = patients.filter_map do |patient|
        raw = patient.slice(*::Person::CONTACT_FIELDS, "guarantor_id").transform_values { |value| value.is_a?(Date) ? value.iso8601 : value }
        person = existing[patient.fetch("id")]
        attributes = { clinic_id: @clinic.id, source_id: patient.fetch("id"), name: "#{patient.fetch('first_name')} #{patient.fetch('last_name')}", raw: raw }
        attributes.merge!(::Person.contact_attributes(raw, person&.overrides || {}, person&.verified_against || {}))
        attributes unless person && attributes.all? { |key, value| person.public_send(key) == value }
      end
      people = existing.transform_values(&:id)
      if changes.any?
        written = ::Person.upsert_all(changes, unique_by: [ :clinic_id, :source_id ], returning: %w[source_id id])
        people.merge!(written.rows.to_h)
      end
      people
    end

    def visit_attributes(raw, person_id)
      wall = raw.fetch("start_at").strftime("%Y-%m-%d %H:%M:%S")
      revision = Digest::SHA256.hexdigest([ raw.fetch("id"), raw.fetch("patient_id"), wall, raw.fetch("status") ].join("|"))
      { clinic_id: @clinic.id, person_id: person_id, source_id: raw.fetch("id"), revision: revision,
        wall_time: wall, local_date: Date.iso8601(wall[0, 10]), starts_at: utc_time(wall),
        source_status: raw.fetch("status"), provider: raw["provider_name"] }
    end

    def utc_time(wall)
      time = DateTime.parse(wall)
      local = Time.utc(time.year, time.month, time.day, time.hour, time.minute, time.second)
      @clinic.zone.tzinfo.local_to_utc(local)
    rescue TZInfo::PeriodNotFound, TZInfo::AmbiguousTime
      nil
    end
  end
end
