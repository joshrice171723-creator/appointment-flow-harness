module Reminders
  class Run
    INITIAL_DAYS = 7
    FOLLOW_UP_DAYS = 3
    FINAL_DAYS = 1
    WINDOW = (10...18)

    def initialize(clinic, now: nil, transport: FakeTransport.new)
      @clock = now ? -> { now } : -> { Time.current }
      @clinic, @now, @transport = clinic, @clock.call, transport
    end

    def call
      sent = 0
      @clinic.with_lock do
        Pms::Refresh.new(@clinic, now: @now).call
        @clinic.visits.upcoming(@now).where(starts_at: ...(@now + 8.days)).in_batches(of: 250) do |scope|
          visits = scope.includes(:person).to_a
          prepare_batch(visits)
          visits.each { |visit| sent += process_visit(visit) }
          Message.insert_all!(@attempts, returning: false) if @attempts.any?
          @issues.group_by { |_, reason| reason }.each do |reason, entries|
            @clinic.visits.where(id: entries.map(&:first)).update_all(issue: reason)
          end
        end
      end
      { sent: sent, synced_at: @clinic.synced_at }
    rescue Pms::Refresh::Unavailable => error
      @clinic.update!(sync_error: error.message)
      raise
    end

    private

    def prepare_batch(visits)
      people = visits.map(&:person)
      phones, emails = people.map(&:phone).compact.uniq, people.map(&:email).compact.uniq
      @phone_counts = @clinic.people.where(phone: phones).group(:phone).count
      @email_counts = @clinic.people.where(email: emails).group(:email).count
      @suppressions = @clinic.suppressions.where(recipient: phones + emails).pluck(:channel, :recipient).to_set
      @prior_steps = Message.where(visit_id: visits.map(&:id), revision: visits.map(&:revision)).pluck(:visit_id, :step, :channel).group_by(&:first)
      @attempts, @issues = [], {}
    end

    def process_visit(visit)
      current_time = @clock.call
      return 0 unless visit.actionable?(current_time)

      local = current_time.in_time_zone(@clinic.timezone)
      person = visit.person
      reason = person.hold_reason(local.to_date)
      channels = person.permitted_channels(suppressions: @suppressions)
      channels.reject! { |channel, recipient| (channel == "sms" ? @phone_counts : @email_counts).fetch(recipient, 0) > 1 }
      reason ||= "No safe permitted contact channel" if channels.empty?
      if reason
        @issues[visit.id] = reason unless visit.issue == reason || visit.issue == "Reply needs review"
        return 0
      end
      days = (visit.local_date - local.to_date).to_i
      issue = days <= 2 && visit.confirmation != "confirmed" ? "No confirmation; contact patient" : nil
      @issues[visit.id] = issue unless visit.issue == "Reply needs review" || visit.issue == issue || visit.issue == "Delivery failed"
      return 0 unless WINDOW.cover?(local.hour)
      return 0 if days > INITIAL_DAYS

      step = days <= FINAL_DAYS ? "final" : days <= FOLLOW_UP_DAYS ? "follow_up" : "initial"
      return 0 if visit.confirmation == "confirmed" && step != "final"

      channel = channels.key?("sms") ? "sms" : "email"
      if days == 6 && channels.key?("email") && @prior_steps.fetch(visit.id, []).any? { |_, _, channel| channel == "sms" }
        step, channel = "backup", "email"
      end
      deliver(visit, step, channel, channels.fetch(channel))
    end

    def deliver(visit, step, channel, recipient)
      return 0 if @prior_steps.fetch(visit.id, []).include?([ visit.id, step, channel ])
      send_time = @clock.call
      return 0 unless visit.actionable?(send_time) && WINDOW.cover?(send_time.in_time_zone(@clinic.timezone).hour)

      body = message_body(visit, channel)
      status, failure = "sent", nil
      begin
        @transport.deliver(channel: channel, recipient: recipient, body: body)
      rescue FakeTransport::DeliveryFailure => error
        status, failure = "failed", error.message
      end
      @attempts << { visit_id: visit.id, revision: visit.revision, step: step, channel: channel, recipient: recipient,
        body: body, status: status, failure: failure, created_at: send_time }
      @issues[visit.id] = "Delivery failed" if failure && visit.issue != "Reply needs review"
      status == "sent" ? 1 : 0
    end

    def message_body(visit, channel)
      details = "#{visit.starts_at.in_time_zone(@clinic.timezone).strftime('%a %b %d, %Y %H:%M')} #{@clinic.timezone}, #{@clinic.name}."
      if visit.person.language == "es"
        action = visit.confirmation == "confirmed" ? "Cita confirmada." : "Responda YES para confirmar o NO para ayuda."
        "Cita: #{details} #{action}#{channel == 'sms' ? ' Responda STOP para detener mensajes.' : ''}"
      else
        action = visit.confirmation == "confirmed" ? "Your visit is confirmed." : "Reply YES to confirm or NO for help."
        "Appointment: #{details} #{action}#{channel == 'sms' ? ' Reply STOP to stop texts.' : ''}"
      end
    end
  end
end
