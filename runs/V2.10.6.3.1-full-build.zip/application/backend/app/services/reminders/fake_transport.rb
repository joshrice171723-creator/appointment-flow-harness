module Reminders
  class FakeTransport
    class DeliveryFailure < StandardError; end

    def deliver(channel:, recipient:, body:)
      # Reserved synthetic values provide a deterministic failure exercise.
      raise DeliveryFailure, "Simulated provider rejection" if recipient.end_with?("0199") || recipient.start_with?("fail@")

      "sent"
    end
  end
end
