module Pms
  class Clinic < Record
    self.table_name = "pms.clinics"
  end
end
