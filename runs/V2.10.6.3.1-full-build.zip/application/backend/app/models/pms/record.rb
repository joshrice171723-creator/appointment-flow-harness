module Pms
  class Record < ActiveRecord::Base
    self.abstract_class = true
    connects_to database: { writing: :pms }
    self.skip_time_zone_conversion_for_attributes = [ :start_at, :updated_at ]

    def readonly?
      true
    end
  end
end
