class Visit < ApplicationRecord
  belongs_to :clinic
  belongs_to :person
  has_many :messages, dependent: :restrict_with_exception
  has_many :activities, dependent: :restrict_with_exception

  scope :upcoming, ->(now) { where(source_status: "scheduled", staff_outcome: nil, starts_at: now..).where.not(starts_at: now) }

  def actionable?(now)
    source_status == "scheduled" && staff_outcome.nil? && starts_at && starts_at > now
  end

  def outcome
    { "complete" => "Completed", "broken" => "Canceled", "unscheduled" => "Rescheduled" }.fetch(source_status, "Unknown")
  end
end
