class Reply < ApplicationRecord
  belongs_to :clinic
  belongs_to :message
  validates :external_id, :body, :sender, presence: true
  validates :body, length: { maximum: 2000 }
end
