class Person < ApplicationRecord
  belongs_to :clinic
  has_many :visits, dependent: :restrict_with_exception
  has_many :activities, dependent: :restrict_with_exception

  CONTACT_FIELDS = %w[birthdate wireless_phone email preferred_language].freeze
  CONTACT_POLICY_VERSION = 1

  def self.normalize_phone(value)
    digits = value.to_s.gsub(/\D/, "")
    digits = digits.delete_prefix("1") if digits.length == 11
    "+1#{digits}" if digits.match?(/\A[2-9]\d{2}[2-9]\d{6}\z/)
  end

  def self.normalize_email(value)
    value.to_s.strip.downcase.presence if value.to_s.strip.match?(/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/)
  end

  def self.contact_attributes(raw, overrides, verified_against)
    effective = raw.merge(overrides)
    { phone: normalize_phone(effective["wireless_phone"]), email: normalize_email(effective["email"]),
      birthdate: effective["birthdate"] && Date.iso8601(effective["birthdate"]), language: effective["preferred_language"],
      conflict: verified_against.any? { |key, value| raw[key] != value } }
  end

  def hold_reason(today)
    return "Source and verified contact differ" if conflict
    return "Verify birthdate" unless birthdate && birthdate <= today
    return "Verify authorized adult contact" if birthdate > today.years_ago(18) && !adult_authorized
    return "Review preferred language" unless %w[en es].include?(language)

    nil
  end

  def permitted_channels(suppressions:)
    channels = {}
    channels["sms"] = phone if phone && sms_allowed
    channels["email"] = email if email && email_allowed
    channels.reject do |channel, recipient|
      suppressions.include?([ channel, recipient ])
    end
  end

  def shared_contact?(channel, recipient)
    column = channel == "sms" ? :phone : :email
    clinic.people.where(column => recipient).where.not(id: id).exists?
  end
end
