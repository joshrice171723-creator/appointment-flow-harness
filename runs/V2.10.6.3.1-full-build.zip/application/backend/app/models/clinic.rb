class Clinic < ApplicationRecord
  has_many :people, dependent: :restrict_with_exception
  has_many :visits, dependent: :restrict_with_exception
  has_many :suppressions, dependent: :restrict_with_exception
  has_many :replies, dependent: :restrict_with_exception

  def zone
    ActiveSupport::TimeZone[timezone]
  end
end
