class Message < ApplicationRecord
  belongs_to :visit
  has_many :replies, dependent: :restrict_with_exception
end
