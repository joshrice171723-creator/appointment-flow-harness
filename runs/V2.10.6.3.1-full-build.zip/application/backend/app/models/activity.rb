class Activity < ApplicationRecord
  belongs_to :visit, optional: true
  belongs_to :person
  validates :external_id, :staff, :note, presence: true
  validates :note, length: { maximum: 2000 }
end
