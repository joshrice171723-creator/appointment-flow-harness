require_relative "../config/environment"

# Administration uses the verified supplied database as its maintenance connection.
config = ApplicationRecord.connection_db_config.configuration_hash
abort "Wrong private port" unless config[:port].to_s == ENV.fetch("PGPORT")
name = "apex_v210_rebuild_setup_test"
ApplicationRecord.with_connection do |connection|
  exists = connection.select_value("SELECT 1 FROM pg_database WHERE datname = #{connection.quote(name)}")
  if exists
    puts "Clean-setup database already exists; setup will preserve its records."
  else
    connection.create_database(name)
    puts "Created #{name} on private port #{config[:port]}."
  end
end
