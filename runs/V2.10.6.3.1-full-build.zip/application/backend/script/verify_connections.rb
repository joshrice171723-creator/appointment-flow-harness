require_relative "../config/environment"

[ ApplicationRecord, Pms::Record ].each do |owner|
  owner.with_connection do |connection|
    config = connection.pool.db_config.configuration_hash
    resolved = connection.select_one("SELECT current_database() AS database, current_user AS user, inet_server_addr() AS host, inet_server_port() AS port, current_setting('default_transaction_read_only') AS read_only")
    abort "Wrong private endpoint" unless resolved["port"].to_s == ENV.fetch("PGPORT") && resolved["host"] == ENV.fetch("PGHOST")
    abort "Unsafe test name" if Rails.env.test? && !resolved["database"].end_with?("_test")
    abort "Wrong resolved database" unless resolved["database"] == config[:database]
    abort "PMS must be read-only" if owner == Pms::Record && resolved["read_only"] != "on"
    puts "#{owner.name}: #{resolved.inspect}"
  end
end
