# V2.5.1.0.0

Standalone full rebuild. Input manifest matches the launched workspace. The application is the recorded frozen build.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
