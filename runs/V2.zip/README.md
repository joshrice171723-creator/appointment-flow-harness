# V2

Historical source and harness. Archived input manifest matches the saved application workspace.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
