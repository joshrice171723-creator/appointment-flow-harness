# V2.4.1.1.0 paired trial

Earlier matched rebuild attempt. Partial application source from an interrupted trial. No completed benchmark.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
