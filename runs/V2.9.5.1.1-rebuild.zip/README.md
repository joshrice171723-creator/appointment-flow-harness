# V2.9.5.1.1-rebuild

Standalone full rebuild. The input manifest and prompt match the launch receipt. Includes first and final source checkpoints plus the observed checks.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
