# Patient appointment history repair

| Revision | Grade for the requested read | Evidence |
| --- | --- | --- |
| `500c78e877dc49e53c19da18efb6d2d31618b61e` | REVISE | Upcoming history checks two visits and scans all 5,577 mirror appointments on the grown fixture. The tracked-only past projection also grows from 23 to 58 shared buffers. |
| `bb76461f3ed52b83915850ff25c691d110d4106e` | PASS | Both lookups are selective on the grown fixture. All five response hashes and request work counters match at both sizes. |

The repair grade is a builder self-review. The repository-wide Active Record checker still grades REVISE on 17 inherited findings. The independent harness comparison is external to this checkout.

## Request and query ownership

`GET /api/patient-details/:id/history` checks staff clinic access and patient visibility in `DeskController#patient_history`. `PatientWorkspaceHistory#appointments` requests 26 keys for a 25-row page and encodes the next cursor from its last displayed key. `PatientAppointmentsQuery#page` chooses source and tracked keys in one repeatable-read snapshot. `#rows` hydrates the selected IDs and serializes revisions, source outcomes, and local confirmation facts. The measured requests issued zero writes. [Controller](../backend/app/controllers/desk_controller.rb#L30) · [History](../backend/app/queries/patient_workspace_history.rb#L63) · [Appointment query](../backend/app/queries/patient_appointments_query.rb#L15)

A source booking with the same appointment ID, patient, and clinic owns the history date across the entire mirror. Missing and reassigned bookings allow the tracked visit date to qualify. The original lookup expressed that rule as a left join on ID with a filter after the join. A trial subquery scoped source IDs to candidate visits, but PostgreSQL still chose a hash join, scanned the mirror, and used 77 shared buffers for grown upcoming history. The final lookup uses a three-key Active Record association and `where.missing`. PostgreSQL recognizes the resulting ownership check as an anti join. The existing ID-only association still serves hydration. The repair adds no indexes, schema changes, or stored values. [Visit associations](../backend/app/models/visit.rb#L1) · [Tracked projection](../backend/app/queries/patient_appointments_query.rb#L88)

## Executed plans and responses

Run from `backend` with the supplied disposable `v285_original_test` database configuration. The benchmark and tests each reset the fixture. The benchmark warmed each request, took five complete Rack request samples, then replayed captured SELECTs with their original binds under `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)`. PostgreSQL was 17.11 and Rails was 8.1.3.1. [Captured request metrics and four plans per revision](PATIENT_APPOINTMENT_BENCHMARK.jsonl)

```sh
ruby ../benchmark/patient_requests.rb --seed 719
ruby -Itest -r ./test/patient_workspace_test.rb -r ./test/patient_details_test.rb -e nil -- --seed 719
ruby bin/rails runner -e test ../.refactor-harness/quality/check_active_record_queries.rb
```

The small fixture contains 577 appointments and 278 visits. The grown fixture contains 5,577 appointments and 15,278 visits. Its added appointments belong to the mixed-history patient and predate the upcoming cutoff. The added visits include 5,000 older revisions for the tracked-only patient that qualify for the past filter.

Shared buffers are hit plus read blocks. The projection column counts the entire tracked projection. The mirror column counts its appointment scan or lookup node.

| Request | Fixture | Baseline mirror operation | Repaired mirror operation | Mirror buffers | Projection buffers |
| --- | --- | --- | --- | ---: | ---: |
| Upcoming | Small | Primary-key index, two probes | Primary-key index, two probes | 5 → 5 | 8 → 8 |
| Upcoming | Grown | Sequential scan, 5,577 rows | Primary-key index, two probes | 71 → 5 | 74 → 8 |
| Tracked-only past | Small | Sequential scan, 577 rows | Clinic/patient index-only scan, zero matches, materialized once | 9 → 2 | 23 → 16 |
| Tracked-only past | Grown | Primary-key index, 26 probes | Clinic/patient index-only scan, zero matches, materialized once | 52 → 2 | 58 → 8 |

Upcoming examined two visit candidates and returned one tracked key at both sizes. The mixed response contained the same three keys after merging with source appointments. Grown tracked-only stopped after 26 ordered visit keys and displayed 25 with a cursor. Median whole-request timings over five samples on the grown fixture were 92.228 → 72.394 ms for upcoming and 185.033 → 102.041 ms for tracked-only past. The raw capture includes every timing sample.

All five callers returned HTTP 200. Full-body SHA-256 values match across both fixture sizes and both revisions, including the exact cursor strings. All recorded request counters match, with zero write statements or affected rows.

| Request | Body bytes | Read statements | Rows returned to Rails | Models instantiated | Body SHA-256 |
| --- | ---: | ---: | ---: | ---: | --- |
| Mixed past, page one | 7,893 | 17 | 62 | 35 | `fc4f780d9b81d3788413974e29fb72a3faa7cf9263c93d79c87e06174048469f` |
| Mixed past, page two | 7,704 | 10 | 57 | 30 | `a49f05383af60bb7a0adcc65a797c526c085414689af0af8abe0b151e1b9e22e` |
| Mixed upcoming | 1,146 | 17 | 14 | 11 | `d9d6e0e9e47d3e36e4a19a5bf762161650aeaf2e5f7c67994513c71fb82b2d57` |
| Mixed patient detail | 1,920 | 20 | 13 | 7 | `c23dcc27b56ca7ccf15cb033fd161969c37208b34f5b070870e8c901dfbaa1fa` |
| Tracked-only past | 9,079 | 18 | 59 | 32 | `cf0c3d561dd73c707a4eae11f48531397244e8599b608c3f9607b65a14c0e754` |

## Repair regrade

| Criterion | Grade | Failure challenged and evidence |
| --- | --- | --- |
| Required behavior | PASS | A tracked date could override a source date outside the page or a higher revision ID could change selection. The benchmark asserts ordered mixed and tracked IDs, revision IDs, confirmation, source status, and next-appointment selection. The workspace test exercises microsecond date ties and the grouped fallback for repeated revisions across pages. [Workspace tests](../backend/test/patient_workspace_test.rb#L39) |
| Safety and data boundaries | PASS | An appointment ID can be reassigned across patients or clinics. The endpoint test expects local visit facts without the new booking's status or provider. It restores one mirror booking to the original clinic at an upcoming date and expects its old past row to disappear. Deleting the mirror row restores the exact original past rows. The suite also checks clinic authorization and live guardian authority. The benchmark confirms the external reader can SELECT and lacks write grants. The source replica retains only the two original appointment indexes. [Reassignment and missing-source test](../backend/test/patient_workspace_test.rb#L79) · [Guardian test](../backend/test/patient_workspace_test.rb#L168) |
| Performance and Rails queries | PASS | Two visits could still trigger a full source scan, or old tracked visits could increase work before the first page. Both grown plans use index lookups and eight shared buffers. The Rails-generated lookup still reads the migrated tables `desk.visits` and the app mirror `pms.appointments`. [Plan capture](PATIENT_APPOINTMENT_BENCHMARK.jsonl) |
| Material workflow coverage | PASS | Changing the tracked projection could cause duplicates or skips across date ties, alter the mixed page, or affect patient detail. Mixed past pages, upcoming, tracked-only past, and detail ran through the authenticated HTTP caller. The focused suite also exercised guarded activity and detail paths from the frozen refactor. [Workspace tests](../backend/test/patient_workspace_test.rb) |
| Human readability | PASS | A change to the ownership rule could accidentally affect ID-based hydration. The three matching keys live together on `Visit` and the tracked-date decision is the single `where.missing` call in `tracked_page`. Date filtering, later revisions, source floor, and group fallback remain in execution order there. [Visit](../backend/app/models/visit.rb#L1) · [Tracked projection](../backend/app/queries/patient_appointments_query.rb#L88) |
| Ease of change | PASS | A page-size change could affect source and tracked limits differently. In an ignored temporary copy of `PatientWorkspaceHistory`, changing only `PAGE_SIZE` from 25 to 10 returned tracked IDs 8400000–8400009 and 8400010–8400019 via the returned cursor. The neighboring upcoming request still returned 8100200, 8100102, and 8100101. The exercise used the grown fixture through Rack and the temporary copy was removed. |
| Failure and transaction behavior | PASS | Cursor misuse could disclose another section's page or a partial read could persist effects. The wrong-section cursor returns 409 through the real endpoint. The source and tracked key reads keep the existing repeatable-read transaction, and every warmed replay in the benchmark asserts zero writes and an identical body. [Cursor test](../backend/test/patient_workspace_test.rb#L39) · [Snapshot](../backend/app/queries/patient_appointments_query.rb#L15) |
| Verification and handoff | PASS for this read | Both benchmark runs passed 1 test and 199 assertions. The compatibility run passed 11 tests and 132 assertions on the frozen revision, then 11 tests and 136 assertions after the repair and new mirror-change assertions. Both commands rebuilt the disposable schemas through the real migrations and seeded the same fixture. The repository-wide checker ran against the migrated test database and reported only the inherited findings below. |

The repository-wide check flagged `FollowUpIssue` reply filtering, `SourceSync` timestamp lookup, `OperationsQuery` reporting, `Database` connection and lock operations, and `PmsSnapshot` import expressions. These files match the frozen revision byte-for-byte. The separate follow-up and activity cursor path in `PatientWorkspaceHistory#paginate` also retains inherited Arel. The checker reported no missing or view-backed model data sources and no findings in the changed production files. [Issue filtering](../backend/app/models/follow_up_issue.rb#L11) · [Source timestamp](../backend/app/models/source_sync.rb#L9) · [Reporting](../backend/app/queries/operations_query.rb#L71) · [Database](../backend/app/services/database.rb#L30) · [Snapshot import](../backend/app/services/pms_snapshot.rb#L109) · [Other history cursors](../backend/app/queries/patient_workspace_history.rb#L158)
