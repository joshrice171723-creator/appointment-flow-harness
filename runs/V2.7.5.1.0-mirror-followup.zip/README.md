# V2.7.5.1.0

Patient appointment refactor and app-owned index follow-up. Follow-up guidance hashes match. All 330 request measurements had matching bodies and cursors.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
