# Original appointment-flow

Historical product control. Includes the preserved project guidance. No single frozen launch input is documented.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
