# V2.8.5.1.1-rebuild

Standalone full rebuild. The app passed its own rubric and 42 of 44 separate checks. The contact query still grows with source data.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
