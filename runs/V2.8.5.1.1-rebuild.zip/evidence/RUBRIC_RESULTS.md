# Quality review

The independent reviewer inspected the new project's routes, models, migrations, workflows, tests, and React callers. The review ran without optional skills or prior-project sources. It reproduced the findings in an isolated PostgreSQL database.

## Round 1 — REVISE

Application checkpoint `0b2191ed92d6c9e8bd5a36d397f3f05290b27111`.

| Criterion | Grade | Observed evidence |
| --- | --- | --- |
| Required behavior | REVISE | The configured gate found that default-clock reminder POST dereferenced nil before starting a run. The explicit-clock CLI still delivered fake messages. |
| Safety and data boundaries | REVISE | Two staff sessions loaded the same source contact version. Jordan corrected the number to 512-555-0125 and Alex's stale draft restored 512-555-0101. Both saves returned 201. The next explicit-clock run wrote one delivery to the stale number. |
| Performance and Rails queries | REVISE | A NO reply with 120 additional source patients read the recipient directory and stored clarification candidates the UI and service could never use for that reply. The migrated-database query source check passed. |
| Material workflow coverage | REVISE | A source contact change was tested before the stale local-verification case had an executable regression. |
| Human readability | PASS | Keep HTTP inputs in resource controllers. The reminder CLI and staff POST share `ReminderRun`. The reply and staff write objects expose transaction scope in their public methods. The send window and cadence have named rule owners. |
| Ease of change | UNVERIFIED | The disposable rule exercise was still running during the first grade. |
| Failure and transaction behavior | PASS | Independent reply probe inserted the inbound event and then forced a PostgreSQL check violation on the confirmation write. Zero event replies and zero decisions survived. The same event confirmed after removing the constraint. |
| Verification and handoff | REVISE | Seven of eight configured checks passed. Rails tests exposed the runtime error. |

The repairs moved the actual send clock inside the reminder lock and rechecked at dispatch. Contact edits now compare both replica and local verified values within the transaction, after recognizing an exact replay. Only exact YES prepares appointment candidates. A work item retains its recorded clinic, patient, and reply references when the source record disappears, and the staff UI can load that case through its own clinic-scoped endpoint.

## Regrade — PASS

Application checkpoint `49e692ac9b99b5811f3f8b3de7d5b2efe378d57f`. The independent reviewer reran the challenged workflow using a separate PostgreSQL database and inspected the repair and the material callers. The implementation agent ran the configured gate and clean-checkout smoke.

| Criterion | Grade | What could fail and the evidence checked |
| --- | --- | --- |
| Required behavior | PASS | The staff reminder POST uses the default clock and delivered one attempt after the contact correction. The time-controlled tests prove SMS, backup email, and suppression after confirmation, with an informational final step. The CLI run recorded four Austin attempts. The browser exercised both SMS and email YES against the seeded app and reported the resulting confirmations. |
| Safety and data boundaries | PASS | Independent retest gave the first verifier 201 and the stale draft 409. One audit survived and the next send used +15125550125. The reminder suite changes a formatted contact owner outside the active clinic/date scope and proves suppression with an allowed control. The reply suite verifies new start and appointment ID, a wrong clinic/patient, late replies, shared numbers, source removal, and STOP. The batch suite covers concurrent sends, DST ambiguity and gap, missing or empty source, and contact holds. The leadership response assertion exercises both clinics and rejects patient identifiers and the test note. Source models are read-only at runtime and both transports are simulated. |
| Performance and Rails queries | PASS | The benchmark holds required results and effects fixed under 4,000 other appointments and verifies indexed actual plans. The separate raw-owner test quantifies a safety-dependent directory scan. After repair an ordinary NO with 120 unrelated patients returned 201/review with zero owner queries and no candidates. The Active Record query source check passed against migrated databases. [Measurements and scope](PERFORMANCE_RESULTS.md) |
| Material workflow coverage | PASS | Checked reminder POST and shared rake command, inbox picker/history/replies, board filters and assignment, scoped appointment paging and patient detail, staff follow-up and contact audit, and clinic/month outcome summaries. Existing request assertions cover server contracts and the live browser exercised the workspaces and both reply channels. The case lookup retains the audit after source removal, and React uses that clinic-scoped lookup when the current patient is unavailable. |
| Human readability | PASS | The reminder controller delegates to `ReminderRun#call` for eligibility, delivery and source check. The inbound controller identifies the delivered message, then `PatientReplyIntake#call` interprets, records and applies in one transaction. `StaffFollowUp#record` and `ContactVerification#record` own their independent writes. The appointment and outcomes controllers keep their screen scopes and payloads in their own resource. `ReminderRun::SEND_HOURS` owns the local start and end hours. |
| Ease of change | PASS | The disposable copy moved the opening time from 10:00 to 11:00 in `reminder_run.rb`. A targeted staff reminder request produced zero attempts at Phoenix 09:59 and 10:00 and one at 11:00. Wrong-status and past visits stayed excluded. One test and seven assertions passed. The submitted application retains 10:00. |
| Failure and transaction behavior | PASS | PostgreSQL constraints forced failures after inbound reply or staff-audit creation. The relevant API tests assert the original PG cause and verify that the reply, decision, and audit roll back as applicable. Retry with the same event then commits once. An error during page two of the reminder run rolled back page one's attempts and the source timestamp. A Chrome fixture committed a reply, interrupted its response, retained the draft, retried the same event, and observed one persisted reply. |
| Verification and handoff | PASS | All eight local gate checks passed. Rails passed 32 tests and 248 assertions. Vitest passed two tests. RuboCop reported zero offenses, Brakeman zero warnings, and the React lint, type check and build passed. A new PostgreSQL database was created, migrated and seeded. The locked Ruby/Node dependencies and launcher booted the application in a separate checkout, and installed Chrome exercised it there. |

## Acceptance evidence

| Checklist area | Result and evidence |
| --- | --- |
| Official appointment selection, cadence, SMS/email, reply, clinic staff UI, local setup | PASS. Reminder and reply request tests, scoped appointment list tests, fresh launch, manual CLI and browser smoke. |
| Official written handoff | README, architecture and AI usage verified. Candidate-authored DECISIONS.md and live defense remain candidate work. |
| Workspace entry and clinic isolation | PASS. Staff session, appointment and work-item scope assertions, plus the three browser workspaces. |
| Board, calendar, contact verification and audit | PASS. `staff_workspaces_test.rb` asserts search, counts, filter scope, stable order, assignment, note validation, replay, resolution, and current/local verification conflicts. The growth test asserts page boundaries. The browser navigated appointment dates. |
| Patient inbox and reporting | PASS. Browser verified the email empty state and accepted SMS and email replies. The month report requests assert outcome and activity totals and absence of patient data. Chrome opened the expanded report. |
| Visual layout and narrow screen | PASS. Desktop smoke reached all three workspaces and Chrome checked the 390 px Workspaces viewport for overflow. The supplied references guided the warm neutral layout and navigation. |
| Safety and change behavior | PASS. `reminder_run_test.rb`, `patient_reply_test.rb` and `staff_workspaces_test.rb` exercise the risky caller paths and PostgreSQL rollback. The independent reviewer re-exercised the reported failure cases. |
| Candidate live modification and external CI | Candidate live defense and hosted CI were not run. The automated disposable policy exercise and local gate did run. This checkout has no configured remote. |
