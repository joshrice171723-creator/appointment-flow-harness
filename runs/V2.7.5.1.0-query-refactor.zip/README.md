# V2.7.5.1.0 query refactor

Patient appointment query before the index follow-up. Launch prompt and supplied guidance match recorded input hashes. Ten paired HTTP responses matched.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
