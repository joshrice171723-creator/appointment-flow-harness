# Architecture

```mermaid
flowchart LR
  React["React workspaces"] --> Rails["Rails HTTP resources"]
  Rake["Reminder command"] --> Reminders["ReminderRun"]
  Rails --> Reminders
  Rails --> Replies["PatientReply"]
  Rails --> Staff["StaffFollowUp / VerifyPatientContact"]
  Reminders --> Policy["ContactPolicy"]
  Replies --> Policy
  Policy --> PMS[("PostgreSQL PMS replica")]
  Reminders --> PMS
  Replies --> PMS
  Staff --> PMS
  Rails --> Comparisons["App-owned source comparisons"]
  Comparisons --> PMS
  Reminders --> Fake["Fake transport result"]
  Fake --> Local[("Messages, visit decisions, opt-outs and follow-ups")]
  Replies --> Local
  Staff --> Local
  Local --> Rails
```

- The assessment tables stay in `pms`. `PmsPatient`, `PmsVisit`, and `PmsClinic` read those tables directly. Their model guard and the source write trigger still reject runtime writes. Seed and test fixtures explicitly enable replica writes within their own transaction. The replacement migration removes the old query views and their expression indexes. Runtime queries use ordinary Active Record relations and associations.
- `PmsVisit` owns the revision fingerprint and clinic-local date. Its Ruby fingerprint preserves the original PostgreSQL text format and MD5 value, including omitted null update timestamps and trimmed fractional seconds. Saved attempts and decisions keep their identities.
- `PatientSearch` owns canonical contact keys and search prefixes in an app-owned comparison table. `PmsPatient` defines conservative source matching keys; `ContactPolicy` defines permitted recipients. A source contact can block a shared destination even if that source value is unsuitable for sending. Each contact decision refreshes IDs, phones, and email addresses across the complete source directory. A reminder run performs this refresh once across all pages. Search refreshes IDs and names separately. Each projection leaves the other's columns unchanged, and each caller refreshes its required fields before use. The source has no patient change feed, so freshness requires a full scalar source read and comparison read on each operation. First population and changed values use bulk writes. Unchanged rows do not write. A name edit does not cause a contact-decision write.
- `WorkspaceVisit` stores source appointment comparison fields. Appointment pages refresh the selected week. Patient detail refreshes recent history, future scheduled visits, and linked candidates. Follow-up queues refresh active ordinary case appointments. `SourceComparison` serializes each kind of refresh with a database row lock, reconciles changed records in batches, and removes records that left the refreshed scope. Source reads and comparison maintenance occur inside that refresh transaction. These are operational comparisons; a GET does not create messages, decisions, or staff actions.
- Workspace filters use relationships to current revision decisions and open reviews. `ReviewAppointment` makes candidate membership queryable without array SQL. `FollowUp` maintains these links when candidates change; the migration backfills existing candidates. `WorkspaceFollowUp` owns queue scopes. Its payload predicate uses the same resolved/source-revision rules on preloaded data to avoid per-row queries. Board checks compare row queues with full-scope totals after source changes and deletions.
- A reminder run owns one clinic transaction. It checks that the replica has clinic visits, examines current scheduled visits in pages of 200, and checks the current revision, local time, and contact directory before writing. Messages are the fake dispatch ledger. The transaction commits the attempts, follow-up changes and successful-sync timestamp together. The attempt uniqueness key is clinic, appointment, revision and step.
- A patient event owns a clinic transaction for its audit message, confirmation, SMS opt-out or review case. A supplied outbound ID belongs to the selected patient and channel. Automatic confirmation also requires its revision and recipient to match the current scheduled visit and contact policy. A clinic and event reference identify a replay.
- Staff saves own clinic transactions for current task state, visit updates, responsibility, and audit records. The client preserves the draft and same save reference after a rejected or uncertain request. Patient contact writes keep raw PMS values and local verification history separately.
- Date ranges and filters execute in PostgreSQL. Interactive lists have stable order and explicit limits. Appointment payloads load review IDs for the displayed rows instead of instantiating every review. Leadership reads and groups raw source outcomes directly, without refreshing workspace comparisons, and serializes clinic totals only.

```mermaid
stateDiagram-v2
  [*] --> Unconfirmed: Scheduled source revision
  Unconfirmed --> Confirmed: Eligible YES or documented staff confirmation
  Unconfirmed --> Review: NO, ambiguous, shared, late or stale reply
  Confirmed --> Review: Later reply requires review while confirmation remains
  Review --> Confirmed: Staff confirms a current linked visit
  Review --> Unconfirmed: Staff resolves case without changing the visit
  Unconfirmed --> OutreachStopped: Staff records cancel or reschedule
  Confirmed --> OutreachStopped: Staff records cancel or reschedule
  OutreachStopped --> Unconfirmed: PMS supplies a new scheduled revision
  Confirmed --> Unconfirmed: PMS supplies a new scheduled revision
```

Review and confirmation can coexist. Completion is read separately from the PMS. An SMS opt-out survives source edits and applies to the clinic's patient and normalized destination. PMS revision fingerprints conservatively include the source update timestamp, so a routine edit can require a new confirmation cycle. Source replication lag still determines how current the observed data can be.
