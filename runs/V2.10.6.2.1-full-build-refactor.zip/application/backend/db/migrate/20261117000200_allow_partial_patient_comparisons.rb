class AllowPartialPatientComparisons < ActiveRecord::Migration[8.1]
  def change
    change_column_null :patient_searches, :first_last, true
    change_column_null :patient_searches, :last_name, true
  end
end
