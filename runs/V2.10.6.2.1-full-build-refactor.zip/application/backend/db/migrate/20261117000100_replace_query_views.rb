class ReplaceQueryViews < ActiveRecord::Migration[8.1]
  def up
    execute "DROP VIEW workspace_visits, workspace_follow_ups, pms.patient_search, pms.directory, pms.visits"
    execute "DROP INDEX pms.replica_patient_sms, pms.replica_patient_email, pms.replica_patient_name, pms.replica_patients_first_last, pms.replica_patients_last_name"
    execute "DROP FUNCTION pms.sms_key(text), pms.email_key(text)"

    create_table :source_comparisons, id: :string
    comparison = Class.new(ActiveRecord::Base) { self.table_name = "source_comparisons" }
    comparison.insert_all!([ { id: "patients" }, { id: "appointments" } ])

    create_table :patient_searches, id: :bigint do |t|
      t.text :first_last, collation: "C", null: false
      t.text :last_name, collation: "C", null: false
      t.text :sms_key
      t.text :email_key
      t.index :first_last
      t.index :last_name
      t.index :sms_key
      t.index :email_key
    end

    create_table :workspace_visits, id: :bigint do |t|
      t.bigint :clinic_id, null: false
      t.bigint :patient_id, null: false
      t.text :provider_name
      t.timestamp :start_at, null: false
      t.integer :length_minutes
      t.text :status, null: false
      t.string :revision, null: false
      t.date :visit_date, null: false
      t.index [ :clinic_id, :start_at, :id ]
      t.index [ :clinic_id, :patient_id, :start_at ]
      t.index [ :clinic_id, :id, :revision ], unique: true
    end

    create_table :review_appointments do |t|
      t.references :follow_up, null: false, foreign_key: { on_delete: :cascade }
      t.bigint :site_id, null: false
      t.bigint :appointment_id, null: false
      t.index [ :site_id, :appointment_id, :follow_up_id ], unique: true
    end
    task = Class.new(ActiveRecord::Base) { self.table_name = "follow_ups" }
    link = Class.new(ActiveRecord::Base) { self.table_name = "review_appointments" }
    task.where(issue: "reply_review").find_in_batches do |tasks|
      rows = tasks.flat_map do |entry|
        entry.candidate_ids.uniq.map { |id| { follow_up_id: entry.id, site_id: entry.site_id, appointment_id: id } }
      end
      link.insert_all!(rows) if rows.any?
    end
  end

  def down
    raise ActiveRecord::IrreversibleMigration, "The Ruby comparison owners replace the query views."
  end
end
