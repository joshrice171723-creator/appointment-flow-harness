class StaffFollowUp
  ACTIONS = %w[attempted confirmed canceled rescheduled resolved].freeze

  def initialize(site, staff, now: Time.current)
    @site = site
    @staff = staff
    @now = now
  end

  def claim(id)
    @site.with_lock do
      task = available_task(id)
      raise WorkflowRejection, "This item is assigned to another staff member." if task.staff_member_id && task.staff_member_id != @staff.id

      task.update!(staff_member: @staff)
      task
    end
  end

  def record(id, outcome:, note:, event_key:, targets:)
    note = note.to_s.strip
    validate_input(outcome, note, event_key)
    @site.with_lock do
      existing = @site.staff_actions.find_by(event_key:)
      if existing
        verify_replay(existing, id, outcome, note, targets)
        next existing
      end

      task = available_task(id)
      raise WorkflowRejection, "This item is assigned to another staff member." if task.staff_member_id && task.staff_member_id != @staff.id

      visits = select_visits(task, outcome, targets)
      update_visits(visits, outcome)
      task.update!(staff_member: @staff, resolved_at: outcome == "attempted" ? nil : @now)
      @site.staff_actions.create!(follow_up: task, patient_id: task.patient_id, staff_member: @staff,
        action: outcome, note:, event_key:, created_at: @now, details: { targets: })
    end
  end

  private

  def validate_input(outcome, note, event_key)
    raise WorkflowRejection, "Choose a follow-up outcome." unless ACTIONS.include?(outcome)
    raise WorkflowRejection, "Enter a note of 1 to 500 characters." unless note.length.in?(1..500)
    raise WorkflowRejection, "A save reference is required." unless event_key.is_a?(String) && event_key.length.in?(1..80)
  end

  def verify_replay(existing, id, outcome, note, targets)
    return if existing.follow_up_id.to_s == id.to_s && existing.staff_member_id == @staff.id &&
      existing.action == outcome && existing.note == note && existing.details["targets"] == targets

    raise WorkflowRejection, "That save reference is already in use."
  end

  def available_task(id)
    task = @site.follow_ups.find(id)
    scope = WorkspaceVisit.where(clinic_id: @site.id, id: task.appointment_id)
    WorkspaceVisit.refresh(@site.visits.where(id: task.appointment_id), scope:)
    view = WorkspaceFollowUp.find(task.id)
    raise WorkflowRejection, "This item is resolved. Reload the patient to see the current work." if view.queue == "resolved"

    task
  end

  def select_visits(task, outcome, targets)
    return [] if %w[attempted resolved].include?(outcome)

    allowed_ids = task.issue == "reply_review" ? task.candidate_ids : [ task.appointment_id ].compact
    raise WorkflowRejection, "Select an appointment to update." if targets.empty?
    raise WorkflowRejection, "Select only appointments linked to this item." unless (targets.keys.map(&:to_i) - allowed_ids).empty?

    visits = @site.visits.scheduled.where(id: targets.keys).to_a
    unless visits.size == targets.size && visits.all? { |visit| targets[visit.id.to_s] == visit.revision }
      raise WorkflowRejection, "An appointment changed. Reload before recording this outcome."
    end
    if outcome == "confirmed" && visits.any? { |visit| (@site.visit_instant(visit) || @now) <= @now }
      raise WorkflowRejection, "Only future appointments can be confirmed."
    end
    visits
  end

  def update_visits(visits, outcome)
    return if visits.empty?

    if outcome == "confirmed" && @site.visit_decisions.where([ :appointment_id, :revision ] => visits.map { |visit| [ visit.id, visit.revision ] })
        .where(outcome: %w[canceled rescheduled]).exists?
      raise WorkflowRejection, "Staff already recorded a schedule change for this appointment."
    end
    rows = visits.map { |visit| visit.identity.merge(outcome:) }
    @site.visit_decisions.upsert_all(rows, unique_by: %i[site_id appointment_id revision], returning: false)
    @site.follow_ups.where([ :appointment_id, :revision ] => visits.map { |visit| [ visit.id, visit.revision ] })
      .where(issue: "no_reply", resolved_at: nil).update_all(resolved_at: @now)
  end
end
