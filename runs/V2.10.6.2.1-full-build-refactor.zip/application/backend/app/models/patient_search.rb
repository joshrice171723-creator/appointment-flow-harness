class PatientSearch < ApplicationRecord
  def self.refresh
    SourceComparison.refresh("patients") do
      rows = PmsPatient.pluck(:id, :first_name, :last_name).map do |id, first, last|
        { id:, first_last: "#{first} #{last}".downcase(:ascii),
          last_name: last.downcase(:ascii) }
      end
      SourceComparison.reconcile(self, rows)
    end
  end

  def self.refresh_contacts
    SourceComparison.refresh("patients") do
      rows = PmsPatient.pluck(:id, :wireless_phone, :email).map do |id, phone, email|
        { id:, sms_key: PmsPatient.sms_key(phone), email_key: PmsPatient.email_key(email) }
      end
      SourceComparison.reconcile(self, rows)
    end
  end

  def self.starting_with(query)
    prefix = query.downcase...("#{query.downcase}\u{10ffff}")
    where(first_last: prefix).or(where(last_name: prefix))
  end
end
