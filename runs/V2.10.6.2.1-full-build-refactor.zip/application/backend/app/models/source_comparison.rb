class SourceComparison < ApplicationRecord
  # The replica has no patient change feed. Reconcile fresh authoritative values,
  # and write only changed comparisons. The row lock serializes local refreshes.
  def self.refresh(name)
    transaction do
      lock.find(name)
      yield
    end
  end

  def self.reconcile(model, rows, scope: model.all)
    columns = [ :id ] + ((rows.first&.keys || []) - [ :id ])
    stored = scope.pluck(*columns).map { |row| Array(row) }.index_by(&:first)
    changed = rows.reject { |row| stored[row.fetch(:id)] == row.values_at(*columns) }
    changed.each_slice(500) { |batch| model.upsert_all(batch, unique_by: :id, returning: false) }
    obsolete = stored.keys - rows.pluck(:id)
    scope.where(id: obsolete).delete_all if obsolete.any?
  end
end
