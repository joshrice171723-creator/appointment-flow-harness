class WorkspaceVisit < ApplicationRecord
  self.table_name = "workspace_visits"

  OUTCOMES = { "complete" => "completed", "broken" => "canceled", "unscheduled" => "rescheduled" }.freeze
  PAYLOAD_ASSOCIATIONS = %i[patient visit_decision].freeze

  belongs_to :patient, class_name: "PmsPatient"
  belongs_to :visit_decision, optional: true,
    foreign_key: %i[clinic_id id revision], primary_key: %i[site_id appointment_id revision]
  has_many :linked_reviews, -> { open_reviews }, class_name: "FollowUp",
    foreign_key: %i[site_id appointment_id revision], primary_key: %i[clinic_id id revision]
  has_many :review_appointments, foreign_key: %i[site_id appointment_id], primary_key: %i[clinic_id id]
  has_many :candidate_reviews, -> { open_reviews }, through: :review_appointments, source: :follow_up

  scope :scheduled, -> { where(status: "scheduled") }
  scope :confirmed, -> { where(id: joins(:visit_decision).where(visit_decisions: { outcome: "confirmed" }).select(:id)) }
  scope :unconfirmed, -> { where.missing(:visit_decision) }
  scope :available, -> { where(id: unconfirmed.select(:id)).or(where(id: confirmed.select(:id))) }
  scope :needing_review, -> {
    where(id: joins(:linked_reviews).select(:id)).or(where(id: joins(:candidate_reviews).select(:id)))
  }

  def self.on_days(first, last = first)
    from = Time.utc(first.year, first.month, first.day)
    through = Time.utc(last.year, last.month, last.day)
    where(start_at: from...(through + 1.day))
  end

  def self.refresh(source, scope: all)
    SourceComparison.refresh("appointments") do
      rows = source.select(*PmsVisit::READ_COLUMNS).map do |visit|
        visit.attributes.symbolize_keys.except(:updated_at).merge(revision: visit.revision, visit_date: visit.visit_date)
      end
      SourceComparison.reconcile(self, rows, scope:)
    end
  end

  def self.refresh_tasks(site, tasks: site.follow_ups)
    ids = tasks.where(resolved_at: nil).where.not(issue: "reply_review").select(:appointment_id)
    refresh(site.visits.where(id: ids), scope: where(clinic_id: site.id, id: ids))
  end

  def decision
    visit_decision&.outcome
  end

  def reply_review
    self.class.where(id: id).needing_review.exists?
  end

  def self.payloads(visits)
    rows = visits.to_a
    review_ids = where(id: rows.map(&:id)).needing_review.pluck(:id).to_set
    rows.map { |visit| visit.as_payload(reply_review: review_ids.include?(visit.id)) }
  end

  def as_payload(reply_review: self.reply_review)
    {
      id: id, revision:, patient_id:, patient: patient.full_name, start_at: start_at.strftime("%Y-%m-%dT%H:%M:%S"), provider: provider_name,
      minutes: length_minutes, confirmation: decision || "unconfirmed", reply_review:,
      outcome: OUTCOMES.fetch(status, "unknown")
    }
  end
end
