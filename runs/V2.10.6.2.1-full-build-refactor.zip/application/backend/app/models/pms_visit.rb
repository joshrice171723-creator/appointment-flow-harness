class PmsVisit < PmsRecord
  self.table_name = "pms.appointments"
  self.primary_key = :id

  READ_COLUMNS = %i[id clinic_id patient_id provider_name start_at length_minutes status updated_at].freeze

  belongs_to :patient, class_name: "PmsPatient"
  scope :scheduled, -> { where(status: "scheduled") }

  def self.on_days(first, last = first)
    from = Time.utc(first.year, first.month, first.day)
    through = Time.utc(last.year, last.month, last.day) + 1.day
    where(start_at: from...through)
  end

  def revision
    # Keep the PostgreSQL concat_ws fingerprint used by existing audit records.
    values = [ clinic_id, patient_id, fingerprint_time(start_at), fingerprint_time(updated_at) ]
    Digest::MD5.hexdigest(values.compact.join("|"))
  end

  def visit_date
    start_at.to_date
  end

  def identity
    { appointment_id: id, revision: revision }
  end

  def wall_time
    start_at.strftime("%Y-%m-%dT%H:%M:%S")
  end

  private

  def fingerprint_time(value)
    return unless value

    fraction = format("%06d", value.usec).sub(/0+\z/, "")
    value.strftime("%Y-%m-%d %H:%M:%S") + (fraction.empty? ? "" : ".#{fraction}")
  end
end
