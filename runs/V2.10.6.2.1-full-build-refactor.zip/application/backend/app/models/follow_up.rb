class FollowUp < ApplicationRecord
  ISSUES = %w[no_reply contact_hold delivery_failed reply_review].freeze
  SMS_OPT_OUT_REVIEW = "The text may be an opt-out request. Review it before sending more texts."

  belongs_to :site
  belongs_to :message, optional: true
  belongs_to :staff_member, optional: true
  has_many :review_appointments, dependent: :delete_all

  scope :open_reviews, -> { where(issue: "reply_review", resolved_at: nil) }

  after_save :sync_review_appointments, if: :saved_change_to_candidate_ids?

  private

  def sync_review_appointments
    previous_ids = candidate_ids_before_last_save || []
    removed_ids = previous_ids - candidate_ids
    review_appointments.where(appointment_id: removed_ids).delete_all if removed_ids.any?
    rows = (candidate_ids - previous_ids).map { |id| { site_id:, appointment_id: id } }
    review_appointments.insert_all!(rows, returning: false) if rows.any?
  end
end
