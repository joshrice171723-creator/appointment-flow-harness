class PmsPatient < PmsRecord
  self.table_name = "pms.patients"
  self.primary_key = :id

  CONTACT_FIELDS = %w[birthdate wireless_phone email preferred_language].freeze

  def full_name
    "#{first_name} #{last_name}"
  end

  def sms_key
    self.class.sms_key(wireless_phone)
  end

  def self.sms_key(value)
    # Source matching remains conservative even when the raw contact is invalid.
    value&.gsub(/[^0-9]/, "")&.sub(/\A1(?=\d{10}\z)/, "")
  end

  def email_key
    self.class.email_key(email)
  end

  def self.email_key(value)
    value&.strip&.downcase(:ascii)
  end
end
