class WorkspaceFollowUp < FollowUp
  self.table_name = "follow_ups"
  self.primary_key = :id

  QUEUES = %w[needs_attention in_progress resolved].freeze

  belongs_to :patient, class_name: "PmsPatient"
  belongs_to :staff_member, optional: true
  belongs_to :message, optional: true
  belongs_to :source_visit, class_name: "WorkspaceVisit", optional: true,
    foreign_key: %i[site_id appointment_id], primary_key: %i[clinic_id id]
  belongs_to :current_visit, class_name: "WorkspaceVisit", optional: true,
    foreign_key: %i[site_id appointment_id revision], primary_key: %i[clinic_id id revision]

  scope :resolved, -> {
    ended = joins(:source_visit).merge(WorkspaceVisit.where.not(status: "scheduled"))
    revised = where.not(revision: nil).where.associated(:source_visit).where.missing(:current_visit)
    stale = where.not(issue: "reply_review").where(id: ended.select(:id)).or(
      where.not(issue: "reply_review").where(id: revised.select(:id)))
    where.not(resolved_at: nil).or(where(id: stale.select(:id)))
  }
  scope :active, -> { where.not(id: resolved.select(:id)) }

  def self.in_queue(queue)
    case queue
    when "resolved" then resolved
    when "needs_attention" then active.where(staff_member_id: nil)
    when "in_progress" then active.where.not(staff_member_id: nil)
    else active
    end
  end

  def queue
    return "resolved" if resolved_at

    stale = issue != "reply_review" && source_visit &&
      (source_visit.status != "scheduled" || (revision && source_visit.revision != revision))
    return "resolved" if stale

    staff_member_id ? "in_progress" : "needs_attention"
  end

  def as_payload
    {
      id: id, patient_id:, patient: patient.full_name, issue:, reason:, queue:, staff_id: staff_member_id,
      assignee: staff_member&.name, appointment_id:, revision:, created_at:
    }
  end
end
