class ReviewAppointment < ApplicationRecord
  belongs_to :follow_up
end
