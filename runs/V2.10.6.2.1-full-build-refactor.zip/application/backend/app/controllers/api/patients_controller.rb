module Api
  class PatientsController < StaffController
    def show
      patient = @site.patients.find(params[:id])
      now = @site.local_time(Time.current)
      tasks = WorkspaceFollowUp.where(site_id: @site.id, patient_id: patient.id).order(created_at: :desc, id: :desc)
        .limit(30).preload(:patient, :staff_member, :message).to_a
      visit_ids = refresh_visits(patient, tasks, now)
      ActiveRecord::Associations::Preloader.new(records: tasks, associations: :source_visit).call
      visits = WorkspaceVisit.where(clinic_id: @site.id, patient_id: patient.id, id: visit_ids)
        .preload(*WorkspaceVisit::PAYLOAD_ASSOCIATIONS)
      upcoming = visits.scheduled.where(start_at: Time.utc(now.year, now.month, now.day, now.hour, now.min, now.sec)..)
        .available.order(:start_at, :id).first
      render json: site_metadata.merge(patient: { id: patient.id, name: patient.full_name },
        contacts: contacts(patient), next_visit: upcoming&.as_payload,
        visits: WorkspaceVisit.payloads(visits.order(start_at: :desc, id: :desc).limit(30)),
        tasks: task_payloads(tasks), activity: activity(patient.id))
    end

    private

    def refresh_visits(patient, tasks, now)
      linked_ids = tasks.flat_map { |task| task.candidate_ids.presence || [ task.appointment_id ].compact }.uniq
      patient_visits = @site.visits.where(patient_id: patient.id)
      recent_ids = patient_visits.order(start_at: :desc, id: :desc).limit(30).pluck(:id)
      wall_now = Time.utc(now.year, now.month, now.day, now.hour, now.min, now.sec)
      future_ids = patient_visits.scheduled.where(start_at: wall_now..).pluck(:id)
      visit_ids = (recent_ids + future_ids + linked_ids).uniq
      source = @site.visits.where(id: visit_ids)
      clinic_mirror = WorkspaceVisit.where(clinic_id: @site.id)
      scope = clinic_mirror.where(id: recent_ids)
        .or(clinic_mirror.where(patient_id: patient.id, status: "scheduled", start_at: wall_now..))
        .or(clinic_mirror.where(id: linked_ids))
      WorkspaceVisit.refresh(source, scope:)
      visit_ids
    end

    def contacts(patient)
      verifications = @site.contact_verifications.where(patient_id: patient.id).preload(:staff_member).index_by(&:field)
      facts = ContactPolicy.facts(patient, verifications)
      PmsPatient::CONTACT_FIELDS.map do |field|
        raw = patient[field]&.to_s
        verified = verifications[field]
        { field:, source: raw, value: facts.values[field], verified_value: verified&.value,
          status: !verified ? "unverified" : (raw == verified.source_value ? "verified" : "conflict"),
          verified_by: verified&.staff_member&.name, verified_at: verified&.updated_at }
      end
    end

    def task_payloads(tasks)
      entries = tasks.to_a
      ids = entries.flat_map { |task| task.candidate_ids.presence || [ task.appointment_id ].compact }.uniq
      candidates = WorkspaceVisit.where(clinic_id: @site.id, id: ids)
      visits = candidates.preload(*WorkspaceVisit::PAYLOAD_ASSOCIATIONS).index_by(&:id)
      payloads = WorkspaceVisit.payloads(visits.values).index_by { |payload| payload.fetch(:id) }
      entries.map do |task|
        candidates = task.candidate_ids.presence || [ task.appointment_id ].compact
        task.as_payload.merge(candidates: candidates.filter_map { |id| payloads[id] }, reply: task.message&.body)
      end
    end

    def activity(patient_id)
      @site.staff_actions.where(patient_id:).order(created_at: :desc, id: :desc).limit(30).preload(:staff_member).map do |event|
        { id: event.id, action: event.action, note: event.note, staff: event.staff_member.name, created_at: event.created_at }
      end
    end
  end
end
