module Api
  class AppointmentsController < StaffController
    PAGE_SIZE = 25

    def index
      date = iso_date(params[:date], @site.local_time(Time.current).to_date)
      week_start = date.beginning_of_week
      clinic_visits = WorkspaceVisit.where(clinic_id: @site.id)
      WorkspaceVisit.refresh(@site.visits.on_days(week_start, week_start + 6),
        scope: clinic_visits.on_days(week_start, week_start + 6))
      day_visits = clinic_visits.on_days(date)
      visible_visits = filter(day_visits)
      rows = visible_visits.order(:start_at, :id).offset((page - 1) * PAGE_SIZE).limit(PAGE_SIZE + 1)
        .preload(*WorkspaceVisit::PAYLOAD_ASSOCIATIONS).to_a
      render json: site_metadata.merge(date:, calendar: clinic_visits.on_days(week_start, week_start + 6).group(:visit_date).count,
        totals: totals(day_visits), rows: WorkspaceVisit.payloads(rows.first(PAGE_SIZE)), page:, more: rows.size > PAGE_SIZE)
    end

    private

    def filter(visits)
      case params[:filter]
      when "confirmed" then visits.confirmed
      when "unconfirmed" then visits.unconfirmed
      when "review" then visits.needing_review
      else visits
      end
    end

    def totals(visits)
      counts = visits.left_joins(:visit_decision).group("visit_decisions.outcome").count
      {
        all: counts.values.sum,
        confirmed: counts.fetch("confirmed", 0),
        unconfirmed: counts.fetch(nil, 0),
        review: visits.needing_review.count
      }
    end
  end
end
