module Api
  class InboxesController < SiteController
    def index
      search = params[:q].to_s.strip.first(80)
      patients = @site.patients
      if search.present?
        PatientSearch.refresh
        patients = patients.where(id: PatientSearch.starting_with(search).select(:id))
      end
      rows = patients.order(:last_name, :first_name, :id).offset((page - 1) * 50).limit(51)
        .pluck(:id, :first_name, :last_name)
      render json: { patients: rows.first(50).map { |id, first, last| { id:, name: "#{first} #{last}" } }, more: rows.size > 50, page: }
    end

    def show
      patient = @site.patients.find(params[:id])
      channel = params.fetch(:channel, "sms")
      raise WorkflowRejection, "Choose Text messages or Email." unless Message::CHANNELS.include?(channel)

      messages = @site.messages.where(patient_id: patient.id, channel:).order(occurred_at: :desc, id: :desc)
        .offset((page - 1) * 40).limit(41)
        .pluck(:id, :body, :direction, :result, :occurred_at, :in_reply_to_id)
      history = messages.first(40).reverse.map do |id, body, direction, result, occurred_at, in_reply_to|
        { id:, body:, direction:, result:, occurred_at:, in_reply_to: }
      end
      render json: { messages: history, timezone: @site.timezone, page:, more: messages.size > 40 }
    end
  end
end
