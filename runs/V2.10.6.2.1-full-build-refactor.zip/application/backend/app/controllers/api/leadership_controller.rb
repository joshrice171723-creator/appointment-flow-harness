module Api
  class LeadershipController < ApplicationController
    def show
      month = reporting_month
      sites = Site.includes(:clinic).order(:id)
      counts = outcomes(month)
      previous = outcomes(month.prev_month)
      activity = activity_counts(month)
      render json: { month: month.strftime("%Y-%m"), clinics: sites.map { |site| clinic_metrics(site, counts, previous, activity) } }
    end

    private

    def reporting_month
      value = params[:month].presence || Date.current.strftime("%Y-%m")
      raise WorkflowRejection, "Choose a valid reporting month." unless value.to_s.match?(/\A\d{4}-\d{2}\z/)

      Date.iso8601("#{value}-01")
    rescue Date::Error
      raise WorkflowRejection, "Choose a valid reporting month."
    end

    def outcomes(month)
      PmsVisit.on_days(month, month.end_of_month).group(:clinic_id, :status).count
        .group_by { |(clinic_id, _status), _count| clinic_id }
    end

    def activity_counts(month)
      next_month = month.next_month
      range = Time.utc(month.year, month.month)...Time.utc(next_month.year, next_month.month)
      {
        messages: Message.outbound.where(occurred_at: range).group(:site_id, :result).count,
        holds: FollowUp.where(created_at: range, issue: "contact_hold").group(:site_id).count,
        follow_ups: StaffAction.where(created_at: range).where.not(action: "verified").group(:site_id, :action).count
      }
    end

    def clinic_metrics(site, counts, previous, activity)
      {
        id: site.id, name: site.clinic.name, outcomes: outcome_metrics(counts, site.id),
        previous: outcome_metrics(previous, site.id),
        delivered: activity[:messages].fetch([ site.id, "delivered" ], 0),
        failed: activity[:messages].fetch([ site.id, "failed" ], 0),
        holds: activity[:holds].fetch(site.id, 0),
        follow_ups: StaffFollowUp::ACTIONS.to_h { |action| [ action, activity[:follow_ups].fetch([ site.id, action ], 0) ] }
      }
    end

    def outcome_metrics(counts, clinic_id)
      totals = { completed: 0, rescheduled: 0, canceled: 0, unknown: 0 }
      counts.fetch(clinic_id, []).each do |(_id, status), count|
        totals[WorkspaceVisit::OUTCOMES.fetch(status, "unknown").to_sym] += count
      end
      recorded = totals.values.sum
      totals.merge(recorded:, completion_rate: recorded.zero? ? nil : totals[:completed].fdiv(recorded))
    end
  end
end
