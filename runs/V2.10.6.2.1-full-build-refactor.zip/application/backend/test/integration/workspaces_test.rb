require "test_helper"
require Rails.root.join("../docs/ai-harness/quality/rails_workload_probe")

class WorkspacesTest < ActionDispatch::IntegrationTest
  setup do
    travel_to DEMO_NOW
    @site = create_site
    @staff = @site.staff_members.create!(name: "Taylor Morgan")
    @other = create_site(id: 2, name: "Phoenix", timezone: "America/Phoenix")
    @other_staff = @other.staff_members.create!(name: "Casey Brooks")
    @patient = create_patient(first_name: "Demo", last_name: "Lane")
    @other_patient = create_patient(first_name: "Other", last_name: "Person", wireless_phone: "602-555-0100", email: "other@example.test")
    @visit = create_visit(@site, @patient)
    @other_visit = create_visit(@other, @other_patient)
    @headers = { "X-Demo-Staff" => @staff.id.to_s }
    @root = "/api/sites/#{@site.id}"
  end

  test "normal reminder and email reply endpoints change current appointment and deduplicate a replay" do
    ReplicaFixtures.write { @patient.update!(wireless_phone: nil) }
    post "#{@root}/reminder_runs", headers: @headers
    assert_response :created
    assert_equal 1, response.parsed_body.fetch("delivered")

    get "#{@root}/inboxes/#{@patient.id}", params: { channel: "email" }
    assert_response :success
    sent = response.parsed_body.fetch("messages").sole
    assert_equal "delivered", sent.fetch("result")
    refute_includes sent.to_json, @patient.email

    body = { reply: { channel: "email", body: "YES", event_key: "incoming", message_id: sent.fetch("id") } }
    2.times do
      post "#{@root}/inboxes/#{@patient.id}/replies", params: body, as: :json
      assert_response :created
      assert_equal "confirmed", response.parsed_body.fetch("result")
    end
    assert_equal 1, @site.messages.where(direction: "inbound").count

    get "#{@root}/appointments", params: { date: "2026-11-19", filter: "confirmed" }, headers: @headers
    assert_response :success
    assert_equal [ @visit.id ], response.parsed_body.fetch("rows").pluck("id")
    assert_equal "unknown", response.parsed_body.fetch("rows").sole.fetch("outcome")
  end

  test "foreign clinic IDs and staff assignments are rejected by staff and patient endpoints" do
    travel_to DEMO_NOW + 6.days
    ReminderRun.new(@other).call
    other_task = @other.follow_ups.sole
    assert_nil other_task.staff_member_id
    get "#{@root}/patients/#{@other_patient.id}", headers: @headers
    assert_response :not_found
    get "#{@root}/inboxes/#{@other_patient.id}"
    assert_response :not_found
    post "#{@root}/inboxes/#{@other_patient.id}/replies", params: { reply: { channel: "sms", body: "YES", event_key: "wrong" } }, as: :json
    assert_response :not_found
    patch "#{@root}/follow_ups/#{other_task.id}", headers: @headers
    assert_response :not_found
    get "/api/sites/#{@other.id}/appointments", headers: @headers
    assert_response :not_found
    get "/api/sites/#{@other.id}/appointments", params: { date: "2026-11-19" }, headers: { "X-Demo-Staff" => @other_staff.id.to_s }
    assert_response :success
    assert_equal [ @other_visit.id ], response.parsed_body.fetch("rows").pluck("id")
    assert_nil other_task.reload.staff_member_id
    assert_empty @site.messages
  end

  test "claim, attempted contact, stale write rejection and staff confirmation preserve exact local state" do
    travel_to DEMO_NOW + 6.days
    ReminderRun.new(@site).call
    task = @site.follow_ups.sole
    patch "#{@root}/follow_ups/#{task.id}", headers: @headers
    assert_response :success
    assert_equal @staff.id, task.reload.staff_member_id

    send_staff_action(task, "attempted", "", "invalid")
    assert_response :unprocessable_entity
    assert_empty @site.staff_actions
    assert_nil task.reload.resolved_at

    2.times do
      send_staff_action(task, "attempted", "Left a message.", "attempt")
      assert_response :created
    end
    assert_nil task.reload.resolved_at
    assert_equal 1, @site.staff_actions.count

    send_staff_action(task, "confirmed", "Reached the patient.", "stale", revision: "stale")
    assert_response :unprocessable_entity
    assert_empty @site.visit_decisions
    assert_nil task.reload.resolved_at

    send_staff_action(task, "confirmed", "Reached the patient.", "confirmation", revision: task.revision)
    assert_response :created
    assert_equal "confirmed", @site.visit_decisions.sole.outcome
    assert_equal Time.current, task.reload.resolved_at
    assert_equal "scheduled", @visit.reload.status
  end

  test "the board searches within a clinic and queue filtering preserves full totals" do
    travel_to DEMO_NOW + 6.days
    ReminderRun.new(@site).call
    ReminderRun.new(@other).call
    task = @site.follow_ups.sole
    get "#{@root}/follow_ups", params: { q: "lan", queue: "active", issue: "no_reply" }, headers: @headers
    assert_response :success
    assert_equal [ task.id ], response.parsed_body.fetch("rows").pluck("id")
    assert_equal({ "needs_attention" => 1 }, response.parsed_body.fetch("totals"))
    get "#{@root}/follow_ups", params: { q: "other", queue: "active" }, headers: @headers
    assert_response :success
    assert_empty response.parsed_body.fetch("rows")
    assert_equal({ "needs_attention" => 1 }, response.parsed_body.fetch("totals"))
  end

  test "a failed staff audit write rolls back confirmation and case resolution" do
    travel_to DEMO_NOW + 6.days
    ReminderRun.new(@site).call
    task = @site.follow_ups.sole
    fail_audit = lambda do |event|
      raise "injected audit failure" if event.payload[:sql].start_with?('INSERT INTO "staff_actions"')
    end
    ActiveSupport::Notifications.subscribed(fail_audit, "sql.active_record") do
      error = assert_raises(RuntimeError) do
        send_staff_action(task, "confirmed", "Reached the patient.", "rolled-back", revision: task.revision)
      end
      assert_equal "injected audit failure", error.message
    end
    assert_empty @site.visit_decisions
    assert_empty @site.staff_actions
    assert_nil task.reload.resolved_at
    assert_nil task.staff_member_id
  end

  test "contact verification can unblock outreach, preserves raw PMS data and detects a later conflict" do
    ReplicaFixtures.write { @patient.update!(birthdate: nil) }
    ReminderRun.new(@site).call
    assert_empty @site.messages
    assert_equal "contact_hold", @site.follow_ups.sole.issue

    verification = { field: "birthdate", value: "1980-01-20", expected_source: nil, event_key: "verify" }
    2.times do
      patch "#{@root}/patients/#{@patient.id}/contact_verification", params: { verification: }, headers: @headers, as: :json
      assert_response :success
    end
    assert_equal 1, @site.staff_actions.count
    assert_nil @patient.reload.birthdate
    assert_equal 1, ReminderRun.new(@site).call.fetch(:delivered)
    assert_not_nil @site.follow_ups.sole.resolved_at

    ReplicaFixtures.write { @patient.update!(birthdate: "2016-01-20") }
    get "#{@root}/patients/#{@patient.id}", headers: @headers
    assert_response :success
    fact = response.parsed_body.fetch("contacts").find { |entry| entry.fetch("field") == "birthdate" }
    assert_equal [ "2016-01-20", "1980-01-20", "conflict" ], fact.values_at("source", "verified_value", "status")
    assert_no_difference -> { @site.messages.count } do
      ReminderRun.new(@site, now: DEMO_NOW + 4.days).call
    end
    assert_nil @site.follow_ups.sole.reload.resolved_at
    assert_match "differ", @site.follow_ups.sole.reason
  end

  test "a patient turning 18 before the visit waits until their birthday for outreach" do
    ReplicaFixtures.write { @patient.update!(birthdate: "2008-11-13") }
    post "#{@root}/reminder_runs", headers: @headers
    assert_response :created
    assert_equal 0, response.parsed_body.fetch("delivered")
    assert_empty @site.messages
    assert_match "guardian", @site.follow_ups.sole.reason

    travel_to DEMO_NOW + 1.day
    post "#{@root}/reminder_runs", headers: @headers
    assert_response :created
    assert_equal 1, response.parsed_body.fetch("delivered")
    assert_equal @visit.id, @site.messages.outbound.sole.appointment_id
  end

  test "email safety sees matching source addresses with tabs outside the clinic and current view" do
    ReplicaFixtures.write { @patient.update!(wireless_phone: nil) }
    post "#{@root}/reminder_runs", headers: @headers
    assert_equal 1, response.parsed_body.fetch("delivered")
    sent = @site.messages.outbound.sole

    # The authoritative match is absent from Austin's patient and appointment lists.
    ReplicaFixtures.write { @other_patient.update!(email: "\tDEMO@EXAMPLE.TEST\r\n") }
    post "#{@root}/inboxes/#{@patient.id}/replies", params: {
      reply: { channel: "email", body: "YES", event_key: "shared", message_id: sent.id }
    }, as: :json
    assert_response :created
    assert_equal "review", response.parsed_body.fetch("result")
    assert_empty @site.visit_decisions
    assert_equal [ @visit.id ], @site.follow_ups.find_by!(issue: "reply_review").candidate_ids

    travel_to DEMO_NOW + 4.days
    post "#{@root}/reminder_runs", headers: @headers
    assert_response :created
    assert_equal 0, response.parsed_body.fetch("delivered")
    assert_equal sent.id, @site.messages.outbound.sole.id
    assert_match "shared", @site.follow_ups.find_by!(issue: "contact_hold").reason
  end

  test "leadership exposes clinic aggregates and derives completion only from source status" do
    create_visit(@site, @patient, status: "complete")
    @site.visit_decisions.create!(**PmsVisit.find(@visit.id).identity, outcome: "confirmed")
    ReminderRun.new(@other).call
    get "/api/leadership", params: { month: "2026-11" }
    assert_response :success
    clinics = response.parsed_body.fetch("clinics")
    assert_equal [ @site.id, @other.id ], clinics.pluck("id")
    assert_equal %w[canceled completed completion_rate recorded rescheduled unknown], clinics.first.fetch("outcomes").keys.sort
    assert_equal [ 1, 2, 1, 0.5 ], clinics.first.fetch("outcomes").values_at("completed", "recorded", "unknown", "completion_rate")
    %w[patient birthdate email phone recipient body procedure_note appointment_id].each do |key|
      refute_includes response.body, %("#{key}")
    end
    [ @patient.first_name, @other_patient.last_name, @patient.wireless_phone ].each do |value|
      refute_includes response.body, value
    end
  end

  test "appointment endpoint keeps day and calendar totals while limiting and ordering the selected page" do
    ReplicaFixtures.write do
      ReplicaFixtures::Appointment.insert_all!(28.times.map do
        { clinic_id: @site.id, patient_id: @patient.id, start_at: @visit.start_at, status: "scheduled" }
      end)
    end
    params = { date: "2026-11-19" }
    full_ids = @site.visits.scheduled.order(:start_at, :id).pluck(:id)
    get "#{@root}/appointments", params:, headers: @headers
    assert_response :success
    assert_equal full_ids.first(25), response.parsed_body.fetch("rows").pluck("id")
    assert_equal 29, response.parsed_body.fetch("totals").fetch("all")
    assert_equal 29, response.parsed_body.fetch("calendar").fetch("2026-11-19")
    assert response.parsed_body.fetch("more")
    get "#{@root}/appointments", params: { **params, page: 2 }, headers: @headers
    assert_response :success
    assert_equal full_ids.drop(25), response.parsed_body.fetch("rows").pluck("id")
    refute response.parsed_body.fetch("more")
  end

  test "whole appointment read keeps the same payload and workload when clinic history grows" do
    path = "#{@root}/appointments?date=2026-11-19"
    get path, headers: @headers
    body = response.body
    _, small = measure_appointments(path)
    ReplicaFixtures.write do
      ReplicaFixtures::Appointment.insert_all!(500.times.map do
        { clinic_id: @site.id, patient_id: @patient.id, start_at: "2026-10-19 09:00", status: "scheduled" }
      end)
    end
    assert_equal 501, @site.visits.count
    _, large = measure_appointments(path)
    assert_response :success
    assert_equal body, response.body
    assert_equal [ @visit.id ], response.parsed_body.fetch("rows").pluck("id")
    %i[database_statements read_rows instantiated_records direct_write_statements].each do |metric|
      assert_equal small[metric], large[metric], metric.to_s
    end
    puts "Appointments #{body.bytesize} bytes; small: #{small}; large: #{large}"
  end

  private

  def measure_appointments(path)
    ActiveRecord::Base.with_connection(&:clear_query_cache)
    RailsWorkloadProbe.measure { get path, headers: @headers }
  end

  def send_staff_action(task, outcome, note, event_key, revision: nil)
    visits = revision ? [ { id: @visit.id, revision: } ] : []
    post "#{@root}/follow_ups/#{task.id}/staff_actions", headers: @headers, as: :json,
      params: { action_record: { outcome:, note:, event_key:, visits: } }
  end
end
