require "test_helper"
require Rails.root.join("../docs/ai-harness/quality/rails_workload_probe")

class RefactorWorkloadTest < ActionDispatch::IntegrationTest
  setup do
    travel_to DEMO_NOW
    @site = create_site
    @staff = @site.staff_members.create!(name: "Demo Staff")
    @patient = create_patient
    @visit = create_visit(@site, @patient)
    @headers = { "X-Demo-Staff" => @staff.id.to_s }
    @root = "/api/sites/#{@site.id}"
  end

  test "complete appointment and reminder callers include first population and unrelated source growth" do
    measure("appointments_first") { get "#{@root}/appointments", params: { date: "2026-11-19" }, headers: @headers }
    assert_response :success
    expected_body = response.body
    expected_appointments = response.parsed_body.except("last_synced_at")
    assert_equal [ @visit.id ], response.parsed_body.fetch("rows").pluck("id")
    measure("appointments_repeat") { get "#{@root}/appointments", params: { date: "2026-11-19" }, headers: @headers }
    assert_equal expected_body, response.body
    print_plans("small") if ENV["CAPTURE_PLANS"] == "1"

    measure("reminders_first") { post "#{@root}/reminder_runs", headers: @headers }
    assert_response :created
    assert_equal({ "delivered" => 1, "failed" => 0, "follow_ups_created" => 0 }, response.parsed_body)
    sent = @site.messages.outbound.sole
    measure("reminders_repeat") { post "#{@root}/reminder_runs", headers: @headers }
    assert_response :created
    assert_equal 0, response.parsed_body.fetch("delivered")

    ReplicaFixtures.write do
      ReplicaFixtures::Patient.insert_all!(300.times.map do |index|
        { first_name: "Unrelated", last_name: "Patient #{index}", email: "unrelated#{index}@example.test" }
      end)
      ReplicaFixtures::Appointment.insert_all!(300.times.map do
        { clinic_id: @site.id, patient_id: @patient.id, start_at: "2025-01-01 10:00", status: "scheduled" }
      end)
    end
    assert_equal 301, PmsPatient.count
    assert_equal 301, @site.visits.count
    measure("appointments_grown") { get "#{@root}/appointments", params: { date: "2026-11-19" }, headers: @headers }
    assert_equal expected_appointments, response.parsed_body.except("last_synced_at")
    measure("reminders_grown_first") { post "#{@root}/reminder_runs", headers: @headers }
    assert_response :created
    assert_equal 0, response.parsed_body.fetch("delivered")
    measure("reminders_grown_repeat") { post "#{@root}/reminder_runs", headers: @headers }
    assert_equal [ sent.id ], @site.messages.outbound.pluck(:id)
    assert_empty @site.follow_ups
    print_plans("grown") if ENV["CAPTURE_PLANS"] == "1"
  end

  private

  def measure(label)
    ActiveRecord::Base.with_connection(&:clear_query_cache)
    _, metrics = RailsWorkloadProbe.measure { yield }
    puts({ workload: label, metrics:, response_bytes: response.body.bytesize,
      source_bytes: "unavailable" }.to_json)
  end

  def print_plans(label)
    ApplicationRecord.uncached { explain_relations(label) }
  end

  def explain_relations(label)
    puts "Plans: #{label}"
    date = Date.new(2026, 11, 19)
    puts @site.visits.on_days(date.beginning_of_week, date.end_of_week).explain(:analyze, :buffers).pluck(*PmsVisit::READ_COLUMNS)
    puts PmsPatient.all.explain(:analyze, :buffers).pluck(:id, :wireless_phone, :email)
    puts PatientSearch.all.explain(:analyze, :buffers).pluck(:id, :sms_key, :email_key)
    puts PatientSearch.where(sms_key: "5125550100").group(:sms_key).explain(:analyze, :buffers).count
    puts WorkspaceVisit.where(clinic_id: @site.id).on_days(date).order(:start_at, :id).limit(26)
      .explain(:analyze, :buffers).pluck(*WorkspaceVisit.column_names)
  end
end
