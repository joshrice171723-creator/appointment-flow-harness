require "test_helper"
require Rails.root.join("../docs/ai-harness/quality/rails_workload_probe")

class SourceComparisonsTest < ActionDispatch::IntegrationTest
  setup do
    travel_to DEMO_NOW
    @site = create_site
    @staff = @site.staff_members.create!(name: "Demo Staff")
    @patient = create_patient
    @visit = create_visit(@site, @patient)
    @root = "/api/sites/#{@site.id}"
    @headers = { "X-Demo-Staff" => @staff.id.to_s }
  end

  test "a source move clears the old week and preserves revision identity at the new date" do
    read_appointments
    old_revision = response.parsed_body.fetch("rows").sole.fetch("revision")
    @site.visit_decisions.create!(appointment_id: @visit.id, revision: old_revision, outcome: "confirmed")
    ReplicaFixtures.write { @visit.update!(start_at: "2026-12-01 14:00", updated_at: DEMO_NOW + 1.minute) }
    read_appointments
    assert_empty response.parsed_body.fetch("rows")
    assert_equal 0, response.parsed_body.fetch("totals").fetch("all")
    read_appointments(date: "2026-12-01")
    row = response.parsed_body.fetch("rows").sole
    assert_equal @visit.id, row.fetch("id")
    assert_not_equal old_revision, row.fetch("revision")
    assert_equal PmsVisit.find(@visit.id).revision, row.fetch("revision")
    assert_equal "unconfirmed", row.fetch("confirmation")
    ReplicaFixtures.write { @visit.destroy! }
    read_appointments(date: "2026-12-01")
    assert_empty response.parsed_body.fetch("rows")
    assert_not WorkspaceVisit.exists?(@visit.id)
  end

  test "candidate and direct review links produce one row and one total per appointment" do
    second = create_visit(@site, @patient, start_at: "2026-11-19 15:00")
    post "#{@root}/reminder_runs", headers: @headers
    sent = @site.messages.outbound.order(:id).first
    post "#{@root}/inboxes/#{@patient.id}/replies", params: {
      reply: { channel: "sms", body: "NO", event_key: "review", message_id: sent.id }
    }, as: :json
    assert_response :created
    review = @site.follow_ups.find_by!(issue: "reply_review")
    assert_equal [ @visit.id, second.id ], review.candidate_ids
    assert_equal review.candidate_ids, review.review_appointments.order(:appointment_id).pluck(:appointment_id)
    read_appointments(filter: "review")
    assert_equal [ @visit.id, second.id ], response.parsed_body.fetch("rows").pluck("id")
    assert_equal 2, response.parsed_body.fetch("totals").fetch("review")
    assert response.parsed_body.fetch("rows").all? { |row| row.fetch("reply_review") }

    review.update!(candidate_ids: [ second.id ])
    assert_equal [ second.id ], review.review_appointments.pluck(:appointment_id)
    read_appointments(filter: "review")
    assert_equal 2, response.parsed_body.fetch("rows").size
    review.update!(resolved_at: Time.current)
    read_appointments(filter: "review")
    assert_empty response.parsed_body.fetch("rows")
    assert_equal 0, response.parsed_body.fetch("totals").fetch("review")
  end

  test "board queue totals and staff rejection observe a changed source revision" do
    travel_to DEMO_NOW + 6.days
    post "#{@root}/reminder_runs", headers: @headers
    task = @site.follow_ups.sole
    get "#{@root}/follow_ups", headers: @headers
    assert_response :success
    assert_equal({ "needs_attention" => 1 }, response.parsed_body.fetch("totals"))
    ReplicaFixtures.write { @visit.update!(start_at: "2026-11-20 15:00", updated_at: Time.current) }
    get "#{@root}/follow_ups", params: { queue: "resolved" }, headers: @headers
    assert_response :success
    assert_equal [ task.id ], response.parsed_body.fetch("rows").pluck("id")
    assert_equal({ "resolved" => 1 }, response.parsed_body.fetch("totals"))
    patch "#{@root}/follow_ups/#{task.id}", headers: @headers
    assert_response :unprocessable_entity
    assert_nil task.reload.staff_member_id

    ReplicaFixtures.write { @visit.destroy! }
    get "#{@root}/follow_ups", params: { queue: "active" }, headers: @headers
    assert_response :success
    assert_equal [ task.id ], response.parsed_body.fetch("rows").pluck("id")
    assert_equal "needs_attention", response.parsed_body.fetch("rows").sole.fetch("queue")
  end

  test "fresh contact comparisons include patients without appointments and remove deleted contacts" do
    post "#{@root}/reminder_runs", headers: @headers
    assert_equal 1, response.parsed_body.fetch("delivered")
    sent = @site.messages.outbound.sole
    outsider = create_patient(wireless_phone: "+1 (512) 555-0100", email: nil)
    assert_not @site.patients.exists?(outsider.id)
    post "#{@root}/inboxes/#{@patient.id}/replies", params: {
      reply: { channel: "sms", body: "YES", event_key: "shared", message_id: sent.id }
    }, as: :json
    assert_response :created
    assert_equal "review", response.parsed_body.fetch("result")
    assert_empty @site.visit_decisions
    assert_equal "5125550100", PatientSearch.find(outsider.id).sms_key
    ReplicaFixtures.write { outsider.destroy! }
    post "#{@root}/inboxes/#{@patient.id}/replies", params: {
      reply: { channel: "sms", body: "YES", event_key: "allowed", message_id: sent.id }
    }, as: :json
    assert_response :created
    assert_equal "confirmed", response.parsed_body.fetch("result")
    assert_not PatientSearch.exists?(outsider.id)
    assert_equal sent.revision, @site.visit_decisions.sole.revision
  end

  test "failed attempt persistence rolls back contact population and a retry sends once" do
    listener = lambda do |event|
      raise "attempt failure" if event.payload[:sql].start_with?('INSERT INTO "messages"')
    end
    before_keys = PatientSearch.order(:id).pluck(:id)
    ActiveSupport::Notifications.subscribed(listener, "sql.active_record") do
      error = assert_raises(RuntimeError) { post "#{@root}/reminder_runs", headers: @headers }
      assert_equal "attempt failure", error.message
    end
    assert_equal before_keys, PatientSearch.order(:id).pluck(:id)
    assert_empty @site.messages
    assert_nil @site.reload.last_synced_at
    2.times { post "#{@root}/reminder_runs", headers: @headers }
    assert_response :created
    assert_equal 0, response.parsed_body.fetch("delivered")
    assert_equal @visit.id, @site.messages.outbound.sole.appointment_id
  end

  test "unchanged source comparisons do not write and changed raw contacts update one comparison" do
    post "#{@root}/reminder_runs", headers: @headers
    _, repeated = RailsWorkloadProbe.measure { post "#{@root}/reminder_runs", headers: @headers }
    assert_equal 0, repeated.fetch(:direct_write_statements)
    ReplicaFixtures.write { @patient.update!(email: "updated@example.test") }
    _, changed = RailsWorkloadProbe.measure { post "#{@root}/reminder_runs", headers: @headers }
    assert_equal 1, changed.fetch(:direct_write_statements)
    assert_equal 1, changed.fetch(:affected_rows)
    assert_equal "updated@example.test", PatientSearch.find(@patient.id).email_key
    assert_equal 1, @site.messages.outbound.count

    ReplicaFixtures.write { @patient.update!(first_name: "Revised") }
    _, renamed = RailsWorkloadProbe.measure { post "#{@root}/reminder_runs", headers: @headers }
    assert_equal 0, renamed.fetch(:direct_write_statements)
    get "#{@root}/inboxes", params: { q: "revised" }
    assert_response :success
    assert_equal [ @patient.id ], response.parsed_body.fetch("patients").pluck("id")
    assert_equal "updated@example.test", PatientSearch.find(@patient.id).email_key
  end

  test "Ruby revision matches the fingerprint captured from the baseline view" do
    visit = PmsVisit.new(id: 1319, clinic_id: 1, patient_id: 247,
      start_at: "2026-11-19 13:00", updated_at: DEMO_NOW)
    assert_equal "2d182d70139319231d88567d0f5bbe50", visit.revision
    visit.updated_at = nil
    assert_equal "65feea397ddf0c16547358d3535907a2", visit.revision
    visit.start_at = "2026-11-19 13:00:00.123400"
    visit.updated_at = "2026-11-12 17:30:00.000001"
    assert_equal "46ca70b6f30ffa74efccca675481bed8", visit.revision
  end

  test "patient detail keeps bounded history and the same next visit when older source history grows" do
    ReplicaFixtures.write do
      ReplicaFixtures::Appointment.insert_all!(30.times.map do |index|
        { clinic_id: @site.id, patient_id: @patient.id, status: "complete", start_at: Time.utc(2026, 10, 1) + index.hours }
      end)
    end
    get "#{@root}/patients/#{@patient.id}", headers: @headers
    assert_response :success
    expected = response.parsed_body
    assert_equal 30, expected.fetch("visits").size
    assert_equal @visit.id, expected.fetch("next_visit").fetch("id")
    ActiveRecord::Base.with_connection(&:clear_query_cache)
    _, small = RailsWorkloadProbe.measure { get "#{@root}/patients/#{@patient.id}", headers: @headers }
    ReplicaFixtures.write do
      ReplicaFixtures::Appointment.insert_all!(500.times.map do
        { clinic_id: @site.id, patient_id: @patient.id, status: "complete", start_at: "2025-01-01 10:00" }
      end)
    end
    assert_equal 531, @site.visits.count
    ActiveRecord::Base.with_connection(&:clear_query_cache)
    _, grown = RailsWorkloadProbe.measure { get "#{@root}/patients/#{@patient.id}", headers: @headers }
    assert_response :success
    assert_equal expected, response.parsed_body
    puts "Patient detail #{response.body.bytesize} bytes; small: #{small}; grown: #{grown}"
    %i[database_statements read_rows instantiated_records direct_write_statements].each do |metric|
      assert_equal small.fetch(metric), grown.fetch(metric), metric.to_s
    end
  end

  private

  def read_appointments(**params)
    get "#{@root}/appointments", params: { date: "2026-11-19", **params }, headers: @headers
    assert_response :success
  end
end
