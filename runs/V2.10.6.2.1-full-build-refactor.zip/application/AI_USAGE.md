# AI usage

Codex implemented the clean-room application from the packaged assignment, sanitized product behavior, and ten reference screenshots. It used standard Rails, React, Vite, PostgreSQL and browser tools. It authored the implementation, synthetic fixtures, checks, architecture, and factual handoff. The workflow used local Git and a distinct AI review of the local application. No messages used a live vendor and no prior application repository was accessed.

Joshua required a passing preflight before application implementation and asked to proceed with the rebuild immediately afterward. The implementation choices and test evidence are recorded in the build log and rubric report. Candidate-authored decisions and interview explanations belong to Joshua.

Codex performed the existing-code refactor using the installed V2.10.6.2.1 harness and this checkout's source, architecture, usage notes, and implemented behavior. New plans and executable evidence are under `review/current/`. No accepted `DECISIONS.md` was present. The first implementation checkpoint precedes the independent Appointment Flow Performance Benchmark V1.0.0; no final benchmark grade is claimed. All work and commits remain local.
