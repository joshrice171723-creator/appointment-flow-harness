# V2.2

Historical source and harness. Version-associated archives. No matching launch receipt was recovered.

Open the harness and application archives separately. The company-supplied PDF is excluded. The run metadata describes the input match and the observed evidence.
