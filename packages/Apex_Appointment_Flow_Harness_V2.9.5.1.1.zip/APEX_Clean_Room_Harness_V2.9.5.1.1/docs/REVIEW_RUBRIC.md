# V2.9.5.1.1 AI grading rubric

Apply this rubric to the completed clean-room implementation and after each repair round. The AI owns the grade and its evidence. Inspect the source and calls, execute the required checks, and resolve uncertainty through focused investigation.

## Grades

- **PASS** means the criterion is satisfied on the current revision and the report shows the evidence.
- **REVISE** means a specific, material code or behavior issue needs a fix. Cite where it occurs and what it changes.
- **UNVERIFIED** means required evidence is missing. Collect it through source inspection or an executable check appropriate to the criterion.

The overall grade is **PASS** only when every required criterion below passes and the configured quality gate passes on the final implementation. Use **REVISE** while a fix, a check, or other evidence is still needed. Use **BLOCKED** only when a required prerequisite is genuinely unavailable after reasonable diagnosis and recovery attempts. Record the exact blocker, what was attempted, and which evidence is missing.

## What earns a PASS

For each criterion, state a concrete way the claim could fail and cite evidence that addresses it. For runtime claims, give the caller, exercised input, expected result, and observed result on the graded revision. Check the assertions in any reused test. Test names, green suites without relevant assertions, and the author's summary leave the claim UNVERIFIED. A confirmed breach of an explicit harness rule is REVISE.

Before the first grade, the reviewer selects a material risk whose failure is least covered and challenges it with a focused check through its real caller. Reuse existing runnable evidence if it tests that exact risk. On regrade, rerun checks affected by repairs and record why any carried-forward evidence still applies. Grade against the current revision. The AI owns every check, repair, and regrade.

## Required criteria

| Criterion | Evidence for PASS |
|---|---|
| **Task execution** | Apply the completion gate in `docs/TASK_EXECUTION_STANDARD.md`. Verify scope, before-and-after evidence, and the final four-part report. Grade a failed required check REVISE and missing required evidence UNVERIFIED. |
| **Required behavior** | Map the core assignment and adopted scope to actual results. Exercise a real local reminder-and-reply workflow through the normal entry points. Reconcile any scope cuts with the brief. |
| **Safety and data boundaries** | Review and verify the applicable recipient, appointment revision, clinic isolation, opt-out, scheduling, and duplicate-send safeguards. Confirm the demo uses fictional data, fake transport, and read-only PMS access. For a decision based on a bounded view or derivative, verify how a relevant record outside that view affects the result after source data changes. Exercise the applicable high-risk behavior through its real caller. |
| **Performance and Rails queries** | For material HTTP callers, apply the relevant API and performance checks in `docs/PERFORMANCE.md`. Compare exact caller results and persisted effects under the same workloads. For a shared prerequisite, check that the added fixture records satisfy its actual selection. Check first population and unchanged repeats separately. Compare affected rows, returned rows, payload, and statements. Verified avoidable growth or duplicate effects require REVISE. For derived query values, verify their update owner, legacy data, freshness contract, and total maintenance cost. |
| **Material workflow coverage** | Identify the material workflows from actual entry points and call sites. Apply relevant rubric criteria to each, including shared operations. Cite existing or newly gathered evidence for the material guarantees. |
| **Human readability** | Read the public action or workflow entry point first and trace it to the caller-visible result. Identify who owns each decision. Verify that named private steps make meaningful rules findable, screen-specific work stays with its controller, and a service has shared callers or its own business and transaction boundary. Cite a concrete edit location and verify the rule's inputs and output. |
| **Ease of change** | Select one plausible change to an implemented rule. Apply it in a disposable copy, record where the rule was found and which production files changed, and run a focused check that proves the new result and one neighboring unchanged behavior. Keep the exercise patch outside the submitted build. Reuse it on regrade if the tested path is unaffected. |
| **Failure and transaction behavior** | Trace an applicable failure through the owning transaction and caller. Identify what commits, rolls back, or survives, and verify the caller's response. Show where the error is identified and how its original cause is preserved. Exercise rollback, retry, or uncertain writes where the workflow depends on them. |
| **Verification and handoff** | Run the configured gate against the finished implementation. Check that it ran actual tests, verify one documented local setup from an empty database, and exercise the demo. Include a migration-only start when required runtime state is created by migrations. Identify the application revision tested and check documentation for factual accuracy. |

Run the required Active Record query source check against the migrated test database. Trace material relations through model mappings, migrations, and derived values as well. For consequential lookups with a small result and a plausible broad scan, verify the executed plan comparison from `PERFORMANCE.md`. An unchanged response with growing, avoidable scan work remains REVISE. A missing material plan remains UNVERIFIED. Verify the actual query source on the migrated database before assigning PASS.

## Grading and repair loop

1. **Grade the built revision.** Follow `agent-prompts/03_INDEPENDENT_REVIEW.md`. The grader discovers material workflows after implementation and verifies coverage using the actual code and evidence.
2. **Repair verified findings.** Fix the smallest responsible area. Preserve required behavior, safety boundaries, and proportionate scope. Investigate speculative findings before changing code. Resolve an UNVERIFIED criterion by collecting evidence.
3. **Verify and regrade.** Run focused checks for the changes, then apply the full rubric again to the updated revision. Carry forward evidence when its code and inputs still apply. Refresh evidence invalidated by fixes. Run the full configured gate on the final revision before recording an overall PASS.
4. **Repeat until PASS.** Continue through additional repair and grading rounds as needed. A blocked result is an incomplete build and cannot be frozen as passed.

Use an independent AI reviewer when the environment supports it. If it does not, run a dedicated grading pass using the source and runnable evidence in the current agent and label that result as self-review. A self-review does not supply independent comparison evidence. Keep all code inspection, execution, decisions about findings, and validation with the AI.

## Evidence record

Write `review/RUBRIC_RESULTS.md` during the build. For each round, record the implementation revision or snapshot, overall grade, all criterion grades, and the evidence supporting them. Use file and line references, commands and results, or observed runtime behavior. For REVISE findings, give the impact, smallest remedy, and verification after repair. For UNVERIFIED criteria, say what evidence remains. Record the independent-review mode and final gate result. Report stylistic preferences as optional observations.

The interview's personal authorship and live defense requirements sit outside the AI grade. The agent verifies the decision notes as factual handoff material.
