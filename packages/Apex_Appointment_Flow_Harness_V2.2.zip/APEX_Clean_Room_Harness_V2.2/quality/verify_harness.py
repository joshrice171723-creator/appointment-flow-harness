"""Verify the handoff package without installing app dependencies."""
from pathlib import Path
import hashlib
import sys

ROOT=Path(__file__).resolve().parents[1]
REQUIRED=[
    'AGENTS.md','START_HERE.md','RUN_THIS_IN_RUBYMINE.md',
    'reference/Appointment-Confirmation-Take-Home.pdf',
    'product-spec/PRODUCT_BRIEF.md','product-spec/BEHAVIORAL_REQUIREMENTS.md',
    'product-spec/USER_JOURNEYS.md','product-spec/SCENARIOS.md',
    'product-spec/ACCEPTANCE_TESTS.md','product-spec/SCREENSHOT_INDEX.md',
    'product-spec/INPUT_SOURCES_AND_EXCLUSIONS.md',
    'docs/CODING_STANDARDS.md','docs/ARCHITECTURE_GUARDRAILS.md',
    'quality/run_checks.py','reference/screenshots/09-patient-conversation-reply.png',
    'reference/screenshots/10-patient-inbox-email.png',
]

def main():
    missing=[name for name in REQUIRED if not (ROOT/name).is_file()]
    images=sorted((ROOT/'reference'/'screenshots').glob('*.png'))
    if len(images)!=10:
        print(f'FAIL: Expected 10 verified screenshots, found {len(images)}.')
        return 1
    for image in images:
        if image.read_bytes()[:8]!=b'\x89PNG\r\n\x1a\n':
            print('FAIL: Invalid PNG signature:',image)
            return 1
    if missing:
        print('FAIL: Missing required files:',', '.join(missing))
        return 1
    manifest=ROOT/'MANIFEST.sha256'
    if manifest.is_file():
        for line in manifest.read_text(encoding='utf-8').splitlines():
            if not line.strip(): continue
            digest,rel=line.split('  ',1)
            path=ROOT/rel
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
                print('FAIL: Manifest mismatch:',rel)
                return 1
    print(f'PASS: Clean-room handoff files present; {len(images)} verified PNG screenshots; original PDF present; integrity manifest verified.')
    print('NOTE: No application quality checks have run yet.')
    return 0

if __name__=='__main__':
    sys.exit(main())
