# Architecture guardrails

## Avoid accidentally building a platform

This is a take-home at approximately 60 clinics / 4,000 appointments per day, not a production deployment. Prefer a **single repository** and the fewest needed runtime components.

Proposed starting arrangement **for discussion, not an already-approved design**:

- Rails + PostgreSQL for replicated read-side records, local confirmation/reminder state, and a small HTTP API.
- React + TypeScript via a minimal build tool for one staff-facing dashboard.
- A fake, local SMS and email delivery adapter with inspectable send history.
- Explicit/manual reminder-run entry point for local demonstration. A minimal background job may be used if its lifecycle/retry behavior adds clarity.

Alternative worth considering: Rails full-stack with embedded React. Choose once; do not create parallel architectures.

## Rails responsibility boundaries

- **Controllers** group actions for a cohesive resource or workflow. They establish request scope, validate and translate HTTP input, call the business operation, and render the response.
- **Active Record models** own persistence, associations, and rules about their own records. Keep filtering, existence checks, and aggregation in the database when ordinary Active Record expresses them clearly.
- **Workflow objects** give a cross-record or external operation a name and a transaction owner. Use a plain Ruby class in `app/services` when it makes that responsibility easier to find and test independently. Give substantial read operations a named query when doing so makes their scope and result clear. Keep straightforward single-record operations and queries direct.

Check the route map for unrelated responsibilities collected under the same controller. Trace a representative write through its rule owner and transaction. Judge the structure by how easily someone can find and change a rule.

## Introduce an abstraction only with an explanation

| Proposed addition | Evidence required |
|---|---|
| Service class | A named workflow that coordinates records or external I/O and has a clear caller and owner for its writes |
| New React hook | Shared lifecycle/stateful behavior that cannot be kept clearly in its component |
| Context/store | State genuinely shared across distant components, not simply prop-drilled across 1–2 layers |
| Event bus / queue | Concrete concurrency, retry, or scheduling need; cannot be justified by "future scale" alone |
| Repository layer | A real boundary not already supplied sufficiently by ActiveRecord |
| New dependency | Value, maintenance burden, security implications, and simpler alternative |
| Caching | Measured problem, invalidation plan, and consistency consequences |

**Avoid:** auto-generated abstractions named `Manager`, `Handler`, `Factory`, `BaseService`, `Helper`, `Orchestrator`, or `Util` without an actual single responsibility. Names alone are not forbidden; needless layers are.

## Safety-critical boundaries that DO justify careful engineering

1. **Who receives a message:** patient/guarantor policy, consent assumptions, contact normalization, wrong-recipient prevention.
2. **Which appointment:** identity of an appointment across reschedule, cancellation/breakage, and the PMS replication delay.
3. **When a message sends:** clinic-local wall time and timezone/DST interpretation; reminder-window eligibility.
4. **How many times:** concurrency/idempotency for repeated runs and retries; no accidental duplicate sends.
5. **What confirmation means:** authentication/verification assumptions for replies and state transitions; no silent confirmations on unrelated input.
6. **Who sees data:** clinic-scoped backend queries and a staff auth stub, without false security claims.

Prove the behavior with focused, readable tests before inventing additional architecture.

## No hidden scope expansion

Do not build booking, rescheduling, patient portal, production auth, live message providers, infrastructure-as-code, or a deploy pipeline. Do not collect real patient information. If a missing feature seems necessary to make the demo safe, document the conflict and offer the narrowest alternative.
