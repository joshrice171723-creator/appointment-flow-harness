# Acceptance matrix — verify behavior, not architecture

This matrix translates the take-home into testable examples. Items marked **proposal** are safety-oriented acceptance hypotheses, not direct employer requirements. Confirm or revise them in `DECISIONS.md`.

| ID | Scenario / evidence | Source status | Test level |
|---|---|---|---|
| F1 | Upcoming scheduled appointments are selected for confirmation | Explicit | Model/integration |
| F2 | SMS AND email are sent via fake/sandbox adapter | Explicit | Integration |
| F3 | A configurable/explicit roughly week-before and days-before cadence is demonstrated | Explicit concept; specific intervals are assumptions | Time-controlled integration |
| F4 | Confirmation reply changes the correct appointment's confirmation status | Explicit | Request + domain |
| F5 | Each clinic's staff can view upcoming appointment confirmation status | Explicit | Request + React UI |
| F6 | Local setup, deterministic fake seeds, reminder trigger, reply simulation, automated tests are documented | Explicit | Smoke + docs |
| S1 | Broken/unscheduled/completed appointments never get upcoming reminders | Proposal | Model/integration |
| S2 | Moving appointment time on same ID invalidates or reevaluates stale reminder eligibility | Proposal based on reschedule note | Integration |
| S3 | Breaking an old appointment and creating a new ID doesn't confirm the new one silently | Proposal based on reschedule note | Integration |
| S4 | Re-running the same reminder window does not accidentally send twice | Proposal | Concurrency/idempotency test |
| S5 | Invalid/missing phone or email handled explicitly, without pretending delivered | Proposal | Adapter/integration |
| S6 | An unknown/ambiguous reply does not falsely mark a patient confirmed | Proposal | Domain/request |
| S7 | Appointment timestamp interpreted using documented clinic timezone; DST tests where relevant | Proposal based on wall-clock source | Time-focused |
| S8 | Clinic A cannot fetch Clinic B's appointments through the backend | Proposal; auth is stubbed | Request |
| S9 | Outbound messages and logs avoid sensitive procedure details | Proposal | Adapter/request |
| S10 | Fake provider failure/retry behavior is explainable and tested | Proposal | Unit/integration |
| P1 | 4,000/day scale considered through reasonable indexes/batching where appropriate; no speculative microservices | Explicit volume; approach proposed | Explain + focused query review |
| D1 | `DECISIONS.md` authored by user with assumptions, choices, rejected alternatives, next-week plan | Explicit | Human review |
| D2 | Architecture components, data flow, state lifecycle diagram included | Explicit | Human review |
| D3 | `AI_USAGE.md` accurately records models/tasks/overrides/corrections | Explicit | Human review |
| D4 | README includes install/run/trigger/reply simulation | Explicit | Manual smoke |

## Approval policy

Before coding each slice, pick the relevant IDs and define expected observations. After implementation, report passing/failing **commands and evidence**, not merely "covered". Mark a proposal as an adopted requirement only after a deliberate decision, not because the harness suggested it.
