# AGENTS.md — Apex clean-room rebuild contract V2.2

## Read order and precedence
1. `RUN_THIS_IN_RUBYMINE.md` (execution contract)
2. `reference/Appointment-Confirmation-Take-Home.pdf` (official assignment, highest product authority)
3. `product-spec/PRODUCT_BRIEF.md`, `BEHAVIORAL_REQUIREMENTS.md`, `USER_JOURNEYS.md`, `SCENARIOS.md`, and `ACCEPTANCE_TESTS.md` (observed product intent)
4. `product-spec/SCREENSHOT_INDEX.md` and the actual PNGs (visual reference, **not** proof of unseen behavior)
5. `docs/CODING_STANDARDS.md`, `docs/ARCHITECTURE_GUARDRAILS.md`, `docs/REVIEW_RUBRIC.md` (engineering discipline)
6. Other templates, prompts, and reference documents

If sources disagree, keep the official assessment above the baseline behavior and visuals. Note material ambiguity in a decision log; make a narrow, defensible choice rather than inventing facts.

## Absolute clean-room boundary
- Build in this newly extracted directory, as a **brand-new application and Git repository**.
- NEVER open, clone, search, fetch, inspect, or copy code, tests, config, commit history, issues, agent notes, API routes, model names, database migrations, or architecture from the earlier appointment-flow repository. This includes GitHub connector access and local files from that repository. The old project is strictly a post-completion comparison baseline.
- Only the assessment PDF, the ten included UI screenshots, and **sanitized behavior-only documents** are authorized information about the prior product. Do not look for screenshots or more details in the old codebase.
- Do not add the old repository as a Git remote. Do not publish to it. Create a new independent repository if publishing is authorized.
- The screenshot names are descriptive labels, not code or API requirements.
- Do not recreate the former code architecture even if a product example tempts you to do so. Choose your own solution from the problem and justify it.

## Quality hierarchy
Preserve safety, correctness, and required behavior. Judge implementations by performance, human readability, and ease of change. Use ordinary framework conventions that make the work, the business rules, and failure behavior clear.

- Read new-project code before editing it. Take small, reviewable vertical slices.
- Use meaningful domain names, direct control flow, cohesive functions, and minimal, justified abstraction. Apply the Rails responsibility boundaries in `docs/ARCHITECTURE_GUARDRAILS.md`. Add abstractions when they give a real responsibility a clear home or reduce reading effort.
- Implement real behavior, not just a screenshot replica. Every important UI action must be connected to an observable state change.
- Add focused automated tests for high-risk behavior: wrong-recipient outreach, clinic data isolation, duplicate sends, ambiguous replies, opt-outs, rescheduled appointments, timezone/clinic-local dates, no PHI in leadership data.
- Do not treat a fake provider's successful API call as proof of real-world SMS/email delivery. No live communications or real patient data.
- Preserve fake PMS source data as read-only from the app's perspective; do not modify the authoritative replica tables at runtime.
- Don't add booking, self-service rescheduling, production infrastructure, full authentication, or live vendor accounts. The brief puts these out of scope.
- Never skip failed or unavailable checks; don't claim unrun tests passed. Use the quality runner after the app is scaffolded.
- Run a **separate reviewer session** for the final diff; require file/line references, evidence, severity, and the least complex fix. Do not mechanically adopt speculative review requests.
- No automatic push/PR/merge. No destructive operations outside the new workspace. Obtain user authorization to create external resources, access secrets, or install third-party executables.
- The candidate writes `DECISIONS.md` in their **own words**. The agent can produce tradeoff bullet notes, questions, and critique, but must not ghostwrite personal explanations and attribute them to the candidate.

## At each slice
Follow `agent-prompts/02_SIMPLIFY.md` when reviewing material changes to data access, business rules, or transactions. The independent reviewer follows `agent-prompts/03_INDEPENDENT_REVIEW.md` after the build.

Summarize requirement IDs, implementation approach, alternatives, tests run and *actual* results, remaining gaps, and a plain-English explanation of why this code is structured this way. Do not pad with generic engineering essays.
