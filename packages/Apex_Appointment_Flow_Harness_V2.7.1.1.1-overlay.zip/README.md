# V2.7.1.1.1 refactor overlay

Apply the enclosed guidance with V2.7.1.1.0 in a copy of an existing app.
