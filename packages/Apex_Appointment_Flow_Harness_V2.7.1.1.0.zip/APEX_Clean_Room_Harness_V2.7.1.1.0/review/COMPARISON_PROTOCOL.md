# Comparing frozen builds

Run comparison in a separate evaluation workspace after the new build is frozen. The implementation session stays inside its own project. Give the evaluator the same behavioral cases and workload, anonymized source from each frozen revision, and an equivalent rule-change exercise in disposable copies. Compare evidence against the same rubric. Record code revisions, commands, result equivalence, fixture sizes, measured work, reviewer findings, and completion or blockers. Use the existing experiment authorization for read-only comparisons.
