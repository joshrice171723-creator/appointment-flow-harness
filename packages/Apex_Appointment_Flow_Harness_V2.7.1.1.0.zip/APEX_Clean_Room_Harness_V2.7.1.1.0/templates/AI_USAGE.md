# AI_USAGE

This is a truthful usage log, not a marketing statement. Log every AI tool used, for what work, and meaningful overrides/corrections.

| Date | Agent/model/tool | Task | What it suggested or changed | What I verified, rejected, or corrected |
|---|---|---|---|---|
| TODO | TODO | TODO | TODO | TODO |

## Where I disagreed with an agent

- TODO: Concrete code location/decision and the correction (if none, state none; don't invent one).

## Verification I performed

- TODO: Commands, test results, manual checks, limitations.
