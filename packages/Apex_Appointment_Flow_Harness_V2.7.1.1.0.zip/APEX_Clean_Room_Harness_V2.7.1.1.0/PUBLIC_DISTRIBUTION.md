# Public archive

The company-supplied take-home PDF is omitted here and from nested archives. The original run manifests identify the original inputs. Use the repository checksums to verify this export. Verification of the original assessment needs the separately supplied PDF and original archive bytes.
