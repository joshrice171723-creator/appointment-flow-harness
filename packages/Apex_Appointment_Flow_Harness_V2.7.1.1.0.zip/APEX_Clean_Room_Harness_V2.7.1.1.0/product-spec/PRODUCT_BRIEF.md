# Product brief: Apex Appointment Flow (clean-room target)

## Purpose
A local Rails + React demonstration of an appointment-confirmation and patient-follow-up workflow for dental clinics. Help clinics reduce avoidable missed visits by contacting patients before appointments, safely recording confirmation replies, and showing front-desk staff which patients need human follow-up. Provide operations leaders **aggregate** reporting only. Use synthetic patient data and fake/sandbox transports.

## Authoritative scope
The original `reference/Appointment-Confirmation-Take-Home.pdf` controls. Core: find upcoming visits in a replicated PostgreSQL PMS dataset; send SMS and email via a fake interface, roughly one week and a few days ahead; record confirmations; staff-facing appointment/confirmation dashboard; run locally with tests and seed data. Approximately 60 clinics / 4,000 appointments daily are context, **not** a reason to build a distributed platform. Excluded: booking, full rescheduling UI, production deployment/IaC, real messaging providers, full staff authentication.

## Three user workspaces
1. **Front desk:** demo clinic + staff picker; clinic-scoped patient-flow task board; appointments calendar/table; patient details, follow-up, history and activity.
2. **Leadership:** outcome and activity summaries per clinic and month; no names, phone numbers, email addresses, messages, birthdates or other patient-level details.
3. **Patient (demo):** clinic and fake patient picker; text/email history; simulate inbound replies, which must exercise the same outcome-processing rules as the system's inbound interface.

## Observable product boundaries
- Appointment source is externally owned and read-only to this application. The demo should model source changes/reschedules and show the last successful sync.
- Patient communication should never be directed to a known-wrong, ambiguous or unpermitted recipient; surface actionable follow-up instead.
- A confirmation is about a **specific appointment version**. Moving a visit may invalidate an earlier confirmation.
- No duplicate sends on repeated runs/retries. Preserve attempts/outcomes for inspection in the local demo.
- Scheduling and timestamps must handle clinic-local time and US timezones explicitly. Original `start_at` is a wall-clock timestamp, **not UTC**.
- Lead with user-explainable decisions and testable behavior rather than layering on unnecessary architecture.

## Provenance
Behavior and visual concepts were supplied by the user from their prior product. All structural source-code references were intentionally discarded. They describe **what users see and do**, not how the old implementation was constructed. The new implementation must be original.
