# User journeys and observable interactions

## Front desk
1. Open Workspaces; select **Austin** and fictional staff member; open front desk. Board shows totals for Needs attention, In progress and Resolved.
2. Use board tabs (active/resolved/all appointments), search, issue-type filter and pagination. Open a work card to reach the patient's follow-up context. Opening a card can claim it for the active staff identity.
3. For a no-reply issue, record a required note and Contact attempted (stay open) or Confirmed (close task and confirm current appointment); for a resolved appointment, record canceled/rescheduled and stop further reminders. If the save is rejected, keep the draft and show the error.
4. For ambiguous replies, view the message and candidate appointments, choose the matching appointment(s) only after human clarification, and save what was learned.
5. Use the patient's details card to inspect phone, email, birthday and language. Verify/correct permitted local details without editing source PMS records; blocked outreach should be re-evaluated next batch.
6. Use Appointments to browse the week, jump dates, filter by confirmation status, and open patient/follow-up details. Show the last PMS sync and clinic-local time.
7. Return to Workspaces; select **Phoenix**. Austin work and patient records must not appear in the Phoenix workspace.

## Leadership
1. Open Apex leadership from Workspaces; select a reporting month.
2. View outcome counts and completion percentages by reporting clinic; inspect clinic comparison.
3. Expand monthly history/reminder activity, contact holds, contact/follow-up details; each value must show a meaningful definition and denominator.
4. No patient data can appear in any visible or API payload of this workspace.

## Patient demo
1. Open Patient from Workspaces, then select clinic and fictional patient.
2. Read text message history, switch to Email tab, and enter a simulated reply.
3. Send `YES`, `NO`, `STOP`, or ambiguous wording and verify the matching staff view changes correctly; nothing is sent to actual phones or email addresses.

## Visual notes
Each screenshot depicts a **sample state**, not a requirement that all fixture counts, dates, patient names, and precise labels must match. Follow `SCREENSHOT_INDEX.md` for evidence and uncertainty; do not claim to have seen Email-tab details that are missing from the archive.
