# Acceptance scenarios using synthetic patients

Use these as **observable behavioral checks** and automated test targets, not as prescribed model class names or API endpoints. The agent should choose its own architecture. The examples derive from provided product behavior notes; the original assignment PDF is authoritative where wording differs.

| ID | Situation | Expected observable outcome |
|---|---|---|
| S01 | SMS sent seven days ahead; correct patient replies `YES` | Visit confirmed for current appointment version; subsequent request skipped; final reminder can remain informational |
| S02 | No textable phone, valid authorized email; patient replies `yes` | Email request and inbound reply can confirm same way as SMS |
| S03 | Patient confirmed, then PMS changes appointment start time on same record | Old confirmation no longer automatically applies to new time; reevaluate reminders without duplicate or post-start sends |
| S04 | PMS ends old appointment and creates a new one | Old visit no longer receives reminders; new visit has its own confirmation lifecycle |
| S05 | SMS fails; email permitted | Failed attempt remains visible; one appropriate backup email; task for staff to inspect failed contact; no infinite retries or duplicate sends |
| S06 | Same delivery event or reply is ingested twice | No duplicate business effect; preserve auditability and idempotency |
| S07 | Valid YES then later NO | Do not silently undo confirmation; route conflicting later intent to staff review |
| S08 | Reply received after appointment starts | Retain reply for audit/history; do not retroactively confirm or trigger messaging |
| S09 | Exact `STOP` for valid clinic/recipient | Future SMS suppressed; later source sync cannot reset the opt-out; ambiguous STOP variants safely reviewed |
| S10 | Switch front desk from Austin to Phoenix | Board, patients, results and ownership never leak between clinics |
| S11 | No reply within approximately 48 hours of visit | Staff follow-up appears; attempted contact stays open; phone confirmation closes and marks confirmed |
| S12 | Two patients share a family phone | Ambiguous YES not applied to either; staff receives linked candidates for review |
| S13 | Minor lacks verified guardian/permissions or patient details are unsafe | No outgoing message; actionable contact hold; authorized verified local correction can unblock future batch |
| S14 | Empty/missing/failed PMS refresh | Do not silently lose previously tracked visits or send based on partial/untrusted refresh; surface failure |
| S15 | Reminder batch rerun repeatedly or concurrently | One logical message per eligible step and appointment version, no duplicates; no sends outside configured local window |
| S16 | Confirmed vs completed visit | Appointment confirmation state and PMS outcome are kept separate; leadership completion rate is based only on recorded outcomes |
| S17 | Leadership data requested for every reporting clinic | No patient-identifying information in page or API response, even for expanded sections |
| S18 | User changes date/filter/search on front-desk views | Visible records correspond to chosen clinic/date/filter and empty/error states are understandable |
| S19 | Staff follow-up save fails validation or network result is uncertain | Draft persists, error or safe retry instructions displayed, no silent duplicate outcome |
| S20 | Email tab shown for a demo patient | Email message history exists, and a submitted email reply updates the same follow-up state; exact screen layout not supplied |

## High-impact test priorities
Wrong patient, wrong clinic, wrong appointment version, duplicate sends, privacy exposure and opt-out handling are higher priority than pixel-perfect layout or extra analytics.
