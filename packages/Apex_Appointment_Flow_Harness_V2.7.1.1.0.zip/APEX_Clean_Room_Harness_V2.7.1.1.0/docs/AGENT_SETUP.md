# RubyMine + agent setup (external tools are NOT bundled)

## Essential

- RubyMine with Ruby/Rails and JS/TS features enabled. RubyMine 2026.3 documents an **Air plugin** that hosts external coding agents and exposes IDE intelligence through an MCP server. Version/plugin availability depends on your installation.
- A working **Codex** or **Claude Code** agent installation/subscription, chosen by the user. This ZIP is agent-agnostic and works through `AGENTS.md` even without external plugins. RubyMine doesn't automatically enable an agent solely because this ZIP is unzipped.
- Python 3 to run the bundled **standard-library-only** harness verification / post-scaffold quality runner.

## Experiment setup

Open a fresh agent session. Keep optional agent skills, style modes such as Ponytail, external review or orchestration plugins, and prior-project memory off for this run. Use the bundled prompts and the normal tools available in RubyMine. Record the agent/model and any required host guidance in `notes/BUILD_LOG.md`. Apply the same instruction sources to the builder and reviewer.

## IDE preferences

- The grading agent can use RubyMine inspections alongside source review and executed checks.
- Share relevant `AGENTS.md` and `docs` paths with the agent context if automatic loading is absent.
- Run checks from RubyMine Terminal (`python quality/verify_harness.py`, later `python quality/run_checks.py`).

## Dependency/version choices

Do not pin Rails, Ruby, Node, PostgreSQL, React, or TypeScript until the agent verifies compatible versions in the environment. Record concrete versions and lockfiles in the resulting application. Avoid prerelease tooling without clear need. A fresh Rails app may use Minitest; a fresh Vite React app can use TypeScript and Vitest if approved.
