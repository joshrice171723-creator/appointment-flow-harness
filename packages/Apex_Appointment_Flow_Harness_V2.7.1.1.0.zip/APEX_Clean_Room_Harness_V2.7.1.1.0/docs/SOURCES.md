# Public references for engineering standards (not old app sources)

These are generic practices and tooling sources; no code was copied from any project. Verify versions/compatibility during actual setup.

- Rails Guides (models, Active Record, testing, APIs): https://guides.rubyonrails.org/
- Official React Learn docs (state/effects): https://react.dev/learn
- React useEffect guidance: https://react.dev/learn/you-might-not-need-an-effect
- Ruby Style Guide and RuboCop: https://rubocop.org/ and https://github.com/rubocop/rubocop-rails
- Brakeman security scanner: https://brakemanscanner.org/
- TypeScript: https://www.typescriptlang.org/docs/
- ESLint React Hooks: https://react.dev/reference/eslint-plugin-react-hooks
- Playwright testing: https://playwright.dev/docs/best-practices
- GitHub required checks: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches
- Thoughtbot engineering guides: https://github.com/thoughtbot/guides
- Optional Compound Engineering plugin: https://github.com/EveryInc/compound-engineering-plugin (current README documents Codex/Claude support). Plugin is **not** bundled or required for harness integrity.

No third-party source code or plugin binaries are distributed in the ZIP.
