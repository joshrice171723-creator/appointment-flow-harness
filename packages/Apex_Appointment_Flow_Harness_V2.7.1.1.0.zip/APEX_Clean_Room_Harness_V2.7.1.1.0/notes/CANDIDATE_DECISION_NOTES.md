# Tradeoff notes for candidate's own DECISIONS.md

The assessment requires that the candidate write `DECISIONS.md` **personally in their own words**. Capture factual choices and alternatives here so the candidate can make their own narrative later. Agent must not claim authorship on their behalf.

- Assumption / ambiguity:
- What was chosen and why:
- Alternative considered and drawback:
- Risk / what would change with another week:
- Evidence (test/demo/measurement):
