# Refactor existing code

Read [Task execution standard](TASK_EXECUTION_STANDARD.md) before editing. Use its four-part sequence and completion gate. Supply the same standard to each reviewer and repair agent.

Read the current project decisions and usage notes. Preserve their accepted behavior and start from a frozen baseline. Trace the requested operation from its normal caller. List the in-scope owners, required access rules, public results, writes, and failure behavior. Keep unrelated changes outside the trial. Include a shared owner or app-owned schema change only when it is necessary for the requested result and permitted by the scope. Treat the supplied external schema and read-only access as fixed.

Run focused compatibility checks before changing the implementation. For a database-work refactor, also capture the material plans on small and grown fixtures through the complete caller. Give the reviewer the same inputs after the change. Check applicable authorization, ordering, paging, missing or changed source data, and retry behavior. Run the same checks on the final revision. A local optimization can pass on its own while the whole request still requires revision. Record both results and the exact work that remains.

Apply the checks in PERFORMANCE.md and the grading loop in REVIEW_RUBRIC.md to the agreed scope. Freeze the initial and repaired changes so their results can be reproduced. Keep earlier coding guides, review artifacts, and private evaluation cases outside the builder's context. Existing project decisions remain context. Any inherited source findings outside the agreed scope belong in the report, with their location and impact.

For feature delivery, identify the requested behavior change and its affected owners. Keep restructuring within the work needed to deliver that feature. Preserve accepted decisions and unrelated behavior. For a refactor, preserve the public contract. The reviewer discovers applicable access and policy rules from the accepted project rather than adding requirements from another project.
