# Database work and performance

Measure the useful result, time for the complete operation, and work done as the data grows. Start at the existing entry point and follow shared services, association reads, writes and retries. Keep clinic, revision, authorization and transaction boundaries intact.

Always use standard Active Record methods for application queries. Avoid handwritten SQL strings and expressions, including fragments passed into Active Record. Keep Arel out of application queries.

## Make the stored data support the decision

Before implementing a consequential read, identify the smallest answer the caller needs and express its predicate using standard Active Record. Trace any transformation needed to compare, group, or order values. If answering a small question requires loading an expanding collection into Ruby, revisit the representation and its update owner before accepting that query.

Where the application owns the schema, consider a typed or canonical comparison value, a relationship, and an index that directly support the rule. Keep required raw source values inspectable. Give derivation and invalidation one clear owner. Use the installed framework's supported APIs. Explain the extra write or synchronization work alongside the read savings. Avoid introducing stored derivatives whose consistency cannot be maintained.

Verify initial creation, changes to the source values or applicable policy, existing records, and retries through normal entry points. A normalization declaration alone does not migrate stored legacy values. Check bulk write paths and reads as well as individual saves. Respect read-only sources and the change information they actually provide. State the freshness contract when a derived value participates in a decision.

Measure the whole workflow, including the work that maintains the representation. For a request that returns the same result as unrelated data grows, trace avoidable growth in scans, transferred values, and Ruby work to its owner. Check query plans where a flat returned-row count could hide an expanding scan. Do not accept an optimization solely because it replaces SQL strings, reduces model allocations, or lowers query count.

In the existing slice evidence, show the query, the owner that keeps its inputs correct, and the focused correctness and growth results. Include the reading and change burden of the chosen design. A repeated domain calculation in a query layer and a model needs an explicit reason and evidence that their behavior stays consistent.

## Choose the query by its result

Before implementing a material database decision, identify the eligible rows and the smallest result the caller needs. Note it in the existing slice plan. Read the actual Rails version's [Active Record Query Interface](https://guides.rubyonrails.org/active_record_querying.html) for the patterns you use.

| Caller needs | Start with |
|---|---|
| Whether a matching record exists | Scoped `exists?` on an unloaded relation. Reuse a suitable collection when it is already loaded and the answer needs the same snapshot. |
| A few scalar values | `pluck` or `pick`. Use `select` when a caller still needs specific model attributes or behavior. |
| Totals by category | `group(...).count`. Keep the intended grouping and date boundary. |
| A list and related rows | Filter and bound the parent list first, then load the required associations together. Check the rendered or serialized result for lazy per-row queries. |
| Related rows or keys already read | Reuse them within the consistency boundary. If an existing write can return the needed keys, check the adapter's return options instead of automatically reading them again. |
| A set of similar writes | Check whether a bulk API preserves validation, callbacks, timestamps, uniqueness, and rollback. Verify the affected rows and return only values the caller uses. |

Keep a clear leading scope. Make null, range endpoints, ordering, and revision or tenant predicates explicit. Check the SQL Active Record sends to PostgreSQL when changing a relation, join, or index. Make an expensive shared read or source refresh visible at the owning workflow, with the time-critical section and expected failure easy to find.

For list endpoints, give the full scope, any rule-specific subset, and the displayed rows names that distinguish them. Keep filtering, ordering, counts, and limits in the relation. Preload associations required by the displayed rows. If a tab filters only displayed rows, verify that it preserves full-scope totals. Use focused endpoint checks for applicable clinic scope, date boundaries, ordering, limits, flags, response fields, and query growth.

## Catch API and performance anti-patterns during implementation

For each material HTTP caller you introduce or change, record the requested result, its scope and bound, the fields the caller consumes, and any intended persisted effect in the existing slice plan. Pick the applicable checks below and run them through the normal entry point before starting the next dependent slice. Reuse an existing check when its assertions cover the same behavior.

| Anti-pattern | Design and executable check |
|---|---|
| Bulk fetch followed by late filtering, sorting, or counting in Ruby | Narrow the Active Record relation before loading it. Check the exact IDs or totals and stable ordering, then add in-scope records that should leave that result unchanged. Compare statements and rows returned by the material query and the whole operation. A scalar projection can still transfer too much data. |
| One query or request per item | Exercise serialization and follow-up requests at small and larger supported page or batch sizes. Watch for repeated reads of the same associations, repeated writes, and client fan-out. Load required associations for the bounded result and batch equivalent work only when the business guarantees hold. |
| Oversized or unbounded responses | Return fields the caller needs and apply the contract's ordering and bound before materialization. For an interactive list, verify page boundaries, returned item count, and response body bytes under growth. For a full export, measure bounded batches and verify the complete result. |
| Request retries repeat a business effect | Keep state-changing work behind the appropriate HTTP method. For an operation whose caller can retry, repeat the same logical request under its actual retry contract. Assert the intended record identities, state, and side effects, then compare the work repeated. When an error can follow a partial write, exercise that failure through the actual caller. |

Measure setup and assertions separately from the operation. Compare response status, meaningful fields and identities, and persisted effects before interpreting performance figures. Record SQL statements and rows returned to Rails separately from models instantiated and rows affected. Where database-side scans or time matter, inspect the query plan or timing evidence. Where the rendered workflow makes multiple API calls, count requests for that workflow. Measure response bytes at a consistent boundary when comparing payload sizes.

When unchanged useful work grows with unrelated data, trace the growth to an owner and verify whether it is required by the contract. Demonstrated avoidable growth or a duplicate business effect is REVISE even if a headline count looks good. Missing required measurements or assertions remain UNVERIFIED. For justified growth or a tradeoff, show the same correct outcomes and measurements on equivalent fixtures.

References: [Active Record Query Interface](https://guides.rubyonrails.org/active_record_querying.html), [Active Support Instrumentation](https://guides.rubyonrails.org/active_support_instrumentation.html), [HTTP method semantics](https://www.rfc-editor.org/rfc/rfc9110.html#section-9.2).

## Verify growth during implementation

Choose a consequential read and write or batch from the normal callers. A shared operation is in scope even when it lives several calls below the entry point. Before choosing the query or persistence path, specify the small fixture and which additional records will enter each material prerequisite. Execute the check when the first material path works. Reuse this evidence in review if the final source and workload still match.

1. Establish the expected response and persisted effects in a small synthetic fixture. Run the complete operation with setup and assertions outside the measured block.
2. Keep the caller's result and required business effects fixed. Add records that qualify for the largest shared read or write prerequisite. Show which real predicate or caller accepts them. Compare the prerequisite and the complete operation. Classify any additional persisted rows by the other caller or requirement that needs them. If equivalent writes issue one statement per row, test whether a set-based Rails API can preserve constraints, validation, returned identifiers, rollback, and readable ownership.
3. Measure first population separately from operating on existing data. Grow eligible batch work where applicable. For a retry, repeat with existing results and check persisted effects and repeated work. Include the scope of any lock or transaction. Record write statements, affected rows, and rows returned by writes separately.
4. Record statement counts, returned rows when available, model instantiations, relevant writes, elapsed time, and the query or application source location behind meaningful growth. For a JSON aggregate or wide result, inspect record cardinality or payload size as appropriate. Use a plan to assess a scan or an index. Record which metrics are available and conditions that affect timing.

Use the existing test instrumentation or `quality/rails_workload_probe.rb` for synchronous Rails operations. It measures Active Record events on the calling thread. Check external connections or work on other threads separately when they are material. Framework schema work and cache hits have separate counters. A large payload, misleading aggregate row count, or unnecessary work under a lock matters even when the query count stays flat.

During grading, use equivalent results and trace evidence to distinguish necessary work from avoidable work. For any verified material finding, change the smallest responsible code, rerun the same scenario, and check correctness and performance together. Explain unavoidable growth and distinguish measured facts from a source prediction.
