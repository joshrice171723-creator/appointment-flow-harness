# Internal review record

Record the implementation revision, the material workflows reviewed, the assertions exercised, and the actual results. Review each claim against the task and accepted project decisions. Use the rubric and performance guidance for project checks. Give each verified finding an owner and a focused verification method. Record the implementation and repaired checkpoints separately. Confirm that the final grade applies to the frozen revision.
