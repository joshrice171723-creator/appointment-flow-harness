# Freeze checklist (complete at end — placeholders are not results)

- [ ] Exact new-repository commit hash: NOT YET CREATED
- [ ] Runtime/dependency versions recorded
- [ ] Phase timestamps and total elapsed time recorded in `notes/BUILD_LOG.md`
- [ ] Local boot/seed instructions verified on this machine
- [ ] Reminder run manually exercised and result captured
- [ ] SMS + email reply simulation demonstrated
- [ ] Actual automated test result captured
- [ ] Quality-gate result captured
- [ ] `review/RUBRIC_RESULTS.md` records final PASS for every required criterion, including material workflow coverage and the performance comparison.
- [ ] The final grade includes evidence per criterion and resolves the reviewer's challenged failure case.
- [ ] The agent checked factual decision notes against the implementation.
- [ ] AI_USAGE and architecture deliverables reviewed for truth
- [ ] No old code, GitHub repo, prior notes, fixtures or commits inspected
- [ ] Explicit user authorization obtained **before** future comparison

- [ ] The agent completed the gate in `docs/TASK_EXECUTION_STANDARD.md`.
- [ ] The report includes ACTION, CONSTRAINTS, VERIFICATION, and REPORTING.
