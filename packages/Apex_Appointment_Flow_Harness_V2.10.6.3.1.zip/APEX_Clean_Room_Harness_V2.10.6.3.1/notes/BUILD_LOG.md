# Build log — generated only from actual work

The agent should append factual, dated entries: requirements addressed, test commands + actual output, meaningful choices, and blockers. Never insert fictional results or commit hashes.

## Phase timing

Capture a wall-clock timestamp with timezone or offset at the start of Stage 0 and enter it here after preflight passes. Add timestamps at the start of Stages 1, 4, and 5 and at the end of technical freeze. Those checkpoints measure preflight, design/build/local setup, verification/review/repairs, and freeze. Report total elapsed time and each phase duration. Note a material wait or retry when observed. Record missing times as unknown.

## Task record

Use one record for the task or reuse its existing slice plan. Record ACTION and CONSTRAINTS before changing code. Record planned checks under VERIFICATION. Add the actual results as checks run. Complete REPORTING after review.
