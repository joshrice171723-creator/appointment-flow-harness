"""Verify the frozen inputs to a fresh build."""

import hashlib
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXPECTED_INPUTS = {
    '.editorconfig',
    '.gitignore',
    'AGENTS.md',
    'CLAUDE.md',
    'docs/TASK_EXECUTION_STANDARD.md',
    'RUN_THIS_IN_RUBYMINE.md',
    'START_HERE.md',
    'agent-prompts/00_BOOTSTRAP_IN_RUBYMINE.md',
    'agent-prompts/01_IMPLEMENT_ONE_SLICE.md',
    'agent-prompts/02_SIMPLIFY.md',
    'agent-prompts/03_INDEPENDENT_REVIEW.md',
    'agent-prompts/04_LIVE_DEFENSE_REHEARSAL.md',
    'docs/ACCEPTANCE_MATRIX.md',
    'docs/AGENT_SETUP.md',
    'docs/AI_LOOP.md',
    'docs/ARCHITECTURE_GUARDRAILS.md',
    'docs/ASSESSMENT_REQUIREMENTS.md',
    'docs/CODING_STANDARDS.md',
    'docs/DELIVERABLES_AND_DECISIONS.md',
    'docs/PERFORMANCE.md',
    'docs/REFACTOR_MODE.md',
    'docs/PROPOSED_WORKFLOW.md',
    'docs/REVIEW_RUBRIC.md',
    'docs/SOURCES.md',
    'notes/BUILD_LOG.md',
    'notes/CANDIDATE_DECISION_NOTES.md',
    'product-spec/ACCEPTANCE_TESTS.md',
    'product-spec/BEHAVIORAL_REQUIREMENTS.md',
    'product-spec/INPUT_SOURCES_AND_EXCLUSIONS.md',
    'product-spec/PRODUCT_BRIEF.md',
    'product-spec/SCENARIOS.md',
    'product-spec/SCREENSHOT_INDEX.md',
    'product-spec/USER_JOURNEYS.md',
    'product-spec/VISUAL_DESIGN_BRIEF.md',
    'quality/README.md',
    'quality/checks.example.json',
    'quality/ci-rails-react.yml.template',
    'quality/check_active_record_queries.rb',
    'quality/rails_workload_probe.rb',
    'quality/run_checks.py',
    'quality/verify_harness.py',
    'reference/Appointment-Confirmation-Take-Home.pdf',
    'reference/screenshots/01-launch-workspaces.png',
    'reference/screenshots/02-front-desk-board.png',
    'reference/screenshots/03-appointments-table.png',
    'reference/screenshots/04-work-case-detail.png',
    'reference/screenshots/05-patient-details.png',
    'reference/screenshots/06-operations-leadership.png',
    'reference/screenshots/07-operations-expanded.png',
    'reference/screenshots/08-patient-inbox-picker.png',
    'reference/screenshots/09-patient-conversation-reply.png',
    'reference/screenshots/10-patient-inbox-email.png',
    'review/COMPARISON_PROTOCOL.md',
    'review/FREEZE_CHECKLIST.md',
    'templates/AI_USAGE.md',
    'templates/ARCHITECTURE.md',
    'templates/DECISIONS.md',
    'templates/REVIEW_CHECKLIST.md',
}
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def verify():
    manifest = ROOT / "MANIFEST.sha256"
    hashes = {}
    for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        pair = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if pair is None:
            raise ValueError(f"Invalid manifest entry on line {number}")
        digest, relative = pair.groups()
        if relative not in EXPECTED_INPUTS or relative in hashes:
            raise ValueError(f"Unexpected or duplicate manifest entry: {relative}")
        hashes[relative] = digest

    missing = sorted(EXPECTED_INPUTS - hashes.keys())
    if missing:
        raise ValueError(f"Missing manifest entries: {', '.join(missing)}")

    for relative, digest in hashes.items():
        path = ROOT / relative
        if not path.resolve().is_relative_to(ROOT):
            raise ValueError(f"Input resolves outside the harness: {relative}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f"Manifest mismatch: {relative}")

    screenshots = sorted((ROOT / "reference" / "screenshots").glob("*.png"))
    if len(screenshots) != 10:
        raise ValueError(f"Expected 10 screenshots, found {len(screenshots)}")
    for image in screenshots:
        if image.relative_to(ROOT).as_posix() not in hashes:
            raise ValueError(f"Unlisted screenshot: {image.name}")
        with image.open("rb") as stream:
            if stream.read(len(PNG_SIGNATURE)) != PNG_SIGNATURE:
                raise ValueError(f"Invalid PNG signature: {image.name}")

    print(f"PASS: Verified {len(hashes)} packaged inputs and 10 screenshot signatures.")
    print("NOTE: No application quality checks have run yet.")


def main():
    try:
        verify()
    except (OSError, ValueError) as error:
        print(f"FAIL: {error}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
