# Quality checks

Before writing app code, run `python quality/verify_harness.py` (Windows: `py quality/verify_harness.py`). This requires the complete manifest and verifies packaged inputs and screenshot format before app files are created.

After the app is scaffolded:
1. Copy `quality/checks.example.json` to `quality/checks.json` and edit paths/commands for the actual project. Only include checks that exist; do not quietly remove required categories without documenting why.
2. Run `python quality/run_checks.py` to execute the commands with real exit codes. Missing configuration is a **failure** (not a passing skip).
3. Adapt `quality/ci-rails-react.yml.template` to actual runtime and locations; then enable required CI checks.
4. Run safety scenarios, the performance check in `docs/PERFORMANCE.md`, and the AI grading loop in `docs/REVIEW_RUBRIC.md`. Record the final gate and rubric results for the same implementation.

The bundled checks and templates are not automatically installed or enabled just by unzipping.

The workload probe adds Rails result rows and affected rows when the adapter reports them. Zero row counts and absent telemetry have distinct counters. See `docs/PERFORMANCE.md` for fixture design and complete-operation checks.

## Task completion

Apply the completion gate in `docs/TASK_EXECUTION_STANDARD.md` after the relevant checks run. The command runner reports command results. The reviewer checks the task scope, readability, and evidence. A passing command runner does not establish task completion on its own.

## Mandatory Active Record check

Set `rails_root` in `quality/checks.json` to the actual Rails directory. Prepare the test database through the documented setup before running the gate. The runner always adds the migrated-data Active Record source check before the configured checks. The check cannot be removed by omitting it from that list. A source-check failure fails the gate. Read the actual query sources during review as well.
