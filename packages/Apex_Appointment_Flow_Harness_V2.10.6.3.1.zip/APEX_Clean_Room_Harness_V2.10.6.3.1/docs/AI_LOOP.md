# AI grading and repair loop

## Record the implementation

Create a local checkpoint of the working implementation and its tests before the first grade. Record its exact revision. Discover the material workflows, decision owners, and applicable checks from the task, accepted project policy, and actual code.

## Review through real callers

Apply `REVIEW_RUBRIC.md`. Select a consequential claim with weak coverage and challenge it through its normal caller. Use existing tests when their assertions prove that claim. Add a focused check when required evidence is missing. For performance claims, use `PERFORMANCE.md` and measure the complete operation, including first population, repeats, growth, and derived-data maintenance where applicable.

A separate AI reviewer can inspect the implementation and run these project checks when the environment supports it. Otherwise, record a dedicated self-review. The AI owns each grade and its evidence. The user does not need to inspect code to validate the grade.

## Repair verified findings

Confirm each finding against current source and accepted policy. Fix the smallest responsible owner. Preserve the task's required behavior and scope. Reproduce the failure when practical, repair it, and rerun the affected checks and relevant neighboring behavior. Review shared prerequisites when a repair changes them. Record the finding, implementation checkpoint, repair, and observed result.

## Verify and grade the finished code

Run the configured quality gate and full rubric against the finished implementation. Carry forward evidence only when its code and inputs still apply, and state that reason. Failed required checks remain REVISE. Missing required evidence remains UNVERIFIED. Report the precise prerequisite and recovery attempts when work is blocked. Continue the internal repair loop until the required criteria pass or the remaining work requires an unavailable prerequisite. Freeze the checked revision and give the four-part final report.
