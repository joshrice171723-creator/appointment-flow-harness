# Review checklist (copy to each review when implementation begins)

- [ ] Requirement IDs and scope are explicit; no unauthorized extra features.
- [ ] No older assessment code, history, prompts, or data was imported.
- [ ] Correct recipient, clinic, appointment, timing, and confirmation identity verified.
- [ ] Reschedules/cancellations/replication delay addressed to the agreed extent.
- [ ] Repeated reminder runs and fake provider failures cannot silently create duplicate confirmations/sends.
- [ ] Sensitive details omitted from outbound bodies/logs; fake data and providers only.
- [ ] Plain, idiomatic Ruby/Rails and React/TypeScript; unnecessary abstractions removed.
- [ ] Tests for behavior and important edge cases; test/lint/type checks reported honestly.
- [ ] Narrow diff; no unrelated edits, unneeded deps, or disabled checks.
- [ ] The AI traced a representative workflow and identified the rule owner and focused check for a plausible change.
- [ ] The AI verified the decision notes, README, architecture, and AI usage record against the implementation.
- [ ] Final grade and repair evidence recorded in `review/RUBRIC_RESULTS.md`.
