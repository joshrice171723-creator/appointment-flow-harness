# Optional interview rehearsal

Use this prompt when the candidate requests interview practice separately from the AI grading loop.

Without consulting any old assessment implementation, question the candidate about THIS new project's actual code, tests, architecture, and decisions. Use the employer's criteria: correctness, judgment, ownership, clarity, and proportion.

Ask realistic, **specific** questions about message recipient selection, timezone/wall-clock data, update/reschedule race cases, confirmation identity, retry/idempotency, clinic privacy, why this architecture rather than a simpler one, rejected alternatives, and how to add or change a small feature live. Make the candidate answer in their own words, then flag claims not supported by code/tests. Do not invent test results, backfill answers, or substitute a prewritten script for understanding.
