# Post-freeze comparison protocol (DO NOT perform during development)

Purpose: compare the new independently built application with the old baseline only **after** the new code is complete, tested and frozen.

Before comparison:
1. Record new build commit hash and environment versions.
2. Record the final AI rubric grade and actual check results. Freeze the decision notes and architecture.
3. Create a reproducible test fixture set and document known gaps.
4. Ask the user to **explicitly authorize** opening the original project.

After authorization, compare on the same feature scenarios:
- Correctness in S01–S20; failures and safety regressions.
- Rails/React readability and ease of change assessed by an AI applying the same rubric to each anonymized build.
- Architectural complexity: unnecessary layers and cross-file indirection.
- Feature completeness, UI state coverage, ease of local setup, testing and documentation.
- Engineering ownership evidenced by an AI trace of the decision, its owning code, and the checks for a plausible change.

Don't use the old code to train/refine the new implementation before freezing it. Record all deviations and exclusions in the comparison.
