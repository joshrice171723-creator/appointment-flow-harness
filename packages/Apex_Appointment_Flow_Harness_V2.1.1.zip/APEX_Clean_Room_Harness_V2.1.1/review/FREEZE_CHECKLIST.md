# Technical freeze checklist

The implementation agent completes this checklist from the current build's evidence.

- [ ] Exact implementation revision or snapshot and runtime versions recorded.
- [ ] Local boot, seed, reminder run, and fake SMS/email reply paths verified.
- [ ] Final configured quality gate passed on the revision being frozen.
- [ ] `review/RUBRIC_RESULTS.md` lists each grading round and the evidence for a final overall PASS.
- [ ] Each required rubric criterion passed and fixes were verified.
- [ ] README, architecture, AI usage record, factual decision notes, and known limitations checked against the build.
- [ ] Clean-room source isolation preserved.

Report any blocker in `review/RUBRIC_RESULTS.md` and keep the technical freeze incomplete until the rubric passes.
