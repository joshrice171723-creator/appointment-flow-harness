# Clean-room acceptance checklist

Report each item PASS / FAIL / NOT RUN, link to test filename or manual evidence. Do not treat unchecked items as passing. `official` means mandated by the assignment PDF; `extended` describes the user's observed product.

## Official brief
- [ ] [official] App finds upcoming unconfirmed visits from provided PMS PostgreSQL schema.
- [ ] [official] Local fake/sandbox SMS **and** email paths can send pre-appointment notifications on documented cadence.
- [ ] [official] Confirmation replies produce a recorded appointment confirmation state.
- [ ] [official] Staff UI exposes upcoming appointments and confirmation state by clinic.
- [ ] [official] App starts locally with realistic **fictional** seed data and automated tests.
- [ ] [official] README, architecture/state-flow diagram, and AI_USAGE are present and accurate. The employer also requires candidate-authored DECISIONS for assessment submission. The AI verifies factual decision notes as part of the technical freeze.

## Product workflows (extended)
- [ ] [extended] Three separate workspaces function and front-desk identity/clinic selection scopes data.
- [ ] [extended] Board shows Needs attention/In progress/Resolved, search/filter/pagination, assignment and follow-up recording.
- [ ] [extended] Appointments calendar has date navigation, state tabs, and patient details navigation.
- [ ] [extended] Patient details display verification state and safe local corrections, without source PMS writes.
- [ ] [extended] Patient SMS and email simulation surfaces message history and reply form.
- [ ] [extended] Leadership compares clinic and month outcomes, with no identifiable data.
- [ ] [extended] Visual layout matches broad screenshot structure and color/typography identity on desktop, with usable narrow viewport.

## High-risk correctness
- [ ] [safety] S01–S03 confirm/recurrence/reschedule correctness; old YES never blindly confirms changed time.
- [ ] [safety] S05–S06 and S15 prove send/reply deduplication on retries and concurrent batches.
- [ ] [safety] S08–S09 reject late retroactive confirmation and preserve STOP opt-outs.
- [ ] [safety] S10–S13 prove clinic isolation, shared-contact handling and contact holds.
- [ ] [safety] S14 protects against failed/source-empty refresh.
- [ ] [safety] S16–S17 separate confirmed vs completed and enforce leadership de-identification.
- [ ] [safety] No reminders at/after visit start; clinic-local times correctly interpreted.
- [ ] [safety] No real patient data, secrets, or live vendor messages in the demo.

## Build and quality
- [ ] [quality] Project lints, typechecks, tests and builds with the configured commands.
- [ ] [quality] All important UI actions have real behavior and visible error/empty/success states.
- [ ] [quality] The AI reviewed the actual implementation and recorded a passing grade with evidence for every required criterion.
- [ ] [quality] New code has never accessed/copy-pasted from old repository.

## Important reporting rule
The previous submission's behavior notes contain some implementation-specific choices. These are **illustrations**, not mandatory backend architecture. A scenario can be met with a different design, provided the user-visible result and safety invariants hold.
