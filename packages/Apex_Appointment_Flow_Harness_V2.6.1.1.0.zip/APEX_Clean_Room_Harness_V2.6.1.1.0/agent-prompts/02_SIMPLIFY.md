Review the current **new-project** diff only. Focus strictly on simpler, more idiomatic, human-readable Ruby on Rails / React / TypeScript implementations. Do not modify unrelated files or introduce new abstractions to satisfy abstract clean-code slogans.

For each potential change, explain the real maintenance/correctness benefit. Prefer direct control flow, cohesive responsibilities, descriptive names, one owner for shared rules, minimal React state and effects, and ordinary Rails idioms. **Do not flatten necessary domain boundaries**, delete important tests, change externally visible behavior, or weaken privacy and idempotency logic.

## Check consequential workflows during implementation

Find them from this slice's real entry points and shared operations. A workflow merits this check if it introduces or changes an important business decision, coordinates writes or an outside dependency, or can do increasingly expensive work with more data or more calls. Reuse evidence for an unchanged workflow reached by a new caller when the contract and work are equivalent.

1. Start at the caller. Read the rule owner's entry point before its private methods. Trace the ordinary case to the visible result, including the data needed and the writes. Give distinct stages or important decisions meaningful private names when that makes the sequence or edit location easier to find.
2. Exercise a relevant rejection. Where multiple writes are supposed to commit together, verify persisted state after an induced failure following a meaningful write. Identify the transaction owner, which failure can be handled there, the caller's response, and any surviving state or retry. Use an existing test if it proves the transition.
3. For material data growth or repetition, use the workload check in `docs/PERFORMANCE.md` from the real caller. Prefer ordinary Active Record when it expresses the same rule clearly. Inspect the callers of shared work before adding caching, concurrency, or a new abstraction.

Run the focused slice checks and repair verified material issues before building dependent work. Reuse their commands and results in the existing build log. If a dependency genuinely prevents a check, record the blocker and the exact missing evidence. The independent review still verifies the finished behavior.

At a material database decision, compare the caller's needed result with the rows and fields fetched. Check repeated lookups, batch writes, and the retry or reject path under the owning transaction. Use the existing slice evidence and `docs/PERFORMANCE.md`. Record one concrete observation if it could change the design.
