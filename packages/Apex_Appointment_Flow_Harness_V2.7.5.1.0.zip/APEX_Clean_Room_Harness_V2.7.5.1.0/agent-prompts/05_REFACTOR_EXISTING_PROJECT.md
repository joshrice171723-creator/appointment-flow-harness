# Refactor an existing project

Work in the supplied disposable clone. Read `AI_USAGE.md` and `DECISIONS.md` in full when supplied. Treat the user's accepted product and engineering decisions as constraints and preserve those documents. Use the current harness for implementation, performance checks, and grading.

When preparing an isolated trial, omit previous coding guides and grading rubrics from the builder's working tree. Preserve the accepted product documentation and record which guidance the builder received.

Trace the requested workflow from the caller to its result. Record the public behavior, source boundaries, and rule owners before editing. Keep the change scoped to the requested workflow and its directly necessary code or tests. Use standard Active Record for application queries and apply the query-source and workload checks in `docs/PERFORMANCE.md`.

Read the supplied external PMS schema before choosing a design. For Appointment Flow, see pages 2–3 of the assignment PDF. Keep that source contract fixed, including the schema, available fields, and read-only access. The app-owned mirror can change within the requested refactor. Use the data the external source already provides. If the mirror changes, verify initial population, legacy records, source updates, and retries where they affect the rule.

Make one measurable change at a time. Verify equivalent behavior and persisted effects on the same before-and-after workload. Repair regressions, rerun affected checks, and record the exact revision checked. Keep the repeatable probe and raw measurements with the trial evidence so the next slice can reuse them. Report gaps honestly. Keep the result local for review.
