# Quality checks

Before writing app code, run `python quality/verify_harness.py` (Windows: `py quality/verify_harness.py`). This requires the complete manifest and verifies packaged inputs and screenshot format before app files are created.

After the app is scaffolded:
1. Copy `quality/checks.example.json` to `quality/checks.json` and edit paths/commands for the actual project. Only include checks that exist; do not quietly remove required categories without documenting why.
2. Run `python quality/run_checks.py` to execute the commands with real exit codes. Missing configuration is a **failure** (not a passing skip).
3. Adapt `quality/ci-rails-react.yml.template` to actual runtime and locations; then enable required CI checks.
4. Run safety scenarios, the performance check in `docs/PERFORMANCE.md`, and the AI grading loop in `docs/REVIEW_RUBRIC.md`. Record the final gate and rubric results for the same implementation.

The bundled checks and templates are not automatically installed or enabled just by unzipping.

The quality gate always runs the Active Record query source check against the migrated test database. For a focused slice, run `ruby bin/rails runner -e test ../quality/check_active_record_queries.rb` from the `backend` directory. Set `rails_root` in `checks.json` if Rails lives elsewhere. The check flags common handwritten SQL call sites and models mapped to views in the local test schema. The independent reviewer traces dynamic queries and other database dependencies for material callers.

The workload probe adds Rails result rows and affected rows when the adapter reports them. Zero row counts and absent telemetry have distinct counters. See `docs/PERFORMANCE.md` for fixture design and complete-operation checks.
