# START HERE — one-file handoff for a clean-room Apex rebuild

This is a **specification + coding-quality harness**, not an application. It combines the official Apex take-home PDF, ten supplied screenshots, behavior-only specs reconstructed from the user's notes, testing and review rules, and starter agent prompts. It contains **no old application code**.

## In RubyMine

1. Extract this ZIP into a **brand-new empty directory**, separate from all previous appointment-flow repositories and copies. RubyMine cannot execute a ZIP as a code agent: open the **extracted directory** with File > Open.
2. Start your Codex or Claude Code agent inside RubyMine. If it doesn't read `AGENTS.md` automatically, explicitly include it in the agent context.
3. Open `RUN_THIS_IN_RUBYMINE.md` and **paste its complete contents into the agent**. This is the single entrypoint. It instructs the agent to read and verify the harness *before* writing code, then build from scratch.
4. This is a permitted AI-assisted interview exercise, but the assignment requires that **you personally write `DECISIONS.md` in your own words** and be able to defend the new implementation live. The coding agent should generate tradeoff notes, not a falsely attributed personal essay.
5. A full implementation requires local Ruby, Rails, Node, PostgreSQL and the agent to be available. Start a fresh agent session with optional skills and review plugins off. See `docs/AGENT_SETUP.md` for the run setup.

## Contents

- `reference/Appointment-Confirmation-Take-Home.pdf` — original five-page assignment, authoritative.
- `reference/screenshots/` — **10 images**, no source code; named in `product-spec/SCREENSHOT_INDEX.md`.
- `product-spec/` — clean-room product brief, behavior, journeys, test scenarios, acceptance checklist, visual design brief and **known input gap**.
- `AGENTS.md` / `docs/` — Rails/React quality standards and architecture controls.
- `agent-prompts/` — suggested slice, simplify, independent review, and defense review prompts.
- `quality/` — harness integrity check; gated app checks and CI templates to configure **only after scaffolding**.
- `templates/` — incomplete deliverable outlines; your own explanations and tradeoffs are required.

## Visual reference completeness

All ten screenshots, including `10-patient-inbox-email.png`, are included. Screenshot contents demonstrate visible UI states only, not the underlying behavior or implementation. The Email-tab image shows an empty simulated-email state for a selected patient.

## Evidence precedence

Official assessment > behavioral requirements and acceptance scenarios > screenshots for visible appearance > coding-quality rules. Screenshots show sample UI states, **not** internal architecture and not proof of hidden interactions. Unverified legacy decisions do not become architectural prescriptions.

## Assessment limitations

The original submission may have already occurred; this package makes no claim that a new submission is authorized. Use this as a learning/quality-harness experiment unless separately permitted by the employer. No external service or old private repository is accessed by this package.
