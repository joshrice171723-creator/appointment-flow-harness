# Paste this file into a RubyMine coding-agent session

You are the implementation agent for a clean-room quality-harness evaluation. Build a **new** Rails + React version of the Apex appointment-confirmation product using ONLY this ZIP's assessment document, included UI screenshots, sanitized product specification, and engineering rules. A separate old implementation exists but is forbidden to access until this rebuild is completely finished and frozen. The purpose is to test whether the harness creates a high-quality implementation, not whether it can reproduce old code.

## Mandatory sequence — start immediately

Use a fresh agent session with optional skills and review plugins off. Capture the agent/model, any required host guidance still active, and the Stage 0 start time in the session. Add those details to the build log after preflight passes. After preflight passes, record that start time and subsequent phase timestamps in `notes/BUILD_LOG.md`.

**Stage 0: Harness setup, before application code.** Read `AGENTS.md`, `START_HERE.md`, `reference/Appointment-Confirmation-Take-Home.pdf`, every file in `product-spec/`, then `docs/CODING_STANDARDS.md`, `docs/ARCHITECTURE_GUARDRAILS.md`, `docs/REVIEW_RUBRIC.md`, and `docs/DELIVERABLES_AND_DECISIONS.md`. Run `python quality/verify_harness.py` (Windows: `py quality/verify_harness.py`). Confirm the screen count from the actual filesystem. Confirm the Email-tab screenshot is included, read it, and do not infer hidden behavior from it. State a concise implementation plan and identify decision points. Do not read old code, and do not write app code until this Stage 0 plan has been established.

**Stage 1: Independent design.** Choose the smallest understandable Rails + React solution that can meet the *official* scope and present the UI/workflows shown. Use appropriate current stable runtime and tool versions available on the user's machine; document the exact versions. No mandated classes, API routes, component structure, background job product, global store, or folder split. The picture and written behavior are inputs, not an architecture blueprint. Explicitly address reminder scheduling, safe reply matching, reschedules, clinic isolation, read-only PMS boundary, timezones, fake transport, and testability.

**Stage 2: Scaffold and implement.** After the Stage 0 plan is captured, proceed with implementation in small working vertical slices without asking about ordinary, reversible choices. Prioritize a runnable app and the official core requirements; then add the visual workflows and safety-sensitive extended behavior within scope. No pixel-perfect mandate: retain the warm neutral / dark-green visual identity and the main navigation patterns. Seed **fictional** records representing Austin and Phoenix and enough cases to exercise each state. No live external messaging. After the first working Rails write path, use the existing simplify pass to trace its route, rule owner, transaction, and response. If a multi-step service owns the operation, check its public workflow and private steps. Trace a successful and a rejected path before repeating that structure across endpoints. Apply the Rails responsibility boundaries before adding the remaining endpoints. For each slice, test behavior and simplify the real diff before adding new abstractions. Keep a compact progress record in `notes/BUILD_LOG.md`.

**Stage 3: Working local demo.** Document one reproducible startup path from a clean checkout, how to seed, how to trigger a reminder batch manually, how to simulate SMS/email replies, how to inspect sent fake messages, and how to run all checks. If prerequisites are not available, describe the exact blocker and give tested partial steps; do not fabricate success.

**Stage 4: Verify independently.** Configure `quality/checks.json` using the actual structure after scaffolding; execute `python quality/run_checks.py`. Run tests for high-risk scenarios in `product-spec/SCENARIOS.md`, plus UI smoke checks and a separate code-review session per `agent-prompts/03_INDEPENDENT_REVIEW.md`. Resolve verified material findings before freeze. After repairs, run focused checks and run the configured gate on the final implementation if earlier results were invalidated. Reuse results supported by the same code and inputs. Record uncovered paths explicitly.

**Stage 5: Candidate-owned deliverables and freeze.** Produce a usable `README.md`, an honest `AI_USAGE.md`, and an architecture diagram. Create only **decision notes** for the candidate to turn into their own `DECISIONS.md`; do not write the final decision narrative as their words. Produce `review/FREEZE_CHECKLIST.md` with actual results, commit hash if one exists, known limitations, and instructions to preserve this version for a later blind comparison. Do not access the old repo during this stage. Do not push or submit anything without explicit authorization.

## Agent interaction rules
- Do not ask broad stylistic preference questions. Make reasonable, documented choices.
- Stop and ask only for a blocking prerequisite, a truly consequential irreversible choice, or required permission.
- Explicitly distinguish **observed in screenshot**, **provided in spec**, **chosen for rebuild**, and **verified by test**.
- Use this ZIP's instructions for planning, implementation, and review. Standard IDE and framework tools are available for development and verification.
- Keep the new implementation fully independent until the user explicitly authorizes final comparison.

Begin Stage 0 now, in this directory.
