# Independent code review rubric

The reviewer must inspect the actual diff, tests, relevant call sites, and changed database behavior without treating the implementer's explanation as proof.

## Blocking findings (fix before accepting)

- Could contact the wrong person, expose patient/clinic information, confirm the wrong appointment, or send live messages accidentally.
- Incorrect handling of appointment reschedules/status changes or timezones that affects user-facing state/reminder eligibility.
- Concurrency/retry behavior demonstrably duplicates reminders (unless a documented, knowingly accepted limitation).
- Tests fail, are skipped to hide a regression, or assert a false/fabricated success.
- Code violates an explicit assessment requirement or adds prohibited scope.

## Major findings (fix or make an explicit decision)

- Reasonably likely behavior regressions; missing essential edge-case tests.
- Deeply nested or opaque control flow; needless abstractions that obscure actual behavior.
- Unidiomatic ActiveRecord/React lifecycle usage that makes changes difficult.
- A multi-step service buries its workflow or a meaningful business decision in low-level details, or exposes internal helpers in a way that obscures its supported interface. Cite the step an engineer would struggle to trace or the specific method callers are meant to use.
- A service does avoidable work before it can reject unusable input, obscures which writes commit on failure, or reports an unrelated error cause. Show the affected success or rejection path and its consequence.
- Unrelated HTTP responsibilities grouped together or a cross-record rule and transaction buried in request handling when this makes a specific change harder to trace or verify. Show the route and the rule owner.
- Reimplementation of existing helpers; duplicate business rules; status values with inconsistent meanings.
- Missing validation of untrusted input or missing backend clinic-scoping enforcement.

## Minor findings

- Local naming, simple duplication, unclear comments, small readability opportunities. Do not demand refactoring with no demonstrable improvement.

## Review report format

1. **Verdict:** Ready / Needs fixes / Not reviewed (say which).
2. **Findings:** severity, exact `path:line`, behavior/risk, minimal fix, and whether verified or speculative.
3. **Missing evidence:** tests/conditions not run or not examined.
4. **Done well:** 1–3 specific examples, not generic praise.
5. **Decision questions:** only material ambiguities.

## Six-category comparative quality score (optional, not validated benchmark)

Human reviewers may score 0–5 each for correctness, readability, Rails/React idioms, proportionate abstraction, maintainability, and test quality. Scores are subjective and **not** proof of objectively superior code. Use a blind comparison of equivalent tasks where possible. Track regression counts and actual reviewer fixes separately. **Do not view/import the old baseline until the new project is declared finished.**
