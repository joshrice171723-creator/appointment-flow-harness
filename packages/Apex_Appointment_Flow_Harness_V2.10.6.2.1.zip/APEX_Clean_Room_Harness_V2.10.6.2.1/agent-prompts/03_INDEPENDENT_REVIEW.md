Act as an independent reviewer. Do not assume the implementing agent's summary proves correctness. Read `AGENTS.md`, `docs/REVIEW_RUBRIC.md`, `docs/ASSESSMENT_REQUIREMENTS.md`, and `docs/ACCEPTANCE_MATRIX.md`; inspect the actual diff and nearby call sites/tests.

Review first for: wrong-recipient or PHI exposure; appointment-reschedule correctness; fake-vs-live messaging; confirmation matching; duplicate send/parallel retry; clinic scope; timezones/DST; missing behavior tests. Then inspect maintainability: Rails idioms, React state/effects, duplication, unnecessary layers, naming, complexity, and test quality.

After the build, review the route map for controller cohesion. Check where HTTP handling, domain rules, and persistence coordination live. Flag a verified ownership problem when it makes a rule harder to understand, test, or change. Identify the material workflows from the actual routes, jobs, and call sites, including shared operations. Review each material workflow using the existing rubric. Use the product scope and code to decide which criteria apply. Follow material paths from caller to result and keep the depth of review proportional to their impact. Check how the work grows with unrelated data, including records loaded, repeated queries, and transaction or lock scope where applicable. Pick a plausible change to a business rule and identify the owning edit and focused check. Trace one failure through rollback, any state that survives, and the caller's response. Ground the review in the code path, observed SQL, or focused tests. Report measured and source-inferred costs with their evidence.

Inspect the multi-step workflows owned by controllers, services, or other rule owners. For a detailed trace, start with the public entry point and reconstruct the workflow before opening its private helpers. Reuse existing evidence for the same path and choose detailed traces where they resolve a material judgment.

- Trace one successful path and one rejected path. For each, identify the records loaded, when validation runs, which writes can happen, what commits or rolls back, and what the caller receives. Where atomicity matters, choose a failure that exercises the rollback guarantee and use a focused check when the existing evidence leaves it uncertain.
- Verify who calls each public method. Identify the transaction owner, the boundaries that explain failures, and the exact method to edit for one plausible business-rule change. Record the relevant code paths and distinguish executed checks from source observations.

Apply the performance check in `docs/PERFORMANCE.md` to the two paths selected from the built app. Verify the recorded evidence fits the current revision and check an uncertain result when needed.

Record each criterion and the overall grade using `docs/REVIEW_RUBRIC.md`. Name the material workflows examined and cite the code and actual evidence. For each confirmed material deficiency, give its consequence, the smallest remedy, and how to verify it. The implementation agent makes repairs and requests another grading pass. The AI owns all review and validation. Use a separate AI reviewer when supported, or record a dedicated grading pass in the implementation agent when needed.

Use the current revision's actual query trace or run the missing focused check. For ease of change, use a disposable copy and verify a plausible rule change through its real caller. Report where you found the rule, what you touched, what still passed, and the revision reviewed.

Read the task execution standard. Apply its completion gate to each grade and regrade. See `docs/TASK_EXECUTION_STANDARD.md`.

Run the Active Record source check on the migrated test database. Trace the actual relation sources and derived-data update owners. Grade the complete operation, including first population and unchanged retries. Check meaningful responsibility grouping and namespaces under `docs/ARCHITECTURE_GUARDRAILS.md`.

Follow `docs/AI_LOOP.md` for the first freeze, independent benchmark, repairs, and final regrade. For links within `docs/`, the file is `AI_LOOP.md`. The launcher supplies the independent benchmark inputs after the initial checkpoint. Record initial and final results on their exact revisions.
