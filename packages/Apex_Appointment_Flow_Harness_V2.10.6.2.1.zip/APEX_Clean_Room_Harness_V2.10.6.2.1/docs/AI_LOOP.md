# AI grading and benchmark repair loop

## Freeze the first implementation

Create a local checkpoint of the first working implementation and its tests before independent evaluation. Record its exact revision. Keep the independent evaluator's comparison fixtures, earlier implementations, and known fixes outside the builder's initial context.

## Run the independent benchmark

Use the versioned benchmark supplied by the launcher for this project. In this experiment, the evaluator supplies Appointment Flow Performance Benchmark V1.0.0 after the first checkpoint. The evaluator runs its applicable groups on the frozen implementation through normal callers. Record the benchmark name, version, source revision, inputs, actual results, and unsupported or unavailable groups. Preserve the existing fixed measurement and scoring method supplied for the comparison. Missing evidence cannot earn a passing grade or a fabricated score.

The evaluator gives verified findings and reproducible evidence to the repair agent after this first freeze. The AI owns the evaluation, repairs, and verification. The user does not need to read code to approve a grade.

## Repair and check the result

Confirm each finding against the source and accepted project policy. Repair the responsible owner within the requested scope. Use the supplied failure evidence to rerun the affected group and its relevant neighboring behavior. Run additional groups when the change affects their shared prerequisite. Record each implementation checkpoint, finding, repair, and actual result. Keep the same benchmark contract and scoring method across these rounds.

## Regrade the final revision

Run every applicable required benchmark group on the final implementation after repairs. Run the configured quality gate and the full rubric on that revision. Carry forward a check only when its implementation and inputs still apply, and explain that decision. A failed required group remains REVISE. A group with missing evidence remains UNVERIFIED. Record a specific unavailable prerequisite and recovery attempts when work is blocked. Continue the AI repair loop until the required criteria pass or a prerequisite prevents the remaining work. Freeze the checked revision and preserve the initial and final evidence separately.
