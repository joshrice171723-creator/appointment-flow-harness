# Performance

Performance is the elapsed time of a complete operation and how its database work, application work, and lock scope grow with data or use.

| Dimension | Poor example | Better example |
|---|---|---|
| Data scope | Load the entire record history for a dated, paginated view. | Filter to the requested owner and time window in Active Record, and retrieve the page before loading its related data. |
| Repeated work | Look up or prepare the same parent record for every child in a batch. | Fetch the needed records once and reuse the result. |
| Existence and aggregation | Materialize records for a boolean or issue separate counts for each status. | Use a scoped `exists?` or `group(:status).count` when it answers the same question. |
| Writes | Update one parent timestamp for every child processed. | Record one logically shared update in the transaction that commits the work. |
| Locks and retries | Serialize independent work or repeat already committed work after a partial failure. | Match the lock to the consistency boundary and verify what a retry repeats or skips. |
| Measurement | Time a helper in isolation or count one query that returns an entire history. | Measure the complete caller operation, SQL statements, and rows returned or loaded. |

## Post-build workload check

The AI selects one consequential read and one write or batch from the finished app. Run each against a small synthetic fixture and against the same relevant records plus more unrelated history. Keep inputs, expected behavior, and measurement conditions comparable. Record elapsed time, SQL counts, and relevant row counts for both workloads. Explain the work that grows and any transaction or lock scope that matters. Where a real retry path is part of the operation, check what repeats after a controlled failure.

Use small repeatable fixtures and existing test or query instrumentation. Record the commands, inputs, and results. Fix verified waste that materially affects the agreed scope, and rerun the affected comparison. Recognize justified growth when the operation actually has more relevant work to do. Production capacity requires separate evidence.
