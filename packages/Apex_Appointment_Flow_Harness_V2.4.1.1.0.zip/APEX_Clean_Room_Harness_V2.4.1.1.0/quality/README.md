# Quality checks

Before writing app code, run `python quality/verify_harness.py` (Windows: `py quality/verify_harness.py`). This checks files, screenshot count/signatures and SHA-256 manifest, not app behavior.

After the app is scaffolded:
1. Copy `quality/checks.example.json` to `quality/checks.json` and edit paths/commands for the actual project. Only include checks that exist; do not quietly remove required categories without documenting why.
2. Run `python quality/run_checks.py` to execute the commands with real exit codes. Missing configuration is a **failure** (not a passing skip).
3. Adapt `quality/ci-rails-react.yml.template` to actual runtime and locations; then enable required CI checks.
4. Run safety scenarios, the performance check in `docs/PERFORMANCE.md`, and the AI grading loop in `docs/REVIEW_RUBRIC.md`. Record the final gate and rubric results for the same implementation.

The bundled checks and templates are not automatically installed or enabled just by unzipping.
