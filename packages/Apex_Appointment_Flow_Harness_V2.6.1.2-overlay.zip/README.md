# V2.6.1.2 refactor overlay

Apply the enclosed guidance with V2.6.1.1.0 in a copy of an existing app.
