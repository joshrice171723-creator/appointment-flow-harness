"""Run the original job on a mixed ticket-and-reminder fixture in the benchmark's isolated database."""

from appointment_benchmark import run
from pathlib import Path


def capture(folder, label, command, *args, **options):
    if label == "summary":
        return
    if label == "benchmark":
        command = [*command[:-1], Path(__file__).with_name("original_ticket_spa_probe.rb")]
    return original_capture(folder, label, command, *args, **options)


original_capture = run.capture
run.capture = capture
run.main()
