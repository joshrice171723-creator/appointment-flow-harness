# Original reminder job and PMS benchmark

This run used the original frozen Rails app at `db037d7932b13fc4d735106e0fa199815fb2d22c`. The measured code is `ReminderRunner.tick`. The four scenarios use synthetic data and a private, loopback PostgreSQL instance.

## Reproduce

From this extracted ZIP, use the original app checkout with its locked Ruby gems installed. Use Python 3.11+ and local PostgreSQL 17. Pass your PostgreSQL binary directory when it differs from the Windows default.

```powershell
python run_original_ticket_spa_probe.py --project C:/path/to/appointment-flow --revision db037d7932b13fc4d735106e0fa199815fb2d22c --adapter original --output results
python summarize_reminder_job.py results/<run-folder> comparison.csv
```

The growth case adds 2,000 unrelated patients with no appointments and unique contact values. Each fixture starts with the same 24 appointments. Each first tick must record 16 tickets and 16 fake emails. Each same-clock retry must add zero tickets or sends. The log records direct PMS statements separately from the Rails SQL events. Fixture setup is outside the timed tick.

To verify the saved traces, run `python summarize_reminder_job.py evidence reconstructed.csv`.
