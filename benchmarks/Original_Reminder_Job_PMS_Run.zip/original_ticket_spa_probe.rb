require "uri"
require "active_support/testing/time_helpers"
require_relative "appointment_benchmark/fixture"

include ActiveSupport::Testing::TimeHelpers

def verify_isolation!
  db = ActiveRecord::Base.connection_db_config
  port = ENV.fetch("PGPORT").to_i
  source = URI(ENV.fetch("PMS_ADMIN_URL"))
  raise "Expected private synthetic databases" unless Rails.env.test? &&
    db.database == "apex_benchmark_test" && db.configuration_hash[:host] == "127.0.0.1" &&
    db.configuration_hash[:port].to_i == port && source.host == "127.0.0.1" && source.port == port &&
    source.path == "/apex_benchmark_source_test"
end

def measure_tick(label)
  Thread.current[:audit_case] = label
  started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  OriginalWorkflow.batch(label)
  AuditTrace.record("outcome", duration_ms: (Process.clock_gettime(Process::CLOCK_MONOTONIC) - started) * 1000)
ensure
  Thread.current[:audit_case] = nil
end

def outcome
  sizes = Message.sent.pluck(:body).map(&:bytesize)
  {
    cases: FollowUpCase.count, issues: FollowUpIssue.open.group(:code).count,
    sent: sizes.size, failed: Message.where(status: "failed").count,
    message_items: MessageItem.count,
    activity_events: ActivityEvent.group(:kind).count,
    body_bytes: { min: sizes.min, max: sizes.max, total: sizes.sum }
  }
end

def measure_mixed_fixture(name, extra_patients:)
  fixture = { due: 24, older_appointments: 0, extra_patients: extra_patients, later_appointments: 0 }
  OriginalWorkflow.prepare(ActiveRecord::Base.lease_connection, fixture)
  PG.connect(ENV.fetch("PMS_ADMIN_URL")) do |source|
    source.exec("UPDATE pms.appointments SET start_at = TIMESTAMP '2026-11-17 14:00:00' WHERE id BETWEEN 9 AND 16")
    source.exec("UPDATE pms.patients SET email = NULL WHERE id BETWEEN 17 AND 24")
  end

  measure_tick("#{name}/first_tick")
  first = outcome
  raise first.inspect unless first.values_at(:cases, :sent, :failed, :message_items) == [16, 16, 0, 24]
  raise first.inspect unless first[:issues] == { "contact" => 8, "no_response" => 8 }
  raise first.inspect unless first[:activity_events] == { "issue_opened" => 16, "sent" => 16 }
  AuditTrace.record("ticket_result", case_name: "#{name}/first_tick", source_patients: 24 + extra_patients, **first)

  measure_tick("#{name}/same_clock_retry")
  retry_result = outcome
  raise retry_result.inspect unless retry_result == first
  AuditTrace.record("ticket_result", case_name: "#{name}/same_clock_retry", source_patients: 24 + extra_patients, **retry_result)
end

verify_isolation!
require_relative "appointment_benchmark/original"
travel_to BenchmarkFixture::NOW
measure_mixed_fixture("mixed", extra_patients: 0)
measure_mixed_fixture("mixed_extra_patients", extra_patients: 2_000)
puts "Both fixtures produced 16 tickets, 16 sends, and no new tickets or sends on retry."
