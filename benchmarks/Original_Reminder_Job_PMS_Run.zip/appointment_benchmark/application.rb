require_relative "fixture"
require "active_support/testing/time_helpers"
require "action_dispatch/testing/integration"
require "json"
require "uri"
include ActiveSupport::Testing::TimeHelpers

module BenchmarkMeasurement
  def self.measure(name)
    Thread.current[:audit_case] = name
    start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    result = yield
    elapsed_ms = (Process.clock_gettime(Process::CLOCK_MONOTONIC) - start) * 1000
    AuditTrace.record("outcome", result: result, duration_ms: elapsed_ms)
    result
  ensure
    Thread.current[:audit_case] = nil
  end

  def self.assert_local_database
    config = ActiveRecord::Base.connection_db_config
    settings = config.configuration_hash
    raise "Use the isolated benchmark database" unless Rails.env.test? &&
      config.database == "apex_benchmark_test" && (settings[:host] || ENV["PGHOST"]) == "127.0.0.1" &&
      (settings[:port] || ENV.fetch("PGPORT")).to_i == ENV.fetch("PGPORT").to_i
  end
end

BenchmarkMeasurement.assert_local_database
style = ENV.fetch("BENCHMARK_ADAPTER")
load File.expand_path(ENV.fetch("BENCHMARK_ADAPTER_FILE")) if style == "custom"
require_relative "original" if style == "original"
now = BenchmarkFixture::NOW
visit_date = BenchmarkFixture::APPOINTMENT_DATE
travel_to now
connection = ActiveRecord::Base.lease_connection

def prepare(style, db, fixture)
  case style
  when "original" then OriginalWorkflow.prepare(db, fixture)
  when "custom" then CandidateWorkflow.prepare(db, fixture)
  else
    BenchmarkFixture.clear_local(db, %w[public pms])
    BenchmarkFixture.seed(db, fixture)
    case style
    when "direct_replica"
      ClinicState.create!(id: 1)
      ContactDirectory.create!(id: 1)
      [1, "Morgan"]
    when "token_projection"
      [Clinic.create!(id: 1, name: "Benchmark Clinic", timezone: "America/Chicago", staff: ["Morgan"]), "Morgan"]
    when "staff_projection"
      clinic = Clinic.create!(source_id: 1, name: "Benchmark Clinic", timezone: "America/Chicago")
      [clinic, clinic.staff_members.create!(name: "Morgan").id]
    else raise "Unknown benchmark adapter #{style.inspect}"
    end
  end
end

def batch_for(style, checkpoint, clinic, now)
  case style
  when "original" then OriginalWorkflow.batch(checkpoint)
  when "custom" then CandidateWorkflow.batch(clinic, now)
  when "direct_replica" then ReminderBatch.new(now: now).run(clinic)
  when "token_projection" then ReminderRun.call(clinic, now: now)
  when "staff_projection" then ReminderBatch.call(clinic, now: now)
  end
end

def session_for(style, session, clinic, staff)
  case style
  when "original" then OriginalWorkflow.session_for(session)
  when "custom" then CandidateWorkflow.session_for(session, clinic, staff)
  when "direct_replica"
    ["/api/clinics/#{clinic}/appointments", { "X-Demo-Staff" => staff }, {}, "appointments"]
  when "token_projection"
    session.post("/api/demo_sessions", params: { clinic_id: clinic.id, staff: staff }, as: :json)
    raise "Session HTTP #{session.response.status}" unless session.response.status == 201
    ["/api/appointments", { "X-Demo-Session" => JSON.parse(session.response.body).fetch("token") }, {}, "visits"]
  when "staff_projection"
    session.post("/api/staff_session", params: { clinic_id: clinic.id, staff_id: staff }, as: :json)
    raise "Session HTTP #{session.response.status}" unless session.response.status == 200
    ["/api/clinics/#{clinic.id}/appointments", {}, {}, "visits"]
  end
end

def persisted_sends(style, clinic)
  case style
  when "original" then OriginalWorkflow.sends
  when "custom" then CandidateWorkflow.sends(clinic)
  when "staff_projection" then clinic.deliveries.where(status: "sent").count
  when "token_projection" then clinic.messages.outbound.where(status: "sent").count
  when "direct_replica" then Message.outbound.where(clinic_id: clinic, status: "sent").count
  end
end

def check_sends(style, label, clinic, now, expected, contact_hold: false)
  before = persisted_sends(style, clinic)
  result = BenchmarkMeasurement.measure(label) { batch_for(style, label, clinic, now) }
  persisted = persisted_sends(style, clinic) - before
  result = { sent: persisted, failed: OriginalWorkflow.failed } if style == "original"
  if contact_hold
    unless style == "custom" && CandidateWorkflow.respond_to?(:contact_hold?)
      raise "The shared-before-send fixture needs an adapter that checks the persisted contact hold"
    end
    result = result.merge(contact_hold: CandidateWorkflow.contact_hold?(clinic, source_id: 1))
  else
    raise "#{label}: expected #{expected} stored sends, got #{persisted}" unless persisted == expected
    unless result[:sent] == expected && result[:failed].zero?
      raise "#{label}: expected #{expected} sends, got #{result.inspect}"
    end
  end
  AuditTrace.record("assertion", case_name: label, result: result.merge(persisted_sends: persisted))
end

def check_later_day(style, label, session, path, headers, params, collection_key)
  date = BenchmarkFixture::LATER_APPOINTMENT_DATE
  result = BenchmarkMeasurement.measure(label) do
    session.get(path, params: params.merge(date: date), headers: headers)
    body = JSON.parse(session.response.body)
    day = if style == "custom" && CandidateWorkflow.respond_to?(:calendar_day)
      CandidateWorkflow.calendar_day(body, date)
    else
      {
        total: body["total"], week_count: body.fetch("week", {})[date],
        source_ids: body[collection_key]&.map { |visit| visit["source_id"] }
      }
    end
    { status: session.response.status }.merge(day)
  end
  AuditTrace.record("assertion", case_name: label, result: result)
end

def reply_for(style, session, clinic, label, address: "person1@example.test")
  key = "a1b20000-0000-4000-8000-000000000001"
  case style
  when "original" then OriginalWorkflow.reply_for(session, label, address, key)
  when "custom" then CandidateWorkflow.reply_for(session, clinic, address, key)
  when "staff_projection"
    patient = clinic.patients.find_by!(source_id: 1)
    ["/api/demo_clinics/#{clinic.id}/patients/#{patient.id}/replies", {}, { channel: "email", body: "YES", event_id: key }]
  when "token_projection"
    message = clinic.messages.outbound.find_by!(recipient: address, status: "sent")
    ["/api/clinics/#{clinic.id}/patients/#{message.contact_id}/replies", {},
      { channel: "email", body: "YES", event_key: key, reply_to_id: message.id }]
  when "direct_replica"
    message = Message.outbound.find_by!(clinic_id: clinic, recipient: address, status: "sent")
    ["/api/clinics/#{clinic}/patients/1/replies", {},
      { channel: "email", body: "YES", external_id: key, message_id: message.id }]
  end
end

def confirmed_count(style, clinic)
  case style
  when "original" then OriginalWorkflow.confirmed_count
  when "custom" then CandidateWorkflow.confirmed_count(clinic)
  when "staff_projection" then clinic.visits.where.not(confirmed_at: nil).count
  when "token_projection" then clinic.visits.where(state: "confirmed").count
  when "direct_replica" then VisitDecision.where(clinic_id: clinic, state: "confirmed").count
  end
end

BenchmarkFixture.cases.each do |fixture|
  name = fixture.fetch(:name)
  eligible = fixture.fetch(:due)
  clinic, staff = prepare(style, connection, fixture)
  sms_reply = fixture[:sms_reply]
  sms_workflow = nil
  if sms_reply
    sms_workflow = case style
    when "custom" then CandidateWorkflow
    when "original" then OriginalWorkflow
    end
    required = %i[set_source_phone confirmed_source_ids reply_visible_for_review?]
    unless sms_workflow && required.all? { |method| sms_workflow.respond_to?(method) }
      raise "The SMS benchmark needs source mutation, exact confirmation identity, and review assertions"
    end

    sms_workflow.set_source_phone(1, "(512) 555-0121")
  end
  check_sends(style, "#{name}/reminder_batch", clinic, now, eligible, contact_hold: fixture[:shared_before_send])
  session = ActionDispatch::Integration::Session.new(Rails.application)
  path, headers, params, collection_key = session_for(style, session, clinic, staff)
  calendar = BenchmarkMeasurement.measure("#{name}/appointment_list") do
    request_params = params.merge(date: visit_date)
    if style == "custom" && CandidateWorkflow.respond_to?(:appointments)
      CandidateWorkflow.appointments(session, path, headers, request_params, collection_key)
    else
      session.get(path, params: request_params, headers: headers)
      body = JSON.parse(session.response.body)
      { status: session.response.status, visits: body[collection_key]&.length }
    end
  end
  raise "#{name}: expected #{eligible} appointments, got #{calendar.inspect}" unless
    calendar[:status] == 200 && calendar[:visits] == eligible
  AuditTrace.record("assertion", case_name: "#{name}/appointment_list", result: calendar)
  if fixture[:verify_later_day]
    check_later_day(style, "#{name}/later_day_after_send", session, path, headers, params, collection_key)
  end
  check_sends(style, "#{name}/same_clock_retry", clinic, now, 0) if fixture.fetch(:retry)
  if eligible.positive? && !fixture[:shared_before_send]
    reply_session = ActionDispatch::Integration::Session.new(Rails.application)
    reply_case = "#{name}/confirming_reply"
    if sms_reply == "shared_after_send"
      sms_workflow.set_source_phone(2, "+1 512-555-0121")
    end
    address = sms_reply ? "+15125550121" : "person1@example.test"
    endpoint, reply_headers, body = reply_for(style, reply_session, clinic, reply_case, address: address)
    before = confirmed_count(style, clinic)
    identity_reader = sms_workflow
    if style == "custom" && CandidateWorkflow.respond_to?(:confirmed_source_ids)
      identity_reader = CandidateWorkflow
    end
    before_ids = identity_reader.confirmed_source_ids(clinic) if identity_reader
    status = BenchmarkMeasurement.measure(reply_case) do
      reply_session.post(endpoint, headers: reply_headers, params: body, as: :json)
      reply_session.response.status
    end
    confirmed = confirmed_count(style, clinic) - before
    expected_confirmed = sms_reply == "shared_after_send" ? 0 : 1
    result = { confirmed: confirmed }
    matched = status.between?(200, 299) && confirmed == expected_confirmed
    if !sms_reply && !matched
      raise "#{reply_case}: HTTP #{status}, #{confirmed} confirmations, #{reply_session.response.body}"
    end
    result[:unexpected_http_status] = status unless status.between?(200, 299)
    if identity_reader
      changed_ids = identity_reader.confirmed_source_ids(clinic) - before_ids
      expected_ids = expected_confirmed.zero? ? [] : [1]
      unless changed_ids == expected_ids
        raise "#{reply_case}: expected IDs #{expected_ids.inspect}, confirmed #{changed_ids.inspect}" unless sms_reply

        result[:unexpected_confirmed_source_ids] = changed_ids
      end
      AuditTrace.record("identity_assertion", case_name: reply_case, confirmed_source_ids: changed_ids)
    end
    if expected_confirmed.zero?
      result[:staff_review] = status.between?(200, 299) &&
        sms_workflow.reply_visible_for_review?(clinic, reply_session.response)
    end
    AuditTrace.record("assertion", case_name: reply_case, result: result)
    if fixture[:verify_later_day]
      check_later_day(style, "#{name}/later_day_after_reply", session, path, headers, params, collection_key)
    end
  end
end
