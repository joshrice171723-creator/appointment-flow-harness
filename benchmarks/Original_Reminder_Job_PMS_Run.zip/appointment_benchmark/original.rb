require "pg"
require "uri"

module OriginalWorkflow
  module ReplicaPayload
    def exec_params(query, ...)
      result = super
      if Thread.current[:audit_case] && db == "apex_benchmark_source_test" && query.match?(/json_agg/)
        table = query[/FROM pms\.(\w+)/, 1]
        AuditTrace.record("replica_payload", relation: table, bytes: result.getvalue(0, 0).bytesize)
      end
      result
    end
  end

  PG::Connection.prepend(ReplicaPayload)
  load Rails.root.join("bin/setup_replica.rb")

  def self.prepare(connection, fixture)
    BenchmarkFixture.clear_local(connection, %w[desk pms])
    connection.execute("INSERT INTO pms.clinics (id, name) VALUES (1, 'Benchmark Clinic')")
    ClinicSetting.create!(clinic_id: 1, timezone: "America/Chicago", sender: "+15125550100")
    StaffMember.create!(id: 11, clinic_id: 1, name: "Morgan")
    PG.connect(ENV.fetch("PMS_ADMIN_URL")) do |source|
      source.exec("TRUNCATE pms.appointments, pms.patients, pms.clinics RESTART IDENTITY CASCADE")
      BenchmarkFixture.seed(source, fixture)
    end
    [1, 11]
  end

  def self.tag_replica(label)
    reader = URI(ENV.fetch("PMS_READER_URL"))
    reader.query = URI.encode_www_form(application_name: "benchmark_replica_#{label}")
    ENV["PMS_READER_URL"] = reader.to_s
  end

  def self.batch(label)
    tag_replica(label)
    ReminderRunner.tick
  end

  def self.sends
    Message.where(status: "sent").count
  end

  def self.failed
    Message.where(status: "failed").count
  end

  def self.session_for(session)
    entry_headers = enter_workspace(session, workspace: "desk", clinic: 1, staff: 11)
    ["/api/appointments", entry_headers, { clinic: 1 }, "visits"]
  end

  def self.confirmed_count
    Visit.for_clinic(1).where.not(confirmed_at: nil).count
  end

  def self.confirmed_source_ids(clinic)
    Visit.for_clinic(clinic).where.not(confirmed_at: nil).pluck(:appointment_id)
  end

  def self.set_source_phone(patient_id, phone)
    PG.connect(ENV.fetch("PMS_ADMIN_URL")) do |source|
      result = source.exec_params("UPDATE pms.patients SET wireless_phone = $1 WHERE id = $2", [phone, patient_id])
      raise "Missing synthetic PMS patient #{patient_id}" unless result.cmd_tuples == 1
    end
  end

  def self.reply_visible_for_review?(clinic, _response)
    replies = ActivityEvent.where(actor: "Patient", body: "YES").where.not(request_key: nil)
    FollowUpIssue.open.for_clinic(clinic).exists?(reply_event_id: replies.select(:id))
  end

  def self.reply_for(session, label, address, key)
    tag_replica(label)
    receipt = Message.sent.find_by!(destination: address)
    headers = enter_workspace(session, workspace: "patient")
    ["/api/patient/messages/#{receipt.token}", headers, { body: "YES", key: key }]
  end

  def self.enter_workspace(session, params)
    session.get("/")
    raise "Workspace HTTP #{session.response.status}" unless session.response.status == 200
    token = session.response.body[/name="csrf-token" content="([^"]+)"/, 1]
    headers = token ? { "X-CSRF-Token" => token } : {}
    session.post("/api/enter", params: params, headers: headers, as: :json)
    raise "Session HTTP #{session.response.status}" unless session.response.status == 200
    headers
  end
end
