require "json"

module BenchmarkFixture
  NOW = Time.utc(2026, 11, 16, 18)
  APPOINTMENT_DATE = "2026-11-23"
  LATER_APPOINTMENT_DATE = "2026-11-30"
  LATER_ID_OFFSET = 200_000

  def self.clear_local(connection, schemas)
    quoted_schemas = schemas.map { |schema| connection.quote(schema) }.join(", ")
    names = connection.select_rows(
      "SELECT schemaname, tablename FROM pg_tables WHERE schemaname IN (#{quoted_schemas}) " \
      "AND tablename NOT IN ('schema_migrations', 'ar_internal_metadata')"
    )
    tables = names.map { |parts| parts.map { |part| connection.quote_column_name(part) }.join(".") }
    connection.execute("TRUNCATE #{tables.join(', ')} RESTART IDENTITY CASCADE") if tables.any?
  end

  def self.cases
    data = JSON.parse(File.read(ENV.fetch("BENCHMARK_CASES")), symbolize_names: true)
    names = data.map { |entry| entry.fetch(:name) }
    raise "Invalid fixture names" unless names.uniq == names && names.all? { |name| name.match?(/\A[a-z_]+\z/) }
    data.each do |entry|
      %i[due older_appointments extra_patients later_appointments].each do |field|
        raise "Invalid #{field}" unless entry.fetch(field).is_a?(Integer) && entry[field].between?(0, 20_000)
      end
      if entry.key?(:sms_reply)
        valid_owner = if entry[:historical_contact_owner]
          entry[:due] == 1
        else
          entry[:due] >= 2
        end
        unless %w[unique shared_after_send].include?(entry[:sms_reply]) && valid_owner && entry[:extra_patients].positive?
          raise "Invalid SMS reply fixture"
        end
      end
      if entry[:shared_before_send] && !(entry[:historical_contact_owner] && !entry[:sms_reply] &&
          entry[:due] == 1 && entry[:extra_patients].positive?)
        raise "The shared-before-send fixture needs one due visit and a historical contact owner"
      end
      additional_owners = entry.fetch(:additional_historical_owners, 0)
      unless additional_owners.is_a?(Integer) && additional_owners.between?(0, 1_000)
        raise "Invalid additional historical contact owner count"
      end
      if entry[:verify_later_day] && !entry[:later_appointments].between?(1, 25)
        raise "The later-day check requires one page of synthetic appointments"
      end
    end
    data
  end

  def self.set_source_phone(connection, patient_id, phone, schema:)
    raise "Unexpected fixture schema" unless %w[public pms].include?(schema)

    id = Integer(patient_id)
    count = connection.update("UPDATE #{schema}.patients SET wireless_phone = #{connection.quote(phone)} WHERE id = #{id}")
    raise "Missing synthetic PMS patient #{id}" unless count == 1
  end

  def self.seed(source, fixture, schema: "pms")
    raise "Unexpected fixture schema" unless %w[public pms].include?(schema)

    execute = source.respond_to?(:execute) ? source.method(:execute) : source.method(:exec)
    due = fixture.fetch(:due)
    late = fixture.fetch(:later_appointments)
    patients = due + fixture.fetch(:extra_patients) + late
    execute.call("INSERT INTO #{schema}.clinics (id, name) VALUES (1, 'Benchmark Clinic')")
    execute.call(<<~SQL)
      INSERT INTO #{schema}.patients (id, first_name, last_name, birthdate, email, preferred_language)
      SELECT id, 'Fictional', 'Patient ' || id, DATE '1980-04-08', 'person' || id || '@example.test', 'en'
      FROM generate_series(1, #{patients}) AS id
    SQL
    execute.call(<<~SQL)
      INSERT INTO #{schema}.appointments (id, clinic_id, patient_id, start_at, status, provider_name, length_minutes)
      SELECT id, 1, id, TIMESTAMP '#{APPOINTMENT_DATE} 14:00:00', 'scheduled', 'Dr. Example', 30
      FROM generate_series(1, #{due}) AS id
    SQL
    execute.call(<<~SQL)
      INSERT INTO #{schema}.appointments (id, clinic_id, patient_id, start_at, status, provider_name, length_minutes)
      SELECT 100000 + id, 1, 1, TIMESTAMP '2024-02-12 14:00:00', 'complete', 'Dr. Example', 30
      FROM generate_series(1, #{fixture.fetch(:older_appointments)}) AS id
    SQL
    if fixture[:historical_contact_owner]
      execute.call(<<~SQL)
        INSERT INTO #{schema}.appointments (id, clinic_id, patient_id, start_at, status, provider_name, length_minutes)
        VALUES (95000, 1, 2, TIMESTAMP '2024-02-12 14:00:00', 'complete', 'Dr. Example', 30)
      SQL
    end
    if fixture[:shared_before_send]
      execute.call(<<~SQL)
        UPDATE #{schema}.patients SET wireless_phone = '(512) 555-0121', email = NULL WHERE id = 1
      SQL
      execute.call(<<~SQL)
        UPDATE #{schema}.patients SET wireless_phone = '+1 512-555-0121' WHERE id = 2
      SQL
    end
    additional_owners = fixture.fetch(:additional_historical_owners, 0)
    if additional_owners.positive?
      execute.call(<<~SQL)
        INSERT INTO #{schema}.patients (id, first_name, last_name, birthdate, wireless_phone, preferred_language)
        SELECT #{patients} + id, 'Fictional', 'Archived Patient ' || id, DATE '1980-04-08',
          '(512) 555-' || (1000 + id), 'en'
        FROM generate_series(1, #{additional_owners}) AS id
      SQL
      execute.call(<<~SQL)
        INSERT INTO #{schema}.appointments (id, clinic_id, patient_id, start_at, status, provider_name, length_minutes)
        SELECT 300000 + id, 1, #{patients} + id, TIMESTAMP '2024-02-12 14:00:00', 'complete', 'Dr. Example', 30
        FROM generate_series(1, #{additional_owners}) AS id
      SQL
    end
    execute.call(<<~SQL)
      INSERT INTO #{schema}.appointments (id, clinic_id, patient_id, start_at, status, provider_name, length_minutes)
      SELECT #{LATER_ID_OFFSET} + id, 1, #{due} + id, TIMESTAMP '#{LATER_APPOINTMENT_DATE} 14:00:00',
        'scheduled', 'Dr. Example', 30
      FROM generate_series(1, #{late}) AS id
    SQL
  end
end
