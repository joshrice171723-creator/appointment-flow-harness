"""Benchmark an exact Appointment Flow revision in an isolated local PostgreSQL instance."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tarfile
import tempfile
from time import perf_counter

HERE = Path(__file__).resolve().parent
WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
ADAPTERS = ("original", "staff_projection", "token_projection", "direct_replica", "custom")


def capture(folder, label, command, cwd=None, env=None, timeout=900):
    command = [str(item) for item in command]
    start = perf_counter()
    receipt = {"argv": command, "cwd": str(cwd) if cwd else None,
               "start_utc": datetime.now(timezone.utc).isoformat()}
    try:
        with (folder / f"{label}.log").open("wb") as stream:
            result = subprocess.run(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=timeout, creationflags=WINDOW)
        receipt["exit_code"] = result.returncode
        if result.returncode:
            raise RuntimeError(f"{label} failed with exit {result.returncode}. See {folder / (label + '.log')}")
    finally:
        receipt["elapsed_seconds"] = round(perf_counter() - start, 3)
        (folder / f"{label}.command.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")


def pg_command(directory, command):
    if directory:
        return directory / (command + (".exe" if os.name == "nt" else ""))
    return command


def isolated_config(backend):
    config = backend / "config/database.yml"
    data = config.read_text(encoding="utf-8")
    test_block = re.search(r"(?m)^test:\s*\n(?:^[ \t].*\n|^\s*\n)*", data)
    if not test_block:
        raise ValueError("The Rails database file has no explicit test configuration")
    block, count = re.subn(r"(?m)^([ \t]+database:)[^\n]*$", r"\1 apex_benchmark_test", test_block[0])
    if not count:
        raise ValueError("Set up an isolated test database mapping for this project's adapter")
    config.write_text(data[:test_block.start()] + block + data[test_block.end():], encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--adapter", choices=ADAPTERS, required=True)
    parser.add_argument("--adapter-file", type=Path)
    parser.add_argument("--backend", default="backend", help="Rails path inside the archived project")
    parser.add_argument("--pms-role", help="Use a distinct read-only PMS login with Rails database URLs")
    parser.add_argument("--app-role", help="Create the application role expected by migrations")
    parser.add_argument("--cases", type=Path, action="append",
                        help="Case file. Repeat to run multiple suites in one isolated database")
    parser.add_argument("--output", type=Path, default=HERE / "runs")
    parser.add_argument("--capture-plans", action="store_true",
                        help="Log actual query plans and buffer use in a diagnostic run")
    default_pg = Path("C:/Program Files/PostgreSQL/17/bin")
    parser.add_argument("--postgres-bin", type=Path, default=default_pg if default_pg.exists() else None)
    opts = parser.parse_args()
    project = opts.project.resolve(strict=True)
    if opts.adapter == "custom" and not opts.adapter_file:
        parser.error("--adapter-file is required for a custom adapter")
    if opts.pms_role and (opts.adapter != "custom" or not re.fullmatch(r"[a-z_][a-z0-9_]{0,31}", opts.pms_role)):
        parser.error("--pms-role requires a custom adapter and a lowercase PostgreSQL role name")
    if opts.app_role and (not opts.pms_role or opts.app_role == opts.pms_role
                          or not re.fullmatch(r"[a-z_][a-z0-9_]{0,31}", opts.app_role)):
        parser.error("--app-role requires a separate lowercase PostgreSQL role name and --pms-role")
    revision = subprocess.check_output(["git", "-C", project, "rev-parse", "--verify", opts.revision + "^{commit}"],
                                       text=True).strip()
    output = opts.output.resolve()
    output.mkdir(exist_ok=True, parents=True)
    folder = Path(tempfile.mkdtemp(prefix=f"{project.name}-", dir=output))
    print(folder, flush=True)
    archive = folder / "frozen.tar"
    source = folder / "source"
    capture(folder, "archive", ["git", "-C", project, "archive", "-o", archive, revision])
    with tarfile.open(archive) as package:
        package.extractall(source, filter="data")
    archive.unlink()
    backend = (source / opts.backend).resolve()
    if not backend.is_relative_to(source) or not (backend / "bin/rails").is_file():
        raise ValueError("The Rails entry point must be inside the frozen project")
    if opts.adapter != "original" and not opts.pms_role:
        isolated_config(backend)
    cases = folder / "cases.json"
    case_files = opts.cases or [HERE / "cases.json"]
    if len(case_files) == 1:
        cases.write_bytes(case_files[0].read_bytes())
    else:
        cases_by_file = [json.loads(path.read_text(encoding="utf-8-sig")) for path in case_files]
        if not all(isinstance(suite, list) for suite in cases_by_file):
            raise ValueError("Each case file must contain an array")
        names = [case["name"] for suite in cases_by_file for case in suite]
        if len(names) != len(set(names)):
            raise ValueError("Combined case files contain duplicate scenario names")
        cases.write_text(json.dumps([case for suite in cases_by_file for case in suite], indent=2),
                         encoding="utf-8")
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    data = folder / "postgres"
    pg = {name: pg_command(opts.postgres_bin, name) for name in ("initdb", "pg_ctl", "createdb", "postgres", "psql")}
    capture(folder, "ruby-version", ["ruby", "--version"])
    capture(folder, "pg-version", [pg["postgres"], "--version"])
    capture(folder, "initdb", [pg["initdb"], "-D", data, "-U", "postgres", "-A", "trust", "--locale=C", "-E", "UTF8", "--no-sync"])
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(("PG", "BUNDLE_")) and k not in {
               "DATABASE_URL", "PRIMARY_DATABASE_URL", "PMS_DATABASE_URL", "PMS_READER_DATABASE_URL", "DEMO_NOW", "RUBYOPT",
               "ASSESSMENT_REMINDERS_START", "CLINIC_SETUP_FILE",
           }}
    if opts.postgres_bin:
        env["PATH"] = str(opts.postgres_bin) + os.pathsep + env["PATH"]
    url = f"postgresql://postgres@127.0.0.1:{port}"
    env.update({
        "RAILS_ENV": "test", "PGHOST": "127.0.0.1", "PGPORT": str(port), "PGSSLMODE": "disable",
        "APEX_DB_HOST": "127.0.0.1", "APEX_DB_PORT": str(port), "APEX_DB_USER": "postgres",
        "APEX_DB_PASSWORD": "",
        "PGUSER": "postgres", "PGAPPNAME": "benchmark_app", "BENCHMARK_ADAPTER": opts.adapter,
        "BENCHMARK_CASES": str(cases), "AUDIT_PHASE": "benchmark", "AUDIT_TRACE": str(folder / "trace.jsonl"),
        "DENTAL_DATABASE_URL": url + "/apex_benchmark_test", "APP_ADMIN_URL": url + "/postgres",
        "PMS_ADMIN_URL": url + "/apex_benchmark_source_test",
        "PMS_READER_URL": f"postgresql://benchmark_reader@127.0.0.1:{port}/apex_benchmark_source_test",
        "SEED_AT": "2026-11-16T18:00:00Z",
    })
    if opts.pms_role:
        env["PRIMARY_DATABASE_URL"] = url + "/apex_benchmark_test"
        env["PMS_DATABASE_URL"] = f"postgresql://{opts.pms_role}@127.0.0.1:{port}/apex_benchmark_test"
    if opts.adapter_file:
        snapshot = folder / "candidate_adapter.rb"
        snapshot.write_bytes(opts.adapter_file.read_bytes())
        env["BENCHMARK_ADAPTER_FILE"] = str(snapshot)
    (folder / "run.json").write_text(json.dumps({
        "project": str(project), "revision": revision, "adapter": opts.adapter,
        "postgres_port": port, "setup": "private loopback PostgreSQL with synthetic data",
        "capture_plans": opts.capture_plans,
        "pms_role": opts.pms_role,
        "app_role": opts.app_role,
        "case_sources": [{"name": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                         for path in case_files],
        "benchmark_input_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in [cases, *(HERE / name for name in
                         ("application.rb", "fixture.rb", "trace.rb", "summarize.py")),
                         *([snapshot] if opts.adapter_file else []),
                         *([HERE / "original.rb"] if opts.adapter == "original" else [])]
        },
    }, indent=2), encoding="utf-8")
    options = f"-h 127.0.0.1 -p {port} -c log_statement=all -c log_line_prefix=%m_%d_%a_%p_"
    capture(folder, "postgres-start", [pg["pg_ctl"], "-D", data, "-l", folder / "postgres-server.log",
                                       "-o", options, "-w", "start"])
    try:
        capture(folder, "create", [pg["createdb"], "apex_benchmark_test"], env=env)
        for label, role in (("pms-role", opts.pms_role), ("app-role", opts.app_role)):
            if role:
                capture(folder, label, [pg["psql"], "-X", "-d", "postgres", "-v", "ON_ERROR_STOP=1",
                                        "-c", f"CREATE ROLE {role} LOGIN"], env=env)
        capture(folder, "migrate", ["ruby", "bin/rails", "db:migrate"], backend, env)
        if opts.capture_plans:
            settings = {
                "session_preload_libraries": "'auto_explain'",
                "auto_explain.log_min_duration": "0",
                "auto_explain.log_analyze": "on",
                "auto_explain.log_timing": "off",
                "auto_explain.log_buffers": "on",
                "auto_explain.log_parameter_max_length": "0",
            }
            command = [pg["psql"], "-X", "-d", "postgres", "-v", "ON_ERROR_STOP=1"]
            for name, value in settings.items():
                command.extend(("-c", f"ALTER DATABASE apex_benchmark_test SET {name} TO {value}"))
            capture(folder, "enable-plans", command, env=env)
        capture(folder, "benchmark", ["ruby", "-r", HERE / "trace.rb", "bin/rails", "runner",
                                      "--skip-executor", HERE / "application.rb"], backend, env)
    finally:
        capture(folder, "postgres-stop", [pg["pg_ctl"], "-D", data, "-m", "fast", "-w", "stop"])
    capture(folder, "summary", [sys.executable, HERE / "summarize.py", folder])
    print(f"Verified cases and metrics: {folder / 'summary.csv'}", flush=True)


if __name__ == "__main__":
    main()
