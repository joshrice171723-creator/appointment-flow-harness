require "bundler/setup"
require "active_support"
require "active_support/notifications"
require "json"

module AuditTrace
  ROOT = File.expand_path(Dir.pwd).tr("\\", "/") + "/"
  OUTPUT = File.open(ENV.fetch("AUDIT_TRACE"), "w")
  OWNER = Thread.current

  def self.record(event, details)
    return unless Thread.current.equal?(OWNER)

    OUTPUT.puts(JSON.generate(details.merge(event: event, case: Thread.current[:audit_case])))
  end

  def self.source
    caller_locations.filter_map do |frame|
      path = (frame.absolute_path || frame.path).tr("\\", "/")
      next unless path.downcase.start_with?(ROOT.downcase)

      relative = path[ROOT.length..]
      [relative, frame.lineno, frame.base_label] if relative.start_with?("app/", "lib/")
    end.first(8)
  end
end

ActiveSupport::Notifications.monotonic_subscribe("sql.active_record") do |_name, start, finish, _id, details|
  next unless Thread.current[:audit_case]

  config = details[:connection]&.pool&.db_config
  AuditTrace.record("sql", sql: details[:sql], name: details[:name], cached: !!details[:cached],
    rows: details[:row_count], affected_rows: details[:affected_rows], start_ms: start * 1000,
    finish_ms: finish * 1000, database: config&.name, error: details[:exception]&.first,
    source: AuditTrace.source)
end

ActiveSupport::Notifications.subscribe("instantiation.active_record") do |event|
  next unless Thread.current[:audit_case]

  AuditTrace.record("instantiate", model: event.payload[:class_name], rows: event.payload[:record_count])
end
