"""Verify the scenario receipts and write comparable per-operation counters."""

from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import re
import sys


WRITE = re.compile(r"^\s*(?:INSERT|UPDATE|DELETE|TRUNCATE|MERGE)\b", re.I)
READ = re.compile(r"^\s*SELECT\b", re.I)
LOCK = re.compile(r"\bFOR UPDATE\b|\bpg_advisory_xact_lock\w*\(", re.I)
END = re.compile(r"^\s*(?:COMMIT|ROLLBACK)\s*$", re.I)
REPLICA = re.compile(
    r"apex_benchmark_source_test_benchmark_replica_(?P<case>[a-z_/]+)_\d+_LOG:\s+"
    r"(?:statement|execute [^:]+):\s*(?P<sql>.+)"
)


def metrics(events, replica):
    data = Counter()
    rows_present, affected_present, write_result_rows, replica_bytes = [], [], [], []
    sql_ms, wall_ms = 0.0, 0.0
    largest_source = ""
    acquired, ended = None, None
    for event in events:
        if event["event"] == "outcome":
            wall_ms = event["duration_ms"]
        elif event["event"] == "instantiate":
            data["models_loaded"] += event["rows"]
        elif event["event"] == "replica_payload":
            replica_bytes.append(event["bytes"])
        elif event["event"] == "sql":
            if event["cached"]:
                data["cache_hits"] += 1
                continue
            if event["name"] == "SCHEMA":
                data["schema_statements"] += 1
                continue
            sql = event["sql"]
            data["sql_statements"] += 1
            sql_ms += event["finish_ms"] - event["start_ms"]
            if WRITE.match(sql):
                data["write_statements"] += 1
                if event["rows"] is not None:
                    write_result_rows.append(event["rows"])
                else:
                    data["writes_missing_result_row_count"] += 1
                if event["affected_rows"] is not None:
                    affected_present.append(event["affected_rows"])
                else:
                    data["writes_missing_row_count"] += 1
            if READ.match(sql):
                data["read_statements"] += 1
                if event["rows"] is not None:
                    if not rows_present or event["rows"] > max(rows_present):
                        source = event["source"]
                        largest_source = f"{source[0][0]}:{source[0][1]}" if source else ""
                    rows_present.append(event["rows"])
                else:
                    data["reads_missing_row_count"] += 1
            if acquired is None and LOCK.search(sql) and not event["error"]:
                acquired = event
            if acquired and END.match(sql) and event["database"] == acquired["database"]:
                ended = event
    data["sql_statements"] += len(replica)
    return {
        "sql_statements": data["sql_statements"],
        "direct_replica_statements": len(replica),
        "rails_read_statements": data["read_statements"],
        "rails_read_rows": sum(rows_present) if rows_present else None,
        "largest_rails_read_rows": max(rows_present) if rows_present else None,
        "largest_rails_read_source": largest_source,
        "reads_missing_row_count": data["reads_missing_row_count"],
        "write_statements": data["write_statements"],
        "write_result_rows": sum(write_result_rows) if write_result_rows else (0 if not data["write_statements"] else None),
        "writes_missing_result_row_count": data["writes_missing_result_row_count"],
        "affected_rows": sum(affected_present) if affected_present else (0 if not data["write_statements"] else None),
        "writes_missing_row_count": data["writes_missing_row_count"],
        "models_loaded": data["models_loaded"],
        "replica_json_bytes": sum(replica_bytes) if replica_bytes else None,
        "schema_statements": data["schema_statements"],
        "cache_hits": data["cache_hits"],
        "observed_row_lock_window_ms": round(ended["finish_ms"] - acquired["finish_ms"], 3) if ended else None,
        "rails_sql_ms": round(sql_ms, 3),
        "wall_ms": round(wall_ms, 3),
    }


def main(folder):
    folder = Path(folder)
    receipt = json.loads((folder / "benchmark.command.json").read_text())
    assert receipt["exit_code"] == 0, receipt
    info = json.loads((folder / "run.json").read_text())
    cases = json.loads((folder / "cases.json").read_text())
    streams, raw = defaultdict(list), defaultdict(list)
    asserted = {}
    for line in (folder / "trace.jsonl").read_text(encoding="utf-8").splitlines():
        event = json.loads(line)
        if event["case"]:
            streams[event["case"]].append(event)
        if event["event"] == "assertion":
            assert event["case_name"] not in asserted
            asserted[event["case_name"]] = event["result"]
    if info["adapter"] == "original":
        for line in (folder / "postgres-server.log").read_text(encoding="utf-8").splitlines():
            entry = REPLICA.search(line)
            if entry:
                raw[entry["case"]].append(entry["sql"])
    expected = {
        f'{case["name"]}/{operation}': value
        for case in cases
        for operation, value in (
            ("reminder_batch", {"sent": 0, "failed": 0, "persisted_sends": 0, "contact_hold": True}
             if case.get("shared_before_send") else {"sent": case["due"], "failed": 0, "persisted_sends": case["due"]}),
            ("appointment_list", {"status": 200, "visits": case["due"]}),
            *((("confirming_reply", {"confirmed": 0, "staff_review": True}
                if case.get("sms_reply") == "shared_after_send" else {"confirmed": 1}),)
              if case["due"] and not case.get("shared_before_send") else ()),
            *((("same_clock_retry", {"sent": 0, "failed": 0, "persisted_sends": 0}),) if case["retry"] else ()),
        )
    }
    for case in cases:
        if case.get("verify_later_day"):
            count = case["later_appointments"]
            wanted = {"status": 200, "total": count, "week_count": count,
                      "source_ids": list(range(200001, 200001 + count))}
            expected[f'{case["name"]}/later_day_after_send'] = wanted
            if case["due"]:
                expected[f'{case["name"]}/later_day_after_reply'] = wanted
    assert asserted.keys() == expected.keys(), (asserted.keys(), expected.keys())
    mismatches = {label: (expected[label], result) for label, result in asserted.items()
                  if result != expected[label]}
    if info["adapter"] == "original":
        assert all(len(raw[label]) == 7 for label in expected
                   if label.endswith(("/reminder_batch", "/same_clock_retry")))
    rows = [{"revision": info["revision"], "adapter": info["adapter"], "case": label,
             **metrics(streams[label], raw[label]), "result": json.dumps(asserted[label])}
            for label in expected]
    assert all(row["sql_statements"] > 0 and row["wall_ms"] > 0 for row in rows)
    with (folder / "summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    if mismatches:
        for label, (wanted, actual) in mismatches.items():
            print(f"FAIL: {label} expected {wanted}, observed {actual}")
        raise SystemExit(1)
    print(f"PASS: {len(rows)} behavior assertions and benchmark records.")


if __name__ == "__main__":
    main(sys.argv[1])
