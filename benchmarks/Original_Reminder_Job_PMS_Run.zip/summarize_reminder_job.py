"""Verify the mixed reminder workload and separate PMS transfer from application work."""

from collections import defaultdict
from pathlib import Path
import csv
import json
import sys

from appointment_benchmark.summarize import REPLICA, WRITE, metrics


def main(run, output):
    receipt = json.loads((run / "benchmark.command.json").read_text(encoding="utf-8"))
    if receipt["exit_code"] != 0:
        raise ValueError("The reminder job benchmark did not pass")
    revision = json.loads((run / "run.json").read_text(encoding="utf-8"))["revision"]
    events, direct, outcomes = defaultdict(list), defaultdict(list), {}
    for line in (run / "trace.jsonl").read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row["case"]:
            events[row["case"]].append(row)
        if row["event"] == "ticket_result":
            outcomes[row["case_name"]] = row
    for line in (run / "postgres-server.log").read_text(encoding="utf-8").splitlines():
        match = REPLICA.search(line)
        if match:
            direct[match["case"]].append(match["sql"])

    rows = []
    for fixture, count in (("mixed", 24), ("mixed_extra_patients", 2024)):
        for operation in ("first_tick", "same_clock_retry"):
            case = f"{fixture}/{operation}"
            result = outcomes[case]
            assert result["source_patients"] == count and result["cases"] == result["sent"] == 16
            raw = direct[case]
            assert len(raw) == 7 and not any(WRITE.match(sql) for sql in raw), raw
            group = events[case]
            transfers = {row["relation"]: row["bytes"] for row in group if row["event"] == "replica_payload"}
            assert set(transfers) == {"clinics", "patients", "appointments"}, transfers
            local = metrics(group, raw)
            mirror_writes = [row for row in group if row["event"] == "sql" and not row["cached"]
                             and WRITE.match(row["sql"]) and any(frame[0] == "app/services/pms_snapshot.rb" for frame in row["source"])]
            assert all(row["affected_rows"] is not None for row in mirror_writes)
            rows.append({"revision": revision, "fixture": fixture, "operation": operation,
                         "pms_patients": count, "new_tickets": result["cases"] if operation == "first_tick" else 0,
                         "new_deliveries": result["sent"] if operation == "first_tick" else 0,
                         "stored_message_body_bytes": result["body_bytes"]["total"],
                         "pms_clinic_json_bytes": transfers["clinics"], "pms_patient_json_bytes": transfers["patients"],
                         "pms_appointment_json_bytes": transfers["appointments"],
                         "mirror_write_statements": len(mirror_writes),
                         "mirror_rows_affected": sum(row["affected_rows"] for row in mirror_writes), **local})

    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print("Verified 4 reminder job measurements with identical outcomes and separate PMS byte counts.")


if __name__ == "__main__":
    main(*map(Path, sys.argv[1:]))
