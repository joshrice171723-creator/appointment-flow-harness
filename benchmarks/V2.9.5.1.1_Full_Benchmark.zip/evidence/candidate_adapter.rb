require "pg"

# This connection belongs to the fixture setup. Measured application requests use apex_app.
class V295FixtureOwner < ActiveRecord::Base
  self.abstract_class = true
  establish_connection ActiveRecord::Base.connection_db_config.configuration_hash.merge(username: "postgres")
end

module CandidateWorkflow
  def self.prepare(_connection, fixture)
    owner = V295FixtureOwner.lease_connection
    BenchmarkFixture.clear_local(owner, %w[public pms])
    BenchmarkFixture.seed(owner, fixture)
    owner.execute("UPDATE pms.clinics SET city = 'Austin', state = 'TX' WHERE id = 1")
    ActiveRecord::Base.connection_pool.clear_query_cache
    [Clinic.find(1), "Morgan"]
  end

  def self.batch(clinic, now)
    ReminderBatch.new(clinic).run(now: now).slice(:sent, :failed)
  end

  def self.sends(clinic)
    DeliveryAttempt.sent.where(clinic_id: clinic.id).count
  end

  def self.contact_hold?(clinic, source_id:)
    WorkItem.open.where(clinic_id: clinic.id, visit_id: source_id, kind: "contact_hold").exists?
  end

  def self.session_for(session, clinic, staff)
    session.post("/api/staff_session", params: { clinic_id: clinic.id, staff: staff }, as: :json)
    raise "Staff sign-in HTTP #{session.response.status}" unless session.response.status == 201

    token = JSON.parse(session.response.body).fetch("token")
    ["/api/staff/appointments", { "Authorization" => "Bearer #{token}" }, {}, "visits"]
  end

  def self.appointments(session, path, headers, params, collection_key)
    ids = []
    (1..10).each do |page|
      session.get(path, params: params.merge(page: page), headers: headers)
      return { status: session.response.status, visits: nil } unless session.response.status == 200

      body = JSON.parse(session.response.body)
      ids.concat(body.fetch(collection_key).pluck("id"))
      next if ids.length < body.fetch("total")

      raise "Repeated appointment IDs across pages" unless ids.uniq == ids
      return { status: 200, visits: ids.length }
    end
    raise "The appointment fixture exceeded its expected page bound"
  end

  def self.calendar_day(body, date)
    count = body.fetch("week").find { |day| day.fetch("date") == date }
    { total: body.fetch("total"), week_count: count&.fetch("total"),
      source_ids: body.fetch("visits").pluck("id") }
  end

  def self.reply_for(_session, clinic, address, key)
    attempt = DeliveryAttempt.sent.find_by!(clinic_id: clinic.id, recipient: address)
    ["/api/demo/clinics/#{clinic.id}/patients/#{attempt.patient_id}/replies", {},
      { channel: attempt.channel, body: "YES", event_id: key, attempt_id: attempt.id }]
  end

  def self.confirmed_count(clinic)
    VisitDecision.where(clinic_id: clinic.id, state: "confirmed").count
  end

  def self.confirmed_source_ids(clinic)
    VisitDecision.where(clinic_id: clinic.id, state: "confirmed").order(:visit_id).pluck(:visit_id)
  end

  def self.set_source_phone(patient_id, phone)
    BenchmarkFixture.set_source_phone(V295FixtureOwner.lease_connection, patient_id, phone, schema: "pms")
    ActiveRecord::Base.connection_pool.clear_query_cache
  end

  def self.reply_visible_for_review?(clinic, response)
    reply_id = JSON.parse(response.body).fetch("id")
    WorkItem.open.exists?(clinic_id: clinic.id, inbound_reply_id: reply_id, kind: "reply_review")
  end
end
