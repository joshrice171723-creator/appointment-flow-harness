"""Prepare separately isolated workspaces and launch a matched full rebuild."""

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import queue
import socket
import subprocess
import sys
import tempfile
import threading
from time import time
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = ROOT / "outputs"
PAIRED = ROOT / "work" / "paired-rebuild"
VERSIONS = {"a": "2.4.1.1.0", "b": "2.5.1.1.0"}
MODEL = "gpt-6.1-sol"
EFFORT = "xhigh"
POSTGRES = Path(r"C:\Program Files\PostgreSQL\17\bin")
STARTUP = [
    "--disable", "hooks", "--disable", "memories", "--disable", "plugins",
    "-c", "memories.use_memories=false", "-c", "memories.generate_memories=false",
]
LAUNCH_NOTES = """
## Matched-run capture

Use the isolated PostgreSQL instance addressed by the supplied PGHOST, PGPORT, and PGUSER. Keep persisted app data in that instance. Use HARNESS_API_PORT and HARNESS_UI_PORT when starting servers for smoke checks so the two runs can coexist. App source lives in this working directory.

Immediately after Stage 3 and before the initial grade, create a local Git checkpoint of the implementation and tests. Record its hash and timestamp in the existing build log. Take another local checkpoint after final grading and repairs. Keep completed evidence tied to the code checked. Record exact blockers and preserve partial evidence if a required check cannot run. Add no Git remote. Use a local synthetic Git author identity if required.

"""


def package(version):
    return OUTPUTS / f"Apex_Appointment_Flow_Harness_V{version}.zip"


def extract(version, dest):
    top = f"APEX_Clean_Room_Harness_V{version}"
    with ZipFile(package(version)) as archive:
        for item in archive.infolist():
            if item.is_dir():
                continue
            parts = PurePosixPath(item.filename).parts
            assert len(parts) > 1 and parts[0] == top
            assert not any(part in ("", ".", "..") or "\\" in part or ":" in part for part in parts)
            target = dest.joinpath(*parts[1:])
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(item))


def shared_prompt(roots):
    documents = [(root / "RUN_THIS_IN_RUBYMINE.md").read_bytes() for root in roots.values()]
    assert documents[0] == documents[1]
    text = documents[0].decode("utf-8")
    marker = "Begin Stage 0 now, in this directory."
    assert text.count(marker) == 1
    path = OUTPUTS / "Harness_Paired_Rebuild_Launch_Prompt.md"
    path.write_text(text.replace(marker, LAUNCH_NOTES.lstrip() + marker), encoding="utf-8", newline="\n")
    return path.read_bytes()


def configuration(codex, root, env, settings):
    server = subprocess.Popen(
        [codex, "app-server", *settings, "--listen", "stdio://"],
        cwd=root, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )
    output = queue.Queue()

    def read():
        for line in server.stdout:
            output.put(json.loads(line))
        output.put(None)

    def send(method, params=None, request_id=None):
        request = {"method": method}
        if params is not None:
            request["params"] = params
        if request_id is not None:
            request["id"] = request_id
        server.stdin.write((json.dumps(request) + "\n").encode())
        server.stdin.flush()
        if request_id is None:
            return None
        while True:
            item = output.get(timeout=45)
            assert item is not None, "Codex app-server closed before verifying settings"
            if item.get("id") == request_id:
                assert "result" in item, item
                return item["result"]

    threading.Thread(target=read, daemon=True).start()
    try:
        send("initialize", {"clientInfo": {"name": "codex_cli", "version": "0.166.0"}}, 1)
        send("initialized")
        skills = send("skills/list", {"cwds": [str(root)], "forceReload": True}, 2)["data"]
        config = send("config/read", {"cwd": str(root)}, 3)["config"]
        assert len(skills) == 1 and not skills[0]["errors"], "Skill discovery was incomplete"
        enabled = [entry["name"] for entry in skills[0]["skills"] if entry["enabled"]]
        assert not enabled, f"Enabled skills: {enabled}"
        features = config["features"]
        assert all(features[name] is False for name in ("hooks", "memories", "plugins")), features
        if "memories" in config:
            assert config["memories"]["use_memories"] is False
        return {"enabled_skills": enabled, "hooks": False, "memories": False, "plugins": False}
    finally:
        server.terminate()
        server.wait(timeout=10)


def open_ports(count):
    sockets = []
    try:
        for _ in range(count):
            listener = socket.socket()
            sockets.append(listener)
            listener.bind(("127.0.0.1", 0))
        return [listener.getsockname()[1] for listener in sockets]
    finally:
        for listener in sockets:
            listener.close()


def postgres_start(data, port, log):
    creation = subprocess.CREATE_NO_WINDOW
    with log.open("ab") as stream:
        subprocess.run(
            [POSTGRES / "initdb.exe", "-D", data, "-U", "postgres", "-A", "trust", "--locale=C", "-E", "UTF8"],
            stdout=stream, stderr=subprocess.STDOUT, check=True, creationflags=creation,
        )
        subprocess.run(
            [POSTGRES / "pg_ctl.exe", "-D", data, "-l", log.with_suffix(".server.log"), "-o", f"-h 127.0.0.1 -p {port}", "-w", "start"],
            stdout=stream, stderr=subprocess.STDOUT, check=True, creationflags=creation,
        )


def postgres_stop(data, log):
    with log.open("ab") as stream:
        subprocess.run(
            [POSTGRES / "pg_ctl.exe", "-D", data, "-m", "fast", "-w", "stop"],
            stdout=stream, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW,
        )


def launch(codex, root, env, prompt, settings, run_log):
    args = [
        codex, "exec", *settings, "-m", MODEL, "-c", f'model_reasoning_effort="{EFFORT}"',
        "--skip-git-repo-check", "--ephemeral", "--json", "-C", root, "-",
    ]
    with run_log.open("wb") as stream:
        process = subprocess.Popen(args, cwd=root, env=env, stdin=subprocess.PIPE, stdout=stream, stderr=subprocess.STDOUT)
    with process.stdin as writer:
        writer.write(prompt)
    return process


def main():
    assert (ROOT / "work" / "harness-paired-comparison.md").is_file()
    codex = os.environ["HARNESS_ACP_BINARY"]
    PAIRED.mkdir(exist_ok=True)
    trial = Path(tempfile.mkdtemp(prefix="trial-", dir=PAIRED))
    print(f"Trial: {trial}", flush=True)
    roots = {arm: trial / f"build-{arm}" for arm in VERSIONS}
    for arm, version in VERSIONS.items():
        extract(version, roots[arm])
        subprocess.run([sys.executable, "quality/verify_harness.py"], cwd=roots[arm], check=True)
    prompt = shared_prompt(roots)
    envs = {arm: dict(os.environ) for arm in VERSIONS}
    settings = [*STARTUP]
    for mcp in ("node_repl", "shortcut", "twilio-docs", "twilio-video", "graft", "rubymine", "frontier-radar", "cloudflare"):
        settings.extend(("-c", f"mcp_servers.{mcp}.enabled=false"))
    provenance = {
        "model": MODEL, "effort": EFFORT, "paired_launch_sha256": hashlib.sha256(prompt).hexdigest(),
        "versions": VERSIONS, "workspaces": {arm: str(root) for arm, root in roots.items()}, "configurations": {},
    }
    for arm in VERSIONS:
        provenance["configurations"][arm] = configuration(codex, roots[arm], envs[arm], settings)
    print("Both arms verified with zero enabled skills, hooks off, and memory off.", flush=True)
    fixture_ports = open_ports(3 * len(VERSIONS))
    started_databases = []
    processes = {}
    try:
        for arm in VERSIONS:
            pg_port, api_port, ui_port, *fixture_ports = fixture_ports
            data = trial / f"postgres-{arm}"
            db_log = trial / f"postgres-{arm}.log"
            postgres_start(data, pg_port, db_log)
            started_databases.append((data, db_log))
            envs[arm].update({
                "PGPORT": str(pg_port), "PGHOST": "127.0.0.1", "PGUSER": "postgres",
                "HARNESS_API_PORT": str(api_port), "HARNESS_UI_PORT": str(ui_port),
            })
        provenance["start_times"] = {}
        for arm in VERSIONS:
            provenance["start_times"][arm] = time()
            processes[arm] = launch(codex, roots[arm], envs[arm], prompt, settings, trial / f"arm-{arm}.jsonl")
        (trial / "provenance.json").write_text(json.dumps(provenance, indent=2), encoding="utf-8")
        print("Both full rebuilds launched with isolated PostgreSQL instances.", flush=True)
        pending = set(processes)
        while pending:
            for arm in tuple(pending):
                try:
                    status = processes[arm].wait(timeout=15)
                except subprocess.TimeoutExpired:
                    continue
                (trial / f"arm-{arm}-exit.json").write_text(json.dumps({"code": status, "finished_at": time()}), encoding="utf-8")
                print(f"Arm {arm} exited with code {status}.", flush=True)
                pending.remove(arm)
    finally:
        for process in processes.values():
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=10)
        for data, log in reversed(started_databases):
            postgres_stop(data, log)


if __name__ == "__main__":
    main()
