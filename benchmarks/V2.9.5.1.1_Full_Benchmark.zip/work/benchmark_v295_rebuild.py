"""Replay the unchanged 44-case workload against the frozen V2.9.5.1.1 build."""

from argparse import ArgumentParser
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import mkdtemp
from time import perf_counter
from zipfile import ZipFile

from appointment_benchmark.run import capture
from run_harness_pair import ROOT, open_ports, postgres_start, postgres_stop, POSTGRES


PROJECT = Path.home() / "RubyMineProjects/appointment-flow_v2.9.5.1.1"
REVISION = "e26f412b52c435e031e5beb40f33cbfddf652f59"
KIT = ROOT / "work/appointment_benchmark"
CASE_NAMES = ("cases.json", "recipient_change_cases.json", "later_day_cases.json", "historical_recipient_cases.json")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=PROJECT)
    parser.add_argument("--revision", default=REVISION)
    opts = parser.parse_args()
    project = opts.project.resolve(strict=True)
    revision = subprocess.check_output(["git", "-C", project, "rev-parse", "--verify", opts.revision + "^{commit}"], text=True).strip()
    run = Path(mkdtemp(prefix="v295-full-workload-", dir=ROOT / "work"))
    print(f"Matched V2.9.5.1.1 benchmark: {run}", flush=True)
    began = perf_counter()
    started = datetime.now(timezone.utc).isoformat()
    frozen = run / "source.zip"
    capture(run, "archive", ["git", "-C", project, "archive", "--format=zip", "--output", frozen, revision])
    source = run / "source"
    with ZipFile(frozen) as archive:
        assert archive.comment.decode() == revision
        archive.extractall(source)
    backend = source / "backend"
    case_files = [KIT / name for name in CASE_NAMES]
    cases = [case for path in case_files for case in json.loads(path.read_text(encoding="utf-8-sig"))]
    (run / "cases.json").write_text(json.dumps(cases, indent=2), encoding="utf-8")
    adapter = run / "candidate_adapter.rb"
    adapter.write_bytes((KIT / "v295_adapter.rb").read_bytes())
    port, = open_ports(1)
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(("PG", "APEX_", "BUNDLE_")) and not key.endswith("DATABASE_URL")
           and key not in {"DEMO_NOW", "RUBYOPT", "CLINIC_SETUP_FILE", "ASSESSMENT_REMINDERS_START"}}
    env.update(RAILS_ENV="test", PGHOST="127.0.0.1", PGPORT=str(port), PGUSER="postgres", PGSSLMODE="disable",
               APEX_DB_HOST="127.0.0.1", APEX_DB_PORT=str(port), APEX_DB_USER="apex_app", APEX_DB_PASSWORD="",
               APEX_TEST_DB="apex_benchmark_test", APEX_PMS_OWNER="postgres",
               BENCHMARK_ADAPTER="custom", BENCHMARK_ADAPTER_FILE=str(adapter),
               BENCHMARK_CASES=str(run / "cases.json"), AUDIT_TRACE=str(run / "trace.jsonl"), AUDIT_PHASE="benchmark",
               SECRET_KEY_BASE=hashlib.sha256(b"isolated full rebuild benchmark").hexdigest())
    info = dict(project=str(project), revision=revision, adapter="custom", postgres_port=port,
                started_at=started, setup="private loopback PostgreSQL with synthetic data", capture_plans=False,
                app_role="apex_app", case_sources=[dict(name=path.name, sha256=digest(path)) for path in case_files],
                source_archive_sha256=digest(frozen),
                benchmark_input_sha256={path.name: digest(path) for path in [run / "cases.json", adapter,
                    *(KIT / name for name in ("application.rb", "fixture.rb", "trace.rb", "summarize.py"))]})
    (run / "run.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    data, pglog = run / "postgres", run / "postgres.log"
    postgres_start(data, port, pglog)
    try:
        capture(run, "create-role", [POSTGRES / "psql.exe", "-X", "-d", "postgres", "-v", "ON_ERROR_STOP=1",
                "-c", "CREATE ROLE apex_app LOGIN"], env=env)
        capture(run, "create-database", [POSTGRES / "createdb.exe", "apex_benchmark_test"], env=env)
        capture(run, "provision-source", [POSTGRES / "psql.exe", "-X", "-d", "apex_benchmark_test", "-v",
                "ON_ERROR_STOP=1", "-f", backend / "db/pms.sql"], env=env)
        capture(run, "migrate", ["ruby", "bin/rails", "db:migrate"], backend, env)
        capture(run, "benchmark", ["ruby", "-r", KIT / "trace.rb", "bin/rails", "runner", "--skip-executor",
                KIT / "application.rb"], backend, env)
        capture(run, "query-source", ["ruby", "bin/rails", "runner", "-e", "test",
                source / "quality/check_active_record_queries.rb"], backend, env)
        try:
            capture(run, "summary", [sys.executable, KIT / "summarize.py", run])
        except RuntimeError:
            if not (run / "summary.csv").is_file():
                raise
    finally:
        postgres_stop(data, pglog)
        info.update(finished_at=datetime.now(timezone.utc).isoformat(), elapsed_seconds=round(perf_counter() - began, 3))
        (run / "run.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    print(f"Saved the unchanged-case result in {run / 'summary.csv'}", flush=True)


if __name__ == "__main__":
    main()
