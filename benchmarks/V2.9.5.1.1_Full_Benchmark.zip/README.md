# V2.9.5.1.1 full benchmark

Open the report for the recorded results. The evidence folder includes every measured SQL event, command receipt, outcome, fixture, and input checksum. The paired build archive includes the original public harness and frozen application.

To replay, use Windows with Git, Python 3, Ruby and Bundler for this app, and PostgreSQL 17 in its standard Program Files directory. Extract this ZIP. Extract application.zip from paired-build.zip into a project directory. Initialize a local Git repository and commit that snapshot. Install the backend's bundled gems. From this extracted ZIP directory, run the command below with the project path and its local snapshot commit. The replay creates a private database and records its own revision and input checksums.

```powershell
py work/benchmark_v295_rebuild.py --project "C:/path/to/snapshot" --revision HEAD
```
